jQuery(document).ready(function ($) {
    // Tab switching
    $('.wpsh-tabs .nav-tab').on('click', function (e) {
        e.preventDefault();

        // Update active tab
        $('.wpsh-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');

        // Show corresponding content
        var target = $(this).attr('href');
        $('.wpsh-tab-content').removeClass('active');
        $(target).addClass('active');
    });

    // Initialize security score circle
    $('.wpsh-score-circle').each(function () {
        var score = $(this).data('score');
        var fill = $(this).find('.wpsh-score-circle-fill');
        var text = $(this).find('.wpsh-score-circle-text span');

        // Set color based on score
        if (score >= 80) {
            fill.css('stroke', '#46b450'); // Green
        } else if (score >= 60) {
            fill.css('stroke', '#ffb900'); // Yellow
        } else {
            fill.css('stroke', '#dc3232'); // Red
        }
    });

    // Run security scan
    $('#wpsh-run-scan').on('click', function () {
        var $button = $(this);
        var $progress = $('.wpsh-scan-progress');
        var $progressBar = $('.wpsh-progress-bar-fill');
        var $progressText = $('.wpsh-progress-text');
        var $progressStatus = $('.wpsh-progress-status');
        var $results = $('#wpsh-scan-results');

        $button.prop('disabled', true).text(wpsh_admin.scanning);
        $progress.show();

        // Start the scan
        $.ajax({
            url: wpsh_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'wpsh_run_scan',
                nonce: wpsh_admin.nonce
            },
            success: function (response) {
                if (response.success) {
                    if (response.data.status === 'started') {
                        // Poll for progress
                        var progressInterval = setInterval(function () {
                            checkScanProgress();
                        }, 1000);

                        // Update the scan progress checking function
                        function checkScanProgress() {
                            $.ajax({
                                url: wpsh_admin.ajax_url,
                                type: 'POST',
                                data: {
                                    action: 'wpsh_scan_progress',
                                    nonce: wpsh_admin.nonce
                                },
                                success: function (response) {
                                    if (response.success) {
                                        var progress = response.data.progress;
                                        var status = response.data.status;

                                        $progressBar.css('width', progress + '%');
                                        $progressText.text(progress + '%');
                                        $progressStatus.text(status);

                                        if (!response.data.scan_in_progress || progress >= 100) {
                                            clearInterval(progressInterval);
                                            $button.prop('disabled', false).text(wpsh_admin.run_scan);
                                            $progressStatus.text(wpsh_admin.complete);

                                            // Reload after short delay to ensure results are saved
                                            setTimeout(function () {
                                                location.reload();
                                            }, 1000);
                                        }
                                    }
                                },
                                error: function () {
                                    clearInterval(progressInterval);
                                    $button.prop('disabled', false).text(wpsh_admin.run_scan);
                                    $progressStatus.text(__('Error checking progress', 'wp-security-hardener'));
                                }
                            });
                        }
                    }
                } else {
                    $results.html('<div class="error"><p>' + response.data + '</p></div>');
                }
            },
            error: function (xhr, status, error) {
                $results.html('<div class="error"><p>' + error + '</p></div>');
                $button.prop('disabled', false).text(wpsh_admin.run_scan);
                $progress.hide();
            }
        });
    });

    // Toggle advanced settings
    $('.wpsh-advanced-toggle').on('click', function (e) {
        e.preventDefault();
        $(this).closest('.wpsh-settings-section').find('.wpsh-advanced-settings').toggle();
    });
});

// Add this to your display_logs() method output
jQuery(document).ready(function($) {
    $('.location-unknown').each(function() {
        var $elem = $(this);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    $elem.text(position.coords.latitude + ', ' + position.coords.longitude);
                },
                function(error) {
                    console.log('Geolocation error:', error);
                }
            );
        }
    });
});

jQuery(document).ready(function($) {
    // Handle backup button click
    $(document).on('click', '.wpsh-create-backup', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        $button.prop('disabled', true).text('Creating Backup...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wpsh_create_db_backup',
                nonce: wpsh_scan_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Create download link
                    var $downloadLink = $('<a>', {
                        href: response.data.backup_url,
                        text: 'Download Backup',
                        class: 'button button-primary',
                        download: response.data.backup_file
                    });
                    
                    // Replace button with download link
                    $button.replaceWith($downloadLink);
                    
                    // Show success message
                    alert(response.data.message);
                } else {
                    alert(response.data.error);
                    $button.prop('disabled', false).text('Create Backup Now');
                }
            },
            error: function() {
                alert('An error occurred while creating the backup.');
                $button.prop('disabled', false).text('Create Backup Now');
            }
        });
    });
});