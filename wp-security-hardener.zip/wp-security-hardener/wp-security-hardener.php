<?php
/**
 * Plugin Name: WP Security Hardener Pro
 * Description: Comprehensive WordPress security plugin with scanning, hardening, and monitoring options.
 * Version: 2.0.0
 * Author: Amit Chauhan
 * License: GPL-2.0+
 * Text Domain: wp-security-hardener
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WPSH_VERSION', '2.0.0');
define('WPSH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPSH_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPSH_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once WPSH_PLUGIN_DIR . 'includes/class-security-scanner.php';
require_once WPSH_PLUGIN_DIR . 'includes/class-security-tweaks.php';
require_once WPSH_PLUGIN_DIR . 'includes/class-settings-page.php';
require_once WPSH_PLUGIN_DIR . 'includes/class-firewall.php';
require_once WPSH_PLUGIN_DIR . 'includes/class-login-protection.php';
require_once WPSH_PLUGIN_DIR . 'includes/class-activity-log.php';

/**
 * Main plugin class
 */
class WP_Security_Hardener {

    private static $instance = null;
    public $scanner;
    public $tweaks;
    public $settings;
    public $firewall;
    public $login_protection;
    public $activity_log;

    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));

        // Initialize components
        $this->scanner = new WPSH_Security_Scanner();
        $this->tweaks = new WPSH_Security_Tweaks();
        $this->settings = new WPSH_Settings_Page();
        $this->firewall = new WPSH_Firewall();
        $this->login_protection = new WPSH_Login_Protection();
        $this->activity_log = new WPSH_Activity_Log();

        // Activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Add security headers on init
        add_action('send_headers', array($this, 'add_security_headers'));
    }

    /**
     * Load plugin textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'wp-security-hardener',
            false,
            dirname(WPSH_PLUGIN_BASENAME) . '/languages'
        );
    }

    /**
     * Add security headers
     */
    public function add_security_headers() {
        if (get_option('wpsh_enable_security_headers')) {
            // X-XSS-Protection
            header('X-XSS-Protection: 1; mode=block');
            
            // X-Content-Type-Options
            header('X-Content-Type-Options: nosniff');
            
            // Strict-Transport-Security (HSTS)
            if (is_ssl()) {
                header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
            }
            
            // X-Frame-Options
            header('X-Frame-Options: SAMEORIGIN');
            
            // Content-Security-Policy
            if (get_option('wpsh_enable_csp')) {
                $csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' *.googleapis.com *.gstatic.com; style-src 'self' 'unsafe-inline' *.googleapis.com; img-src 'self' data: *.gravatar.com;";
                header("Content-Security-Policy: $csp");
            }
        }
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        if (!get_option('wpsh_installed')) {
            update_option('wpsh_disallow_file_edit', true);
            update_option('wpsh_prevent_php_execution', true);
            update_option('wpsh_enable_security_headers', true);
            update_option('wpsh_enable_login_protection', true);
            update_option('wpsh_login_attempts', 5);
            update_option('wpsh_login_lockout_time', 30);
            update_option('wpsh_enable_2fa', false);
            update_option('wpsh_enable_activity_log', true);
            update_option('wpsh_installed', time());
        }
        
        // Create database tables
        $this->activity_log->create_tables();
        
        // Schedule security scans
        if (!wp_next_scheduled('wpsh_daily_security_scan')) {
            wp_schedule_event(time(), 'daily', 'wpsh_daily_security_scan');
        }
        
        // Schedule database backups
        if (!wp_next_scheduled('wpsh_weekly_db_backup')) {
            wp_schedule_event(time(), 'weekly', 'wpsh_weekly_db_backup');
        }
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('wpsh_daily_security_scan');
        wp_clear_scheduled_hook('wpsh_weekly_db_backup');
        
        // Remove security tweaks
        $this->tweaks->disable_all_tweaks();
    }
}

// Initialize the plugin
WP_Security_Hardener::get_instance();