<?php
/**
 * Enhanced Activity logging functionality with location tracking and export options
 */
class WPSH_Activity_Log {

    public function __construct() {
        if (get_option('wpsh_enable_activity_log')) {
            // Log user activities
            add_action('wp_login', array($this, 'log_user_login'), 10, 2);
            add_action('wp_logout', array($this, 'log_user_logout'));
            add_action('profile_update', array($this, 'log_profile_update'), 10, 2);
            add_action('user_register', array($this, 'log_user_registration'));
            add_action('delete_user', array($this, 'log_user_deletion'));
            
            // Log content changes
            add_action('transition_post_status', array($this, 'log_post_status_change'), 10, 3);
            add_action('delete_post', array($this, 'log_post_deletion'));
            
            // Log plugin and theme changes
            add_action('activated_plugin', array($this, 'log_plugin_activation'));
            add_action('deactivated_plugin', array($this, 'log_plugin_deactivation'));
            add_action('switch_theme', array($this, 'log_theme_change'));
            
            // Handle log export and deletion
            add_action('admin_init', array($this, 'handle_log_actions'));
        }
    }

    /**
     * Create database tables with additional columns
     */
    public function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            user_id bigint(20),
            ip_address varchar(45),
            location varchar(255),
            action varchar(255) NOT NULL,
            object_type varchar(100),
            object_id bigint(20),
            description text NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY object_type (object_type)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Log activity with location tracking
     */
    public function log_activity($action, $description, $ip_address = null, $user_id = null, $object_type = null, $object_id = null) {
        global $wpdb;
        
        $ip_address = $ip_address ?: $this->get_client_ip();
        $user_id = $user_id ?: get_current_user_id();
        $location = $this->get_ip_location($ip_address);
        
        $wpdb->insert(
            $wpdb->prefix . 'wpsh_activity_log',
            array(
                'time' => current_time('mysql'),
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'location' => $location,
                'action' => $action,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'description' => $description
            )
        );
    }

    /**
     * Log user login
     */
    public function log_user_login($user_login, $user) {
        $this->log_activity(
            'login',
            sprintf(__('User %s logged in', 'wp-security-hardener'), $user_login),
            null,
            $user->ID
        );
    }

    /**
     * Log user logout
     */
    public function log_user_logout() {
        $user = wp_get_current_user();
        if ($user->ID > 0) {
            $this->log_activity(
                'logout',
                sprintf(__('User %s logged out', 'wp-security-hardener'), $user->user_login),
                null,
                $user->ID
            );
        }
    }

    /**
     * Log profile update
     */
    public function log_profile_update($user_id, $old_user_data) {
        $user = get_user_by('id', $user_id);
        $this->log_activity(
            'profile_update',
            sprintf(__('User profile updated: %s', 'wp-security-hardener'), $user->user_login),
            null,
            $user_id
        );
    }

    /**
     * Log user registration
     */
    public function log_user_registration($user_id) {
        $user = get_user_by('id', $user_id);
        $this->log_activity(
            'user_register',
            sprintf(__('New user registered: %s', 'wp-security-hardener'), $user->user_login),
            null,
            $user_id
        );
    }

    /**
     * Log user deletion
     */
    public function log_user_deletion($user_id) {
        $user = get_user_by('id', $user_id);
        $this->log_activity(
            'user_delete',
            sprintf(__('User deleted: %s', 'wp-security-hardener'), $user->user_login),
            null,
            $user_id
        );
    }

    /**
     * Log post status change
     */
    public function log_post_status_change($new_status, $old_status, $post) {
        if ($old_status === 'new' || $new_status === $old_status) {
            return;
        }
        
        $user = wp_get_current_user();
        $post_type = get_post_type_object($post->post_type);
        
        $this->log_activity(
            'post_status_change',
            sprintf(
                __('%s "%s" status changed from %s to %s', 'wp-security-hardener'),
                $post_type->labels->singular_name,
                $post->post_title,
                $old_status,
                $new_status
            ),
            null,
            $user->ID
        );
    }

    /**
     * Log post deletion
     */
    public function log_post_deletion($post_id) {
        $post = get_post($post_id);
        $user = wp_get_current_user();
        $post_type = get_post_type_object($post->post_type);
        
        $this->log_activity(
            'post_delete',
            sprintf(
                __('%s "%s" deleted', 'wp-security-hardener'),
                $post_type->labels->singular_name,
                $post->post_title
            ),
            null,
            $user->ID
        );
    }

    /**
     * Log plugin activation
     */
    public function log_plugin_activation($plugin) {
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
        $user = wp_get_current_user();
        
        $this->log_activity(
            'plugin_activate',
            sprintf(__('Plugin activated: %s', 'wp-security-hardener'), $plugin_data['Name']),
            null,
            $user->ID
        );
    }

    /**
     * Log plugin deactivation
     */
    public function log_plugin_deactivation($plugin) {
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
        $user = wp_get_current_user();
        
        $this->log_activity(
            'plugin_deactivate',
            sprintf(__('Plugin deactivated: %s', 'wp-security-hardener'), $plugin_data['Name']),
            null,
            $user->ID
        );
    }

    /**
     * Log theme change
     */
    public function log_theme_change($new_theme) {
        $user = wp_get_current_user();
        $this->log_activity(
            'theme_switch',
            sprintf(__('Theme changed to: %s', 'wp-security-hardener'), $new_theme),
            null,
            $user->ID
        );
    }
    /**
     * Get approximate location from IP address
     */
private function get_ip_location($ip_address) {
    // Skip local IPs
    if ($ip_address === '127.0.0.1' || substr($ip_address, 0, 3) === '10.' || 
        substr($ip_address, 0, 8) === '192.168.' || substr($ip_address, 0, 7) === '172.16.') {
        return 'Local Network';
    }

    // Try multiple services as fallback
    $services = [
        'ipapi' => "https://ipapi.co/{$ip_address}/json/",
        'ipinfo' => "https://ipinfo.io/{$ip_address}/json?token=YOUR_TOKEN", // Get free token at ipinfo.io
        'geoplugin' => "http://www.geoplugin.net/json.gp?ip={$ip_address}"
    ];

    foreach ($services as $service => $url) {
        $response = wp_remote_get($url, [
            'timeout' => 3,
            'sslverify' => false
        ]);

        if (!is_wp_error($response)) {
            $data = json_decode($response['body'], true);
            
            // ipapi.co format
            if ($service === 'ipapi' && isset($data['city'])) {
                $location = [];
                if (!empty($data['city'])) $location[] = $data['city'];
                if (!empty($data['region'])) $location[] = $data['region'];
                if (!empty($data['country_name'])) $location[] = $data['country_name'];
                return implode(', ', $location);
            }
            
            // ipinfo.io format
            if ($service === 'ipinfo' && isset($data['city'])) {
                $location = [];
                if (!empty($data['city'])) $location[] = $data['city'];
                if (!empty($data['region'])) $location[] = $data['region'];
                if (!empty($data['country'])) $location[] = $data['country'];
                return implode(', ', $location);
            }
            
            // geoplugin format
            if ($service === 'geoplugin' && isset($data['geoplugin_city'])) {
                $location = [];
                if (!empty($data['geoplugin_city'])) $location[] = $data['geoplugin_city'];
                if (!empty($data['geoplugin_regionName'])) $location[] = $data['geoplugin_regionName'];
                if (!empty($data['geoplugin_countryName'])) $location[] = $data['geoplugin_countryName'];
                return implode(', ', $location);
            }
        }
    }

    return 'Unknown';
}

    /**
     * Handle log export and deletion actions
     */
    public function handle_log_actions() {
        if (!isset($_GET['wpsh_log_action']) || !isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'wpsh_log_action')) {
            return;
        }
        
        $action = $_GET['wpsh_log_action'];
        
        switch ($action) {
            case 'export':
                $this->export_logs();
                break;
                
            case 'delete_all':
                $this->delete_all_logs();
                break;
                
            case 'delete_old':
                $this->delete_old_logs();
                break;
                
            case 'delete_selected':
                if (isset($_GET['log_ids'])) {
                    $this->delete_selected_logs($_GET['log_ids']);
                }
                break;
        }
    }

    /**
     * Export logs to CSV
     */
    private function export_logs() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY time DESC");
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="wpsh_activity_logs_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // CSV header
        fputcsv($output, array(
            __('Date', 'wp-security-hardener'),
            __('User', 'wp-security-hardener'),
            __('IP Address', 'wp-security-hardener'),
            __('Location', 'wp-security-hardener'),
            __('Action', 'wp-security-hardener'),
            __('Description', 'wp-security-hardener')
        ));
        
        // CSV data
        foreach ($logs as $log) {
            $user = $log->user_id ? get_user_by('id', $log->user_id) : null;
            
            fputcsv($output, array(
                date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->time)),
                $user ? $user->user_login : __('System', 'wp-security-hardener'),
                $log->ip_address,
                $log->location,
                ucfirst(str_replace('_', ' ', $log->action)),
                $log->description
            ));
        }
        
        fclose($output);
        exit;
    }

    /**
     * Delete all logs
     */
    private function delete_all_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $wpdb->query("TRUNCATE TABLE $table_name");
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('All activity logs have been deleted.', 'wp-security-hardener') . '</p></div>';
        });
    }

    /**
     * Delete logs older than 30 days
     */
    private function delete_old_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE time < %s",
            date('Y-m-d H:i:s', strtotime('-30 days'))
        ));
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Activity logs older than 30 days have been deleted.', 'wp-security-hardener') . '</p></div>';
        });
    }

    /**
     * Delete selected logs
     */
    private function delete_selected_logs($log_ids) {
        if (!is_array($log_ids)) {
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $placeholders = implode(',', array_fill(0, count($log_ids), '%d'));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE id IN ($placeholders)",
            $log_ids
        ));
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Selected activity logs have been deleted.', 'wp-security-hardener') . '</p></div>';
        });
    }

    /**
     * Display activity logs with management options
     */
    public function display_logs() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wpsh_activity_log';
        $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY time DESC LIMIT 500");
        
        // Action URLs with nonce
        $export_url = wp_nonce_url(add_query_arg('wpsh_log_action', 'export'), 'wpsh_log_action');
        $delete_all_url = wp_nonce_url(add_query_arg('wpsh_log_action', 'delete_all'), 'wpsh_log_action');
        $delete_old_url = wp_nonce_url(add_query_arg('wpsh_log_action', 'delete_old'), 'wpsh_log_action');
        ?>
        <div class="wrap">
            <h1><?php _e('Activity Logs', 'wp-security-hardener'); ?></h1>
            
            <div class="wpsh-log-actions">
                <a href="<?php echo esc_url($export_url); ?>" class="button button-primary">
                    <?php _e('Export to CSV', 'wp-security-hardener'); ?>
                </a>
                <a href="<?php echo esc_url($delete_old_url); ?>" class="button" onclick="return confirm('<?php _e('Are you sure you want to delete logs older than 30 days?', 'wp-security-hardener'); ?>')">
                    <?php _e('Delete Old Logs (30+ days)', 'wp-security-hardener'); ?>
                </a>
                <a href="<?php echo esc_url($delete_all_url); ?>" class="button button-danger" onclick="return confirm('<?php _e('Are you sure you want to delete ALL activity logs? This cannot be undone.', 'wp-security-hardener'); ?>')">
                    <?php _e('Delete All Logs', 'wp-security-hardener'); ?>
                </a>
            </div>
            
            <form method="get" action="">
                <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page']); ?>">
                <?php wp_nonce_field('wpsh_log_action', '_wpnonce'); ?>
                <input type="hidden" name="wpsh_log_action" value="delete_selected">
                
                <div class="wpsh-activity-logs">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th class="manage-column column-cb check-column"><input type="checkbox" id="select-all-logs"></th>
                                <th><?php _e('Date', 'wp-security-hardener'); ?></th>
                                <th><?php _e('User', 'wp-security-hardener'); ?></th>
                                <th><?php _e('IP Address', 'wp-security-hardener'); ?></th>
                                <th><?php _e('Location', 'wp-security-hardener'); ?></th>
                                <th><?php _e('Action', 'wp-security-hardener'); ?></th>
                                <th><?php _e('Description', 'wp-security-hardener'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($logs)): ?>
                                <tr>
                                    <td colspan="7"><?php _e('No activity logs found.', 'wp-security-hardener'); ?></td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <th scope="row" class="check-column"><input type="checkbox" name="log_ids[]" value="<?php echo esc_attr($log->id); ?>"></th>
                                        <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->time))); ?></td>
                                        <td>
                                            <?php if ($log->user_id): ?>
                                                <?php $user = get_user_by('id', $log->user_id); ?>
                                                <?php echo esc_html($user->user_login); ?>
                                            <?php else: ?>
                                                <?php _e('System', 'wp-security-hardener'); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo esc_html($log->ip_address); ?></td>
                                        <!-- <td><//?php echo esc_html($log->location); ?></td> -->
                                        <td class="<?php echo $log->location === 'Unknown' ? 'location-unknown' : ''; ?>">
    <?php echo esc_html($log->location); ?>
</td>
                                        <td><?php echo esc_html(ucfirst(str_replace('_', ' ', $log->action))); ?></td>
                                        <td><?php echo esc_html($log->description); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (!empty($logs)): ?>
                    <div class="tablenav bottom">
                        <div class="alignleft actions bulkactions">
                            <button type="submit" class="button button-danger" onclick="return confirm('<?php _e('Are you sure you want to delete the selected logs?', 'wp-security-hardener'); ?>')">
                                <?php _e('Delete Selected', 'wp-security-hardener'); ?>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </form>
            
            <script>
                jQuery(document).ready(function($) {
                    $('#select-all-logs').on('click', function() {
                        $('input[name="log_ids[]"]').prop('checked', $(this).prop('checked'));
                    });
                });
            </script>
            
            <style>
                .wpsh-log-actions {
                    margin-bottom: 20px;
                }
                .button-danger {
                    color: #a00;
                    border-color: #a00;
                }
                .button-danger:hover {
                    color: #fff;
                    background: #a00;
                    border-color: #a00;
                }
            </style>
        </div>
        <?php
    }

  
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
}