<?php
/**
 * Security hardening implementations
 */
class WPSH_Security_Tweaks {

    public function __construct() {
        // Initialize security tweaks based on settings
        add_action('init', array($this, 'apply_tweaks'));
        
        // Handle settings updates
        add_action('update_option_wpsh_disallow_file_edit', array($this, 'toggle_file_edit'), 10, 2);
        add_action('update_option_wpsh_prevent_php_execution', array($this, 'toggle_php_execution'), 10, 2);
        add_action('update_option_wpsh_enable_security_headers', array($this, 'toggle_security_headers'), 10, 2);
        
        // Add weekly database backup
        add_action('wpsh_weekly_db_backup', array($this, 'perform_db_backup'));
    }

    /**
     * Apply all active security tweaks
     */
    public function apply_tweaks() {
        if (get_option('wpsh_disallow_file_edit')) {
            $this->enable_file_edit_protection();
        }
        
        if (get_option('wpsh_prevent_php_execution')) {
            $this->prevent_php_execution();
        }
        
        if (get_option('wpsh_enable_security_headers')) {
            $this->enable_security_headers();
        }
        
        // Disable XML-RPC if not needed
        if (get_option('wpsh_disable_xmlrpc')) {
            $this->disable_xmlrpc();
        }
        
        // Disable directory listing
        $this->disable_directory_listing();
    }

    /**
     * Disable all tweaks on plugin deactivation
     */
    public function disable_all_tweaks() {
        $this->disable_file_edit_protection();
        $this->allow_php_execution();
        $this->disable_security_headers();
    }

    /**
     * Enable/disable file edit protection
     */
    public function toggle_file_edit($old_value, $new_value) {
        if ((bool)$new_value) {
            $this->enable_file_edit_protection();
        } else {
            $this->disable_file_edit_protection();
        }
    }

    /**
     * Enable file edit protection
     */
    private function enable_file_edit_protection() {
        $config_file = $this->locate_wp_config();
        
        if (!$config_file || !is_writable($config_file)) {
            return false;
        }
        
        $config_contents = file_get_contents($config_file);
        
        if (strpos($config_contents, 'DISALLOW_FILE_EDIT') === false) {
            $config_contents = preg_replace(
                '/^<\?php\s*/',
                "<?php\ndefine('DISALLOW_FILE_EDIT', true);\n",
                $config_contents
            );
            file_put_contents($config_file, $config_contents);
        }
        
        return true;
    }

    /**
     * Disable file edit protection
     */
    private function disable_file_edit_protection() {
        $config_file = $this->locate_wp_config();
        
        if (!$config_file || !is_writable($config_file)) {
            return false;
        }
        
        $config_contents = file_get_contents($config_file);
        $config_contents = preg_replace(
            "/define\s*\(\s*'DISALLOW_FILE_EDIT'\s*,\s*true\s*\)\s*;\s*/",
            '',
            $config_contents
        );
        file_put_contents($config_file, $config_contents);
        
        return true;
    }

    /**
     * Enable/disable PHP execution protection
     */
    public function toggle_php_execution($old_value, $new_value) {
        if ((bool)$new_value) {
            $this->prevent_php_execution();
        } else {
            $this->allow_php_execution();
        }
    }

    /**
     * Prevent PHP execution in sensitive directories
     */
    private function prevent_php_execution() {
        $directories = array(
            WP_CONTENT_DIR . '/uploads/',
            WP_CONTENT_DIR . '/languages/',
            WP_PLUGIN_DIR . '/',
        );
        
        $htaccess_content = "<Files *.php>\n    deny from all\n</Files>";
        
        foreach ($directories as $dir) {
            if (!is_dir($dir)) continue;
            
            $htaccess_file = trailingslashit($dir) . '.htaccess';
            
            if (!file_exists($htaccess_file)) {
                if (is_writable($dir)) {
                    file_put_contents($htaccess_file, $htaccess_content);
                }
            }
        }
    }

    /**
     * Allow PHP execution in sensitive directories
     */
    private function allow_php_execution() {
        $directories = array(
            WP_CONTENT_DIR . '/uploads/',
            WP_CONTENT_DIR . '/languages/',
            WP_PLUGIN_DIR . '/',
        );
        
        foreach ($directories as $dir) {
            if (!is_dir($dir)) continue;
            
            $htaccess_file = trailingslashit($dir) . '.htaccess';
            
            if (file_exists($htaccess_file)) {
                $contents = file_get_contents($htaccess_file);
                if (strpos($contents, 'deny from all') !== false) {
                    unlink($htaccess_file);
                }
            }
        }
    }

    /**
     * Enable/disable security headers
     */
    public function toggle_security_headers($old_value, $new_value) {
        if ((bool)$new_value) {
            $this->enable_security_headers();
        } else {
            $this->disable_security_headers();
        }
    }

    /**
     * Enable security headers
     */
    private function enable_security_headers() {
        // Headers are added via the main plugin class
    }

    /**
     * Disable security headers
     */
    private function disable_security_headers() {
        // Headers are removed via the main plugin class
    }

    /**
     * Disable XML-RPC
     */
    private function disable_xmlrpc() {
        add_filter('xmlrpc_enabled', '__return_false');
        add_filter('wp_headers', array($this, 'remove_x_pingback'));
    }

    /**
     * Remove X-Pingback header
     */
    public function remove_x_pingback($headers) {
        unset($headers['X-Pingback']);
        return $headers;
    }

    /**
     * Disable directory listing
     */
    private function disable_directory_listing() {
        $htaccess_file = ABSPATH . '.htaccess';
        $rules = "Options -Indexes\n";
        
        if (file_exists($htaccess_file)) {
            $contents = file_get_contents($htaccess_file);
            if (strpos($contents, 'Options -Indexes') === false) {
                file_put_contents($htaccess_file, $rules, FILE_APPEND);
            }
        } else {
            file_put_contents($htaccess_file, $rules);
        }
    }

    /**
     * Perform database backup
     */
    public function perform_db_backup() {
        if (!get_option('wpsh_enable_db_backup')) {
            return;
        }
        
        global $wpdb;
        
        $tables = $wpdb->get_col('SHOW TABLES');
        $backup_file = WP_CONTENT_DIR . '/backups/db-backup-' . date('Y-m-d-H-i-s') . '.sql';
        $backup_dir = dirname($backup_file);
        
        if (!is_dir($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }
        
        $handle = fopen($backup_file, 'w+');
        
        foreach ($tables as $table) {
            $create_table = $wpdb->get_row("SHOW CREATE TABLE $table", ARRAY_N);
            fwrite($handle, "-- Table structure for table `$table`\n");
            fwrite($handle, $create_table[1] . ";\n\n");
            
            $rows = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);
            if (!empty($rows)) {
                fwrite($handle, "-- Data for table `$table`\n");
                $insert = "INSERT INTO `$table` VALUES ";
                $values = array();
                
                foreach ($rows as $row) {
                    $row_values = array();
                    foreach ($row as $value) {
                        $row_values[] = $wpdb->prepare('%s', $value);
                    }
                    $values[] = '(' . implode(',', $row_values) . ')';
                }
                
                fwrite($handle, $insert . implode(',', $values) . ";\n\n");
            }
        }
        
        fclose($handle);
        
        // Compress the backup
        if (function_exists('gzopen')) {
            $compressed_file = $backup_file . '.gz';
            $gz = gzopen($compressed_file, 'w9');
            gzwrite($gz, file_get_contents($backup_file));
            gzclose($gz);
            unlink($backup_file);
            $backup_file = $compressed_file;
        }
        
        update_option('wpsh_last_db_backup', current_time('mysql'));
        
        // Send email notification
        $admin_email = get_option('admin_email');
        $subject = sprintf(__('[%s] Database Backup Completed', 'wp-security-hardener'), get_bloginfo('name'));
        $message = __('A database backup was successfully created.', 'wp-security-hardener') . "\n";
        $message .= __('Backup file:', 'wp-security-hardener') . ' ' . basename($backup_file) . "\n";
        $message .= __('Backup size:', 'wp-security-hardener') . ' ' . size_format(filesize($backup_file)) . "\n";
        
        wp_mail($admin_email, $subject, $message);
    }

    /**
     * Locate wp-config.php file
     */
    private function locate_wp_config() {
        $config_file = ABSPATH . 'wp-config.php';
        
        if (!file_exists($config_file)) {
            $config_file = dirname(ABSPATH) . '/wp-config.php';
        }
        
        return file_exists($config_file) ? $config_file : false;
    }
}