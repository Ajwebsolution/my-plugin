<?php
/**
 * Security scanner functionality
 */
class WPSH_Security_Scanner {

    private $scan_progress = 0;
    private $total_checks = 8; // Total number of checks we'll perform

    public function __construct() {
        // Hook into daily scan event
        add_action('wpsh_daily_security_scan', array($this, 'run_daily_scan'));
        
        // Add manual scan AJAX handler
        add_action('wp_ajax_wpsh_run_scan', array($this, 'ajax_run_scan'));
        
        // Add progress check AJAX handler
        add_action('wp_ajax_wpsh_scan_progress', array($this, 'ajax_scan_progress'));
            // Add DB backup AJAX handler
        add_action('wp_ajax_wpsh_create_db_backup', array($this, 'ajax_create_db_backup'));
    }

    /**
     * Run comprehensive security scan
     */
    public function run_scan() {
        $this->scan_progress = 0;
        $results = array();
        
        // Update progress
        $this->update_progress(10, __('Starting scan...', 'wp-security-hardener'));
        
        // File permissions check
        $results['file_permissions'] = $this->check_file_permissions();
        $this->update_progress(20, __('Checking file permissions...', 'wp-security-hardener'));
        
        // Database security check
        $results['database_security'] = $this->check_database_security();
        $this->update_progress(30, __('Checking database security...', 'wp-security-hardener'));
        
        // User accounts check
        $results['user_accounts'] = $this->check_user_accounts();
        $this->update_progress(40, __('Checking user accounts...', 'wp-security-hardener'));
        
        // Core integrity check
        $results['core_integrity'] = $this->check_core_integrity();
        $this->update_progress(50, __('Checking WordPress core integrity...', 'wp-security-hardener'));
        
        // Plugins and themes check
        $results['plugins_themes'] = $this->check_plugins_themes();
        $this->update_progress(60, __('Checking plugins and themes...', 'wp-security-hardener'));
        
        // Server configuration check
        $results['server_config'] = $this->check_server_config();
        $this->update_progress(70, __('Checking server configuration...', 'wp-security-hardener'));
        
        // Security headers check
        $results['security_headers'] = $this->check_security_headers();
        $this->update_progress(80, __('Checking security headers...', 'wp-security-hardener'));
        
        // Firewall rules check
        $results['firewall_rules'] = $this->check_firewall_rules();
        $this->update_progress(90, __('Checking firewall rules...', 'wp-security-hardener'));
        
        // Calculate security score
        $results['security_score'] = $this->calculate_security_score($results);
        $this->update_progress(100, __('Finalizing results...', 'wp-security-hardener'));
        
        $results['timestamp'] = current_time('timestamp');
        
        update_option('wpsh_last_scan_results', $results);
        update_option('wpsh_last_scan_time', current_time('mysql'));
        
        // Reset progress
        delete_option('wpsh_scan_in_progress');
        delete_option('wpsh_scan_progress');
        delete_option('wpsh_scan_status');
        
        return $results;
    }

    /**
     * Update scan progress
     */
    private function update_progress($percent, $status) {
        $this->scan_progress = $percent;
        update_option('wpsh_scan_in_progress', true);
        update_option('wpsh_scan_progress', $percent);
        update_option('wpsh_scan_status', $status);
    }

    /**
     * Run daily scheduled scan
     */
    public function run_daily_scan() {
        $this->run_scan();
        
        // Send email notification if enabled
        if (get_option('wpsh_scan_email_notify')) {
            $this->send_scan_notification();
        }
    }

    /**
     * Send scan notification email
     */
    private function send_scan_notification() {
        $results = get_option('wpsh_last_scan_results');
        $admin_email = get_option('admin_email');
        $site_name = get_bloginfo('name');
        
        $subject = sprintf(__('[%s] Security Scan Completed', 'wp-security-hardener'), $site_name);
        
        $message = sprintf(__('A security scan was completed on %s with the following results:', 'wp-security-hardener'), date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $results['timestamp'])) . "\n\n";
        
        $message .= sprintf(__('Security Score: %d%%', 'wp-security-hardener'), $results['security_score']) . "\n\n";
        
        $total_issues = 0;
        foreach ($results as $section => $issues) {
            if (in_array($section, array('timestamp', 'security_score'))) continue;
            
            $message .= ucfirst(str_replace('_', ' ', $section)) . ":\n";
            
            if (empty($issues)) {
                $message .= __('No issues found', 'wp-security-hardener') . "\n";
            } else {
                $total_issues += count($issues);
                foreach ($issues as $issue) {
                    $message .= "- " . $issue['message'] . "\n";
                }
            }
            $message .= "\n";
        }
        
        $message .= sprintf(__('Total issues found: %d', 'wp-security-hardener'), $total_issues) . "\n\n";
        $message .= __('You can view the full report in your WordPress admin dashboard.', 'wp-security-hardener');
        
        wp_mail($admin_email, $subject, $message);
    }

    /**
     * AJAX handler for manual scan
     */
    public function ajax_run_scan() {
    check_ajax_referer('wpsh_scan_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('You do not have sufficient permissions.', 'wp-security-hardener'));
    }
    
    // Clear previous scan data
    delete_option('wpsh_scan_in_progress');
    delete_option('wpsh_scan_progress');
    delete_option('wpsh_scan_status');
    
    // Run scan in background
    wp_schedule_single_event(time(), 'wpsh_daily_security_scan');
    
    wp_send_json_success(array(
        'message' => __('Scan started in the background. Please wait...', 'wp-security-hardener'),
        'status' => 'started'
    ));
}

public function ajax_scan_progress() {
    check_ajax_referer('wpsh_scan_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('You do not have sufficient permissions.', 'wp-security-hardener'));
    }
    
    $response = array(
        'progress' => get_option('wpsh_scan_progress', 0),
        'status' => get_option('wpsh_scan_status', __('Preparing scan...', 'wp-security-hardener')),
        'scan_in_progress' => get_option('wpsh_scan_in_progress', false)
    );
    
    wp_send_json_success($response);
}

    /**
     * Calculate security score
     */
    /**
 * Calculate security score
 */
private function calculate_security_score($results) {
    $total_issues = 0;
    $weighted_score = 0;
    $max_score = 0;
    
    // Define weights for each severity level
    $severity_weights = array(
        'high' => 3,    // Most severe
        'medium' => 2,  // Medium severity
        'warning' => 1  // Least severe
    );
    
    // First calculate maximum possible score (worst case scenario)
    foreach ($results as $section => $issues) {
        if (in_array($section, array('timestamp', 'security_score'))) continue;
        $max_score += count($issues) * 3; // 3 = weight of high severity
    }
    
    // If no issues found, return perfect score
    if ($max_score == 0) {
        return 100;
    }
    
    // Calculate actual weighted score
    foreach ($results as $section => $issues) {
        if (in_array($section, array('timestamp', 'security_score'))) continue;
        
        foreach ($issues as $issue) {
            $weight = isset($severity_weights[$issue['type']]) ? $severity_weights[$issue['type']] : 1;
            $weighted_score += $weight;
        }
    }
    
    // Calculate percentage (100% minus penalty percentage)
    $score = 100 - (($weighted_score / $max_score) * 100);
    
    // Ensure score is between 0-100 and round to nearest integer
    return max(0, min(100, round($score)));
}

    /**
     * Check file permissions
     */
    private function check_file_permissions() {
        $issues = array();
        
        // Check wp-config.php
        $wp_config = ABSPATH . 'wp-config.php';
        if (file_exists($wp_config)) {
            $perms = substr(sprintf('%o', fileperms($wp_config)), -4);
            if ($perms !== '0400') {
                $issues[] = array(
                    'type' => 'high',
                    'message' => sprintf(__('wp-config.php permissions are %s - should be 400 for better security.', 'wp-security-hardener'), $perms),
                    'fix' => 'chmod 400 ' . $wp_config
                );
            }
        }
        
        // Check uploads directory
        $uploads_dir = wp_upload_dir();
        if (isset($uploads_dir['basedir'])) {
            $perms = substr(sprintf('%o', fileperms($uploads_dir['basedir'])), -4);
            if ($perms !== '0755') {
                $issues[] = array(
                    'type' => 'medium',
                    'message' => sprintf(__('Uploads directory permissions are %s - should be 755.', 'wp-security-hardener'), $perms),
                    'fix' => 'chmod 755 ' . $uploads_dir['basedir']
                );
            }
            
            // Check for unprotected directories
            $subdirs = array('', 'cache', 'backups');
            foreach ($subdirs as $subdir) {
                $dir = trailingslashit($uploads_dir['basedir']) . $subdir;
                if (is_dir($dir) && !file_exists(trailingslashit($dir) . '.htaccess')) {
                    $issues[] = array(
                        'type' => 'medium',
                        'message' => sprintf(__('No .htaccess file found in %s directory.', 'wp-security-hardener'), $dir),
                        'fix' => __('Add .htaccess file with deny rules.', 'wp-security-hardener')
                    );
                }
            }
        }
        
        // Check wp-content directory
        $wp_content_perms = substr(sprintf('%o', fileperms(WP_CONTENT_DIR)), -4);
        if ($wp_content_perms !== '0755') {
            $issues[] = array(
                'type' => 'medium',
                'message' => sprintf(__('wp-content directory permissions are %s - should be 755.', 'wp-security-hardener'), $wp_content_perms),
                'fix' => 'chmod 755 ' . WP_CONTENT_DIR
            );
        }
        
        return $issues;
    }

    /**
     * AJAX handler for creating database backup
     */
    public function ajax_create_db_backup() {
        check_ajax_referer('wpsh_scan_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'wp-security-hardener'));
        }
        
        $result = $this->create_database_backup();
        
        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Database backup created successfully!', 'wp-security-hardener'),
                'backup_file' => basename($result['file']),
                'backup_url' => content_url('/wpsh-backups/' . basename($result['file']))
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to create database backup.', 'wp-security-hardener'),
                'error' => $result['error']
            ));
        }
    }

    
    /**
     * Create database backup
     */
    private function create_database_backup() {
        global $wpdb;
        
        // Create backup directory if it doesn't exist
        $backup_dir = WP_CONTENT_DIR . '/wpsh-backups';
        if (!file_exists($backup_dir)) {
            if (!wp_mkdir_p($backup_dir)) {
                return array(
                    'success' => false,
                    'error' => __('Could not create backup directory.', 'wp-security-hardener')
                );
            }
            
            // Add .htaccess for security
            file_put_contents($backup_dir . '/.htaccess', 'deny from all');
        }
        
        // Generate filename with timestamp
        $backup_file = $backup_dir . '/db-backup-' . sanitize_file_name(get_bloginfo('name')) . '-' . current_time('Y-m-d-H-i-s') . '.sql';
        
        // Get all tables
        $tables = $wpdb->get_col('SHOW TABLES');
        
        $output = '';
        
        try {
            // Add SQL header
            $output .= "-- WordPress Database Backup\n";
            $output .= "-- Generated: " . current_time('mysql') . "\n";
            $output .= "-- Site: " . get_bloginfo('name') . " (" . home_url() . ")\n";
            $output .= "-- Host: " . DB_HOST . "\n";
            $output .= "-- Database: " . DB_NAME . "\n\n";
            $output .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";
            
            foreach ($tables as $table) {
                // Skip if not our prefix (for multisite)
                if (!empty($wpdb->prefix) && strpos($table, $wpdb->prefix) !== 0) {
                    continue;
                }
                
                // Add table structure
                $output .= "--\n-- Table structure for table `$table`\n--\n\n";
                $output .= "DROP TABLE IF EXISTS `$table`;\n";
                $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
                $output .= $create_table[1] . ";\n\n";
                
                // Add table data
                $output .= "--\n-- Dumping data for table `$table`\n--\n\n";
                
                $rows = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
                if (!empty($rows)) {
                    $output .= "INSERT INTO `$table` VALUES\n";
                    $row_count = count($rows);
                    $current = 1;
                    
                    foreach ($rows as $row) {
                        $values = array();
                        foreach ($row as $value) {
                            $values[] = "'" . $wpdb->_real_escape($value) . "'";
                        }
                        $output .= "(" . implode(',', $values) . ")";
                        
                        if ($current < $row_count) {
                            $output .= ",\n";
                        } else {
                            $output .= ";\n\n";
                        }
                        $current++;
                    }
                }
            }
            
            $output .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            
            // Save to file
            if (file_put_contents($backup_file, $output) !== false) {
                // Update last backup time
                update_option('wpsh_last_db_backup', current_time('mysql'));
                
                return array(
                    'success' => true,
                    'file' => $backup_file
                );
            } else {
                return array(
                    'success' => false,
                    'error' => __('Could not write backup file.', 'wp-security-hardener')
                );
            }
        } catch (Exception $e) {
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    /**
     * Enhanced database security check with backup button
     */
    private function check_database_security() {
        $issues = array();
        global $wpdb, $table_prefix;
        
        // Check table prefix
        if ($table_prefix === 'wp_') {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('Database is using default table prefix "wp_" which is insecure.', 'wp-security-hardener'),
                'fix' => __('Consider changing the table prefix.', 'wp-security-hardener')
            );
        }
        
        // Check for admin users with default username
        $admin_users = $wpdb->get_results(
            "SELECT user_login FROM {$wpdb->users} 
             INNER JOIN {$wpdb->usermeta} ON {$wpdb->users}.ID = {$wpdb->usermeta}.user_id
             WHERE {$wpdb->usermeta}.meta_key = '{$wpdb->prefix}capabilities'
             AND {$wpdb->usermeta}.meta_value LIKE '%administrator%'
             AND {$wpdb->users}.user_login = 'admin'"
        );
        
        if (!empty($admin_users)) {
            $issues[] = array(
                'type' => 'high',
                'message' => __('Administrator account with username "admin" exists.', 'wp-security-hardener'),
                'fix' => __('Create a new admin account and delete the "admin" account.', 'wp-security-hardener')
            );
        }
        
        // Check for weak database passwords
        if (defined('DB_PASSWORD') && strlen(DB_PASSWORD) < 12) {
            $issues[] = array(
                'type' => 'high',
                'message' => __('Database password is too short (less than 12 characters).', 'wp-security-hardener'),
                'fix' => __('Change the database password to a stronger one.', 'wp-security-hardener')
            );
        }
        
        // Enhanced backup check with backup button option
        $last_backup = get_option('wpsh_last_db_backup');
        if (!$last_backup || strtotime($last_backup) < strtotime('-7 days')) {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('No recent database backup found (older than 7 days).', 'wp-security-hardener'),
                'fix' => __('Create a database backup immediately.', 'wp-security-hardener'),
                'action' => array(
                    'type' => 'button',
                    'label' => __('Create Backup Now', 'wp-security-hardener'),
                    'class' => 'wpsh-create-backup',
                    'handler' => 'wpsh_create_db_backup'
                )
            );
        }
        
        return $issues;
    }

    /**
     * Check user accounts
     */
    private function check_user_accounts() {
        $issues = array();
        $users = get_users();
        
        // Check for weak passwords
        foreach ($users as $user) {
            if (empty($user->user_pass)) continue;
            
            if (wp_check_password('password', $user->user_pass) || 
                wp_check_password('123456', $user->user_pass) || 
                wp_check_password($user->user_login, $user->user_pass)) {
                $issues[] = array(
                    'type' => 'high',
                    'message' => sprintf(__('User "%s" has a very weak password.', 'wp-security-hardener'), $user->user_login),
                    'fix' => __('Change the password immediately.', 'wp-security-hardener')
                );
            }
        }
        
        // Check for admin email
        if (get_option('admin_email') === 'admin@example.com') {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('Default admin email address is still being used.', 'wp-security-hardener'),
                'fix' => __('Change the admin email in Settings > General.', 'wp-security-hardener')
            );
        }
        
        // Check for too many admin users
        $admin_users = get_users(array('role' => 'administrator'));
        if (count($admin_users) > 3) {
            $issues[] = array(
                'type' => 'warning',
                'message' => sprintf(__('There are %d administrator accounts - consider reducing this number.', 'wp-security-hardener'), count($admin_users)),
                'fix' => __('Review administrator accounts and remove unnecessary ones.', 'wp-security-hardener')
            );
        }
        
        // Check for inactive users
        $inactive_threshold = get_option('wpsh_inactive_user_threshold', 180); // 6 months
        foreach ($users as $user) {
            $last_login = get_user_meta($user->ID, 'wpsh_last_login', true);
            if ($last_login && strtotime($last_login) < strtotime("-$inactive_threshold days")) {
                $issues[] = array(
                    'type' => 'warning',
                    'message' => sprintf(__('User "%s" has been inactive for more than %d days.', 'wp-security-hardener'), $user->user_login, $inactive_threshold),
                    'fix' => __('Consider removing inactive user accounts.', 'wp-security-hardener')
                );
            }
        }
        
        return $issues;
    }

    /**
     * Check WordPress core integrity
     */
    private function check_core_integrity() {
        $issues = array();
        global $wp_version;
        
        // Check WordPress version
        $latest_version = get_transient('wpsh_latest_wp_version');
        if (!$latest_version) {
            $response = wp_remote_get('https://api.wordpress.org/core/version-check/1.7/');
            if (!is_wp_error($response)) {
                $body = json_decode($response['body']);
                $latest_version = $body->offers[0]->version;
                set_transient('wpsh_latest_wp_version', $latest_version, DAY_IN_SECONDS);
            }
        }
        
        if ($latest_version && version_compare($wp_version, $latest_version, '<')) {
            $issues[] = array(
                'type' => 'high',
                'message' => sprintf(__('Your WordPress version (%s) is outdated. Latest version is %s.', 'wp-security-hardener'), $wp_version, $latest_version),
                'fix' => __('Update WordPress to the latest version.', 'wp-security-hardener')
            );
        }
        
        // Check core file modifications
        if (!function_exists('get_core_checksums')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        
        $checksums = get_core_checksums($wp_version, isset($_GET['locale']) ? $_GET['locale'] : 'en_US');
        if (is_array($checksums)) {
            $modified_files = array();
            foreach ($checksums as $file => $checksum) {
                $file_path = ABSPATH . $file;
                if (file_exists($file_path) && md5_file($file_path) !== $checksum) {
                    $modified_files[] = $file;
                }
            }
            
            if (!empty($modified_files)) {
                $issues[] = array(
                    'type' => 'high',
                    'message' => sprintf(__('%d core files have been modified.', 'wp-security-hardener'), count($modified_files)),
                    'fix' => __('Reinstall WordPress core files.', 'wp-security-hardener'),
                    'details' => $modified_files
                );
            }
        }
        
        // Check for unnecessary files
        $unnecessary_files = array(
            'readme.html',
            'license.txt',
            'wp-config-sample.php'
        );
        
        foreach ($unnecessary_files as $file) {
            if (file_exists(ABSPATH . $file)) {
                $issues[] = array(
                    'type' => 'warning',
                    'message' => sprintf(__('Unnecessary file %s exists in root directory.', 'wp-security-hardener'), $file),
                    'fix' => __('Remove this file from your server.', 'wp-security-hardener')
                );
            }
        }
        
        return $issues;
    }

    /**
     * Check plugins and themes for security issues
     */
    private function check_plugins_themes() {
        $issues = array();
        
        // Check plugins
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $plugins = get_plugins();
        $update_plugins = get_site_transient('update_plugins');
        
        foreach ($plugins as $plugin_path => $plugin) {
            // Check for outdated plugins
            if (isset($update_plugins->response[$plugin_path])) {
                $issues[] = array(
                    'type' => 'medium',
                    'message' => sprintf(__('Plugin "%s" has an available update (%s).', 'wp-security-hardener'), 
                        $plugin['Name'], 
                        $update_plugins->response[$plugin_path]->new_version),
                    'fix' => __('Update the plugin to the latest version.', 'wp-security-hardener')
                );
            }
            
            // Check for abandoned plugins
            if (isset($update_plugins->no_update[$plugin_path]) && 
                strtotime($update_plugins->no_update[$plugin_path]->last_updated) < strtotime('-2 years')) {
                $issues[] = array(
                    'type' => 'warning',
                    'message' => sprintf(__('Plugin "%s" hasn\'t been updated in over 2 years.', 'wp-security-hardener'), $plugin['Name']),
                    'fix' => __('Consider finding an alternative plugin.', 'wp-security-hardener')
                );
            }
            
            // Check for vulnerable plugins
            $vulnerable = $this->check_plugin_vulnerability($plugin['Name'], $plugin['Version']);
            if ($vulnerable) {
                $issues[] = array(
                    'type' => 'high',
                    'message' => sprintf(__('Plugin "%s" (version %s) has known vulnerabilities.', 'wp-security-hardener'), $plugin['Name'], $plugin['Version']),
                    'fix' => __('Update or remove this plugin immediately.', 'wp-security-hardener')
                );
            }
        }
        
        // Check themes
        $themes = wp_get_themes();
        $update_themes = get_site_transient('update_themes');
        
        foreach ($themes as $theme) {
            $stylesheet = $theme->get_stylesheet();
            
            // Check for outdated themes
            if (isset($update_themes->response[$stylesheet])) {
                $issues[] = array(
                    'type' => 'medium',
                    'message' => sprintf(__('Theme "%s" has an available update (%s).', 'wp-security-hardener'), 
                        $theme->get('Name'), 
                        $update_themes->response[$stylesheet]['new_version']),
                    'fix' => __('Update the theme to the latest version.', 'wp-security-hardener')
                );
            }
            
            // Check for unused themes
            if ($stylesheet !== get_option('stylesheet') && $stylesheet !== get_option('template')) {
                $issues[] = array(
                    'type' => 'warning',
                    'message' => sprintf(__('Theme "%s" is installed but not active.', 'wp-security-hardener'), $theme->get('Name')),
                    'fix' => __('Delete unused themes.', 'wp-security-hardener')
                );
            }
            
            // Check for vulnerable themes
            $vulnerable = $this->check_theme_vulnerability($theme->get('Name'), $theme->get('Version'));
            if ($vulnerable) {
                $issues[] = array(
                    'type' => 'high',
                    'message' => sprintf(__('Theme "%s" (version %s) has known vulnerabilities.', 'wp-security-hardener'), $theme->get('Name'), $theme->get('Version')),
                    'fix' => __('Update or remove this theme immediately.', 'wp-security-hardener')
                );
            }
        }
        
        return $issues;
    }

    /**
     * Check plugin vulnerability
     */
    private function check_plugin_vulnerability($plugin_name, $plugin_version) {
        // In a real implementation, you would query a vulnerability database API
        // This is a simplified version for demonstration
        $vulnerable_plugins = array(
            'Old Plugin' => array('versions' => array('<2.0.0'), 'risk' => 'high'),
            'Insecure Addon' => array('versions' => array('<1.5.3'), 'risk' => 'critical')
        );
        
        foreach ($vulnerable_plugins as $name => $data) {
            if (strpos($plugin_name, $name) !== false) {
                foreach ($data['versions'] as $version_condition) {
                    if (version_compare($plugin_version, substr($version_condition, 1), $version_condition[0])) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }

    /**
     * Check theme vulnerability
     */
    private function check_theme_vulnerability($theme_name, $theme_version) {
        // Similar to plugin vulnerability check
        // Would query an API in real implementation
        return false;
    }

    /**
     * Check server configuration
     */
    private function check_server_config() {
        $issues = array();
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            $issues[] = array(
                'type' => 'high',
                'message' => sprintf(__('Your PHP version (%s) is outdated and may contain security vulnerabilities.', 'wp-security-hardener'), PHP_VERSION),
                'fix' => __('Update PHP to version 7.4 or higher.', 'wp-security-hardener')
            );
        }
        
        // Check display_errors
        if (ini_get('display_errors')) {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('PHP display_errors is enabled, which can expose sensitive information.', 'wp-security-hardener'),
                'fix' => __('Set display_errors to Off in php.ini.', 'wp-security-hardener')
            );
        }
        
        // Check if debug mode is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $issues[] = array(
                'type' => 'warning',
                'message' => __('WordPress debug mode is enabled.', 'wp-security-hardener'),
                'fix' => __('Set WP_DEBUG to false in wp-config.php for production sites.', 'wp-security-hardener')
            );
        }
        
        // Check server software
        if (isset($_SERVER['SERVER_SOFTWARE'])) {
            $server_software = $_SERVER['SERVER_SOFTWARE'];
            
            if (strpos($server_software, 'Apache') !== false && version_compare(preg_replace('/[^0-9.]/', '', $server_software), '2.4', '<')) {
                $issues[] = array(
                    'type' => 'medium',
                    'message' => __('Your Apache version is outdated.', 'wp-security-hardener'),
                    'fix' => __('Update Apache to version 2.4 or higher.', 'wp-security-hardener')
                );
            }
            
            if (strpos($server_software, 'nginx') !== false) {
                // Check for missing security headers in nginx
                $headers = headers_list();
                $security_headers = array(
                    'X-Frame-Options',
                    'X-XSS-Protection',
                    'X-Content-Type-Options',
                    'Strict-Transport-Security'
                );
                
                foreach ($security_headers as $header) {
                    $found = false;
                    foreach ($headers as $h) {
                        if (stripos($h, $header) === 0) {
                            $found = true;
                            break;
                        }
                    }
                    
                    if (!$found) {
                        $issues[] = array(
                            'type' => 'medium',
                            'message' => sprintf(__('Security header %s is missing.', 'wp-security-hardener'), $header),
                            'fix' => __('Add the header to your nginx configuration.', 'wp-security-hardener')
                        );
                    }
                }
            }
        }
        
        // Check for vulnerable PHP extensions
        $vulnerable_extensions = array(
            'xmlrpc' => __('XML-RPC is enabled which can be used for brute force attacks.', 'wp-security-hardener'),
            'mbstring' => __('mbstring extension has known vulnerabilities in older versions.', 'wp-security-hardener')
        );
        
        foreach ($vulnerable_extensions as $ext => $message) {
            if (extension_loaded($ext)) {
                $issues[] = array(
                    'type' => 'warning',
                    'message' => $message,
                    'fix' => __('Disable or update the extension if not needed.', 'wp-security-hardener')
                );
            }
        }
        
        // Check for open ports
        if (function_exists('fsockopen')) {
            $ports_to_check = array(21, 22, 3306);
            foreach ($ports_to_check as $port) {
                $connection = @fsockopen('localhost', $port, $errno, $errstr, 1);
                if (is_resource($connection)) {
                    $issues[] = array(
                        'type' => 'high',
                        'message' => sprintf(__('Port %d is open which could be a security risk.', 'wp-security-hardener'), $port),
                        'fix' => __('Close unnecessary ports or protect them with firewall rules.', 'wp-security-hardener')
                    );
                    fclose($connection);
                }
            }
        }
        
        return $issues;
    }

    /**
     * Check security headers
     */
    private function check_security_headers() {
        $issues = array();
        $headers = headers_list();
        
        $required_headers = array(
            'X-Frame-Options' => array(
                'expected' => 'SAMEORIGIN',
                'type' => 'medium'
            ),
            'X-XSS-Protection' => array(
                'expected' => '1; mode=block',
                'type' => 'medium'
            ),
            'X-Content-Type-Options' => array(
                'expected' => 'nosniff',
                'type' => 'medium'
            ),
            'Strict-Transport-Security' => array(
                'expected' => 'max-age=31536000',
                'type' => 'high',
                'ssl_only' => true
            ),
            'Content-Security-Policy' => array(
                'expected' => '',
                'type' => 'warning'
            )
        );
        
        foreach ($required_headers as $header => $data) {
            $found = false;
            
            // Skip HSTS if not SSL
            if (isset($data['ssl_only']) && $data['ssl_only'] && !is_ssl()) {
                continue;
            }
            
            foreach ($headers as $h) {
                if (stripos($h, $header) === 0) {
                    $found = true;
                    
                    // Check if the value matches expected
                    if (!empty($data['expected'])) {
                        $value = trim(substr($h, strlen($header) + 1));
                        if ($value !== $data['expected']) {
                            $issues[] = array(
                                'type' => $data['type'],
                                'message' => sprintf(__('Header %s has incorrect value: %s (expected: %s)', 'wp-security-hardener'), $header, $value, $data['expected']),
                                'fix' => __('Update the header value in your server configuration.', 'wp-security-hardener')
                            );
                        }
                    }
                    
                    break;
                }
            }
            
            if (!$found) {
                $issues[] = array(
                    'type' => $data['type'],
                    'message' => sprintf(__('Security header %s is missing.', 'wp-security-hardener'), $header),
                    'fix' => __('Add the header to your server configuration.', 'wp-security-hardener')
                );
            }
        }
        
        return $issues;
    }

    /**
     * Check firewall rules
     */
    private function check_firewall_rules() {
        $issues = array();
        
        // Check if firewall is active
        if (!get_option('wpsh_firewall_enabled')) {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('Firewall protection is not enabled.', 'wp-security-hardener'),
                'fix' => __('Enable the firewall in the security settings.', 'wp-security-hardener')
            );
        }
        
        // Check for common malicious requests
        $log_file = WP_CONTENT_DIR . '/wpsh_firewall.log';
        if (file_exists($log_file) && filesize($log_file) > 0) {
            $issues[] = array(
                'type' => 'warning',
                'message' => __('Firewall has blocked some malicious requests.', 'wp-security-hardener'),
                'fix' => __('Review the firewall logs for details.', 'wp-security-hardener')
            );
        }
        
        // Check for brute force protection
        if (!get_option('wpsh_login_protection_enabled')) {
            $issues[] = array(
                'type' => 'medium',
                'message' => __('Brute force protection is not enabled.', 'wp-security-hardener'),
                'fix' => __('Enable login protection in the security settings.', 'wp-security-hardener')
            );
        }
        
        return $issues;
    }
}