<?php
/**
 * Plugin settings page
 */
class WPSH_Settings_Page {

    public function __construct() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Load assets
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Add plugin action links
        add_filter('plugin_action_links_' . WPSH_PLUGIN_BASENAME, array($this, 'add_plugin_action_links'));
    }

    /**
     * Add admin menu item
     */
    public function add_admin_menu() {
        add_menu_page(
            __('WP Security Hardener', 'wp-security-hardener'),
            __('Security Hardener', 'wp-security-hardener'),
            'manage_options',
            'wp-security-hardener',
            array($this, 'render_settings_page'),
            'dashicons-shield',
            80
        );
        
        // Add dashboard submenu
        add_submenu_page(
            'wp-security-hardener',
            __('Dashboard', 'wp-security-hardener'),
            __('Dashboard', 'wp-security-hardener'),
            'manage_options',
            'wp-security-hardener',
            array($this, 'render_settings_page')
        );
        
        // Add hardening submenu
        add_submenu_page(
            'wp-security-hardener',
            __('Hardening', 'wp-security-hardener'),
            __('Hardening', 'wp-security-hardener'),
            'manage_options',
            'wp-security-hardener-hardening',
            array($this, 'render_hardening_page')
        );
        
        // Add firewall submenu
        add_submenu_page(
            'wp-security-hardener',
            __('Firewall', 'wp-security-hardener'),
            __('Firewall', 'wp-security-hardener'),
            'manage_options',
            'wp-security-hardener-firewall',
            array($this, 'render_firewall_page')
        );
        
        // Add logs submenu
        add_submenu_page(
            'wp-security-hardener',
            __('Activity Logs', 'wp-security-hardener'),
            __('Activity Logs', 'wp-security-hardener'),
            'manage_options',
            'wp-security-hardener-logs',
            array($this, 'render_logs_page')
        );
    }

    /**
     * Add plugin action links
     */
    public function add_plugin_action_links($links) {
        $action_links = array(
            '<a href="' . admin_url('admin.php?page=wp-security-hardener') . '">' . __('Settings', 'wp-security-hardener') . '</a>',
            '<a href="https://wordpress.org/support/plugin/wp-security-hardener/" target="_blank">' . __('Support', 'wp-security-hardener') . '</a>',
        );
        
        return array_merge($action_links, $links);
    }

    /**
     * Register plugin settings
     */
    public function register_settings() {
        // General settings section
        add_settings_section(
            'wpsh_general_settings',
            __('Security Hardening', 'wp-security-hardener'),
            array($this, 'render_general_settings_section'),
            'wp-security-hardener'
        );
        
        // Scanner settings section
        add_settings_section(
            'wpsh_scanner_settings',
            __('Security Scanner', 'wp-security-hardener'),
            array($this, 'render_scanner_settings_section'),
            'wp-security-hardener'
        );
        
        // Firewall settings section
        add_settings_section(
            'wpsh_firewall_settings',
            __('Firewall Protection', 'wp-security-hardener'),
            array($this, 'render_firewall_settings_section'),
            'wp-security-hardener'
        );
        
        // Login protection settings section
        add_settings_section(
            'wpsh_login_settings',
            __('Login Protection', 'wp-security-hardener'),
            array($this, 'render_login_settings_section'),
            'wp-security-hardener'
        );
        
        // Register settings fields
        register_setting('wpsh_settings_group', 'wpsh_disallow_file_edit');
        register_setting('wpsh_settings_group', 'wpsh_prevent_php_execution');
        register_setting('wpsh_settings_group', 'wpsh_enable_security_headers');
        register_setting('wpsh_settings_group', 'wpsh_enable_csp');
        register_setting('wpsh_settings_group', 'wpsh_scan_email_notify');
        register_setting('wpsh_settings_group', 'wpsh_firewall_enabled');
        register_setting('wpsh_settings_group', 'wpsh_login_protection_enabled');
        register_setting('wpsh_settings_group', 'wpsh_login_attempts');
        register_setting('wpsh_settings_group', 'wpsh_login_lockout_time');
        register_setting('wpsh_settings_group', 'wpsh_enable_2fa');
        register_setting('wpsh_settings_group', 'wpsh_enable_activity_log');
        register_setting('wpsh_settings_group', 'wpsh_inactive_user_threshold');
        
        // Hardening fields
        add_settings_field(
            'wpsh_disallow_file_edit',
            __('Disable File Editor', 'wp-security-hardener'),
            array($this, 'render_disallow_file_edit_field'),
            'wp-security-hardener',
            'wpsh_general_settings'
        );
        
        add_settings_field(
            'wpsh_prevent_php_execution',
            __('Prevent PHP Execution', 'wp-security-hardener'),
            array($this, 'render_prevent_php_execution_field'),
            'wp-security-hardener',
            'wpsh_general_settings'
        );
        
        add_settings_field(
            'wpsh_enable_security_headers',
            __('Enable Security Headers', 'wp-security-hardener'),
            array($this, 'render_enable_security_headers_field'),
            'wp-security-hardener',
            'wpsh_general_settings'
        );
        
        add_settings_field(
            'wpsh_enable_csp',
            __('Enable Content Security Policy', 'wp-security-hardener'),
            array($this, 'render_enable_csp_field'),
            'wp-security-hardener',
            'wpsh_general_settings'
        );
        
        // Scanner fields
        add_settings_field(
            'wpsh_scan_email_notify',
            __('Email Notifications', 'wp-security-hardener'),
            array($this, 'render_scan_email_notify_field'),
            'wp-security-hardener',
            'wpsh_scanner_settings'
        );
        
        // Firewall fields
        add_settings_field(
            'wpsh_firewall_enabled',
            __('Enable Firewall', 'wp-security-hardener'),
            array($this, 'render_firewall_enabled_field'),
            'wp-security-hardener',
            'wpsh_firewall_settings'
        );
        
        // Login protection fields
        add_settings_field(
            'wpsh_login_protection_enabled',
            __('Enable Login Protection', 'wp-security-hardener'),
            array($this, 'render_login_protection_enabled_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
        
        add_settings_field(
            'wpsh_login_attempts',
            __('Max Login Attempts', 'wp-security-hardener'),
            array($this, 'render_login_attempts_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
        
        add_settings_field(
            'wpsh_login_lockout_time',
            __('Lockout Time (minutes)', 'wp-security-hardener'),
            array($this, 'render_login_lockout_time_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
        
        add_settings_field(
            'wpsh_enable_2fa',
            __('Enable Two-Factor Authentication', 'wp-security-hardener'),
            array($this, 'render_enable_2fa_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
        
        // Activity log fields
        add_settings_field(
            'wpsh_enable_activity_log',
            __('Enable Activity Logging', 'wp-security-hardener'),
            array($this, 'render_enable_activity_log_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
        
        add_settings_field(
            'wpsh_inactive_user_threshold',
            __('Inactive User Threshold (days)', 'wp-security-hardener'),
            array($this, 'render_inactive_user_threshold_field'),
            'wp-security-hardener',
            'wpsh_login_settings'
        );
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'wp-security-hardener'));
        }
        
        // Get last scan results
        $last_scan = get_option('wpsh_last_scan_results');
        $security_score = isset($last_scan['security_score']) ? $last_scan['security_score'] : 0;
        $last_scan_time = get_option('wpsh_last_scan_time');
        ?>
        <div class="wrap wpsh-settings">
            <h1><?php _e('WP Security Hardener', 'wp-security-hardener'); ?></h1>
            
            <?php settings_errors(); ?>
            
            <div class="wpsh-dashboard">
                <div class="wpsh-dashboard-widgets">
                    <div class="wpsh-widget wpsh-widget-security-score">
                        <h3><?php _e('Security Score', 'wp-security-hardener'); ?></h3>
                        <div class="wpsh-score-circle" data-score="<?php echo esc_attr($security_score); ?>">
                            <svg class="wpsh-score-circle-progress" viewBox="0 0 36 36">
                                <path class="wpsh-score-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                <path class="wpsh-score-circle-fill" stroke-dasharray="<?php echo esc_attr($security_score); ?>, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            </svg>
                            <div class="wpsh-score-circle-text">
                                <span><?php echo esc_html($security_score); ?>%</span>
                            </div>
                        </div>
                        <p class="wpsh-score-description">
                            <?php if ($security_score >= 80): ?>
                                <?php _e('Excellent! Your site is well secured.', 'wp-security-hardener'); ?>
                            <?php elseif ($security_score >= 60): ?>
                                <?php _e('Good, but there are some improvements needed.', 'wp-security-hardener'); ?>
                            <?php else: ?>
                                <?php _e('Your site needs immediate security attention.', 'wp-security-hardener'); ?>
                            <?php endif; ?>
                        </p>
                        <?php if ($last_scan_time): ?>
                            <p class="wpsh-last-scan">
                                <?php printf(__('Last scanned on: %s', 'wp-security-hardener'), date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_scan_time))); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="wpsh-widget wpsh-widget-critical-issues">
                        <h3><?php _e('Critical Issues', 'wp-security-hardener'); ?></h3>
                        <?php if ($last_scan && isset($last_scan['security_score'])): ?>
                            <?php 
                            $critical_issues = 0;
                            foreach ($last_scan as $section => $issues) {
                                if (in_array($section, array('timestamp', 'security_score'))) continue;
                                foreach ($issues as $issue) {
                                    if ($issue['type'] === 'high') {
                                        $critical_issues++;
                                    }
                                }
                            }
                            ?>
                            <div class="wpsh-issues-count">
                                <span class="wpsh-issues-count-number"><?php echo esc_html($critical_issues); ?></span>
                                <span class="wpsh-issues-count-label"><?php _e('High Priority Issues', 'wp-security-hardener'); ?></span>
                            </div>
                            <?php if ($critical_issues > 0): ?>
                                <a href="#scanner" class="button button-primary"><?php _e('View Issues', 'wp-security-hardener'); ?></a>
                            <?php else: ?>
                                <p class="wpsh-no-critical-issues"><?php _e('No critical issues found', 'wp-security-hardener'); ?></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p><?php _e('No scan results available. Run a security scan first.', 'wp-security-hardener'); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="wpsh-widget wpsh-widget-recommendations">
                        <h3><?php _e('Recommendations', 'wp-security-hardener'); ?></h3>
                        <?php if ($last_scan && isset($last_scan['security_score'])): ?>
                            <ul class="wpsh-recommendations-list">
                                <?php 
                                $recommendations = array();
                                foreach ($last_scan as $section => $issues) {
                                    if (in_array($section, array('timestamp', 'security_score'))) continue;
                                    foreach ($issues as $issue) {
                                        if ($issue['type'] === 'high' || $issue['type'] === 'medium') {
                                            $recommendations[] = $issue;
                                        }
                                    }
                                }
                                
                                // Limit to 5 recommendations
                                $recommendations = array_slice($recommendations, 0, 5);
                                
                                if (!empty($recommendations)) {
                                    foreach ($recommendations as $rec) {
                                        echo '<li>' . esc_html($rec['message']) . '</li>';
                                    }
                                } else {
                                    echo '<li>' . __('No urgent recommendations', 'wp-security-hardener') . '</li>';
                                }
                                ?>
                            </ul>
                        <?php else: ?>
                            <p><?php _e('Run a security scan to get recommendations.', 'wp-security-hardener'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="wpsh-tabs">
                    <h2 class="nav-tab-wrapper">
                        <a href="#hardening" class="nav-tab nav-tab-active"><?php _e('Hardening', 'wp-security-hardener'); ?></a>
                        <a href="#scanner" class="nav-tab"><?php _e('Security Scanner', 'wp-security-hardener'); ?></a>
                        <a href="#firewall" class="nav-tab"><?php _e('Firewall', 'wp-security-hardener'); ?></a>
                        <a href="#login" class="nav-tab"><?php _e('Login Protection', 'wp-security-hardener'); ?></a>
                    </h2>
                </div>
                
                <div id="hardening" class="wpsh-tab-content active">
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('wpsh_settings_group');
                        do_settings_sections('wp-security-hardener');
                        submit_button();
                        ?>
                    </form>
                </div>
                
                <div id="scanner" class="wpsh-tab-content">
                    <h2><?php _e('Security Scanner', 'wp-security-hardener'); ?></h2>
                    <p><?php _e('Run a comprehensive security scan of your WordPress installation.', 'wp-security-hardener'); ?></p>
                    
                    <div class="wpsh-scan-controls">
                        <button id="wpsh-run-scan" class="button button-primary">
                            <?php _e('Run Security Scan', 'wp-security-hardener'); ?>
                        </button>
                        
                        <div class="wpsh-scan-progress" style="display: none;">
                            <div class="wpsh-progress-bar">
                                <div class="wpsh-progress-bar-fill" style="width: 0%;"></div>
                            </div>
                            <span class="wpsh-progress-text">0%</span>
                            <span class="wpsh-progress-status"><?php _e('Preparing scan...', 'wp-security-hardener'); ?></span>
                        </div>
                    </div>
                    
                    <div id="wpsh-scan-results">
                        <?php if ($last_scan): ?>
                            <h3><?php _e('Last Scan Results', 'wp-security-hardener'); ?></h3>
                            <p><?php printf(__('Last scanned on: %s', 'wp-security-hardener'), date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $last_scan['timestamp'])); ?></p>
                            <p><?php printf(__('Security Score: %d%%', 'wp-security-hardener'), $last_scan['security_score']); ?></p>
                            
                            <?php $this->render_scan_results($last_scan); ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div id="firewall" class="wpsh-tab-content">
                    <h2><?php _e('Firewall Settings', 'wp-security-hardener'); ?></h2>
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('wpsh_settings_group');
                        do_settings_sections('wp-security-hardener');
                        submit_button();
                        ?>
                    </form>
                </div>
                
                <div id="login" class="wpsh-tab-content">
                    <h2><?php _e('Login Protection Settings', 'wp-security-hardener'); ?></h2>
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('wpsh_settings_group');
                        do_settings_sections('wp-security-hardener');
                        submit_button();
                        ?>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render hardening page
     */
    public function render_hardening_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Security Hardening', 'wp-security-hardener'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('wpsh_settings_group');
                do_settings_sections('wp-security-hardener');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Render firewall page
     */
    public function render_firewall_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Firewall Protection', 'wp-security-hardener'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('wpsh_settings_group');
                do_settings_sections('wp-security-hardener');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Render logs page
     */
    public function render_logs_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Activity Logs', 'wp-security-hardener'); ?></h1>
            <?php
            $activity_log = new WPSH_Activity_Log();
            $activity_log->display_logs();
            ?>
        </div>
        <?php
    }

    /**
     * Render scan results
     */
    private function render_scan_results($results) {
        $score = isset($results['security_score']) ? $results['security_score'] : 0;
        ?>
        <div class="wpsh-scan-results">
                 <div class="wpsh-score-display">
            <h3>Security Score: <?php echo esc_html($score); ?>%</h3>
            <p class="wpsh-score-rating">
                <?php
                if ($score >= 90) {
                    _e('Excellent - Your site is very secure', 'wp-security-hardener');
                } elseif ($score >= 75) {
                    _e('Good - Minor improvements needed', 'wp-security-hardener');
                } elseif ($score >= 50) {
                    _e('Fair - Several issues to address', 'wp-security-hardener');
                } else {
                    _e('Poor - Immediate attention required', 'wp-security-hardener');
                }
                ?>
            </p>
        </div>
            <div class="wpsh-results-summary">
                <div class="wpsh-summary-item wpsh-summary-high">
                    <span class="wpsh-summary-count">
                        <?php 
                        $high_issues = 0;
                        foreach ($results as $section => $issues) {
                            if (in_array($section, array('timestamp', 'security_score'))) continue;
                            foreach ($issues as $issue) {
                                if ($issue['type'] === 'high') $high_issues++;
                            }
                        }
                        echo esc_html($high_issues);
                        ?>
                    </span>
                    <span class="wpsh-summary-label"><?php _e('High', 'wp-security-hardener'); ?></span>
                </div>
                
                <div class="wpsh-summary-item wpsh-summary-medium">
                    <span class="wpsh-summary-count">
                        <?php 
                        $medium_issues = 0;
                        foreach ($results as $section => $issues) {
                            if (in_array($section, array('timestamp', 'security_score'))) continue;
                            foreach ($issues as $issue) {
                                if ($issue['type'] === 'medium') $medium_issues++;
                            }
                        }
                        echo esc_html($medium_issues);
                        ?>
                    </span>
                    <span class="wpsh-summary-label"><?php _e('Medium', 'wp-security-hardener'); ?></span>
                </div>
                
                <div class="wpsh-summary-item wpsh-summary-warning">
                    <span class="wpsh-summary-count">
                        <?php 
                        $warning_issues = 0;
                        foreach ($results as $section => $issues) {
                            if (in_array($section, array('timestamp', 'security_score'))) continue;
                            foreach ($issues as $issue) {
                                if ($issue['type'] === 'warning') $warning_issues++;
                            }
                        }
                        echo esc_html($warning_issues);
                        ?>
                    </span>
                    <span class="wpsh-summary-label"><?php _e('Warning', 'wp-security-hardener'); ?></span>
                </div>
            </div>
            
            <div class="wpsh-results-sections">
                <?php foreach ($results as $section => $issues): ?>
                    <?php if ($section === 'timestamp' || $section === 'security_score') continue; ?>
                    
                    <div class="wpsh-results-section">
                        <h4 class="wpsh-section-title">
                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $section))); ?>
                            <span class="wpsh-section-count">
                                <?php echo esc_html(count($issues)); ?> <?php _e('issues', 'wp-security-hardener'); ?>
                            </span>
                        </h4>
                        
                        <?php if (empty($issues)): ?>
                            <p class="wpsh-no-issues"><?php _e('No issues found', 'wp-security-hardener'); ?></p>
                        <?php else: ?>
                            <div class="wpsh-issues">
                                <?php foreach ($issues as $issue): ?>
                                    <div class="wpsh-issue wpsh-issue-<?php echo esc_attr($issue['type']); ?>">
                                        <div class="wpsh-issue-severity"><?php echo esc_html(ucfirst($issue['type'])); ?></div>
                                        <div class="wpsh-issue-content">
                                            <p class="wpsh-issue-message"><?php echo esc_html($issue['message']); ?></p>
                                            <?php if (!empty($issue['fix'])): ?>
                                                <div class="wpsh-issue-fix">
                                                    <strong><?php _e('How to fix:', 'wp-security-hardener'); ?></strong>
                                                    <p><?php echo esc_html($issue['fix']); ?></p>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($issue['details'])): ?>
                                                <div class="wpsh-issue-details">
                                                    <strong><?php _e('Details:', 'wp-security-hardener'); ?></strong>
                                                    <ul>
                                                        <?php foreach ($issue['details'] as $detail): ?>
                                                            <li><?php echo esc_html($detail); ?></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render general settings section
     */
    public function render_general_settings_section() {
        echo '<p>' . __('Enable or disable security hardening features below.', 'wp-security-hardener') . '</p>';
    }

    /**
     * Render scanner settings section
     */
    public function render_scanner_settings_section() {
        echo '<p>' . __('Configure security scanner settings.', 'wp-security-hardener') . '</p>';
    }

    /**
     * Render firewall settings section
     */
    public function render_firewall_settings_section() {
        echo '<p>' . __('Configure firewall protection settings.', 'wp-security-hardener') . '</p>';
    }

    /**
     * Render login settings section
     */
    public function render_login_settings_section() {
        echo '<p>' . __('Configure login protection settings.', 'wp-security-hardener') . '</p>';
    }

    /**
     * Render disallow file edit field
     */
    public function render_disallow_file_edit_field() {
        $value = get_option('wpsh_disallow_file_edit', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_disallow_file_edit" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Prevents users from editing plugin and theme files from the WordPress admin.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render prevent PHP execution field
     */
    public function render_prevent_php_execution_field() {
        $value = get_option('wpsh_prevent_php_execution', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_prevent_php_execution" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Adds .htaccess rules to prevent PHP file execution in sensitive directories.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render enable security headers field
     */
    public function render_enable_security_headers_field() {
        $value = get_option('wpsh_enable_security_headers', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_enable_security_headers" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enables security headers like X-Frame-Options, X-XSS-Protection, etc.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render enable CSP field
     */
    public function render_enable_csp_field() {
        $value = get_option('wpsh_enable_csp', false);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_enable_csp" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enables Content Security Policy header to prevent XSS attacks.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render scan email notify field
     */
    public function render_scan_email_notify_field() {
        $value = get_option('wpsh_scan_email_notify', false);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_scan_email_notify" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Send email notification when a security scan completes.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render firewall enabled field
     */
    public function render_firewall_enabled_field() {
        $value = get_option('wpsh_firewall_enabled', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_firewall_enabled" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enable firewall protection against common attacks.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render login protection enabled field
     */
    public function render_login_protection_enabled_field() {
        $value = get_option('wpsh_login_protection_enabled', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_login_protection_enabled" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enable brute force protection for login attempts.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render login attempts field
     */
    public function render_login_attempts_field() {
        $value = get_option('wpsh_login_attempts', 5);
        ?>
        <input type="number" name="wpsh_login_attempts" value="<?php echo esc_attr($value); ?>" min="1" max="20" class="small-text">
        <p class="description">
            <?php _e('Maximum number of failed login attempts before lockout.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render login lockout time field
     */
    public function render_login_lockout_time_field() {
        $value = get_option('wpsh_login_lockout_time', 30);
        ?>
        <input type="number" name="wpsh_login_lockout_time" value="<?php echo esc_attr($value); ?>" min="1" max="1440" class="small-text">
        <p class="description">
            <?php _e('Lockout time in minutes after too many failed login attempts.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render enable 2FA field
     */
    public function render_enable_2fa_field() {
        $value = get_option('wpsh_enable_2fa', false);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_enable_2fa" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enable two-factor authentication for administrator accounts.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render enable activity log field
     */
    public function render_enable_activity_log_field() {
        $value = get_option('wpsh_enable_activity_log', true);
        ?>
        <label class="wpsh-switch">
            <input type="checkbox" name="wpsh_enable_activity_log" value="1" <?php checked(1, $value); ?>>
            <span class="wpsh-slider"></span>
        </label>
        <p class="description">
            <?php _e('Enable logging of security-related activities.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Render inactive user threshold field
     */
    public function render_inactive_user_threshold_field() {
        $value = get_option('wpsh_inactive_user_threshold', 180);
        ?>
        <input type="number" name="wpsh_inactive_user_threshold" value="<?php echo esc_attr($value); ?>" min="30" max="365" class="small-text">
        <p class="description">
            <?php _e('Number of days after which inactive users are flagged.', 'wp-security-hardener'); ?>
        </p>
        <?php
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_assets($hook) {
        if (strpos($hook, 'wp-security-hardener') === false) {
            return;
        }
        
        // CSS
        wp_enqueue_style(
            'wpsh-admin-css',
            WPSH_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            WPSH_VERSION
        );
        
        // JS
        wp_enqueue_script(
            'wpsh-admin-js',
            WPSH_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            WPSH_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script(
            'wpsh-admin-js',
            'wpsh_admin',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wpsh_scan_nonce'),
                'scanning' => __('Scanning...', 'wp-security-hardener'),
                'run_scan' => __('Run Security Scan', 'wp-security-hardener'),
                'complete' => __('Scan complete!', 'wp-security-hardener'),
            )
        );
    }
}