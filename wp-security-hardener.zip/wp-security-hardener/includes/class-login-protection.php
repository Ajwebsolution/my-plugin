<?php
/**
 * Enhanced Login Protection with 2FA and Security Questions
 */
class WPSH_Login_Protection {

    public function __construct() {
        if (get_option('wpsh_login_protection_enabled')) {
            add_action('wp_login_failed', array($this, 'track_login_failure'));
            add_filter('authenticate', array($this, 'check_login_attempts'), 30, 3);
            add_action('wp_login', array($this, 'clear_login_failures'));
            
            // Enable 2FA if configured
            if (get_option('wpsh_enable_2fa')) {
                add_filter('authenticate', array($this, 'validate_2fa'), 40, 3);
                $this->init_security_questions();
            }
            
            // Add login form modifications
            add_action('login_form', array($this, 'modify_login_form'));
            add_action('login_enqueue_scripts', array($this, 'login_page_scripts'));

            // Debugging
            add_action('init', array($this, 'debug_tools'));
        }
    }

    /**
     * Track failed login attempts
     */
    public function track_login_failure($username) {
        $ip = $this->get_client_ip();
        $failures = get_transient('wpsh_login_failures_' . $ip) ?: 0;
        $failures++;
        
        set_transient('wpsh_login_failures_' . $ip, $failures, get_option('wpsh_login_lockout_time', 30) * MINUTE_IN_SECONDS);
        
        if (get_option('wpsh_enable_activity_log')) {
            $activity_log = new WPSH_Activity_Log();
            $activity_log->log_activity(
                'login_failed',
                sprintf(__('Failed login attempt for username: %s', 'wp-security-hardener'), $username),
                $ip
            );
        }
        
        error_log("Login failed for {$username} from IP: {$ip}. Attempt #{$failures}");
    }

    /**
     * Check login attempts and block if too many failures
     */
    public function check_login_attempts($user, $username, $password) {
        if (empty($username) || empty($password)) {
            return $user;
        }
        
        $ip = $this->get_client_ip();
        $failures = get_transient('wpsh_login_failures_' . $ip) ?: 0;
        $max_attempts = get_option('wpsh_login_attempts', 5);
        
        if ($failures >= $max_attempts) {
            $lockout_time = get_option('wpsh_login_lockout_time', 30);
            
            if (get_option('wpsh_enable_activity_log')) {
                $activity_log = new WPSH_Activity_Log();
                $activity_log->log_activity(
                    'login_lockout',
                    sprintf(__('Login locked out for IP: %s', 'wp-security-hardener'), $ip),
                    $ip
                );
            }
            
            error_log("Login locked out for IP: {$ip} after {$failures} attempts");
            
            return new WP_Error(
                'too_many_attempts',
                sprintf(__('<strong>ERROR</strong>: Too many failed login attempts. Please try again in %d minutes.', 'wp-security-hardener'), $lockout_time)
            );
        }
        
        return $user;
    }

    /**
     * Clear login failures on successful login
     */
    public function clear_login_failures($username) {
        $ip = $this->get_client_ip();
        delete_transient('wpsh_login_failures_' . $ip);
        
        if (get_option('wpsh_enable_activity_log')) {
            $user = get_user_by('login', $username);
            $activity_log = new WPSH_Activity_Log();
            $activity_log->log_activity(
                'login_success',
                __('User logged in successfully', 'wp-security-hardener'),
                $ip,
                $user->ID
            );
        }
        
        error_log("Successful login for {$username} from IP: {$ip}");
    }

    /**
     * Initialize security questions
     */
    public function init_security_questions() {
        add_action('show_user_profile', array($this, 'add_security_question_fields'));
        add_action('edit_user_profile', array($this, 'add_security_question_fields'));
        add_action('personal_options_update', array($this, 'save_security_question'));
        add_action('edit_user_profile_update', array($this, 'save_security_question'));
    }

    /**
     * Modify the login form for 2FA
     */
    public function modify_login_form() {
        // Handle code resend requests
        if (isset($_GET['wpsh_resend_2fa']) && isset($_GET['log'])) {
            $username = sanitize_user($_GET['log']);
            $user = get_user_by('login', $username);
            
            if ($user) {
                $sent = $this->generate_2fa_code($user->user_login, $user);
                $notice_type = $sent ? 'success' : 'error';
                $notice_message = $sent ? 
                    __('New verification code sent!', 'wp-security-hardener') : 
                    __('Failed to send verification code. Please contact support.', 'wp-security-hardener');
                
                echo '<div class="notice notice-'.$notice_type.'"><p>'.$notice_message.'</p></div>';
            }
        }
        
        // Show any email errors
        if (isset($_GET['wpsh_email_error']) && isset($_GET['log'])) {
            $username = sanitize_user($_GET['log']);
            $user = get_user_by('login', $username);
            
            if ($user) {
                echo '<div class="notice notice-error"><p>'
                    .__('Failed to send verification email. Please try again or contact support.', 'wp-security-hardener')
                    .'</p></div>';
            }
        }
        
        // Only show 2FA fields if we're at that step
        if (isset($_GET['wpsh_2fa']) && isset($_GET['log'])) {
            $this->show_2fa_form(sanitize_user($_GET['log']));
        }
    }

    /**
     * Show the 2FA form
     */
    private function show_2fa_form($username) {
        $user = get_user_by('login', $username);
        if (!$user) return;
        
        $transient_key = 'wpsh_2fa_code_'.$user->ID.'_'.$this->get_client_ip();
        $code_exists = get_transient($transient_key) ? true : false;
        
        ?>
        <div class="wpsh-2fa-form">
            <h3><?php _e('Two-Factor Authentication', 'wp-security-hardener'); ?></h3>
            
            <?php if (!$code_exists): ?>
            <div class="notice notice-error">
                <p><?php _e('Your verification code has expired. Please try logging in again.', 'wp-security-hardener'); ?></p>
            </div>
            <?php else: ?>
            
            <p>
                <label for="wpsh_2fa_code"><?php _e('Verification Code', 'wp-security-hardener'); ?><br>
                <input type="text" name="wpsh_2fa_code" id="wpsh_2fa_code" class="input" size="20" required autocomplete="off"></label>
                <small>
                    <a href="<?php echo esc_url(add_query_arg('wpsh_resend_2fa', '1', add_query_arg('log', $username, wp_login_url()))); ?>">
                        <?php _e('Resend Code', 'wp-security-hardener'); ?>
                    </a>
                </small>
            </p>
            
            <?php 
            $security_question = get_user_meta($user->ID, 'wpsh_security_question', true);
            if ($security_question): 
            ?>
            <p>
                <label for="wpsh_security_answer"><?php _e('Security Question', 'wp-security-hardener'); ?><br>
                <strong><?php echo esc_html($security_question); ?></strong><br>
                <input type="text" name="wpsh_security_answer" id="wpsh_security_answer" class="input" size="20" required autocomplete="off"></label>
            </p>
            <?php endif; ?>
            
            <input type="hidden" name="log" value="<?php echo esc_attr($username); ?>">
            <input type="hidden" name="wpsh_2fa" value="1">
            
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Add security question fields to user profile
     */
    public function add_security_question_fields($user) {
        if (!current_user_can('edit_user', $user->ID)) {
            return;
        }
        ?>
        <h3><?php _e('Security Questions', 'wp-security-hardener'); ?></h3>
        
        <table class="form-table">
            <tr>
                <th><label for="wpsh_security_question"><?php _e('Security Question', 'wp-security-hardener'); ?></label></th>
                <td>
                    <select name="wpsh_security_question" id="wpsh_security_question" class="regular-text">
                        <option value=""><?php _e('-- Select a question --', 'wp-security-hardener'); ?></option>
                        <option value="What was your first pet's name?" <?php selected(get_user_meta($user->ID, 'wpsh_security_question', true), "What was your first pet's name?"); ?>><?php _e("What was your first pet's name?", 'wp-security-hardener'); ?></option>
                        <option value="What city were you born in?" <?php selected(get_user_meta($user->ID, 'wpsh_security_question', true), "What city were you born in?"); ?>><?php _e("What city were you born in?", 'wp-security-hardener'); ?></option>
                        <option value="What is your mother's maiden name?" <?php selected(get_user_meta($user->ID, 'wpsh_security_question', true), "What is your mother's maiden name?"); ?>><?php _e("What is your mother's maiden name?", 'wp-security-hardener'); ?></option>
                        <option value="What was your first school's name?" <?php selected(get_user_meta($user->ID, 'wpsh_security_question', true), "What was your first school's name?"); ?>><?php _e("What was your first school's name?", 'wp-security-hardener'); ?></option>
                        <option value="custom" <?php selected(get_user_meta($user->ID, 'wpsh_security_question_source', true), "custom"); ?>><?php _e("Custom question...", 'wp-security-hardener'); ?></option>
                    </select>
                    <div id="wpsh_custom_question_wrap" style="<?php echo (get_user_meta($user->ID, 'wpsh_security_question_source', true) === 'custom' ? '' : 'display:none;'); ?>">
                        <input type="text" name="wpsh_custom_security_question" id="wpsh_custom_security_question" value="<?php echo esc_attr(get_user_meta($user->ID, 'wpsh_custom_security_question', true)); ?>" class="regular-text">
                    </div>
                </td>
            </tr>
            <tr>
                <th><label for="wpsh_security_answer"><?php _e('Answer', 'wp-security-hardener'); ?></label></th>
                <td>
                    <input type="text" name="wpsh_security_answer" id="wpsh_security_answer" value="<?php echo esc_attr(get_user_meta($user->ID, 'wpsh_security_answer', true)); ?>" class="regular-text">
                    <p class="description"><?php _e('This answer will be required along with 2FA code for login.', 'wp-security-hardener'); ?></p>
                </td>
            </tr>
        </table>
        
        <script>
        jQuery(document).ready(function($) {
            $('#wpsh_security_question').change(function() {
                if ($(this).val() === 'custom') {
                    $('#wpsh_custom_question_wrap').show();
                } else {
                    $('#wpsh_custom_question_wrap').hide();
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Save security question
     */
    public function save_security_question($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return;
        }
        
        if (isset($_POST['wpsh_security_question'])) {
            if ($_POST['wpsh_security_question'] === 'custom' && !empty($_POST['wpsh_custom_security_question'])) {
                update_user_meta($user_id, 'wpsh_security_question', sanitize_text_field($_POST['wpsh_custom_security_question']));
                update_user_meta($user_id, 'wpsh_security_question_source', 'custom');
            } else {
                update_user_meta($user_id, 'wpsh_security_question', sanitize_text_field($_POST['wpsh_security_question']));
                delete_user_meta($user_id, 'wpsh_security_question_source');
            }
        }
        
        if (isset($_POST['wpsh_security_answer'])) {
            $answer = strtolower(trim(sanitize_text_field($_POST['wpsh_security_answer'])));
            update_user_meta($user_id, 'wpsh_security_answer', $answer);
        }
    }

    /**
     * Validate 2FA code and security question
     */
    public function validate_2fa($user, $username, $password) {
        // Skip if already an error
        if (is_wp_error($user) || !$user) {
            error_log('2FA validation skipped - user error');
            return $user;
        }
        
        // Skip if 2FA not enabled for this user
        if (!in_array('administrator', (array)$user->roles)) {
            error_log('2FA skipped - not admin');
            return $user;
        }
        
        // Handle 2FA form submission
        if (isset($_POST['wpsh_2fa'])) {
            $transient_key = 'wpsh_2fa_code_'.$user->ID.'_'.$this->get_client_ip();
            $stored_code = get_transient($transient_key);
            
            error_log('2FA validation attempt for '.$username.' with code '.($_POST['wpsh_2fa_code'] ?? 'none'));
            
            // Verify 2FA code
            if (empty($_POST['wpsh_2fa_code']) || !$stored_code || $stored_code !== $_POST['wpsh_2fa_code']) {
                error_log('2FA code validation failed');
                return new WP_Error(
                    '2fa_invalid',
                    __('<strong>ERROR</strong>: Invalid two-factor authentication code.', 'wp-security-hardener')
                );
            }
            
            // Verify security question if set
            $security_question = get_user_meta($user->ID, 'wpsh_security_question', true);
            if ($security_question) {
                $stored_answer = get_user_meta($user->ID, 'wpsh_security_answer', true);
                $submitted_answer = isset($_POST['wpsh_security_answer']) ? strtolower(trim($_POST['wpsh_security_answer'])) : '';
                
                if (empty($submitted_answer)) {
                    error_log('Security answer missing');
                    return new WP_Error(
                        'security_answer_required',
                        __('<strong>ERROR</strong>: Please answer your security question.', 'wp-security-hardener')
                    );
                }
                
                if ($stored_answer !== $submitted_answer) {
                    error_log('Security answer incorrect');
                    return new WP_Error(
                        'security_answer_invalid',
                        __('<strong>ERROR</strong>: Incorrect answer to security question.', 'wp-security-hardener')
                    );
                }
            }
            
            // All checks passed - clear code and log in
            delete_transient($transient_key);
            error_log('2FA validation successful for user: ' . $username);
            return $user;
        }
        
        // Generate and send code
        $email_sent = $this->generate_2fa_code($username, $user);
        
        if (!$email_sent) {
            // If email failed to send, show error immediately
            return new WP_Error(
                '2fa_email_failed',
                __('<strong>ERROR</strong>: Could not send verification email. Please try again or contact support.', 'wp-security-hardener')
            );
        }
        
        // Store the username in a transient for validation
        set_transient('wpsh_2fa_user_'.$this->get_client_ip(), $username, 15 * MINUTE_IN_SECONDS);

        // Redirect to 2FA form
        wp_redirect(add_query_arg(array(
            'wpsh_2fa' => 1,
            'log' => $username
        ), wp_login_url()));
        exit;
    }

    /**
     * Generate and email 2FA code with enhanced error handling
     */
    public function generate_2fa_code($username, $user) {
        // Generate 6-digit numeric code
        $code = wp_generate_password(6, false, false);
        $transient_key = 'wpsh_2fa_code_'.$user->ID.'_'.$this->get_client_ip();
        set_transient($transient_key, $code, 15 * MINUTE_IN_SECONDS);
        
        error_log("2FA Code generated for {$user->user_email}: {$code} (Transient: {$transient_key})");

        // Email content
        $subject = sprintf(__('Your Two-Factor Authentication Code for %s', 'wp-security-hardener'), get_bloginfo('name'));
        $message = sprintf(__('Login attempt detected for account: %s', 'wp-security-hardener'), $username) . "<br><br>";
        $message .= sprintf(__('Your verification code is: <strong>%s</strong>', 'wp-security-hardener'), $code) . "<br><br>";
        $message .= __('This code will expire in 15 minutes.', 'wp-security-hardener') . "<br><br>";
        $message .= __('If you did not attempt to log in, please secure your account immediately.', 'wp-security-hardener');

        // Remove any existing content type filters
        remove_all_filters('wp_mail_content_type');
        
        // Add HTML content type filter
        add_filter('wp_mail_content_type', function() { 
            return 'text/html'; 
        });
        
        $sent = wp_mail(
            $user->user_email,
            $subject,
            $message,
            array('Content-Type: text/html; charset=UTF-8')
        );
        
        // Remove our filter
        remove_filter('wp_mail_content_type', function() { 
            return 'text/html'; 
        });
        
        error_log("2FA Email send result for {$user->user_email}: " . ($sent ? 'Success' : 'Failed'));
        
        return $sent;
    }

    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        if (strpos($ip, ',') !== false) {
            $ips = explode(',', $ip);
            $ip = trim($ips[0]);
        }
        
        return sanitize_text_field($ip);
    }

    /**
     * Enqueue login page scripts
     */
    public function login_page_scripts() {
        wp_enqueue_script('wpsh-login', plugins_url('js/login.js', __FILE__), array('jquery'), '1.0', true);
    }

    /**
     * Debug tools
     */
    public function debug_tools() {
        if (current_user_can('administrator') && isset($_GET['wpsh_debug_email'])) {
            $sent = wp_mail(
                get_option('admin_email'),
                'Test Email from WPSH',
                'This is a test email from the WordPress Security Hardener plugin.'
            );
            wp_die('Test email ' . ($sent ? 'sent successfully' : 'failed to send'));
        }
        
        if (current_user_can('administrator') && isset($_GET['wpsh_debug_transient'])) {
            $transient_key = 'wpsh_2fa_code_'.get_current_user_id().'_'.$this->get_client_ip();
            $code = get_transient($transient_key);
            wp_die('Current 2FA transient value: ' . ($code ? $code : 'Not found'));
        }
    }
}