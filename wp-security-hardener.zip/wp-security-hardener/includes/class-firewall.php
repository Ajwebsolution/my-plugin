<?php
/**
 * Firewall protection
 */
class WPSH_Firewall {

    public function __construct() {
        if (get_option('wpsh_firewall_enabled')) {
            add_action('init', array($this, 'init_firewall'));
        }
    }

    /**
     * Initialize firewall protection
     */
    public function init_firewall() {
        // Block bad user agents
        $this->block_bad_user_agents();
        
        // Block suspicious query strings
        $this->block_suspicious_query_strings();
        
        // Block SQL injection attempts
        $this->block_sql_injections();
        
        // Block XSS attempts
        $this->block_xss_attempts();
        
        // Block directory traversal attempts
        $this->block_directory_traversal();
    }

    /**
     * Block bad user agents
     */
    private function block_bad_user_agents() {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) {
            return;
        }
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $bad_agents = array(
            'libwww-perl',
            'wget',
            'curl',
            'scan',
            'httrack',
            'harvest',
            'sqlmap',
            'nikto',
            'zmeu'
        );
        
        foreach ($bad_agents as $agent) {
            if (stripos($user_agent, $agent) !== false) {
                $this->log_and_block('Bad user agent: ' . $user_agent);
            }
        }
    }

    /**
     * Block suspicious query strings
     */
    private function block_suspicious_query_strings() {
        if (empty($_SERVER['QUERY_STRING'])) {
            return;
        }
        
        $query_string = urldecode($_SERVER['QUERY_STRING']);
        $bad_strings = array(
            'mosConfig_',
            'base64_',
            'eval(',
            'document.cookie',
            'javascript:',
            'vbscript:',
            'onload=',
            'onerror=',
            'onclick=',
            'http://',
            'https://',
            '../',
            'etc/passwd'
        );
        
        foreach ($bad_strings as $string) {
            if (stripos($query_string, $string) !== false) {
                $this->log_and_block('Suspicious query string: ' . $query_string);
            }
        }
    }

    /**
     * Block SQL injection attempts
     */
    private function block_sql_injections() {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $query_string = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
        $post_data = $_POST;
        
        $sql_keywords = array(
            'union select',
            'concat(',
            'information_schema',
            'benchmark(',
            'sleep(',
            'select * from',
            'insert into',
            'update set',
            'delete from',
            'drop table',
            'truncate table',
            'create table',
            'alter table',
            'xp_cmdshell'
        );
        
        // Check URI and query string
        $input = $request_uri . ' ' . $query_string;
        foreach ($sql_keywords as $keyword) {
            if (stripos($input, $keyword) !== false) {
                $this->log_and_block('SQL injection attempt: ' . $keyword);
            }
        }
        
        // Check POST data
        foreach ($post_data as $key => $value) {
            if (is_array($value)) {
                continue;
            }
            
            foreach ($sql_keywords as $keyword) {
                if (stripos($value, $keyword) !== false) {
                    $this->log_and_block('SQL injection attempt in POST data: ' . $keyword);
                }
            }
        }
    }

    /**
     * Block XSS attempts
     */
    private function block_xss_attempts() {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $query_string = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
        $post_data = $_POST;
        
        $xss_patterns = array(
            '<script',
            'javascript:',
            'vbscript:',
            'onload=',
            'onerror=',
            'onclick=',
            'onmouseover=',
            'document.cookie',
            'window.location',
            'alert(',
            'confirm(',
            'prompt('
        );
        
        // Check URI and query string
        $input = $request_uri . ' ' . $query_string;
        foreach ($xss_patterns as $pattern) {
            if (stripos($input, $pattern) !== false) {
                $this->log_and_block('XSS attempt: ' . $pattern);
            }
        }
        
        // Check POST data
        foreach ($post_data as $key => $value) {
            if (is_array($value)) {
                continue;
            }
            
            foreach ($xss_patterns as $pattern) {
                if (stripos($value, $pattern) !== false) {
                    $this->log_and_block('XSS attempt in POST data: ' . $pattern);
                }
            }
        }
    }

    /**
     * Block directory traversal attempts
     */
    private function block_directory_traversal() {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $query_string = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
        
        $traversal_patterns = array(
            '../',
            '..\\',
            '%00',
            'etc/passwd',
            'boot.ini',
            'win.ini'
        );
        
        $input = $request_uri . ' ' . $query_string;
        foreach ($traversal_patterns as $pattern) {
            if (stripos($input, $pattern) !== false) {
                $this->log_and_block('Directory traversal attempt: ' . $pattern);
            }
        }
    }

    /**
     * Log and block the request
     */
    private function log_and_block($reason) {
        $this->log_request($reason);
        $this->block_request();
    }

    /**
     * Log the blocked request
     */
    private function log_request($reason) {
        $log_file = WP_CONTENT_DIR . '/wpsh_firewall.log';
        $log_entry = sprintf(
            "[%s] %s %s %s %s\n",
            current_time('mysql'),
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['REQUEST_METHOD'],
            $_SERVER['REQUEST_URI'],
            $reason
        );
        
        file_put_contents($log_file, $log_entry, FILE_APPEND);
    }

    /**
     * Block the request
     */
    private function block_request() {
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        die('<h1>403 Forbidden</h1><p>Your request has been blocked by the firewall.</p>');
    }
}