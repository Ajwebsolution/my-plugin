<?php
/**
 * Uninstall handler.
 *
 * Runs ONLY when the plugin is deleted via WordPress → Plugins → Delete
 * (WordPress core guarantees this file is never loaded any other way — it
 * checks WP_UNINSTALL_PLUGIN itself before including this file).
 *
 * Per the spec: "On uninstall: Ask/allow full cleanup according to
 * WordPress conventions. Never delete WooCommerce product data." This file
 * only removes the plugin's OWN operational tables/options/transients, and
 * only if the site owner opted in via Settings → General →
 * "Delete data on uninstall". WooCommerce products, variations, terms and
 * media are never touched here under any circumstance.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'awpm_settings', array() );

if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	// Default behaviour: leave everything in place, in case the plugin is
	// reinstalled later or the deletion was accidental.
	return;
}

require_once plugin_dir_path( __FILE__ ) . 'includes/class-awpm-installer.php';
AWPM_Installer::drop_tables();

delete_option( 'awpm_settings' );
delete_option( AWPM_Installer::DB_VERSION_OPTION );

// Clear any AWPM cron hooks.
wp_clear_scheduled_hook( 'awpm_daily_maintenance' );
wp_clear_scheduled_hook( 'awpm_batch_tick' );

global $wpdb;
$scheduled_ids = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}awpm_scheduled_jobs" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
foreach ( (array) $scheduled_ids as $id ) {
	wp_clear_scheduled_hook( 'awpm_run_scheduled_job', array( (int) $id ) );
}

// Remove the private temp-file directory (never contains anything but
// AWPM's own generated import/export files).
$upload_dir = wp_upload_dir();
$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
if ( is_dir( $tmp_dir ) ) {
	foreach ( glob( trailingslashit( $tmp_dir ) . '*' ) ?: array() as $file ) {
		if ( is_file( $file ) ) {
			@unlink( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
	@rmdir( $tmp_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
}

// Note: the `_awpm_external_id` / `_awpm_source_system` / `_awpm_source_id`
// postmeta this plugin writes to products is deliberately NOT deleted here
// — those live on WooCommerce's own product rows, and per the spec this
// file must never delete WooCommerce product data (including its meta).
