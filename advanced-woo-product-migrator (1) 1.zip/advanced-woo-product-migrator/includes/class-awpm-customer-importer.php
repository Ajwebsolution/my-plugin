<?php
/**
 * AWPM_Customer_Importer
 *
 * Creates/updates WordPress user accounts + WooCommerce billing/shipping
 * meta from CSV/JSON/XLSX. Matching is by email by design (WordPress
 * enforces unique emails, and it's the one identifier that reliably means
 * the same person across two separate WordPress installs) with the
 * external-ID relationship map as a secondary match for repeat imports.
 * Mirrors AWPM_Product_Importer's shape.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Customer_Importer {

	const ADDRESS_FIELDS = array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country', 'email', 'phone' );

	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return AWPM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return AWPM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return AWPM_CSV_Handler::read( $file_path );
		}
	}

	public function start_job( $args ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = AWPM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'customers',
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array(
					'existing_action' => $args['existing_action'] ?? 'update',
					'match_strategy'  => $args['match_strategy'] ?? 'email',
					'default_role'    => $args['default_role'] ?? 'customer',
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 50,
				'total_rows'  => count( $rows ),
			)
		);

		AWPM_Logger::set_run_id( 'awpm_run_job_' . $job_id, 'import', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Import job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$rows = $this->read_rows( $job['file_path'], $job['format'] );
		if ( is_wp_error( $rows ) ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			return $rows;
		}

		$offset  = (int) $job['offset_row'];
		$batch   = array_slice( $rows, $offset, (int) $job['batch_size'] );
		$options = $job['options'];

		$created = 0; $updated = 0; $skipped = 0; $failed = 0;

		foreach ( $batch as $i => $raw_row ) {
			$row_index = $offset + $i;
			try {
				$record = $this->apply_mapping( $raw_row, $job['mapping'] );
				$result = $this->process_record( $record, $options, (bool) $job['dry_run'] );
				if ( 'created' === $result['verdict'] ) { $created++; }
				elseif ( 'updated' === $result['verdict'] ) { $updated++; }
				else { $skipped++; }
				AWPM_Jobs::add_import_item( $job_id, $row_index, $record['email'] ?? '', $result['id'] ?? null, 'success', $result['message'] );
			} catch ( Exception $e ) {
				$failed++;
				AWPM_Jobs::add_import_item( $job_id, $row_index, '', null, 'error', $e->getMessage() );
			}
		}

		AWPM_Jobs::increment_import_counts( $job_id, $created, $updated, $skipped, $failed, count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array(
				'job_id'  => $job_id,
				'created' => $job['created_count'] + $created,
				'updated' => $job['updated_count'] + $updated,
				'skipped' => $job['skipped_count'] + $skipped,
				'failed'  => $job['failed_count'] + $failed,
			);
			AWPM_Notifications::notify( 'import_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Customer import job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_import_job( $job_id ) );
	}

	protected function apply_mapping( $raw_row, $mapping ) {
		if ( empty( $mapping ) ) {
			return $raw_row;
		}
		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$record[ $target_field ] = $raw_row[ $source_column ];
		}
		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}
		return $record;
	}

	protected function find_existing_user( $record, $strategy ) {
		if ( 'external_id' === $strategy && ! empty( $record['external_id'] ) ) {
			$id = AWPM_Relationship_Map::resolve( 'default', $record['external_id'], 'customer' );
			if ( $id && get_userdata( $id ) ) {
				return (int) $id;
			}
		}
		if ( ! empty( $record['email'] ) ) {
			$user = get_user_by( 'email', $record['email'] );
			if ( $user ) {
				return (int) $user->ID;
			}
		}
		if ( ! empty( $record['username'] ) ) {
			$user = get_user_by( 'login', $record['username'] );
			if ( $user ) {
				return (int) $user->ID;
			}
		}
		return 0;
	}

	protected function process_record( $record, $options, $dry_run ) {
		if ( empty( $record['email'] ) || ! is_email( $record['email'] ) ) {
			throw new Exception( __( 'A valid email address is required to import a customer.', 'advanced-woo-product-migrator' ) );
		}

		$existing_id = $this->find_existing_user( $record, $options['match_strategy'] ?? 'email' );

		if ( $existing_id && 'skip' === ( $options['existing_action'] ?? 'update' ) ) {
			return array( 'verdict' => 'skipped', 'id' => $existing_id, 'message' => __( 'Customer already exists — skipped.', 'advanced-woo-product-migrator' ) );
		}

		if ( $dry_run ) {
			return array(
				'verdict' => $existing_id ? 'updated' : 'created',
				'id'      => $existing_id,
				'message' => $existing_id ? __( 'Would update existing customer.', 'advanced-woo-product-migrator' ) : __( 'Would create new customer.', 'advanced-woo-product-migrator' ),
			);
		}

		if ( $existing_id ) {
			wp_update_user(
				array(
					'ID'         => $existing_id,
					'first_name' => $record['first_name'] ?? '',
					'last_name'  => $record['last_name'] ?? '',
				)
			);
			$user_id = $existing_id;
		} else {
			$username = ! empty( $record['username'] ) ? $record['username'] : sanitize_user( current( explode( '@', $record['email'] ) ), true );
			if ( username_exists( $username ) ) {
				$username .= '-' . wp_generate_password( 4, false, false );
			}
			$user_id = wp_insert_user(
				array(
					'user_login' => $username,
					'user_email' => $record['email'],
					'user_pass'  => wp_generate_password( 20 ),
					'first_name' => $record['first_name'] ?? '',
					'last_name'  => $record['last_name'] ?? '',
					'role'       => ! empty( $record['roles'][0] ) ? $record['roles'][0] : ( $options['default_role'] ?? 'customer' ),
				)
			);
			if ( is_wp_error( $user_id ) ) {
				throw new Exception( $user_id->get_error_message() );
			}
		}

		foreach ( array( 'billing', 'shipping' ) as $group ) {
			foreach ( (array) ( $record[ $group ] ?? array() ) as $field => $value ) {
				if ( ! in_array( $field, self::ADDRESS_FIELDS, true ) ) {
					continue;
				}
				update_user_meta( $user_id, $group . '_' . $field, $value );
			}
		}

		if ( isset( $record['is_paying_customer'] ) ) {
			update_user_meta( $user_id, 'paying_customer', (int) $record['is_paying_customer'] );
		}

		if ( ! empty( $record['custom_meta'] ) ) {
			foreach ( (array) $record['custom_meta'] as $key => $value ) {
				update_user_meta( $user_id, sanitize_key( $key ), $value );
			}
		}

		$external_id = $record['external_id'] ?? ( $record['user_id'] ?? '' );
		if ( $external_id ) {
			update_user_meta( $user_id, '_awpm_external_id', $external_id );
			AWPM_Relationship_Map::set_mapping( 'default', (string) $external_id, $user_id, 'customer', (string) $external_id );
		}

		return array(
			'verdict' => $existing_id ? 'updated' : 'created',
			'id'      => $user_id,
			'message' => $existing_id ? __( 'Updated existing customer.', 'advanced-woo-product-migrator' ) : __( 'Created new customer.', 'advanced-woo-product-migrator' ),
		);
	}

	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$rows    = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview = array();

		foreach ( $rows as $raw_row ) {
			$record      = $this->apply_mapping( $raw_row, $args['mapping'] ?? array() );
			$existing_id = $this->find_existing_user( $record, $args['match_strategy'] ?? 'email' );

			$issues = array();
			if ( empty( $record['email'] ) || ! is_email( $record['email'] ?? '' ) ) {
				$issues[] = __( 'Missing or invalid email address.', 'advanced-woo-product-migrator' );
			}

			$preview[] = array(
				'name'        => trim( ( $record['first_name'] ?? '' ) . ' ' . ( $record['last_name'] ?? '' ) ) ?: ( $record['username'] ?? '' ),
				'sku'         => $record['email'] ?? '',
				'type'        => implode( ', ', (array) ( $record['roles'] ?? array( 'customer' ) ) ),
				'price'       => $record['total_spent'] ?? '',
				'categories'  => $record['billing']['country'] ?? '',
				'image_count' => 0,
				'variation_count' => (int) ( $record['order_count'] ?? 0 ),
				'has_acf'     => false,
				'has_yoast'   => false,
				'meta_count'  => count( (array) ( $record['custom_meta'] ?? array() ) ),
				'status'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $issues,
			);
		}

		return $preview;
	}
}
