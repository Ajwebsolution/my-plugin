<?php
/**
 * AWPM_Relationship_Map
 *
 * The temporary source->target mapping table required for resolving
 * upsells, cross-sells, grouped products, and ACF relationship/post_object
 * fields across repeated migrations — without ever trusting a raw source
 * post ID as if it meant the same thing on the destination site. Also
 * backs the external ID system (_awpm_external_id product meta +
 * source_system/source_id bookkeeping) so re-running the same import
 * against the same source always resolves to the same destination product.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Relationship_Map {

	const META_KEY = '_awpm_external_id';

	/**
	 * Record (or update) a source -> target mapping.
	 *
	 * Note: AWPM_Product_Importer and AWPM_ACF_Handler both currently call
	 * this with source_system = 'default' — i.e. one shared namespace per
	 * destination site rather than segregating by literal originating
	 * domain. This is deliberate: it's what lets an ACF relationship field
	 * (resolved deep inside a static value-walking method with no access
	 * to the top-level import record) look up the same map row the
	 * importer wrote when it created that referenced product. A true
	 * multi-source setup (e.g. two distinct supplier feeds whose IDs could
	 * collide) can pass a real value here via the `source_system` param —
	 * the column exists and is indexed for exactly that — but doing so
	 * requires also updating AWPM_ACF_Handler::resolve_post_ref() to look
	 * up the right namespace, since it can't infer it from the value alone.
	 *
	 * @param string $source_system e.g. "store-a", defaults to "default".
	 * @param string $source_id     Source product ID or SKU.
	 * @param int    $target_id     Local post ID it resolved to.
	 * @param string $object_type   product|term|attachment|user
	 * @param string $external_id   Optional external/business ID (e.g. "ABC-1001").
	 */
	public static function set_mapping( $source_system, $source_id, $target_id, $object_type = 'product', $external_id = '' ) {
		global $wpdb;
		$source_system = $source_system ?: 'default';

		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}awpm_relationship_map WHERE source_system = %s AND source_id = %s AND object_type = %s",
				$source_system, $source_id, $object_type
			)
		);

		if ( $existing ) {
			$wpdb->update(
				$wpdb->prefix . 'awpm_relationship_map',
				array( 'target_id' => $target_id, 'external_id' => $external_id ?: null ),
				array( 'id' => $existing ),
				array( '%d', '%s' ),
				array( '%d' )
			);
			return (int) $existing;
		}

		$wpdb->insert(
			$wpdb->prefix . 'awpm_relationship_map',
			array(
				'source_system' => $source_system,
				'source_id'     => (string) $source_id,
				'external_id'   => $external_id ?: null,
				'target_id'     => $target_id,
				'object_type'   => $object_type,
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( 'product' === $object_type && $external_id ) {
			update_post_meta( $target_id, self::META_KEY, $external_id );
			update_post_meta( $target_id, '_awpm_source_system', $source_system );
			update_post_meta( $target_id, '_awpm_source_id', $source_id );
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Resolve a source ID (or external ID) to a local target ID.
	 *
	 * @return int|null
	 */
	public static function resolve( $source_system, $source_id, $object_type = 'product' ) {
		global $wpdb;
		$source_system = $source_system ?: 'default';

		$target = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT target_id FROM {$wpdb->prefix}awpm_relationship_map WHERE source_system = %s AND (source_id = %s OR external_id = %s) AND object_type = %s",
				$source_system, $source_id, $source_id, $object_type
			)
		);

		if ( $target && self::target_still_exists( (int) $target, $object_type ) ) {
			return (int) $target;
		}

		// Fall back to a direct postmeta lookup, in case the map table was
		// cleared but the product still carries its external ID meta.
		if ( 'product' === $object_type ) {
			$posts = get_posts(
				array(
					'post_type'      => array( 'product', 'product_variation' ),
					'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'     => $source_id, // phpcs:ignore WordPress.DB.SlowDBQuery
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);
			if ( ! empty( $posts ) ) {
				return (int) $posts[0];
			}
		}

		return null;
	}

	/**
	 * Whether a previously-mapped target_id still refers to a real object,
	 * checked the right way for what object_type actually is — not every
	 * entity this map now covers is a wp_posts row. Fixes a bug where
	 * resolve() always validated via get_post_status(), which silently
	 * failed "match by External ID" for every customer (a WP_User, never a
	 * post) and for any order on a site with WooCommerce's High-Performance
	 * Order Storage enabled (orders live in their own table, not wp_posts).
	 *
	 * @param int    $target_id
	 * @param string $object_type product|term|attachment|user|customer|order
	 * @return bool
	 */
	protected static function target_still_exists( $target_id, $object_type ) {
		if ( ! $target_id ) {
			return false;
		}
		switch ( $object_type ) {
			case 'customer':
			case 'user':
				return (bool) get_userdata( $target_id );
			case 'order':
				return function_exists( 'wc_get_order' ) ? (bool) wc_get_order( $target_id ) : (bool) get_post_status( $target_id );
			case 'term':
				global $wpdb;
				return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT term_id FROM {$wpdb->prefix}terms WHERE term_id = %d", $target_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			default:
				return (bool) get_post_status( $target_id );
		}
	}

	/**
	 * Find a product by its external ID directly (used by the importer's
	 * "match by External ID" duplicate-prevention strategy).
	 */
	public static function find_by_external_id( $external_id ) {
		if ( ! $external_id ) {
			return null;
		}
		$posts = get_posts(
			array(
				'post_type'      => 'product',
				'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'post_status'    => 'any',
			)
		);
		return ! empty( $posts ) ? (int) $posts[0] : null;
	}

	/**
	 * Rebuild the relationship map from existing _awpm_external_id /
	 * _awpm_source_id postmeta (Tools -> "Rebuild Relationship Map").
	 *
	 * @return int Number of rows (re)built.
	 */
	public static function rebuild() {
		global $wpdb;
		$products = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'post_status'    => 'any',
			)
		);

		$count = 0;
		foreach ( $products as $product_id ) {
			$external_id   = get_post_meta( $product_id, self::META_KEY, true );
			$source_system = get_post_meta( $product_id, '_awpm_source_system', true ) ?: 'default';
			$source_id     = get_post_meta( $product_id, '_awpm_source_id', true ) ?: $external_id;
			if ( $external_id ) {
				self::set_mapping( $source_system, $source_id, $product_id, 'product', $external_id );
				$count++;
			}
		}
		return $count;
	}
}
