<?php
/**
 * AWPM_Transformer
 *
 * Applies a single configured transform to one mapped value before it's
 * written into the import record. Called from
 * AWPM_Product_Importer::apply_mapping() for every source column that has
 * a transform configured in the wizard's Step 3 "Transform" modal — this
 * is genuinely wired in, not a UI control with nothing behind it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Transformer {

	/**
	 * @param mixed $value  The raw (pre-mapping) cell value.
	 * @param array $config { type: string, ...type-specific args }
	 * @return mixed
	 */
	public static function apply( $value, $config ) {
		if ( empty( $config['type'] ) || ! is_string( $value ) ) {
			return $value; // Transforms only operate on plain scalar text; arrays/objects (already-decoded JSON cells) pass through untouched.
		}

		switch ( $config['type'] ) {
			case 'trim':
				return trim( $value );

			case 'lowercase':
				return function_exists( 'mb_strtolower' ) ? mb_strtolower( $value ) : strtolower( $value );

			case 'uppercase':
				return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $value ) : strtoupper( $value );

			case 'capitalize':
				return ucwords( strtolower( $value ) );

			case 'find_replace':
				if ( '' === ( $config['find'] ?? '' ) ) {
					return $value;
				}
				return str_replace( $config['find'], $config['replace'] ?? '', $value );

			case 'prefix':
				return ( $config['prefix'] ?? '' ) . $value;

			case 'suffix':
				return $value . ( $config['suffix'] ?? '' );

			case 'regex_replace':
				if ( empty( $config['pattern'] ) ) {
					return $value;
				}
				$result = @preg_replace( $config['pattern'], $config['replace'] ?? '', $value ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				return null === $result ? $value : $result; // Invalid pattern: fail safe, keep original rather than nulling the field.

			case 'to_number':
				$clean = preg_replace( '/[^0-9.\-]/', '', $value );
				return '' === $clean ? '' : (float) $clean;

			case 'to_boolean':
				$truthy = array( 'yes', 'true', '1', 'y', 'on' );
				return in_array( strtolower( trim( $value ) ), $truthy, true );

			case 'to_date':
				$ts = strtotime( $value );
				return $ts ? gmdate( ! empty( $config['format'] ) ? $config['format'] : 'Y-m-d', $ts ) : $value;

			default:
				return $value;
		}
	}

	/**
	 * Human-readable list of supported transform types, for the wizard's
	 * Transform modal (kept here so the UI and the engine can never drift
	 * out of sync with each other).
	 */
	public static function get_available_transforms() {
		return array(
			'trim'          => __( 'Trim whitespace', 'advanced-woo-product-migrator' ),
			'lowercase'     => __( 'Lowercase', 'advanced-woo-product-migrator' ),
			'uppercase'     => __( 'Uppercase', 'advanced-woo-product-migrator' ),
			'capitalize'    => __( 'Capitalize Words', 'advanced-woo-product-migrator' ),
			'find_replace'  => __( 'Find & Replace', 'advanced-woo-product-migrator' ),
			'prefix'        => __( 'Add Prefix', 'advanced-woo-product-migrator' ),
			'suffix'        => __( 'Add Suffix', 'advanced-woo-product-migrator' ),
			'regex_replace' => __( 'Regex Replace', 'advanced-woo-product-migrator' ),
			'to_number'     => __( 'Convert to Number', 'advanced-woo-product-migrator' ),
			'to_boolean'    => __( 'Convert to Yes/No → true/false', 'advanced-woo-product-migrator' ),
			'to_date'       => __( 'Convert to Date', 'advanced-woo-product-migrator' ),
		);
	}
}
