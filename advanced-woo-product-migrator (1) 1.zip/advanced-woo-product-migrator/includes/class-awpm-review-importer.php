<?php
/**
 * AWPM_Review_Importer
 *
 * Creates/updates WooCommerce product reviews (WP_Comment, type "review")
 * from CSV/JSON/XLSX, matching the same shape and batch-job pattern as
 * AWPM_Product_Importer so the wizard, progress polling, and preview step
 * work identically for this entity.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Review_Importer {

	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return AWPM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return AWPM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return AWPM_CSV_Handler::read( $file_path );
		}
	}

	public function start_job( $args ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = AWPM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'reviews',
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array(
					'existing_action' => $args['existing_action'] ?? 'skip',
					'match_strategy'  => $args['match_strategy'] ?? 'review_id',
					'default_status'  => $args['default_status'] ?? 'approve',
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 50,
				'total_rows'  => count( $rows ),
			)
		);

		AWPM_Logger::set_run_id( 'awpm_run_job_' . $job_id, 'import', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Import job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$rows = $this->read_rows( $job['file_path'], $job['format'] );
		if ( is_wp_error( $rows ) ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			return $rows;
		}

		$offset  = (int) $job['offset_row'];
		$batch   = array_slice( $rows, $offset, (int) $job['batch_size'] );
		$options = $job['options'];

		$created = 0; $updated = 0; $skipped = 0; $failed = 0;

		foreach ( $batch as $i => $raw_row ) {
			$row_index = $offset + $i;
			try {
				$record = $this->apply_mapping( $raw_row, $job['mapping'] );
				$result = $this->process_record( $record, $options, (bool) $job['dry_run'] );
				if ( 'created' === $result['verdict'] ) { $created++; }
				elseif ( 'updated' === $result['verdict'] ) { $updated++; }
				else { $skipped++; }
				AWPM_Jobs::add_import_item( $job_id, $row_index, '', $result['id'] ?? null, 'success', $result['message'] );
			} catch ( Exception $e ) {
				$failed++;
				AWPM_Jobs::add_import_item( $job_id, $row_index, '', null, 'error', $e->getMessage() );
			}
		}

		AWPM_Jobs::increment_import_counts( $job_id, $created, $updated, $skipped, $failed, count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array(
				'job_id'  => $job_id,
				'created' => $job['created_count'] + $created,
				'updated' => $job['updated_count'] + $updated,
				'skipped' => $job['skipped_count'] + $skipped,
				'failed'  => $job['failed_count'] + $failed,
			);
			AWPM_Notifications::notify( 'import_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Review import job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_import_job( $job_id ) );
	}

	protected function apply_mapping( $raw_row, $mapping ) {
		if ( empty( $mapping ) ) {
			return $raw_row;
		}
		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$record[ $target_field ] = $raw_row[ $source_column ];
		}
		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}
		return $record;
	}

	/**
	 * Resolve the target product for a review record: SKU first (most
	 * portable across sites), then the external-ID relationship map (set by
	 * a prior product import from the same source), then a raw same-site
	 * product_id as a last resort.
	 */
	protected function resolve_product_id( $record ) {
		if ( ! empty( $record['product_sku'] ) ) {
			$id = wc_get_product_id_by_sku( $record['product_sku'] );
			if ( $id ) {
				return $id;
			}
		}
		if ( ! empty( $record['product_external_id'] ) ) {
			$id = AWPM_Relationship_Map::resolve( 'default', $record['product_external_id'], 'product' );
			if ( $id ) {
				return $id;
			}
		}
		if ( ! empty( $record['product_id'] ) && 'product' === get_post_type( $record['product_id'] ) ) {
			return (int) $record['product_id'];
		}
		return 0;
	}

	protected function find_existing_review( $record, $strategy ) {
		if ( 'external_id' === $strategy && ! empty( $record['external_id'] ) ) {
			$found = get_comments(
				array(
					'meta_key'   => '_awpm_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value' => $record['external_id'], // phpcs:ignore WordPress.DB.SlowDBQuery
					'type'       => 'review',
					'number'     => 1,
				)
			);
			if ( $found ) {
				return (int) $found[0]->comment_ID;
			}
		}

		if ( ! empty( $record['review_id'] ) ) {
			$existing = get_comment( (int) $record['review_id'] );
			if ( $existing && 'review' === $existing->comment_type ) {
				return (int) $existing->comment_ID;
			}
		}

		// Heuristic de-dupe: same product + same author email + same content
		// is almost certainly the same review re-exported/re-imported.
		if ( ! empty( $record['author_email'] ) ) {
			$product_id = $this->resolve_product_id( $record );
			if ( $product_id ) {
				$found = get_comments(
					array(
						'post_id'    => $product_id,
						'author_email' => $record['author_email'],
						'type'       => 'review',
						'number'     => 1,
					)
				);
				if ( $found ) {
					return (int) $found[0]->comment_ID;
				}
			}
		}

		return 0;
	}

	protected function process_record( $record, $options, $dry_run ) {
		$product_id = $this->resolve_product_id( $record );
		if ( ! $product_id ) {
			throw new Exception( __( 'Could not resolve the target product (no matching SKU, external ID, or product ID on this site).', 'advanced-woo-product-migrator' ) );
		}

		$existing_id = $this->find_existing_review( $record, $options['match_strategy'] ?? 'review_id' );

		if ( $existing_id && 'skip' === ( $options['existing_action'] ?? 'skip' ) ) {
			return array( 'verdict' => 'skipped', 'id' => $existing_id, 'message' => __( 'Review already exists — skipped.', 'advanced-woo-product-migrator' ) );
		}
		if ( $existing_id && 'duplicate' === ( $options['existing_action'] ?? '' ) ) {
			$existing_id = 0;
		}

		if ( $dry_run ) {
			return array(
				'verdict' => $existing_id ? 'updated' : 'created',
				'id'      => $existing_id,
				'message' => $existing_id ? __( 'Would update existing review.', 'advanced-woo-product-migrator' ) : __( 'Would create new review.', 'advanced-woo-product-migrator' ),
			);
		}

		$status_map = array( 'approved' => '1', 'unapproved' => '0', 'hold' => '0', 'spam' => 'spam', 'trash' => 'trash' );
		$status     = $status_map[ $record['status'] ?? '' ] ?? ( 'approve' === ( $options['default_status'] ?? 'approve' ) ? '1' : '0' );

		$comment_data = array(
			'comment_post_ID'      => $product_id,
			'comment_author'       => $record['author_name'] ?? '',
			'comment_author_email' => $record['author_email'] ?? '',
			'comment_content'      => $record['content'] ?? '',
			'comment_type'         => 'review',
			'comment_approved'     => $status,
			'user_id'              => ! empty( $record['author_user_id'] ) ? (int) $record['author_user_id'] : 0,
		);
		if ( ! empty( $record['date_created'] ) ) {
			$comment_data['comment_date'] = $record['date_created'];
		}

		if ( $existing_id ) {
			$comment_data['comment_ID'] = $existing_id;
			wp_update_comment( $comment_data );
			$comment_id = $existing_id;
		} else {
			$comment_id = wp_insert_comment( $comment_data );
		}

		if ( ! $comment_id ) {
			throw new Exception( __( 'Failed to write the review comment.', 'advanced-woo-product-migrator' ) );
		}

		if ( isset( $record['rating'] ) ) {
			update_comment_meta( $comment_id, 'rating', (int) $record['rating'] );
		}
		if ( isset( $record['verified_owner'] ) ) {
			update_comment_meta( $comment_id, 'verified', (int) $record['verified_owner'] );
		}

		$external_id = $record['external_id'] ?? ( $record['review_id'] ?? '' );
		if ( $external_id ) {
			update_comment_meta( $comment_id, '_awpm_external_id', $external_id );
			AWPM_Relationship_Map::set_mapping( 'default', (string) $external_id, $comment_id, 'review', (string) $external_id );
		}

		return array(
			'verdict' => $existing_id ? 'updated' : 'created',
			'id'      => $comment_id,
			'message' => $existing_id ? __( 'Updated existing review.', 'advanced-woo-product-migrator' ) : __( 'Created new review.', 'advanced-woo-product-migrator' ),
		);
	}

	/**
	 * Read-only preview, mirroring AWPM_Product_Importer::preview_rows().
	 */
	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$rows    = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview = array();

		foreach ( $rows as $raw_row ) {
			$record = $this->apply_mapping( $raw_row, $args['mapping'] ?? array() );
			$issues = array();

			$product_id = 0;
			try {
				$product_id = $this->resolve_product_id( $record );
			} catch ( Exception $e ) {
				$issues[] = $e->getMessage();
			}
			if ( ! $product_id ) {
				$issues[] = __( 'Target product not found on this site.', 'advanced-woo-product-migrator' );
			}
			$existing_id = $product_id ? $this->find_existing_review( $record, $args['match_strategy'] ?? 'review_id' ) : 0;

			$preview[] = array(
				'name'        => $record['author_name'] ?? '',
				'sku'         => $record['product_sku'] ?? '',
				'type'        => 'review',
				'price'       => ! empty( $record['rating'] ) ? str_repeat( '★', (int) $record['rating'] ) : '—',
				'categories'  => '',
				'image_count' => 0,
				'variation_count' => 0,
				'has_acf'     => false,
				'has_yoast'   => false,
				'meta_count'  => 0,
				'status'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $issues,
			);
		}

		return $preview;
	}
}
