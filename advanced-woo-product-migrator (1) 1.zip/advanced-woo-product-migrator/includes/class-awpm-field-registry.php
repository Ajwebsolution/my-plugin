<?php
/**
 * AWPM_Field_Registry
 *
 * Builds the full catalogue of fields available for export selection and
 * import mapping: WooCommerce core fields, ACF fields (recursively, incl.
 * repeater/flexible content sub-fields), Yoast SEO fields, and raw/custom
 * post meta discovered by scanning real products.
 *
 * This is what powers the "SOURCE FIELD -> TARGET FIELD" mapping UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Field_Registry {

	/**
	 * Core WooCommerce / WordPress fields, grouped, with a stable "key"
	 * used throughout the exporter/importer to address the field.
	 *
	 * @return array
	 */
	public static function get_core_fields() {
		return array(
			'general'   => array(
				'id'                 => __( 'Product ID', 'advanced-woo-product-migrator' ),
				'external_id'        => __( 'External ID (source system business ID)', 'advanced-woo-product-migrator' ),
				'name'               => __( 'Product Title', 'advanced-woo-product-migrator' ),
				'slug'               => __( 'Slug', 'advanced-woo-product-migrator' ),
				'description'        => __( 'Description', 'advanced-woo-product-migrator' ),
				'short_description'  => __( 'Short Description', 'advanced-woo-product-migrator' ),
				'sku'                => __( 'SKU', 'advanced-woo-product-migrator' ),
				'status'             => __( 'Product Status', 'advanced-woo-product-migrator' ),
				'catalog_visibility' => __( 'Catalog Visibility', 'advanced-woo-product-migrator' ),
				'featured'           => __( 'Featured', 'advanced-woo-product-migrator' ),
				'type'               => __( 'Product Type', 'advanced-woo-product-migrator' ),
				'menu_order'         => __( 'Menu Order', 'advanced-woo-product-migrator' ),
			),
			'pricing'   => array(
				'regular_price'  => __( 'Regular Price', 'advanced-woo-product-migrator' ),
				'sale_price'     => __( 'Sale Price', 'advanced-woo-product-migrator' ),
				'date_on_sale_from' => __( 'Sale Start Date', 'advanced-woo-product-migrator' ),
				'date_on_sale_to'   => __( 'Sale End Date', 'advanced-woo-product-migrator' ),
			),
			'inventory' => array(
				'manage_stock'   => __( 'Manage Stock', 'advanced-woo-product-migrator' ),
				'stock_quantity' => __( 'Stock Quantity', 'advanced-woo-product-migrator' ),
				'stock_status'   => __( 'Stock Status', 'advanced-woo-product-migrator' ),
				'backorders'     => __( 'Backorders', 'advanced-woo-product-migrator' ),
				'sold_individually' => __( 'Sold Individually', 'advanced-woo-product-migrator' ),
			),
			'shipping'  => array(
				'weight'         => __( 'Weight', 'advanced-woo-product-migrator' ),
				'length'         => __( 'Length', 'advanced-woo-product-migrator' ),
				'width'          => __( 'Width', 'advanced-woo-product-migrator' ),
				'height'         => __( 'Height', 'advanced-woo-product-migrator' ),
				'shipping_class' => __( 'Shipping Class', 'advanced-woo-product-migrator' ),
			),
			'tax'       => array(
				'tax_status' => __( 'Tax Status', 'advanced-woo-product-migrator' ),
				'tax_class'  => __( 'Tax Class', 'advanced-woo-product-migrator' ),
			),
			'purchase'  => array(
				'virtual'      => __( 'Virtual', 'advanced-woo-product-migrator' ),
				'downloadable' => __( 'Downloadable', 'advanced-woo-product-migrator' ),
				'purchase_note' => __( 'Purchase Note', 'advanced-woo-product-migrator' ),
				'downloads'    => __( 'Downloadable Files', 'advanced-woo-product-migrator' ),
				'download_limit' => __( 'Download Limit', 'advanced-woo-product-migrator' ),
				'download_expiry' => __( 'Download Expiry (days)', 'advanced-woo-product-migrator' ),
				'product_url'  => __( 'External/Affiliate Product URL', 'advanced-woo-product-migrator' ),
				'button_text'  => __( 'External/Affiliate Button Text', 'advanced-woo-product-migrator' ),
			),
			'relations' => array(
				'upsell_ids'    => __( 'Upsells (SKUs)', 'advanced-woo-product-migrator' ),
				'cross_sell_ids'=> __( 'Cross-sells (SKUs)', 'advanced-woo-product-migrator' ),
				'grouped_ids'   => __( 'Grouped Product SKUs', 'advanced-woo-product-migrator' ),
			),
			'taxonomy'  => array(
				'categories' => __( 'Categories', 'advanced-woo-product-migrator' ),
				'tags'       => __( 'Tags', 'advanced-woo-product-migrator' ),
			),
			'images'    => array(
				'featured_image' => __( 'Featured Image', 'advanced-woo-product-migrator' ),
				'gallery_images' => __( 'Gallery Images', 'advanced-woo-product-migrator' ),
			),
			'attributes' => array(
				'attributes' => __( 'Attributes (all)', 'advanced-woo-product-migrator' ),
			),
			'variations' => array(
				'variations' => __( 'Variations (all)', 'advanced-woo-product-migrator' ),
			),
		);
	}

	/**
	 * Core fields for the Reviews entity (Export Step 4 / Import mapping
	 * catalog when "Reviews" is the selected data type). Reviews are plain
	 * WP_Comment rows — there's no ACF/Yoast layer for them, so (unlike
	 * products) this is the entire field catalog for this entity.
	 *
	 * @return array
	 */
	public static function get_review_fields() {
		return array(
			'general' => array(
				'review_id'      => __( 'Review ID', 'advanced-woo-product-migrator' ),
				'external_id'    => __( 'External ID', 'advanced-woo-product-migrator' ),
				'product_sku'    => __( 'Product SKU', 'advanced-woo-product-migrator' ),
				'author_name'    => __( 'Author Name', 'advanced-woo-product-migrator' ),
				'author_email'   => __( 'Author Email', 'advanced-woo-product-migrator' ),
				'content'        => __( 'Review Content', 'advanced-woo-product-migrator' ),
				'rating'         => __( 'Star Rating (1-5)', 'advanced-woo-product-migrator' ),
				'verified_owner' => __( 'Verified Owner', 'advanced-woo-product-migrator' ),
				'status'         => __( 'Approval Status', 'advanced-woo-product-migrator' ),
				'date_created'   => __( 'Date', 'advanced-woo-product-migrator' ),
			),
		);
	}

	/**
	 * Core fields for the Orders entity.
	 *
	 * @return array
	 */
	public static function get_order_fields() {
		return array(
			'general' => array(
				'order_id'       => __( 'Order ID', 'advanced-woo-product-migrator' ),
				'external_id'    => __( 'External ID', 'advanced-woo-product-migrator' ),
				'order_number'   => __( 'Order Number', 'advanced-woo-product-migrator' ),
				'status'         => __( 'Order Status', 'advanced-woo-product-migrator' ),
				'currency'       => __( 'Currency', 'advanced-woo-product-migrator' ),
				'date_created'   => __( 'Date Created', 'advanced-woo-product-migrator' ),
				'customer_email' => __( 'Customer Email', 'advanced-woo-product-migrator' ),
				'payment_method' => __( 'Payment Method', 'advanced-woo-product-migrator' ),
				'customer_note'  => __( 'Customer Note', 'advanced-woo-product-migrator' ),
			),
			'pricing' => array(
				'total'          => __( 'Order Total', 'advanced-woo-product-migrator' ),
				'total_tax'      => __( 'Total Tax', 'advanced-woo-product-migrator' ),
				'shipping_total' => __( 'Shipping Total', 'advanced-woo-product-migrator' ),
				'discount_total' => __( 'Discount Total', 'advanced-woo-product-migrator' ),
			),
			'relations' => array(
				'line_items'     => __( 'Line Items', 'advanced-woo-product-migrator' ),
				'shipping_lines' => __( 'Shipping Lines', 'advanced-woo-product-migrator' ),
				'fee_lines'      => __( 'Fee Lines', 'advanced-woo-product-migrator' ),
				'coupon_lines'   => __( 'Coupon Codes', 'advanced-woo-product-migrator' ),
			),
			'taxonomy' => array(
				'billing'  => __( 'Billing Address', 'advanced-woo-product-migrator' ),
				'shipping' => __( 'Shipping Address', 'advanced-woo-product-migrator' ),
			),
		);
	}

	/**
	 * Core fields for the Customers entity.
	 *
	 * @return array
	 */
	public static function get_customer_fields() {
		return array(
			'general' => array(
				'user_id'         => __( 'User ID', 'advanced-woo-product-migrator' ),
				'external_id'     => __( 'External ID', 'advanced-woo-product-migrator' ),
				'username'        => __( 'Username', 'advanced-woo-product-migrator' ),
				'email'           => __( 'Email', 'advanced-woo-product-migrator' ),
				'first_name'      => __( 'First Name', 'advanced-woo-product-migrator' ),
				'last_name'       => __( 'Last Name', 'advanced-woo-product-migrator' ),
				'roles'           => __( 'Role(s)', 'advanced-woo-product-migrator' ),
				'date_registered' => __( 'Date Registered', 'advanced-woo-product-migrator' ),
			),
			'pricing' => array(
				'is_paying_customer' => __( 'Paying Customer', 'advanced-woo-product-migrator' ),
				'order_count'         => __( 'Order Count', 'advanced-woo-product-migrator' ),
				'total_spent'         => __( 'Total Spent', 'advanced-woo-product-migrator' ),
			),
			'taxonomy' => array(
				'billing'  => __( 'Billing Address', 'advanced-woo-product-migrator' ),
				'shipping' => __( 'Shipping Address', 'advanced-woo-product-migrator' ),
			),
		);
	}

	/**
	 * Core fields for the standalone Categories & Tags entity. Covers both
	 * product_cat (hierarchical) and product_tag (flat) terms — the 'path'
	 * field carries the full "Parent > Child" ancestor chain for categories
	 * so hierarchy round-trips; it's just the term's own name for tags.
	 *
	 * @return array
	 */
	public static function get_taxonomy_fields() {
		return array(
			'general' => array(
				'term_id'      => __( 'Term ID', 'advanced-woo-product-migrator' ),
				'external_id'  => __( 'External ID', 'advanced-woo-product-migrator' ),
				'taxonomy'     => __( 'Taxonomy (Category or Tag)', 'advanced-woo-product-migrator' ),
				'name'         => __( 'Name', 'advanced-woo-product-migrator' ),
				'slug'         => __( 'Slug', 'advanced-woo-product-migrator' ),
				'description'  => __( 'Description', 'advanced-woo-product-migrator' ),
				'path'         => __( 'Full Hierarchy Path (categories only)', 'advanced-woo-product-migrator' ),
				'count'        => __( 'Product Count', 'advanced-woo-product-migrator' ),
			),
		);
	}

	/**
	 * Discover every ACF field group/field relevant to WooCommerce products
	 * (location rule: Post Type == product, or a group with no location
	 * restriction, included defensively).
	 *
	 * Returns a flat list of field definitions with dotted "selector" keys
	 * such as: specifications (repeater) -> specifications.material
	 *
	 * @return array
	 */
	public static function get_acf_fields() {
		if ( ! function_exists( 'acf_get_field_groups' ) ) {
			return array();
		}

		$groups = acf_get_field_groups( array( 'post_type' => 'product' ) );
		// Fall back to ALL groups if location targeting can't be resolved
		// (some setups use complex/OR location logic acf_get_field_groups
		// won't match against a bare post_type argument).
		if ( empty( $groups ) ) {
			$groups = acf_get_field_groups();
		}

		$fields = array();

		foreach ( $groups as $group ) {
			$group_fields = function_exists( 'acf_get_fields' ) ? acf_get_fields( $group['key'] ) : array();
			foreach ( (array) $group_fields as $field ) {
				$fields = array_merge( $fields, self::flatten_acf_field( $field, $group['title'] ) );
			}
		}

		return $fields;
	}

	/**
	 * Recursively flatten an ACF field (and sub_fields for repeater / group,
	 * and layouts/sub_fields for flexible_content) into a list of
	 * { selector, label, type, group } entries used by the mapping UI.
	 *
	 * The "selector" here is the dotted path passed straight to ACF's own
	 * get_field()/update_field() — ACF understands "repeater_name" as a
	 * whole (returns array of rows); we expose sub-selectors purely for
	 * display/mapping convenience in CSV mode, where each repeater row's
	 * sub-field can be targeted individually.
	 *
	 * @param array  $field ACF field array.
	 * @param string $group_label Parent field group title, for display grouping.
	 * @param string $prefix Dotted selector prefix (for nested calls).
	 * @return array
	 */
	protected static function flatten_acf_field( $field, $group_label, $prefix = '' ) {
		$selector = $prefix ? $prefix . '.' . $field['name'] : $field['name'];

		$entry = array(
			'selector' => $selector,
			'name'     => $field['name'],
			'key'      => $field['key'],
			'label'    => $field['label'],
			'type'     => $field['type'],
			'group'    => $group_label,
		);

		$out = array( $entry );

		if ( in_array( $field['type'], array( 'repeater', 'group' ), true ) && ! empty( $field['sub_fields'] ) ) {
			foreach ( $field['sub_fields'] as $sub ) {
				$out = array_merge( $out, self::flatten_acf_field( $sub, $group_label, $selector ) );
			}
		}

		if ( 'flexible_content' === $field['type'] && ! empty( $field['layouts'] ) ) {
			foreach ( $field['layouts'] as $layout ) {
				if ( empty( $layout['sub_fields'] ) ) {
					continue;
				}
				$layout_prefix = $selector . '.' . $layout['name'];
				foreach ( $layout['sub_fields'] as $sub ) {
					$out = array_merge( $out, self::flatten_acf_field( $sub, $group_label, $layout_prefix ) );
				}
			}
		}

		return $out;
	}

	/**
	 * Yoast SEO field map: our internal key => Yoast's actual postmeta key.
	 * Centralized here (rather than hardcoded scattered constants) so it's
	 * the single configurable source the spec asks for.
	 *
	 * @return array
	 */
	public static function get_yoast_field_map() {
		/**
		 * Filterable so site owners can add/rename keys for custom Yoast
		 * add-ons or future Yoast schema changes without touching code.
		 */
		return apply_filters(
			'awpm_yoast_field_map',
			array(
				'yoast_title'        => '_yoast_wpseo_title',
				'yoast_metadesc'     => '_yoast_wpseo_metadesc',
				'yoast_focuskw'      => '_yoast_wpseo_focuskw',
				'yoast_linkdex'      => '_yoast_wpseo_linkdex',
				'yoast_canonical'    => '_yoast_wpseo_canonical',
				'yoast_meta_robots_noindex'  => '_yoast_wpseo_meta-robots-noindex',
				'yoast_meta_robots_nofollow' => '_yoast_wpseo_meta-robots-nofollow',
				'yoast_opengraph_title'   => '_yoast_wpseo_opengraph-title',
				'yoast_opengraph_desc'    => '_yoast_wpseo_opengraph-description',
				'yoast_opengraph_image'   => '_yoast_wpseo_opengraph-image',
				'yoast_twitter_title'     => '_yoast_wpseo_twitter-title',
				'yoast_twitter_desc'      => '_yoast_wpseo_twitter-description',
				'yoast_twitter_image'     => '_yoast_wpseo_twitter-image',
			)
		);
	}

	/**
	 * Scan a sample of real products' postmeta to build a list of "unknown"
	 * custom meta keys the exporter should surface for include/exclude/
	 * rename/map decisions. Internal/reserved keys (_edit_lock, WC's own
	 * managed keys, ACF's own "_fieldname" key-reference rows, Yoast keys)
	 * are excluded since those are handled by their own dedicated systems.
	 *
	 * @param int $sample_size Number of products to sample.
	 * @return array List of meta_key => example value.
	 */
	public static function discover_custom_meta_keys( $sample_size = 100 ) {
		global $wpdb;

		$excluded_prefixes = array( '_yoast_wpseo_', '_wc_', '_product_', '_edit_', '_wp_' );
		$excluded_exact     = array(
			'_sku', '_regular_price', '_sale_price', '_price', '_stock', '_stock_status',
			'_manage_stock', '_backorders', '_sold_individually', '_weight', '_length',
			'_width', '_height', '_tax_status', '_tax_class', '_downloadable', '_virtual',
			'_featured', '_visibility', '_thumbnail_id', '_product_image_gallery',
			'_upsell_ids', '_crosssell_ids', '_children', '_product_attributes',
			'_default_attributes', '_variation_description', '_edit_lock', '_edit_last',
		);

		$product_ids = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => 'any',
				'posts_per_page' => $sample_size,
				'fields'         => 'ids',
				'orderby'        => 'rand',
			)
		);

		if ( empty( $product_ids ) ) {
			return array();
		}

		$ids_sql = implode( ',', array_map( 'intval', $product_ids ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $ids_sql is int-cast above.
		$rows = $wpdb->get_results( "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$ids_sql})" );

		$discovered = array();

		foreach ( $rows as $row ) {
			$key = $row->meta_key;

			if ( isset( $discovered[ $key ] ) ) {
				continue;
			}
			if ( in_array( $key, $excluded_exact, true ) ) {
				continue;
			}
			// ACF stores a shadow "_field_name" reference row per field; skip those,
			// ACF's own field data (by real field name) is handled by the ACF handler.
			if ( 0 === strpos( $key, '_' ) && function_exists( 'acf_get_field' ) ) {
				$maybe_field_key = get_post_meta( $product_ids[0], $key, true );
				if ( is_string( $maybe_field_key ) && 0 === strpos( $maybe_field_key, 'field_' ) ) {
					continue;
				}
			}

			$skip = false;
			foreach ( $excluded_prefixes as $prefix ) {
				if ( 0 === strpos( $key, $prefix ) ) {
					$skip = true;
					break;
				}
			}
			if ( $skip ) {
				continue;
			}

			$discovered[ $key ] = $row->meta_value;
		}

		return $discovered;
	}
}
