<?php
/**
 * AWPM_Jobs
 *
 * All reads/writes to wp_awpm_import_jobs / wp_awpm_export_jobs /
 * wp_awpm_import_items. This is what turns import/export from a single
 * blocking PHP request into a real batch-processed background job: a job
 * row tracks offset/total/counts, and AWPM_Ajax::process_import_batch()
 * (or WP-Cron, for scheduled jobs) advances it one batch at a time until
 * it's done — never processing an entire large dataset in one request.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Jobs {

	/* ------------------------- Import jobs ------------------------- */

	public static function create_import_job( $args ) {
		global $wpdb;
		$defaults = array(
			'status'      => 'pending',
			'entity_type' => 'product',
			'file_path'   => '',
			'format'      => 'json',
			'mapping'     => array(),
			'options'     => array(),
			'dry_run'     => 0,
			'batch_size'  => 50,
			'total_rows'  => 0,
			'created_by'  => get_current_user_id(),
			'mapping_profile_id' => null,
		);
		$args = wp_parse_args( $args, $defaults );

		$wpdb->insert(
			$wpdb->prefix . 'awpm_import_jobs',
			array(
				'status'      => $args['status'],
				'entity_type' => $args['entity_type'],
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => wp_json_encode( $args['mapping'] ),
				'options'     => wp_json_encode( $args['options'] ),
				'dry_run'     => (int) $args['dry_run'],
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => (int) $args['total_rows'],
				'mapping_profile_id' => $args['mapping_profile_id'],
				'created_by'  => (int) $args['created_by'],
				'created_at'  => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function get_import_job( $job_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}awpm_import_jobs WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$row['mapping'] = json_decode( $row['mapping'], true ) ?: array();
		$row['options'] = json_decode( $row['options'], true ) ?: array();
		return $row;
	}

	public static function update_import_job( $job_id, $fields ) {
		global $wpdb;
		if ( isset( $fields['mapping'] ) && is_array( $fields['mapping'] ) ) {
			$fields['mapping'] = wp_json_encode( $fields['mapping'] );
		}
		if ( isset( $fields['options'] ) && is_array( $fields['options'] ) ) {
			$fields['options'] = wp_json_encode( $fields['options'] );
		}
		$wpdb->update( $wpdb->prefix . 'awpm_import_jobs', $fields, array( 'id' => $job_id ) );
	}

	public static function increment_import_counts( $job_id, $created = 0, $updated = 0, $skipped = 0, $failed = 0, $offset_advance = 0 ) {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}awpm_import_jobs SET
					created_count = created_count + %d,
					updated_count = updated_count + %d,
					skipped_count = skipped_count + %d,
					failed_count  = failed_count + %d,
					offset_row    = offset_row + %d
				WHERE id = %d",
				$created, $updated, $skipped, $failed, $offset_advance, $job_id
			)
		);
	}

	public static function add_import_item( $job_id, $row_index, $sku, $product_id, $result, $message = '' ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'awpm_import_items',
			array(
				'job_id'     => $job_id,
				'row_index'  => $row_index,
				'sku'        => $sku,
				'product_id' => $product_id ?: null,
				'result'     => $result, // success|warning|error
				'message'    => $message,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%d', '%s', '%s', '%s' )
		);
	}

	public static function get_import_items( $job_id, $result_filter = '', $limit = 200, $offset = 0 ) {
		global $wpdb;
		$where = $wpdb->prepare( 'job_id = %d', $job_id );
		if ( $result_filter ) {
			$where .= $wpdb->prepare( ' AND result = %s', $result_filter );
		}
		return $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}awpm_import_items WHERE {$where} ORDER BY id ASC LIMIT " . (int) $limit . ' OFFSET ' . (int) $offset, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			ARRAY_A
		);
	}

	public static function list_import_jobs( $limit = 50 ) {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}awpm_import_jobs ORDER BY id DESC LIMIT " . (int) $limit, ARRAY_A ); // phpcs:ignore
	}

	/* ------------------------- Export jobs ------------------------- */

	public static function create_export_job( $args ) {
		global $wpdb;
		$defaults = array(
			'status'     => 'pending',
			'entity_type' => 'product',
			'format'     => 'json',
			'args'       => array(),
			'batch_size' => 50,
			'total_rows' => 0,
			'created_by' => get_current_user_id(),
		);
		$args = wp_parse_args( $args, $defaults );

		$wpdb->insert(
			$wpdb->prefix . 'awpm_export_jobs',
			array(
				'status'     => $args['status'],
				'entity_type' => $args['entity_type'],
				'format'     => $args['format'],
				'args'       => wp_json_encode( $args['args'] ),
				'batch_size' => (int) $args['batch_size'],
				'total_rows' => (int) $args['total_rows'],
				'created_by' => (int) $args['created_by'],
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function get_export_job( $job_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}awpm_export_jobs WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$row['args'] = json_decode( $row['args'], true ) ?: array();
		return $row;
	}

	public static function update_export_job( $job_id, $fields ) {
		global $wpdb;
		if ( isset( $fields['args'] ) && is_array( $fields['args'] ) ) {
			$fields['args'] = wp_json_encode( $fields['args'] );
		}
		$wpdb->update( $wpdb->prefix . 'awpm_export_jobs', $fields, array( 'id' => $job_id ) );
	}

	public static function list_export_jobs( $limit = 50 ) {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}awpm_export_jobs ORDER BY id DESC LIMIT " . (int) $limit, ARRAY_A ); // phpcs:ignore
	}

	/* ------------------------- Dashboard stats ------------------------- */

	public static function get_dashboard_stats() {
		global $wpdb;
		$prefix = $wpdb->prefix;

		$last_import = $wpdb->get_row( "SELECT * FROM {$prefix}awpm_import_jobs WHERE status = 'completed' ORDER BY finished_at DESC LIMIT 1", ARRAY_A );
		$last_export = $wpdb->get_row( "SELECT * FROM {$prefix}awpm_export_jobs WHERE status = 'completed' ORDER BY finished_at DESC LIMIT 1", ARRAY_A );

		$totals = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(created_count),0) as created,
				COALESCE(SUM(updated_count),0) as updated,
				COALESCE(SUM(failed_count),0) as failed
			FROM {$prefix}awpm_import_jobs WHERE status = 'completed'",
			ARRAY_A
		);

		return array(
			'products'      => (int) wp_count_posts( 'product' )->publish + (int) wp_count_posts( 'product' )->draft,
			'variations'    => (int) wp_count_posts( 'product_variation' )->publish,
			'last_import'   => $last_import,
			'last_export'   => $last_export,
			'total_created' => (int) ( $totals['created'] ?? 0 ),
			'total_updated' => (int) ( $totals['updated'] ?? 0 ),
			'total_failed'  => (int) ( $totals['failed'] ?? 0 ),
			'recent_imports' => self::list_import_jobs( 5 ),
			'recent_exports' => self::list_export_jobs( 5 ),
		);
	}
}
