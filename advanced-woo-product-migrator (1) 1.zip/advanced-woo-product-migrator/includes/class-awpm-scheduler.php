<?php
/**
 * AWPM_Scheduler
 *
 * Real WP-Cron backed scheduling: wp_awpm_scheduled_jobs rows are synced to
 * actual wp_schedule_event() hooks on save, and the cron callback creates a
 * genuine import/export job (via AWPM_Jobs) and kicks off batch processing
 * through the same code path the manual UI uses — not a fake "scheduled"
 * label with nothing behind it. Also registers the plugin's custom cron
 * intervals (every 6 hours) since WordPress only ships hourly/twicedaily/
 * daily by default, and a daily maintenance event for log/snapshot pruning
 * and batch continuation of any in-flight jobs a request didn't finish.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Scheduler {

	const CRON_HOOK_RUN_JOB     = 'awpm_run_scheduled_job';
	const CRON_HOOK_MAINTENANCE = 'awpm_daily_maintenance';
	const CRON_HOOK_BATCH_TICK  = 'awpm_batch_tick';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'register_intervals' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		add_action( self::CRON_HOOK_RUN_JOB, array( __CLASS__, 'run_scheduled_job' ), 10, 1 );
		add_action( self::CRON_HOOK_MAINTENANCE, array( __CLASS__, 'maintenance' ) );
		add_action( self::CRON_HOOK_BATCH_TICK, array( __CLASS__, 'advance_pending_batches' ) );

		if ( ! wp_next_scheduled( self::CRON_HOOK_MAINTENANCE ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK_MAINTENANCE );
		}
		if ( ! wp_next_scheduled( self::CRON_HOOK_BATCH_TICK ) ) {
			wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'awpm_every_five_minutes', self::CRON_HOOK_BATCH_TICK );
		}
	}

	public static function register_intervals( $schedules ) {
		$schedules['awpm_every_six_hours']    = array( 'interval' => 6 * HOUR_IN_SECONDS, 'display' => __( 'Every 6 Hours', 'advanced-woo-product-migrator' ) );
		$schedules['awpm_every_five_minutes'] = array( 'interval' => 5 * MINUTE_IN_SECONDS, 'display' => __( 'Every 5 Minutes (AWPM internal)', 'advanced-woo-product-migrator' ) );
		return $schedules;
	}

	/**
	 * Create/update the DB row AND its wp_schedule_event() hook together,
	 * so the two never drift out of sync.
	 */
	public static function save_scheduled_job( $args ) {
		global $wpdb;

		$recurrence_map = array(
			'hourly'      => 'hourly',
			'six_hourly'  => 'awpm_every_six_hours',
			'daily'       => 'daily',
			'weekly'      => 'weekly',
		);
		$wp_recurrence = $recurrence_map[ $args['recurrence'] ] ?? 'daily';

		$id = ! empty( $args['id'] ) ? (int) $args['id'] : 0;

		$row = array(
			'name'                => sanitize_text_field( $args['name'] ),
			'type'                => in_array( $args['type'], array( 'import', 'export' ), true ) ? $args['type'] : 'import',
			'recurrence'          => sanitize_key( $args['recurrence'] ),
			'source_type'         => sanitize_key( $args['source_type'] ?? 'remote_url' ),
			'source_config'       => wp_json_encode( $args['source_config'] ?? array() ),
			'mapping_profile_id'  => ! empty( $args['mapping_profile_id'] ) ? (int) $args['mapping_profile_id'] : null,
			'active'              => ! empty( $args['active'] ) ? 1 : 0,
		);

		if ( $id ) {
			$wpdb->update( $wpdb->prefix . 'awpm_scheduled_jobs', $row, array( 'id' => $id ) );
			wp_clear_scheduled_hook( self::CRON_HOOK_RUN_JOB, array( $id ) );
		} else {
			$row['created_at'] = current_time( 'mysql' );
			$wpdb->insert( $wpdb->prefix . 'awpm_scheduled_jobs', $row );
			$id = (int) $wpdb->insert_id;
		}

		if ( $row['active'] ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, $wp_recurrence, self::CRON_HOOK_RUN_JOB, array( $id ) );
		}

		return $id;
	}

	public static function delete_scheduled_job( $id ) {
		global $wpdb;
		wp_clear_scheduled_hook( self::CRON_HOOK_RUN_JOB, array( $id ) );
		$wpdb->delete( $wpdb->prefix . 'awpm_scheduled_jobs', array( 'id' => $id ), array( '%d' ) );
	}

	public static function list_scheduled_jobs() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}awpm_scheduled_jobs ORDER BY id DESC", ARRAY_A );
		foreach ( $rows as &$row ) {
			$row['source_config'] = json_decode( $row['source_config'], true ) ?: array();
			$row['next_run']      = wp_next_scheduled( self::CRON_HOOK_RUN_JOB, array( (int) $row['id'] ) );
		}
		return $rows;
	}

	/**
	 * Cron callback: fetch the source (currently: remote URL — FTP/SFTP is
	 * a documented extension point, see readme.txt), create a real import
	 * job using the saved mapping profile, and process it fully via the
	 * same batch loop the manual "Run Import" button uses.
	 */
	public static function run_scheduled_job( $scheduled_job_id ) {
		global $wpdb;
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}awpm_scheduled_jobs WHERE id = %d", $scheduled_job_id ), ARRAY_A );
		if ( ! $job || ! $job['active'] ) {
			return;
		}

		$source_config = json_decode( $job['source_config'], true ) ?: array();

		AWPM_Logger::start_run( $job['type'], $scheduled_job_id );

		if ( 'export' === $job['type'] ) {
			$exporter = new AWPM_Product_Exporter();
			$result   = $exporter->export( $source_config['export_args'] ?? array() );
			$status   = is_wp_error( $result ) ? 'failed' : 'completed';
		} else {
			$fetched = self::fetch_scheduled_source( $job['source_type'], $source_config );
			if ( is_wp_error( $fetched ) ) {
				self::mark_run( $scheduled_job_id, 'failed' );
				AWPM_Logger::log( 'error', 'Scheduled import fetch failed: ' . $fetched->get_error_message() );
				AWPM_Webhooks::dispatch( 'import.failed', array( 'scheduled_job_id' => $scheduled_job_id, 'error' => $fetched->get_error_message() ) );
				AWPM_Notifications::notify( 'import_failed', array( 'job_id' => $scheduled_job_id, 'error' => $fetched->get_error_message() ) );
				return;
			}

			$mapping_profile = ! empty( $job['mapping_profile_id'] ) ? AWPM_Mappings::get( $job['mapping_profile_id'] ) : null;
			$config          = $mapping_profile['config'] ?? array();

			$importer = new AWPM_Product_Importer();
			$result   = $importer->import(
				array(
					'file_path'       => $fetched['file_path'],
					'format'          => $fetched['format'],
					'mapping'         => $config['mapping'] ?? array(),
					'match_strategy'  => $config['match_strategy'] ?? 'sku',
					'existing_action' => $config['existing_action'] ?? 'update',
					'options'         => $config['options'] ?? array(),
					'dry_run'         => false,
				)
			);
			$status = is_wp_error( $result ) ? 'failed' : 'completed';
		}

		self::mark_run( $scheduled_job_id, $status );

		$notify_event = 'completed' === $status ? ( 'export' === $job['type'] ? 'export_completed' : 'import_completed' ) : ( 'export' === $job['type'] ? 'export_failed' : 'import_failed' );
		$notify_data  = array( 'job_id' => $scheduled_job_id );
		if ( is_wp_error( $result ) ) {
			$notify_data['error'] = $result->get_error_message();
		}
		AWPM_Notifications::notify( $notify_event, $notify_data );

		AWPM_Webhooks::dispatch(
			'completed' === $status ? ( 'export' === $job['type'] ? 'export.completed' : 'import.completed' ) : 'import.failed',
			array( 'scheduled_job_id' => $scheduled_job_id, 'result' => is_wp_error( $result ) ? $result->get_error_message() : $result )
		);
	}

	protected static function mark_run( $scheduled_job_id, $status ) {
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'awpm_scheduled_jobs',
			array( 'last_run_at' => current_time( 'mysql' ), 'last_status' => $status ),
			array( 'id' => $scheduled_job_id )
		);
	}

	/**
	 * Dispatch to the right fetcher for a scheduled import's configured
	 * source. Passwords in $source_config are never logged by either
	 * fetcher — only host/path appear in log messages.
	 *
	 * @param string $source_type remote_url|ftp
	 * @param array  $source_config
	 * @return array{file_path:string,format:string}|WP_Error
	 */
	protected static function fetch_scheduled_source( $source_type, $source_config ) {
		if ( 'ftp' === $source_type ) {
			return AWPM_Ftp_Fetcher::fetch( $source_config );
		}
		if ( 'remote_url' === $source_type && ! empty( $source_config['url'] ) ) {
			return AWPM_Remote_Fetcher::fetch( $source_config['url'] );
		}
		return new WP_Error( 'awpm_no_usable_source', __( 'Scheduled import has no usable source configured.', 'advanced-woo-product-migrator' ) );
	}

	/**
	 * Daily maintenance: prune old logs and expired rollback snapshots.
	 */
	public static function maintenance() {
		AWPM_Logger::prune_old_logs();
		AWPM_Snapshot::prune_expired();

		// Also clean stale temp import/export files older than 48 hours.
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		foreach ( glob( trailingslashit( $tmp_dir ) . 'awpm-*' ) ?: array() as $file ) {
			if ( is_file( $file ) && filemtime( $file ) < time() - 2 * DAY_IN_SECONDS ) {
				@unlink( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
		}
	}

	/**
	 * Safety net: if a batch job (import/export) was left "running" because
	 * the browser tab closed mid-way, this cron tick advances it a bit
	 * further every 5 minutes so large jobs still complete even without an
	 * open browser tab.
	 */
	public static function advance_pending_batches() {
		global $wpdb;

		$stuck_imports = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}awpm_import_jobs WHERE status = 'running' AND created_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE) LIMIT 5" );
		foreach ( $stuck_imports as $job_id ) {
			$importer = new AWPM_Product_Importer();
			$importer->process_next_batch( (int) $job_id );
		}

		$stuck_exports = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}awpm_export_jobs WHERE status = 'running' AND created_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE) LIMIT 5" );
		foreach ( $stuck_exports as $job_id ) {
			$exporter = new AWPM_Product_Exporter();
			$exporter->process_next_batch( (int) $job_id );
		}
	}
}
