<?php
/**
 * AWPM_Webhooks
 *
 * Dispatches a real HTTP POST to the site owner's configured webhook URL
 * on import/export lifecycle events, with the documented JSON payload
 * shape. Fire-and-forget (non-blocking) so a slow/broken webhook endpoint
 * never delays or fails the import/export itself.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Webhooks {

	/**
	 * @param string $event  import.started|import.completed|import.failed|export.completed|export.failed
	 * @param array  $data   Event-specific payload merged into the envelope.
	 */
	public static function dispatch( $event, $data = array() ) {
		$settings = get_option( 'awpm_settings', array() );
		$url      = $settings['webhook_url'] ?? '';

		if ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return;
		}

		$enabled_events = $settings['webhook_events'] ?? array( 'import.completed', 'import.failed', 'export.completed', 'export.failed' );
		if ( ! in_array( $event, $enabled_events, true ) ) {
			return;
		}

		$payload = array_merge(
			array(
				'event'   => $event,
				'site'    => site_url(),
				'time'    => current_time( 'mysql' ),
			),
			$data
		);

		wp_remote_post(
			$url,
			array(
				'timeout'   => 10,
				'blocking'  => false, // Fire-and-forget — never blocks the import/export request.
				'headers'   => array( 'Content-Type' => 'application/json' ),
				'body'      => wp_json_encode( $payload ),
			)
		);
	}
}
