<?php
/**
 * AWPM_Meta_Handler
 *
 * Handles arbitrary/unknown WordPress custom meta that isn't covered by
 * the dedicated WooCommerce, ACF or Yoast handlers — so the exporter never
 * silently discards data the user hasn't explicitly excluded.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Meta_Handler {

	/**
	 * Export a product's custom meta, honoring an include/exclude/rename
	 * rule set built from the mapping UI.
	 *
	 * @param int   $post_id
	 * @param array $rules {
	 *     @type string   $mode      'export_all'|'selected'.
	 *     @type string[] $excluded  Meta keys to always skip.
	 *     @type string[] $included  When mode = 'selected', only these keys are exported.
	 *     @type array    $rename_map Source meta_key => export key.
	 * }
	 * @return array export_key => value
	 */
	public static function export_meta( $post_id, $rules = array() ) {
		$mode       = $rules['mode'] ?? 'export_all';
		$excluded   = $rules['excluded'] ?? array();
		$included   = $rules['included'] ?? array();
		$rename_map = $rules['rename_map'] ?? array();

		$known_keys = self::reserved_keys();
		$all_meta   = get_post_meta( $post_id );

		$out = array();
		foreach ( $all_meta as $key => $values ) {
			if ( in_array( $key, $known_keys, true ) ) {
				continue; // Handled by WC core / ACF / Yoast handlers already.
			}
			if ( in_array( $key, $excluded, true ) ) {
				continue;
			}
			if ( 'selected' === $mode && ! in_array( $key, $included, true ) ) {
				continue;
			}

			$export_key = $rename_map[ $key ] ?? $key;
			$value      = count( $values ) > 1 ? $values : maybe_unserialize( $values[0] );
			$out[ $export_key ] = $value;
		}

		return $out;
	}

	/**
	 * Import custom meta back onto a product, applying any transform
	 * callbacks configured in the mapping UI (e.g. strip HTML, cast to int).
	 *
	 * @param int   $post_id
	 * @param array $data export_key => value
	 * @param array $rules { transform_map: export_key => callback name }
	 * @return void
	 */
	public static function import_meta( $post_id, $data, $rules = array() ) {
		$transform_map = $rules['transform_map'] ?? array();

		foreach ( (array) $data as $key => $value ) {
			if ( isset( $transform_map[ $key ] ) ) {
				$value = self::apply_transform( $value, $transform_map[ $key ] );
			}
			update_post_meta( $post_id, sanitize_key( $key ), $value );
		}
	}

	protected static function apply_transform( $value, $transform ) {
		switch ( $transform ) {
			case 'strip_tags':
				return is_string( $value ) ? wp_strip_all_tags( $value ) : $value;
			case 'to_int':
				return (int) $value;
			case 'to_float':
				return (float) $value;
			case 'trim':
				return is_string( $value ) ? trim( $value ) : $value;
			default:
				/**
				 * Allow site-specific custom transforms to be registered.
				 */
				return apply_filters( 'awpm_meta_transform_' . $transform, $value );
		}
	}

	/**
	 * Meta keys already handled by dedicated systems (WooCommerce core,
	 * ACF's own field + "_field" reference rows, Yoast). Anything else is
	 * fair game for the generic custom-meta system.
	 *
	 * @return string[]
	 */
	public static function reserved_keys() {
		static $keys = null;
		if ( null !== $keys ) {
			return $keys;
		}

		$keys = array(
			'_sku', '_regular_price', '_sale_price', '_price', '_stock', '_stock_status',
			'_manage_stock', '_backorders', '_sold_individually', '_weight', '_length',
			'_width', '_height', '_tax_status', '_tax_class', '_downloadable', '_virtual',
			'_featured', '_visibility', '_thumbnail_id', '_product_image_gallery',
			'_upsell_ids', '_crosssell_ids', '_children', '_product_attributes',
			'_default_attributes', '_variation_description', '_edit_lock', '_edit_last',
			'_download_limit', '_download_expiry', '_downloadable_files', '_purchase_note',
			'_sale_price_dates_from', '_sale_price_dates_to', '_product_version',
			'total_sales',
		);

		$keys = array_merge( $keys, array_values( AWPM_Field_Registry::get_yoast_field_map() ) );

		if ( function_exists( 'acf_get_field_groups' ) ) {
			$groups = acf_get_field_groups( array( 'post_type' => 'product' ) );
			foreach ( $groups as $group ) {
				foreach ( (array) acf_get_fields( $group['key'] ) as $field ) {
					$keys[] = $field['name'];
					$keys[] = '_' . $field['name'];
				}
			}
		}

		return $keys = apply_filters( 'awpm_reserved_meta_keys', $keys );
	}
}
