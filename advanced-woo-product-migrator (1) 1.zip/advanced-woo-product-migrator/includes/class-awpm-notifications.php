<?php
/**
 * AWPM_Notifications
 *
 * Actually sends the emails the Settings screen's "Notify on completion" /
 * "Notify on failure" checkboxes promise — these existed as saved options
 * with nothing reading them until this class. Called from the importer,
 * exporter, and scheduler at the exact points a job transitions to
 * completed/failed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Notifications {

	/**
	 * @param string $event 'import_completed'|'import_failed'|'export_completed'|'export_failed'
	 * @param array  $data  Event-specific details merged into the email body.
	 */
	public static function notify( $event, $data = array() ) {
		$settings = get_option( 'awpm_settings', array() );

		$is_failure = false !== strpos( $event, '_failed' );
		$setting_key = $is_failure ? 'notify_on_failure' : 'notify_on_completion';

		if ( empty( $settings[ $setting_key ] ) ) {
			return;
		}

		$recipients = ! empty( $settings['notification_emails'] ) ? array_filter( (array) $settings['notification_emails'] ) : array( get_option( 'admin_email' ) );
		if ( empty( $recipients ) ) {
			return;
		}

		$subject = self::build_subject( $event, $data );
		$body    = self::build_body( $event, $data );

		$sent = wp_mail( $recipients, $subject, $body );

		AWPM_Logger::log(
			$sent ? 'info' : 'error',
			$sent ? sprintf( 'Notification email sent for %s.', $event ) : sprintf( 'Notification email FAILED to send for %s (check your site\'s mail configuration).', $event )
		);
	}

	protected static function build_subject( $event, $data ) {
		$site = wp_parse_url( site_url(), PHP_URL_HOST );

		$map = array(
			'import_completed' => __( 'Import completed', 'advanced-woo-product-migrator' ),
			'import_failed'    => __( 'Import FAILED', 'advanced-woo-product-migrator' ),
			'export_completed' => __( 'Export completed', 'advanced-woo-product-migrator' ),
			'export_failed'    => __( 'Export FAILED', 'advanced-woo-product-migrator' ),
		);

		return sprintf( '[%s] Advanced Product Migrator — %s', $site, $map[ $event ] ?? $event );
	}

	protected static function build_body( $event, $data ) {
		$lines = array();

		$lines[] = sprintf( __( 'Job #%d', 'advanced-woo-product-migrator' ), $data['job_id'] ?? 0 );
		$lines[] = '';

		if ( false !== strpos( $event, 'import' ) ) {
			$lines[] = sprintf( __( 'Created: %d', 'advanced-woo-product-migrator' ), $data['created'] ?? 0 );
			$lines[] = sprintf( __( 'Updated: %d', 'advanced-woo-product-migrator' ), $data['updated'] ?? 0 );
			$lines[] = sprintf( __( 'Skipped: %d', 'advanced-woo-product-migrator' ), $data['skipped'] ?? 0 );
			$lines[] = sprintf( __( 'Failed: %d', 'advanced-woo-product-migrator' ), $data['failed'] ?? 0 );
		} else {
			$lines[] = sprintf( __( 'Products exported: %d', 'advanced-woo-product-migrator' ), $data['products'] ?? 0 );
		}

		if ( ! empty( $data['error'] ) ) {
			$lines[] = '';
			$lines[] = __( 'Error:', 'advanced-woo-product-migrator' ) . ' ' . $data['error'];
		}

		$lines[] = '';
		$lines[] = sprintf( __( 'View details: %s', 'advanced-woo-product-migrator' ), admin_url( 'admin.php?page=awpm-history' ) );

		return implode( "\n", $lines );
	}
}
