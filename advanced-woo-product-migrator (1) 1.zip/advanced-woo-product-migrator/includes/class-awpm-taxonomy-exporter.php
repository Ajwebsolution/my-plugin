<?php
/**
 * AWPM_Taxonomy_Exporter
 *
 * Exports product categories (product_cat, hierarchical) and tags
 * (product_tag, flat) as a standalone, independent dataset — not tied to
 * any one product export. Reuses AWPM_Category_Handler's own
 * export_term_path()/resolve_path() logic (already battle-tested by the
 * Product exporter/importer's category handling) so hierarchy is captured
 * and later rebuilt the same way it already is for products. Mirrors
 * AWPM_Product_Exporter's export()/start_job()/process_next_batch() shape.
 *
 * A term's id is exported/consumed as a composite "taxonomy:term_id"
 * string (e.g. "product_cat:12") rather than a bare int, because
 * WordPress term IDs are only unique per-taxonomy — product_cat and
 * product_tag can (rarely, after a term split) share the same term_id.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Taxonomy_Exporter {

	const TAXONOMIES = array( 'product_cat', 'product_tag' );

	/**
	 * @param array $args {
	 *     @type string $format       csv|xlsx|json
	 *     @type array  $taxonomies   subset of product_cat/product_tag; empty = both
	 *     @type array  $term_ids     composite "taxonomy:id" strings — exact terms to export
	 *     @type string $search       term name/slug search
	 *     @type bool   $include_empty default true — include terms with 0 products
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 */
	public function export( $args ) {
		$args = $this->parse_args( $args );
		$run_id = AWPM_Logger::start_run();

		$term_ids = $this->resolve_term_ids( $args );
		if ( empty( $term_ids ) ) {
			return new WP_Error( 'awpm_no_terms', __( 'No categories or tags matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$records = array();
		foreach ( $term_ids as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$write_true_xlsx = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename        = 'awpm-export-categories-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path       = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = AWPM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = AWPM_XLSX_Handler::write( $records, $file_path );
		} else {
			$ok = AWPM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'awpm_write_failed', __( 'Could not write export file.', 'advanced-woo-product-migrator' ) );
		}

		return array(
			'file_path'     => $file_path,
			'file_url'      => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename,
			'product_count' => count( $records ),
			'run_id'        => $run_id,
		);
	}

	public function start_job( $args ) {
		$args = $this->parse_args( $args );

		$term_ids = $this->resolve_term_ids( $args );
		if ( empty( $term_ids ) ) {
			return new WP_Error( 'awpm_no_terms', __( 'No categories or tags matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = AWPM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'categories',
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_ids' => $term_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $term_ids ),
			)
		);

		$xlsx_ok  = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename = 'awpm-export-categories-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		AWPM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename ) );

		AWPM_Logger::set_run_id( 'awpm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Export job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$ids    = $job['args']['_ids'] ?? array();
		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $ids, $offset, (int) $job['batch_size'] );

		$records = array();
		foreach ( $batch as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		AWPM_Exporter_File_Writer::append( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch ) ) >= count( $ids ), 'categories' );

		AWPM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch ) ) >= count( $ids ) || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'products' => (int) $job['processed_count'] + count( $records ) );
			AWPM_Webhooks::dispatch( 'export.completed', $totals );
			AWPM_Notifications::notify( 'export_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Categories/Tags export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_export_job( $job_id ) );
	}

	protected function parse_args( $args ) {
		return wp_parse_args(
			$args,
			array(
				'format'         => 'json',
				'taxonomies'     => array(),
				'term_ids'       => array(),
				'search'         => '',
				'include_empty'  => true,
				'limit'          => 0,
				'offset'         => 0,
				'batch_size'     => 50,
			)
		);
	}

	protected function resolve_term_ids( $args ) {
		if ( ! empty( $args['term_ids'] ) ) {
			return array_values( (array) $args['term_ids'] );
		}

		$taxonomies = ! empty( $args['taxonomies'] ) ? array_intersect( (array) $args['taxonomies'], self::TAXONOMIES ) : self::TAXONOMIES;

		$ids = array();
		foreach ( $taxonomies as $taxonomy ) {
			$query_args = array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => empty( $args['include_empty'] ),
				'fields'     => 'ids',
			);
			if ( ! empty( $args['search'] ) ) {
				$query_args['search'] = $args['search'];
			}
			$terms = get_terms( $query_args );
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			foreach ( $terms as $term_id ) {
				$ids[] = $taxonomy . ':' . $term_id;
			}
		}

		if ( ! empty( $args['offset'] ) ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	/**
	 * @param string $composite_id "taxonomy:term_id", e.g. "product_cat:12".
	 */
	public function build_record( $composite_id ) {
		list( $taxonomy, $term_id ) = array_pad( explode( ':', (string) $composite_id, 2 ), 2, '' );
		$term_id = (int) $term_id;
		if ( ! $taxonomy || ! $term_id ) {
			return null;
		}

		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return null;
		}

		$path = 'product_cat' === $taxonomy
			? AWPM_Category_Handler::export_term_path( $term_id, $taxonomy )
			: array( array( 'id' => $term->term_id, 'slug' => $term->slug, 'name' => $term->name ) );

		return array(
			'source_site'  => site_url(),
			'term_id'      => $term_id,
			'external_id'  => get_term_meta( $term_id, '_awpm_external_id', true ) ?: ( $taxonomy . ':' . $term_id ),
			'taxonomy'     => $taxonomy,
			'name'         => $term->name,
			'slug'         => $term->slug,
			'description'  => $term->description,
			'path'         => $path,
			'count'        => (int) $term->count,
		);
	}
}
