<?php
/**
 * AWPM_CLI
 *
 * WP-CLI commands, only registered when WP-CLI is actually running
 * (`class_exists( 'WP_CLI' )`). This is the spec's own suggested answer
 * to "very large-catalog imports should be run via WP-CLI or a batched
 * background process rather than the synchronous AJAX importer" — the
 * importer/exporter's start_job()/process_next_batch() pair was written
 * decoupled from the admin/AJAX layer specifically so a CLI command could
 * drive the exact same batch loop the browser's progress bar drives,
 * without a browser tab open, and without PHP's max_execution_time
 * capping a single run (WP-CLI requests aren't subject to that limit the
 * way a web request is).
 *
 * Usage:
 *   wp awpm export --format=json --status=publish
 *   wp awpm export --format=csv --category=clothing,shoes --output=/tmp/out.csv
 *   wp awpm import /path/to/file.json --match=sku --existing=update
 *   wp awpm import /path/to/file.csv --mapping-profile=3 --dry-run
 *   wp awpm rollback 42
 *   wp awpm status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_CLI {

	/**
	 * Export products to a file.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : csv, json, or xlsx. Default: json.
	 *
	 * [--status=<status>]
	 * : Product status filter (publish, draft, pending, private, any). Default: any.
	 *
	 * [--category=<slugs>]
	 * : Comma-separated category slugs to limit to.
	 *
	 * [--tag=<slugs>]
	 * : Comma-separated tag slugs to limit to.
	 *
	 * [--type=<types>]
	 * : Comma-separated product types (simple,variable,grouped,external). Default: all types.
	 *
	 * [--limit=<n>]
	 * : Maximum number of products to export.
	 *
	 * [--offset=<n>]
	 * : Skip the first N matching products.
	 *
	 * [--mapping-profile=<id>]
	 * : Use a saved export profile's field selection.
	 *
	 * [--output=<path>]
	 * : Absolute path to write the file to. Defaults to the plugin's tmp folder.
	 *
	 * [--batch-size=<n>]
	 * : Rows processed per batch iteration. Default: 200 (CLI can afford larger batches than the browser AJAX loop).
	 *
	 * @when after_wp_load
	 */
	public function export( $args, $assoc_args ) {
		$field_config = array();
		if ( ! empty( $assoc_args['mapping-profile'] ) ) {
			$profile = AWPM_Mappings::get( (int) $assoc_args['mapping-profile'] );
			if ( $profile && ! empty( $profile['config']['field_config'] ) ) {
				$field_config = $profile['config']['field_config'];
			}
		}

		$exporter = new AWPM_Product_Exporter();
		$job_id   = $exporter->start_job(
			array(
				'format'     => $assoc_args['format'] ?? 'json',
				'selection'  => 'all',
				'status'     => $assoc_args['status'] ?? 'any',
				'categories' => ! empty( $assoc_args['category'] ) ? array_map( 'trim', explode( ',', $assoc_args['category'] ) ) : array(),
				'tags'       => ! empty( $assoc_args['tag'] ) ? array_map( 'trim', explode( ',', $assoc_args['tag'] ) ) : array(),
				'types'      => ! empty( $assoc_args['type'] ) ? array_map( 'trim', explode( ',', $assoc_args['type'] ) ) : array(),
				'limit'      => (int) ( $assoc_args['limit'] ?? 0 ),
				'offset'     => (int) ( $assoc_args['offset'] ?? 0 ),
				'batch_size' => (int) ( $assoc_args['batch-size'] ?? 200 ),
				'field_config' => $field_config,
			)
		);

		if ( is_wp_error( $job_id ) ) {
			WP_CLI::error( $job_id->get_error_message() );
		}

		WP_CLI::log( sprintf( 'Export job #%d started.', $job_id ) );

		$progress = WP_CLI\Utils\make_progress_bar( 'Exporting', 100 ); // phpcs:ignore
		$last_pct = 0;

		do {
			$result = $exporter->process_next_batch( $job_id );
			if ( is_wp_error( $result ) ) {
				$progress->finish();
				WP_CLI::error( $result->get_error_message() );
			}
			$job = $result['job'];
			$pct = $job['total_rows'] > 0 ? (int) round( ( $job['offset_row'] / $job['total_rows'] ) * 100 ) : 100;
			$progress->tick( max( 0, $pct - $last_pct ) );
			$last_pct = $pct;
		} while ( ! $result['done'] );

		$progress->finish();

		if ( ! empty( $assoc_args['output'] ) ) {
			copy( $job['file_path'], $assoc_args['output'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			WP_CLI::success( sprintf( '%d product(s) exported to %s', $job['processed_count'], $assoc_args['output'] ) );
		} else {
			WP_CLI::success( sprintf( '%d product(s) exported to %s', $job['processed_count'], $job['file_path'] ) );
		}
	}

	/**
	 * Import products from a file.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : Path to the .csv or .json file to import.
	 *
	 * [--format=<format>]
	 * : csv or json. Auto-detected from the file extension if omitted.
	 *
	 * [--match=<strategy>]
	 * : sku, product_id, slug, external_id, or none. Default: sku.
	 *
	 * [--existing=<action>]
	 * : update, skip, or duplicate. Default: update.
	 *
	 * [--mapping-profile=<id>]
	 * : Use a saved import profile's column mapping/transforms/options.
	 *
	 * [--image-strategy=<strategy>]
	 * : attachment_id, url, filename, sku_filename, or url_filename_fallback. Default: url_filename_fallback.
	 *
	 * [--create-missing-attributes]
	 * : Create missing global attributes automatically.
	 *
	 * [--create-missing-categories]
	 * : Create missing categories automatically.
	 *
	 * [--backup]
	 * : Snapshot each updated product first, so the job can be rolled back later.
	 *
	 * [--batch-size=<n>]
	 * : Rows processed per batch iteration. Default: 200.
	 *
	 * [--dry-run]
	 * : Report what would happen without writing anything.
	 *
	 * @when after_wp_load
	 */
	public function import( $args, $assoc_args ) {
		$file_path = $args[0];
		if ( ! file_exists( $file_path ) ) {
			WP_CLI::error( sprintf( 'File not found: %s', $file_path ) );
		}

		$format = $assoc_args['format'] ?? strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		if ( ! in_array( $format, array( 'csv', 'json' ), true ) ) {
			WP_CLI::error( 'Format must be csv or json (or use a .csv/.json file so it can be auto-detected).' );
		}

		// CLI reads the file directly, rather than going through the
		// browser-upload path — copy it into the plugin's own tmp folder so
		// the rest of the pipeline (which always works from there) applies
		// unchanged.
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );
		$working_copy = trailingslashit( $tmp_dir ) . 'awpm-cli-import-' . wp_generate_password( 8, false ) . '.' . $format;
		copy( $file_path, $working_copy ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$mapping = array();
		$transforms = array();
		$options = array(
			'image_match_strategy' => $assoc_args['image-strategy'] ?? 'url_filename_fallback',
			'create_missing_global_attributes' => isset( $assoc_args['create-missing-attributes'] ),
			'create_missing_categories' => isset( $assoc_args['create-missing-categories'] ),
			'create_backup' => isset( $assoc_args['backup'] ),
		);

		if ( ! empty( $assoc_args['mapping-profile'] ) ) {
			$profile = AWPM_Mappings::get( (int) $assoc_args['mapping-profile'] );
			if ( $profile ) {
				$mapping    = $profile['config']['mapping'] ?? array();
				$transforms = $profile['config']['transforms'] ?? array();
				$options    = array_merge( $options, $profile['config']['options'] ?? array() );
			} else {
				WP_CLI::warning( sprintf( 'Mapping profile #%d not found — continuing without it.', $assoc_args['mapping-profile'] ) );
			}
		}

		$importer = new AWPM_Product_Importer();
		$job_id   = $importer->start_job(
			array(
				'file_path'       => $working_copy,
				'format'          => $format,
				'mapping'         => $mapping,
				'transforms'      => $transforms,
				'match_strategy'  => $assoc_args['match'] ?? 'sku',
				'existing_action' => $assoc_args['existing'] ?? 'update',
				'options'         => $options,
				'batch_size'      => (int) ( $assoc_args['batch-size'] ?? 200 ),
				'dry_run'         => isset( $assoc_args['dry-run'] ),
			)
		);

		if ( is_wp_error( $job_id ) ) {
			WP_CLI::error( $job_id->get_error_message() );
		}

		WP_CLI::log( sprintf( '%sImport job #%d started.', isset( $assoc_args['dry-run'] ) ? '[DRY RUN] ' : '', $job_id ) );

		$job      = $importer->process_next_batch( $job_id );
		$total    = is_wp_error( $job ) ? 0 : ( $job['job']['total_rows'] ?? 0 );
		$progress = WP_CLI\Utils\make_progress_bar( 'Importing', 100 ); // phpcs:ignore
		$last_pct = 0;
		$result   = null;

		do {
			$result = $importer->process_next_batch( $job_id );
			if ( is_wp_error( $result ) ) {
				$progress->finish();
				WP_CLI::error( $result->get_error_message() );
			}
			$job_row = $result['job'];
			$pct     = $job_row['total_rows'] > 0 ? (int) round( ( $job_row['offset_row'] / $job_row['total_rows'] ) * 100 ) : 100;
			$progress->tick( max( 0, $pct - $last_pct ) );
			$last_pct = $pct;
		} while ( ! $result['done'] );

		$progress->finish();
		$job_row = $result['job'];

		WP_CLI::success(
			sprintf(
				'Job #%d complete — Created: %d, Updated: %d, Skipped: %d, Failed: %d.',
				$job_id, $job_row['created_count'], $job_row['updated_count'], $job_row['skipped_count'], $job_row['failed_count']
			)
		);
	}

	/**
	 * Roll back a completed import job (restores updated products from
	 * their pre-import snapshot; trashes products the job created). Only
	 * works if the job was run with `--backup` / "Create backup before
	 * update" enabled — otherwise there's nothing to restore from.
	 *
	 * ## OPTIONS
	 *
	 * <job_id>
	 * : The import job ID to roll back (see `wp awpm history` or the History screen).
	 *
	 * @when after_wp_load
	 */
	public function rollback( $args ) {
		$job_id = (int) $args[0];
		$job    = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			WP_CLI::error( sprintf( 'Import job #%d not found.', $job_id ) );
		}

		$summary = AWPM_Snapshot::rollback_job( $job_id );
		WP_CLI::success( sprintf( 'Rollback complete — %d product(s) restored, %d product(s) trashed.', $summary['restored'], $summary['trashed'] ) );
		if ( ! empty( $summary['errors'] ) ) {
			foreach ( $summary['errors'] as $error ) {
				WP_CLI::warning( $error );
			}
		}
	}

	/**
	 * List recent import/export jobs.
	 *
	 * ## OPTIONS
	 *
	 * [--type=<type>]
	 * : import or export. Default: import.
	 *
	 * [--limit=<n>]
	 * : Default: 20.
	 *
	 * @when after_wp_load
	 */
	public function history( $args, $assoc_args ) {
		$type  = $assoc_args['type'] ?? 'import';
		$limit = (int) ( $assoc_args['limit'] ?? 20 );

		$jobs = 'export' === $type ? AWPM_Jobs::list_export_jobs( $limit ) : AWPM_Jobs::list_import_jobs( $limit );

		if ( 'export' === $type ) {
			WP_CLI\Utils\format_items( 'table', $jobs, array( 'id', 'status', 'format', 'processed_count', 'created_at' ) ); // phpcs:ignore
		} else {
			WP_CLI\Utils\format_items( 'table', $jobs, array( 'id', 'status', 'created_count', 'updated_count', 'skipped_count', 'failed_count', 'created_at' ) ); // phpcs:ignore
		}
	}

	/**
	 * Print the plugin's system status report (same as Settings -> System Status -> Copy Report).
	 *
	 * @when after_wp_load
	 */
	public function status() {
		WP_CLI::log( AWPM_System_Status::as_text() );
	}
}

if ( class_exists( 'WP_CLI' ) ) {
	WP_CLI::add_command( 'awpm', 'AWPM_CLI' );
}
