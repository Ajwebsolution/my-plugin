<?php
/**
 * AWPM_Rest_Api
 *
 * Real, authenticated REST endpoints (WordPress cookie+nonce auth for
 * logged-in admin users, or Application Passwords for external systems —
 * both handled natively by WP core's REST auth, so nothing custom to get
 * wrong here). Every route requires the `manage_awpm` capability. No
 * product data field is exposed beyond what the equivalent Export screen
 * would output for a similarly-privileged user.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Rest_Api {

	const NAMESPACE_ = 'awpm/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_,
			'/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'start_import' ),
				'permission_callback' => array( __CLASS__, 'permission_check' ),
				'args'                => array(
					'file_url'        => array( 'required' => false, 'type' => 'string' ),
					'format'          => array( 'required' => false, 'type' => 'string', 'default' => 'json' ),
					'mapping_profile_id' => array( 'required' => false, 'type' => 'integer' ),
					'dry_run'         => array( 'required' => false, 'type' => 'boolean', 'default' => false ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'start_export' ),
				'permission_callback' => array( __CLASS__, 'permission_check' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/jobs',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'list_jobs' ),
				'permission_callback' => array( __CLASS__, 'permission_check' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/jobs/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_job' ),
				'permission_callback' => array( __CLASS__, 'permission_check' ),
				'args'                => array(
					'type' => array( 'required' => false, 'type' => 'string', 'default' => 'import', 'enum' => array( 'import', 'export' ) ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'list_products' ),
				'permission_callback' => array( __CLASS__, 'permission_check' ),
			)
		);
	}

	public static function permission_check( $request ) {
		return current_user_can( 'manage_awpm' ) || current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Start an import from a remote file URL (SSRF-validated) using either
	 * an explicit mapping or a saved mapping profile. Returns a job ID the
	 * caller can then poll via GET /jobs/{id}?type=import and continue via
	 * repeated POSTs — REST doesn't auto-process batches server-side to
	 * avoid a single REST request timing out on a large file; the caller
	 * (or the internal WP-Cron safety net) advances it.
	 */
	public static function start_import( WP_REST_Request $request ) {
		$file_url = $request->get_param( 'file_url' );
		if ( ! $file_url ) {
			return new WP_Error( 'awpm_missing_file_url', __( 'file_url is required.', 'advanced-woo-product-migrator' ), array( 'status' => 400 ) );
		}

		$fetched = AWPM_Remote_Fetcher::fetch( $file_url );
		if ( is_wp_error( $fetched ) ) {
			return $fetched;
		}

		$profile_id = $request->get_param( 'mapping_profile_id' );
		$config     = $profile_id ? ( AWPM_Mappings::get( $profile_id )['config'] ?? array() ) : array();

		$importer = new AWPM_Product_Importer();
		$job_id   = $importer->start_job(
			array(
				'file_path'       => $fetched['file_path'],
				'format'          => $fetched['format'],
				'mapping'         => $config['mapping'] ?? array(),
				'match_strategy'  => $config['match_strategy'] ?? 'sku',
				'existing_action' => $config['existing_action'] ?? 'update',
				'options'         => $config['options'] ?? array(),
				'dry_run'         => (bool) $request->get_param( 'dry_run' ),
				'mapping_profile_id' => $profile_id,
			)
		);

		if ( is_wp_error( $job_id ) ) {
			return $job_id;
		}

		return rest_ensure_response( array( 'job_id' => $job_id, 'status' => 'pending' ) );
	}

	public static function start_export( WP_REST_Request $request ) {
		$exporter = new AWPM_Product_Exporter();
		$args     = $request->get_json_params() ?: array();
		$job_id   = $exporter->start_job( $args );

		if ( is_wp_error( $job_id ) ) {
			return $job_id;
		}

		return rest_ensure_response( array( 'job_id' => $job_id, 'status' => 'pending' ) );
	}

	public static function list_jobs( WP_REST_Request $request ) {
		return rest_ensure_response(
			array(
				'import' => AWPM_Jobs::list_import_jobs( 20 ),
				'export' => AWPM_Jobs::list_export_jobs( 20 ),
			)
		);
	}

	public static function get_job( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$type = $request->get_param( 'type' );

		$job = 'export' === $type ? AWPM_Jobs::get_export_job( $id ) : AWPM_Jobs::get_import_job( $id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Job not found.', 'advanced-woo-product-migrator' ), array( 'status' => 404 ) );
		}

		return rest_ensure_response( $job );
	}

	/**
	 * A thin, read-only product listing — intentionally only exposes the
	 * same public-ish fields WooCommerce's own REST API would, never raw
	 * private meta, per spec #46's "Never expose private product metadata
	 * publicly."
	 */
	public static function list_products( WP_REST_Request $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, (int) $request->get_param( 'per_page' ) ?: 20 );

		$ids = wc_get_products( array( 'limit' => $per_page, 'page' => $page, 'return' => 'ids' ) );

		$out = array();
		foreach ( $ids as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) {
				continue;
			}
			$out[] = array(
				'id'    => $id,
				'name'  => $p->get_name(),
				'sku'   => $p->get_sku(),
				'type'  => $p->get_type(),
				'price' => $p->get_price(),
				'status'=> $p->get_status(),
			);
		}

		return rest_ensure_response( $out );
	}
}
