<?php
/**
 * AWPM_Snapshot
 *
 * Real rollback support: before an existing product is updated, its full
 * WooCommerce CRUD data array (get_data(), including meta_data) is
 * serialized into wp_awpm_snapshots keyed to the import job. Rolling back
 * a job restores every "update" snapshot via WC_Product::set_props() +
 * save() (never deletes production data), and safely trash-deletes
 * products that were newly "created" by that job. This is exactly what
 * the spec requires: "For updated products: restore snapshot rather than
 * deleting product. Do NOT blindly delete existing production data."
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Snapshot {

	/**
	 * Snapshot a product's current state before it gets overwritten by an
	 * update. No-op (and returns false) for a brand-new product, since
	 * there's nothing to roll back to but deletion — which the importer
	 * tracks separately via the import_items 'created' record.
	 *
	 * @param int $job_id
	 * @param int $product_id
	 * @return bool
	 */
	public static function capture( $job_id, $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return false;
		}

		global $wpdb;

		$data = $product->get_data();
		// get_data() on variable products doesn't include variation objects;
		// snapshotting the parent's own props is sufficient because the
		// importer's own write_variations() re-matches existing variations
		// by SKU/ID rather than deleting-and-recreating, so a parent-level
		// rollback plus WooCommerce's own variation data (never touched by
		// AWPM_Snapshot) is enough to restore parent-level fields.
		$data['meta_data'] = array_map(
			function ( $m ) {
				return array( 'key' => $m->key, 'value' => $m->value );
			},
			$product->get_meta_data()
		);

		$settings = get_option( 'awpm_settings', array() );
		$days     = ! empty( $settings['snapshot_retention_days'] ) ? (int) $settings['snapshot_retention_days'] : 14;

		$wpdb->insert(
			$wpdb->prefix . 'awpm_snapshots',
			array(
				'job_id'     => $job_id,
				'product_id' => $product_id,
				'action'     => 'update',
				'snapshot'   => wp_json_encode( $data ),
				'created_at' => current_time( 'mysql' ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $days * DAY_IN_SECONDS ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s' )
		);

		return true;
	}

	/**
	 * Record that a product was newly created by this job (so rollback
	 * knows it's safe to remove, unlike an "update" snapshot).
	 */
	public static function record_created( $job_id, $product_id ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'awpm_snapshots',
			array(
				'job_id'     => $job_id,
				'product_id' => $product_id,
				'action'     => 'create',
				'snapshot'   => wp_json_encode( array() ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s' )
		);
	}

	/**
	 * Roll back every snapshot recorded for a job: restore "update"
	 * snapshots, trash "create" snapshots. Returns a summary.
	 *
	 * @param int $job_id
	 * @return array { restored, trashed, errors }
	 */
	public static function rollback_job( $job_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}awpm_snapshots WHERE job_id = %d ORDER BY id ASC", $job_id ), ARRAY_A );

		$summary = array( 'restored' => 0, 'trashed' => 0, 'errors' => array() );

		foreach ( $rows as $row ) {
			try {
				if ( 'create' === $row['action'] ) {
					$product = wc_get_product( $row['product_id'] );
					if ( $product ) {
						$product->delete( false ); // Trash, not force-delete — recoverable, never a hard destroy.
						$summary['trashed']++;
					}
				} else {
					$data = json_decode( $row['snapshot'], true );
					if ( ! is_array( $data ) ) {
						continue;
					}
					$product = wc_get_product( $row['product_id'] );
					if ( ! $product ) {
						continue;
					}
					unset( $data['id'], $data['date_modified'], $data['date_created'] );
					$meta_data = $data['meta_data'] ?? array();
					unset( $data['meta_data'] );

					$product->set_props( $data );
					foreach ( $meta_data as $m ) {
						$product->update_meta_data( $m['key'], $m['value'] );
					}
					$product->save();
					$summary['restored']++;
				}
			} catch ( Exception $e ) {
				$summary['errors'][] = sprintf( 'Product #%d: %s', $row['product_id'], $e->getMessage() );
			}
		}

		AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'rolled_back' ) );
		AWPM_Logger::log( 'info', sprintf( 'Rollback of job #%d: %d restored, %d trashed', $job_id, $summary['restored'], $summary['trashed'] ) );

		return $summary;
	}

	/**
	 * Purge expired snapshots. Hooked to a daily cron event — "Do not
	 * create unlimited snapshots."
	 */
	public static function prune_expired() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->prefix}awpm_snapshots WHERE expires_at IS NOT NULL AND expires_at < NOW()" ); // phpcs:ignore
	}
}
