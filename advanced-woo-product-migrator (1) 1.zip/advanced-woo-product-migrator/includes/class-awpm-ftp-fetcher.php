<?php
/**
 * AWPM_Ftp_Fetcher
 *
 * A genuine FTP/FTPS import source using PHP's built-in `ftp` extension —
 * no external library. Plain FTP (ftp_connect) and explicit FTPS
 * (ftp_ssl_connect, TLS-encrypted control+data channel) are both native to
 * PHP and involve no hand-rolled cryptography, unlike SFTP (SSH-based),
 * which genuinely needs a real crypto implementation (phpseclib or the
 * rare ssh2 PECL extension) — that's why SFTP is still a documented
 * extension point rather than something built here: hand-writing SSH
 * key exchange/cipher code would be a real security liability, whereas
 * wrapping PHP's own FTP calls is not.
 *
 * Credentials are never logged — every AWPM_Logger call in this class
 * passes only host/path, never $username or $password.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Ftp_Fetcher {

	const TIMEOUT = 30;

	public static function is_available() {
		return function_exists( 'ftp_connect' );
	}

	/**
	 * @param array $config {
	 *     @type string $host
	 *     @type int    $port     Default 21.
	 *     @type string $username
	 *     @type string $password
	 *     @type string $path      Remote file path.
	 *     @type bool   $use_ssl   Use explicit FTPS (ftp_ssl_connect) instead of plain FTP.
	 *     @type bool   $passive   Passive mode (default true — works through more firewalls/NAT).
	 * }
	 * @return array{file_path:string, format:string}|WP_Error
	 */
	public static function fetch( $config ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'awpm_ftp_unavailable', __( 'The PHP FTP extension is not available on this server.', 'advanced-woo-product-migrator' ) );
		}

		$host = trim( $config['host'] ?? '' );
		$path = trim( $config['path'] ?? '' );
		if ( ! $host || ! $path ) {
			return new WP_Error( 'awpm_ftp_missing_config', __( 'FTP host and remote file path are required.', 'advanced-woo-product-migrator' ) );
		}

		$port = ! empty( $config['port'] ) ? (int) $config['port'] : 21;
		$use_ssl = ! empty( $config['use_ssl'] );

		$conn = $use_ssl
			? @ftp_ssl_connect( $host, $port, self::TIMEOUT ) // phpcs:ignore WordPress.PHP.NoSilencedErrors
			: @ftp_connect( $host, $port, self::TIMEOUT ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		if ( ! $conn ) {
			AWPM_Logger::log( 'error', sprintf( 'FTP connection to %s:%d failed.', $host, $port ) );
			return new WP_Error( 'awpm_ftp_connect_failed', sprintf( __( 'Could not connect to FTP host %1$s:%2$d.', 'advanced-woo-product-migrator' ), $host, $port ) );
		}

		$login_ok = @ftp_login( $conn, $config['username'] ?? '', $config['password'] ?? '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $login_ok ) {
			ftp_close( $conn );
			AWPM_Logger::log( 'error', sprintf( 'FTP login to %s failed (check username/password).', $host ) );
			return new WP_Error( 'awpm_ftp_login_failed', __( 'FTP login failed — check the username and password.', 'advanced-woo-product-migrator' ) );
		}

		ftp_pasv( $conn, $config['passive'] ?? true );

		$ext        = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$format     = in_array( $ext, array( 'csv', 'json', 'xlsx' ), true ) ? $ext : 'csv';
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );
		$dest = trailingslashit( $tmp_dir ) . 'awpm-ftp-' . wp_generate_password( 8, false ) . '.' . $format;

		$downloaded = @ftp_get( $conn, $dest, $path, FTP_BINARY ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		ftp_close( $conn );

		if ( ! $downloaded || ! file_exists( $dest ) ) {
			AWPM_Logger::log( 'error', sprintf( 'FTP download of %s from %s failed.', $path, $host ) );
			return new WP_Error( 'awpm_ftp_download_failed', sprintf( __( 'Could not download %s from the FTP server — check the remote path.', 'advanced-woo-product-migrator' ), $path ) );
		}

		AWPM_Logger::log( 'info', sprintf( 'Fetched file via FTP from %s (%s, %d bytes).', $host, $format, filesize( $dest ) ) );

		return array( 'file_path' => $dest, 'format' => $format );
	}
}
