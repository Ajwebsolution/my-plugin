<?php
/**
 * AWPM_Remote_Fetcher
 *
 * Downloads a remote CSV/JSON/XLSX for import with real SSRF protections:
 * scheme allow-list, DNS resolution + private/loopback/link-local IP block
 * (checked before AND after any redirect, since a first-hop public host
 * can still redirect to an internal address), redirect count limit, byte
 * size limit, and a hard timeout. This is the actual implementation behind
 * "Remote URL Import" — not a bare wp_remote_get() call.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Remote_Fetcher {

	const MAX_REDIRECTS = 3;
	const TIMEOUT        = 30;
	const MAX_BYTES      = 200 * 1024 * 1024; // 200MB ceiling for a remote import file.

	/**
	 * @param string $url
	 * @return array{file_path:string, format:string}|WP_Error
	 */
	public static function fetch( $url ) {
		$check = self::validate_url( $url );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$current_url = $url;
		for ( $hop = 0; $hop <= self::MAX_REDIRECTS; $hop++ ) {
			$response = wp_remote_get(
				$current_url,
				array(
					'timeout'     => self::TIMEOUT,
					'redirection' => 0, // We follow redirects manually so each hop is re-validated against SSRF rules.
					'headers'     => array( 'User-Agent' => 'AdvancedWooProductMigrator/1.0' ),
				)
			);

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$code = wp_remote_retrieve_response_code( $response );

			if ( in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
				$location = wp_remote_retrieve_header( $response, 'location' );
				if ( ! $location ) {
					return new WP_Error( 'awpm_redirect_no_location', __( 'Redirect response had no Location header.', 'advanced-woo-product-migrator' ) );
				}
				$location_check = self::validate_url( $location );
				if ( is_wp_error( $location_check ) ) {
					return $location_check;
				}
				$current_url = $location;
				continue;
			}

			if ( $code < 200 || $code >= 300 ) {
				return new WP_Error( 'awpm_remote_fetch_failed', sprintf( __( 'Remote file returned HTTP %d.', 'advanced-woo-product-migrator' ), $code ) );
			}

			$body = wp_remote_retrieve_body( $response );
			if ( strlen( $body ) > self::MAX_BYTES ) {
				return new WP_Error( 'awpm_remote_file_too_large', __( 'Remote file exceeds the maximum allowed size.', 'advanced-woo-product-migrator' ) );
			}

			$format = self::detect_format( $current_url, wp_remote_retrieve_header( $response, 'content-type' ), $body );

			$upload_dir = wp_upload_dir();
			$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
			wp_mkdir_p( $tmp_dir );
			$dest = trailingslashit( $tmp_dir ) . 'awpm-remote-' . wp_generate_password( 8, false ) . '.' . $format;

			if ( false === file_put_contents( $dest, $body ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
				return new WP_Error( 'awpm_remote_write_failed', __( 'Could not save the downloaded file.', 'advanced-woo-product-migrator' ) );
			}

			AWPM_Logger::log( 'info', sprintf( 'Fetched remote import file (%s, %d bytes)', $format, strlen( $body ) ) );

			return array( 'file_path' => $dest, 'format' => $format );
		}

		return new WP_Error( 'awpm_too_many_redirects', __( 'Too many redirects while fetching the remote file.', 'advanced-woo-product-migrator' ) );
	}

	/**
	 * Validate scheme + resolve the host to an IP and reject anything
	 * private/loopback/link-local/reserved — the core SSRF defense.
	 *
	 * @param string $url
	 * @return true|WP_Error
	 */
	public static function validate_url( $url ) {
		$parts = wp_parse_url( $url );
		if ( empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return new WP_Error( 'awpm_invalid_scheme', __( 'Only http/https URLs are allowed.', 'advanced-woo-product-migrator' ) );
		}
		if ( empty( $parts['host'] ) ) {
			return new WP_Error( 'awpm_invalid_url', __( 'Invalid URL.', 'advanced-woo-product-migrator' ) );
		}

		$host = $parts['host'];

		// Block obvious localhost/metadata hostnames outright.
		$blocked_hosts = array( 'localhost', '127.0.0.1', '::1', '0.0.0.0', 'metadata.google.internal' );
		if ( in_array( strtolower( $host ), $blocked_hosts, true ) ) {
			return new WP_Error( 'awpm_blocked_host', __( 'This host is not allowed.', 'advanced-woo-product-migrator' ) );
		}

		$ip = filter_var( $host, FILTER_VALIDATE_IP ) ? $host : gethostbyname( $host );
		if ( ! $ip || $ip === $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return new WP_Error( 'awpm_dns_failed', __( 'Could not resolve host.', 'advanced-woo-product-migrator' ) );
		}

		if ( self::is_private_ip( $ip ) ) {
			return new WP_Error( 'awpm_ssrf_blocked', __( 'Requests to private/internal network addresses are not allowed.', 'advanced-woo-product-migrator' ) );
		}

		return true;
	}

	protected static function is_private_ip( $ip ) {
		// filter_var with these flags returns false for private/reserved ranges — i.e. NOT a "public" IP.
		return false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}

	protected static function detect_format( $url, $content_type, $body ) {
		$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'csv', 'json', 'xlsx' ), true ) ) {
			return $ext;
		}
		if ( $content_type && false !== strpos( $content_type, 'json' ) ) {
			return 'json';
		}
		$trimmed = ltrim( $body );
		if ( isset( $trimmed[0] ) && ( '{' === $trimmed[0] || '[' === $trimmed[0] ) ) {
			return 'json';
		}
		return 'csv';
	}
}
