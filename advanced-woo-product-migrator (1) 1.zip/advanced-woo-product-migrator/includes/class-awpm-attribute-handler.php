<?php
/**
 * AWPM_Attribute_Handler
 *
 * Handles both global attributes (pa_color, stored as a real taxonomy with
 * terms, shared across products) and local/custom product attributes
 * (stored as free-text values on the product itself). Detects which kind
 * an exported attribute is, and — if it's global and missing on the
 * destination site — can create the taxonomy, register it with
 * WooCommerce, and create its terms before assigning it to the product.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Attribute_Handler {

	/**
	 * Export every attribute on a (possibly variable) product into a
	 * portable structure.
	 *
	 * @param WC_Product $product
	 * @return array[]
	 */
	public static function export_attributes( $product ) {
		$out = array();

		foreach ( $product->get_attributes() as $attribute ) {
			/** @var WC_Product_Attribute $attribute */
			$is_taxonomy = $attribute->is_taxonomy();

			$entry = array(
				'name'            => $is_taxonomy ? $attribute->get_name() : $attribute->get_name(), // pa_color OR "Material"
				'label'           => $is_taxonomy ? wc_attribute_label( $attribute->get_name() ) : $attribute->get_name(),
				'is_global'       => $is_taxonomy,
				'position'        => $attribute->get_position(),
				'visible'         => $attribute->get_visible(),
				'variation'       => $attribute->get_variation(),
				'values'          => array(),
			);

			if ( $is_taxonomy ) {
				$terms = $attribute->get_terms();
				foreach ( (array) $terms as $term ) {
					$entry['values'][] = array( 'slug' => $term->slug, 'name' => $term->name );
				}
			} else {
				foreach ( $attribute->get_options() as $option ) {
					$entry['values'][] = array( 'slug' => sanitize_title( $option ), 'name' => $option );
				}
			}

			$out[] = $entry;
		}

		return $out;
	}

	/**
	 * Import a full attribute set onto a product object (does not save —
	 * caller is responsible for $product->save()).
	 *
	 * @param WC_Product $product
	 * @param array      $attributes_data Exported structure from export_attributes().
	 * @param array      $options { create_missing_global_attributes: bool }
	 * @return WC_Product_Attribute[] Keyed the same way WC expects for set_attributes().
	 */
	public static function import_attributes( $product, $attributes_data, $options = array() ) {
		$create_missing = ! empty( $options['create_missing_global_attributes'] );
		$attributes     = array();

		foreach ( (array) $attributes_data as $attr ) {
			$wc_attribute = new WC_Product_Attribute();

			if ( ! empty( $attr['is_global'] ) ) {
				$taxonomy = self::ensure_global_attribute_exists( $attr['name'], $attr['label'] ?? $attr['name'], $create_missing );
				if ( ! $taxonomy ) {
					continue; // Global attribute doesn't exist and we're not allowed to create it — skip.
				}

				$term_ids = self::ensure_terms_exist( $taxonomy, $attr['values'], $create_missing );

				$wc_attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
				$wc_attribute->set_name( $taxonomy );
				$wc_attribute->set_options( $term_ids );
			} else {
				$wc_attribute->set_id( 0 );
				$wc_attribute->set_name( $attr['name'] );
				$wc_attribute->set_options( wp_list_pluck( $attr['values'], 'name' ) );
			}

			$wc_attribute->set_position( $attr['position'] ?? 0 );
			$wc_attribute->set_visible( ! empty( $attr['visible'] ) );
			$wc_attribute->set_variation( ! empty( $attr['variation'] ) );

			$attributes[] = $wc_attribute;
		}

		return $attributes;
	}

	/**
	 * Make sure a global attribute taxonomy (e.g. pa_color) exists;
	 * create it via WooCommerce's own attribute table if missing and
	 * allowed to.
	 *
	 * @param string $raw_name Either "pa_color" or a plain label like "Color".
	 * @param string $label
	 * @param bool   $create_missing
	 * @return string|null Taxonomy name (e.g. "pa_color") or null.
	 */
	public static function ensure_global_attribute_exists( $raw_name, $label, $create_missing ) {
		$slug = str_replace( 'pa_', '', wc_sanitize_taxonomy_name( $raw_name ) );
		$taxonomy = wc_attribute_taxonomy_name( $slug );

		if ( taxonomy_exists( $taxonomy ) ) {
			return $taxonomy;
		}

		if ( ! $create_missing ) {
			return null;
		}

		$attribute_id = wc_create_attribute(
			array(
				'name'         => $label,
				'slug'         => $slug,
				'type'         => 'select',
				'order_by'     => 'menu_order',
				'has_archives' => false,
			)
		);

		if ( is_wp_error( $attribute_id ) ) {
			AWPM_Logger::log( 'error', 'Failed creating global attribute ' . $label . ': ' . $attribute_id->get_error_message() );
			return null;
		}

		// WooCommerce needs the taxonomy actually registered in this request
		// before we can insert terms into it.
		delete_transient( 'wc_attribute_taxonomies' );
		$taxonomy = wc_attribute_taxonomy_name( $slug );
		register_taxonomy(
			$taxonomy,
			apply_filters( 'woocommerce_taxonomy_objects_' . $taxonomy, array( 'product' ) ),
			apply_filters( 'woocommerce_taxonomy_args_' . $taxonomy, array( 'hierarchical' => false, 'show_ui' => false, 'query_var' => true, 'rewrite' => false ) )
		);

		return $taxonomy;
	}

	/**
	 * Make sure the given terms exist under a global attribute taxonomy;
	 * create missing ones if allowed. Returns term slugs, which is the
	 * format WC_Product_Attribute::set_options() expects for taxonomy
	 * attributes.
	 *
	 * @param string $taxonomy
	 * @param array  $values [{slug,name}, ...]
	 * @param bool   $create_missing
	 * @return string[]
	 */
	public static function ensure_terms_exist( $taxonomy, $values, $create_missing ) {
		$slugs = array();
		foreach ( (array) $values as $value ) {
			$term = get_term_by( 'slug', $value['slug'], $taxonomy );
			if ( ! $term && $create_missing ) {
				$inserted = wp_insert_term( $value['name'], $taxonomy, array( 'slug' => $value['slug'] ) );
				if ( ! is_wp_error( $inserted ) ) {
					$term = get_term( $inserted['term_id'], $taxonomy );
				}
			}
			if ( $term && ! is_wp_error( $term ) ) {
				$slugs[] = $term->slug;
			}
		}
		return $slugs;
	}

	/**
	 * Export a variation's attribute selections (attribute name => selected
	 * value slug/text) in a portable form.
	 *
	 * @param WC_Product_Variation $variation
	 * @return array
	 */
	public static function export_variation_attributes( $variation ) {
		$out = array();
		foreach ( $variation->get_variation_attributes( false ) as $key => $value ) {
			// $key looks like "attribute_pa_color" or "attribute_material".
			$attribute_name = str_replace( 'attribute_', '', $key );
			$out[ $attribute_name ] = $value; // term slug for taxonomy attrs, raw text for custom attrs.
		}
		return $out;
	}

	/**
	 * Convert exported variation attributes into the array
	 * WC_Product_Variation::set_attributes() expects (unprefixed keys,
	 * lowercase attribute names, term slugs for taxonomy attributes).
	 *
	 * @param array $exported
	 * @return array
	 */
	public static function import_variation_attributes( $exported ) {
		$out = array();
		foreach ( (array) $exported as $name => $value ) {
			$out[ sanitize_title( $name ) ] = taxonomy_exists( $name ) ? sanitize_title( $value ) : $value;
		}
		return $out;
	}
}
