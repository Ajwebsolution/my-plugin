<?php
/**
 * AWPM_Customer_Exporter
 *
 * Exports WordPress users who are WooCommerce customers (any role, by
 * default filtered to the "customer" role to exclude shop staff/admins —
 * configurable via $args['roles']) together with their WooCommerce billing
 * and shipping address meta, as structured, portable records. Mirrors
 * AWPM_Product_Exporter's export()/start_job()/process_next_batch() shape.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Customer_Exporter {

	const ADDRESS_FIELDS = array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country', 'email', 'phone' );

	/**
	 * Populated by resolve_user_ids() during this request; not relied on by
	 * build_guest_record(), which re-queries orders by email so a guest
	 * customer still exports correctly on a later AJAX batch request (a
	 * fresh PHP process) where this property would otherwise be empty.
	 *
	 * @var array
	 */
	protected $guest_emails = array();

	/**
	 * @param array $args {
	 *     @type string $format           csv|xlsx|json
	 *     @type array  $user_ids
	 *     @type array  $roles            default: ['customer']
	 *     @type string $registered_after Y-m-d
	 *     @type string $registered_before Y-m-d
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 */
	public function export( $args ) {
		$args = $this->parse_args( $args );
		$run_id = AWPM_Logger::start_run();

		$user_ids = $this->resolve_user_ids( $args );
		if ( empty( $user_ids ) ) {
			return new WP_Error( 'awpm_no_customers', __( 'No customers matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$records = array();
		foreach ( $user_ids as $user_id ) {
			$record = $this->build_record( $user_id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$write_true_xlsx = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename        = 'awpm-export-customers-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path       = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = AWPM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = AWPM_XLSX_Handler::write( $records, $file_path );
		} else {
			$ok = AWPM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'awpm_write_failed', __( 'Could not write export file.', 'advanced-woo-product-migrator' ) );
		}

		return array(
			'file_path'     => $file_path,
			'file_url'      => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename,
			'product_count' => count( $records ),
			'run_id'        => $run_id,
		);
	}

	public function start_job( $args ) {
		$args = $this->parse_args( $args );

		$user_ids = $this->resolve_user_ids( $args );
		if ( empty( $user_ids ) ) {
			return new WP_Error( 'awpm_no_customers', __( 'No customers matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = AWPM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'customers',
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_ids' => $user_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $user_ids ),
			)
		);

		$xlsx_ok  = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename = 'awpm-export-customers-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		AWPM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename ) );

		AWPM_Logger::set_run_id( 'awpm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Export job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$ids    = $job['args']['_ids'] ?? array();
		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $ids, $offset, (int) $job['batch_size'] );

		$records = array();
		foreach ( $batch as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		AWPM_Exporter_File_Writer::append( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch ) ) >= count( $ids ), 'customers' );

		AWPM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch ) ) >= count( $ids ) || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'products' => (int) $job['processed_count'] + count( $records ) );
			AWPM_Webhooks::dispatch( 'export.completed', $totals );
			AWPM_Notifications::notify( 'export_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Customer export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_export_job( $job_id ) );
	}

	protected function parse_args( $args ) {
		return wp_parse_args(
			$args,
			array(
				'format'             => 'json',
				'user_ids'           => array(),
				'roles'              => array( 'customer' ),
				'registered_after'   => '',
				'registered_before'  => '',
				'limit'              => 0,
				'offset'             => 0,
				'batch_size'         => 50,
			)
		);
	}

	protected function resolve_user_ids( $args ) {
		if ( ! empty( $args['user_ids'] ) ) {
			return array_map( 'absint', (array) $args['user_ids'] );
		}

		$query_args = array( 'fields' => 'ID' );
		if ( ! empty( $args['roles'] ) ) {
			$query_args['role__in'] = (array) $args['roles'];
		}
		if ( ! empty( $args['registered_after'] ) || ! empty( $args['registered_before'] ) ) {
			$query_args['date_query'] = array(
				array(
					'after'     => $args['registered_after'] ?: '1970-01-01',
					'before'    => ( $args['registered_before'] ?: gmdate( 'Y-m-d' ) ) . ' 23:59:59',
					'inclusive' => true,
				),
			);
		}

		$registered_ids = array_map( 'absint', (array) get_users( $query_args ) );

		// A role filter only narrows which *registered* accounts are
		// included — it never excludes someone who has actually placed an
		// order. In real stores, "customer" in the WooCommerce sense
		// (what the WooCommerce → Customers screen shows) is anyone who
		// has ordered, whatever WordPress role their account holds — often
		// 'subscriber', or even the shop's own admin account placing a
		// manual/test order — plus guest checkouts that never created an
		// account at all. Defaulting to a strict role__in=['customer']
		// query (the UI's default filter) silently returns zero on most
		// real stores, since WooCommerce doesn't force that literal role.
		// Scanning orders once here, in addition to the role-filtered
		// account query above, is what makes this match what the
		// WooCommerce admin itself shows as "customers".
		$ordering_user_ids    = array();
		$this->guest_emails   = array();
		if ( function_exists( 'wc_get_orders' ) ) {
			$order_ids = wc_get_orders( array( 'limit' => -1, 'return' => 'ids', 'type' => 'shop_order' ) );
			foreach ( (array) $order_ids as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					continue;
				}
				$cid = (int) $order->get_customer_id();
				if ( $cid > 0 ) {
					$ordering_user_ids[ $cid ] = true;
					continue;
				}
				$email = strtolower( trim( $order->get_billing_email() ) );
				// Skip if this email now belongs to a real account — that
				// account (with its own order history) is already covered
				// above, and listing it twice (once as itself, once as a
				// leftover guest order) would create a duplicate customer.
				if ( $email && ! get_user_by( 'email', $email ) ) {
					$this->guest_emails[ $email ] = true;
				}
			}
		}

		$ids = array_values( array_unique( array_merge( $registered_ids, array_keys( $ordering_user_ids ) ) ) );
		foreach ( array_keys( $this->guest_emails ) as $email ) {
			$ids[] = 'guest:' . $email;
		}

		if ( ! empty( $args['offset'] ) ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	/**
	 * Builds an export record for a customer, which may be either a real
	 * WordPress account ($user_id is an int) or a guest checkout that never
	 * created one ($user_id is the string "guest:<email>", produced by
	 * resolve_user_ids() above).
	 *
	 * @param int|string $user_id
	 */
	public function build_record( $user_id ) {
		if ( is_string( $user_id ) && 0 === strpos( $user_id, 'guest:' ) ) {
			return $this->build_guest_record( substr( $user_id, 6 ) );
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return null;
		}

		$billing  = array();
		$shipping = array();
		foreach ( self::ADDRESS_FIELDS as $field ) {
			$billing[ $field ] = get_user_meta( $user_id, 'billing_' . $field, true );
			if ( 'email' !== $field && 'phone' !== $field ) {
				$shipping[ $field ] = get_user_meta( $user_id, 'shipping_' . $field, true );
			}
		}

		return array(
			'source_site'      => site_url(),
			'user_id'          => $user_id,
			'external_id'      => get_user_meta( $user_id, '_awpm_external_id', true ) ?: (string) $user_id,
			'username'         => $user->user_login,
			'email'            => $user->user_email,
			'first_name'       => $user->first_name,
			'last_name'        => $user->last_name,
			'display_name'     => $user->display_name,
			'roles'            => $user->roles,
			'date_registered'  => $user->user_registered,
			'is_paying_customer' => (int) get_user_meta( $user_id, 'paying_customer', true ),
			'billing'          => $billing,
			'shipping'         => $shipping,
			'order_count'      => function_exists( 'wc_get_customer_order_count' ) ? wc_get_customer_order_count( $user_id ) : 0,
			'total_spent'      => function_exists( 'wc_get_customer_total_spent' ) ? wc_get_customer_total_spent( $user_id ) : 0,
			'custom_meta'      => $this->export_user_meta( $user_id ),
		);
	}

	/**
	 * Builds an export record for a guest checkout — someone who ordered
	 * without creating a WordPress account. There's no WP_User or user meta
	 * to read, so the record is assembled from their most recent order's
	 * billing/shipping address instead. Always re-queries by email rather
	 * than trusting $this->guest_emails, since a batch export job's later
	 * batches run in a fresh AJAX request (a new instance of this class).
	 *
	 * @param string $email
	 */
	protected function build_guest_record( $email ) {
		if ( ! $email || ! function_exists( 'wc_get_orders' ) ) {
			return null;
		}

		$orders = wc_get_orders(
			array(
				'billing_email' => $email,
				'limit'         => -1,
				'orderby'       => 'date',
				'order'         => 'DESC',
			)
		);
		if ( empty( $orders ) ) {
			return null;
		}

		$latest      = $orders[0];
		$order_count = count( $orders );
		$total_spent = 0;
		foreach ( $orders as $order ) {
			$total_spent += (float) $order->get_total();
		}

		return array(
			'source_site'         => site_url(),
			'user_id'             => 0,
			'is_guest'            => true,
			'external_id'         => 'guest:' . $email,
			'username'            => '',
			'email'               => $email,
			'first_name'          => $latest->get_billing_first_name(),
			'last_name'           => $latest->get_billing_last_name(),
			'display_name'        => trim( $latest->get_billing_first_name() . ' ' . $latest->get_billing_last_name() ),
			'roles'               => array(),
			'date_registered'     => '',
			'is_paying_customer'  => 1,
			'billing'             => array(
				'first_name' => $latest->get_billing_first_name(), 'last_name' => $latest->get_billing_last_name(),
				'company'    => $latest->get_billing_company(), 'address_1' => $latest->get_billing_address_1(),
				'address_2'  => $latest->get_billing_address_2(), 'city' => $latest->get_billing_city(),
				'state'      => $latest->get_billing_state(), 'postcode' => $latest->get_billing_postcode(),
				'country'    => $latest->get_billing_country(), 'email' => $email,
				'phone'      => $latest->get_billing_phone(),
			),
			'shipping'            => array(
				'first_name' => $latest->get_shipping_first_name(), 'last_name' => $latest->get_shipping_last_name(),
				'company'    => $latest->get_shipping_company(), 'address_1' => $latest->get_shipping_address_1(),
				'address_2'  => $latest->get_shipping_address_2(), 'city' => $latest->get_shipping_city(),
				'state'      => $latest->get_shipping_state(), 'postcode' => $latest->get_shipping_postcode(),
				'country'    => $latest->get_shipping_country(),
			),
			'order_count'         => $order_count,
			'total_spent'         => $total_spent,
			'custom_meta'         => array(),
		);
	}

	protected function export_user_meta( $user_id ) {
		$reserved_prefixes = array( 'billing_', 'shipping_', 'session_tokens', 'wp_', 'wc_', '_awpm_external_id', 'paying_customer' );
		$all = get_user_meta( $user_id );
		$out = array();
		foreach ( $all as $key => $values ) {
			$skip = false;
			foreach ( $reserved_prefixes as $prefix ) {
				if ( 0 === strpos( $key, $prefix ) ) {
					$skip = true;
					break;
				}
			}
			if ( $skip ) {
				continue;
			}
			$out[ $key ] = count( $values ) > 1 ? $values : maybe_unserialize( $values[0] );
		}
		return $out;
	}
}
