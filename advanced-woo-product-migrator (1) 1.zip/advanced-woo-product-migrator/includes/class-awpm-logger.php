<?php
/**
 * AWPM_Logger
 *
 * Writes to wp_awpm_logs (persistent — this backs the Import Logs / Export
 * Logs admin screens and survives past the 6-hour transient window) AND to
 * a short-lived transient (for the in-progress AJAX polling panel, which
 * needs low-latency reads without hitting the DB on every poll tick).
 * Errors/critical entries also go to PHP's error log when WP_DEBUG is on.
 * Never logs credentials — callers keep secrets out of $message/$context
 * (see AWPM_Remote_Fetcher, which redacts before logging).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Logger {

	protected static $run_id   = null;
	protected static $job_type = 'import';
	protected static $job_id   = null;

	public static function start_run( $job_type = 'import', $job_id = null ) {
		self::$run_id   = 'awpm_run_' . wp_generate_password( 8, false );
		self::$job_type = $job_type;
		self::$job_id   = $job_id;
		set_transient( self::$run_id, array(), 6 * HOUR_IN_SECONDS );
		return self::$run_id;
	}

	public static function set_run_id( $run_id, $job_type = 'import', $job_id = null ) {
		self::$run_id   = $run_id;
		self::$job_type = $job_type;
		self::$job_id   = $job_id;
	}

	public static function log( $level, $message, $context = array() ) {
		if ( self::$run_id ) {
			$entries   = get_transient( self::$run_id );
			$entries   = is_array( $entries ) ? $entries : array();
			$entries[] = array(
				'time'    => current_time( 'mysql' ),
				'level'   => $level,
				'message' => $message,
				'context' => $context,
			);
			if ( count( $entries ) > 500 ) {
				$entries = array_slice( $entries, -500 );
			}
			set_transient( self::$run_id, $entries, 6 * HOUR_IN_SECONDS );
		}

		self::persist( $level, $message, $context );

		if ( in_array( $level, array( 'error', 'critical' ), true ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[AWPM] ' . $message ); // phpcs:ignore
		}
	}

	protected static function persist( $level, $message, $context ) {
		if ( ! self::should_persist( $level ) ) {
			return;
		}
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'awpm_logs',
			array(
				'job_type'   => self::$job_type ?: 'import',
				'job_id'     => self::$job_id,
				'level'      => $level,
				'message'    => is_string( $message ) ? $message : wp_json_encode( $message ),
				'context'    => ! empty( $context ) ? wp_json_encode( $context ) : null,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	protected static function should_persist( $level ) {
		$settings = get_option( 'awpm_settings', array() );
		if ( isset( $settings['logging_enabled'] ) && ! $settings['logging_enabled'] ) {
			return in_array( $level, array( 'error', 'critical' ), true ); // Always keep errors even if verbose logging is off.
		}
		return true;
	}

	public static function get_log( $run_id ) {
		$entries = get_transient( $run_id );
		return is_array( $entries ) ? $entries : array();
	}

	/**
	 * Query persisted logs for the Import Logs / Export Logs admin screens.
	 *
	 * @param array $args { job_type, job_id, level, limit, offset }
	 * @return array
	 */
	public static function query( $args = array() ) {
		global $wpdb;
		$args = wp_parse_args( $args, array( 'job_type' => '', 'job_id' => 0, 'level' => '', 'limit' => 100, 'offset' => 0 ) );

		$where  = array( '1=1' );
		$params = array();

		if ( $args['job_type'] ) {
			$where[]  = 'job_type = %s';
			$params[] = $args['job_type'];
		}
		if ( $args['job_id'] ) {
			$where[]  = 'job_id = %d';
			$params[] = $args['job_id'];
		}
		if ( $args['level'] ) {
			$where[]  = 'level = %s';
			$params[] = $args['level'];
		}

		$sql      = "SELECT * FROM {$wpdb->prefix}awpm_logs WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d';
		$params[] = (int) $args['limit'];
		$params[] = (int) $args['offset'];

		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Delete persisted logs older than the configured retention period.
	 * Hooked to a daily cron event (see AWPM_Scheduler::maintenance()).
	 */
	public static function prune_old_logs() {
		global $wpdb;
		$settings = get_option( 'awpm_settings', array() );
		$days     = ! empty( $settings['log_retention_days'] ) ? (int) $settings['log_retention_days'] : 30;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}awpm_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)", $days ) );
	}

	public static function clear_all() {
		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}awpm_logs" ); // phpcs:ignore
	}
}
