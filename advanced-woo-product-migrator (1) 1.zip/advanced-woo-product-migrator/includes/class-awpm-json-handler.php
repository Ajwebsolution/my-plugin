<?php
/**
 * AWPM_JSON_Handler
 *
 * JSON is the "lossless" export format — nested ACF repeater/flexible
 * content structures are written exactly as produced by AWPM_ACF_Handler,
 * with no flattening. Preferred format when round-tripping between two
 * AWPM-powered sites.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_JSON_Handler {

	/**
	 * Write an array of product export records to a JSON file.
	 *
	 * @param array  $records
	 * @param string $file_path
	 * @return bool
	 */
	public static function write( $records, $file_path ) {
		$payload = array(
			'generator'    => 'Advanced WooCommerce Product Migrator',
			'version'      => AWPM_VERSION,
			'exported_at'  => current_time( 'mysql' ),
			'site_url'     => site_url(),
			'product_count'=> count( $records ),
			'products'     => $records,
		);

		$json = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return false !== file_put_contents( $file_path, $json ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Read a previously exported (or hand-authored) JSON file back into an
	 * array of product records.
	 *
	 * @param string $file_path
	 * @return array|WP_Error
	 */
	public static function read( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'awpm_file_missing', __( 'JSON file not found.', 'advanced-woo-product-migrator' ) );
		}

		$raw  = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = json_decode( $raw, true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error( 'awpm_invalid_json', sprintf( __( 'Invalid JSON: %s', 'advanced-woo-product-migrator' ), json_last_error_msg() ) );
		}

		// Accept either our wrapped export format, or a bare array of product records.
		if ( isset( $data['products'] ) && is_array( $data['products'] ) ) {
			return $data['products'];
		}

		return is_array( $data ) ? $data : array();
	}
}
