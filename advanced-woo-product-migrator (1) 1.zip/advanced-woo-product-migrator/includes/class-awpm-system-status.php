<?php
/**
 * AWPM_System_Status
 *
 * Real environment introspection — every value below is read live from PHP/
 * WordPress/WooCommerce, not hardcoded. Backs Settings -> System Status and
 * the dashboard's status strip.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_System_Status {

	public static function get_report() {
		global $wpdb;

		$memory_limit = self::to_bytes( ini_get( 'memory_limit' ) );
		$exec_time    = (int) ini_get( 'max_execution_time' );

		return array(
			'plugin_version'      => AWPM_VERSION,
			'wordpress_version'   => get_bloginfo( 'version' ),
			'php_version'         => PHP_VERSION,
			'php_status'          => version_compare( PHP_VERSION, '8.0', '>=' ) ? 'good' : ( version_compare( PHP_VERSION, AWPM_MIN_PHP, '>=' ) ? 'warning' : 'critical' ),
			'mysql_version'       => $wpdb->db_version(),
			'woocommerce_version' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
			'woocommerce_status'  => class_exists( 'WooCommerce' ) ? 'good' : 'critical',
			'acf_active'          => AWPM_ACF_Handler::is_active(),
			'acf_pro'             => defined( 'ACF_PRO' ) && ACF_PRO,
			'acf_version'         => defined( 'ACF_VERSION' ) ? ACF_VERSION : null,
			'yoast_active'        => AWPM_Yoast_Handler::is_active(),
			'yoast_version'       => AWPM_Yoast_Handler::get_version(),
			'action_scheduler'    => class_exists( 'ActionScheduler' ),
			'rest_api_enabled'    => true, // WP core REST is always available >= 4.7; reported for parity with the spec's checklist.
			'memory_limit'        => ini_get( 'memory_limit' ),
			'memory_status'       => $memory_limit >= 256 * MB_IN_BYTES ? 'good' : ( $memory_limit >= 128 * MB_IN_BYTES ? 'warning' : 'critical' ),
			'max_execution_time'  => $exec_time,
			'exec_time_status'    => ( 0 === $exec_time || $exec_time >= 300 ) ? 'good' : ( $exec_time >= 60 ? 'warning' : 'critical' ),
			'upload_max_filesize' => ini_get( 'upload_max_filesize' ),
			'post_max_size'       => ini_get( 'post_max_size' ),
			'curl_available'      => function_exists( 'curl_init' ),
			'zip_available'       => class_exists( 'ZipArchive' ),
			'ftp_available'       => function_exists( 'ftp_connect' ),
			'wp_debug'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'multisite'           => is_multisite(),
			'active_theme'        => wp_get_theme()->get( 'Name' ),
			'integrations'        => self::detect_integrations(),
		);
	}

	/**
	 * Dynamically detected third-party integrations relevant to product
	 * data (never hardcoded — spec section 55).
	 */
	public static function detect_integrations() {
		$integrations = array();

		$integrations['ACF'] = array(
			'detected' => AWPM_ACF_Handler::is_active(),
			'version'  => defined( 'ACF_VERSION' ) ? ACF_VERSION : null,
			'supported'=> true,
		);
		$integrations['Yoast SEO'] = array(
			'detected' => AWPM_Yoast_Handler::is_active(),
			'version'  => AWPM_Yoast_Handler::get_version(),
			'supported'=> true,
		);
		$integrations['WooCommerce Subscriptions'] = array(
			'detected' => class_exists( 'WC_Subscriptions' ),
			'version'  => defined( 'WC_Subscriptions::$version' ) ? WC_Subscriptions::$version : null,
			'supported'=> class_exists( 'WC_Subscriptions' ), // We pass subscription products through as their own registered type; no bespoke handling needed beyond that.
		);
		$integrations['Action Scheduler'] = array(
			'detected' => class_exists( 'ActionScheduler' ),
			'version'  => defined( 'ActionScheduler::VERSION' ) ? ActionScheduler::VERSION : null,
			'supported'=> true,
		);

		/**
		 * Let other plugins declare themselves as detected/supported
		 * integrations without AWPM needing to know about them in advance.
		 */
		return apply_filters( 'awpm_detected_integrations', $integrations );
	}

	/**
	 * Plain-text report for the "Copy System Report" button.
	 */
	public static function as_text() {
		$r    = self::get_report();
		$lines = array(
			'### Advanced WooCommerce Product Migrator — System Report ###',
			'Plugin Version: ' . $r['plugin_version'],
			'WordPress: ' . $r['wordpress_version'],
			'PHP: ' . $r['php_version'],
			'MySQL: ' . $r['mysql_version'],
			'WooCommerce: ' . ( $r['woocommerce_version'] ?: 'not detected' ),
			'ACF: ' . ( $r['acf_active'] ? ( $r['acf_pro'] ? 'Pro ' : '' ) . $r['acf_version'] : 'not detected' ),
			'Yoast SEO: ' . ( $r['yoast_active'] ? $r['yoast_version'] : 'not detected' ),
			'Action Scheduler: ' . ( $r['action_scheduler'] ? 'available' : 'not available (falls back to WP-Cron)' ),
			'Memory Limit: ' . $r['memory_limit'],
			'Max Execution Time: ' . $r['max_execution_time'],
			'Upload Max Filesize: ' . $r['upload_max_filesize'],
			'Post Max Size: ' . $r['post_max_size'],
			'cURL: ' . ( $r['curl_available'] ? 'yes' : 'no' ),
			'ZipArchive: ' . ( $r['zip_available'] ? 'yes' : 'no' ),
			'Multisite: ' . ( $r['multisite'] ? 'yes' : 'no' ),
			'Active Theme: ' . $r['active_theme'],
		);
		return implode( "\n", $lines );
	}

	protected static function to_bytes( $value ) {
		$value = trim( $value );
		$last  = strtolower( $value[ strlen( $value ) - 1 ] );
		$num   = (int) $value;
		switch ( $last ) {
			case 'g': $num *= 1024;
			case 'm': $num *= 1024;
			case 'k': $num *= 1024;
		}
		return $num;
	}
}
