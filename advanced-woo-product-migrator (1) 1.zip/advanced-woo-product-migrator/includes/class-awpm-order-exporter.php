<?php
/**
 * AWPM_Order_Exporter
 *
 * Exports WooCommerce orders (via the WC_Order CRUD API, never raw postmeta)
 * as structured, portable records: billing/shipping address, line items
 * (resolved to SKU so they re-match on the destination site rather than
 * trusting raw product IDs), shipping/fee/coupon lines, totals, status, and
 * the customer's email (used by the importer to link back to a customer
 * account on the destination site). Mirrors AWPM_Product_Exporter's
 * export()/start_job()/process_next_batch() shape.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Order_Exporter {

	/**
	 * @param array $args {
	 *     @type string $format        csv|xlsx|json
	 *     @type array  $order_ids
	 *     @type array  $statuses      wc-processing, wc-completed, ... empty = any.
	 *     @type string $date_after    Y-m-d (order date)
	 *     @type string $date_before   Y-m-d
	 *     @type string $customer_email
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 */
	public function export( $args ) {
		$args = $this->parse_args( $args );
		$run_id = AWPM_Logger::start_run();

		$order_ids = $this->resolve_order_ids( $args );
		if ( empty( $order_ids ) ) {
			return new WP_Error( 'awpm_no_orders', __( 'No orders matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$records = array();
		foreach ( $order_ids as $order_id ) {
			$record = $this->build_record( $order_id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$write_true_xlsx = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename        = 'awpm-export-orders-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path       = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = AWPM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = AWPM_XLSX_Handler::write( $records, $file_path );
		} else {
			$ok = AWPM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'awpm_write_failed', __( 'Could not write export file.', 'advanced-woo-product-migrator' ) );
		}

		return array(
			'file_path'     => $file_path,
			'file_url'      => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename,
			'product_count' => count( $records ),
			'run_id'        => $run_id,
		);
	}

	public function start_job( $args ) {
		$args = $this->parse_args( $args );

		$order_ids = $this->resolve_order_ids( $args );
		if ( empty( $order_ids ) ) {
			return new WP_Error( 'awpm_no_orders', __( 'No orders matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = AWPM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'orders',
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_ids' => $order_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $order_ids ),
			)
		);

		$xlsx_ok  = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename = 'awpm-export-orders-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		AWPM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename ) );

		AWPM_Logger::set_run_id( 'awpm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Export job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$ids    = $job['args']['_ids'] ?? array();
		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $ids, $offset, (int) $job['batch_size'] );

		$records = array();
		foreach ( $batch as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		AWPM_Exporter_File_Writer::append( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch ) ) >= count( $ids ), 'orders' );

		AWPM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch ) ) >= count( $ids ) || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'products' => (int) $job['processed_count'] + count( $records ) );
			AWPM_Webhooks::dispatch( 'export.completed', $totals );
			AWPM_Notifications::notify( 'export_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Order export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_export_job( $job_id ) );
	}

	protected function parse_args( $args ) {
		return wp_parse_args(
			$args,
			array(
				'format'         => 'json',
				'order_ids'      => array(),
				'statuses'       => array(),
				'date_after'     => '',
				'date_before'    => '',
				'customer_email' => '',
				'limit'          => 0,
				'offset'         => 0,
				'batch_size'     => 50,
			)
		);
	}

	protected function resolve_order_ids( $args ) {
		if ( ! empty( $args['order_ids'] ) ) {
			return array_map( 'absint', (array) $args['order_ids'] );
		}

		$query_args = array(
			'limit'   => -1,
			'return'  => 'ids',
			'type'    => 'shop_order',
		);
		if ( ! empty( $args['statuses'] ) ) {
			$query_args['status'] = (array) $args['statuses'];
		}
		if ( ! empty( $args['customer_email'] ) ) {
			$query_args['billing_email'] = $args['customer_email'];
		}
		if ( ! empty( $args['date_after'] ) || ! empty( $args['date_before'] ) ) {
			$after  = $args['date_after'] ?: '1970-01-01';
			$before = $args['date_before'] ?: gmdate( 'Y-m-d' );
			$query_args['date_created'] = $after . '...' . $before;
		}

		$ids = wc_get_orders( $query_args );
		$ids = array_map( 'absint', (array) $ids );

		if ( ! empty( $args['offset'] ) ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	public function build_record( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return null;
		}

		$line_items = array();
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			/** @var WC_Order_Item_Product $item */
			$product = $item->get_product();
			$line_items[] = array(
				'name'       => $item->get_name(),
				'sku'        => $product ? $product->get_sku() : '',
				'product_external_id' => $product ? ( get_post_meta( $product->get_id(), AWPM_Relationship_Map::META_KEY, true ) ?: (string) $product->get_id() ) : '',
				'quantity'   => $item->get_quantity(),
				'subtotal'   => $item->get_subtotal(),
				'total'      => $item->get_total(),
				'total_tax'  => $item->get_total_tax(),
			);
		}

		$shipping_lines = array();
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			/** @var WC_Order_Item_Shipping $item */
			$shipping_lines[] = array( 'method_title' => $item->get_method_title(), 'total' => $item->get_total() );
		}

		$fee_lines = array();
		foreach ( $order->get_items( 'fee' ) as $item ) {
			/** @var WC_Order_Item_Fee $item */
			$fee_lines[] = array( 'name' => $item->get_name(), 'total' => $item->get_total() );
		}

		$coupon_lines = array();
		foreach ( $order->get_items( 'coupon' ) as $item ) {
			/** @var WC_Order_Item_Coupon $item */
			$coupon_lines[] = $item->get_code();
		}

		$customer_id = $order->get_customer_id();

		return array(
			'source_site'     => site_url(),
			'order_id'        => $order_id,
			'external_id'     => get_post_meta( $order_id, '_awpm_external_id', true ) ?: (string) $order_id,
			'order_number'    => $order->get_order_number(),
			'status'          => $order->get_status(),
			'currency'        => $order->get_currency(),
			'date_created'    => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
			'date_paid'       => $order->get_date_paid() ? $order->get_date_paid()->date( 'Y-m-d H:i:s' ) : '',
			'date_completed'  => $order->get_date_completed() ? $order->get_date_completed()->date( 'Y-m-d H:i:s' ) : '',
			'customer_id'     => $customer_id,
			'customer_email'  => $order->get_billing_email(),
			'customer_external_id' => $customer_id ? ( get_user_meta( $customer_id, '_awpm_external_id', true ) ?: (string) $customer_id ) : '',
			'payment_method'  => $order->get_payment_method(),
			'payment_method_title' => $order->get_payment_method_title(),
			'customer_note'   => $order->get_customer_note(),
			'total'           => $order->get_total(),
			'total_tax'       => $order->get_total_tax(),
			'shipping_total'  => $order->get_shipping_total(),
			'discount_total'  => $order->get_discount_total(),
			'billing'         => array(
				'first_name' => $order->get_billing_first_name(), 'last_name' => $order->get_billing_last_name(),
				'company'    => $order->get_billing_company(), 'address_1' => $order->get_billing_address_1(),
				'address_2'  => $order->get_billing_address_2(), 'city' => $order->get_billing_city(),
				'state'      => $order->get_billing_state(), 'postcode' => $order->get_billing_postcode(),
				'country'    => $order->get_billing_country(), 'email' => $order->get_billing_email(),
				'phone'      => $order->get_billing_phone(),
			),
			'shipping'        => array(
				'first_name' => $order->get_shipping_first_name(), 'last_name' => $order->get_shipping_last_name(),
				'company'    => $order->get_shipping_company(), 'address_1' => $order->get_shipping_address_1(),
				'address_2'  => $order->get_shipping_address_2(), 'city' => $order->get_shipping_city(),
				'state'      => $order->get_shipping_state(), 'postcode' => $order->get_shipping_postcode(),
				'country'    => $order->get_shipping_country(),
			),
			'line_items'      => $line_items,
			'shipping_lines'  => $shipping_lines,
			'fee_lines'       => $fee_lines,
			'coupon_lines'    => $coupon_lines,
			'custom_meta'     => $this->export_order_meta( $order ),
		);
	}

	/**
	 * Order meta via WC_Order::get_meta_data() rather than get_post_meta()
	 * — orders may live in WooCommerce's own HPOS tables instead of wp_posts
	 * on sites with High-Performance Order Storage enabled, and the CRUD
	 * object is the only reliable way to read their meta either way.
	 *
	 * @param WC_Order $order
	 * @return array
	 */
	protected function export_order_meta( $order ) {
		$reserved = array( '_billing_', '_shipping_', '_order_key', '_order_currency', '_payment_method', '_customer_user', '_awpm_external_id' );
		$out = array();
		foreach ( $order->get_meta_data() as $meta ) {
			$key = $meta->key;
			$skip = false;
			foreach ( $reserved as $prefix ) {
				if ( 0 === strpos( $key, $prefix ) ) {
					$skip = true;
					break;
				}
			}
			if ( $skip ) {
				continue;
			}
			$out[ $key ] = $meta->value;
		}
		return $out;
	}
}
