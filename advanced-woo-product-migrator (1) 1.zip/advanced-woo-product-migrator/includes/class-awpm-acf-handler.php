<?php
/**
 * AWPM_ACF_Handler
 *
 * Exports and imports ACF data for a product using ACF's own field API
 * (get_field / update_field with $formatted = false) rather than reading
 * raw postmeta. This is deliberate: ACF already knows how to serialize
 * repeaters, flexible content, galleries, relationship and post_object
 * fields into structured arrays, and update_field() already knows how to
 * write that structure back correctly (including the internal "_field"
 * reference rows ACF relies on). Re-implementing that by hand is how
 * off-the-shelf importers corrupt ACF data — so we don't.
 *
 * Image/File/Gallery sub-fields are the one place raw IDs from another
 * site are meaningless, so those are resolved through AWPM_Image_Handler
 * before being written back with update_field().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_ACF_Handler {

	/**
	 * Is ACF (free or Pro) active?
	 *
	 * @return bool
	 */
	public static function is_active() {
		return function_exists( 'get_field' ) && function_exists( 'update_field' ) && function_exists( 'acf_get_field_groups' );
	}

	/**
	 * Export all top-level ACF fields attached to a product (or variation)
	 * post into a nested associative array keyed by field name.
	 *
	 * @param int $post_id Product or variation post ID.
	 * @return array
	 */
	public static function export_fields( $post_id ) {
		if ( ! self::is_active() ) {
			return array();
		}

		$field_objects = get_field_objects( $post_id, false ); // false = raw / unformatted values.
		if ( empty( $field_objects ) ) {
			return array();
		}

		$export = array();
		foreach ( $field_objects as $name => $field ) {
			$export[ $name ] = self::export_field_value( $field['value'], $field );
		}

		return $export;
	}

	/**
	 * Recursively walk a field's value, converting attachment-ID-bearing
	 * sub-fields (image, file, gallery) into portable identifiers
	 * (ID + URL + filename) so the data survives a move to another site.
	 * Everything else (text, repeater rows, relationship post arrays,
	 * flexible content layouts, etc.) is preserved as ACF returns it,
	 * since that's already the exact shape update_field() expects back.
	 *
	 * @param mixed $value Raw field value from get_field_objects().
	 * @param array $field Field definition array (for type-aware handling).
	 * @return mixed
	 */
	protected static function export_field_value( $value, $field ) {
		switch ( $field['type'] ) {

			case 'image':
			case 'file':
				return self::export_attachment_ref( $value );

			case 'gallery':
				if ( ! is_array( $value ) ) {
					return array();
				}
				return array_map( array( __CLASS__, 'export_attachment_ref' ), $value );

			case 'repeater':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$rows = array();
				foreach ( $value as $row ) {
					$rows[] = self::export_row( $row, $field['sub_fields'] );
				}
				return $rows;

			case 'group':
				// A Group returns ONE associative array (not a list of rows
				// like a repeater) — same sub-field-aware handling via
				// export_row() so an image/gallery/relationship field
				// nested inside a group still gets converted to a portable
				// reference instead of a raw local ID that won't resolve
				// on the destination site.
				if ( ! is_array( $value ) ) {
					return array();
				}
				return self::export_row( $value, $field['sub_fields'] ?? array() );

			case 'clone':
				// A non-"seamless" clone field behaves like a group (one
				// associative array of the cloned sub-fields); seamless
				// clones inject their fields as direct siblings and never
				// reach this switch under their own 'clone' type at all,
				// so this branch only ever sees the non-seamless case.
				if ( ! is_array( $value ) ) {
					return $value;
				}
				return self::export_row( $value, $field['sub_fields'] ?? array() );

			case 'flexible_content':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$layouts_out = array();
				foreach ( $value as $row ) {
					$layout_name    = $row['acf_fc_layout'];
					$layout_def     = self::find_layout_def( $field['layouts'], $layout_name );
					$sub_fields_def = $layout_def ? $layout_def['sub_fields'] : array();
					$row_export             = self::export_row( $row, $sub_fields_def );
					$row_export['acf_fc_layout'] = $layout_name;
					$layouts_out[]          = $row_export;
				}
				return $layouts_out;

			case 'relationship':
			case 'post_object':
				// Store portable references (ID kept for same-site match,
				// plus title/type/guid so the importer can re-match by
				// title on the destination site if the ID doesn't exist,
				// and external_id when the referenced post is itself a
				// product, so AWPM_Relationship_Map can resolve it exactly).
				$posts = is_array( $value ) ? $value : ( $value ? array( $value ) : array() );
				$refs  = array();
				foreach ( $posts as $p ) {
					$pid = is_object( $p ) ? $p->ID : $p;
					if ( ! $pid ) {
						continue;
					}
					$refs[] = array(
						'id'          => (int) $pid,
						'title'       => get_the_title( $pid ),
						'post_type'   => get_post_type( $pid ),
						'guid'        => get_permalink( $pid ),
						'external_id' => in_array( get_post_type( $pid ), array( 'product', 'product_variation' ), true )
							? ( get_post_meta( $pid, AWPM_Relationship_Map::META_KEY, true ) ?: (string) $pid )
							: null,
					);
				}
				return $field['type'] === 'post_object' && ! is_array( $value ) ? ( $refs[0] ?? null ) : $refs;

			case 'taxonomy':
				$terms = is_array( $value ) ? $value : ( $value ? array( $value ) : array() );
				$refs  = array();
				foreach ( $terms as $t ) {
					$term = is_object( $t ) ? $t : get_term( $t );
					if ( ! $term || is_wp_error( $term ) ) {
						continue;
					}
					$refs[] = array(
						'term_id'  => $term->term_id,
						'slug'     => $term->slug,
						'name'     => $term->name,
						'taxonomy' => $term->taxonomy,
					);
				}
				return $refs;

			case 'user':
				$users = is_array( $value ) ? $value : ( $value ? array( $value ) : array() );
				$refs  = array();
				foreach ( $users as $u ) {
					$uid = is_array( $u ) ? ( $u['ID'] ?? null ) : $u;
					if ( ! $uid ) {
						continue;
					}
					$user = get_userdata( $uid );
					if ( $user ) {
						$refs[] = array( 'id' => $uid, 'user_login' => $user->user_login, 'user_email' => $user->user_email );
					}
				}
				return $refs;

			default:
				// text, textarea, number, email, url, password, wysiwyg,
				// oembed, select, checkbox, radio, button_group,
				// true_false, date_picker, date_time_picker, time_picker,
				// color_picker, clone (as merged array), etc. — ACF
				// already returns these as plain scalars/arrays, safe to
				// pass through unchanged.
				return $value;
		}
	}

	/**
	 * Export one repeater/flexible-content row, mapping each sub-field's
	 * value through export_field_value() using its own sub-field def.
	 *
	 * @param array $row Raw row (name => value).
	 * @param array $sub_fields_def Sub-field definitions for this row shape.
	 * @return array
	 */
	protected static function export_row( $row, $sub_fields_def ) {
		$sub_fields_by_name = array();
		foreach ( (array) $sub_fields_def as $sf ) {
			$sub_fields_by_name[ $sf['name'] ] = $sf;
		}

		$out = array();
		foreach ( $row as $key => $val ) {
			if ( 'acf_fc_layout' === $key ) {
				continue; // Handled separately by caller for flexible_content.
			}
			if ( isset( $sub_fields_by_name[ $key ] ) ) {
				$out[ $key ] = self::export_field_value( $val, $sub_fields_by_name[ $key ] );
			} else {
				$out[ $key ] = $val;
			}
		}
		return $out;
	}

	protected static function find_layout_def( $layouts, $name ) {
		foreach ( (array) $layouts as $layout ) {
			if ( $layout['name'] === $name ) {
				return $layout;
			}
		}
		return null;
	}

	/**
	 * Convert an attachment ID (image/file field raw value) into a
	 * portable reference: ID (source site), URL, filename — per spec
	 * "Option 4: export all available identifiers" so the importer has
	 * maximum ability to re-match on the destination site.
	 *
	 * @param mixed $value Raw attachment ID, or already an array/null.
	 * @return array|null
	 */
	public static function export_attachment_ref( $value ) {
		$id = is_array( $value ) ? ( $value['ID'] ?? $value['id'] ?? null ) : $value;
		if ( ! $id ) {
			return null;
		}
		$url = wp_get_attachment_url( $id );
		return array(
			'source_id'  => (int) $id,
			'url'        => $url ? $url : '',
			'filename'   => $url ? wp_basename( $url ) : '',
			'alt'        => get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'      => get_the_title( $id ),
			'caption'    => wp_get_attachment_caption( $id ),
			'description'=> get_post_field( 'post_content', $id ),
		);
	}

	/* -------------------------------------------------------------------
	 * IMPORT
	 * ------------------------------------------------------------------ */

	/**
	 * Import a previously-exported ACF field set onto a product/variation.
	 * Resolves any attachment references (image/file/gallery, at any
	 * nesting depth) to local attachment IDs first, then hands the whole
	 * structure to update_field() per top-level field, which is exactly
	 * what ACF needs to persist repeaters / flexible content / galleries
	 * correctly.
	 *
	 * @param int   $post_id Destination post ID.
	 * @param array $data    Exported ACF data (field name => value).
	 * @param array $options Import options (image_match_strategy, etc).
	 * @return array Log of field => status.
	 */
	public static function import_fields( $post_id, $data, $options = array() ) {
		if ( ! self::is_active() || empty( $data ) || ! is_array( $data ) ) {
			return array();
		}

		$field_objects = get_field_objects( $post_id, false );
		$log           = array();

		foreach ( $data as $name => $value ) {
			$field_def = $field_objects[ $name ] ?? self::find_field_def_by_name( $post_id, $name );
			if ( ! $field_def ) {
				// Field no longer exists on destination site's ACF config — skip,
				// but keep it out of custom meta so we don't silently duplicate it.
				$log[ $name ] = 'skipped_no_field_definition';
				continue;
			}

			$resolved = self::resolve_field_value( $value, $field_def, $options );
			$selector = $field_def['key'] ?: $name;
			update_field( $selector, $resolved, $post_id );
			$log[ $name ] = 'imported';
		}

		return $log;
	}

	protected static function find_field_def_by_name( $post_id, $name ) {
		if ( ! function_exists( 'acf_get_field' ) ) {
			return null;
		}
		// Fall back: look across product-located field groups for a name match
		// (covers the case get_field_objects() returns nothing yet, e.g. a
		// brand-new post with no meta saved at all).
		$groups = acf_get_field_groups( array( 'post_type' => 'product' ) );
		foreach ( $groups as $group ) {
			foreach ( (array) acf_get_fields( $group['key'] ) as $field ) {
				if ( $field['name'] === $name ) {
					return $field;
				}
			}
		}
		return null;
	}

	/**
	 * Recursively resolve exported values back into ACF-native shapes,
	 * turning our portable attachment/relationship/taxonomy references
	 * back into real local IDs.
	 *
	 * @param mixed $value Exported value.
	 * @param array $field Field definition.
	 * @param array $options Import options.
	 * @return mixed
	 */
	protected static function resolve_field_value( $value, $field, $options ) {
		switch ( $field['type'] ) {

			case 'image':
			case 'file':
				return self::resolve_attachment_ref( $value, $options );

			case 'gallery':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$ids = array();
				foreach ( $value as $ref ) {
					$id = self::resolve_attachment_ref( $ref, $options );
					if ( $id ) {
						$ids[] = $id;
					}
				}
				return $ids;

			case 'repeater':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$rows = array();
				foreach ( $value as $row ) {
					$rows[] = self::resolve_row( $row, $field['sub_fields'], $options );
				}
				return $rows;

			case 'group':
			case 'clone':
				// Mirrors export_field_value()'s group/clone handling: one
				// associative array of sub-field values, resolved the same
				// way a single repeater row would be.
				if ( ! is_array( $value ) ) {
					return $value;
				}
				return self::resolve_row( $value, $field['sub_fields'] ?? array(), $options );

			case 'flexible_content':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$rows = array();
				foreach ( $value as $row ) {
					$layout_name = $row['acf_fc_layout'] ?? '';
					$layout_def  = self::find_layout_def( $field['layouts'], $layout_name );
					$sub_fields  = $layout_def ? $layout_def['sub_fields'] : array();
					$resolved    = self::resolve_row( $row, $sub_fields, $options );
					$resolved['acf_fc_layout'] = $layout_name;
					$rows[]      = $resolved;
				}
				return $rows;

			case 'relationship':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$ids = array();
				foreach ( $value as $ref ) {
					$id = self::resolve_post_ref( $ref );
					if ( $id ) {
						$ids[] = $id;
					}
				}
				return $ids;

			case 'post_object':
				if ( is_array( $value ) && isset( $value['id'] ) ) {
					return self::resolve_post_ref( $value );
				}
				return null;

			case 'taxonomy':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$term_ids = array();
				foreach ( $value as $ref ) {
					$term = get_term_by( 'slug', $ref['slug'] ?? '', $ref['taxonomy'] ?? '' );
					if ( ! $term && ! empty( $ref['name'] ) && ! empty( $ref['taxonomy'] ) ) {
						// Create missing term on destination if it doesn't exist.
						$created = wp_insert_term( $ref['name'], $ref['taxonomy'] );
						if ( ! is_wp_error( $created ) ) {
							$term_ids[] = $created['term_id'];
						}
						continue;
					}
					if ( $term ) {
						$term_ids[] = $term->term_id;
					}
				}
				return $term_ids;

			case 'user':
				if ( ! is_array( $value ) ) {
					return array();
				}
				$user_ids = array();
				foreach ( $value as $ref ) {
					$user = ! empty( $ref['user_email'] ) ? get_user_by( 'email', $ref['user_email'] ) : false;
					if ( $user ) {
						$user_ids[] = $user->ID;
					}
				}
				return $user_ids;

			default:
				return $value;
		}
	}

	protected static function resolve_row( $row, $sub_fields_def, $options ) {
		$sub_fields_by_name = array();
		foreach ( (array) $sub_fields_def as $sf ) {
			$sub_fields_by_name[ $sf['name'] ] = $sf;
		}
		$out = array();
		foreach ( $row as $key => $val ) {
			if ( 'acf_fc_layout' === $key ) {
				continue;
			}
			$out[ $key ] = isset( $sub_fields_by_name[ $key ] )
				? self::resolve_field_value( $val, $sub_fields_by_name[ $key ], $options )
				: $val;
		}
		return $out;
	}

	/**
	 * Resolve an exported post reference (relationship/post_object) to a
	 * local post ID. Per the spec's relationship-mapping requirement, this
	 * never blindly trusts the source site's raw post ID — it first checks
	 * the relationship map (populated by AWPM_Product_Importer as products
	 * are created/updated), then falls back to an exact title+post_type
	 * match, and only as a last resort accepts the raw ID if it happens to
	 * exist locally with a matching post type (same-site re-import case).
	 *
	 * @param array $ref
	 * @return int|null
	 */
	protected static function resolve_post_ref( $ref ) {
		if ( empty( $ref['id'] ) ) {
			return null;
		}

		$object_type = ( 'product' === ( $ref['post_type'] ?? '' ) || 'product_variation' === ( $ref['post_type'] ?? '' ) ) ? 'product' : 'post';

		if ( 'product' === $object_type && class_exists( 'AWPM_Relationship_Map' ) ) {
			$lookup = $ref['external_id'] ?? (string) $ref['id'];
			$mapped = AWPM_Relationship_Map::resolve( '', $lookup, 'product' );
			if ( $mapped ) {
				return $mapped;
			}
		}

		if ( get_post_status( $ref['id'] ) && get_post_type( $ref['id'] ) === ( $ref['post_type'] ?? get_post_type( $ref['id'] ) ) ) {
			return (int) $ref['id']; // Same-site case: the raw ID is still valid here.
		}

		$match = get_page_by_title( $ref['title'] ?? '', OBJECT, $ref['post_type'] ?? 'post' );
		return $match ? $match->ID : null;
	}

	/**
	 * Resolve an exported attachment reference to a local attachment ID,
	 * delegating the actual match/download logic to AWPM_Image_Handler so
	 * import strategy (ID / URL / filename / SKU+filename) is centralized.
	 *
	 * @param array|null $ref
	 * @param array      $options
	 * @return int|null
	 */
	protected static function resolve_attachment_ref( $ref, $options ) {
		if ( empty( $ref ) || ! is_array( $ref ) ) {
			return null;
		}
		return AWPM_Image_Handler::resolve_attachment(
			array(
				'id'       => $ref['source_id'] ?? null,
				'url'      => $ref['url'] ?? '',
				'filename' => $ref['filename'] ?? '',
				'alt'      => $ref['alt'] ?? '',
				'title'    => $ref['title'] ?? '',
				'caption'  => $ref['caption'] ?? '',
				'description' => $ref['description'] ?? '',
			),
			$options
		);
	}
}
