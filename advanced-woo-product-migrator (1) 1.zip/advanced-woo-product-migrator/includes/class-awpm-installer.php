<?php
/**
 * AWPM_Installer
 *
 * Creates/upgrades the plugin's own operational tables (jobs, items, logs,
 * mappings, snapshots for rollback, scheduled jobs, and the source->target
 * relationship map used for cross-site ID resolution). WooCommerce/WordPress
 * remain the sole source of truth for product data — these tables only ever
 * hold plugin bookkeeping, never a duplicate copy of product data.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Installer {

	const DB_VERSION_OPTION = 'awpm_db_version';
	const DB_VERSION        = '1.1.0';

	public static function install() {
		self::create_tables();
		self::register_capability();
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Called on plugins_loaded to silently upgrade tables if the plugin
	 * version shipped a schema change since the site's stored DB version.
	 */
	public static function maybe_upgrade() {
		if ( get_option( self::DB_VERSION_OPTION ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	protected static function register_capability() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( 'manage_awpm' ) ) {
			$admin->add_cap( 'manage_awpm' );
		}
		$shop_manager = get_role( 'shop_manager' );
		if ( $shop_manager && ! $shop_manager->has_cap( 'manage_awpm' ) ) {
			$shop_manager->add_cap( 'manage_awpm' );
		}
	}

	protected static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$prefix           = $wpdb->prefix;

		$sql = array();

		// Import & export jobs (batch/background processing state + history).
		$sql[] = "CREATE TABLE {$prefix}awpm_import_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			entity_type VARCHAR(20) NOT NULL DEFAULT 'product',
			file_path TEXT NULL,
			format VARCHAR(10) NOT NULL DEFAULT 'json',
			mapping LONGTEXT NULL,
			options LONGTEXT NULL,
			dry_run TINYINT(1) NOT NULL DEFAULT 0,
			batch_size INT UNSIGNED NOT NULL DEFAULT 50,
			offset_row INT UNSIGNED NOT NULL DEFAULT 0,
			total_rows INT UNSIGNED NOT NULL DEFAULT 0,
			created_count INT UNSIGNED NOT NULL DEFAULT 0,
			updated_count INT UNSIGNED NOT NULL DEFAULT 0,
			skipped_count INT UNSIGNED NOT NULL DEFAULT 0,
			failed_count INT UNSIGNED NOT NULL DEFAULT 0,
			mapping_profile_id BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			started_at DATETIME NULL,
			finished_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}awpm_export_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			entity_type VARCHAR(20) NOT NULL DEFAULT 'product',
			format VARCHAR(10) NOT NULL DEFAULT 'json',
			args LONGTEXT NULL,
			batch_size INT UNSIGNED NOT NULL DEFAULT 50,
			offset_row INT UNSIGNED NOT NULL DEFAULT 0,
			total_rows INT UNSIGNED NOT NULL DEFAULT 0,
			processed_count INT UNSIGNED NOT NULL DEFAULT 0,
			file_path TEXT NULL,
			file_url TEXT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			started_at DATETIME NULL,
			finished_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset_collate};";

		// Per-row outcome within an import job (for the Import Logs / preview screens).
		$sql[] = "CREATE TABLE {$prefix}awpm_import_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_id BIGINT UNSIGNED NOT NULL,
			row_index INT UNSIGNED NOT NULL DEFAULT 0,
			sku VARCHAR(191) NULL,
			product_id BIGINT UNSIGNED NULL,
			result VARCHAR(20) NOT NULL DEFAULT 'success',
			message TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY result (result),
			KEY sku (sku)
		) {$charset_collate};";

		// Persistent structured logs (Import Logs / Export Logs tab), independent of the live transient used for in-progress polling.
		$sql[] = "CREATE TABLE {$prefix}awpm_logs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_type VARCHAR(10) NOT NULL DEFAULT 'import',
			job_id BIGINT UNSIGNED NULL,
			level VARCHAR(10) NOT NULL DEFAULT 'info',
			message TEXT NOT NULL,
			context LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY level (level),
			KEY created_at (created_at)
		) {$charset_collate};";

		// Saved mapping/export profiles.
		$sql[] = "CREATE TABLE {$prefix}awpm_mappings (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			type VARCHAR(10) NOT NULL DEFAULT 'import',
			config LONGTEXT NOT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY type (type)
		) {$charset_collate};";

		// Pre-update snapshots for rollback. Stores the WooCommerce CRUD data
		// array (not a duplicate "source of truth" — just a restore point).
		$sql[] = "CREATE TABLE {$prefix}awpm_snapshots (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			job_id BIGINT UNSIGNED NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			action VARCHAR(10) NOT NULL DEFAULT 'update',
			snapshot LONGTEXT NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			expires_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY job_id (job_id),
			KEY product_id (product_id),
			KEY expires_at (expires_at)
		) {$charset_collate};";

		// Recurring scheduled import/export definitions (WP-Cron backed).
		$sql[] = "CREATE TABLE {$prefix}awpm_scheduled_jobs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			type VARCHAR(10) NOT NULL DEFAULT 'import',
			recurrence VARCHAR(20) NOT NULL DEFAULT 'daily',
			source_type VARCHAR(20) NOT NULL DEFAULT 'remote_url',
			source_config LONGTEXT NULL,
			mapping_profile_id BIGINT UNSIGNED NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			last_run_at DATETIME NULL,
			last_status VARCHAR(20) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY active (active)
		) {$charset_collate};";

		// Source-system -> target-product-ID map, used to resolve
		// relationships/upsells/cross-sells/ACF post_object-relationship
		// fields across repeated migrations without trusting raw source IDs.
		$sql[] = "CREATE TABLE {$prefix}awpm_relationship_map (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_system VARCHAR(191) NOT NULL DEFAULT 'default',
			source_id VARCHAR(191) NOT NULL,
			external_id VARCHAR(191) NULL,
			target_id BIGINT UNSIGNED NOT NULL,
			object_type VARCHAR(20) NOT NULL DEFAULT 'product',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY source_lookup (source_system, source_id, object_type),
			KEY external_id (external_id),
			KEY target_id (target_id)
		) {$charset_collate};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Drop all plugin tables. Only ever called from uninstall.php, and only
	 * when the site owner has opted into full cleanup — never automatically.
	 */
	public static function drop_tables() {
		global $wpdb;
		$prefix = $wpdb->prefix;
		$tables = array(
			'awpm_import_jobs', 'awpm_export_jobs', 'awpm_import_items', 'awpm_logs',
			'awpm_mappings', 'awpm_snapshots', 'awpm_scheduled_jobs', 'awpm_relationship_map',
		);
		foreach ( $tables as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$prefix}{$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}
	}
}
