<?php
/**
 * AWPM_Product_Exporter
 *
 * Builds the full, structured export record for a product (simple or
 * variable, including all variations), pulling core WC data, attributes,
 * categories/tags, images, ACF, Yoast and custom meta together, then
 * writes the whole set out via the CSV or JSON handler.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Product_Exporter {

	/**
	 * Field-selection config from the wizard's Step 4 (field mapping)
	 * screen, set once per export() / start_job() call and read by
	 * apply_field_selection() inside build_record(). Empty means "export
	 * everything" — the default for Tools/REST/Scheduled exports that
	 * never pass a field_config at all.
	 *
	 * @var array
	 */
	protected $field_config = array();

	/**
	 * @param array $args {
	 *     @type string   $format      csv|xlsx|json
	 *     @type string   $selection   all|selected|ids|skus|category|tag
	 *     @type array    $product_ids
	 *     @type array    $skus
	 *     @type array    $categories
	 *     @type array    $tags
	 *     @type array    $types       simple|variable|grouped|external
	 *     @type string   $status      publish|draft|pending|private|any
	 *     @type string   $date_created_after   Y-m-d — products created on/after this date.
	 *     @type string   $date_created_before  Y-m-d — products created on/before this date.
	 *     @type string   $date_modified_after  Y-m-d — products last modified on/after this date.
	 *     @type string   $date_modified_before Y-m-d — products last modified on/before this date.
	 *     @type array    $meta_rules  Passed straight through to AWPM_Meta_Handler::export_meta().
	 * }
	 * @return array { file_path, file_url, product_count }|WP_Error
	 */
	public function export( $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'format'     => 'json',
				'selection'  => 'all',
				'product_ids'=> array(),
				'skus'       => array(),
				'categories' => array(),
				'tags'       => array(),
				'types'      => array(),
				'status'     => 'any',
				'date_created_after'  => '',
				'date_created_before' => '',
				'date_modified_after' => '',
				'date_modified_before'=> '',
				'meta_rules' => array( 'mode' => 'export_all' ),
				'field_config' => array(),
				'limit'         => 0,
				'offset'        => 0,
				'product_names' => array(),
				'exclude_names' => array(),
				'exclude_ids'   => array(),
				'stock_status'  => '',
				'brand'         => array(),
			)
		);

		$this->field_config = $args['field_config'];

		$run_id = AWPM_Logger::start_run();

		$product_ids = $this->resolve_product_ids( $args );
		if ( empty( $product_ids ) ) {
			return new WP_Error( 'awpm_no_products', __( 'No products matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$records = array();
		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			$records[] = $this->build_record( $product, $args['meta_rules'] );
			AWPM_Logger::log( 'info', sprintf( 'Exported product #%d (%s)', $product_id, $product->get_sku() ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		// True .xlsx needs the ZipArchive PHP extension (bundled with PHP by
		// default, but not universally enabled on every host) — fall back to
		// CSV with an explicit log entry rather than silently mislabeling a
		// CSV file as .xlsx.
		$write_true_xlsx = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename         = 'awpm-export-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path        = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = AWPM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = AWPM_XLSX_Handler::write( $records, $file_path );
		} else {
			if ( 'xlsx' === $args['format'] ) {
				AWPM_Logger::log( 'warning', 'ZipArchive PHP extension not available — XLSX export was written as CSV instead.' );
			}
			$ok = AWPM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'awpm_write_failed', __( 'Could not write export file.', 'advanced-woo-product-migrator' ) );
		}

		return array(
			'file_path'     => $file_path,
			'file_url'      => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename,
			'product_count' => count( $records ),
			'run_id'        => $run_id,
		);
	}

	/* ---------------------------------------------------------------
	 * Batch/background job processing for large catalogs — mirrors
	 * AWPM_Product_Importer's job model. Product IDs are resolved once up
	 * front (cheap — it's just a list of IDs), then records are built and
	 * appended to the export file batch_size at a time so memory stays flat
	 * regardless of catalog size.
	 * ------------------------------------------------------------- */

	public function start_job( $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'format' => 'json', 'batch_size' => 50, 'meta_rules' => array( 'mode' => 'export_all' ), 'field_config' => array(),
				'limit' => 0, 'offset' => 0, 'product_names' => array(), 'exclude_names' => array(), 'exclude_ids' => array(), 'stock_status' => '', 'brand' => array(),
				'date_created_after' => '', 'date_created_before' => '', 'date_modified_after' => '', 'date_modified_before' => '',
			)
		);

		$product_ids = $this->resolve_product_ids( $args );
		if ( empty( $product_ids ) ) {
			return new WP_Error( 'awpm_no_products', __( 'No products matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = AWPM_Jobs::create_export_job(
			array(
				'status'     => 'pending',
				'format'     => $args['format'],
				'args'       => array_merge( $args, array( '_product_ids' => $product_ids ) ),
				'batch_size' => (int) $args['batch_size'],
				'total_rows' => count( $product_ids ),
			)
		);

		// Seed the (initially empty) JSON array file / CSV header so batches
		// can append. For true XLSX, the final file only gets assembled on
		// the last batch (see append_records_to_file()) — a ZIP archive's
		// central directory can't be incrementally appended to the way a
		// CSV/JSON file can — so the extension here reflects what the
		// FINISHED file will be, not what exists on disk mid-job.
		$xlsx_ok  = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename  = 'awpm-export-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		AWPM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename ) );

		AWPM_Logger::set_run_id( 'awpm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Export job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$product_ids = $job['args']['_product_ids'] ?? array();
		$offset      = (int) $job['offset_row'];
		$batch_ids   = array_slice( $product_ids, $offset, (int) $job['batch_size'] );

		try {
			$records = array();
			foreach ( $batch_ids as $product_id ) {
				$product = wc_get_product( $product_id );
				if ( $product ) {
					$this->field_config = $job['args']['field_config'] ?? array();
					$records[] = $this->build_record( $product, $job['args']['meta_rules'] ?? array( 'mode' => 'export_all' ) );
				}
			}

			$this->append_records_to_file( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch_ids ) ) >= count( $product_ids ) );
		} catch ( Exception $e ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			AWPM_Logger::log( 'error', sprintf( 'Export job #%d failed: %s', $job_id, $e->getMessage() ) );
			AWPM_Notifications::notify( 'export_failed', array( 'job_id' => $job_id, 'error' => $e->getMessage() ) );
			AWPM_Webhooks::dispatch( 'export.failed', array( 'job_id' => $job_id, 'error' => $e->getMessage() ) );
			return new WP_Error( 'awpm_export_batch_failed', $e->getMessage() );
		}

		AWPM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch_ids ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch_ids ) ) >= count( $product_ids ) || empty( $batch_ids );

		if ( $done ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'products' => (int) $job['processed_count'] + count( $records ) );
			AWPM_Webhooks::dispatch( 'export.completed', $totals );
			AWPM_Notifications::notify( 'export_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_export_job( $job_id ) );
	}

	/**
	 * Append a batch of records to the export file, streaming rather than
	 * holding the whole export in memory. JSON is appended as raw array
	 * elements between the wrapper's opening/closing brackets (written on
	 * the first/last batch); CSV appends rows after writing the header on
	 * the first batch (column set is taken from the first batch, which is
	 * safe here since AWPM only exports one product type set per job).
	 * XLSX can't be appended to incrementally the way CSV/JSON can (a ZIP
	 * archive's central directory has to be finalized in one go), so rows
	 * are staged in an NDJSON scratch file batch-by-batch and only
	 * assembled into a real .xlsx on the final batch.
	 */
	protected function append_records_to_file( $file_path, $format, $records, $is_first_batch, $is_last_batch ) {
		if ( 'json' === $format ) {
			$fh = fopen( $file_path, $is_first_batch ? 'w' : 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $is_first_batch ) {
				fwrite( $fh, '{"generator":"Advanced WooCommerce Product Migrator","version":"' . AWPM_VERSION . '","products":[' );
			}
			foreach ( $records as $i => $record ) {
				if ( ! $is_first_batch || $i > 0 ) {
					fwrite( $fh, ',' );
				}
				fwrite( $fh, wp_json_encode( $record, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
			}
			if ( $is_last_batch ) {
				fwrite( $fh, ']}' );
			}
			fclose( $fh );
			return;
		}

		if ( 'xlsx' === $format && AWPM_XLSX_Handler::is_available() ) {
			$scratch_path  = $file_path . '.scratch.ndjson';
			$rows          = array_map( array( 'AWPM_CSV_Handler', 'flatten_record' ), $records );
			$columns_key   = 'awpm_export_job_columns_' . basename( $file_path );

			if ( $is_first_batch ) {
				$columns = array();
				foreach ( $rows as $row ) {
					$columns = array_merge( $columns, array_keys( $row ) );
				}
				$columns = array_values( array_unique( $columns ) );
				update_option( $columns_key, $columns, false );
				$sfh = fopen( $scratch_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			} else {
				$columns = get_option( $columns_key, array() );
				$sfh     = fopen( $scratch_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}

			foreach ( $rows as $row ) {
				$line = array();
				foreach ( $columns as $col ) {
					$line[] = $row[ $col ] ?? '';
				}
				fwrite( $sfh, wp_json_encode( $line ) . "\n" );
			}
			fclose( $sfh );

			if ( $is_last_batch ) {
				AWPM_XLSX_Handler::write_from_ndjson( $scratch_path, $columns, $file_path );
				@unlink( $scratch_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				delete_option( $columns_key );
			}
			return;
		}

		// CSV (also the fallback for xlsx when ZipArchive isn't available —
		// $file_path already carries a .csv extension in that case, set by
		// start_job()): build rows for this batch, write header + rows on
		// the first batch, append rows thereafter.
		$rows = array_map( array( 'AWPM_CSV_Handler', 'flatten_record' ), $records );
		if ( $is_first_batch ) {
			$columns = array();
			foreach ( $rows as $row ) {
				$columns = array_merge( $columns, array_keys( $row ) );
			}
			$columns = array_values( array_unique( $columns ) );
			update_option( 'awpm_export_job_columns_' . basename( $file_path ), $columns, false );

			$fh = fopen( $file_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fwrite( $fh, "\xEF\xBB\xBF" );
			fputcsv( $fh, $columns );
		} else {
			$columns = get_option( 'awpm_export_job_columns_' . basename( $file_path ), array() );
			$fh      = fopen( $file_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = $row[ $col ] ?? '';
			}
			fputcsv( $fh, $line );
		}
		fclose( $fh );

		if ( $is_last_batch ) {
			delete_option( 'awpm_export_job_columns_' . basename( $file_path ) );
		}
	}

	/**
	 * Resolve the selection criteria to a flat list of product IDs
	 * (parent/simple products only — variations are pulled in per-parent
	 * inside build_record()).
	 *
	 * @param array $args
	 * @return int[]
	 */
	protected function resolve_product_ids( $args ) {
		$ids = $this->resolve_base_selection( $args );
		$ids = $this->apply_cross_filters( $ids, $args );

		// "Skip first n products" / "Total number of products to export".
		if ( ! empty( $args['offset'] ) && (int) $args['offset'] > 0 ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) && (int) $args['limit'] > 0 ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	/**
	 * The primary targeting query (spec's "Which products?" selector).
	 *
	 * @param array $args
	 * @return int[]
	 */
	protected function resolve_base_selection( $args ) {
		if ( 'ids' === $args['selection'] && ! empty( $args['product_ids'] ) ) {
			return array_map( 'absint', $args['product_ids'] );
		}

		if ( 'skus' === $args['selection'] && ! empty( $args['skus'] ) ) {
			$ids = array();
			foreach ( $args['skus'] as $sku ) {
				$id = wc_get_product_id_by_sku( $sku );
				if ( $id ) {
					$ids[] = $id;
				}
			}
			return $ids;
		}

		$query_args = array(
			'status'   => 'any' === $args['status'] ? array( 'publish', 'draft', 'pending', 'private' ) : array( $args['status'] ),
			'limit'    => -1,
			'return'   => 'ids',
			'type'     => ! empty( $args['types'] ) ? $args['types'] : '',
		);

		if ( 'category' === $args['selection'] && ! empty( $args['categories'] ) ) {
			$query_args['category'] = $args['categories'];
		}
		if ( 'tag' === $args['selection'] && ! empty( $args['tags'] ) ) {
			$query_args['tag'] = $args['tags'];
		}
		if ( 'selected' === $args['selection'] && ! empty( $args['product_ids'] ) ) {
			$query_args['include'] = array_map( 'absint', $args['product_ids'] );
		}

		return wc_get_products( $query_args );
	}

	/**
	 * Secondary, WebToffee-style narrowing filters that apply on top of
	 * whatever the primary selection returned, regardless of which
	 * selection mode was used: product name search, exclude list, stock
	 * status, and brand (only if a brand taxonomy is actually registered
	 * on this site — never assumed).
	 *
	 * @param int[] $ids
	 * @param array $args
	 * @return int[]
	 */
	protected function apply_cross_filters( $ids, $args ) {
		if ( ! empty( $args['product_names'] ) ) {
			$matched = array();
			foreach ( $args['product_names'] as $name ) {
				$name = trim( $name );
				if ( '' === $name ) {
					continue;
				}
				$found = get_posts(
					array(
						'post_type'      => 'product',
						'post_status'    => 'any',
						's'              => $name,
						'posts_per_page' => -1,
						'fields'         => 'ids',
					)
				);
				$matched = array_merge( $matched, $found );
			}
			$ids = array_values( array_intersect( $ids, array_unique( $matched ) ) );
		}

		if ( ! empty( $args['exclude_names'] ) ) {
			$excluded = array();
			foreach ( $args['exclude_names'] as $name ) {
				$name = trim( $name );
				if ( '' === $name ) {
					continue;
				}
				$found = get_posts(
					array(
						'post_type'      => 'product',
						'post_status'    => 'any',
						's'              => $name,
						'posts_per_page' => -1,
						'fields'         => 'ids',
					)
				);
				$excluded = array_merge( $excluded, $found );
			}
			$ids = array_values( array_diff( $ids, $excluded ) );
		}
		if ( ! empty( $args['exclude_ids'] ) ) {
			$ids = array_values( array_diff( $ids, array_map( 'absint', $args['exclude_ids'] ) ) );
		}

		if ( ! empty( $args['stock_status'] ) && 'any' !== $args['stock_status'] ) {
			$ids = array_values(
				array_filter(
					$ids,
					function ( $id ) use ( $args ) {
						return get_post_meta( $id, '_stock_status', true ) === $args['stock_status'];
					}
				)
			);
		}

		if ( ! empty( $args['brand'] ) && taxonomy_exists( 'product_brand' ) ) {
			$ids = array_values(
				array_filter(
					$ids,
					function ( $id ) use ( $args ) {
						return has_term( $args['brand'], 'product_brand', $id );
					}
				)
			);
		}

		// Date created / Date modified range filters — available regardless
		// of which primary selection mode was used, matching the spec's
		// listing of "Date range" and "Modified date" as independent
		// filter fields rather than an exclusive selection mode.
		if ( ! empty( $args['date_created_after'] ) || ! empty( $args['date_created_before'] ) ) {
			$ids = array_values( array_filter( $ids, function ( $id ) use ( $args ) {
				return self::date_in_range( get_post_field( 'post_date', $id ), $args['date_created_after'] ?? '', $args['date_created_before'] ?? '' );
			} ) );
		}
		if ( ! empty( $args['date_modified_after'] ) || ! empty( $args['date_modified_before'] ) ) {
			$ids = array_values( array_filter( $ids, function ( $id ) use ( $args ) {
				return self::date_in_range( get_post_field( 'post_modified', $id ), $args['date_modified_after'] ?? '', $args['date_modified_before'] ?? '' );
			} ) );
		}

		return $ids;
	}

	protected static function date_in_range( $date_string, $after, $before ) {
		$ts = strtotime( $date_string );
		if ( ! $ts ) {
			return false;
		}
		if ( $after && $ts < strtotime( $after ) ) {
			return false;
		}
		if ( $before && $ts > strtotime( $before . ' 23:59:59' ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Build the complete portable export record for one product.
	 *
	 * @param WC_Product $product
	 * @param array      $meta_rules
	 * @return array
	 */
	public function build_record( $product, $meta_rules = array() ) {
		$product_id = $product->get_id();

		$record = array(
			'source_site'        => site_url(),
			'product_id'         => $product_id,
			'external_id'        => get_post_meta( $product_id, AWPM_Relationship_Map::META_KEY, true ) ?: (string) $product_id,
			'type'               => $product->get_type(),
			'name'               => $product->get_name(),
			'slug'               => $product->get_slug(),
			'description'        => $product->get_description(),
			'short_description'  => $product->get_short_description(),
			'sku'                => $product->get_sku(),
			'status'             => $product->get_status(),
			'catalog_visibility' => $product->get_catalog_visibility(),
			'featured'           => $product->get_featured(),
			'menu_order'         => $product->get_menu_order(),

			'regular_price'      => $product->get_regular_price(),
			'sale_price'         => $product->get_sale_price(),
			'date_on_sale_from'  => $this->format_date( $product->get_date_on_sale_from() ),
			'date_on_sale_to'    => $this->format_date( $product->get_date_on_sale_to() ),

			'manage_stock'       => $product->get_manage_stock(),
			'stock_quantity'     => $product->get_stock_quantity(),
			'stock_status'       => $product->get_stock_status(),
			'backorders'         => $product->get_backorders(),
			'sold_individually'  => $product->get_sold_individually(),

			'weight'             => $product->get_weight(),
			'length'             => $product->get_length(),
			'width'              => $product->get_width(),
			'height'             => $product->get_height(),
			'shipping_class'     => $product->get_shipping_class(),

			'tax_status'         => $product->get_tax_status(),
			'tax_class'          => $product->get_tax_class(),

			'virtual'            => $product->get_virtual(),
			'downloadable'       => $product->get_downloadable(),
			'purchase_note'      => $product->get_purchase_note(),
			'download_limit'     => $product->get_download_limit(),
			'download_expiry'    => $product->get_download_expiry(),
			'downloads'          => $this->export_downloads( $product ),

			'upsell_skus'        => $this->ids_to_skus( $product->get_upsell_ids() ),
			'cross_sell_skus'    => $this->ids_to_skus( $product->get_cross_sell_ids() ),

			'categories'         => AWPM_Category_Handler::export_product_categories( $product_id ),
			'tags'               => wp_list_pluck( get_the_terms( $product_id, 'product_tag' ) ?: array(), 'name' ),

			'featured_image'     => $this->export_image_id( $product->get_image_id() ),
			'gallery_images'     => array_map( array( $this, 'export_image_id' ), $product->get_gallery_image_ids() ),

			'attributes'         => AWPM_Attribute_Handler::export_attributes( $product ),
		);

		if ( $product->is_type( 'grouped' ) ) {
			$record['grouped_skus'] = $this->ids_to_skus( $product->get_children() );
		}

		if ( $product->is_type( 'external' ) && method_exists( $product, 'get_product_url' ) ) {
			$record['product_url'] = $product->get_product_url();
			$record['button_text'] = $product->get_button_text();
		}

		if ( $product->is_type( 'variable' ) ) {
			$record['default_attributes'] = $product->get_default_attributes();
			$record['variations']         = $this->export_variations( $product );
		}

		if ( AWPM_ACF_Handler::is_active() ) {
			$record['acf'] = AWPM_ACF_Handler::export_fields( $product_id );
		}
		if ( AWPM_Yoast_Handler::is_active() ) {
			$record['yoast'] = AWPM_Yoast_Handler::export_fields( $product_id );
		}

		$record['custom_meta'] = AWPM_Meta_Handler::export_meta( $product_id, $meta_rules );

		if ( ! empty( $this->field_config ) ) {
			$record = $this->apply_field_selection( $record );
		}

		return apply_filters( 'awpm_export_record', $record, $product );
	}

	/**
	 * Filter a fully-built record down to only the fields the user checked
	 * in the Export wizard's field-selection step. Identity fields needed
	 * for any future re-import (source_site, product_id, external_id,
	 * type) are always kept regardless of selection, since dropping them
	 * would silently break update-matching on the next import — the user
	 * can still exclude sku itself if they explicitly uncheck it.
	 *
	 * $this->field_config['enabled'] is a flat list of dotted keys in the
	 * same vocabulary AWPM_Field_Registry uses for mapping targets:
	 * top-level keys as-is ('name', 'categories', 'attributes', ...) and
	 * 'acf.<name>' / 'yoast.<key>' / 'custom_meta.<key>' for sub-fields.
	 * Only top-level ACF field names are selectable — a repeater's
	 * internal rows aren't independently prunable without corrupting the
	 * structure, so enabling 'acf.specifications' keeps the whole
	 * repeater.
	 *
	 * @param array $record
	 * @return array
	 */
	protected function apply_field_selection( $record ) {
		$enabled = array_flip( $this->field_config['enabled'] ?? array() );
		$always_keep = array( 'source_site', 'product_id', 'external_id', 'type' );

		foreach ( $record as $key => $value ) {
			if ( in_array( $key, $always_keep, true ) ) {
				continue;
			}
			if ( 'acf' === $key && is_array( $value ) ) {
				$record['acf'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 4 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'acf.' ); } ) ) ) );
				continue;
			}
			if ( 'yoast' === $key && is_array( $value ) ) {
				$record['yoast'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 6 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'yoast.' ); } ) ) ) );
				continue;
			}
			if ( 'custom_meta' === $key && is_array( $value ) ) {
				$record['custom_meta'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 12 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'custom_meta.' ); } ) ) ) );
				continue;
			}
			if ( ! isset( $enabled[ $key ] ) ) {
				unset( $record[ $key ] );
			}
		}

		return $record;
	}

	/**
	 * Export every variation of a variable product with the same depth of
	 * data as a simple product (minus fields that don't apply).
	 *
	 * @param WC_Product_Variable $product
	 * @return array[]
	 */
	protected function export_variations( $product ) {
		$out = array();

		foreach ( $product->get_children() as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$row = array(
				'variation_id'    => $variation_id,
				'parent_id'       => $product->get_id(),
				'sku'             => $variation->get_sku(),
				'regular_price'   => $variation->get_regular_price(),
				'sale_price'      => $variation->get_sale_price(),
				'stock_quantity'  => $variation->get_stock_quantity(),
				'stock_status'    => $variation->get_stock_status(),
				'manage_stock'    => $variation->get_manage_stock(),
				'weight'          => $variation->get_weight(),
				'length'          => $variation->get_length(),
				'width'           => $variation->get_width(),
				'height'          => $variation->get_height(),
				'virtual'         => $variation->get_virtual(),
				'downloadable'    => $variation->get_downloadable(),
				'downloads'       => $this->export_downloads( $variation ),
				'description'     => $variation->get_description(),
				'image'           => $this->export_image_id( $variation->get_image_id() ),
				'attributes'      => AWPM_Attribute_Handler::export_variation_attributes( $variation ),
				'menu_order'      => $variation->get_menu_order(),
				'status'          => $variation->get_status(),
			);

			if ( AWPM_ACF_Handler::is_active() ) {
				$row['acf'] = AWPM_ACF_Handler::export_fields( $variation_id );
			}
			$row['custom_meta'] = AWPM_Meta_Handler::export_meta( $variation_id, array( 'mode' => 'export_all' ) );

			$out[] = $row;
		}

		return $out;
	}

	protected function export_image_id( $attachment_id ) {
		if ( ! $attachment_id ) {
			return null;
		}
		return AWPM_ACF_Handler::export_attachment_ref( $attachment_id );
	}

	protected function export_downloads( $product ) {
		$downloads = array();
		foreach ( $product->get_downloads() as $download ) {
			/** @var WC_Product_Download $download */
			$downloads[] = array(
				'name' => $download->get_name(),
				'file' => $download->get_file(),
			);
		}
		return $downloads;
	}

	protected function ids_to_skus( $ids ) {
		$skus = array();
		foreach ( (array) $ids as $id ) {
			$sku = get_post_meta( $id, '_sku', true );
			if ( $sku ) {
				$skus[] = $sku;
			}
		}
		return $skus;
	}

	protected function format_date( $date ) {
		return $date ? $date->date( 'Y-m-d H:i:s' ) : '';
	}
}
