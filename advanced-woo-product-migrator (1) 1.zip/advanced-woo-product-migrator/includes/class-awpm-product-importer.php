<?php
/**
 * AWPM_Product_Importer
 *
 * Reads rows from CSV/JSON, applies the user's field mapping, resolves
 * existing-product matching (SKU / ID / slug), and creates or updates
 * WooCommerce products — including full variable product + variation
 * handling, attributes (global + local), categories, images, ACF, Yoast
 * and custom meta. Supports a dry-run mode that reports exactly what
 * would happen without writing anything.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Product_Importer {

	/**
	 * Read a source file into an array of raw rows, dispatching on format.
	 * The one place all four import entry points (import(), start_job(),
	 * process_next_batch(), preview_rows()) go through, so JSON/CSV/XLSX
	 * support stays in exactly one spot.
	 *
	 * @param string $file_path
	 * @param string $format json|csv|xlsx
	 * @return array[]|WP_Error
	 */
	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return AWPM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return AWPM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return AWPM_CSV_Handler::read( $file_path );
		}
	}

	/**
	 * @param array $args {
	 *     @type string $file_path
	 *     @type string $format          csv|json
	 *     @type array  $mapping         source_column => target_field (only used for CSV with non-native headers; JSON exported by this plugin is self-describing and mapping is optional).
	 *     @type string $match_strategy  sku|product_id|slug|none (none = always create).
	 *     @type string $existing_action skip|update|duplicate
	 *     @type array  $options {
	 *         create_missing_global_attributes: bool,
	 *         create_missing_categories: bool,
	 *         image_match_strategy: string,
	 *     }
	 *     @type bool   $dry_run
	 * }
	 * @return array|WP_Error Summary: { new, updated, skipped, errors[], run_id, dry_run }
	 */
	public function import( $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'file_path'       => '',
				'format'          => 'json',
				'mapping'         => array(),
				'match_strategy'  => 'sku',
				'existing_action' => 'update',
				'options'         => array(),
				'dry_run'         => false,
			)
		);

		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$run_id = AWPM_Logger::start_run();

		$summary = array(
			'new'      => 0,
			'updated'  => 0,
			'skipped'  => 0,
			'duplicated' => 0,
			'errors'   => array(),
			'categories_to_create' => array(),
			'attributes_to_create' => array(),
			'run_id'   => $run_id,
			'dry_run'  => (bool) $args['dry_run'],
			'total'    => count( $rows ),
		);

		foreach ( $rows as $i => $raw_row ) {
			try {
				$record             = $this->apply_mapping( $raw_row, $args['mapping'], $args['format'], $args['transforms'] ?? array() );
				$args['_row_index'] = $i;
				$this->process_record( $record, $args, $summary );
			} catch ( Exception $e ) {
				$summary['errors'][] = sprintf( 'Row %d: %s', $i + 1, $e->getMessage() );
				AWPM_Logger::log( 'error', sprintf( 'Row %d failed: %s', $i + 1, $e->getMessage() ) );
				if ( ! empty( $args['job_id'] ) ) {
					AWPM_Jobs::add_import_item( $args['job_id'], $i, $raw_row['sku'] ?? '', null, 'error', $e->getMessage() );
					AWPM_Jobs::increment_import_counts( $args['job_id'], 0, 0, 0, 1 );
				}
			}
		}

		return $summary;
	}

	/* ---------------------------------------------------------------
	 * Batch/background job processing — used by the "large dataset"
	 * requirement (spec #48/#49/#75) so a 10k+ row import is never run in
	 * a single blocking PHP request. AWPM_Ajax::process_import_batch()
	 * calls process_next_batch() once per AJAX tick from the browser, and
	 * AWPM_Scheduler::advance_pending_batches() calls it from WP-Cron as a
	 * safety net if the browser tab closes mid-import.
	 * ------------------------------------------------------------- */

	/**
	 * Create a tracked job row and return its ID. The file is read once
	 * here just to get an accurate total row count for the progress bar;
	 * actual row data is re-read per batch in process_next_batch() so we
	 * never hold the whole dataset in PHP memory across requests.
	 *
	 * @param array $args Same shape as import(), minus dry_run (set per-call to process_next_batch if needed).
	 * @return int|WP_Error Job ID.
	 */
	public function start_job( $args ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = AWPM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array_merge(
					$args['options'] ?? array(),
					array( 'match_strategy' => $args['match_strategy'] ?? 'sku', 'existing_action' => $args['existing_action'] ?? 'update', 'transforms' => $args['transforms'] ?? array() )
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 50,
				'total_rows'  => count( $rows ),
				'mapping_profile_id' => $args['mapping_profile_id'] ?? null,
			)
		);

		AWPM_Logger::set_run_id( 'awpm_run_job_' . $job_id, 'import', $job_id );
		set_transient( 'awpm_run_job_' . $job_id, array(), 6 * HOUR_IN_SECONDS );

		return $job_id;
	}

	/**
	 * Advance one job by exactly `batch_size` rows and persist progress.
	 * Idempotent to call repeatedly — always resumes from the job's own
	 * `offset_row`, so a page reload / lost connection mid-import just
	 * means the next poll picks up where it left off.
	 *
	 * @param int $job_id
	 * @return array|WP_Error { done: bool, job: array }
	 */
	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Import job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}

		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
			AWPM_Webhooks::dispatch( 'import.started', array( 'job_id' => $job_id ) );
		}

		AWPM_Logger::set_run_id( 'awpm_run_job_' . $job_id, 'import', $job_id );

		$rows = $this->read_rows( $job['file_path'], $job['format'] );

		if ( is_wp_error( $rows ) ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			AWPM_Notifications::notify( 'import_failed', array( 'job_id' => $job_id, 'error' => $rows->get_error_message() ) );
			AWPM_Webhooks::dispatch( 'import.failed', array( 'job_id' => $job_id, 'error' => $rows->get_error_message() ) );
			return $rows;
		}

		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $rows, $offset, (int) $job['batch_size'] );

		$options = $job['options'];
		$args    = array(
			'mapping'         => $job['mapping'],
			'match_strategy'  => $options['match_strategy'] ?? 'sku',
			'existing_action' => $options['existing_action'] ?? 'update',
			'options'         => $options,
			'dry_run'         => (bool) $job['dry_run'],
			'job_id'          => $job_id,
		);

		$summary = array( 'new' => 0, 'updated' => 0, 'skipped' => 0, 'duplicated' => 0, 'errors' => array(), 'categories_to_create' => array(), 'attributes_to_create' => array() );

		foreach ( $batch as $i => $raw_row ) {
			$row_index          = $offset + $i;
			$args['_row_index'] = $row_index;
			try {
				$record = $this->apply_mapping( $raw_row, $args['mapping'], $job['format'], $job['options']['transforms'] ?? array() );
				$this->process_record( $record, $args, $summary );
			} catch ( Exception $e ) {
				AWPM_Jobs::add_import_item( $job_id, $row_index, $raw_row['sku'] ?? '', null, 'error', $e->getMessage() );
				$summary['errors'][] = $e->getMessage();
			}
		}

		AWPM_Jobs::increment_import_counts( $job_id, $summary['new'], $summary['updated'], $summary['skipped'], count( $summary['errors'] ), count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'created' => $job['created_count'] + $summary['new'], 'updated' => $job['updated_count'] + $summary['updated'], 'skipped' => $job['skipped_count'] + $summary['skipped'], 'failed' => $job['failed_count'] + count( $summary['errors'] ) );
			AWPM_Webhooks::dispatch( 'import.completed', $totals );
			AWPM_Notifications::notify( 'import_completed', $totals );
			if ( $totals['failed'] > 0 ) {
				AWPM_Notifications::notify( 'import_failed', array_merge( $totals, array( 'error' => sprintf( '%d row(s) failed — see Import Logs for job #%d.', $totals['failed'], $job_id ) ) ) );
			}
			AWPM_Logger::log( 'info', sprintf( 'Import job #%d complete.', $job_id ) );
		}

		return array(
			'done'    => $done,
			'job'     => AWPM_Jobs::get_import_job( $job_id ),
			'batch_categories_to_create' => $summary['categories_to_create'],
			'batch_attributes_to_create' => $summary['attributes_to_create'],
		);
	}

	/**
	 * For JSON exported by this plugin, the record is already in our
	 * canonical shape — no mapping needed. For CSV (or a foreign
	 * CSV/JSON whose columns don't match our field keys 1:1), apply the
	 * user-defined source_column => target_field mapping to rename keys
	 * into our canonical shape before processing, running each column's
	 * configured transform (Step 3's Transform modal) first.
	 *
	 * @param array  $raw_row
	 * @param array  $mapping     source_column => target_field.
	 * @param string $format
	 * @param array  $transforms  source_column => transform config, applied before mapping.
	 * @return array
	 */
	protected function apply_mapping( $raw_row, $mapping, $format, $transforms = array() ) {
		if ( ! empty( $transforms ) ) {
			foreach ( $transforms as $source_column => $config ) {
				if ( array_key_exists( $source_column, $raw_row ) ) {
					$raw_row[ $source_column ] = AWPM_Transformer::apply( $raw_row[ $source_column ], $config );
				}
			}
		}

		if ( empty( $mapping ) ) {
			return $raw_row; // Assume native/canonical column names already.
		}

		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$this->set_dotted( $record, $target_field, $raw_row[ $source_column ] );
		}

		// Anything not explicitly mapped but already using a canonical key
		// (e.g. re-importing our own JSON with a partial mapping override)
		// passes through untouched.
		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}

		return $record;
	}

	/**
	 * Set a value into a nested array using "acf.material" style dotted
	 * target field notation from the mapping UI.
	 */
	protected function set_dotted( &$array, $dotted_key, $value ) {
		$parts = explode( '.', $dotted_key );
		$ref   = &$array;
		foreach ( $parts as $i => $part ) {
			if ( $i === count( $parts ) - 1 ) {
				$ref[ $part ] = $value;
			} else {
				if ( ! isset( $ref[ $part ] ) || ! is_array( $ref[ $part ] ) ) {
					$ref[ $part ] = array();
				}
				$ref = &$ref[ $part ];
			}
		}
	}

	/**
	 * Process one mapped product record: resolve existing/new, and either
	 * simulate (dry run) or write it.
	 *
	 * @param array $record
	 * @param array $args
	 * @param array $summary (by reference)
	 * @return void
	 */
	protected function process_record( $record, $args, &$summary ) {
		$existing_id = $this->find_existing_product( $record, $args['match_strategy'] );

		if ( $existing_id ) {
			switch ( $args['existing_action'] ) {
				case 'skip':
					$summary['skipped']++;
					return;
				case 'duplicate':
					$existing_id = null; // Fall through to create-new below.
					$summary['duplicated']++;
					break;
				case 'update':
				default:
					$summary['updated']++;
					break;
			}
		} else {
			$summary['new']++;
		}

		// Track categories/attributes that don't exist yet, for the dry-run report.
		foreach ( (array) ( $record['categories'] ?? array() ) as $path ) {
			$leaf = is_array( $path ) ? end( $path ) : $path;
			$name = is_array( $leaf ) ? ( $leaf['name'] ?? '' ) : $leaf;
			if ( $name && ! AWPM_Category_Handler::resolve_path( $path, 'product_cat', false ) ) {
				$summary['categories_to_create'][] = $name;
			}
		}
		foreach ( (array) ( $record['attributes'] ?? array() ) as $attr ) {
			if ( ! empty( $attr['is_global'] ) && ! taxonomy_exists( wc_attribute_taxonomy_name( str_replace( 'pa_', '', $attr['name'] ) ) ) ) {
				$summary['attributes_to_create'][] = $attr['label'] ?? $attr['name'];
			}
		}

		if ( $args['dry_run'] ) {
			$this->log_item( $args, $record, $existing_id ? 'success' : 'success', $existing_id ? 'Would update' : 'Would create' );
			return; // Report-only — nothing written.
		}

		// Real rollback support: snapshot the product's current state before
		// we overwrite it, so a later "Rollback" actually restores it rather
		// than just being a label.
		if ( $existing_id && ! empty( $args['job_id'] ) && ! empty( $args['options']['create_backup'] ) ) {
			AWPM_Snapshot::capture( $args['job_id'], $existing_id );
		}

		$product_id = $this->write_product( $record, $existing_id, $args['options'] );

		if ( ! $existing_id && ! empty( $args['job_id'] ) ) {
			AWPM_Snapshot::record_created( $args['job_id'], $product_id );
		}

		// Maintain the source->target relationship map so a repeated import
		// from the same source always resolves back to the same product,
		// and so ACF relationship/post_object fields and upsells/cross-sells
		// exported from THIS product can be resolved on a future migration.
		$external_id = $record['external_id'] ?? ( $record['product_id'] ?? '' );
		if ( $external_id ) {
			AWPM_Relationship_Map::set_mapping( 'default', (string) $external_id, $product_id, 'product', (string) $external_id );
		}

		AWPM_Logger::log( 'info', sprintf( '%s product #%d (%s)', $existing_id ? 'Updated' : 'Created', $product_id, $record['sku'] ?? '' ) );
		$this->log_item( $args, $record, 'success', $existing_id ? 'Updated' : 'Created', $product_id );
	}

	/**
	 * Persist a per-row outcome to wp_awpm_import_items when running as a
	 * tracked job (Import Logs / Import Preview screens read this table).
	 */
	protected function log_item( $args, $record, $result, $message, $product_id = null ) {
		if ( empty( $args['job_id'] ) ) {
			return;
		}
		AWPM_Jobs::add_import_item( $args['job_id'], $args['_row_index'] ?? 0, $record['sku'] ?? '', $product_id, $result, $message );
	}

	/**
	 * @param array  $record
	 * @param string $strategy sku|product_id|slug|external_id|none
	 * @return int|null
	 */
	protected function find_existing_product( $record, $strategy ) {
		switch ( $strategy ) {
			case 'sku':
				if ( ! empty( $record['sku'] ) ) {
					$id = wc_get_product_id_by_sku( $record['sku'] );
					if ( $id ) {
						return $id;
					}
				}
				// Fall back to product_id/slug per spec ("Update by SKU... Fallback to Product ID / Slug").
				return $this->find_existing_product( $record, 'product_id' ) ?: $this->find_existing_product( $record, 'slug' );

			case 'external_id':
				$external_id = $record['external_id'] ?? '';
				if ( $external_id ) {
					$id = AWPM_Relationship_Map::resolve( 'default', $external_id );
					if ( $id ) {
						return $id;
					}
				}
				return $this->find_existing_product( $record, 'sku' );

			case 'product_id':
				if ( ! empty( $record['product_id'] ) && 'product' === get_post_type( $record['product_id'] ) ) {
					return (int) $record['product_id'];
				}
				return null;

			case 'slug':
				if ( ! empty( $record['slug'] ) ) {
					$page = get_page_by_path( $record['slug'], OBJECT, 'product' );
					return $page ? $page->ID : null;
				}
				return null;

			case 'none':
			default:
				return null;
		}
	}

	/**
	 * Create or update the WooCommerce product (and, for variable
	 * products, all its variations) from a mapped record.
	 *
	 * @param array    $record
	 * @param int|null $existing_id
	 * @param array    $options
	 * @return int Product ID.
	 */
	/**
	 * Instantiate the correct WC_Product subclass for a given type slug via
	 * WooCommerce's own factory resolution (WC_Product_Factory::get_product_classname())
	 * rather than a hardcoded simple/variable check. This is what makes
	 * Grouped and External/Affiliate products actually import as the right
	 * object — previously this always produced a Simple or Variable
	 * product regardless of the record's real type — and it also means any
	 * type a third-party plugin registers (e.g. WooCommerce Subscriptions'
	 * "subscription" type) resolves to ITS class automatically, since that
	 * factory method applies the same `woocommerce_product_class` filter
	 * WooCommerce itself uses everywhere else.
	 *
	 * @param string $type
	 * @param int    $existing_id 0 for a new product.
	 * @return WC_Product
	 */
	protected function instantiate_product( $type, $existing_id = 0 ) {
		$classname = WC_Product_Factory::get_product_classname( $existing_id, $type );
		if ( ! $classname || ! class_exists( $classname ) ) {
			$classname = 'WC_Product_Simple'; // Safe fallback for an unrecognized/unregistered type.
		}
		return new $classname( $existing_id );
	}

	protected function write_product( $record, $existing_id, $options ) {
		$type = ! empty( $record['variations'] ) || 'variable' === ( $record['type'] ?? '' ) ? 'variable' : ( $record['type'] ?? 'simple' );

		if ( $existing_id ) {
			$product = wc_get_product( $existing_id );
			if ( ! $product || $product->get_type() !== $type ) {
				// Type changed (e.g. simple -> variable) — WooCommerce can't
				// morph the object in place, so re-create it as the right class
				// while keeping the same post ID.
				$product = $this->instantiate_product( $type, $existing_id );
			}
		} else {
			$product = $this->instantiate_product( $type );
		}

		$this->apply_core_fields( $product, $record );
		$this->apply_taxonomy( $product, $record, $options );
		$this->apply_images( $product, $record, $options );

		if ( ! empty( $record['attributes'] ) ) {
			$product->set_attributes( AWPM_Attribute_Handler::import_attributes( $product, $record['attributes'], $options ) );
		}
		if ( 'variable' === $type && ! empty( $record['default_attributes'] ) ) {
			$product->set_default_attributes( $record['default_attributes'] );
		}

		if ( ! empty( $record['upsell_skus'] ) ) {
			$product->set_upsell_ids( $this->skus_to_ids( $record['upsell_skus'] ) );
		}
		if ( ! empty( $record['cross_sell_skus'] ) ) {
			$product->set_cross_sell_ids( $this->skus_to_ids( $record['cross_sell_skus'] ) );
		}
		if ( 'grouped' === $type && ! empty( $record['grouped_skus'] ) ) {
			$product->set_children( $this->skus_to_ids( $record['grouped_skus'] ) );
		}

		$product_id = $product->save();

		if ( ! empty( $record['acf'] ) ) {
			AWPM_ACF_Handler::import_fields( $product_id, $record['acf'], $options );
		}
		if ( ! empty( $record['yoast'] ) ) {
			AWPM_Yoast_Handler::import_fields( $product_id, $record['yoast'] );
		}
		if ( ! empty( $record['custom_meta'] ) ) {
			AWPM_Meta_Handler::import_meta( $product_id, $record['custom_meta'], $options );
		}

		if ( 'variable' === $type && ! empty( $record['variations'] ) ) {
			$this->write_variations( $product_id, $record['variations'], $options );
			// Variable products need their price range / "has_variations"
			// caches resynced after variations are (re)written.
			$parent = wc_get_product( $product_id );
			if ( $parent ) {
				WC_Product_Variable::sync( $product_id );
				$parent->save();
			}
		}

		return $product_id;
	}

	protected function apply_core_fields( $product, $record ) {
		$map = array(
			'name' => 'set_name', 'slug' => 'set_slug', 'description' => 'set_description',
			'short_description' => 'set_short_description', 'sku' => 'set_sku', 'status' => 'set_status',
			'catalog_visibility' => 'set_catalog_visibility', 'featured' => 'set_featured', 'menu_order' => 'set_menu_order',
			'regular_price' => 'set_regular_price', 'sale_price' => 'set_sale_price',
			'date_on_sale_from' => 'set_date_on_sale_from', 'date_on_sale_to' => 'set_date_on_sale_to',
			'manage_stock' => 'set_manage_stock', 'stock_quantity' => 'set_stock_quantity',
			'stock_status' => 'set_stock_status', 'backorders' => 'set_backorders',
			'sold_individually' => 'set_sold_individually',
			'weight' => 'set_weight', 'length' => 'set_length', 'width' => 'set_width', 'height' => 'set_height',
			'shipping_class' => 'set_shipping_class', 'tax_status' => 'set_tax_status', 'tax_class' => 'set_tax_class',
			'virtual' => 'set_virtual', 'downloadable' => 'set_downloadable', 'purchase_note' => 'set_purchase_note',
			'download_limit' => 'set_download_limit', 'download_expiry' => 'set_download_expiry',
			// External/Affiliate-only fields — method_exists() below means these
			// are silently skipped for every other product type; they only take
			// effect once instantiate_product() has created a real
			// WC_Product_External (see the type-instantiation fix above).
			'product_url' => 'set_product_url', 'button_text' => 'set_button_text',
		);

		foreach ( $map as $key => $setter ) {
			if ( array_key_exists( $key, $record ) && '' !== $record[ $key ] && null !== $record[ $key ] && method_exists( $product, $setter ) ) {
				$product->{$setter}( $record[ $key ] );
			}
		}

		if ( ! empty( $record['downloads'] ) ) {
			$downloads = array();
			foreach ( $record['downloads'] as $d ) {
				$download = new WC_Product_Download();
				$download->set_id( md5( $d['file'] ) );
				$download->set_name( $d['name'] );
				$download->set_file( $d['file'] );
				$downloads[] = $download;
			}
			$product->set_downloads( $downloads );
		}
	}

	protected function apply_taxonomy( $product, $record, $options ) {
		$create_missing_cat = $options['create_missing_categories'] ?? true;

		if ( isset( $record['categories'] ) ) {
			$cat_ids = array();
			foreach ( (array) $record['categories'] as $path ) {
				$id = AWPM_Category_Handler::resolve_path( $path, 'product_cat', $create_missing_cat );
				if ( $id ) {
					$cat_ids[] = $id;
				}
			}
			$product->set_category_ids( $cat_ids );
		}

		if ( isset( $record['tags'] ) ) {
			$tag_ids = array();
			foreach ( (array) $record['tags'] as $tag_name ) {
				$id = AWPM_Category_Handler::resolve_tag( $tag_name, $create_missing_cat );
				if ( $id ) {
					$tag_ids[] = $id;
				}
			}
			$product->set_tag_ids( $tag_ids );
		}
	}

	protected function apply_images( $product, $record, $options ) {
		if ( ! empty( $record['featured_image'] ) ) {
			$id = AWPM_Image_Handler::resolve_attachment( $record['featured_image'], $options );
			if ( $id ) {
				$product->set_image_id( $id );
			}
		}
		if ( isset( $record['gallery_images'] ) ) {
			$ids = AWPM_Image_Handler::resolve_gallery( $record['gallery_images'], $options );
			$product->set_gallery_image_ids( $ids );
		}
	}

	/**
	 * Create/update every variation in the export, matching existing
	 * variations by SKU (falling back to attribute-combination match),
	 * and removing variations on the destination that are no longer in
	 * the import unless they're excluded from that behaviour via the
	 * `awpm_prune_removed_variations` filter.
	 *
	 * @param int   $parent_id
	 * @param array $variations_data
	 * @param array $options
	 * @return void
	 */
	protected function write_variations( $parent_id, $variations_data, $options ) {
		$existing_variation_ids = wc_get_products(
			array( 'type' => 'variation', 'parent' => $parent_id, 'limit' => -1, 'return' => 'ids' )
		);
		$seen_ids = array();

		foreach ( $variations_data as $v_record ) {
			$variation_id = null;

			if ( ! empty( $v_record['sku'] ) ) {
				$variation_id = wc_get_product_id_by_sku( $v_record['sku'] );
			}
			if ( ! $variation_id && ! empty( $v_record['variation_id'] ) && in_array( (int) $v_record['variation_id'], $existing_variation_ids, true ) ) {
				$variation_id = (int) $v_record['variation_id'];
			}

			$variation = $variation_id ? wc_get_product( $variation_id ) : new WC_Product_Variation();
			$variation->set_parent_id( $parent_id );

			$field_map = array(
				'sku' => 'set_sku', 'regular_price' => 'set_regular_price', 'sale_price' => 'set_sale_price',
				'stock_quantity' => 'set_stock_quantity', 'stock_status' => 'set_stock_status',
				'manage_stock' => 'set_manage_stock', 'weight' => 'set_weight', 'length' => 'set_length',
				'width' => 'set_width', 'height' => 'set_height', 'virtual' => 'set_virtual',
				'downloadable' => 'set_downloadable', 'description' => 'set_description',
				'menu_order' => 'set_menu_order', 'status' => 'set_status',
			);
			foreach ( $field_map as $key => $setter ) {
				if ( array_key_exists( $key, $v_record ) && '' !== $v_record[ $key ] && null !== $v_record[ $key ] ) {
					$variation->{$setter}( $v_record[ $key ] );
				}
			}

			if ( ! empty( $v_record['attributes'] ) ) {
				$variation->set_attributes( AWPM_Attribute_Handler::import_variation_attributes( $v_record['attributes'] ) );
			}
			if ( ! empty( $v_record['image'] ) ) {
				$img_id = AWPM_Image_Handler::resolve_attachment( $v_record['image'], $options );
				if ( $img_id ) {
					$variation->set_image_id( $img_id );
				}
			}

			$new_id = $variation->save();
			$seen_ids[] = $new_id;

			if ( ! empty( $v_record['acf'] ) ) {
				AWPM_ACF_Handler::import_fields( $new_id, $v_record['acf'], $options );
			}
			if ( ! empty( $v_record['custom_meta'] ) ) {
				AWPM_Meta_Handler::import_meta( $new_id, $v_record['custom_meta'], $options );
			}
		}

		$should_prune = apply_filters( 'awpm_prune_removed_variations', true, $parent_id );
		if ( $should_prune ) {
			$to_remove = array_diff( $existing_variation_ids, $seen_ids );
			foreach ( $to_remove as $remove_id ) {
				$stale = wc_get_product( $remove_id );
				if ( $stale ) {
					$stale->delete( true );
				}
			}
		}
	}

	protected function skus_to_ids( $skus ) {
		$ids = array();
		foreach ( (array) $skus as $sku ) {
			$id = wc_get_product_id_by_sku( $sku );
			if ( $id ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/* ---------------------------------------------------------------
	 * Preview — read the first N rows, apply mapping, and report what
	 * WOULD happen (create/update/skip + key fields) without touching the
	 * database at all. This is what backs the wizard's Step 5 preview
	 * table; it reuses find_existing_product() (read-only) so the
	 * create/update verdict shown here is the exact same logic the real
	 * import uses, not a separate guess.
	 * ------------------------------------------------------------- */

	/**
	 * @param array $args   Same shape as import()/start_job().
	 * @param int   $limit  Rows to preview.
	 * @return array|WP_Error List of preview rows.
	 */
	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$rows    = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview = array();

		foreach ( $rows as $raw_row ) {
			$record      = $this->apply_mapping( $raw_row, $args['mapping'] ?? array(), $args['format'], $args['transforms'] ?? array() );
			$existing_id = $this->find_existing_product( $record, $args['match_strategy'] ?? 'sku' );

			$categories = array();
			foreach ( (array) ( $record['categories'] ?? array() ) as $path ) {
				$leaf         = is_array( $path ) ? end( $path ) : $path;
				$categories[] = is_array( $leaf ) ? ( $leaf['name'] ?? '' ) : $leaf;
			}

			$preview[] = array(
				'name'        => $record['name'] ?? '',
				'sku'         => $record['sku'] ?? '',
				'type'        => ! empty( $record['variations'] ) || 'variable' === ( $record['type'] ?? '' ) ? 'variable' : ( $record['type'] ?? 'simple' ),
				'price'       => $record['regular_price'] ?? '',
				'categories'  => implode( ', ', array_filter( $categories ) ),
				'image_count' => ( ! empty( $record['featured_image'] ) ? 1 : 0 ) + count( (array) ( $record['gallery_images'] ?? array() ) ),
				'variation_count' => count( (array) ( $record['variations'] ?? array() ) ),
				'has_acf'     => ! empty( $record['acf'] ),
				'has_yoast'   => ! empty( $record['yoast'] ),
				'meta_count'  => count( (array) ( $record['custom_meta'] ?? array() ) ),
				'status'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $this->quick_validate( $record ),
			);
		}

		return $preview;
	}

	/**
	 * Cheap, read-only sanity checks for the preview table — flags rows
	 * the real import would likely fail or warn on, before anything is
	 * written.
	 */
	protected function quick_validate( $record ) {
		$issues = array();
		if ( empty( $record['sku'] ) && empty( $record['name'] ) ) {
			$issues[] = __( 'No SKU or name — row may be unusable.', 'advanced-woo-product-migrator' );
		}
		if ( isset( $record['regular_price'] ) && '' !== $record['regular_price'] && ! is_numeric( $record['regular_price'] ) ) {
			$issues[] = __( 'Regular price is not numeric.', 'advanced-woo-product-migrator' );
		}
		if ( ( 'variable' === ( $record['type'] ?? '' ) || ! empty( $record['variations'] ) ) && empty( $record['attributes'] ) ) {
			$issues[] = __( 'Variable product has no attributes.', 'advanced-woo-product-migrator' );
		}
		return $issues;
	}
}
