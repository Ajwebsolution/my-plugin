<?php
/**
 * AWPM_Order_Importer
 *
 * Creates/updates WooCommerce orders from CSV/JSON/XLSX via the WC_Order
 * CRUD API — never raw post/postmeta inserts — so totals, taxes and status
 * transitions go through WooCommerce's own validated code paths. Line
 * items are re-matched to the destination site's products by SKU (falling
 * back to the external-ID relationship map), so an order exported from one
 * store imports cleanly into another as long as the same products (or their
 * external IDs) exist there. Mirrors AWPM_Product_Importer's shape.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Order_Importer {

	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return AWPM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return AWPM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return AWPM_CSV_Handler::read( $file_path );
		}
	}

	public function start_job( $args ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = AWPM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'orders',
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array(
					'existing_action'       => $args['existing_action'] ?? 'skip',
					'match_strategy'        => $args['match_strategy'] ?? 'external_id',
					'create_missing_customer' => $args['create_missing_customer'] ?? false,
					'set_status'            => $args['set_status'] ?? '',
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 25,
				'total_rows'  => count( $rows ),
			)
		);

		AWPM_Logger::set_run_id( 'awpm_run_job_' . $job_id, 'import', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Import job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$rows = $this->read_rows( $job['file_path'], $job['format'] );
		if ( is_wp_error( $rows ) ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			return $rows;
		}

		$offset  = (int) $job['offset_row'];
		$batch   = array_slice( $rows, $offset, (int) $job['batch_size'] );
		$options = $job['options'];

		$created = 0; $updated = 0; $skipped = 0; $failed = 0;

		foreach ( $batch as $i => $raw_row ) {
			$row_index = $offset + $i;
			try {
				$record = $this->apply_mapping( $raw_row, $job['mapping'] );
				$result = $this->process_record( $record, $options, (bool) $job['dry_run'] );
				if ( 'created' === $result['verdict'] ) { $created++; }
				elseif ( 'updated' === $result['verdict'] ) { $updated++; }
				else { $skipped++; }
				AWPM_Jobs::add_import_item( $job_id, $row_index, $record['order_number'] ?? '', $result['id'] ?? null, 'success', $result['message'] );
			} catch ( Exception $e ) {
				$failed++;
				AWPM_Jobs::add_import_item( $job_id, $row_index, '', null, 'error', $e->getMessage() );
			}
		}

		AWPM_Jobs::increment_import_counts( $job_id, $created, $updated, $skipped, $failed, count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array(
				'job_id'  => $job_id,
				'created' => $job['created_count'] + $created,
				'updated' => $job['updated_count'] + $updated,
				'skipped' => $job['skipped_count'] + $skipped,
				'failed'  => $job['failed_count'] + $failed,
			);
			AWPM_Notifications::notify( 'import_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Order import job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_import_job( $job_id ) );
	}

	protected function apply_mapping( $raw_row, $mapping ) {
		if ( empty( $mapping ) ) {
			return $raw_row;
		}
		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$record[ $target_field ] = $raw_row[ $source_column ];
		}
		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}
		return $record;
	}

	protected function find_existing_order( $record, $strategy ) {
		if ( 'external_id' === $strategy ) {
			$ext = $record['external_id'] ?? '';
			if ( $ext ) {
				$id = AWPM_Relationship_Map::resolve( 'default', $ext, 'order' );
				if ( $id ) {
					return $id;
				}
			}
		}
		if ( 'order_id' === $strategy && ! empty( $record['order_id'] ) ) {
			$order = wc_get_order( (int) $record['order_id'] );
			if ( $order ) {
				return $order->get_id();
			}
		}
		return 0;
	}

	/**
	 * Resolve a customer by email (the one stable, portable identifier an
	 * order carries) — falls back to the external-ID relationship map, and
	 * can optionally create a bare customer account if neither matches and
	 * the import options allow it. An order whose customer can't be
	 * resolved and isn't allowed to create one still imports as a guest
	 * order (customer_id 0) with the billing email preserved — never fails
	 * the whole row just because the customer link is missing.
	 */
	protected function resolve_customer_id( $record, $options ) {
		$email = $record['customer_email'] ?? ( $record['billing']['email'] ?? '' );

		if ( ! empty( $record['customer_external_id'] ) ) {
			$id = AWPM_Relationship_Map::resolve( 'default', $record['customer_external_id'], 'customer' );
			if ( $id ) {
				return (int) $id;
			}
		}
		if ( $email ) {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				return (int) $user->ID;
			}
		}
		if ( $email && ! empty( $options['create_missing_customer'] ) ) {
			$user_id = wp_insert_user(
				array(
					'user_login' => sanitize_user( $email, true ),
					'user_email' => $email,
					'user_pass'  => wp_generate_password( 20 ),
					'role'       => 'customer',
					'first_name' => $record['billing']['first_name'] ?? '',
					'last_name'  => $record['billing']['last_name'] ?? '',
				)
			);
			if ( ! is_wp_error( $user_id ) ) {
				return (int) $user_id;
			}
		}
		return 0;
	}

	protected function process_record( $record, $options, $dry_run ) {
		$existing_id = $this->find_existing_order( $record, $options['match_strategy'] ?? 'external_id' );

		if ( $existing_id && 'skip' === ( $options['existing_action'] ?? 'skip' ) ) {
			return array( 'verdict' => 'skipped', 'id' => $existing_id, 'message' => __( 'Order already exists — skipped.', 'advanced-woo-product-migrator' ) );
		}
		if ( $existing_id && 'duplicate' === ( $options['existing_action'] ?? '' ) ) {
			$existing_id = 0;
		}

		// Resolve every line item's SKU up front so dry-run can report
		// missing products without writing anything.
		$resolved_items = array();
		$missing_skus   = array();
		foreach ( (array) ( $record['line_items'] ?? array() ) as $item ) {
			$product_id = 0;
			if ( ! empty( $item['sku'] ) ) {
				$product_id = wc_get_product_id_by_sku( $item['sku'] );
			}
			if ( ! $product_id && ! empty( $item['product_external_id'] ) ) {
				$product_id = (int) AWPM_Relationship_Map::resolve( 'default', $item['product_external_id'], 'product' );
			}
			if ( ! $product_id ) {
				$missing_skus[] = $item['sku'] ?? $item['name'] ?? '?';
			}
			$resolved_items[] = array_merge( $item, array( '_product_id' => $product_id ) );
		}

		if ( $dry_run ) {
			$msg = $existing_id ? __( 'Would update existing order.', 'advanced-woo-product-migrator' ) : __( 'Would create new order.', 'advanced-woo-product-migrator' );
			if ( $missing_skus ) {
				$msg .= ' ' . sprintf( __( 'Line item product(s) not found: %s', 'advanced-woo-product-migrator' ), implode( ', ', $missing_skus ) );
			}
			return array( 'verdict' => $existing_id ? 'updated' : 'created', 'id' => $existing_id, 'message' => $msg );
		}

		$order = $existing_id ? wc_get_order( $existing_id ) : new WC_Order();

		$customer_id = $this->resolve_customer_id( $record, $options );
		if ( $customer_id ) {
			$order->set_customer_id( $customer_id );
		}

		if ( ! empty( $record['billing'] ) ) {
			$order->set_address( array_filter( (array) $record['billing'] ), 'billing' );
		}
		if ( ! empty( $record['shipping'] ) ) {
			$order->set_address( array_filter( (array) $record['shipping'] ), 'shipping' );
		}

		if ( ! empty( $record['currency'] ) ) {
			$order->set_currency( $record['currency'] );
		}
		if ( ! empty( $record['payment_method'] ) ) {
			$order->set_payment_method( $record['payment_method'] );
		}
		if ( isset( $record['payment_method_title'] ) ) {
			$order->set_payment_method_title( $record['payment_method_title'] );
		}
		if ( isset( $record['customer_note'] ) ) {
			$order->set_customer_note( $record['customer_note'] );
		}

		// Existing line items are cleared and rewritten wholesale on update —
		// simplest reliable way to keep an order's items in sync with the
		// imported source without hand-diffing each one.
		if ( $existing_id ) {
			foreach ( $order->get_items( array( 'line_item', 'shipping', 'fee', 'coupon' ) ) as $item ) {
				$order->remove_item( $item->get_id() );
			}
		}

		foreach ( $resolved_items as $item ) {
			if ( empty( $item['_product_id'] ) ) {
				continue; // Can't add a line item without a resolvable product.
			}
			$product = wc_get_product( $item['_product_id'] );
			if ( ! $product ) {
				continue;
			}
			$order->add_product(
				$product,
				$item['quantity'] ?? 1,
				array(
					'subtotal' => $item['subtotal'] ?? null,
					'total'    => $item['total'] ?? null,
				)
			);
		}

		foreach ( (array) ( $record['shipping_lines'] ?? array() ) as $line ) {
			$item = new WC_Order_Item_Shipping();
			$item->set_method_title( $line['method_title'] ?? '' );
			$item->set_total( $line['total'] ?? 0 );
			$order->add_item( $item );
		}
		foreach ( (array) ( $record['fee_lines'] ?? array() ) as $line ) {
			$item = new WC_Order_Item_Fee();
			$item->set_name( $line['name'] ?? __( 'Fee', 'advanced-woo-product-migrator' ) );
			$item->set_total( $line['total'] ?? 0 );
			$order->add_item( $item );
		}

		if ( ! empty( $record['status'] ) ) {
			$order->set_status( str_replace( 'wc-', '', $record['status'] ) );
		}
		if ( ! empty( $options['set_status'] ) ) {
			$order->set_status( str_replace( 'wc-', '', $options['set_status'] ) );
		}

		$order->calculate_totals( false ); // false: don't re-derive from totals we already imported where possible.

		if ( ! empty( $record['custom_meta'] ) ) {
			foreach ( (array) $record['custom_meta'] as $key => $value ) {
				$order->update_meta_data( sanitize_key( $key ), $value );
			}
		}

		$order_id = $order->save();

		$external_id = $record['external_id'] ?? ( $record['order_id'] ?? '' );
		if ( $external_id ) {
			$order->update_meta_data( '_awpm_external_id', $external_id );
			$order->save();
			AWPM_Relationship_Map::set_mapping( 'default', (string) $external_id, $order_id, 'order', (string) $external_id );
		}

		$message = $existing_id ? __( 'Updated existing order.', 'advanced-woo-product-migrator' ) : __( 'Created new order.', 'advanced-woo-product-migrator' );
		if ( $missing_skus ) {
			$message .= ' ' . sprintf( __( 'Line item product(s) not found and skipped: %s', 'advanced-woo-product-migrator' ), implode( ', ', $missing_skus ) );
		}

		return array( 'verdict' => $existing_id ? 'updated' : 'created', 'id' => $order_id, 'message' => $message );
	}

	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$rows    = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview = array();

		foreach ( $rows as $raw_row ) {
			$record      = $this->apply_mapping( $raw_row, $args['mapping'] ?? array() );
			$existing_id = $this->find_existing_order( $record, $args['match_strategy'] ?? 'external_id' );

			$issues = array();
			foreach ( (array) ( $record['line_items'] ?? array() ) as $item ) {
				$found = ! empty( $item['sku'] ) && wc_get_product_id_by_sku( $item['sku'] );
				if ( ! $found && empty( $item['product_external_id'] ) ) {
					$issues[] = sprintf( __( 'Line item "%s" has no resolvable product.', 'advanced-woo-product-migrator' ), $item['name'] ?? $item['sku'] ?? '?' );
				}
			}

			$preview[] = array(
				'name'        => $record['order_number'] ?? ( '#' . ( $record['order_id'] ?? '?' ) ),
				'sku'         => $record['customer_email'] ?? '',
				'type'        => $record['status'] ?? 'pending',
				'price'       => $record['total'] ?? '',
				'categories'  => '',
				'image_count' => 0,
				'variation_count' => count( (array) ( $record['line_items'] ?? array() ) ),
				'has_acf'     => false,
				'has_yoast'   => false,
				'meta_count'  => count( (array) ( $record['custom_meta'] ?? array() ) ),
				'status'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $issues,
			);
		}

		return $preview;
	}
}
