<?php
/**
 * AWPM_Entity_Registry
 *
 * Central map of "what kind of data" (Step 1 of both wizards) to the
 * exporter/importer class pair that actually handles it. Products were the
 * only real entry for a long time, with Reviews/Categories/Tags/Orders/
 * Customers shown as disabled "Future module" cards; all five are now
 * implemented. This registry is what lets AWPM_Ajax, and the Export/Import
 * wizards, treat every supported
 * entity through one consistent dispatch point instead of hardcoding
 * `new AWPM_Product_Exporter()` everywhere — adding a future entity means
 * adding one row here plus its exporter/importer pair, not touching the
 * AJAX layer's control flow.
 *
 * Every exporter class here implements: export( $args ), start_job( $args ),
 * process_next_batch( $job_id ). Every importer class implements:
 * start_job( $args ), process_next_batch( $job_id ), preview_rows( $args, $limit ).
 * This is the same shape AWPM_Product_Exporter/AWPM_Product_Importer already
 * used, so the batch-job engine, polling JS, and download endpoint work
 * unmodified for every entity.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Entity_Registry {

	/**
	 * @return array entity_key => { label, exporter, importer, implemented }
	 */
	public static function get_entities() {
		return array(
			'product'   => array(
				'label'       => __( 'Products', 'advanced-woo-product-migrator' ),
				'exporter'    => 'AWPM_Product_Exporter',
				'importer'    => 'AWPM_Product_Importer',
				'implemented' => true,
			),
			'reviews'   => array(
				'label'       => __( 'Reviews (Product / Customer)', 'advanced-woo-product-migrator' ),
				'exporter'    => 'AWPM_Review_Exporter',
				'importer'    => 'AWPM_Review_Importer',
				'implemented' => true,
			),
			'orders'    => array(
				'label'       => __( 'Orders', 'advanced-woo-product-migrator' ),
				'exporter'    => 'AWPM_Order_Exporter',
				'importer'    => 'AWPM_Order_Importer',
				'implemented' => true,
			),
			'customers' => array(
				'label'       => __( 'Customers', 'advanced-woo-product-migrator' ),
				'exporter'    => 'AWPM_Customer_Exporter',
				'importer'    => 'AWPM_Customer_Importer',
				'implemented' => true,
			),
			'categories' => array(
				'label'       => __( 'Categories & Tags', 'advanced-woo-product-migrator' ),
				'exporter'    => 'AWPM_Taxonomy_Exporter',
				'importer'    => 'AWPM_Taxonomy_Importer',
				'implemented' => true,
			),
		);
	}

	public static function is_valid( $entity ) {
		$entities = self::get_entities();
		return isset( $entities[ $entity ] ) && ! empty( $entities[ $entity ]['implemented'] );
	}

	/**
	 * @param string $entity
	 * @return object|WP_Error
	 */
	public static function get_exporter( $entity ) {
		if ( ! self::is_valid( $entity ) ) {
			return new WP_Error( 'awpm_unknown_entity', __( 'Unknown or not-yet-implemented data type.', 'advanced-woo-product-migrator' ) );
		}
		$class = self::get_entities()[ $entity ]['exporter'];
		return new $class();
	}

	/**
	 * @param string $entity
	 * @return object|WP_Error
	 */
	public static function get_importer( $entity ) {
		if ( ! self::is_valid( $entity ) ) {
			return new WP_Error( 'awpm_unknown_entity', __( 'Unknown or not-yet-implemented data type.', 'advanced-woo-product-migrator' ) );
		}
		$class = self::get_entities()[ $entity ]['importer'];
		return new $class();
	}
}
