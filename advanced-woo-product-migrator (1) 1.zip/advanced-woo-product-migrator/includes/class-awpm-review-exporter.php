<?php
/**
 * AWPM_Review_Exporter
 *
 * WooCommerce "Product Reviews" (what the storefront calls Customer Reviews
 * too — WooCommerce doesn't have two separate systems; both names point at
 * the same WP_Comment-based review store, keyed to a product and carrying a
 * star rating + verified-owner flag) exported as structured, portable
 * records. Mirrors AWPM_Product_Exporter's shape (export()/start_job()/
 * process_next_batch()) so it plugs into the same batch-job engine, AJAX
 * endpoints, and download flow without any special-casing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Review_Exporter {

	/**
	 * @param array $args {
	 *     @type string $format              csv|xlsx|json
	 *     @type array  $product_ids         Limit to reviews on these products.
	 *     @type array  $skus                Limit to reviews on products with these SKUs.
	 *     @type string $status              approve|hold|spam|trash|all (default: approve)
	 *     @type string $rating              '' | '1'..'5' — exact star rating filter.
	 *     @type bool   $verified_only       Only verified-owner reviews.
	 *     @type string $date_after          Y-m-d
	 *     @type string $date_before         Y-m-d
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 * @return array|WP_Error { file_path, file_url, product_count }
	 */
	public function export( $args ) {
		$args = $this->parse_args( $args );
		$run_id = AWPM_Logger::start_run();

		$comment_ids = $this->resolve_comment_ids( $args );
		if ( empty( $comment_ids ) ) {
			return new WP_Error( 'awpm_no_reviews', __( 'No reviews matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$records = array();
		foreach ( $comment_ids as $comment_id ) {
			$record = $this->build_record( $comment_id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$write_true_xlsx = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename        = 'awpm-export-reviews-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path       = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = AWPM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = AWPM_XLSX_Handler::write( $records, $file_path );
		} else {
			$ok = AWPM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'awpm_write_failed', __( 'Could not write export file.', 'advanced-woo-product-migrator' ) );
		}

		return array(
			'file_path'     => $file_path,
			'file_url'      => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename,
			'product_count' => count( $records ),
			'run_id'        => $run_id,
		);
	}

	public function start_job( $args ) {
		$args = $this->parse_args( $args );

		$comment_ids = $this->resolve_comment_ids( $args );
		if ( empty( $comment_ids ) ) {
			return new WP_Error( 'awpm_no_reviews', __( 'No reviews matched the export criteria.', 'advanced-woo-product-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = AWPM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'reviews',
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_ids' => $comment_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $comment_ids ),
			)
		);

		$xlsx_ok  = 'xlsx' === $args['format'] && AWPM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename = 'awpm-export-reviews-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		AWPM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . $filename ) );

		AWPM_Logger::set_run_id( 'awpm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Export job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$ids    = $job['args']['_ids'] ?? array();
		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $ids, $offset, (int) $job['batch_size'] );

		$records = array();
		foreach ( $batch as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		AWPM_Exporter_File_Writer::append( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch ) ) >= count( $ids ), 'reviews' );

		AWPM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch ) ) >= count( $ids ) || empty( $batch );

		if ( $done ) {
			AWPM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			$totals = array( 'job_id' => $job_id, 'products' => (int) $job['processed_count'] + count( $records ) );
			AWPM_Webhooks::dispatch( 'export.completed', $totals );
			AWPM_Notifications::notify( 'export_completed', $totals );
			AWPM_Logger::log( 'info', sprintf( 'Review export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => AWPM_Jobs::get_export_job( $job_id ) );
	}

	protected function parse_args( $args ) {
		return wp_parse_args(
			$args,
			array(
				'format'       => 'json',
				'product_ids'  => array(),
				'skus'         => array(),
				'status'       => 'approve',
				'rating'       => '',
				'verified_only'=> false,
				'date_after'   => '',
				'date_before'  => '',
				'limit'        => 0,
				'offset'       => 0,
				'batch_size'   => 50,
			)
		);
	}

	protected function resolve_comment_ids( $args ) {
		$product_ids = array_map( 'absint', (array) $args['product_ids'] );
		foreach ( (array) $args['skus'] as $sku ) {
			$id = wc_get_product_id_by_sku( $sku );
			if ( $id ) {
				$product_ids[] = $id;
			}
		}

		$query_args = array(
			'type'    => 'review',
			'status'  => 'all' === $args['status'] ? 'all' : $args['status'],
			'number'  => 0, // All matching — paging is handled by our own offset/limit below.
		);
		if ( ! empty( $product_ids ) ) {
			$query_args['post_id'] = $product_ids;
		}
		if ( ! empty( $args['date_after'] ) || ! empty( $args['date_before'] ) ) {
			$after  = $args['date_after'] ?: '1970-01-01';
			$before = $args['date_before'] ?: gmdate( 'Y-m-d' );
			$query_args['date_query'] = array( array( 'after' => $after, 'before' => $before . ' 23:59:59', 'inclusive' => true ) );
		}

		$comments = get_comments( $query_args );
		$ids      = wp_list_pluck( $comments, 'comment_ID' );

		if ( '' !== $args['rating'] ) {
			$ids = array_values(
				array_filter(
					$ids,
					function ( $id ) use ( $args ) {
						return (string) get_comment_meta( $id, 'rating', true ) === (string) $args['rating'];
					}
				)
			);
		}
		if ( ! empty( $args['verified_only'] ) ) {
			$ids = array_values(
				array_filter(
					$ids,
					function ( $id ) {
						return 1 === (int) get_comment_meta( $id, 'verified', true );
					}
				)
			);
		}

		if ( ! empty( $args['offset'] ) ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return array_map( 'intval', $ids );
	}

	public function build_record( $comment_id ) {
		$comment = get_comment( $comment_id );
		if ( ! $comment || 'product' !== get_post_type( $comment->comment_post_ID ) ) {
			return null;
		}

		$product_id = (int) $comment->comment_post_ID;

		return array(
			'source_site'    => site_url(),
			'review_id'      => (int) $comment->comment_ID,
			'external_id'    => get_comment_meta( $comment_id, '_awpm_external_id', true ) ?: (string) $comment->comment_ID,
			'product_id'     => $product_id,
			'product_sku'    => get_post_meta( $product_id, '_sku', true ),
			'product_external_id' => get_post_meta( $product_id, AWPM_Relationship_Map::META_KEY, true ) ?: (string) $product_id,
			'author_name'    => $comment->comment_author,
			'author_email'   => $comment->comment_author_email,
			'author_user_id' => (int) $comment->user_id,
			'content'        => $comment->comment_content,
			'rating'         => (int) get_comment_meta( $comment_id, 'rating', true ),
			'verified_owner' => (int) get_comment_meta( $comment_id, 'verified', true ),
			'status'         => wp_get_comment_status( $comment ), // approved|unapproved|spam|trash
			'date_created'   => $comment->comment_date,
		);
	}
}
