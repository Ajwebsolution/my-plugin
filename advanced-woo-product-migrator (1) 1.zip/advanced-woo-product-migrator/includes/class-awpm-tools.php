<?php
/**
 * AWPM_Tools
 *
 * Real implementations behind the Tools menu — each one actually scans/
 * validates/generates against the live store, none are placeholders.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Tools {

	public static function scan_product_meta() {
		return AWPM_Field_Registry::discover_custom_meta_keys( 300 );
	}

	public static function scan_acf_fields() {
		return AWPM_Field_Registry::get_acf_fields();
	}

	public static function scan_taxonomies() {
		$taxonomies = get_object_taxonomies( 'product', 'objects' );
		$out = array();
		foreach ( $taxonomies as $tax ) {
			$out[] = array(
				'name'         => $tax->name,
				'label'        => $tax->label,
				'hierarchical' => $tax->hierarchical,
				'term_count'   => wp_count_terms( array( 'taxonomy' => $tax->name, 'hide_empty' => false ) ),
			);
		}
		return $out;
	}

	public static function scan_attributes() {
		if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return array();
		}
		$out = array();
		foreach ( wc_get_attribute_taxonomies() as $attr ) {
			$out[] = array(
				'name'     => wc_attribute_taxonomy_name( $attr->attribute_name ),
				'label'    => $attr->attribute_label,
				'type'     => $attr->attribute_type,
				'global'   => true,
				'term_count' => wp_count_terms( array( 'taxonomy' => wc_attribute_taxonomy_name( $attr->attribute_name ), 'hide_empty' => false ) ),
			);
		}
		return $out;
	}

	public static function scan_product_types() {
		$types = function_exists( 'wc_get_product_types' ) ? wc_get_product_types() : array();
		$out = array();
		foreach ( $types as $slug => $label ) {
			$out[ $slug ] = array(
				'label' => $label,
				'count' => (int) wp_count_posts( 'product' )->publish, // Coarse; per-type count requires a taxonomy query below.
			);
		}
		// Per-type counts via product_type taxonomy.
		foreach ( $out as $slug => &$info ) {
			$term = get_term_by( 'slug', $slug, 'product_type' );
			$info['count'] = $term ? $term->count : 0;
		}
		return $out;
	}

	public static function find_duplicate_skus() {
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT meta_value as sku, COUNT(*) as cnt, GROUP_CONCAT(post_id) as product_ids
			FROM {$wpdb->postmeta}
			WHERE meta_key = '_sku' AND meta_value != ''
			GROUP BY meta_value
			HAVING cnt > 1
			ORDER BY cnt DESC
			LIMIT 200",
			ARRAY_A
		);
		return $rows;
	}

	public static function find_duplicate_products() {
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT post_title as title, COUNT(*) as cnt, GROUP_CONCAT(ID) as product_ids
			FROM {$wpdb->posts}
			WHERE post_type = 'product' AND post_status IN ('publish','draft','pending')
			GROUP BY post_title
			HAVING cnt > 1
			ORDER BY cnt DESC
			LIMIT 200",
			ARRAY_A
		);
		return $rows;
	}

	/**
	 * Validate product data across the store: missing SKU, broken variation
	 * parents, missing attributes on variable products with no variations,
	 * invalid price, invalid stock, broken image references.
	 */
	public static function validate_product_data( $limit = 500 ) {
		$issues = array();

		$products = wc_get_products( array( 'limit' => $limit, 'return' => 'ids', 'status' => array( 'publish', 'draft', 'pending' ) ) );

		foreach ( $products as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			if ( ! $product->get_sku() ) {
				$issues[] = array( 'product_id' => $product_id, 'type' => 'missing_sku', 'message' => __( 'Product has no SKU.', 'advanced-woo-product-migrator' ) );
			}

			if ( '' !== $product->get_regular_price() && ! is_numeric( $product->get_regular_price() ) ) {
				$issues[] = array( 'product_id' => $product_id, 'type' => 'invalid_price', 'message' => __( 'Regular price is not numeric.', 'advanced-woo-product-migrator' ) );
			}

			if ( $product->get_manage_stock() && '' !== $product->get_stock_quantity() && ! is_numeric( $product->get_stock_quantity() ) ) {
				$issues[] = array( 'product_id' => $product_id, 'type' => 'invalid_stock', 'message' => __( 'Stock quantity is not numeric.', 'advanced-woo-product-migrator' ) );
			}

			if ( $product->is_type( 'variable' ) ) {
				$children = $product->get_children();
				if ( empty( $children ) ) {
					$issues[] = array( 'product_id' => $product_id, 'type' => 'no_variations', 'message' => __( 'Variable product has no variations.', 'advanced-woo-product-migrator' ) );
				}
				if ( ! $product->get_attributes() ) {
					$issues[] = array( 'product_id' => $product_id, 'type' => 'missing_attributes', 'message' => __( 'Variable product has no attributes defined.', 'advanced-woo-product-migrator' ) );
				}
				foreach ( $children as $child_id ) {
					if ( get_post_field( 'post_parent', $child_id ) != $product_id ) { // phpcs:ignore WordPress.PHP.StrictComparisons
						$issues[] = array( 'product_id' => $child_id, 'type' => 'broken_variation_parent', 'message' => __( 'Variation parent mismatch.', 'advanced-woo-product-migrator' ) );
					}
				}
			}

			$image_id = $product->get_image_id();
			if ( $image_id && ! wp_get_attachment_url( $image_id ) ) {
				$issues[] = array( 'product_id' => $product_id, 'type' => 'broken_image', 'message' => __( 'Featured image attachment is missing.', 'advanced-woo-product-migrator' ) );
			}

			if ( ! $product->get_category_ids() ) {
				$issues[] = array( 'product_id' => $product_id, 'type' => 'no_category', 'message' => __( 'Product has no category assigned.', 'advanced-woo-product-migrator' ) );
			}
		}

		return $issues;
	}

	public static function clear_temp_files() {
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		$count      = 0;
		foreach ( glob( trailingslashit( $tmp_dir ) . 'awpm-*' ) ?: array() as $file ) {
			if ( is_file( $file ) && @unlink( $file ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$count++;
			}
		}
		return $count;
	}

	public static function rebuild_relationship_map() {
		return AWPM_Relationship_Map::rebuild();
	}

	/**
	 * Attempt to repair a job left in "running" state (e.g. server crash
	 * mid-batch) by nudging it forward one more batch and re-checking.
	 */
	public static function repair_import_job( $job_id ) {
		$job = AWPM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'awpm_job_not_found', __( 'Job not found.', 'advanced-woo-product-migrator' ) );
		}
		if ( 'running' !== $job['status'] && 'pending' !== $job['status'] ) {
			return new WP_Error( 'awpm_job_not_repairable', __( 'Only pending/running jobs can be repaired.', 'advanced-woo-product-migrator' ) );
		}
		$importer = new AWPM_Product_Importer();
		return $importer->process_next_batch( $job_id );
	}

	/**
	 * Generate a self-contained sample JSON export covering every data
	 * category from the spec (simple, variable+variations, global+local
	 * attributes, categories, images, ACF incl. repeater/flexible content,
	 * Yoast, custom meta, relationships) — purely synthetic, no real store
	 * data — so the importer can be exercised end-to-end on a fresh install.
	 *
	 * @return string File path of the generated sample.
	 */
	public static function generate_sample_export() {
		$sample = array(
			array(
				'source_site' => 'sample-generator',
				'product_id'  => 0,
				'type'        => 'simple',
				'name'        => 'Sample Cotton T-Shirt',
				'slug'        => 'sample-cotton-t-shirt',
				'description' => 'A soft, breathable cotton t-shirt. Sample product generated for testing the importer.',
				'short_description' => 'Soft cotton tee.',
				'sku'         => 'SAMPLE-TSHIRT-001',
				'status'      => 'draft',
				'catalog_visibility' => 'visible',
				'featured'    => false,
				'regular_price' => '29.99',
				'sale_price'  => '24.99',
				'manage_stock' => true,
				'stock_quantity' => 50,
				'stock_status'  => 'instock',
				'weight' => '0.2', 'length' => '30', 'width' => '20', 'height' => '2',
				'tax_status' => 'taxable', 'tax_class' => '',
				'virtual' => false, 'downloadable' => false,
				'categories' => array( array( array( 'slug' => 'clothing', 'name' => 'Clothing' ), array( 'slug' => 'tshirts', 'name' => 'T-Shirts' ) ) ),
				'tags' => array( 'sample', 'cotton' ),
				'attributes' => array(
					array( 'name' => 'Material', 'label' => 'Material', 'is_global' => false, 'position' => 0, 'visible' => true, 'variation' => false, 'values' => array( array( 'slug' => 'cotton', 'name' => 'Cotton' ) ) ),
				),
				'acf' => array(
					'material' => 'Cotton',
					'care_instructions' => 'Machine wash cold.',
					'specifications' => array(
						array( 'label' => 'Weight', 'value' => '180gsm' ),
						array( 'label' => 'Origin', 'value' => 'Portugal' ),
					),
				),
				'yoast' => array(
					'yoast_title'    => 'Sample Cotton T-Shirt | Example Store',
					'yoast_metadesc' => 'Buy our sample soft cotton t-shirt.',
				),
				'custom_meta' => array( '_supplier_code' => 'SUPP-001', '_delivery_time' => '3-5 days' ),
			),
			array(
				'source_site' => 'sample-generator',
				'product_id'  => 0,
				'type'        => 'variable',
				'name'        => 'Sample Denim Jacket',
				'slug'        => 'sample-denim-jacket',
				'description' => 'A classic denim jacket. Sample variable product for testing.',
				'sku'         => 'SAMPLE-JACKET-001',
				'status'      => 'draft',
				'regular_price' => '',
				'categories'  => array( array( array( 'slug' => 'clothing', 'name' => 'Clothing' ), array( 'slug' => 'jackets', 'name' => 'Jackets' ) ) ),
				'tags'        => array( 'sample', 'denim' ),
				'attributes'  => array(
					array( 'name' => 'pa_color', 'label' => 'Color', 'is_global' => true, 'position' => 0, 'visible' => true, 'variation' => true, 'values' => array( array( 'slug' => 'blue', 'name' => 'Blue' ), array( 'slug' => 'black', 'name' => 'Black' ) ) ),
					array( 'name' => 'Size', 'label' => 'Size', 'is_global' => false, 'position' => 1, 'visible' => true, 'variation' => true, 'values' => array( array( 'slug' => 's', 'name' => 'S' ), array( 'slug' => 'm', 'name' => 'M' ), array( 'slug' => 'l', 'name' => 'L' ) ) ),
				),
				'default_attributes' => array( 'pa_color' => 'blue', 'size' => 's' ),
				'variations' => array(
					array( 'sku' => 'SAMPLE-JACKET-001-BLU-S', 'regular_price' => '89.99', 'stock_quantity' => 10, 'stock_status' => 'instock', 'attributes' => array( 'pa_color' => 'blue', 'Size' => 's' ) ),
					array( 'sku' => 'SAMPLE-JACKET-001-BLU-M', 'regular_price' => '89.99', 'stock_quantity' => 8, 'stock_status' => 'instock', 'attributes' => array( 'pa_color' => 'blue', 'Size' => 'm' ) ),
					array( 'sku' => 'SAMPLE-JACKET-001-BLK-L', 'regular_price' => '94.99', 'stock_quantity' => 0, 'stock_status' => 'outofstock', 'attributes' => array( 'pa_color' => 'black', 'Size' => 'l' ) ),
				),
				'acf' => array(
					'material' => 'Denim',
					'flexible_layout_demo' => array(
						array( 'acf_fc_layout' => 'hero_section', 'heading' => 'Timeless Denim' ),
						array( 'acf_fc_layout' => 'faq_section', 'faq_rows' => array( array( 'question' => 'Is it true to size?', 'answer' => 'Yes, order your usual size.' ) ) ),
					),
				),
			),
			array(
				'source_site' => 'sample-generator',
				'product_id'  => 0,
				'type'        => 'external',
				'name'        => 'Sample Affiliate Speaker (External Product)',
				'slug'        => 'sample-affiliate-speaker',
				'description' => 'Sample external/affiliate product for testing — links out to a partner store instead of being purchased directly.',
				'sku'         => 'SAMPLE-EXTERNAL-001',
				'status'      => 'draft',
				'regular_price' => '89.00',
				'product_url' => 'https://example-partner-store.com/products/speaker',
				'button_text' => 'Buy on Partner Store',
				'categories'  => array( array( array( 'slug' => 'electronics', 'name' => 'Electronics' ) ) ),
				'custom_meta' => array( '_affiliate_network' => 'sample-network' ),
			),
		);

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );
		$file_path = trailingslashit( $tmp_dir ) . 'awpm-sample-export-' . gmdate( 'Y-m-d-His' ) . '.json';
		AWPM_JSON_Handler::write( $sample, $file_path );

		return array(
			'file_path' => $file_path,
			'file_url'  => trailingslashit( $upload_dir['baseurl'] ) . 'awpm-tmp/' . basename( $file_path ),
		);
	}
}
