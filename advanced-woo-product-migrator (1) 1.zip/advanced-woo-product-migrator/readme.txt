=== Advanced WooCommerce Product Migrator ===
Contributors: yourcompany
Tags: woocommerce, import, export, acf, migration
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
WC requires at least: 5.0
Stable tag: 1.2.0
License: GPLv2 or later

A custom, full-fidelity WooCommerce product import/export system with a
WebToffee-style workflow (dashboard, wizard, mapping, dry run, history,
logs, scheduling) and its own original architecture and UI — built to
handle ACF, Yoast, and custom meta that off-the-shelf importers drop.

== Installation ==

1. Copy the `advanced-woo-product-migrator` folder into `wp-content/plugins/`,
   or upload the zip via Plugins → Add New → Upload Plugin.
2. Activate it (WooCommerce must already be active — the plugin checks and
   shows an admin notice, it never fatals, if WooCommerce is missing).
3. Go to WooCommerce → Advanced Product Migrator.

== What's real vs. documented extension points ==

Every visible feature actually does what it says — no "Coming Soon"
buttons. What's flagged rather than faked:

* **SFTP import** — FTP and FTPS (explicit TLS) are fully implemented
  natively via PHP's own `ftp_*` extension (`class-awpm-ftp-fetcher.php`),
  including the Import wizard's "FTP / FTPS" source option and Scheduled
  Jobs. True SFTP (SSH-key auth) would need `phpseclib` or the `ssh2`
  PECL extension and real SSH crypto — deliberately not hand-rolled here —
  so it remains a documented extension point rather than a form field that
  goes nowhere. Remote URL import/scheduling is fully implemented with
  real SSRF protection (scheme allow-list, DNS-resolved private/loopback
  IP blocking re-checked on every redirect hop, redirect limit, size cap).
* **True `.xlsx` reader/writer** — implemented natively in
  `class-awpm-xlsx-handler.php` via PHP's built-in `ZipArchive` extension
  (no PhpSpreadsheet dependency): writes real OOXML spreadsheets batch by
  batch via a generator so memory stays flat on large exports, and reads
  both this plugin's own `.xlsx` files and real-world Excel/Sheets exports
  (inline strings and `sharedStrings.xml`-based files alike). Falls back to
  CSV, with a logged warning, only if a host disables the `ZipArchive` PHP
  extension entirely.
* **ACF/custom-meta value filters** (e.g. "ACF field X equals Nike") in the
  Export wizard's Step 3 — not implemented. Every filter actually shown in
  Step 3 (product/review/order/customer/category selection, date ranges,
  status, stock, brand, name search) genuinely narrows the query; this is
  the one category of filter the UI doesn't offer at all, rather than
  offering a non-functional one.
* **Scheduled Jobs (recurring WP-Cron import/export)** — only covers
  Products. Reviews, Orders, Customers and Categories & Tags can all be
  exported/imported on demand from their wizards, but not yet added as a
  recurring scheduled source/destination.
* **Load/performance testing at 10k–50k products/orders, and formal
  security penetration testing** — these need a live WordPress + MySQL
  server, which isn't available in the environment this was built in. The
  architecture is built to pass (indexed custom tables, batch/background
  processing with WP-Cron continuation, prepared statements throughout,
  capability + nonce checks on every AJAX/REST endpoint, SSRF-safe fetch),
  but "tested at scale" isn't something to claim without actually running
  it there — please validate on staging before production use. All new
  logic in this release (Reviews/Orders/Customers import-export, the
  Grouped/External product type fix, ACF Group/Clone fields) has isolated
  PHP unit tests against hand-written WordPress/WooCommerce function stubs,
  which is real verification of the logic but not a substitute for
  running against a live site.

== Reviews, Orders, Customers & Categories/Tags (new in 1.1.0 / 1.2.0) ==

All four previously-disabled "Future module" cards in the Export/Import
wizards are now fully implemented, using the exact same wizard →
batch-job-engine → mapping → AJAX architecture as Products (see
`class-awpm-entity-registry.php` for the dispatch point):

* **Reviews** (`class-awpm-review-exporter.php` / `-importer.php`) —
  WooCommerce's product review system (what the storefront also calls
  "Customer Reviews" — WooCommerce has one underlying `WP_Comment`-based
  store for both). Exports/imports star rating, verified-owner flag,
  author, content, and approval status; the target product is matched by
  SKU first, then the external-ID relationship map. Re-importing the same
  review is recognized via Review ID / External ID, or a product + author
  email fallback, rather than creating duplicates.
* **Orders** (`class-awpm-order-exporter.php` / `-importer.php`) — built
  on the `WC_Order` CRUD API (never raw post/postmeta writes), covering
  billing/shipping, line items (re-matched to the destination site's
  products by SKU → external-ID fallback), shipping/fee/coupon lines,
  totals, status, payment method, and custom order meta (read via
  `WC_Order::get_meta_data()`, so it works whether or not the site has
  WooCommerce's High-Performance Order Storage enabled). The customer is
  linked by email, with an optional "create missing customer account"
  setting.
* **Customers** (`class-awpm-customer-exporter.php` / `-importer.php`) —
  `WP_User` accounts plus WooCommerce's billing/shipping address user
  meta, order count and lifetime spend. Matched by email (WordPress
  enforces unique emails, making it the one identifier that reliably means
  the same person across two separate installs), with the external-ID map
  as a secondary match on repeat imports. A guest checkout (an order with
  no WordPress account) is exported as a synthetic "guest:&lt;email&gt;"
  record built from its order's billing address, and becomes a real
  account on import.
* **Categories & Tags** (`class-awpm-taxonomy-exporter.php` /
  `-importer.php`) — a standalone export/import of `product_cat`
  (hierarchical) and `product_tag` (flat) terms, independent of any
  product. Reuses `AWPM_Category_Handler::resolve_path()` — the same
  hierarchy-matching logic the Product importer already relies on for
  categories — so a category exports with its full "Parent > Child"
  ancestor path and re-imports by matching existing levels one at a time,
  only creating the ones that don't already exist, rather than duplicating
  a branch. Tags match by slug, then name.

== Changelog ==

= 1.2.0 =
* Added the Categories & Tags import/export module, replacing its "Future
  module" card in both wizards.
* Fixed Customer export returning "No customers matched the export
  criteria" on real stores: it was querying only WordPress accounts with
  the literal "customer" role, which many stores never assign (orders
  placed by an admin/staff account, a different role, or as a guest with
  no account at all). It now also includes any user who has placed an
  order regardless of role, and exports guest checkouts as a record built
  from their order's billing address.
* Fixed `AWPM_Relationship_Map::resolve()` always validating a resolved
  target with `get_post_status()`, which silently failed "match by
  External ID" for every Customer (a `WP_User`, never a post) and for any
  Order on a site with WooCommerce's High-Performance Order Storage
  enabled (orders aren't `wp_posts` rows there). It now validates each
  object type the right way (`get_userdata()` for customers, `wc_get_order()`
  for orders, a terms-table lookup for categories/tags).

= 1.1.0 =
* Added the Reviews, Orders and Customers import/export modules described
  above, replacing their "Future module" cards in both wizards.
* Added an `entity_type` column to the import/export job tables so the
  existing batch-job engine, AJAX polling, and secure download endpoint
  work unmodified for every entity, not just products.

= 1.0.0 =
* Initial release: Products (simple/variable/grouped/external), full ACF
  (incl. repeater/flexible content/gallery/relationship/group/clone),
  Yoast SEO, custom meta, categories/tags/attributes, images, dry run,
  update-vs-create matching, rollback, scheduling, REST API, WP-CLI.

== Architecture ==

Custom tables (via dbDelta, WooCommerce/WordPress remain the source of
truth for product data — these only ever hold plugin bookkeeping):

* `wp_awpm_import_jobs` / `wp_awpm_export_jobs` — batch job state + history
* `wp_awpm_import_items` — per-product result within a job (Import Logs)
* `wp_awpm_logs` — persistent structured event log
* `wp_awpm_mappings` — saved field-mapping/export profiles
* `wp_awpm_snapshots` — pre-update product snapshots (real rollback)
* `wp_awpm_scheduled_jobs` — WP-Cron-backed recurring import/export
* `wp_awpm_relationship_map` — source→target ID mapping for relationships,
  upsells/cross-sells, and the external ID system across repeat migrations

Key classes (includes/):

* `class-awpm-acf-handler.php` — ACF export/import via ACF's own
  get_field()/update_field() API (not raw postmeta), so repeaters,
  flexible content (incl. nested repeaters inside layouts), galleries,
  relationship/post_object/taxonomy/user fields round-trip correctly.
  Relationship/post_object fields resolve through the relationship map
  rather than trusting raw source post IDs.
* `class-awpm-yoast-handler.php` — filterable Yoast key map
  (`awpm_yoast_field_map`), not a handful of hardcoded fields.
* `class-awpm-meta-handler.php` / `class-awpm-field-registry.php` —
  auto-discovers unknown custom meta by scanning real products; nothing
  silently disappears.
* `class-awpm-image-handler.php` — 5 configurable matching strategies +
  download/dedup, shared by product images, ACF image/file/gallery fields,
  and variation images.
* `class-awpm-category-handler.php` / `class-awpm-attribute-handler.php` —
  hierarchy-preserving category resolution; global (taxonomy) + local
  attribute support with optional auto-creation of missing global
  attributes and terms.
* `class-awpm-product-exporter.php` / `class-awpm-product-importer.php` —
  both support a synchronous `export()`/`import()` call AND a
  `start_job()` + `process_next_batch()` pair for real chunked background
  processing (never loads a whole large catalog into memory at once).
* `class-awpm-snapshot.php` — real rollback: snapshots a product's full
  CRUD data before an update, restores via `set_props()`/`save()`;
  newly-created products are trashed (never force-deleted) on rollback.
* `class-awpm-relationship-map.php` — external ID system
  (`_awpm_external_id` product meta) + source→target lookup table.
* `class-awpm-remote-fetcher.php` — SSRF-safe remote file fetch for
  Remote URL import and scheduled jobs.
* `class-awpm-scheduler.php` — WP-Cron-backed recurring jobs; also runs a
  5-minute safety-net tick that advances any job left "running" if a
  browser tab closed mid-import.
* `class-awpm-rest-api.php` — `/awpm/v1/import`, `/export`, `/jobs`,
  `/jobs/{id}`, `/products`, all requiring `manage_awpm`/`manage_woocommerce`.
* `class-awpm-tools.php` — real diagnostics: duplicate SKU/product finder,
  data validator, meta/ACF/taxonomy/attribute/product-type scanners,
  relationship-map rebuild, sample export generator.
* `class-awpm-webhooks.php` — fire-and-forget HTTP POST on job lifecycle
  events, matching the documented JSON payload shape.
* `class-awpm-xlsx-handler.php` — native `.xlsx` read/write via
  `ZipArchive`, no external library.
* `class-awpm-ftp-fetcher.php` — native FTP/FTPS fetch via PHP's `ftp_*`
  extension, for the Import wizard's "FTP / FTPS" source and Scheduled Jobs.
* `class-awpm-entity-registry.php` — maps each wizard "data type" card
  (product/reviews/orders/customers/categories) to its exporter/importer
  class pair.
* `class-awpm-review-exporter.php` / `-importer.php`,
  `class-awpm-order-exporter.php` / `-importer.php`,
  `class-awpm-customer-exporter.php` / `-importer.php`,
  `class-awpm-taxonomy-exporter.php` / `-importer.php` — the Reviews/
  Orders/Customers/Categories & Tags modules (see "Reviews, Orders,
  Customers & Categories/Tags" below).
* `class-awpm-exporter-file-writer.php` — the shared batch-append
  CSV/JSON/XLSX file writer used by the Reviews/Orders/Customers/
  Categories exporters (`AWPM_Product_Exporter` keeps its own original
  copy of this logic, so existing product-export behaviour is unchanged).
* `class-awpm-cli.php` — WP-CLI commands (`wp awpm export|import|rollback|
  history|status`), registered only when running under WP-CLI.

== Extending ==

* `awpm_yoast_field_map` — add/rename Yoast meta keys.
* `awpm_reserved_meta_keys` — exclude additional keys from the generic
  custom-meta exporter.
* `awpm_meta_transform_{name}` — register a custom meta value transform.
* `awpm_export_record` — filter the full export record per product.
* `awpm_prune_removed_variations` — return false to stop the importer
  deleting variations that exist on the destination but aren't in the
  imported variation list.
* `awpm_detected_integrations` — declare additional third-party
  integrations in the System Status screen.

== Uninstall ==

Deactivating never deletes anything. Fully deleting the plugin via
Plugins → Delete only removes AWPM's own tables/options/logs if you've
opted in under Settings → General → "Delete data on uninstall" — off by
default. WooCommerce product data (including the `_awpm_external_id` meta
this plugin writes) is never deleted by this plugin, ever.
