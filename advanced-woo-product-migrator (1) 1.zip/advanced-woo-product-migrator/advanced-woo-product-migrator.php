<?php
/**
 * Plugin Name: Advanced WooCommerce Product Migrator
 * Plugin URI:  https://example.com/advanced-woo-product-migrator
 * Description: Full-fidelity WooCommerce product import/export with a professional dashboard, step-by-step wizard, field mapping, dry run, background batch processing, rollback, scheduling, saved mapping profiles, and a REST API — built to handle complete ACF (repeater, flexible content, gallery, relationship), Yoast SEO, and custom meta that off-the-shelf importers drop.
 * Version:     1.2.0
 * Author:      Your Company
 * Text Domain: advanced-woo-product-migrator
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * WC requires at least: 5.0
 *
 * @package Advanced_Woo_Product_Migrator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

/* -------------------------------------------------------------------------
 * Constants
 * ---------------------------------------------------------------------- */
define( 'AWPM_VERSION', '1.2.0' );
define( 'AWPM_PLUGIN_FILE', __FILE__ );
define( 'AWPM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AWPM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AWPM_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'AWPM_MIN_PHP', '7.4' );
define( 'AWPM_MIN_WC', '5.0' );

/* -------------------------------------------------------------------------
 * Environment checks
 * ---------------------------------------------------------------------- */

/**
 * Verify WooCommerce is active (and PHP version) before booting anything.
 * We check on 'plugins_loaded' so we're not order-dependent on WooCommerce's
 * own load, and we never fatal — we just deactivate + notice.
 */
function awpm_environment_check() {
	$errors = array();

	if ( version_compare( PHP_VERSION, AWPM_MIN_PHP, '<' ) ) {
		$errors[] = sprintf(
			/* translators: 1: required PHP version, 2: current PHP version */
			__( 'Advanced WooCommerce Product Migrator requires PHP %1$s or higher. You are running %2$s.', 'advanced-woo-product-migrator' ),
			AWPM_MIN_PHP,
			PHP_VERSION
		);
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		$errors[] = __( 'Advanced WooCommerce Product Migrator requires WooCommerce to be installed and active.', 'advanced-woo-product-migrator' );
	}

	return $errors;
}

function awpm_admin_notice_requirements() {
	$errors = awpm_environment_check();
	if ( empty( $errors ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Advanced WooCommerce Product Migrator', 'advanced-woo-product-migrator' ) . ':</strong></p><ul>';
	foreach ( $errors as $error ) {
		echo '<li>' . esc_html( $error ) . '</li>';
	}
	echo '</ul></div>';
}

/* -------------------------------------------------------------------------
 * Boot
 * ---------------------------------------------------------------------- */
function awpm_boot() {
	if ( ! empty( awpm_environment_check() ) ) {
		add_action( 'admin_notices', 'awpm_admin_notice_requirements' );
		return;
	}

	// Order matters only where a class body references another at load time
	// (none do here — all cross-class calls happen inside methods, not at
	// file scope), but we group foundational/DB classes first for clarity.
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-installer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-logger.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-jobs.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-mappings.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-snapshot.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-relationship-map.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-webhooks.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-notifications.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-remote-fetcher.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-ftp-fetcher.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-scheduler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-system-status.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-tools.php';

	// WP-CLI commands — only meaningful when running under WP-CLI, but the
	// file itself has no side effects outside that (the add_command call at
	// the bottom of the file is already guarded by class_exists('WP_CLI')).
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-cli.php';
	}

	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-field-registry.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-acf-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-yoast-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-image-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-category-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-attribute-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-meta-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-transformer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-csv-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-json-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-xlsx-handler.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-product-exporter.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-product-importer.php';

	// Shared batch-append file writer + the entity registry, used by the
	// Reviews/Orders/Customers exporters/importers below (Products keeps
	// its own file-writing method untouched, so existing product export
	// behaviour is unaffected by this addition).
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-exporter-file-writer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-review-exporter.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-review-importer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-order-exporter.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-order-importer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-customer-exporter.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-customer-importer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-taxonomy-exporter.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-taxonomy-importer.php';
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-entity-registry.php';

	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-rest-api.php';

	require_once AWPM_PLUGIN_DIR . 'admin/class-awpm-admin.php';
	require_once AWPM_PLUGIN_DIR . 'admin/class-awpm-settings.php';
	require_once AWPM_PLUGIN_DIR . 'admin/class-awpm-ajax.php';

	// Silently bring the DB schema up to date if this is an upgrade from an
	// older plugin version (activation hook only runs on fresh activation).
	AWPM_Installer::maybe_upgrade();

	AWPM_Scheduler::init();
	AWPM_Rest_Api::init();
	AWPM_Settings::init();

	// Instantiate the admin controller (registers menus, assets, AJAX hooks).
	AWPM_Admin::instance();
	AWPM_Ajax::instance();
}
add_action( 'plugins_loaded', 'awpm_boot', 20 );

/* -------------------------------------------------------------------------
 * Activation / Deactivation
 * ---------------------------------------------------------------------- */
function awpm_activate() {
	// Create a private uploads subfolder for temporary import/export files.
	$upload_dir = wp_upload_dir();
	$awpm_dir   = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
	if ( ! file_exists( $awpm_dir ) ) {
		wp_mkdir_p( $awpm_dir );
	}
	// Protect the folder from direct web access.
	$htaccess = $awpm_dir . '/.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		file_put_contents( $htaccess, "Options -Indexes\nDeny from all\n" );
	}
	$index = $awpm_dir . '/index.php';
	if ( ! file_exists( $index ) ) {
		file_put_contents( $index, "<?php\n// Silence is golden.\n" );
	}

	if ( false === get_option( 'awpm_settings' ) ) {
		add_option(
			'awpm_settings',
			array(
				'default_match_strategy'           => 'sku',
				'image_match_strategy'             => 'url_filename_fallback',
				'create_missing_global_attributes' => true,
				'create_missing_categories'        => true,
				'batch_size'                       => 50,
				'logging_enabled'                  => true,
				'log_retention_days'                => 30,
				'snapshot_retention_days'           => 14,
				'create_backup_before_update'       => false,
				'enable_rollback'                   => true,
				'webhook_url'                        => '',
				'webhook_events'                     => array( 'import.completed', 'import.failed', 'export.completed', 'export.failed' ),
				'notification_emails'                => array( get_option( 'admin_email' ) ),
				'notify_on_completion'               => false,
				'notify_on_failure'                  => true,
			)
		);
	}

	// Requires the plugin's own classes (autoloading isn't set up this
	// early in the activation hook, since plugins_loaded hasn't fired yet).
	require_once AWPM_PLUGIN_DIR . 'includes/class-awpm-installer.php';
	AWPM_Installer::install();
}
register_activation_hook( __FILE__, 'awpm_activate' );

function awpm_deactivate() {
	// Clear all AWPM cron hooks, including per-scheduled-job instances.
	wp_clear_scheduled_hook( 'awpm_daily_maintenance' );
	wp_clear_scheduled_hook( 'awpm_batch_tick' );

	global $wpdb;
	if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}awpm_scheduled_jobs'" ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$ids = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}awpm_scheduled_jobs" );
		foreach ( $ids as $id ) {
			wp_clear_scheduled_hook( 'awpm_run_scheduled_job', array( (int) $id ) );
		}
	}

	// Deliberately does NOT delete database tables, options, logs, snapshots,
	// or any WooCommerce product data — deactivation must be non-destructive.
	// Full cleanup only ever happens in uninstall.php, and only if the site
	// owner opts in via Settings -> Advanced -> "Delete data on uninstall".
}
register_deactivation_hook( __FILE__, 'awpm_deactivate' );
