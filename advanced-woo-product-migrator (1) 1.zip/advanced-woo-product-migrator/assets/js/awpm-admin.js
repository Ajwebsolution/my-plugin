/* global jQuery, AWPM */
( function ( $ ) {
	'use strict';

	var state = {
		fieldCatalog: {}, // cached per-entity: { product: {...}, reviews: {...}, ... }
		uploadedFile: null,
		importJobId: null,
		exportJobId: null,
		importTransforms: {},
		exportFieldConfig: null, // null = "everything enabled" (not yet touched by the user)
		exportEntity: 'product',
		importEntity: 'product',
	};

	/**
	 * Per-entity options for the Import wizard's "If it already exists" /
	 * "Action for existing records" selects (Step 2) — Products, Reviews,
	 * Orders and Customers each have a different, real set of match
	 * strategies (see each importer's find_existing_*() method), so the
	 * dropdown is rebuilt rather than showing options that don't apply.
	 */
	var MATCH_STRATEGIES = {
		product: { options: [ [ 'sku', 'Update by SKU (falls back to Product ID / Slug)' ], [ 'product_id', 'Update by Product ID' ], [ 'slug', 'Update by Slug' ], [ 'external_id', 'Update by External ID (falls back to SKU)' ], [ 'none', 'Never match — always create new' ] ], def: 'sku', help: '' },
		reviews:  { options: [ [ 'review_id', 'Match by Review ID' ], [ 'external_id', 'Match by External ID' ], [ 'none', 'Never match — always create new' ] ], def: 'review_id', help: 'A review is also matched automatically by product + author email as a safety net against accidental duplicates.' },
		orders:   { options: [ [ 'external_id', 'Match by External ID (recommended)' ], [ 'order_id', 'Match by Order ID (same site only)' ], [ 'none', 'Never match — always create new' ] ], def: 'external_id', help: '' },
		customers:{ options: [ [ 'email', 'Match by Email (recommended)' ], [ 'external_id', 'Match by External ID (falls back to Email)' ] ], def: 'email', help: 'WordPress requires every account to have a unique email, so Email is the most reliable match.' },
		categories:{ options: [ [ 'slug', 'Match by Slug (recommended)' ], [ 'external_id', 'Match by External ID (falls back to Slug)' ] ], def: 'slug', help: 'Categories also match by their full parent path; tags are flat and match by slug then name.' },
	};
	var ENTITY_LABELS = { product: 'product', reviews: 'review', orders: 'order', customers: 'customer', categories: 'category/tag' };
	var EXISTING_ACTIONS = {
		product:   { options: [ [ 'update', 'Update existing' ], [ 'skip', 'Skip existing' ], [ 'duplicate', 'Create duplicate' ] ], def: 'update' },
		reviews:   { options: [ [ 'skip', 'Skip existing' ], [ 'update', 'Update existing' ], [ 'duplicate', 'Create duplicate' ] ], def: 'skip' },
		orders:    { options: [ [ 'skip', 'Skip existing' ], [ 'update', 'Update existing' ], [ 'duplicate', 'Create duplicate' ] ], def: 'skip' },
		customers: { options: [ [ 'update', 'Update existing' ], [ 'skip', 'Skip existing' ] ], def: 'update' },
		categories:{ options: [ [ 'update', 'Update existing' ], [ 'skip', 'Skip existing' ] ], def: 'update' },
	};

	function applyEntityToStep2( entity ) {
		var cfg = MATCH_STRATEGIES[ entity ] || MATCH_STRATEGIES.product;
		var $select = $( '#awpm-match-strategy' );
		$select.empty();
		$.each( cfg.options, function ( i, opt ) { $select.append( $( '<option></option>' ).attr( 'value', opt[0] ).text( opt[1] ) ); } );
		$select.val( cfg.def );
		$( '#awpm-match-strategy-help' ).text( cfg.help );

		var label = ENTITY_LABELS[ entity ] || 'record';
		$( '#awpm-step2-heading' ).text( 'What should happen to existing ' + label + 's that already exist?' );

		$( '.awpm-product-only-row' ).toggle( entity === 'product' );
		$( '.awpm-order-only-row' ).toggle( entity === 'orders' );
		$( '.awpm-review-only-row' ).toggle( entity === 'reviews' );
		$( '.awpm-categories-only-row' ).toggle( entity === 'categories' );

		var actionCfg = EXISTING_ACTIONS[ entity ] || EXISTING_ACTIONS.product;
		var $action = $( '#awpm-existing-action' );
		$action.empty();
		$.each( actionCfg.options, function ( i, opt ) { $action.append( $( '<option></option>' ).attr( 'value', opt[0] ).text( opt[1] ) ); } );
		$action.val( actionCfg.def );
	}

	function post( action, data ) {
		data = data || {};
		data.action = action;
		data.nonce = AWPM.nonce;
		return $.post( AWPM.ajax_url, data );
	}

	/**
	 * Build a secure, authenticated download URL for a job's export/import
	 * file (or a Tools-generated file, via type "tool" + a basename). The
	 * awpm-tmp folder itself is blocked from direct web access, so every
	 * download goes through this admin-post.php endpoint instead.
	 */
	function downloadUrl( type, jobId, filename ) {
		var base = AWPM.ajax_url.replace( 'admin-ajax.php', 'admin-post.php' );
		var url = base + '?action=awpm_download&type=' + type + '&_wpnonce=' + encodeURIComponent( AWPM.nonce );
		if ( jobId ) url += '&job_id=' + jobId;
		if ( filename ) url += '&file=' + encodeURIComponent( filename );
		return url;
	}

	/* =====================================================================
	 * Generic wizard engine — used by both #awpm-export-app and #awpm-import-app.
	 * =================================================================== */

	function initWizard( $app, opts ) {
		var totalSteps = $app.find( '.awpm-wizard-pane' ).length;
		var current = 1;

		function show( step ) {
			$app.find( '.awpm-wizard-pane' ).removeClass( 'active' );
			$app.find( '.awpm-wizard-pane[data-pane="' + step + '"]' ).addClass( 'active' );
			$app.find( '.awpm-wizard-step' ).removeClass( 'active done' );
			$app.find( '.awpm-wizard-step' ).each( function () {
				var s = parseInt( $( this ).data( 'step' ), 10 );
				if ( s < step ) $( this ).addClass( 'done' );
				if ( s === step ) $( this ).addClass( 'active' );
			} );
			$app.find( '.awpm-wizard-footer .awpm-back-btn' ).css( 'visibility', step === 1 ? 'hidden' : 'visible' );
			$app.find( '.awpm-wizard-footer .awpm-next-btn' ).toggle( step < totalSteps );
			current = step;
			if ( opts.onShow ) opts.onShow( step );
		}

		$app.find( '.awpm-next-btn' ).on( 'click', function () {
			if ( opts.canAdvance && ! opts.canAdvance( current ) ) return;
			if ( current < totalSteps ) show( current + 1 );
		} );
		$app.find( '.awpm-back-btn' ).on( 'click', function () {
			if ( current > 1 ) show( current - 1 );
		} );
		$app.find( '.awpm-wizard-step' ).on( 'click', function () {
			var target = parseInt( $( this ).data( 'step' ), 10 );
			if ( target <= current || ( opts.canJumpTo && opts.canJumpTo( target ) ) ) show( target );
		} );

		return { show: show, current: function () { return current; } };
	}

	/* =====================================================================
	 * Field catalog (shared by export field-selection and import mapping)
	 * =================================================================== */

	function ensureFieldCatalog( entity, cb ) {
		entity = entity || 'product';
		if ( state.fieldCatalog[ entity ] ) { cb( state.fieldCatalog[ entity ] ); return; }
		post( 'awpm_get_fields', { entity: entity } ).done( function ( res ) { if ( res.success ) { state.fieldCatalog[ entity ] = res.data; cb( res.data ); } } );
	}

	/**
	 * Normalizes the catalog into groups: [{ key, label, fields: [{selector,label,source,column}] }]
	 * `mode` is 'export' (column name shown per the CSV flatten convention)
	 * or 'import' (source column comes from the uploaded file's header).
	 */
	function buildGroups( catalog ) {
		var groups = [];
		var coreLabels = { general: 'Basic Product Fields', pricing: 'Pricing', inventory: 'Inventory', shipping: 'Shipping', tax: 'Tax', purchase: 'Downloadable / Virtual', relations: 'Linked Products', taxonomy: 'Taxonomies', images: 'Media', attributes: 'Attributes', variations: 'Variations' };

		$.each( catalog.core, function ( section, fields ) {
			var groupFields = [];
			$.each( fields, function ( key, label ) {
				groupFields.push( { selector: key, label: label, source: key, exportColumn: key } );
			} );
			groups.push( { key: 'core_' + section, label: coreLabels[ section ] || section, fields: groupFields } );
		} );

		if ( catalog.acf_active && catalog.acf.length ) {
			var acfFields = [];
			$.each( catalog.acf, function ( i, f ) {
				if ( f.selector.indexOf( '.' ) !== -1 ) return; // Only top-level ACF fields are independently selectable (see backend note on repeaters).
				acfFields.push( { selector: 'acf.' + f.selector, label: f.label + ' [' + f.type + ']', source: 'ACF: ' + f.name, exportColumn: 'acf_' + f.name } );
			} );
			groups.push( { key: 'acf', label: 'ACF Fields', fields: acfFields } );
		}

		if ( catalog.yoast_active && catalog.yoast.length ) {
			var yoastFields = [];
			$.each( catalog.yoast, function ( i, key ) {
				yoastFields.push( { selector: 'yoast.' + key, label: key.replace( 'yoast_', '' ).replace( /_/g, ' ' ), source: 'Yoast: ' + key, exportColumn: key } );
			} );
			groups.push( { key: 'yoast', label: 'Yoast SEO', fields: yoastFields } );
		}

		if ( catalog.custom_meta && Object.keys( catalog.custom_meta ).length ) {
			var metaFields = [];
			$.each( catalog.custom_meta, function ( key ) {
				metaFields.push( { selector: 'custom_meta.' + key, label: key, source: 'Meta: ' + key, exportColumn: key } );
			} );
			groups.push( { key: 'custom_meta', label: 'Custom Meta / Hidden Meta', fields: metaFields } );
		}

		return groups;
	}

	function renderFieldGroups( $container, groups, mode ) {
		$container.empty();
		$.each( groups, function ( gi, group ) {
			if ( ! group.fields.length ) return;
			var $group = $( '<div class="awpm-field-group" data-group="' + group.key + '"></div>' );
			var $header = $( '<div class="awpm-field-group-header"><span><span class="dashicons dashicons-arrow-down-alt2"></span> ' + group.label + ' <span class="awpm-group-count">(' + group.fields.length + ')</span></span><label><input type="checkbox" class="awpm-group-toggle" checked> ' + ( mode === 'export' ? 'All' : '' ) + '</label></div>' );
			var $body = $( '<div class="awpm-field-group-body"></div>' );

			$.each( group.fields, function ( fi, field ) {
				var $row = $(
					'<div class="awpm-field-row" data-selector="' + field.selector + '">' +
						( mode === 'export' ? '<input type="checkbox" class="awpm-field-check" checked>' : '' ) +
						'<span class="awpm-field-label">' + field.label + '</span>' +
						'<span class="awpm-field-source">' + field.source + '</span>' +
						( mode === 'export'
							? '<span class="awpm-field-column">' + field.exportColumn + '</span>'
							: '<span class="awpm-field-column">→</span>' )
					+ '</div>'
				);
				$body.append( $row );
			} );

			$group.append( $header ).append( $body );
			$container.append( $group );
		} );

		$container.find( '.awpm-field-group-header' ).on( 'click', function ( e ) {
			if ( $( e.target ).is( 'input' ) ) return;
			$( this ).closest( '.awpm-field-group' ).toggleClass( 'collapsed' );
		} );

		$container.find( '.awpm-group-toggle' ).on( 'change', function () {
			var checked = $( this ).is( ':checked' );
			$( this ).closest( '.awpm-field-group' ).find( '.awpm-field-check' ).prop( 'checked', checked );
		} );
	}

	function filterFieldGroups( $container, term ) {
		term = term.toLowerCase();
		$container.find( '.awpm-field-row' ).each( function () {
			var text = $( this ).text().toLowerCase();
			$( this ).toggle( text.indexOf( term ) !== -1 );
		} );
		$container.find( '.awpm-field-group' ).each( function () {
			var anyVisible = $( this ).find( '.awpm-field-row:visible' ).length > 0;
			$( this ).toggle( anyVisible );
			if ( term ) $( this ).removeClass( 'collapsed' );
		} );
	}

	/* =====================================================================
	 * EXPORT WIZARD
	 * =================================================================== */

	var $exportApp = $( '#awpm-export-app' );
	if ( $exportApp.length ) {

		$( '#awpm-export-back' ).addClass( 'awpm-back-btn' );
		$( '#awpm-export-next' ).addClass( 'awpm-next-btn' );

		var exportWizard = initWizard( $exportApp, {
			onShow: function ( step ) {
				if ( step === 4 ) loadExportFieldGroups();
			},
		} );

		// Step 1: data-type cards — Products, Reviews, Orders, Customers and
		// Categories & Tags are all real, dispatched through the same
		// per-entity filter pane / field catalog / batch-job plumbing below.
		$exportApp.on( 'click', '.awpm-card:not(.disabled)', function () {
			$( this ).siblings().removeClass( 'selected' );
			$( this ).addClass( 'selected' );
			if ( $( this ).data( 'format' ) ) {
				$( '#awpm-export-format' ).val( $( this ).data( 'format' ) );
			}
			if ( $( this ).data( 'value' ) && $( this ).closest( '.awpm-wizard-pane' ).data( 'pane' ) == 1 ) {
				state.exportEntity = $( this ).data( 'value' );
				applyEntityToExportFilters( state.exportEntity );
				$( '#awpm-export-field-groups' ).data( 'loaded', false ); // Field catalog depends on the entity — force a reload.
			}
		} );

		function applyEntityToExportFilters( entity ) {
			$exportApp.find( '.awpm-filter-pane' ).hide();
			$exportApp.find( '.awpm-filter-pane[data-filter-entity="' + entity + '"]' ).show();
			$( '#awpm-export-detected-badges' ).toggle( entity === 'product' );
		}

		$( '#awpm-export-selection' ).on( 'change', function () {
			var val = $( this ).val();
			$( '#awpm-export-selection-value' ).toggle( [ 'ids', 'skus', 'category', 'tag' ].indexOf( val ) !== -1 );
		} );

		function loadExportFieldGroups() {
			if ( $( '#awpm-export-field-groups' ).data( 'loaded' ) ) return;
			ensureFieldCatalog( state.exportEntity, function ( catalog ) {
				var groups = buildGroups( catalog );
				renderFieldGroups( $( '#awpm-export-field-groups' ), groups, 'export' );
				$( '#awpm-export-field-groups' ).data( 'loaded', true );
			} );
		}

		$( '#awpm-export-field-search' ).on( 'input', function () { filterFieldGroups( $( '#awpm-export-field-groups' ), $( this ).val() ); } );
		$( '#awpm-export-select-all' ).on( 'click', function () { $( '#awpm-export-field-groups .awpm-field-check, #awpm-export-field-groups .awpm-group-toggle' ).prop( 'checked', true ); } );
		$( '#awpm-export-select-none' ).on( 'click', function () { $( '#awpm-export-field-groups .awpm-field-check, #awpm-export-field-groups .awpm-group-toggle' ).prop( 'checked', false ); } );
		$( '#awpm-export-reset-defaults' ).on( 'click', function () { $( '#awpm-export-field-groups .awpm-field-check, #awpm-export-field-groups .awpm-group-toggle' ).prop( 'checked', true ); } );

		function collectFieldConfig() {
			// If the field-selection step was never opened, treat as "export everything" (empty enabled array = no filtering, per backend default).
			if ( ! $( '#awpm-export-field-groups' ).data( 'loaded' ) ) return { enabled: [] };
			var enabled = [];
			$( '#awpm-export-field-groups .awpm-field-row' ).each( function () {
				if ( $( this ).find( '.awpm-field-check' ).is( ':checked' ) ) enabled.push( $( this ).data( 'selector' ) );
			} );
			return { enabled: enabled };
		}

		function exportArgs() {
			var entity = state.exportEntity;

			if ( 'reviews' === entity ) {
				var reviewSkus = ( $( '#awpm-export-review-skus' ).val() || '' ).split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
				return {
					entity: entity,
					format: $( '#awpm-export-format' ).val(),
					skus: reviewSkus,
					review_status: $( '#awpm-export-review-status' ).val(),
					rating: $( '#awpm-export-review-rating' ).val(),
					verified_only: $( '#awpm-export-review-verified' ).is( ':checked' ) ? 1 : 0,
					date_created_after: $( '#awpm-export-review-after' ).val(),
					date_created_before: $( '#awpm-export-review-before' ).val(),
					batch_size: $( '#awpm-export-batch-size' ).val(),
				};
			}

			if ( 'orders' === entity ) {
				var statuses = [];
				$( '.awpm-order-status:checked' ).each( function () { statuses.push( $( this ).val() ); } );
				return {
					entity: entity,
					format: $( '#awpm-export-format' ).val(),
					order_statuses: statuses,
					customer_email: $( '#awpm-export-order-email' ).val(),
					date_created_after: $( '#awpm-export-order-after' ).val(),
					date_created_before: $( '#awpm-export-order-before' ).val(),
					batch_size: $( '#awpm-export-batch-size' ).val(),
				};
			}

			if ( 'customers' === entity ) {
				var roles = [];
				$( '.awpm-customer-role:checked' ).each( function () { roles.push( $( this ).val() ); } );
				return {
					entity: entity,
					format: $( '#awpm-export-format' ).val(),
					roles: roles,
					date_created_after: $( '#awpm-export-customer-after' ).val(),
					date_created_before: $( '#awpm-export-customer-before' ).val(),
					batch_size: $( '#awpm-export-batch-size' ).val(),
				};
			}

			if ( 'categories' === entity ) {
				var taxonomies = [];
				$( '.awpm-taxonomy:checked' ).each( function () { taxonomies.push( $( this ).val() ); } );
				return {
					entity: entity,
					format: $( '#awpm-export-format' ).val(),
					taxonomies: taxonomies,
					term_search: $( '#awpm-export-term-search' ).val(),
					hide_empty: $( '#awpm-export-hide-empty' ).is( ':checked' ) ? 1 : 0,
					batch_size: $( '#awpm-export-batch-size' ).val(),
				};
			}

			var selection = $( '#awpm-export-selection' ).val();
			var rawValue = $( '#awpm-export-selection-value' ).val() || '';
			var values = rawValue.split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
			var types = [];
			$( '.awpm-type:checked' ).each( function () { types.push( $( this ).val() ); } );

			var names = ( $( '#awpm-export-names' ).val() || '' ).split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
			var excludeNames = ( $( '#awpm-export-exclude-names' ).val() || '' ).split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
			var brand = $( '#awpm-export-brand' ).length ? $( '#awpm-export-brand' ).val() || [] : [];

			var payload = {
				entity: entity,
				format: $( '#awpm-export-format' ).val(),
				selection: selection,
				status: $( '#awpm-export-status' ).val(),
				types: types,
				batch_size: $( '#awpm-export-batch-size' ).val(),
				field_config: JSON.stringify( collectFieldConfig() ),
				limit: $( '#awpm-export-limit' ).val() || 0,
				offset: $( '#awpm-export-offset' ).val() || 0,
				product_names: names,
				exclude_names: excludeNames,
				stock_status: $( '#awpm-export-stock-status' ).val(),
				brand: brand,
				date_created_after: $( '#awpm-export-created-after' ).val(),
				date_created_before: $( '#awpm-export-created-before' ).val(),
				date_modified_after: $( '#awpm-export-modified-after' ).val(),
				date_modified_before: $( '#awpm-export-modified-before' ).val(),
			};
			if ( selection === 'ids' ) payload.product_ids = values;
			if ( selection === 'skus' ) payload.skus = values;
			if ( selection === 'category' ) payload.categories = values;
			if ( selection === 'tag' ) payload.tags = values;
			return payload;
		}

		$( '#awpm-export-load-profile' ).on( 'change', function () {
			var id = $( this ).val();
			if ( ! id ) return;
			post( 'awpm_get_mapping', { id: id } ).done( function ( res ) {
				if ( ! res.success ) return;
				var cfg = res.data.config || {};
				if ( cfg.export_args ) {
					var a = cfg.export_args;
					if ( a.format ) { $( '#awpm-export-format' ).val( a.format ); $exportApp.find( '.awpm-card[data-format="' + a.format + '"]' ).trigger( 'click' ); }
					if ( a.selection ) $( '#awpm-export-selection' ).val( a.selection ).trigger( 'change' );
					if ( a.status ) $( '#awpm-export-status' ).val( a.status );
				}
			} );
		} );

		$( '#awpm-run-export' ).on( 'click', function () {
			$( '#awpm-export-result' ).empty();
			$( '#awpm-export-progress' ).show();
			post( 'awpm_start_export_job', exportArgs() ).done( function ( res ) {
				if ( ! res.success ) { $( '#awpm-export-result' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				state.exportJobId = res.data.job_id;
				pollExportBatch();
			} );
		} );

		function pollExportBatch() {
			post( 'awpm_process_export_batch', { job_id: state.exportJobId } ).done( function ( res ) {
				if ( ! res.success ) { $( '#awpm-export-result' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				var job = res.data.job;
				var pct = job.total_rows > 0 ? Math.round( ( job.offset_row / job.total_rows ) * 100 ) : 100;
				$( '#awpm-export-progress-fill' ).css( 'width', pct + '%' );
				$( '#awpm-export-progress-text' ).text( job.processed_count + ' / ' + job.total_rows + ' record(s) processed' );

				if ( res.data.done ) {
					var dlUrl = downloadUrl( 'export', job.id );
					$( '#awpm-export-result' ).html( '<div class="notice notice-success"><p>' + job.processed_count + ' record(s) exported. <a class="button button-primary" href="' + dlUrl + '">Download file</a></p></div>' );
				} else {
					setTimeout( pollExportBatch, 300 );
				}
			} );
		}

		$( '#awpm-save-export-profile' ).on( 'click', function () {
			var name = window.prompt( 'Profile name:' );
			if ( ! name ) return;
			post( 'awpm_save_mapping', { name: name, type: 'export', config: JSON.stringify( { export_args: exportArgs() } ) } ).done( function ( res ) {
				if ( res.success ) $( '#awpm-export-result' ).prepend( '<div class="notice notice-success"><p>Profile saved.</p></div>' );
			} );
		} );

		// Map generic footer buttons to this app's markup (ids are shared class names, scoped per-app via IDs below).
	}

	/* =====================================================================
	 * IMPORT WIZARD
	 * =================================================================== */

	var $importApp = $( '#awpm-import-app' );
	if ( $importApp.length ) {

		$( '#awpm-import-back' ).addClass( 'awpm-back-btn' );
		$( '#awpm-import-next' ).addClass( 'awpm-next-btn' );

		var importWizard = initWizard( $importApp, {
			canAdvance: function ( step ) {
				if ( step === 1 && ! state.uploadedFile ) { alert( 'Upload or fetch a file first.' ); return false; }
				return true;
			},
			onShow: function ( step ) {
				if ( step === 3 ) renderImportMappingStep();
			},
		} );

		// --- Step 1: data-type cards (Products/Reviews/Orders/Customers) ---
		$importApp.on( 'click', '.awpm-card[data-entity]', function () {
			$( this ).siblings().removeClass( 'selected' );
			$( this ).addClass( 'selected' );
			state.importEntity = $( this ).data( 'entity' );
			$( '#awpm-import-entity' ).val( state.importEntity );
			applyEntityToStep2( state.importEntity );
			$( '#awpm-mapping-groups' ).data( 'rendered', false ); // Field catalog depends on the entity — force a remap on Step 3.
		} );
		applyEntityToStep2( state.importEntity ); // Initialize Step 2 for the default entity (Products).

		// --- Step 1: source toggle ---
		$importApp.on( 'click', '.awpm-source-toggle button', function () {
			var source = $( this ).data( 'source' );
			$importApp.find( '.awpm-source-toggle button' ).removeClass( 'active' );
			$( this ).addClass( 'active' );
			$importApp.find( '.awpm-source-pane' ).removeClass( 'active' );
			$importApp.find( '.awpm-source-pane[data-source-pane="' + source + '"]' ).addClass( 'active' );
		} );

		$( '#awpm-load-profile' ).on( 'change', function () {
			var id = $( this ).val();
			if ( ! id ) return;
			post( 'awpm_get_mapping', { id: id } ).done( function ( res ) {
				if ( ! res.success ) return;
				var cfg = res.data.config || {};
				if ( cfg.match_strategy ) $( '#awpm-match-strategy' ).val( cfg.match_strategy );
				if ( cfg.existing_action ) $( '#awpm-existing-action' ).val( cfg.existing_action );
				if ( cfg.options && cfg.options.image_match_strategy ) $( '#awpm-image-strategy' ).val( cfg.options.image_match_strategy );
				state.loadedMapping = cfg.mapping || {};
				state.importTransforms = cfg.transforms || {};
			} );
		} );

		function onFileReady( data ) {
			state.uploadedFile = data;
			var msg = '<div class="notice notice-success"><p>' + ( data.format === 'json' ? 'JSON file ready — canonical fields, no mapping needed.' : data.header.length + ' columns detected.' ) + '</p></div>';
			$( '#awpm-upload-status' ).html( msg );
		}

		$( '#awpm-upload-btn' ).on( 'click', function () {
			var fileInput = document.getElementById( 'awpm-import-file' );
			if ( ! fileInput.files.length ) { alert( 'Choose a file first.' ); return; }

			var formData = new FormData();
			formData.append( 'action', 'awpm_upload_file' );
			formData.append( 'nonce', AWPM.nonce );
			formData.append( 'file', fileInput.files[0] );

			$( '#awpm-upload-spinner' ).addClass( 'is-active' );
			$.ajax( { url: AWPM.ajax_url, type: 'POST', data: formData, processData: false, contentType: false } ).done( function ( res ) {
				$( '#awpm-upload-spinner' ).removeClass( 'is-active' );
				if ( ! res.success ) { alert( res.data.message ); return; }
				onFileReady( res.data );
			} );
		} );

		$( '#awpm-remote-fetch-btn' ).on( 'click', function () {
			var url = $( '#awpm-remote-url' ).val();
			if ( ! url ) { alert( 'Enter a URL first.' ); return; }
			$( '#awpm-remote-spinner' ).addClass( 'is-active' );
			post( 'awpm_fetch_remote_file', { url: url } ).done( function ( res ) {
				$( '#awpm-remote-spinner' ).removeClass( 'is-active' );
				if ( ! res.success ) { $( '#awpm-upload-status' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				onFileReady( res.data );
			} );
		} );

		$( '#awpm-ftp-fetch-btn' ).on( 'click', function () {
			var host = $( '#awpm-import-ftp-host' ).val();
			var path = $( '#awpm-import-ftp-path' ).val();
			if ( ! host || ! path ) { alert( 'Host and remote file path are required.' ); return; }
			$( '#awpm-ftp-spinner' ).addClass( 'is-active' );
			post( 'awpm_fetch_ftp_file', {
				host: host,
				port: $( '#awpm-import-ftp-port' ).val() || 21,
				username: $( '#awpm-import-ftp-username' ).val(),
				password: $( '#awpm-import-ftp-password' ).val(),
				path: path,
				use_ssl: $( '#awpm-import-ftp-ssl' ).is( ':checked' ) ? 1 : 0,
			} ).done( function ( res ) {
				$( '#awpm-ftp-spinner' ).removeClass( 'is-active' );
				if ( ! res.success ) { $( '#awpm-upload-status' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				$( '#awpm-import-ftp-password' ).val( '' ); // Never leave the password sitting in the field longer than needed.
				onFileReady( res.data );
			} );
		} );

		// --- Step 3: mapping table ---
		function renderImportMappingStep() {
			if ( ! state.uploadedFile ) return;
			if ( state.uploadedFile.format === 'json' ) {
				$( '#awpm-json-no-mapping-notice' ).show();
				$( '#awpm-csv-mapping-ui' ).hide();
				return;
			}
			$( '#awpm-json-no-mapping-notice' ).hide();
			$( '#awpm-csv-mapping-ui' ).show();
			if ( $( '#awpm-mapping-groups' ).data( 'rendered' ) ) return;

			ensureFieldCatalog( state.importEntity, function ( catalog ) {
				var groups = buildGroups( catalog );
				var $container = $( '#awpm-mapping-groups' ).empty();

				renderSourceMappingTable( $container, state.uploadedFile.header, groups );
				$( '#awpm-mapping-groups' ).data( 'rendered', true );
			} );
		}

		function flattenTargetOptions( groups ) {
			var opts = [ { value: '', label: '— Do not import / Skip —' } ];
			$.each( groups, function ( gi, group ) {
				$.each( group.fields, function ( fi, f ) { opts.push( { value: f.selector, label: group.label + ' → ' + f.label } ); } );
			} );
			return opts;
		}

		function guessTarget( sourceColumn ) {
			var known = [ 'name', 'sku', 'description', 'short_description', 'regular_price', 'sale_price', 'slug', 'status', 'type', 'stock_quantity', 'stock_status', 'weight' ];
			if ( known.indexOf( sourceColumn ) !== -1 ) return sourceColumn;
			if ( sourceColumn.indexOf( 'acf_' ) === 0 ) return 'acf.' + sourceColumn.substring( 4 );
			if ( sourceColumn.indexOf( 'yoast_' ) === 0 ) return 'yoast.' + sourceColumn;
			if ( sourceColumn.indexOf( '_' ) === 0 ) return 'custom_meta.' + sourceColumn;
			return '';
		}

		function renderSourceMappingTable( $container, header, groups ) {
			var options = flattenTargetOptions( groups );
			var $list = $( '<div class="awpm-field-group" data-group="mapping"></div>' );
			var $header = $( '<div class="awpm-field-group-header"><span><span class="dashicons dashicons-arrow-down-alt2"></span> Source Columns <span class="awpm-group-count">(' + header.length + ')</span></span></div>' );
			var $body = $( '<div class="awpm-field-group-body" id="awpm-sortable-mapping"></div>' );

			$.each( header, function ( i, column ) {
				var guessed = guessTarget( column );
				var $select = $( '<select class="awpm-target-select"></select>' );
				$.each( options, function ( oi, opt ) { $select.append( $( '<option></option>' ).attr( 'value', opt.value ).text( opt.label ) ); } );
				$select.val( guessed );

				var $row = $( '<div class="awpm-field-row" data-source="' + column + '"></div>' );
				$row.append( '<span class="awpm-drag-handle dashicons dashicons-menu"></span>' );
				$row.append( '<span class="awpm-field-label">' + column + '</span>' );
				$row.append( $select );
				$row.append( '<button type="button" class="awpm-transform-btn" title="Transform">⚙</button>' );
				$body.append( $row );
			} );

			$list.append( $header ).append( $body );
			$container.append( $list );

			if ( $.fn.sortable ) $body.sortable( { handle: '.awpm-drag-handle', axis: 'y' } );

			$container.find( '.awpm-transform-btn' ).on( 'click', function () { openTransformModal( $( this ).closest( '.awpm-field-row' ).data( 'source' ) ); } );
		}

		$( '#awpm-mapping-search' ).on( 'input', function () { filterFieldGroups( $( '#awpm-mapping-groups' ), $( this ).val() ); } );

		function collectMapping() {
			var mapping = {};
			$( '#awpm-mapping-groups .awpm-field-row' ).each( function () {
				var source = $( this ).data( 'source' );
				var target = $( this ).find( '.awpm-target-select' ).val();
				if ( target ) mapping[ source ] = target;
			} );
			return mapping;
		}

		// --- Transform modal ---
		function openTransformModal( sourceColumn ) {
			var existing = state.importTransforms[ sourceColumn ] || {};
			var $overlay = $( '<div class="awpm-modal-overlay"></div>' );
			var $modal = $( '<div class="awpm-modal"></div>' );
			$modal.append( '<h3>Transform: ' + sourceColumn + '</h3>' );

			var $optionsWrap = $( '<div></div>' );
			var options = AWPM.transforms || {};
			$optionsWrap.append( '<div class="awpm-transform-option"><label><input type="radio" name="awpm-transform-type" value="" ' + ( ! existing.type ? 'checked' : '' ) + '> No transform</label></div>' );
			$.each( options, function ( type, label ) {
				var checked = existing.type === type ? 'checked' : '';
				var $opt = $( '<div class="awpm-transform-option"><label><input type="radio" name="awpm-transform-type" value="' + type + '" ' + checked + '> ' + label + '</label></div>' );
				var $extra = $( '<div class="awpm-transform-extra' + ( checked ? ' visible' : '' ) + '" data-for="' + type + '"></div>' );

				if ( type === 'find_replace' || type === 'regex_replace' ) {
					$extra.append( '<input type="text" class="awpm-t-find" placeholder="' + ( type === 'regex_replace' ? 'Pattern (e.g. /foo/i)' : 'Find' ) + '" value="' + ( existing[ type === 'regex_replace' ? 'pattern' : 'find' ] || '' ) + '">' );
					$extra.append( '<input type="text" class="awpm-t-replace" placeholder="Replace" value="' + ( existing.replace || '' ) + '">' );
				} else if ( type === 'prefix' ) {
					$extra.append( '<input type="text" class="awpm-t-prefix" placeholder="Prefix text" value="' + ( existing.prefix || '' ) + '">' );
				} else if ( type === 'suffix' ) {
					$extra.append( '<input type="text" class="awpm-t-suffix" placeholder="Suffix text" value="' + ( existing.suffix || '' ) + '">' );
				} else if ( type === 'to_date' ) {
					$extra.append( '<input type="text" class="awpm-t-format" placeholder="Output format, e.g. Y-m-d" value="' + ( existing.format || 'Y-m-d' ) + '">' );
				}

				$opt.append( $extra );
				$optionsWrap.append( $opt );
			} );

			$modal.append( $optionsWrap );
			$modal.append( '<div class="awpm-modal-actions"><button type="button" class="button" id="awpm-transform-cancel">Cancel</button><button type="button" class="button button-primary" id="awpm-transform-apply">Apply</button></div>' );
			$overlay.append( $modal );
			$( 'body' ).append( $overlay );

			$modal.on( 'change', 'input[name="awpm-transform-type"]', function () {
				$modal.find( '.awpm-transform-extra' ).removeClass( 'visible' );
				$modal.find( '.awpm-transform-extra[data-for="' + $( this ).val() + '"]' ).addClass( 'visible' );
			} );

			$modal.find( '#awpm-transform-cancel' ).on( 'click', function () { $overlay.remove(); } );
			$modal.find( '#awpm-transform-apply' ).on( 'click', function () {
				var type = $modal.find( 'input[name="awpm-transform-type"]:checked' ).val();
				var $row = $( '#awpm-mapping-groups .awpm-field-row[data-source="' + sourceColumn + '"] .awpm-transform-btn' );
				if ( ! type ) {
					delete state.importTransforms[ sourceColumn ];
					$row.removeClass( 'has-transform' );
					$overlay.remove();
					return;
				}
				var $extra = $modal.find( '.awpm-transform-extra[data-for="' + type + '"]' );
				var config = { type: type };
				if ( type === 'find_replace' ) { config.find = $extra.find( '.awpm-t-find' ).val(); config.replace = $extra.find( '.awpm-t-replace' ).val(); }
				if ( type === 'regex_replace' ) { config.pattern = $extra.find( '.awpm-t-find' ).val(); config.replace = $extra.find( '.awpm-t-replace' ).val(); }
				if ( type === 'prefix' ) config.prefix = $extra.find( '.awpm-t-prefix' ).val();
				if ( type === 'suffix' ) config.suffix = $extra.find( '.awpm-t-suffix' ).val();
				if ( type === 'to_date' ) config.format = $extra.find( '.awpm-t-format' ).val();

				state.importTransforms[ sourceColumn ] = config;
				$row.addClass( 'has-transform' );
				$overlay.remove();
			} );
		}

		// --- Payload builder shared by preview / dry-run / real run ---
		function importPayload( extra ) {
			var mapping = state.uploadedFile.format !== 'json' ? collectMapping() : ( state.loadedMapping || {} );
			var base = {
				entity: state.importEntity,
				file_path: state.uploadedFile.file_path,
				format: state.uploadedFile.format,
				mapping: JSON.stringify( mapping ),
				transforms: JSON.stringify( state.importTransforms ),
				match_strategy: $( '#awpm-match-strategy' ).val(),
				existing_action: $( '#awpm-existing-action' ).val(),
				batch_size: $( '#awpm-batch-size' ).val(),
			};
			if ( 'product' === state.importEntity ) {
				$.extend( base, {
					image_match_strategy: $( '#awpm-image-strategy' ).val(),
					create_missing_global_attributes: $( '#awpm-create-attributes' ).is( ':checked' ) ? 1 : 0,
					create_missing_categories: $( '#awpm-create-categories' ).is( ':checked' ) ? 1 : 0,
					create_backup: $( '#awpm-create-backup' ).is( ':checked' ) ? 1 : 0,
				} );
			} else if ( 'reviews' === state.importEntity ) {
				base.default_status = $( '#awpm-review-default-status' ).val();
			} else if ( 'orders' === state.importEntity ) {
				base.create_missing_customer = $( '#awpm-create-missing-customer' ).is( ':checked' ) ? 1 : 0;
				base.set_status = $( '#awpm-order-set-status' ).val();
			} else if ( 'categories' === state.importEntity ) {
				base.create_missing_parents = $( '#awpm-create-missing-parents' ).is( ':checked' ) ? 1 : 0;
			}
			return $.extend( base, extra || {} );
		}

		// --- Step 5: preview table ---
		$( '#awpm-load-preview' ).on( 'click', function () {
			var $wrap = $( '#awpm-preview-table-wrap' ).html( '<p>Loading preview…</p>' );
			post( 'awpm_preview_import', importPayload() ).done( function ( res ) {
				if ( ! res.success ) { $wrap.html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				renderPreviewTable( $wrap, res.data.rows );
			} );
		} );

		function renderPreviewTable( $wrap, rows ) {
			var html = '<table class="widefat striped awpm-preview-table"><thead><tr>' +
				'<th>Product</th><th>SKU</th><th>Type</th><th>Price</th><th>Category</th><th>Images</th><th>Variations</th><th>ACF</th><th>Yoast</th><th>Meta</th><th>Status</th>' +
				'</tr></thead><tbody>';
			$.each( rows, function ( i, r ) {
				html += '<tr>';
				html += '<td>' + ( r.name || '—' ) + ( r.issues.length ? r.issues.map( function ( i2 ) { return '<span class="awpm-preview-issue">⚠ ' + i2 + '</span>'; } ).join( '' ) : '' ) + '</td>';
				html += '<td>' + ( r.sku || '—' ) + '</td>';
				html += '<td>' + r.type + '</td>';
				html += '<td>' + ( r.price || '—' ) + '</td>';
				html += '<td>' + ( r.categories || '—' ) + '</td>';
				html += '<td>' + r.image_count + '</td>';
				html += '<td>' + r.variation_count + '</td>';
				html += '<td class="' + ( r.has_acf ? 'awpm-preview-yes' : 'awpm-preview-no' ) + '">' + ( r.has_acf ? '✓' : '—' ) + '</td>';
				html += '<td class="' + ( r.has_yoast ? 'awpm-preview-yes' : 'awpm-preview-no' ) + '">' + ( r.has_yoast ? '✓' : '—' ) + '</td>';
				html += '<td>' + r.meta_count + '</td>';
				html += '<td class="awpm-preview-status-' + r.status + '">' + ( r.status === 'will_create' ? 'Will create' : 'Will update #' + r.existing_id ) + '</td>';
				html += '</tr>';
			} );
			html += '</tbody></table><p class="description">Showing first ' + rows.length + ' row(s). Run the full dry run below to see totals for every row.</p>';
			$wrap.html( html );
		}

		function renderSummary( job, isDryRun ) {
			var html = '<div class="notice notice-' + ( job.failed_count > 0 ? 'warning' : 'success' ) + '">';
			html += '<p><strong>' + ( isDryRun ? 'Dry run complete.' : 'Import complete.' ) + '</strong> (Job #' + job.id + ')</p><ul>';
			html += '<li>Total rows: ' + job.total_rows + '</li>';
			html += '<li>New: ' + job.created_count + '</li>';
			html += '<li>Updated: ' + job.updated_count + '</li>';
			html += '<li>Skipped: ' + job.skipped_count + '</li>';
			html += '<li>Failed: ' + job.failed_count + '</li>';
			html += '</ul>';
			if ( ! isDryRun ) html += '<p><a href="?page=awpm-logs&job_id=' + job.id + '">View details</a></p>';
			html += '</div>';
			$( '#awpm-import-result' ).html( html );
		}

		function runImportJob( dryRun ) {
			if ( ! state.uploadedFile ) return;
			if ( ! dryRun && ! window.confirm( AWPM.i18n.confirm_import ) ) return;

			$( '#awpm-import-progress' ).show();
			$( '#awpm-import-result' ).empty();

			post( 'awpm_start_import_job', importPayload( { dry_run: dryRun ? 1 : 0 } ) ).done( function ( res ) {
				if ( ! res.success ) { $( '#awpm-import-result' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				state.importJobId = res.data.job_id;
				pollImportBatch( dryRun );
			} );
		}

		function pollImportBatch( dryRun ) {
			post( 'awpm_process_import_batch', { job_id: state.importJobId } ).done( function ( res ) {
				if ( ! res.success ) { $( '#awpm-import-result' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
				var job = res.data.job;
				var pct = job.total_rows > 0 ? Math.round( ( job.offset_row / job.total_rows ) * 100 ) : 100;
				$( '#awpm-import-progress-fill' ).css( 'width', pct + '%' );
				$( '#awpm-import-progress-text' ).text(
					job.offset_row + ' / ' + job.total_rows + ' — Created: ' + job.created_count + ', Updated: ' + job.updated_count + ', Skipped: ' + job.skipped_count + ', Failed: ' + job.failed_count
				);

				if ( res.data.done ) renderSummary( job, dryRun );
				else setTimeout( function () { pollImportBatch( dryRun ); }, 250 );
			} );
		}

		$( '#awpm-dry-run-btn' ).on( 'click', function () { runImportJob( true ); } );
		$( '#awpm-run-import-btn' ).on( 'click', function () { runImportJob( false ); } );

		$( '#awpm-save-import-profile' ).on( 'click', function () {
			var name = window.prompt( 'Profile name:' );
			if ( ! name ) return;
			var payload = importPayload( {} );
			var config = {
				mapping: JSON.parse( payload.mapping ),
				transforms: JSON.parse( payload.transforms ),
				match_strategy: payload.match_strategy,
				existing_action: payload.existing_action,
				options: { image_match_strategy: payload.image_match_strategy, create_missing_global_attributes: !!payload.create_missing_global_attributes, create_missing_categories: !!payload.create_missing_categories },
			};
			post( 'awpm_save_mapping', { name: name, type: 'import', config: JSON.stringify( config ) } ).done( function ( res ) {
				if ( res.success ) $( '#awpm-import-result' ).prepend( '<div class="notice notice-success"><p>Profile saved.</p></div>' );
			} );
		} );
	}

	/* =====================================================================
	 * Mappings page
	 * =================================================================== */

	$( document ).on( 'click', '.awpm-mapping-delete', function ( e ) {
		e.preventDefault();
		if ( ! window.confirm( AWPM.i18n.confirm_destructive ) ) return;
		var id = $( this ).data( 'id' );
		post( 'awpm_delete_mapping', { id: id } ).done( function () { $( 'tr[data-id="' + id + '"]' ).remove(); } );
	} );

	$( document ).on( 'click', '.awpm-mapping-duplicate', function ( e ) {
		e.preventDefault();
		var name = window.prompt( 'New profile name:' );
		if ( ! name ) return;
		post( 'awpm_duplicate_mapping', { id: $( this ).data( 'id' ), name: name } ).done( function ( res ) { if ( res.success ) location.reload(); } );
	} );

	$( document ).on( 'click', '.awpm-mapping-export', function ( e ) {
		e.preventDefault();
		post( 'awpm_export_mapping', { id: $( this ).data( 'id' ) } ).done( function ( res ) {
			if ( ! res.success ) return;
			var blob = new Blob( [ res.data.json ], { type: 'application/json' } );
			var a = document.createElement( 'a' );
			a.href = URL.createObjectURL( blob );
			a.download = 'awpm-mapping.json';
			a.click();
		} );
	} );

	$( '#awpm-mapping-import-btn' ).on( 'click', function () {
		var fileInput = document.getElementById( 'awpm-mapping-import-file' );
		if ( ! fileInput.files.length ) return;
		var reader = new FileReader();
		reader.onload = function ( e ) {
			post( 'awpm_import_mapping', { json: e.target.result } ).done( function ( res ) {
				if ( res.success ) location.reload();
				else $( '#awpm-mappings-result' ).html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' );
			} );
		};
		reader.readAsText( fileInput.files[0] );
	} );

	/* =====================================================================
	 * Tools page
	 * =================================================================== */

	$( document ).on( 'click', '.awpm-tool', function () {
		var tool = $( this ).data( 'tool' );
		if ( $( this ).hasClass( 'awpm-tool-confirm' ) && ! window.confirm( AWPM.i18n.confirm_destructive ) ) return;

		var $result = $( '#awpm-tools-result' );
		$result.html( '<p>Running…</p>' );
		post( 'awpm_run_tool', { tool: tool } ).done( function ( res ) {
			if ( ! res.success ) { $result.html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
			var data = res.data.result;
			if ( tool === 'generate_sample_export' && data.file_path ) {
				var fname = data.file_path.split( '/' ).pop();
				var dlUrl = downloadUrl( 'tool', null, fname );
				$result.html( '<div class="notice notice-success"><p>Sample export generated. <a class="button button-primary" href="' + dlUrl + '">Download</a></p></div>' );
				return;
			}
			if ( typeof data === 'number' ) {
				$result.html( '<div class="notice notice-success"><p>Done. Result: ' + data + '</p></div>' );
				return;
			}
			$result.html( '<pre class="awpm-tool-output">' + JSON.stringify( data, null, 2 ) + '</pre>' );
		} );
	} );

	/* =====================================================================
	 * Scheduler page
	 * =================================================================== */

	$( '#awpm-sched-source-type' ).on( 'change', function () {
		var type = $( this ).val();
		$( '#awpm-sched-source-remote_url' ).toggle( type === 'remote_url' );
		$( '#awpm-sched-source-ftp' ).toggle( type === 'ftp' );
	} );

	$( '#awpm-sched-create' ).on( 'click', function () {
		var sourceType = $( '#awpm-sched-source-type' ).val();
		var payload = {
			name: $( '#awpm-sched-name' ).val(),
			type: 'import',
			recurrence: $( '#awpm-sched-recurrence' ).val(),
			source_type: sourceType,
			mapping_profile_id: $( '#awpm-sched-mapping' ).val(),
		};
		if ( sourceType === 'ftp' ) {
			payload.ftp_host = $( '#awpm-sched-ftp-host' ).val();
			payload.ftp_port = $( '#awpm-sched-ftp-port' ).val() || 21;
			payload.ftp_username = $( '#awpm-sched-ftp-username' ).val();
			payload.ftp_password = $( '#awpm-sched-ftp-password' ).val();
			payload.ftp_path = $( '#awpm-sched-ftp-path' ).val();
			payload.ftp_use_ssl = $( '#awpm-sched-ftp-ssl' ).is( ':checked' ) ? 1 : 0;
		} else {
			payload.url = $( '#awpm-sched-url' ).val();
		}
		post( 'awpm_save_schedule', payload ).done( function ( res ) { if ( res.success ) location.reload(); } );
	} );

	$( document ).on( 'click', '.awpm-schedule-delete', function ( e ) {
		e.preventDefault();
		if ( ! window.confirm( AWPM.i18n.confirm_destructive ) ) return;
		var id = $( this ).data( 'id' );
		post( 'awpm_delete_schedule', { id: id } ).done( function () { $( 'tr[data-id="' + id + '"]' ).remove(); } );
	} );

	/* =====================================================================
	 * History / rollback
	 * =================================================================== */

	$( document ).on( 'click', '.awpm-rollback-link', function ( e ) {
		e.preventDefault();
		if ( ! window.confirm( AWPM.i18n.confirm_rollback ) ) return;
		var jobId = $( this ).data( 'job-id' );
		post( 'awpm_rollback_job', { job_id: jobId } ).done( function ( res ) {
			if ( res.success ) { alert( 'Rolled back: ' + res.data.restored + ' restored, ' + res.data.trashed + ' trashed.' ); location.reload(); }
			else alert( res.data.message );
		} );
	} );

	/* =====================================================================
	 * Logs page
	 * =================================================================== */

	$( '#awpm-clear-logs, #awpm-clear-logs-2' ).on( 'click', function () {
		if ( ! window.confirm( AWPM.i18n.confirm_destructive ) ) return;
		post( 'awpm_clear_logs' ).done( function () { location.reload(); } );
	} );

	/* =====================================================================
	 * Status page
	 * =================================================================== */

	$( '#awpm-copy-report' ).on( 'click', function () {
		var text = document.getElementById( 'awpm-report-text' );
		text.style.position = 'static';
		text.select();
		document.execCommand( 'copy' );
		text.style.position = 'absolute';
		text.style.left = '-9999px';
		$( '#awpm-status-result' ).html( '<div class="notice notice-success"><p>Copied.</p></div>' );
	} );

	$( '#awpm-run-diagnostics, #awpm-run-diagnostics-2, #awpm-check-compat' ).on( 'click', function () {
		var $result = $( '#awpm-status-result' );
		$result.html( '<p>Running…</p>' );
		post( 'awpm_run_diagnostics' ).done( function ( res ) {
			if ( ! res.success ) { $result.html( '<div class="notice notice-error"><p>' + res.data.message + '</p></div>' ); return; }
			$result.html( '<div class="notice notice-success"><p>Diagnostics complete. ' + res.data.sample_validation_issues + ' potential data issues found in a 200-product sample (see Tools → Validate Product Data for the full list).</p></div>' );
		} );
	} );

} )( jQuery );
