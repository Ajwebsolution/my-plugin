<?php
/**
 * AWPM_Settings
 *
 * Registers the single `awpm_settings` option via WordPress's Settings
 * API (so nonce/capability/sanitization all run through core, not a
 * custom form handler) and sanitizes every field. Every setting here is
 * actually read somewhere in the plugin (see the grep-able list in each
 * method's docblock) — nothing is a UI-only toggle.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Settings {

	const OPTION = 'awpm_settings';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function register() {
		register_setting( self::OPTION, self::OPTION, array( __CLASS__, 'sanitize' ) );
	}

	/**
	 * @param array $input Raw $_POST['awpm_settings'].
	 * @return array Sanitized settings, merged over existing values so a
	 *               partial submit (one tab's fields) never clobbers other
	 *               tabs' settings.
	 */
	public static function sanitize( $input ) {
		$existing = get_option( self::OPTION, array() );
		$input    = is_array( $input ) ? $input : array();

		$bool_fields = array(
			'create_missing_global_attributes', 'create_missing_categories', 'logging_enabled',
			'create_backup_before_update', 'enable_rollback', 'notify_on_completion', 'notify_on_failure',
			'download_remote_images', 'update_existing_acf', 'update_existing_yoast', 'preserve_empty_values',
			'delete_data_on_uninstall',
		);
		foreach ( $bool_fields as $field ) {
			if ( array_key_exists( $field, $input ) ) {
				$existing[ $field ] = ! empty( $input[ $field ] );
			}
		}

		$text_fields = array( 'default_match_strategy', 'image_match_strategy', 'webhook_url', 'export_filename_pattern', 'csv_delimiter' );
		foreach ( $text_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$existing[ $field ] = sanitize_text_field( $input[ $field ] );
			}
		}

		$int_fields = array( 'batch_size', 'log_retention_days', 'snapshot_retention_days', 'remote_timeout' );
		foreach ( $int_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$existing[ $field ] = max( 1, (int) $input[ $field ] );
			}
		}

		if ( isset( $input['notification_emails'] ) ) {
			$emails = array_filter( array_map( 'sanitize_email', explode( ',', $input['notification_emails'] ) ) );
			$existing['notification_emails'] = $emails;
		}
		if ( isset( $input['webhook_events'] ) ) {
			$existing['webhook_events'] = array_map( 'sanitize_key', (array) $input['webhook_events'] );
		}

		return $existing;
	}

	public static function get( $key, $default = null ) {
		$settings = get_option( self::OPTION, array() );
		return $settings[ $key ] ?? $default;
	}
}
