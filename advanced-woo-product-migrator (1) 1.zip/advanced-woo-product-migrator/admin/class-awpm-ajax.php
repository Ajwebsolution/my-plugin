<?php
/**
 * AWPM_Ajax
 *
 * All AJAX endpoints backing the admin UI. Every handler verifies the
 * nonce and the manage_awpm/manage_woocommerce capability before doing
 * anything. Batch endpoints (process_import_batch / process_export_batch)
 * are what the wizard's progress bar polls — each call advances the job
 * by exactly one batch and returns progress, so a 10,000-row import is
 * never handled in a single blocking request.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Ajax {

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	protected function __construct() {
		$actions = array(
			'awpm_get_fields'          => 'get_fields',
			'awpm_upload_file'         => 'upload_file',
			'awpm_fetch_remote_file'   => 'fetch_remote_file',
			'awpm_fetch_ftp_file'      => 'fetch_ftp_file',
			'awpm_preview_import'      => 'preview_import',

			'awpm_start_export_job'    => 'start_export_job',
			'awpm_process_export_batch'=> 'process_export_batch',

			'awpm_start_import_job'    => 'start_import_job',
			'awpm_process_import_batch'=> 'process_import_batch',

			'awpm_save_mapping'        => 'save_mapping',
			'awpm_get_mapping'         => 'get_mapping',
			'awpm_duplicate_mapping'   => 'duplicate_mapping',
			'awpm_delete_mapping'      => 'delete_mapping',
			'awpm_export_mapping'      => 'export_mapping',
			'awpm_import_mapping'      => 'import_mapping',

			'awpm_run_tool'            => 'run_tool',

			'awpm_rollback_job'        => 'rollback_job',

			'awpm_save_schedule'       => 'save_schedule',
			'awpm_delete_schedule'     => 'delete_schedule',

			'awpm_clear_logs'          => 'clear_logs',
			'awpm_run_diagnostics'     => 'run_diagnostics',
		);
		foreach ( $actions as $action => $method ) {
			add_action( 'wp_ajax_' . $action, array( $this, $method ) );
		}

		// Not an AJAX action — a direct GET download endpoint. AJAX actions
		// return JSON, which can't stream a file for the browser to save;
		// admin-post.php is the standard WP way to serve an authenticated
		// file download. Registered here since this class already owns the
		// nonce/capability check pattern the rest of the plugin uses.
		add_action( 'admin_post_awpm_download', array( $this, 'download_file' ) );
	}

	protected function verify_request() {
		check_ajax_referer( 'awpm_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_awpm' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'advanced-woo-product-migrator' ) ), 403 );
		}
	}

	/**
	 * Authenticated file download for export jobs (admin_post_awpm_download).
	 *
	 * Export files live in wp-content/uploads/awpm-tmp/, which is
	 * intentionally blocked from direct web access (.htaccess "Deny from
	 * all" — otherwise anyone who guesses/finds a filename could download
	 * a full product export). This endpoint is the only sanctioned way to
	 * fetch one: it re-checks capability + nonce, resolves the real file
	 * path from the job row in the database (never trusts a path from the
	 * request), confirms the resolved path is still inside awpm-tmp, and
	 * only then streams it. GET + admin-post.php (not admin-ajax.php)
	 * because a JSON AJAX response can't hand the browser a file to save.
	 */
	public function download_file() {
		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'awpm_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed. Please go back and try downloading again.', 'advanced-woo-product-migrator' ), '', array( 'response' => 403 ) );
		}
		if ( ! current_user_can( 'manage_awpm' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'advanced-woo-product-migrator' ), '', array( 'response' => 403 ) );
		}

		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : 'export';
		$job_id = isset( $_GET['job_id'] ) ? absint( $_GET['job_id'] ) : 0;

		if ( 'tool' === $type ) {
			// Tools-generated files (currently: the sample export) aren't
			// tied to a job row — only a basename is trusted from the
			// request, reconstructed against the fixed tmp directory so a
			// path-traversal attempt (../../wp-config.php etc.) can't
			// escape it, and required to match the plugin's own naming
			// prefix as a second check.
			$upload_dir = wp_upload_dir();
			$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp/';
			$basename   = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
			$file_path  = $tmp_dir . basename( $basename );

			if ( ! $basename || 0 !== strpos( $basename, 'awpm-' ) || ! file_exists( $file_path ) ) {
				wp_die( esc_html__( 'File not found or no longer available.', 'advanced-woo-product-migrator' ), '', array( 'response' => 404 ) );
			}

			$this->stream_file( $file_path, $basename );
		}

		$job = 'import' === $type ? AWPM_Jobs::get_import_job( $job_id ) : AWPM_Jobs::get_export_job( $job_id );
		if ( ! $job || empty( $job['file_path'] ) ) {
			wp_die( esc_html__( 'File not found for this job.', 'advanced-woo-product-migrator' ), '', array( 'response' => 404 ) );
		}

		$file_path  = $job['file_path'];
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp/';

		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) || ! file_exists( $file_path ) ) {
			wp_die( esc_html__( 'File not found or no longer available (temporary export/import files are cleaned up automatically after 48 hours — export again if needed).', 'advanced-woo-product-migrator' ), '', array( 'response' => 404 ) );
		}

		$actual_ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		$this->stream_file( $file_path, 'awpm-' . $type . '-' . $job_id . '.' . $actual_ext );
	}

	/**
	 * Send the right headers and stream a file to the browser, then exit.
	 * Shared by both branches of download_file().
	 */
	protected function stream_file( $file_path, $download_name ) {
		$ext          = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		$content_type = array( 'json' => 'application/json', 'csv' => 'text/csv', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );

		nocache_headers();
		header( 'Content-Type: ' . ( $content_type[ $ext ] ?? 'application/octet-stream' ) );
		header( 'Content-Disposition: attachment; filename="' . $download_name . '"' );
		header( 'Content-Length: ' . filesize( $file_path ) );

		// A large export can be tens of MB; stream it rather than loading
		// the whole file into PHP memory with file_get_contents().
		$fh = fopen( $file_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( $fh ) {
			fpassthru( $fh );
			fclose( $fh );
		}
		exit;
	}

	/* ------------------------- Field discovery ------------------------- */

	public function get_fields() {
		$this->verify_request();

		$entity = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'product';

		// Non-product entities (Reviews/Orders/Customers) are plain
		// WP_Comment/WC_Order/WP_User data — there's no ACF/Yoast layer for
		// them, so the catalog is just their own fixed core-field set rather
		// than pretending an ACF/Yoast toggle applies.
		if ( 'reviews' === $entity ) {
			wp_send_json_success( array( 'core' => AWPM_Field_Registry::get_review_fields(), 'acf' => array(), 'acf_active' => false, 'yoast' => array(), 'yoast_active' => false, 'custom_meta' => array(), 'taxonomies' => array(), 'attributes' => array(), 'product_types' => array() ) );
		}
		if ( 'orders' === $entity ) {
			wp_send_json_success( array( 'core' => AWPM_Field_Registry::get_order_fields(), 'acf' => array(), 'acf_active' => false, 'yoast' => array(), 'yoast_active' => false, 'custom_meta' => array(), 'taxonomies' => array(), 'attributes' => array(), 'product_types' => array() ) );
		}
		if ( 'customers' === $entity ) {
			wp_send_json_success( array( 'core' => AWPM_Field_Registry::get_customer_fields(), 'acf' => array(), 'acf_active' => false, 'yoast' => array(), 'yoast_active' => false, 'custom_meta' => array(), 'taxonomies' => array(), 'attributes' => array(), 'product_types' => array() ) );
		}
		if ( 'categories' === $entity ) {
			wp_send_json_success( array( 'core' => AWPM_Field_Registry::get_taxonomy_fields(), 'acf' => array(), 'acf_active' => false, 'yoast' => array(), 'yoast_active' => false, 'custom_meta' => array(), 'taxonomies' => array(), 'attributes' => array(), 'product_types' => array() ) );
		}

		wp_send_json_success(
			array(
				'core'         => AWPM_Field_Registry::get_core_fields(),
				'acf'          => AWPM_ACF_Handler::is_active() ? AWPM_Field_Registry::get_acf_fields() : array(),
				'acf_active'   => AWPM_ACF_Handler::is_active(),
				'yoast'        => AWPM_Yoast_Handler::is_active() ? array_keys( AWPM_Field_Registry::get_yoast_field_map() ) : array(),
				'yoast_active' => AWPM_Yoast_Handler::is_active(),
				'custom_meta'  => AWPM_Field_Registry::discover_custom_meta_keys(),
				'taxonomies'   => AWPM_Tools::scan_taxonomies(),
				'attributes'   => AWPM_Tools::scan_attributes(),
				'product_types'=> AWPM_Tools::scan_product_types(),
			)
		);
	}

	/* ------------------------- Export (batch job) ------------------------- */

	public function start_export_job() {
		$this->verify_request();

		$entity = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'product';

		if ( 'reviews' === $entity ) {
			$args = array(
				'format'        => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
				'product_ids'   => $this->ints( $_POST['product_ids'] ?? array() ),
				'skus'          => $this->texts( $_POST['skus'] ?? array() ),
				'status'        => isset( $_POST['review_status'] ) ? sanitize_key( wp_unslash( $_POST['review_status'] ) ) : 'approve',
				'rating'        => isset( $_POST['rating'] ) ? sanitize_text_field( wp_unslash( $_POST['rating'] ) ) : '',
				'verified_only' => ! empty( $_POST['verified_only'] ),
				'date_after'    => isset( $_POST['date_created_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_after'] ) ) : '',
				'date_before'   => isset( $_POST['date_created_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_before'] ) ) : '',
				'limit'         => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
				'offset'        => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
				'batch_size'    => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 ),
			);
			$exporter = AWPM_Entity_Registry::get_exporter( 'reviews' );
			$job_id   = is_wp_error( $exporter ) ? $exporter : $exporter->start_job( $args );
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'orders' === $entity ) {
			$args = array(
				'format'         => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
				'order_ids'      => $this->ints( $_POST['product_ids'] ?? array() ),
				'statuses'       => $this->texts( $_POST['order_statuses'] ?? array() ),
				'date_after'     => isset( $_POST['date_created_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_after'] ) ) : '',
				'date_before'    => isset( $_POST['date_created_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_before'] ) ) : '',
				'customer_email' => isset( $_POST['customer_email'] ) ? sanitize_email( wp_unslash( $_POST['customer_email'] ) ) : '',
				'limit'          => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
				'offset'         => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
				'batch_size'     => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 ),
			);
			$exporter = AWPM_Entity_Registry::get_exporter( 'orders' );
			$job_id   = is_wp_error( $exporter ) ? $exporter : $exporter->start_job( $args );
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'customers' === $entity ) {
			$args = array(
				'format'             => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
				'user_ids'           => $this->ints( $_POST['product_ids'] ?? array() ),
				'roles'              => $this->texts( $_POST['roles'] ?? array( 'customer' ) ),
				'registered_after'   => isset( $_POST['date_created_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_after'] ) ) : '',
				'registered_before'  => isset( $_POST['date_created_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_before'] ) ) : '',
				'limit'              => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
				'offset'             => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
				'batch_size'         => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 ),
			);
			$exporter = AWPM_Entity_Registry::get_exporter( 'customers' );
			$job_id   = is_wp_error( $exporter ) ? $exporter : $exporter->start_job( $args );
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'categories' === $entity ) {
			$args = array(
				'format'        => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
				'taxonomies'    => $this->texts( $_POST['taxonomies'] ?? array() ),
				'search'        => isset( $_POST['term_search'] ) ? sanitize_text_field( wp_unslash( $_POST['term_search'] ) ) : '',
				'include_empty' => ! isset( $_POST['hide_empty'] ) || empty( $_POST['hide_empty'] ) ? true : false,
				'limit'         => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
				'offset'        => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
				'batch_size'    => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 ),
			);
			$exporter = AWPM_Entity_Registry::get_exporter( 'categories' );
			$job_id   = is_wp_error( $exporter ) ? $exporter : $exporter->start_job( $args );
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		$field_config = json_decode( wp_unslash( $_POST['field_config'] ?? '{}' ), true ); // phpcs:ignore
		$field_config = is_array( $field_config ) ? $field_config : array();

		$args = array(
			'format'     => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
			'selection'  => isset( $_POST['selection'] ) ? sanitize_key( wp_unslash( $_POST['selection'] ) ) : 'all',
			'product_ids'=> $this->ints( $_POST['product_ids'] ?? array() ),
			'skus'       => $this->texts( $_POST['skus'] ?? array() ),
			'categories' => $this->texts( $_POST['categories'] ?? array() ),
			'tags'       => $this->texts( $_POST['tags'] ?? array() ),
			'types'      => $this->texts( $_POST['types'] ?? array() ),
			'status'     => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'any',
			'batch_size' => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 ),
			'meta_rules' => array( 'mode' => 'export_all' ),
			'field_config' => $field_config,
			'limit'         => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
			'offset'        => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
			'product_names' => $this->texts( $_POST['product_names'] ?? array() ),
			'exclude_names' => $this->texts( $_POST['exclude_names'] ?? array() ),
			'exclude_ids'   => $this->ints( $_POST['exclude_ids'] ?? array() ),
			'stock_status'  => isset( $_POST['stock_status'] ) ? sanitize_key( wp_unslash( $_POST['stock_status'] ) ) : '',
			'brand'         => $this->texts( $_POST['brand'] ?? array() ),
			'date_created_after'  => isset( $_POST['date_created_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_after'] ) ) : '',
			'date_created_before' => isset( $_POST['date_created_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_before'] ) ) : '',
			'date_modified_after' => isset( $_POST['date_modified_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_modified_after'] ) ) : '',
			'date_modified_before'=> isset( $_POST['date_modified_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_modified_before'] ) ) : '',
		);

		$exporter = new AWPM_Product_Exporter();
		$job_id   = $exporter->start_job( $args );

		is_wp_error( $job_id )
			? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) )
			: wp_send_json_success( array( 'job_id' => $job_id ) );
	}

	public function process_export_batch() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );

		// The job row itself (not the request) is the source of truth for
		// which entity this job is — the browser just keeps polling the same
		// job_id every tick, so the entity has to be resolvable from the DB
		// alone.
		$job      = AWPM_Jobs::get_export_job( $job_id );
		$entity   = $job['entity_type'] ?? 'product';
		$exporter = 'product' === $entity ? new AWPM_Product_Exporter() : AWPM_Entity_Registry::get_exporter( $entity );

		if ( is_wp_error( $exporter ) ) {
			wp_send_json_error( array( 'message' => $exporter->get_error_message() ) );
		}

		$result = $exporter->process_next_batch( $job_id );

		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( $result );
	}

	/* ------------------------- Import (upload + batch job) ------------------------- */

	public function upload_file() {
		$this->verify_request();

		if ( empty( $_FILES['file'] ) || ! isset( $_FILES['file']['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'advanced-woo-product-migrator' ) ) );
		}

		$file = $_FILES['file']; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$ext  = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		$allowed_exts = array( 'csv', 'json' );
		if ( AWPM_XLSX_Handler::is_available() ) {
			$allowed_exts[] = 'xlsx';
		}
		if ( ! in_array( $ext, $allowed_exts, true ) ) {
			wp_send_json_error(
				array(
					'message' => AWPM_XLSX_Handler::is_available()
						? __( 'Only .csv, .json and .xlsx files are supported.', 'advanced-woo-product-migrator' )
						: __( 'Only .csv and .json files are supported (.xlsx needs the ZipArchive PHP extension, which isn\'t available on this server).', 'advanced-woo-product-migrator' ),
				)
			);
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp';
		wp_mkdir_p( $tmp_dir );
		$dest = trailingslashit( $tmp_dir ) . 'awpm-import-' . wp_generate_password( 8, false ) . '.' . $ext;

		if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			wp_send_json_error( array( 'message' => __( 'Could not store uploaded file.', 'advanced-woo-product-migrator' ) ) );
		}

		$header = $this->read_header_for_format( $ext, $dest );
		if ( is_wp_error( $header ) ) {
			wp_send_json_error( array( 'message' => $header->get_error_message() ) );
		}

		wp_send_json_success( array( 'file_path' => $dest, 'format' => $ext, 'header' => $header ) );
	}

	protected function read_header_for_format( $format, $file_path ) {
		if ( 'csv' === $format ) {
			return AWPM_CSV_Handler::read_header( $file_path );
		}
		if ( 'xlsx' === $format ) {
			return AWPM_XLSX_Handler::read_header( $file_path );
		}
		return array(); // JSON is self-describing — no header/mapping step needed.
	}

	/**
	 * Fetch a remote CSV/JSON/XLSX for import via the SSRF-safe fetcher —
	 * same validated path the scheduler uses, now available from the
	 * manual Import wizard's "Remote URL" source option too.
	 */
	public function fetch_remote_file() {
		$this->verify_request();
		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		if ( ! $url ) {
			wp_send_json_error( array( 'message' => __( 'URL is required.', 'advanced-woo-product-migrator' ) ) );
		}

		$fetched = AWPM_Remote_Fetcher::fetch( $url );
		if ( is_wp_error( $fetched ) ) {
			wp_send_json_error( array( 'message' => $fetched->get_error_message() ) );
		}

		$header = $this->read_header_for_format( $fetched['format'], $fetched['file_path'] );
		if ( is_wp_error( $header ) ) {
			wp_send_json_error( array( 'message' => $header->get_error_message() ) );
		}

		wp_send_json_success( array( 'file_path' => $fetched['file_path'], 'format' => $fetched['format'], 'header' => $header ) );
	}

	/**
	 * Fetch a file from an FTP/FTPS server for manual import (Import
	 * wizard's "FTP / FTPS" source option). The password only ever
	 * travels for this one request — it isn't persisted anywhere; a
	 * recurring FTP import is configured under Scheduled Jobs instead,
	 * where it's stored so the cron job can reconnect on its own.
	 */
	public function fetch_ftp_file() {
		$this->verify_request();

		$config = array(
			'host'     => sanitize_text_field( wp_unslash( $_POST['host'] ?? '' ) ),
			'port'     => absint( $_POST['port'] ?? 21 ),
			'username' => sanitize_text_field( wp_unslash( $_POST['username'] ?? '' ) ),
			'password' => wp_unslash( $_POST['password'] ?? '' ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			'path'     => sanitize_text_field( wp_unslash( $_POST['path'] ?? '' ) ),
			'use_ssl'  => ! empty( $_POST['use_ssl'] ),
		);

		$fetched = AWPM_Ftp_Fetcher::fetch( $config );
		if ( is_wp_error( $fetched ) ) {
			wp_send_json_error( array( 'message' => $fetched->get_error_message() ) );
		}

		$header = $this->read_header_for_format( $fetched['format'], $fetched['file_path'] );
		if ( is_wp_error( $header ) ) {
			wp_send_json_error( array( 'message' => $header->get_error_message() ) );
		}

		wp_send_json_success( array( 'file_path' => $fetched['file_path'], 'format' => $fetched['format'], 'header' => $header ) );
	}

	/**
	 * Read-only preview: maps the first N rows and reports create/update/
	 * skip verdicts and key fields, without writing anything.
	 */
	public function preview_import() {
		$this->verify_request();

		$entity    = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'product';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$format    = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json';

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp/';
		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file path.', 'advanced-woo-product-migrator' ) ) );
		}

		$mapping = json_decode( wp_unslash( $_POST['mapping'] ?? '{}' ), true ); // phpcs:ignore
		$mapping = is_array( $mapping ) ? $mapping : array();

		$transforms = json_decode( wp_unslash( $_POST['transforms'] ?? '{}' ), true ); // phpcs:ignore
		$transforms = is_array( $transforms ) ? $transforms : array();

		$preview_args = array(
			'file_path'      => $file_path,
			'format'         => $format,
			'mapping'        => $mapping,
			'transforms'     => $transforms,
			'match_strategy' => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'sku',
		);

		$importer = 'product' === $entity ? new AWPM_Product_Importer() : AWPM_Entity_Registry::get_importer( $entity );
		if ( is_wp_error( $importer ) ) {
			wp_send_json_error( array( 'message' => $importer->get_error_message() ) );
		}

		$rows = $importer->preview_rows( $preview_args, 20 );

		is_wp_error( $rows ) ? wp_send_json_error( array( 'message' => $rows->get_error_message() ) ) : wp_send_json_success( array( 'rows' => $rows ) );
	}

	public function start_import_job() {
		$this->verify_request();

		$entity    = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'product';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$format    = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json';

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'awpm-tmp/';
		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file path.', 'advanced-woo-product-migrator' ) ) );
		}

		$mapping = json_decode( wp_unslash( $_POST['mapping'] ?? '{}' ), true ); // phpcs:ignore
		$mapping = is_array( $mapping ) ? $mapping : array();

		$transforms = json_decode( wp_unslash( $_POST['transforms'] ?? '{}' ), true ); // phpcs:ignore
		$transforms = is_array( $transforms ) ? $transforms : array();

		$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) AWPM_Settings::get( 'batch_size', 50 );
		$dry_run    = ! empty( $_POST['dry_run'] );

		if ( 'reviews' === $entity ) {
			$importer = AWPM_Entity_Registry::get_importer( 'reviews' );
			$job_id   = is_wp_error( $importer ) ? $importer : $importer->start_job(
				array(
					'file_path'       => $file_path,
					'format'          => $format,
					'mapping'         => $mapping,
					'match_strategy'  => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'review_id',
					'existing_action' => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'skip',
					'default_status'  => isset( $_POST['default_status'] ) ? sanitize_key( wp_unslash( $_POST['default_status'] ) ) : 'approve',
					'batch_size'      => $batch_size,
					'dry_run'         => $dry_run,
				)
			);
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'orders' === $entity ) {
			$importer = AWPM_Entity_Registry::get_importer( 'orders' );
			$job_id   = is_wp_error( $importer ) ? $importer : $importer->start_job(
				array(
					'file_path'               => $file_path,
					'format'                  => $format,
					'mapping'                 => $mapping,
					'match_strategy'          => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'external_id',
					'existing_action'         => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'skip',
					'create_missing_customer' => ! empty( $_POST['create_missing_customer'] ),
					'set_status'              => isset( $_POST['set_status'] ) ? sanitize_key( wp_unslash( $_POST['set_status'] ) ) : '',
					'batch_size'              => $batch_size ?: 25,
					'dry_run'                 => $dry_run,
				)
			);
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'customers' === $entity ) {
			$importer = AWPM_Entity_Registry::get_importer( 'customers' );
			$job_id   = is_wp_error( $importer ) ? $importer : $importer->start_job(
				array(
					'file_path'       => $file_path,
					'format'          => $format,
					'mapping'         => $mapping,
					'match_strategy'  => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'email',
					'existing_action' => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'update',
					'default_role'    => isset( $_POST['default_role'] ) ? sanitize_key( wp_unslash( $_POST['default_role'] ) ) : 'customer',
					'batch_size'      => $batch_size,
					'dry_run'         => $dry_run,
				)
			);
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		if ( 'categories' === $entity ) {
			$importer = AWPM_Entity_Registry::get_importer( 'categories' );
			$job_id   = is_wp_error( $importer ) ? $importer : $importer->start_job(
				array(
					'file_path'               => $file_path,
					'format'                  => $format,
					'mapping'                 => $mapping,
					'match_strategy'          => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'slug',
					'existing_action'         => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'update',
					'create_missing_parents'  => ! empty( $_POST['create_missing_parents'] ),
					'batch_size'              => $batch_size,
					'dry_run'                 => $dry_run,
				)
			);
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		$importer = new AWPM_Product_Importer();
		$job_id   = $importer->start_job(
			array(
				'file_path'       => $file_path,
				'format'          => $format,
				'mapping'         => $mapping,
				'transforms'      => $transforms,
				'match_strategy'  => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'sku',
				'existing_action' => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'update',
				'options'         => array(
					'create_missing_global_attributes' => ! empty( $_POST['create_missing_global_attributes'] ),
					'create_missing_categories'        => ! empty( $_POST['create_missing_categories'] ),
					'image_match_strategy'             => isset( $_POST['image_match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['image_match_strategy'] ) ) : 'url_filename_fallback',
					'create_backup'                    => ! empty( $_POST['create_backup'] ),
				),
				'batch_size'      => $batch_size,
				'dry_run'         => $dry_run,
				'mapping_profile_id' => isset( $_POST['mapping_profile_id'] ) ? absint( $_POST['mapping_profile_id'] ) : null,
			)
		);

		is_wp_error( $job_id )
			? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) )
			: wp_send_json_success( array( 'job_id' => $job_id ) );
	}

	public function process_import_batch() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );

		$job      = AWPM_Jobs::get_import_job( $job_id );
		$entity   = $job['entity_type'] ?? 'product';
		$importer = 'product' === $entity ? new AWPM_Product_Importer() : AWPM_Entity_Registry::get_importer( $entity );

		if ( is_wp_error( $importer ) ) {
			wp_send_json_error( array( 'message' => $importer->get_error_message() ) );
		}

		$result = $importer->process_next_batch( $job_id );

		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( $result );
	}

	/* ------------------------- Mappings ------------------------- */

	public function save_mapping() {
		$this->verify_request();
		$id     = absint( $_POST['id'] ?? 0 );
		$name   = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$type   = sanitize_key( wp_unslash( $_POST['type'] ?? 'import' ) );
		$config = json_decode( wp_unslash( $_POST['config'] ?? '{}' ), true ); // phpcs:ignore
		$config = is_array( $config ) ? $config : array();

		if ( ! $name ) {
			wp_send_json_error( array( 'message' => __( 'Name is required.', 'advanced-woo-product-migrator' ) ) );
		}

		$id = $id ? ( AWPM_Mappings::update( $id, $name, $config ) ?: $id ) : AWPM_Mappings::create( $name, $type, $config );
		wp_send_json_success( array( 'id' => $id ) );
	}

	public function get_mapping() {
		$this->verify_request();
		$row = AWPM_Mappings::get( absint( $_POST['id'] ?? 0 ) );
		$row ? wp_send_json_success( $row ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-woo-product-migrator' ) ) );
	}

	public function duplicate_mapping() {
		$this->verify_request();
		$id       = absint( $_POST['id'] ?? 0 );
		$new_name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ) ?: __( 'Copy', 'advanced-woo-product-migrator' );
		$new_id   = AWPM_Mappings::duplicate( $id, $new_name );
		$new_id ? wp_send_json_success( array( 'id' => $new_id ) ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-woo-product-migrator' ) ) );
	}

	public function delete_mapping() {
		$this->verify_request();
		AWPM_Mappings::delete( absint( $_POST['id'] ?? 0 ) );
		wp_send_json_success();
	}

	public function export_mapping() {
		$this->verify_request();
		$json = AWPM_Mappings::export_json( absint( $_POST['id'] ?? 0 ) );
		$json ? wp_send_json_success( array( 'json' => $json ) ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-woo-product-migrator' ) ) );
	}

	public function import_mapping() {
		$this->verify_request();
		$json = wp_unslash( $_POST['json'] ?? '' ); // phpcs:ignore
		$id   = AWPM_Mappings::import_json( $json );
		is_wp_error( $id ) ? wp_send_json_error( array( 'message' => $id->get_error_message() ) ) : wp_send_json_success( array( 'id' => $id ) );
	}

	/* ------------------------- Tools ------------------------- */

	public function run_tool() {
		$this->verify_request();
		$tool = sanitize_key( wp_unslash( $_POST['tool'] ?? '' ) );

		$allowed = array(
			'scan_product_meta', 'scan_acf_fields', 'scan_taxonomies', 'scan_attributes', 'scan_product_types',
			'find_duplicate_skus', 'find_duplicate_products', 'validate_product_data',
			'clear_temp_files', 'rebuild_relationship_map', 'generate_sample_export',
		);
		if ( ! in_array( $tool, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown tool.', 'advanced-woo-product-migrator' ) ) );
		}

		$result = call_user_func( array( 'AWPM_Tools', $tool ) );
		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( array( 'result' => $result ) );
	}

	/* ------------------------- Rollback ------------------------- */

	public function rollback_job() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );
		if ( ! AWPM_Settings::get( 'enable_rollback', true ) ) {
			wp_send_json_error( array( 'message' => __( 'Rollback is disabled in Settings.', 'advanced-woo-product-migrator' ) ) );
		}
		wp_send_json_success( AWPM_Snapshot::rollback_job( $job_id ) );
	}

	/* ------------------------- Scheduler ------------------------- */

	public function save_schedule() {
		$this->verify_request();

		$source_type = isset( $_POST['source_type'] ) ? sanitize_key( wp_unslash( $_POST['source_type'] ) ) : 'remote_url';

		if ( 'ftp' === $source_type ) {
			$source_config = array(
				'host'     => sanitize_text_field( wp_unslash( $_POST['ftp_host'] ?? '' ) ),
				'port'     => absint( $_POST['ftp_port'] ?? 21 ),
				'username' => sanitize_text_field( wp_unslash( $_POST['ftp_username'] ?? '' ) ),
				// Password is stored as-is in the scheduled job's config (needed
				// verbatim to authenticate on every scheduled run) — never
				// logged, and only ever read back by AWPM_Ftp_Fetcher itself.
				'password' => wp_unslash( $_POST['ftp_password'] ?? '' ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				'path'     => sanitize_text_field( wp_unslash( $_POST['ftp_path'] ?? '' ) ),
				'use_ssl'  => ! empty( $_POST['ftp_use_ssl'] ),
			);
		} else {
			$source_config = array( 'url' => esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) ) );
		}

		$id = AWPM_Scheduler::save_scheduled_job(
			array(
				'name'         => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
				'type'         => sanitize_key( wp_unslash( $_POST['type'] ?? 'import' ) ),
				'recurrence'   => sanitize_key( wp_unslash( $_POST['recurrence'] ?? 'daily' ) ),
				'source_type'  => $source_type,
				'source_config'=> $source_config,
				'mapping_profile_id' => absint( $_POST['mapping_profile_id'] ?? 0 ) ?: null,
				'active'       => true,
			)
		);
		wp_send_json_success( array( 'id' => $id ) );
	}

	public function delete_schedule() {
		$this->verify_request();
		AWPM_Scheduler::delete_scheduled_job( absint( $_POST['id'] ?? 0 ) );
		wp_send_json_success();
	}

	/* ------------------------- Logs / diagnostics ------------------------- */

	public function clear_logs() {
		$this->verify_request();
		AWPM_Logger::clear_all();
		wp_send_json_success();
	}

	public function run_diagnostics() {
		$this->verify_request();
		$issues = AWPM_Tools::validate_product_data( 200 );
		wp_send_json_success( array( 'report' => AWPM_System_Status::get_report(), 'sample_validation_issues' => count( $issues ) ) );
	}

	/* ------------------------- Helpers ------------------------- */

	protected function ints( $arr ) {
		return array_map( 'absint', (array) $arr );
	}

	protected function texts( $arr ) {
		return array_map( 'sanitize_text_field', (array) wp_unslash( $arr ) );
	}
}
