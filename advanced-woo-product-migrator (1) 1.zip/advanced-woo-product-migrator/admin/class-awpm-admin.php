<?php
/**
 * AWPM_Admin
 *
 * Registers a fully separate top-level admin menu (Dashboard, Export,
 * Import, History, Import Logs, Scheduled Jobs, Mappings, Tools, Settings,
 * System Status) — deliberately NOT nested under WooCommerce, so it reads
 * as its own product rather than a WooCommerce sub-feature. Enqueues
 * assets only on our own screens.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AWPM_Admin {

	protected static $instance = null;
	const CAPABILITY = 'manage_woocommerce'; // Also accepted: manage_awpm (see class-awpm-installer.php).
	const SLUG        = 'awpm';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	protected function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( $this, 'maybe_show_requirements_notice' ) );
	}

	public function current_user_can_manage() {
		return current_user_can( 'manage_awpm' ) || current_user_can( self::CAPABILITY );
	}

	protected function pages() {
		return array(
			'dashboard' => __( 'Dashboard', 'advanced-woo-product-migrator' ),
			'export'    => __( 'Export', 'advanced-woo-product-migrator' ),
			'import'    => __( 'Import', 'advanced-woo-product-migrator' ),
			'history'   => __( 'History', 'advanced-woo-product-migrator' ),
			'logs'      => __( 'Import Logs', 'advanced-woo-product-migrator' ),
			'scheduler' => __( 'Scheduled Jobs', 'advanced-woo-product-migrator' ),
			'mappings'  => __( 'Mappings', 'advanced-woo-product-migrator' ),
			'tools'     => __( 'Tools', 'advanced-woo-product-migrator' ),
			'settings'  => __( 'Settings', 'advanced-woo-product-migrator' ),
			'status'    => __( 'System Status', 'advanced-woo-product-migrator' ),
		);
	}

	/**
	 * A genuinely separate top-level menu item (add_menu_page), not a
	 * WooCommerce submenu. The Dashboard page IS the top-level entry
	 * (WordPress requires the parent slug's own page to be one of its
	 * submenus for the URL to resolve cleanly), and every other screen is
	 * registered as its own submenu under that same top-level slug.
	 */
	public function register_menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="#a7aaad"><path d="M10 1l8 4.5v9L10 19l-8-4.5v-9L10 1zm0 2.3L4 6.6v6.8l6 3.3 6-3.3V6.6l-6-3.3zM6.5 9.5h7v1.4h-7V9.5z"/></svg>'
		);

		add_menu_page(
			__( 'Advanced Product Migrator', 'advanced-woo-product-migrator' ),
			__( 'Advanced Product Migrator', 'advanced-woo-product-migrator' ),
			self::CAPABILITY,
			self::SLUG . '-dashboard',
			array( $this, 'render_page' ),
			$icon,
			56 // Just below WooCommerce's own position (55) in the sidebar.
		);

		foreach ( $this->pages() as $slug => $label ) {
			add_submenu_page(
				self::SLUG . '-dashboard',
				sprintf( '%s — %s', __( 'Advanced Product Migrator', 'advanced-woo-product-migrator' ), $label ),
				$label,
				self::CAPABILITY,
				self::SLUG . '-' . $slug,
				array( $this, 'render_page' )
			);
		}
	}

	public function maybe_show_requirements_notice() {
		if ( class_exists( 'WooCommerce' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Advanced WooCommerce Product Migrator', 'advanced-woo-product-migrator' ) . ':</strong> ' . esc_html__( 'requires WooCommerce to be installed and active.', 'advanced-woo-product-migrator' ) . '</p></div>';
	}

	/**
	 * Which of our pages the current request is on. Reads $_GET['page']
	 * directly rather than parsing $screen->id, since the screen ID prefix
	 * differs between a top-level page ("toplevel_page_awpm-dashboard")
	 * and its submenus ("admin_page_awpm-export"-style ids) and isn't
	 * worth keeping in lockstep with WordPress's own naming.
	 */
	protected function current_page_slug() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = 0 === strpos( $page, self::SLUG . '-' ) ? substr( $page, strlen( self::SLUG ) + 1 ) : '';
		return isset( $this->pages()[ $page ] ) ? $page : 'dashboard';
	}

	public function render_page() {
		if ( ! $this->current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advanced-woo-product-migrator' ) );
		}

		$page = $this->current_page_slug();

		echo '<div class="wrap awpm-wrap">';
		echo '<h1 class="awpm-title">' . esc_html__( 'Advanced Product Migrator', 'advanced-woo-product-migrator' ) . '</h1>';

		echo '<nav class="awpm-tabs">';
		foreach ( $this->pages() as $slug => $label ) {
			$class = ( $slug === $page ) ? 'awpm-tab awpm-tab-active' : 'awpm-tab';
			printf(
				'<a href="%s" class="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-' . $slug ) ),
				esc_attr( $class ),
				esc_html( $label )
			);
		}
		echo '</nav>';

		$view_file = AWPM_PLUGIN_DIR . 'admin/views/' . sanitize_file_name( $page ) . '.php';
		if ( file_exists( $view_file ) ) {
			include $view_file;
		} else {
			echo '<div class="awpm-panel"><p>' . esc_html__( 'This screen is not available.', 'advanced-woo-product-migrator' ) . '</p></div>';
		}

		echo '</div>';
	}

	/**
	 * Loads our CSS/JS only on our own screens. Checks $_GET['page']
	 * rather than the $hook suffix for the same reason current_page_slug()
	 * does — robust regardless of top-level vs submenu hook naming.
	 */
	public function enqueue_assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 0 !== strpos( $page, self::SLUG . '-' ) ) {
			return;
		}

		wp_enqueue_style( 'awpm-admin', AWPM_PLUGIN_URL . 'assets/css/awpm-admin.css', array(), AWPM_VERSION );
		wp_enqueue_script( 'awpm-admin', AWPM_PLUGIN_URL . 'assets/js/awpm-admin.js', array( 'jquery', 'jquery-ui-sortable' ), AWPM_VERSION, true );

		wp_localize_script(
			'awpm-admin',
			'AWPM',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'awpm_nonce' ),
				'rest_url' => esc_url_raw( rest_url( 'awpm/v1' ) ),
				'rest_nonce' => wp_create_nonce( 'wp_rest' ),
				'transforms' => class_exists( 'AWPM_Transformer' ) ? AWPM_Transformer::get_available_transforms() : array(),
				'i18n'     => array(
					'confirm_import'     => __( 'This will write changes to your store. Continue?', 'advanced-woo-product-migrator' ),
					'confirm_destructive'=> __( 'This action cannot be undone. Continue?', 'advanced-woo-product-migrator' ),
					'confirm_rollback'   => __( 'This will restore products to their state before this import. Continue?', 'advanced-woo-product-migrator' ),
				),
			)
		);
	}
}
