<?php
/**
 * Import wizard: Select Source -> Product Handling -> Map Columns (CSV
 * only) -> Advanced Options -> Preview & Run. Preview (Step 5) calls the
 * real, read-only AWPM_Product_Importer::preview_rows() — same
 * find_existing_product() logic the actual import uses — so what's shown
 * is not a separate guess.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$import_profiles = AWPM_Mappings::all( 'import' );
?>
<div id="awpm-import-app" class="awpm-panel">

	<div class="awpm-wizard-steps">
		<div class="awpm-wizard-step active" data-step="1"><span class="awpm-step-num">1</span><?php esc_html_e( 'Select Source', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="2"><span class="awpm-step-num">2</span><?php esc_html_e( 'Product Handling', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="3"><span class="awpm-step-num">3</span><?php esc_html_e( 'Map Columns', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="4"><span class="awpm-step-num">4</span><?php esc_html_e( 'Advanced Options', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="5"><span class="awpm-step-num">5</span><?php esc_html_e( 'Preview & Run', 'advanced-woo-product-migrator' ); ?></div>
	</div>

	<?php if ( $import_profiles ) : ?>
	<p>
		<label><?php esc_html_e( 'Use a saved mapping profile:', 'advanced-woo-product-migrator' ); ?></label>
		<select id="awpm-load-profile">
			<option value=""><?php esc_html_e( '— Start fresh —', 'advanced-woo-product-migrator' ); ?></option>
			<?php foreach ( $import_profiles as $p ) : ?>
				<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php endif; ?>

	<!-- STEP 1: Source -->
	<div class="awpm-wizard-pane active" data-pane="1">
		<h2><?php esc_html_e( 'What are you importing?', 'advanced-woo-product-migrator' ); ?></h2>
		<div class="awpm-card-grid">
			<div class="awpm-card selected" data-entity="product">
				<span class="dashicons dashicons-cart"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Products', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'WooCommerce products, variations, attributes and metadata', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-entity="reviews">
				<span class="dashicons dashicons-star-filled"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Reviews', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Product / customer reviews and star ratings', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-entity="orders">
				<span class="dashicons dashicons-list-view"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Orders', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Orders, line items and addresses', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-entity="customers">
				<span class="dashicons dashicons-groups"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Customers', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Customer accounts and billing/shipping addresses', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-entity="categories">
				<span class="dashicons dashicons-category"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Categories & Tags', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Standalone category/tag import, independent of any product', 'advanced-woo-product-migrator' ); ?></span>
			</div>
		</div>
		<input type="hidden" id="awpm-import-entity" value="product">

		<h2><?php esc_html_e( 'Where is your file?', 'advanced-woo-product-migrator' ); ?></h2>
		<div class="awpm-source-toggle">
			<button type="button" class="button active" data-source="upload"><?php esc_html_e( 'Upload File', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" data-source="remote"><?php esc_html_e( 'Remote URL', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" data-source="ftp"><?php esc_html_e( 'FTP / FTPS', 'advanced-woo-product-migrator' ); ?></button>
		</div>

		<div class="awpm-source-pane active" data-source-pane="upload">
			<p><?php esc_html_e( 'Accepts .csv or .json (including files exported by this plugin, or by other tools — you\'ll map their columns in Step 3).', 'advanced-woo-product-migrator' ); ?></p>
			<input type="file" id="awpm-import-file" accept=".csv,.json,.xlsx">
			<button type="button" class="button button-primary" id="awpm-upload-btn"><?php esc_html_e( 'Upload', 'advanced-woo-product-migrator' ); ?></button>
			<span class="spinner" id="awpm-upload-spinner"></span>
		</div>

		<div class="awpm-source-pane" data-source-pane="remote">
			<p><?php esc_html_e( 'Fetches a .csv or .json file from a public URL. Requests to private/internal network addresses are blocked automatically.', 'advanced-woo-product-migrator' ); ?></p>
			<input type="url" id="awpm-remote-url" class="regular-text" placeholder="https://example.com/products.csv">
			<button type="button" class="button button-primary" id="awpm-remote-fetch-btn"><?php esc_html_e( 'Fetch', 'advanced-woo-product-migrator' ); ?></button>
			<span class="spinner" id="awpm-remote-spinner"></span>
		</div>

		<div class="awpm-source-pane" data-source-pane="ftp">
			<p><?php esc_html_e( 'Fetches a .csv, .json or .xlsx file from an FTP or FTPS server.', 'advanced-woo-product-migrator' ); ?></p>
			<p><input type="text" id="awpm-import-ftp-host" placeholder="<?php esc_attr_e( 'FTP host', 'advanced-woo-product-migrator' ); ?>" class="regular-text"> <input type="number" id="awpm-import-ftp-port" placeholder="21" style="width:70px;"></p>
			<p><input type="text" id="awpm-import-ftp-username" placeholder="<?php esc_attr_e( 'Username', 'advanced-woo-product-migrator' ); ?>" class="regular-text"></p>
			<p><input type="password" id="awpm-import-ftp-password" placeholder="<?php esc_attr_e( 'Password', 'advanced-woo-product-migrator' ); ?>" class="regular-text" autocomplete="new-password"></p>
			<p><input type="text" id="awpm-import-ftp-path" placeholder="<?php esc_attr_e( '/path/to/products.csv', 'advanced-woo-product-migrator' ); ?>" class="regular-text"></p>
			<p><label><input type="checkbox" id="awpm-import-ftp-ssl"> <?php esc_html_e( 'Use FTPS (explicit TLS)', 'advanced-woo-product-migrator' ); ?></label></p>
			<button type="button" class="button button-primary" id="awpm-ftp-fetch-btn"><?php esc_html_e( 'Fetch', 'advanced-woo-product-migrator' ); ?></button>
			<span class="spinner" id="awpm-ftp-spinner"></span>
			<p class="description"><?php esc_html_e( 'The password is sent only to fetch this one file — it is not saved anywhere. To repeat this import automatically, use Scheduled Jobs instead.', 'advanced-woo-product-migrator' ); ?></p>
		</div>

		<div id="awpm-upload-status"></div>
	</div>

	<!-- STEP 2: Product handling -->
	<div class="awpm-wizard-pane" data-pane="2">
		<h2 id="awpm-step2-heading"><?php esc_html_e( 'What should happen to existing products?', 'advanced-woo-product-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'If it already exists', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-match-strategy">
					<option value="sku" selected><?php esc_html_e( 'Update by SKU (falls back to Product ID / Slug)', 'advanced-woo-product-migrator' ); ?></option>
					<option value="product_id"><?php esc_html_e( 'Update by Product ID', 'advanced-woo-product-migrator' ); ?></option>
					<option value="slug"><?php esc_html_e( 'Update by Slug', 'advanced-woo-product-migrator' ); ?></option>
					<option value="external_id"><?php esc_html_e( 'Update by External ID (falls back to SKU)', 'advanced-woo-product-migrator' ); ?></option>
					<option value="none"><?php esc_html_e( 'Never match — always create new', 'advanced-woo-product-migrator' ); ?></option>
				</select>
				<p class="description" id="awpm-match-strategy-help"></p>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Action for existing records', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-existing-action">
					<option value="update" selected><?php esc_html_e( 'Update existing', 'advanced-woo-product-migrator' ); ?></option>
					<option value="skip"><?php esc_html_e( 'Skip existing', 'advanced-woo-product-migrator' ); ?></option>
					<option value="duplicate"><?php esc_html_e( 'Create duplicate', 'advanced-woo-product-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr class="awpm-product-only-row"><th scope="row"><?php esc_html_e( 'Missing global attributes', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-create-attributes" checked> <?php esc_html_e( 'Create missing global attributes automatically', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			<tr class="awpm-product-only-row"><th scope="row"><?php esc_html_e( 'Missing categories', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-create-categories" checked> <?php esc_html_e( 'Create missing categories automatically', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			<tr class="awpm-order-only-row" style="display:none;"><th scope="row"><?php esc_html_e( 'Missing customer accounts', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-create-missing-customer"> <?php esc_html_e( 'Create a customer account for orders whose customer email doesn\'t match an existing user', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			<tr class="awpm-review-only-row" style="display:none;"><th scope="row"><?php esc_html_e( 'Default approval status', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-review-default-status">
					<option value="approve" selected><?php esc_html_e( 'Approved', 'advanced-woo-product-migrator' ); ?></option>
					<option value="hold"><?php esc_html_e( 'Pending approval', 'advanced-woo-product-migrator' ); ?></option>
				</select>
				<p class="description"><?php esc_html_e( 'Used only when the imported row has no approval status of its own.', 'advanced-woo-product-migrator' ); ?></p>
			</td></tr>
			<tr class="awpm-categories-only-row" style="display:none;"><th scope="row"><?php esc_html_e( 'Missing parent terms', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-create-missing-parents" checked> <?php esc_html_e( 'Create missing parent levels of a category path automatically', 'advanced-woo-product-migrator' ); ?></label></td></tr>
		</table>
	</div>

	<!-- STEP 3: Map columns -->
	<div class="awpm-wizard-pane" data-pane="3">
		<h2><?php esc_html_e( 'Map import columns', 'advanced-woo-product-migrator' ); ?></h2>
		<div id="awpm-json-no-mapping-notice" style="display:none;">
			<p class="description"><?php esc_html_e( 'This is a JSON file with canonical field names (e.g. exported by this plugin) — no column mapping is needed. Continue to the next step.', 'advanced-woo-product-migrator' ); ?></p>
		</div>
		<div id="awpm-csv-mapping-ui" style="display:none;">
			<div class="awpm-field-toolbar">
				<input type="search" id="awpm-mapping-search" placeholder="<?php esc_attr_e( 'Search columns…', 'advanced-woo-product-migrator' ); ?>">
			</div>
			<div id="awpm-mapping-groups"></div>
		</div>
	</div>

	<!-- STEP 4: Advanced options -->
	<div class="awpm-wizard-pane" data-pane="4">
		<h2><?php esc_html_e( 'Advanced options', 'advanced-woo-product-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr class="awpm-product-only-row"><th scope="row"><?php esc_html_e( 'Image matching strategy', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-image-strategy">
					<option value="url_filename_fallback" selected><?php esc_html_e( 'URL → filename fallback (recommended)', 'advanced-woo-product-migrator' ); ?></option>
					<option value="attachment_id"><?php esc_html_e( 'Attachment ID (same-site only)', 'advanced-woo-product-migrator' ); ?></option>
					<option value="url"><?php esc_html_e( 'URL', 'advanced-woo-product-migrator' ); ?></option>
					<option value="filename"><?php esc_html_e( 'Filename', 'advanced-woo-product-migrator' ); ?></option>
					<option value="sku_filename"><?php esc_html_e( 'SKU + filename', 'advanced-woo-product-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr class="awpm-product-only-row"><th scope="row"><?php esc_html_e( 'Create backup before update', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-create-backup"> <?php esc_html_e( 'Enable rollback for this import (snapshots each updated product first)', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			<tr class="awpm-order-only-row" style="display:none;"><th scope="row"><?php esc_html_e( 'Force order status', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-order-set-status">
					<option value=""><?php esc_html_e( 'Keep each order\'s own status', 'advanced-woo-product-migrator' ); ?></option>
					<?php if ( function_exists( 'wc_get_order_statuses' ) ) : foreach ( wc_get_order_statuses() as $key => $label ) : ?>
						<option value="<?php echo esc_attr( str_replace( 'wc-', '', $key ) ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; endif; ?>
				</select>
			</td></tr>
			<tr><th scope="row"><label for="awpm-batch-size"><?php esc_html_e( 'Batch size', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<select id="awpm-batch-size">
					<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?><option value="<?php echo esc_attr( $n ); ?>" <?php selected( $n, 50 ); ?>><?php echo esc_html( $n ); ?></option><?php endforeach; ?>
				</select>
			</td></tr>
		</table>
	</div>

	<!-- STEP 5: Preview & Run -->
	<div class="awpm-wizard-pane" data-pane="5">
		<h2><?php esc_html_e( 'Preview', 'advanced-woo-product-migrator' ); ?></h2>
		<p>
			<button type="button" class="button" id="awpm-load-preview"><?php esc_html_e( 'Load Preview (first 20 rows, writes nothing)', 'advanced-woo-product-migrator' ); ?></button>
		</p>
		<div id="awpm-preview-table-wrap"></div>

		<p>
			<button type="button" class="button" id="awpm-dry-run-btn"><?php esc_html_e( 'Run Full Dry Run (all rows, writes nothing)', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button button-primary button-hero" id="awpm-run-import-btn"><?php esc_html_e( 'Confirm & Run Import', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-save-import-profile"><?php esc_html_e( 'Save as Profile', 'advanced-woo-product-migrator' ); ?></button>
		</p>

		<div id="awpm-import-progress" style="display:none;">
			<div class="awpm-progress-bar"><div class="awpm-progress-fill" id="awpm-import-progress-fill"></div></div>
			<p id="awpm-import-progress-text"></p>
		</div>

		<div id="awpm-import-result"></div>
	</div>

	<div class="awpm-wizard-footer">
		<button type="button" class="button" id="awpm-import-back" style="visibility:hidden;"><?php esc_html_e( '← Back', 'advanced-woo-product-migrator' ); ?></button>
		<div class="awpm-footer-right">
			<button type="button" class="button button-primary" id="awpm-import-next"><?php esc_html_e( 'Next →', 'advanced-woo-product-migrator' ); ?></button>
		</div>
	</div>
</div>
