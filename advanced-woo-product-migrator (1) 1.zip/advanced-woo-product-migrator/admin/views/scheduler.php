<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$jobs     = AWPM_Scheduler::list_scheduled_jobs();
$mappings = AWPM_Mappings::all( 'import' );
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'Scheduled Jobs', 'advanced-woo-product-migrator' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Backed by real WP-Cron events. Remote URL and FTP/FTPS sources both run on schedule; SFTP is a documented extension point (see readme.txt) since it needs a real SSH/crypto library rather than something safe to hand-roll.', 'advanced-woo-product-migrator' ); ?></p>

	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Name', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Type', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Recurrence', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Next Run', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Last Status', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Active', 'advanced-woo-product-migrator' ); ?></th><th></th></tr></thead>
		<tbody id="awpm-scheduler-tbody">
			<?php foreach ( $jobs as $job ) : ?>
				<tr data-id="<?php echo esc_attr( $job['id'] ); ?>">
					<td><?php echo esc_html( $job['name'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $job['type'] ) ); ?></td>
					<td><?php echo esc_html( $job['recurrence'] ); ?></td>
					<td><?php echo $job['next_run'] ? esc_html( gmdate( 'Y-m-d H:i', $job['next_run'] ) . ' UTC' ) : '—'; ?></td>
					<td><?php echo esc_html( $job['last_status'] ?: '—' ); ?></td>
					<td><?php echo $job['active'] ? '✓' : '—'; ?></td>
					<td><a href="#" class="awpm-schedule-delete" data-id="<?php echo esc_attr( $job['id'] ); ?>"><?php esc_html_e( 'Delete', 'advanced-woo-product-migrator' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $jobs ) ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No scheduled jobs yet.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'Create Scheduled Import', 'advanced-woo-product-migrator' ); ?></h3>
	<table class="form-table" role="presentation">
		<tr><th><label><?php esc_html_e( 'Name', 'advanced-woo-product-migrator' ); ?></label></th><td><input type="text" id="awpm-sched-name" class="regular-text"></td></tr>
		<tr><th><label><?php esc_html_e( 'Recurrence', 'advanced-woo-product-migrator' ); ?></label></th><td>
			<select id="awpm-sched-recurrence">
				<option value="hourly"><?php esc_html_e( 'Hourly', 'advanced-woo-product-migrator' ); ?></option>
				<option value="six_hourly"><?php esc_html_e( 'Every 6 Hours', 'advanced-woo-product-migrator' ); ?></option>
				<option value="daily" selected><?php esc_html_e( 'Daily', 'advanced-woo-product-migrator' ); ?></option>
				<option value="weekly"><?php esc_html_e( 'Weekly', 'advanced-woo-product-migrator' ); ?></option>
			</select>
		</td></tr>
		<tr><th><label><?php esc_html_e( 'Source', 'advanced-woo-product-migrator' ); ?></label></th><td>
			<select id="awpm-sched-source-type">
				<option value="remote_url"><?php esc_html_e( 'Remote URL', 'advanced-woo-product-migrator' ); ?></option>
				<option value="ftp"><?php esc_html_e( 'FTP / FTPS', 'advanced-woo-product-migrator' ); ?></option>
			</select>
			<div id="awpm-sched-source-remote_url">
				<input type="url" id="awpm-sched-url" class="regular-text" placeholder="https://example.com/products.csv">
			</div>
			<div id="awpm-sched-source-ftp" style="display:none;">
				<p><input type="text" id="awpm-sched-ftp-host" placeholder="<?php esc_attr_e( 'FTP host', 'advanced-woo-product-migrator' ); ?>" class="regular-text"> <input type="number" id="awpm-sched-ftp-port" placeholder="21" style="width:70px;"></p>
				<p><input type="text" id="awpm-sched-ftp-username" placeholder="<?php esc_attr_e( 'Username', 'advanced-woo-product-migrator' ); ?>" class="regular-text"></p>
				<p><input type="password" id="awpm-sched-ftp-password" placeholder="<?php esc_attr_e( 'Password', 'advanced-woo-product-migrator' ); ?>" class="regular-text" autocomplete="new-password"></p>
				<p><input type="text" id="awpm-sched-ftp-path" placeholder="<?php esc_attr_e( '/path/to/products.csv', 'advanced-woo-product-migrator' ); ?>" class="regular-text"></p>
				<p><label><input type="checkbox" id="awpm-sched-ftp-ssl"> <?php esc_html_e( 'Use FTPS (explicit TLS)', 'advanced-woo-product-migrator' ); ?></label></p>
				<p class="description"><?php esc_html_e( 'SFTP (SSH-based) is not supported in this version — only plain FTP and FTPS.', 'advanced-woo-product-migrator' ); ?></p>
			</div>
		</td></tr>
		<tr><th><label><?php esc_html_e( 'Mapping profile', 'advanced-woo-product-migrator' ); ?></label></th><td>
			<select id="awpm-sched-mapping">
				<option value=""><?php esc_html_e( '— None (use defaults) —', 'advanced-woo-product-migrator' ); ?></option>
				<?php foreach ( $mappings as $m ) : ?>
					<option value="<?php echo esc_attr( $m['id'] ); ?>"><?php echo esc_html( $m['name'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</td></tr>
	</table>
	<p><button type="button" class="button button-primary" id="awpm-sched-create"><?php esc_html_e( 'Create Scheduled Import', 'advanced-woo-product-migrator' ); ?></button></p>
	<div id="awpm-scheduler-result"></div>
</div>
