<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$job_id = isset( $_GET['job_id'] ) ? absint( $_GET['job_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$level  = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : ''; // phpcs:ignore
$logs   = AWPM_Logger::query( array( 'job_id' => $job_id, 'level' => $level, 'limit' => 200 ) );
$items  = $job_id ? AWPM_Jobs::get_import_items( $job_id, '', 200 ) : array();
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'Import / Export Logs', 'advanced-woo-product-migrator' ); ?><?php if ( $job_id ) printf( ' — ' . esc_html__( 'Job #%d', 'advanced-woo-product-migrator' ), $job_id ); ?></h2>

	<p>
		<a class="button <?php echo '' === $level ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'level', '', '' ) ); ?>"><?php esc_html_e( 'All', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button <?php echo 'error' === $level ? 'button-primary' : ''; ?>" href="?page=awpm-logs&job_id=<?php echo esc_attr( $job_id ); ?>&level=error"><?php esc_html_e( 'Errors', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button <?php echo 'warning' === $level ? 'button-primary' : ''; ?>" href="?page=awpm-logs&job_id=<?php echo esc_attr( $job_id ); ?>&level=warning"><?php esc_html_e( 'Warnings', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button" id="awpm-clear-logs"><?php esc_html_e( 'Clear Logs', 'advanced-woo-product-migrator' ); ?></a>
	</p>

	<?php if ( $job_id && $items ) : ?>
		<h3><?php esc_html_e( 'Per-Product Results', 'advanced-woo-product-migrator' ); ?></h3>
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'SKU', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Product ID', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Result', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Message', 'advanced-woo-product-migrator' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
					<tr>
						<td><?php echo esc_html( $item['sku'] ); ?></td>
						<td><?php echo $item['product_id'] ? '<a href="' . esc_url( get_edit_post_link( $item['product_id'] ) ) . '">#' . esc_html( $item['product_id'] ) . '</a>' : '—'; ?></td>
						<td><span class="awpm-result-<?php echo esc_attr( $item['result'] ); ?>"><?php echo esc_html( $item['result'] ); ?></span></td>
						<td><?php echo esc_html( $item['message'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<h3><?php esc_html_e( 'Event Log', 'advanced-woo-product-migrator' ); ?></h3>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Time', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Level', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Message', 'advanced-woo-product-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $logs as $entry ) : ?>
				<tr>
					<td><?php echo esc_html( $entry['created_at'] ); ?></td>
					<td><span class="awpm-level-<?php echo esc_attr( $entry['level'] ); ?>"><?php echo esc_html( $entry['level'] ); ?></span></td>
					<td><?php echo esc_html( $entry['message'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $logs ) ) : ?>
				<tr><td colspan="3"><?php esc_html_e( 'No log entries.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
