<?php
/**
 * Export wizard. Step content for steps 1-3 and 5 is rendered here; Step 4
 * (field selection) is populated by JS from the same awpm_get_fields
 * catalog the Import mapping screen uses, so both stay in sync with
 * whatever ACF/Yoast/custom-meta actually exists on this site.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$export_profiles = AWPM_Mappings::all( 'export' );
?>
<div id="awpm-export-app" class="awpm-panel">

	<div class="awpm-wizard-steps">
		<div class="awpm-wizard-step active" data-step="1"><span class="awpm-step-num">1</span><?php esc_html_e( 'Select Data', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="2"><span class="awpm-step-num">2</span><?php esc_html_e( 'Export Method', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="3"><span class="awpm-step-num">3</span><?php esc_html_e( 'Filter Data', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="4"><span class="awpm-step-num">4</span><?php esc_html_e( 'Field Mapping', 'advanced-woo-product-migrator' ); ?></div>
		<div class="awpm-wizard-connector"></div>
		<div class="awpm-wizard-step" data-step="5"><span class="awpm-step-num">5</span><?php esc_html_e( 'Advanced Options', 'advanced-woo-product-migrator' ); ?></div>
	</div>

	<?php if ( $export_profiles ) : ?>
	<p>
		<label><?php esc_html_e( 'Use a saved export profile:', 'advanced-woo-product-migrator' ); ?></label>
		<select id="awpm-export-load-profile">
			<option value=""><?php esc_html_e( '— New export —', 'advanced-woo-product-migrator' ); ?></option>
			<?php foreach ( $export_profiles as $p ) : ?>
				<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php endif; ?>

	<!-- STEP 1: Select data type -->
	<div class="awpm-wizard-pane active" data-pane="1">
		<h2><?php esc_html_e( 'What do you want to export?', 'advanced-woo-product-migrator' ); ?></h2>
		<div class="awpm-card-grid">
			<div class="awpm-card selected" data-value="product">
				<span class="dashicons dashicons-cart"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Products', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'WooCommerce products, variations, attributes and metadata', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-value="reviews">
				<span class="dashicons dashicons-star-filled"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Reviews', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Product / customer reviews, star ratings and verified-owner status', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-value="orders">
				<span class="dashicons dashicons-list-view"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Orders', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Orders, line items, billing/shipping and totals', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-value="customers">
				<span class="dashicons dashicons-groups"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Customers', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Customer accounts, billing/shipping address and order stats', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-value="categories">
				<span class="dashicons dashicons-category"></span>
				<span class="awpm-card-title"><?php esc_html_e( 'Categories & Tags', 'advanced-woo-product-migrator' ); ?></span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Standalone taxonomy export, independent of any product', 'advanced-woo-product-migrator' ); ?></span>
			</div>
		</div>
		<p class="description"><?php esc_html_e( 'Products, Reviews, Orders, Customers and Categories & Tags are all fully implemented.', 'advanced-woo-product-migrator' ); ?></p>
	</div>

	<!-- STEP 2: Export method -->
	<div class="awpm-wizard-pane" data-pane="2">
		<h2><?php esc_html_e( 'Choose an export format', 'advanced-woo-product-migrator' ); ?></h2>
		<div class="awpm-card-grid">
			<div class="awpm-card selected" data-format="json">
				<span class="dashicons dashicons-media-code"></span>
				<span class="awpm-card-title">JSON</span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Recommended — fully lossless, including ACF repeaters & flexible content', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-format="csv">
				<span class="dashicons dashicons-media-spreadsheet"></span>
				<span class="awpm-card-title">CSV</span>
				<span class="awpm-card-desc"><?php esc_html_e( 'Spreadsheet-friendly — one column per field, editable in Excel/Sheets', 'advanced-woo-product-migrator' ); ?></span>
			</div>
			<div class="awpm-card" data-format="xlsx">
				<span class="dashicons dashicons-media-spreadsheet"></span>
				<span class="awpm-card-title">XLSX</span>
				<span class="awpm-card-desc"><?php echo AWPM_XLSX_Handler::is_available() ? esc_html__( 'Native Excel format — opens directly in Excel/Sheets without conversion', 'advanced-woo-product-migrator' ) : esc_html__( 'Requires the ZipArchive PHP extension, which is not available on this server — will export as CSV instead', 'advanced-woo-product-migrator' ); ?></span>
			</div>
		</div>
		<input type="hidden" id="awpm-export-format" value="json">
	</div>

	<!-- STEP 3: Filter data -->
	<div class="awpm-wizard-pane" data-pane="3">
		<h2><?php esc_html_e( 'Filter which products to export', 'advanced-woo-product-migrator' ); ?></h2>
		<div class="awpm-filter-pane" data-filter-entity="product">
		<table class="form-table" role="presentation">
			<tr><th scope="row"><label for="awpm-export-limit"><?php esc_html_e( 'Total number of products to export', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<input type="number" min="0" id="awpm-export-limit" class="small-text" placeholder="<?php esc_attr_e( 'Unlimited', 'advanced-woo-product-migrator' ); ?>">
				<p class="description"><?php esc_html_e( 'Leave blank to export all matching products.', 'advanced-woo-product-migrator' ); ?></p>
			</td></tr>
			<tr><th scope="row"><label for="awpm-export-offset"><?php esc_html_e( 'Skip first N products', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<input type="number" min="0" id="awpm-export-offset" class="small-text" value="0">
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Which products?', 'advanced-woo-product-migrator' ); ?></th><td>
				<select id="awpm-export-selection">
					<option value="all"><?php esc_html_e( 'All products', 'advanced-woo-product-migrator' ); ?></option>
					<option value="ids"><?php esc_html_e( 'Specific product IDs', 'advanced-woo-product-migrator' ); ?></option>
					<option value="skus"><?php esc_html_e( 'Specific SKUs', 'advanced-woo-product-migrator' ); ?></option>
					<option value="category"><?php esc_html_e( 'By category', 'advanced-woo-product-migrator' ); ?></option>
					<option value="tag"><?php esc_html_e( 'By tag', 'advanced-woo-product-migrator' ); ?></option>
				</select>
				<input type="text" id="awpm-export-selection-value" class="regular-text" placeholder="<?php esc_attr_e( 'Comma-separated IDs / SKUs / category slugs / tag slugs', 'advanced-woo-product-migrator' ); ?>" style="display:none;margin-left:8px;">
			</td></tr>
			<tr><th scope="row"><label for="awpm-export-names"><?php esc_html_e( 'Products (by name)', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<input type="text" id="awpm-export-names" class="regular-text" placeholder="<?php esc_attr_e( 'Comma-separated product names — narrows the result above to just these', 'advanced-woo-product-migrator' ); ?>">
			</td></tr>
			<tr><th scope="row"><label for="awpm-export-exclude-names"><?php esc_html_e( 'Exclude products (by name)', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<input type="text" id="awpm-export-exclude-names" class="regular-text" placeholder="<?php esc_attr_e( 'Comma-separated product names to leave out', 'advanced-woo-product-migrator' ); ?>">
			</td></tr>
			<tr><th scope="row"><label for="awpm-export-stock-status"><?php esc_html_e( 'Stock status', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<select id="awpm-export-stock-status">
					<option value=""><?php esc_html_e( 'All status', 'advanced-woo-product-migrator' ); ?></option>
					<option value="instock"><?php esc_html_e( 'In stock', 'advanced-woo-product-migrator' ); ?></option>
					<option value="outofstock"><?php esc_html_e( 'Out of stock', 'advanced-woo-product-migrator' ); ?></option>
					<option value="onbackorder"><?php esc_html_e( 'On backorder', 'advanced-woo-product-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Product type', 'advanced-woo-product-migrator' ); ?></th><td>
				<label><input type="checkbox" class="awpm-type" value="simple" checked> <?php esc_html_e( 'Simple', 'advanced-woo-product-migrator' ); ?></label>
				<label><input type="checkbox" class="awpm-type" value="variable" checked> <?php esc_html_e( 'Variable', 'advanced-woo-product-migrator' ); ?></label>
				<label><input type="checkbox" class="awpm-type" value="grouped"> <?php esc_html_e( 'Grouped', 'advanced-woo-product-migrator' ); ?></label>
				<label><input type="checkbox" class="awpm-type" value="external"> <?php esc_html_e( 'External/Affiliate', 'advanced-woo-product-migrator' ); ?></label>
			</td></tr>
			<tr><th scope="row"><label for="awpm-export-status"><?php esc_html_e( 'Product status', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<select id="awpm-export-status">
					<option value="any"><?php esc_html_e( 'Any', 'advanced-woo-product-migrator' ); ?></option>
					<option value="publish"><?php esc_html_e( 'Published', 'advanced-woo-product-migrator' ); ?></option>
					<option value="draft"><?php esc_html_e( 'Draft', 'advanced-woo-product-migrator' ); ?></option>
					<option value="pending"><?php esc_html_e( 'Pending', 'advanced-woo-product-migrator' ); ?></option>
					<option value="private"><?php esc_html_e( 'Private', 'advanced-woo-product-migrator' ); ?></option>
				</select>
			</td></tr>
			<?php if ( taxonomy_exists( 'product_brand' ) ) : ?>
			<tr><th scope="row"><label for="awpm-export-brand"><?php esc_html_e( 'Product brand', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<select id="awpm-export-brand" multiple size="4" style="min-width:220px;">
					<?php foreach ( get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => false ) ) as $term ) : ?>
						<option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</td></tr>
			<?php else : ?>
			<tr><th scope="row"><?php esc_html_e( 'Product brand', 'advanced-woo-product-migrator' ); ?></th><td><p class="description"><?php esc_html_e( 'No brand taxonomy detected on this site — this filter is hidden rather than shown as a non-functional field.', 'advanced-woo-product-migrator' ); ?></p></td></tr>
			<?php endif; ?>
			<tr><th scope="row"><?php esc_html_e( 'Date created', 'advanced-woo-product-migrator' ); ?></th><td>
				<input type="date" id="awpm-export-created-after"> <?php esc_html_e( 'to', 'advanced-woo-product-migrator' ); ?> <input type="date" id="awpm-export-created-before">
				<p class="description"><?php esc_html_e( 'Leave both blank for no date filter.', 'advanced-woo-product-migrator' ); ?></p>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Date modified', 'advanced-woo-product-migrator' ); ?></th><td>
				<input type="date" id="awpm-export-modified-after"> <?php esc_html_e( 'to', 'advanced-woo-product-migrator' ); ?> <input type="date" id="awpm-export-modified-before">
			</td></tr>
		</table>
		<p class="description"><?php esc_html_e( 'ACF-field and custom-meta value filters (e.g. "brand equals Nike") are not implemented in this version — only the filters shown above actually narrow the export query.', 'advanced-woo-product-migrator' ); ?></p>
		</div>

		<div class="awpm-filter-pane" data-filter-entity="reviews" style="display:none;">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="awpm-export-review-skus"><?php esc_html_e( 'Limit to products (SKUs)', 'advanced-woo-product-migrator' ); ?></label></th><td>
					<input type="text" id="awpm-export-review-skus" class="regular-text" placeholder="<?php esc_attr_e( 'Comma-separated SKUs — blank = reviews on any product', 'advanced-woo-product-migrator' ); ?>">
				</td></tr>
				<tr><th scope="row"><label for="awpm-export-review-status"><?php esc_html_e( 'Approval status', 'advanced-woo-product-migrator' ); ?></label></th><td>
					<select id="awpm-export-review-status">
						<option value="approve" selected><?php esc_html_e( 'Approved only', 'advanced-woo-product-migrator' ); ?></option>
						<option value="hold"><?php esc_html_e( 'Pending/hold only', 'advanced-woo-product-migrator' ); ?></option>
						<option value="all"><?php esc_html_e( 'All (approved + pending + spam + trash)', 'advanced-woo-product-migrator' ); ?></option>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="awpm-export-review-rating"><?php esc_html_e( 'Star rating', 'advanced-woo-product-migrator' ); ?></label></th><td>
					<select id="awpm-export-review-rating">
						<option value=""><?php esc_html_e( 'Any rating', 'advanced-woo-product-migrator' ); ?></option>
						<?php for ( $i = 5; $i >= 1; $i-- ) : ?><option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?> ★</option><?php endfor; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Verified owner', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-export-review-verified"> <?php esc_html_e( 'Verified purchases only', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Date', 'advanced-woo-product-migrator' ); ?></th><td>
					<input type="date" id="awpm-export-review-after"> <?php esc_html_e( 'to', 'advanced-woo-product-migrator' ); ?> <input type="date" id="awpm-export-review-before">
				</td></tr>
			</table>
		</div>

		<div class="awpm-filter-pane" data-filter-entity="orders" style="display:none;">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Order status', 'advanced-woo-product-migrator' ); ?></th><td>
					<?php foreach ( wc_get_order_statuses() as $key => $label ) : ?>
						<label style="display:inline-block;margin-right:10px;"><input type="checkbox" class="awpm-order-status" value="<?php echo esc_attr( $key ); ?>"> <?php echo esc_html( $label ); ?></label>
					<?php endforeach; ?>
					<p class="description"><?php esc_html_e( 'Leave all unchecked to export orders in any status.', 'advanced-woo-product-migrator' ); ?></p>
				</td></tr>
				<tr><th scope="row"><label for="awpm-export-order-email"><?php esc_html_e( 'Customer email', 'advanced-woo-product-migrator' ); ?></label></th><td>
					<input type="email" id="awpm-export-order-email" class="regular-text" placeholder="<?php esc_attr_e( 'Leave blank for any customer', 'advanced-woo-product-migrator' ); ?>">
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Order date', 'advanced-woo-product-migrator' ); ?></th><td>
					<input type="date" id="awpm-export-order-after"> <?php esc_html_e( 'to', 'advanced-woo-product-migrator' ); ?> <input type="date" id="awpm-export-order-before">
				</td></tr>
			</table>
		</div>

		<div class="awpm-filter-pane" data-filter-entity="customers" style="display:none;">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Role', 'advanced-woo-product-migrator' ); ?></th><td>
					<?php $wp_roles = wp_roles(); foreach ( $wp_roles->get_names() as $role_key => $role_label ) : ?>
						<label style="display:inline-block;margin-right:10px;"><input type="checkbox" class="awpm-customer-role" value="<?php echo esc_attr( $role_key ); ?>" <?php checked( 'customer', $role_key ); ?>> <?php echo esc_html( $role_label ); ?></label>
					<?php endforeach; ?>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Date registered', 'advanced-woo-product-migrator' ); ?></th><td>
					<input type="date" id="awpm-export-customer-after"> <?php esc_html_e( 'to', 'advanced-woo-product-migrator' ); ?> <input type="date" id="awpm-export-customer-before">
				</td></tr>
			</table>
		</div>

		<div class="awpm-filter-pane" data-filter-entity="categories" style="display:none;">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Taxonomy', 'advanced-woo-product-migrator' ); ?></th><td>
					<label style="display:inline-block;margin-right:10px;"><input type="checkbox" class="awpm-taxonomy" value="product_cat" checked> <?php esc_html_e( 'Categories', 'advanced-woo-product-migrator' ); ?></label>
					<label style="display:inline-block;margin-right:10px;"><input type="checkbox" class="awpm-taxonomy" value="product_tag" checked> <?php esc_html_e( 'Tags', 'advanced-woo-product-migrator' ); ?></label>
				</td></tr>
				<tr><th scope="row"><label for="awpm-export-term-search"><?php esc_html_e( 'Name/slug search', 'advanced-woo-product-migrator' ); ?></label></th><td>
					<input type="text" id="awpm-export-term-search" class="regular-text" placeholder="<?php esc_attr_e( 'Leave blank to export every term', 'advanced-woo-product-migrator' ); ?>">
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Empty terms', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" id="awpm-export-hide-empty"> <?php esc_html_e( 'Only export terms with at least one product', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			</table>
			<p class="description"><?php esc_html_e( 'Categories export with their full parent hierarchy so it can be rebuilt on the destination site; tags are flat.', 'advanced-woo-product-migrator' ); ?></p>
		</div>
	</div>

	<!-- STEP 4: Field mapping / selection -->
	<div class="awpm-wizard-pane" data-pane="4">
		<h2><?php esc_html_e( 'Choose which fields to export', 'advanced-woo-product-migrator' ); ?></h2>
		<p class="awpm-detected" id="awpm-export-detected-badges">
			<?php if ( AWPM_ACF_Handler::is_active() ) : ?>
				<span class="awpm-badge awpm-badge-ok">✓ <?php esc_html_e( 'ACF detected', 'advanced-woo-product-migrator' ); ?></span>
			<?php else : ?>
				<span class="awpm-badge awpm-badge-warn"><?php esc_html_e( 'ACF not detected', 'advanced-woo-product-migrator' ); ?></span>
			<?php endif; ?>
			<?php if ( AWPM_Yoast_Handler::is_active() ) : ?>
				<span class="awpm-badge awpm-badge-ok">✓ <?php esc_html_e( 'Yoast SEO detected', 'advanced-woo-product-migrator' ); ?></span>
			<?php else : ?>
				<span class="awpm-badge awpm-badge-warn"><?php esc_html_e( 'Yoast SEO not detected', 'advanced-woo-product-migrator' ); ?></span>
			<?php endif; ?>
		</p>
		<div class="awpm-field-toolbar">
			<input type="search" id="awpm-export-field-search" placeholder="<?php esc_attr_e( 'Search fields…', 'advanced-woo-product-migrator' ); ?>">
			<button type="button" class="button" id="awpm-export-select-all"><?php esc_html_e( 'Select All', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-export-select-none"><?php esc_html_e( 'Select None', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-export-reset-defaults"><?php esc_html_e( 'Reset Defaults', 'advanced-woo-product-migrator' ); ?></button>
		</div>
		<div id="awpm-export-field-groups"><p><?php esc_html_e( 'Loading fields…', 'advanced-woo-product-migrator' ); ?></p></div>
	</div>

	<!-- STEP 5: Advanced options + run -->
	<div class="awpm-wizard-pane" data-pane="5">
		<h2><?php esc_html_e( 'Advanced options', 'advanced-woo-product-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><label for="awpm-export-batch-size"><?php esc_html_e( 'Batch size', 'advanced-woo-product-migrator' ); ?></label></th><td>
				<select id="awpm-export-batch-size">
					<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?><option value="<?php echo esc_attr( $n ); ?>" <?php selected( $n, 50 ); ?>><?php echo esc_html( $n ); ?></option><?php endforeach; ?>
				</select>
			</td></tr>
		</table>

		<p>
			<button type="button" class="button button-primary button-hero" id="awpm-run-export"><?php esc_html_e( 'Start Export', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-save-export-profile"><?php esc_html_e( 'Save as Profile', 'advanced-woo-product-migrator' ); ?></button>
		</p>

		<div id="awpm-export-progress" style="display:none;">
			<div class="awpm-progress-bar"><div class="awpm-progress-fill" id="awpm-export-progress-fill"></div></div>
			<p id="awpm-export-progress-text"></p>
		</div>

		<div id="awpm-export-result"></div>
	</div>

	<div class="awpm-wizard-footer">
		<button type="button" class="button" id="awpm-export-back" style="visibility:hidden;"><?php esc_html_e( '← Back', 'advanced-woo-product-migrator' ); ?></button>
		<div class="awpm-footer-right">
			<button type="button" class="button button-primary" id="awpm-export-next"><?php esc_html_e( 'Next →', 'advanced-woo-product-migrator' ); ?></button>
		</div>
	</div>
</div>
