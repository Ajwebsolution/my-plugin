<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$stats = AWPM_Jobs::get_dashboard_stats();
$acf_fields = AWPM_ACF_Handler::is_active() ? count( AWPM_Field_Registry::get_acf_fields() ) : 0;
$custom_meta_count = count( AWPM_Field_Registry::discover_custom_meta_keys( 200 ) );
?>
<div class="awpm-panel awpm-dashboard">

	<div class="awpm-stat-grid">
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $stats['products'] ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'Products', 'advanced-woo-product-migrator' ); ?></span></div>
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $stats['variations'] ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'Variations', 'advanced-woo-product-migrator' ); ?></span></div>
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $acf_fields ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'ACF Fields Detected', 'advanced-woo-product-migrator' ); ?></span></div>
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $custom_meta_count ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'Custom Meta Keys (sampled)', 'advanced-woo-product-migrator' ); ?></span></div>
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $stats['total_created'] + $stats['total_updated'] ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'Successful Imports', 'advanced-woo-product-migrator' ); ?></span></div>
		<div class="awpm-stat"><span class="awpm-stat-num"><?php echo esc_html( number_format_i18n( $stats['total_failed'] ) ); ?></span><span class="awpm-stat-label"><?php esc_html_e( 'Failed', 'advanced-woo-product-migrator' ); ?></span></div>
	</div>

	<p class="awpm-last-run">
		<?php if ( $stats['last_import'] ) : ?>
			<?php printf( esc_html__( 'Last Import: %s', 'advanced-woo-product-migrator' ), esc_html( $stats['last_import']['finished_at'] ) ); ?>
		<?php else : ?>
			<?php esc_html_e( 'No imports run yet.', 'advanced-woo-product-migrator' ); ?>
		<?php endif; ?>
		&nbsp;·&nbsp;
		<?php if ( $stats['last_export'] ) : ?>
			<?php printf( esc_html__( 'Last Export: %s', 'advanced-woo-product-migrator' ), esc_html( $stats['last_export']['finished_at'] ) ); ?>
		<?php else : ?>
			<?php esc_html_e( 'No exports run yet.', 'advanced-woo-product-migrator' ); ?>
		<?php endif; ?>
	</p>

	<div class="awpm-quick-actions">
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-export' ) ); ?>"><?php esc_html_e( 'Export Products', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-import' ) ); ?>"><?php esc_html_e( 'Import Products', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-mappings' ) ); ?>"><?php esc_html_e( 'Create Mapping', 'advanced-woo-product-migrator' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-scheduler' ) ); ?>"><?php esc_html_e( 'Schedule Import', 'advanced-woo-product-migrator' ); ?></a>
	</div>

	<h2><?php esc_html_e( 'Recent Activity', 'advanced-woo-product-migrator' ); ?></h2>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Job', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Type', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Result', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Status', 'advanced-woo-product-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $stats['recent_imports'] as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php esc_html_e( 'Import', 'advanced-woo-product-migrator' ); ?></td>
					<td><?php printf( esc_html__( '%1$d created, %2$d updated, %3$d failed', 'advanced-woo-product-migrator' ), (int) $job['created_count'], (int) $job['updated_count'], (int) $job['failed_count'] ); ?></td>
					<td><?php echo esc_html( $job['status'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			<?php foreach ( $stats['recent_exports'] as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php esc_html_e( 'Export', 'advanced-woo-product-migrator' ); ?></td>
					<td><?php printf( esc_html__( '%d products, %s', 'advanced-woo-product-migrator' ), (int) $job['processed_count'], esc_html( strtoupper( $job['format'] ) ) ); ?></td>
					<td><?php echo esc_html( $job['status'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $stats['recent_imports'] ) && empty( $stats['recent_exports'] ) ) : ?>
				<tr><td colspan="4"><?php esc_html_e( 'No activity yet.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'System Status', 'advanced-woo-product-migrator' ); ?></h2>
	<?php $report = AWPM_System_Status::get_report(); ?>
	<ul class="awpm-status-list">
		<li class="<?php echo $report['woocommerce_status'] === 'good' ? 'ok' : 'critical'; ?>">WooCommerce <?php echo $report['woocommerce_status'] === 'good' ? '✓' : '✕'; ?></li>
		<li class="<?php echo $report['acf_active'] ? 'ok' : 'muted'; ?>">ACF <?php echo $report['acf_active'] ? '✓' : '—'; ?></li>
		<li class="<?php echo $report['yoast_active'] ? 'ok' : 'muted'; ?>">Yoast <?php echo $report['yoast_active'] ? '✓' : '—'; ?></li>
		<li class="<?php echo $report['action_scheduler'] ? 'ok' : 'muted'; ?>">Action Scheduler <?php echo $report['action_scheduler'] ? '✓' : '— (using WP-Cron)'; ?></li>
		<li class="ok"><?php esc_html_e( 'REST API', 'advanced-woo-product-migrator' ); ?> ✓</li>
	</ul>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-status' ) ); ?>"><?php esc_html_e( 'View full System Status →', 'advanced-woo-product-migrator' ); ?></a></p>
</div>
