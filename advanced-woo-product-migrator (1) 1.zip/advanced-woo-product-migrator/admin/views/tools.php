<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'Tools', 'advanced-woo-product-migrator' ); ?></h2>

	<div class="awpm-tools-grid">
		<button type="button" class="button awpm-tool" data-tool="scan_product_meta"><?php esc_html_e( 'Scan Product Meta', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="scan_acf_fields"><?php esc_html_e( 'Scan ACF Fields', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="scan_taxonomies"><?php esc_html_e( 'Scan Taxonomies', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="scan_attributes"><?php esc_html_e( 'Scan Attributes', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="scan_product_types"><?php esc_html_e( 'Scan Product Types', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="find_duplicate_skus"><?php esc_html_e( 'Find Duplicate SKUs', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="find_duplicate_products"><?php esc_html_e( 'Find Duplicate Products', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="validate_product_data"><?php esc_html_e( 'Validate Product Data', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool awpm-tool-confirm" data-tool="clear_temp_files"><?php esc_html_e( 'Clear Temporary Files', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button awpm-tool" data-tool="rebuild_relationship_map"><?php esc_html_e( 'Rebuild Relationship Map', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button button-primary awpm-tool" data-tool="generate_sample_export"><?php esc_html_e( 'Generate Sample Export', 'advanced-woo-product-migrator' ); ?></button>
	</div>

	<div id="awpm-tools-result"></div>
</div>
