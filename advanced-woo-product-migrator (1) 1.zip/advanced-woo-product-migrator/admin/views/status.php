<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$r = AWPM_System_Status::get_report();
function awpm_status_dot( $status ) {
	$map = array( 'good' => '🟢', 'warning' => '🟡', 'critical' => '🔴' );
	return $map[ $status ] ?? '⚪';
}
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'System Status', 'advanced-woo-product-migrator' ); ?></h2>

	<table class="widefat striped">
		<tbody>
			<tr><td><?php esc_html_e( 'Plugin Version', 'advanced-woo-product-migrator' ); ?></td><td><?php echo esc_html( $r['plugin_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'WordPress', 'advanced-woo-product-migrator' ); ?></td><td><?php echo esc_html( $r['wordpress_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'PHP', 'advanced-woo-product-migrator' ); ?></td><td><?php echo awpm_status_dot( $r['php_status'] ); ?> <?php echo esc_html( $r['php_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'MySQL', 'advanced-woo-product-migrator' ); ?></td><td><?php echo esc_html( $r['mysql_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'WooCommerce', 'advanced-woo-product-migrator' ); ?></td><td><?php echo awpm_status_dot( $r['woocommerce_status'] ); ?> <?php echo esc_html( $r['woocommerce_version'] ?: __( 'Not installed', 'advanced-woo-product-migrator' ) ); ?></td></tr>
			<tr><td>ACF</td><td><?php echo $r['acf_active'] ? '🟢 ' . esc_html( ( $r['acf_pro'] ? 'Pro ' : '' ) . $r['acf_version'] ) : '⚪ ' . esc_html__( 'Not installed', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><td>Yoast SEO</td><td><?php echo $r['yoast_active'] ? '🟢 ' . esc_html( $r['yoast_version'] ) : '⚪ ' . esc_html__( 'Not installed', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Action Scheduler', 'advanced-woo-product-migrator' ); ?></td><td><?php echo $r['action_scheduler'] ? '🟢' : '⚪ ' . esc_html__( 'Not available — falling back to WP-Cron', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'REST API', 'advanced-woo-product-migrator' ); ?></td><td>🟢</td></tr>
			<tr><td><?php esc_html_e( 'Memory Limit', 'advanced-woo-product-migrator' ); ?></td><td><?php echo awpm_status_dot( $r['memory_status'] ); ?> <?php echo esc_html( $r['memory_limit'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Max Execution Time', 'advanced-woo-product-migrator' ); ?></td><td><?php echo awpm_status_dot( $r['exec_time_status'] ); ?> <?php echo esc_html( $r['max_execution_time'] ); ?>s</td></tr>
			<tr><td><?php esc_html_e( 'Upload Max Filesize', 'advanced-woo-product-migrator' ); ?></td><td><?php echo esc_html( $r['upload_max_filesize'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Post Max Size', 'advanced-woo-product-migrator' ); ?></td><td><?php echo esc_html( $r['post_max_size'] ); ?></td></tr>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'Detected Integrations', 'advanced-woo-product-migrator' ); ?></h3>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Plugin', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Detected', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Version', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Supported', 'advanced-woo-product-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $r['integrations'] as $name => $info ) : ?>
				<tr>
					<td><?php echo esc_html( $name ); ?></td>
					<td><?php echo $info['detected'] ? '✓' : '—'; ?></td>
					<td><?php echo esc_html( $info['version'] ?: '—' ); ?></td>
					<td><?php echo $info['supported'] ? '✓' : '—'; ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<p>
		<button type="button" class="button" id="awpm-copy-report"><?php esc_html_e( 'Copy System Report', 'advanced-woo-product-migrator' ); ?></button>
		<button type="button" class="button" id="awpm-run-diagnostics"><?php esc_html_e( 'Run Diagnostics', 'advanced-woo-product-migrator' ); ?></button>
	</p>
	<textarea id="awpm-report-text" style="position:absolute;left:-9999px;"><?php echo esc_textarea( AWPM_System_Status::as_text() ); ?></textarea>
	<div id="awpm-status-result"></div>
</div>
