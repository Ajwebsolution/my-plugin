<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mappings = AWPM_Mappings::all();
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'Saved Mappings', 'advanced-woo-product-migrator' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Mapping profiles are created from the Export or Import wizard ("Save as Profile") and reused here — for repeat migrations, imports scheduled under Scheduled Jobs, or the REST API.', 'advanced-woo-product-migrator' ); ?></p>

	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Name', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Type', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Updated', 'advanced-woo-product-migrator' ); ?></th><th><?php esc_html_e( 'Actions', 'advanced-woo-product-migrator' ); ?></th></tr></thead>
		<tbody id="awpm-mappings-tbody">
			<?php foreach ( $mappings as $m ) : ?>
				<tr data-id="<?php echo esc_attr( $m['id'] ); ?>">
					<td><?php echo esc_html( $m['name'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $m['type'] ) ); ?></td>
					<td><?php echo esc_html( $m['updated_at'] ); ?></td>
					<td>
						<a href="#" class="awpm-mapping-duplicate" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Duplicate', 'advanced-woo-product-migrator' ); ?></a> |
						<a href="#" class="awpm-mapping-export" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Export', 'advanced-woo-product-migrator' ); ?></a> |
						<a href="#" class="awpm-mapping-delete" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Delete', 'advanced-woo-product-migrator' ); ?></a>
					</td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $mappings ) ) : ?>
				<tr id="awpm-mappings-empty"><td colspan="4"><?php esc_html_e( 'No saved mappings yet. Create one from the Export or Import screen.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'Import a mapping file', 'advanced-woo-product-migrator' ); ?></h3>
	<input type="file" id="awpm-mapping-import-file" accept=".json">
	<button type="button" class="button" id="awpm-mapping-import-btn"><?php esc_html_e( 'Import Mapping', 'advanced-woo-product-migrator' ); ?></button>
	<div id="awpm-mappings-result"></div>
</div>
