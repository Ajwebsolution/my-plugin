<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$imports = AWPM_Jobs::list_import_jobs( 50 );
$exports = AWPM_Jobs::list_export_jobs( 50 );
?>
<div class="awpm-panel">
	<h2><?php esc_html_e( 'Import History', 'advanced-woo-product-migrator' ); ?></h2>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Job ID', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Type', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Date', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Created', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Updated', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Skipped', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Failed', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Status', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'advanced-woo-product-migrator' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $imports as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $job['entity_type'] ?? 'product' ) ); ?></td>
					<td><?php echo esc_html( $job['created_at'] ); ?></td>
					<td><?php echo esc_html( $job['created_count'] ); ?></td>
					<td><?php echo esc_html( $job['updated_count'] ); ?></td>
					<td><?php echo esc_html( $job['skipped_count'] ); ?></td>
					<td><?php echo esc_html( $job['failed_count'] ); ?></td>
					<td><span class="awpm-status-pill awpm-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( $job['status'] ); ?></span></td>
					<td>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=awpm-logs&job_id=' . $job['id'] ) ); ?>"><?php esc_html_e( 'View Details', 'advanced-woo-product-migrator' ); ?></a>
						<?php if ( 'completed' === $job['status'] ) : ?>
							| <a href="#" class="awpm-rollback-link" data-job-id="<?php echo esc_attr( $job['id'] ); ?>"><?php esc_html_e( 'Rollback', 'advanced-woo-product-migrator' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $imports ) ) : ?>
				<tr><td colspan="9"><?php esc_html_e( 'No import jobs yet.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Export History', 'advanced-woo-product-migrator' ); ?></h2>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Job ID', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Type', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Date', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Format', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Records', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'Status', 'advanced-woo-product-migrator' ); ?></th>
				<th><?php esc_html_e( 'File', 'advanced-woo-product-migrator' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $exports as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $job['entity_type'] ?? 'product' ) ); ?></td>
					<td><?php echo esc_html( $job['created_at'] ); ?></td>
					<td><?php echo esc_html( strtoupper( $job['format'] ) ); ?></td>
					<td><?php echo esc_html( $job['processed_count'] ); ?></td>
					<td><span class="awpm-status-pill awpm-status-<?php echo esc_attr( $job['status'] ); ?>"><?php echo esc_html( $job['status'] ); ?></span></td>
					<td><?php if ( ! empty( $job['file_path'] ) && 'completed' === $job['status'] ) : ?><a href="<?php echo esc_url( admin_url( 'admin-post.php?action=awpm_download&type=export&job_id=' . $job['id'] . '&_wpnonce=' . wp_create_nonce( 'awpm_nonce' ) ) ); ?>"><?php esc_html_e( 'Download', 'advanced-woo-product-migrator' ); ?></a><?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $exports ) ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No export jobs yet.', 'advanced-woo-product-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
