<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $wpdb;
$settings = get_option( 'awpm_settings', array() );
$sub_tab  = isset( $_GET['stab'] ) ? sanitize_key( wp_unslash( $_GET['stab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$sub_tabs = array(
	'general'  => __( 'General', 'advanced-woo-product-migrator' ),
	'media'    => __( 'Media', 'advanced-woo-product-migrator' ),
	'backup'   => __( 'Backup & Rollback', 'advanced-woo-product-migrator' ),
	'logging'  => __( 'Logging', 'advanced-woo-product-migrator' ),
	'performance' => __( 'Performance', 'advanced-woo-product-migrator' ),
	'notifications' => __( 'Notifications & API', 'advanced-woo-product-migrator' ),
	'status'   => __( 'Plugin Status', 'advanced-woo-product-migrator' ),
);

function awpm_val( $settings, $key, $default = '' ) {
	return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}
function awpm_checked( $settings, $key, $default = false ) {
	return ! empty( $settings[ $key ] ?? $default ) ? 'checked' : '';
}
?>
<div class="awpm-panel">
	<div class="awpm-subtabs">
		<?php foreach ( $sub_tabs as $slug => $label ) : ?>
			<a class="<?php echo $slug === $sub_tab ? 'active' : ''; ?>" href="?page=awpm-settings&stab=<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</div>

	<?php if ( 'status' === $sub_tab ) : ?>

		<?php $r = AWPM_System_Status::get_report(); ?>
		<h2><?php esc_html_e( 'Plugin Status', 'advanced-woo-product-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th><?php esc_html_e( 'Plugin', 'advanced-woo-product-migrator' ); ?></th><td><?php esc_html_e( 'Advanced WooCommerce Product Migrator', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Status', 'advanced-woo-product-migrator' ); ?></th><td><?php esc_html_e( 'Active', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Version', 'advanced-woo-product-migrator' ); ?></th><td><?php echo esc_html( $r['plugin_version'] ); ?></td></tr>
			<tr><th><?php esc_html_e( 'WooCommerce', 'advanced-woo-product-migrator' ); ?></th><td><?php echo $r['woocommerce_status'] === 'good' ? esc_html__( 'Connected', 'advanced-woo-product-migrator' ) : esc_html__( 'Not installed', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th>ACF</th><td><?php echo $r['acf_active'] ? esc_html__( 'Detected', 'advanced-woo-product-migrator' ) : esc_html__( 'Not installed', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th>ACF Pro</th><td><?php echo $r['acf_pro'] ? esc_html__( 'Detected', 'advanced-woo-product-migrator' ) : esc_html__( 'Not detected', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th>Yoast SEO</th><td><?php echo $r['yoast_active'] ? esc_html__( 'Detected', 'advanced-woo-product-migrator' ) : esc_html__( 'Not installed', 'advanced-woo-product-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'PHP Version', 'advanced-woo-product-migrator' ); ?></th><td><?php echo esc_html( $r['php_version'] ); ?></td></tr>
			<tr><th><?php esc_html_e( 'WordPress Version', 'advanced-woo-product-migrator' ); ?></th><td><?php echo esc_html( $r['wordpress_version'] ); ?></td></tr>
			<tr><th><?php esc_html_e( 'WooCommerce Version', 'advanced-woo-product-migrator' ); ?></th><td><?php echo esc_html( $r['woocommerce_version'] ?: '—' ); ?></td></tr>
		</table>
		<p>
			<button type="button" class="button" id="awpm-check-compat"><?php esc_html_e( 'Check System Compatibility', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-run-diagnostics-2"><?php esc_html_e( 'Run Diagnostics', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button awpm-tool-confirm" data-tool="clear_temp_files"><?php esc_html_e( 'Clear Temporary Data', 'advanced-woo-product-migrator' ); ?></button>
			<button type="button" class="button" id="awpm-clear-logs-2"><?php esc_html_e( 'Clear Logs', 'advanced-woo-product-migrator' ); ?></button>
			<a class="button" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Manage Plugin (Activate/Deactivate)', 'advanced-woo-product-migrator' ); ?></a>
		</p>
		<p class="description"><?php esc_html_e( 'Deactivating this plugin is done through the standard WordPress Plugins screen above — this plugin never deactivates itself through a custom endpoint.', 'advanced-woo-product-migrator' ); ?></p>
		<div id="awpm-status-result"></div>

	<?php else : ?>

	<form method="post" action="options.php">
		<?php settings_fields( 'awpm_settings' ); ?>

		<?php if ( 'general' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Default match strategy', 'advanced-woo-product-migrator' ); ?></th><td>
					<select name="awpm_settings[default_match_strategy]">
						<?php foreach ( array( 'sku' => 'SKU', 'product_id' => 'Product ID', 'slug' => 'Slug', 'external_id' => 'External ID' ) as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( awpm_val( $settings, 'default_match_strategy', 'sku' ), $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Preserve existing values when source is empty', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[preserve_empty_values]" <?php echo awpm_checked( $settings, 'preserve_empty_values' ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'On uninstall', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[delete_data_on_uninstall]" <?php echo awpm_checked( $settings, 'delete_data_on_uninstall' ); ?>> <?php esc_html_e( 'Delete this plugin\'s own tables, logs and settings when fully removed (via Plugins → Delete). WooCommerce product data is never touched by this option.', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			</table>
		<?php elseif ( 'media' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Image matching method', 'advanced-woo-product-migrator' ); ?></th><td>
					<select name="awpm_settings[image_match_strategy]">
						<?php foreach ( array( 'url_filename_fallback' => 'URL → Filename fallback', 'attachment_id' => 'Attachment ID', 'url' => 'URL', 'filename' => 'Filename', 'sku_filename' => 'SKU + filename' ) as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( awpm_val( $settings, 'image_match_strategy', 'url_filename_fallback' ), $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Download remote images by default', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[download_remote_images]" <?php echo awpm_checked( $settings, 'download_remote_images', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
			</table>
		<?php elseif ( 'backup' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Create product snapshot before update', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[create_backup_before_update]" <?php echo awpm_checked( $settings, 'create_backup_before_update' ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Enable rollback', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[enable_rollback]" <?php echo awpm_checked( $settings, 'enable_rollback', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Keep snapshots for (days)', 'advanced-woo-product-migrator' ); ?></th><td><input type="number" min="1" name="awpm_settings[snapshot_retention_days]" value="<?php echo esc_attr( awpm_val( $settings, 'snapshot_retention_days', 14 ) ); ?>"></td></tr>
			</table>
		<?php elseif ( 'logging' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Enable logging', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[logging_enabled]" <?php echo awpm_checked( $settings, 'logging_enabled', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Log retention (days)', 'advanced-woo-product-migrator' ); ?></th><td><input type="number" min="1" name="awpm_settings[log_retention_days]" value="<?php echo esc_attr( awpm_val( $settings, 'log_retention_days', 30 ) ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Log location', 'advanced-woo-product-migrator' ); ?></th><td><code><?php echo esc_html( $wpdb->prefix ?? 'wp_' ); ?>awpm_logs</code> <?php esc_html_e( '(database table — not flat files, so it survives file-based server backups/restores cleanly).', 'advanced-woo-product-migrator' ); ?></td></tr>
			</table>
		<?php elseif ( 'performance' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Default batch size', 'advanced-woo-product-migrator' ); ?></th><td>
					<select name="awpm_settings[batch_size]">
						<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?>
							<option value="<?php echo esc_attr( $n ); ?>" <?php selected( (int) awpm_val( $settings, 'batch_size', 50 ), $n ); ?>><?php echo esc_html( $n ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Remote fetch timeout (seconds)', 'advanced-woo-product-migrator' ); ?></th><td><input type="number" min="5" max="120" name="awpm_settings[remote_timeout]" value="<?php echo esc_attr( awpm_val( $settings, 'remote_timeout', 30 ) ); ?>"></td></tr>
			</table>
		<?php elseif ( 'notifications' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Notification emails', 'advanced-woo-product-migrator' ); ?></th><td><input type="text" class="regular-text" name="awpm_settings[notification_emails]" value="<?php echo esc_attr( implode( ', ', awpm_val( $settings, 'notification_emails', array() ) ) ); ?>" placeholder="you@example.com, ops@example.com"></td></tr>
				<tr><th><?php esc_html_e( 'Notify on completion', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[notify_on_completion]" <?php echo awpm_checked( $settings, 'notify_on_completion' ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Notify on failure', 'advanced-woo-product-migrator' ); ?></th><td><label><input type="checkbox" name="awpm_settings[notify_on_failure]" <?php echo awpm_checked( $settings, 'notify_on_failure', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-woo-product-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Webhook URL', 'advanced-woo-product-migrator' ); ?></th><td><input type="url" class="regular-text" name="awpm_settings[webhook_url]" value="<?php echo esc_attr( awpm_val( $settings, 'webhook_url' ) ); ?>" placeholder="https://example.com/hooks/awpm"></td></tr>
				<tr><th><?php esc_html_e( 'REST API base', 'advanced-woo-product-migrator' ); ?></th><td><code><?php echo esc_html( rest_url( 'awpm/v1' ) ); ?></code></td></tr>
			</table>
		<?php endif; ?>

		<?php submit_button(); ?>
	</form>

	<?php endif; ?>
</div>
