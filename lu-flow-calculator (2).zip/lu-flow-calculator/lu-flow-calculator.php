<?php
/**
 * Plugin Name: NT Cloke Booster Set Builder
 * Description: Flow calculator with enquiry submission for booster systems
 * Version: 3.1
 * Author: NT Cloke
 */

if (!defined('ABSPATH'))
    exit;

// ========================
// 1. ENQUIRY HANDLER (PHP)
// ========================

// Create custom post type for enquiries
add_action('init', function () {
    register_post_type('booster_enquiry', [
        'labels' => [
            'name' => 'Booster Enquiries',
            'singular_name' => 'Enquiry',
            'menu_name' => 'Booster Enquiries',
            'all_items' => 'All Enquiries',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Enquiry',
            'edit_item' => 'View Enquiry',
            'new_item' => 'New Enquiry',
            'view_item' => 'View Enquiry',
            'search_items' => 'Search Enquiries',
            'not_found' => 'No enquiries found',
            'not_found_in_trash' => 'No enquiries found in Trash'
        ],
        'public' => true,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-email-alt',
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => ['title'],
        'map_meta_cap' => true,
        'show_in_rest' => false,
        'rewrite' => false
    ]);
});

// Remove default editor
add_action('admin_init', function () {
    remove_post_type_support('booster_enquiry', 'editor');
});

// AJAX handler for form submission
add_action('wp_ajax_submit_booster_enquiry', 'handle_booster_enquiry');
add_action('wp_ajax_nopriv_submit_booster_enquiry', 'handle_booster_enquiry');

function handle_booster_enquiry()
{
    // Verify nonce for security
    if (!wp_verify_nonce($_POST['nonce'], 'booster_enquiry_nonce')) {
        wp_send_json_error('Security check failed');
        wp_die();
    }

    // Sanitize and validate
    $email = sanitize_email($_POST['email'] ?? '');
    if (!is_email($email)) {
        wp_send_json_error('Please enter a valid email address');
        wp_die();
    }
$property_type = sanitize_text_field($_POST['property_type'] ?? '');
$property_location = sanitize_text_field($_POST['property_location'] ?? '');

    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $notes = sanitize_textarea_field($_POST['notes'] ?? '');

    // Get calculation data
    $calculation_data = [
        'frequency' => sanitize_text_field($_POST['frequency'] ?? 'medium'),
        'total_lu' => floatval($_POST['total_lu'] ?? 0),
        'ciphe_flow' => floatval($_POST['ciphe_flow'] ?? 0),
        'ciphe_storage' => intval($_POST['ciphe_storage'] ?? 0),
        'static_lift' => floatval($_POST['static_lift'] ?? 0),
        'pipe_loss' => floatval($_POST['pipe_loss'] ?? 0),
        'outlet_pressure' => floatval($_POST['outlet_pressure'] ?? 0),
        'total_head' => floatval($_POST['total_head'] ?? 0),
        'submitted_at' => current_time('mysql'),
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ];

    // Add EN806 data if low frequency
    if ($_POST['frequency'] === 'low') {
        $calculation_data['en_flow'] = floatval($_POST['en_flow'] ?? 0);
        $calculation_data['en_storage'] = intval($_POST['en_storage'] ?? 0);
    }

    // Get fixture counts
    $fixture_data = [];
    if (isset($_POST['fixtures']) && is_array($_POST['fixtures'])) {
        foreach ($_POST['fixtures'] as $fixture) {
            $fixture_data[] = sanitize_text_field($fixture);
        }
    }

    // Handle file uploads
    $uploaded_files = [];
    if (!empty($_FILES['photos'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        // Create upload directory if it doesn't exist
        $upload_dir = wp_upload_dir();
        $enquiry_dir = $upload_dir['basedir'] . '/booster-enquiries/' . date('Y/m');
        if (!file_exists($enquiry_dir)) {
            wp_mkdir_p($enquiry_dir);
        }

        foreach ($_FILES['photos']['tmp_name'] as $index => $tmp_name) {
            if ($_FILES['photos']['error'][$index] === 0 && $tmp_name) {
                $file_name = sanitize_file_name($_FILES['photos']['name'][$index]);
                $file_path = $enquiry_dir . '/' . time() . '_' . $file_name;

                if (move_uploaded_file($tmp_name, $file_path)) {
                    $uploaded_files[] = [
                        'path' => $file_path,
                        'url' => str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $file_path),
                        'name' => $file_name,
                        'size' => $_FILES['photos']['size'][$index]
                    ];
                }
            }
        }
    }

    // ====================
    // SAVE ENQUIRY TO DB
    // ====================

    $post_id = wp_insert_post([
        'post_type' => 'booster_enquiry',
        'post_title' => 'Enquiry from ' . $email . ' - ' . date('d/m/Y H:i'),
        'post_status' => 'publish',
        'post_content' => $notes,
        'meta_input' => [
            'contact_email' => $email,
            'property_type' => $property_type,
'property_location' => $property_location,

            'contact_phone' => $phone,
            'calculation_data' => $calculation_data,
            'fixture_data' => $fixture_data,
            'uploaded_files' => $uploaded_files,
            'status' => 'new',
            'assigned_to' => '',
            'engineer_notes' => ''
        ]
    ]);

    // ====================
    // SEND EMAIL NOTIFICATION (TO ADMIN)
    // ====================

    $to = get_option('admin_email'); // Change to enquiries@ntcloke.co.uk
    $subject = 'New Booster Enquiry - ' . get_bloginfo('name') . ' - ' . date('d/m/Y H:i');

    $message = "=== NEW BOOSTER SET ENQUIRY ===\n\n";
    $message .= "CONTACT DETAILS:\n";  
    $message .= "Email: " . $email . "\n";
    $message .= "Phone: " . ($phone ?: 'Not provided') . "\n";
    $message .= "Submitted: " . date('d/m/Y H:i:s') . "\n";
    $message .= "IP Address: " . $calculation_data['ip_address'] . "\n\n";

    $message .= "PROPERTY DETAILS:\n";
    $message .= "Property Type: " . $property_type . "\n";
    $message .= "Location: " . $property_location . "\n\n";


    $message .= "CALCULATION RESULTS:\n";
    $message .= "Frequency: " . ucfirst($calculation_data['frequency']) . "\n";
    $message .= "Total Loading Units: " . $calculation_data['total_lu'] . "\n";
    $message .= "CIPHE Flow Rate: " . $calculation_data['ciphe_flow'] . " L/Sec\n";
    $message .= "CIPHE Storage (15 min): " . $calculation_data['ciphe_storage'] . " Litres\n";

    if (isset($calculation_data['en_flow'])) {
        $message .= "EN 806-3 Flow Rate: " . $calculation_data['en_flow'] . " L/Sec\n";
        $message .= "EN Storage (15 min): " . $calculation_data['en_storage'] . " Litres\n";
    }

    $message .= "\nPRESSURE REQUIREMENTS:\n";
    $message .= "Static Lift: " . $calculation_data['static_lift'] . " m\n";
    $message .= "Pipework Friction Loss: " . $calculation_data['pipe_loss'] . " m\n";
    $message .= "Outlet Pressure: " . $calculation_data['outlet_pressure'] . " m\n";
    $message .= "Total Required Head: " . $calculation_data['total_head'] . " m\n\n";

    if (!empty($fixture_data)) {
        $message .= "FIXTURE COUNT:\n";
        foreach ($fixture_data as $fixture) {
            $message .= "• " . $fixture . "\n";
        }
        $message .= "\n";
    }

    if (!empty($notes)) {
        $message .= "ADDITIONAL NOTES:\n" . $notes . "\n\n";
    }

    $message .= "FILES UPLOADED: " . count($uploaded_files) . "\n\n";

    $message .= "VIEW ENQUIRY IN DASHBOARD:\n";
    $message .= admin_url('edit.php?post_type=booster_enquiry') . "\n\n";

    $message .= "=================================\n";
    $message .= "This is an automated enquiry from the NT Cloke Booster Set Builder.\n";
    $message .= "Please respond within 24 hours.\n";

    $headers = [
        'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>',
        'Content-Type: text/plain; charset=UTF-8'
    ];

    wp_mail($to, $subject, $message, $headers);

    // ====================
    // SEND IMPROVED CONFIRMATION EMAIL TO USER
    // ====================

    $user_subject = 'NT Cloke - Booster Set Enquiry Received (Ref: ENQ-' . $post_id . ')';
    $logo_url = 'https://ntclokepumpsandwater.co.uk/wp-content/uploads/2026/02/ntclock.png';


    // Build HTML email with calculation details
    $user_message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; }
            .header { background: #1296CE; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .calculation-box { background: white; border: 2px solid #1296CE; border-radius: 5px; padding: 15px; margin: 15px 0; }
            .calculation-box h3 { color: #1296CE; margin-top: 0; }
            .calculation-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
            .calculation-row:last-child { border-bottom: none; }
            .calculation-label { font-weight: bold; color: #555; }
            .calculation-value { color: #1296CE; font-weight: bold; }
            .next-steps { background: #e8f4fc; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .footer { background: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #666; }
            .important-note { background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; border-radius: 4px; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class="header">
            <h2>NT Cloke Pumps & Water</h2>
            <h3>Booster Set Enquiry Confirmation</h3>
        </div>
        
        <div class="content">
            <p>Dear Customer,</p>
            
            <p>Thank you for your booster set enquiry. Our engineering team has received your details and will review your requirements.</p>
            
            <div class="calculation-box">
                <h3>Your Calculation Summary</h3>
                
                <div class="calculation-row">
                    <span class="calculation-label">Enquiry Reference:</span>
                    <span class="calculation-value">ENQ-' . $post_id . '</span>
                </div>
                
                <div class="calculation-row">
                    <span class="calculation-label">Frequency of Use:</span>
                    <span class="calculation-value">' . ucfirst($calculation_data['frequency']) . '</span>
                </div>
                
                <div class="calculation-row">
                    <span class="calculation-label">Total Loading Units:</span>
                    <span class="calculation-value">' . $calculation_data['total_lu'] . ' LU</span>
                </div>
                
                <div class="calculation-row">
                    <span class="calculation-label">Flow Rate Required:</span>
                    <span class="calculation-value">' . $calculation_data['ciphe_flow'] . ' L/Sec</span>
                </div>
                
                <div class="calculation-row">
                    <span class="calculation-label">Storage (15 minutes):</span>
                    <span class="calculation-value">' . $calculation_data['ciphe_storage'] . ' Litres</span>
                </div>';

    if (isset($calculation_data['en_flow'])) {
        $user_message .= '
                <div class="calculation-row">
                    <span class="calculation-label">EN 806-3 Flow Rate:</span>
                    <span class="calculation-value">' . $calculation_data['en_flow'] . ' L/Sec</span>
                </div>
                
                <div class="calculation-row">
                    <span class="calculation-label">EN Storage (15 minutes):</span>
                    <span class="calculation-value">' . $calculation_data['en_storage'] . ' Litres</span>
                </div>';
    }

    $user_message .= '
                <div class="calculation-row">
                    <span class="calculation-label">Total Pressure Required:</span>
                    <span class="calculation-value">' . $calculation_data['total_head'] . ' m</span>
                </div>
            </div>
            
            <div class="next-steps">
                <h3>What Happens Next</h3>
                <ol>
                    <li><strong>Review:</strong> Our engineering team will assess your flow calculations and requirements</li>
                    <li><strong>Contact:</strong> We\'ll contact you within 24 hours to discuss your specific needs</li>
                    <li><strong>Site Visit:</strong> If required, we\'ll arrange a visit to measure up and assess site conditions</li>
                    <li><strong>Proposal:</strong> You\'ll receive a tailored solution and quotation</li>
                </ol>
            </div>
            
            <div class="important-note">
                <strong>Important Note:</strong> This email contains calculated values based on the information you provided. 
                These are indicative values only. All booster systems are individually engineered to your specific site 
                requirements by our qualified team. This is not an automated recommendation.
            </div>
            
            <p>If you have any questions in the meantime, please don\'t hesitate to contact us.</p>
            
            <p>Best regards,<br>
            <strong>The NT Cloke Engineering Team</strong></p>
        </div>
        
      <div class="footer">
    <div style="text-align:center;margin-bottom:15px;">
        <img src="' . $logo_url . '" 
             alt="NT Cloke Pumps & Water" 
             style="max-width:200px;height:auto;">
    </div>
    
    <p>
        <strong>NT Cloke Pumps & Water Ltd</strong><br>
        Tel: 0116 3735496<br>
        Email: info@ntclokepumpsandwater.co.uk<br>
        Website: ' . get_site_url() . '
    </p>
    
    <p style="margin-top:15px;font-size:11px;color:#888;">
        This email was sent in response to your enquiry submitted via the NT Cloke Booster Set Builder.
    </p>
</div>

    </body>
    </html>';

    // Set HTML headers for user email
    $user_headers = [
        'From: NT Cloke Pumps & Water <' . get_option('admin_email') . '>',
        'Content-Type: text/html; charset=UTF-8'
    ];

    wp_mail($email, $user_subject, $user_message, $user_headers);

    // Return success response
    wp_send_json_success([
        'message' => 'Thank you! Your enquiry has been submitted successfully.',
        'reference' => 'ENQ-' . $post_id,
        'email' => $email
    ]);

    wp_die();
}

// ========================
// 2. ENHANCED ADMIN COLUMNS
// ========================

// Add custom columns
add_filter('manage_booster_enquiry_posts_columns', function ($columns) {
    $new_columns = [
        'cb' => $columns['cb'],
        'title' => 'Enquiry',
        'contact_email' => 'Email',
        'contact_phone' => 'Phone',
        'total_lu' => 'Loading Units',
        'flow_rate' => 'Flow Rate',
        'pressure' => 'Pressure',
        'status' => 'Status',
        'date' => 'Date'
    ];
    return $new_columns;
});

// Populate custom columns
add_action('manage_booster_enquiry_posts_custom_column', function ($column, $post_id) {
    $calculation_data = get_post_meta($post_id, 'calculation_data', true);

    switch ($column) {
        case 'contact_email':
            echo get_post_meta($post_id, 'contact_email', true) ?: '—';
            break;

        case 'contact_phone':
            echo get_post_meta($post_id, 'contact_phone', true) ?: '—';
            break;

        case 'total_lu':
            echo isset($calculation_data['total_lu']) ?
                '<strong>' . $calculation_data['total_lu'] . ' LU</strong>' : '—';
            break;

        case 'flow_rate':
            if (isset($calculation_data['ciphe_flow'])) {
                $flow = $calculation_data['ciphe_flow'];
                $storage = isset($calculation_data['ciphe_storage']) ? $calculation_data['ciphe_storage'] : ($flow * 900);
                echo '<div class="flow-data">';
                echo '<div><strong>' . $flow . ' L/S</strong></div>';
                echo '<div class="small-text">' . $storage . ' L (15min)</div>';
                echo '</div>';
            } else {
                echo '—';
            }
            break;

        case 'pressure':
            if (isset($calculation_data['total_head'])) {
                $head = $calculation_data['total_head'];
                $static = isset($calculation_data['static_lift']) ? $calculation_data['static_lift'] : 0;
                echo '<div class="pressure-data">';
                echo '<div><strong>' . $head . ' m</strong></div>';
                echo '<div class="small-text">Static: ' . $static . ' m</div>';
                echo '</div>';
            } else {
                echo '—';
            }
            break;

        case 'status':
            $status = get_post_meta($post_id, 'status', true) ?: 'new';
            $status_colors = [
                'new' => '#3498db',
                'review' => '#f39c12',
                'contacted' => '#27ae60',
                'quoted' => '#9b59b6',
                'won' => '#2ecc71',
                'lost' => '#e74c3c',
                'closed' => '#95a5a6'
            ];
            $color = isset($status_colors[$status]) ? $status_colors[$status] : '#95a5a6';
            echo '<span class="status-badge" style="background:' . $color . ';color:white;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:bold;">' . ucfirst($status) . '</span>';
            break;
    }
}, 10, 2);

// Make columns sortable
add_filter('manage_edit-booster_enquiry_sortable_columns', function ($columns) {
    $columns['total_lu'] = 'total_lu';
    $columns['flow_rate'] = 'flow_rate';
    $columns['date'] = 'date';
    return $columns;
});

// ========================
// 3. ENQUIRY DETAILS VIEW
// ========================

// Remove default meta boxes
add_action('admin_menu', function () {
    remove_meta_box('submitdiv', 'booster_enquiry', 'side');
    remove_meta_box('slugdiv', 'booster_enquiry', 'normal');
}, 999);

// Add custom meta boxes
add_action('add_meta_boxes', function () {
    add_meta_box(
        'enquiry_details',
        'Enquiry Details',
        'render_enquiry_details',
        'booster_enquiry',
        'normal',
        'high'
    );

    add_meta_box(
        'calculation_data',
        'Calculation Results',
        'render_calculation_data',
        'booster_enquiry',
        'normal',
        'high'
    );

    add_meta_box(
        'files_data',
        'Uploaded Files',
        'render_files_data',
        'booster_enquiry',
        'normal',
        'high'
    );

    add_meta_box(
        'engineer_notes',
        'Engineering Notes',
        'render_engineer_notes',
        'booster_enquiry',
        'side',
        'high'
    );

    add_meta_box(
        'actions_meta_box',
        'Quick Actions',
        'render_actions_meta_box',
        'booster_enquiry',
        'side',
        'high'
    );
});

function render_enquiry_details($post)
{
    $email = get_post_meta($post->ID, 'contact_email', true);
    $phone = get_post_meta($post->ID, 'contact_phone', true);
    $calculation_data = get_post_meta($post->ID, 'calculation_data', true);
    $submitted_at = isset($calculation_data['submitted_at']) ? $calculation_data['submitted_at'] : '';
    $ip = isset($calculation_data['ip_address']) ? $calculation_data['ip_address'] : '';
    $notes = $post->post_content;

    ?>
    <div class="enquiry-details-container">
        <table class="widefat" style="border:none;">
            <tr>
                <td width="25%" style="padding:10px;"><strong>Email:</strong></td>
                <td style="padding:10px;">
                    <a href="mailto:<?php echo esc_attr($email); ?>">
                        <?php echo esc_html($email); ?>
                    </a>
                </td>
            </tr>
            <tr>
                <td style="padding:10px;"><strong>Phone:</strong></td>
                <td style="padding:10px;">
                    <?php if ($phone): ?>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>">
                            <?php echo esc_html($phone); ?>
                        </a>
                    <?php else: ?>
                        Not provided
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
    <td style="padding:10px;"><strong>Property Type:</strong></td>
    <td style="padding:10px;"><?php echo esc_html(get_post_meta($post->ID, 'property_type', true)); ?></td>
</tr>

<tr>
    <td style="padding:10px;"><strong>Location:</strong></td>
    <td style="padding:10px;"><?php echo esc_html(get_post_meta($post->ID, 'property_location', true)); ?></td>
</tr>

            <tr>
                <td style="padding:10px;"><strong>Submitted:</strong></td>
                <td style="padding:10px;"><?php echo esc_html(date('d/m/Y H:i:s', strtotime($submitted_at))); ?></td>
            </tr>
            <tr>
                <td style="padding:10px;"><strong>IP Address:</strong></td>
                <td style="padding:10px;"><?php echo esc_html($ip); ?></td>
            </tr>
            <?php if ($notes): ?>
                <tr>
                    <td style="padding:10px;vertical-align:top;"><strong>Customer Notes:</strong></td>
                    <td style="padding:10px;"><?php echo nl2br(esc_html($notes)); ?></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
    <?php
}

function render_calculation_data($post)
{
    $calculation_data = get_post_meta($post->ID, 'calculation_data', true);
    $fixture_data = get_post_meta($post->ID, 'fixture_data', true);

    if (empty($calculation_data)) {
        echo '<p>No calculation data available.</p>';
        return;
    }
    ?>
    <div class="calculation-data-container">
        <div
            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
            <!-- Basic Info -->
            <div class="data-section" style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:15px;">
                <h3 style="color:#1296CE;margin-top:0;border-bottom:1px solid #f0f0f0;padding-bottom:8px;">Basic Information
                </h3>
                <table style="width:100%;">
                    <tr>
                        <td style="padding:8px 0;"><strong>Frequency:</strong></td>
                        <td style="padding:8px 0;">
                            <?php echo esc_html(ucfirst($calculation_data['frequency'] ?? 'Medium')); ?></td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;"><strong>Total Loading Units:</strong></td>
                        <td style="padding:8px 0;"><span
                                style="color:#1296CE;font-weight:bold;font-size:16px;"><?php echo esc_html($calculation_data['total_lu'] ?? 0); ?>
                                LU</span></td>
                    </tr>
                </table>
            </div>

            <!-- Flow Data -->
            <div class="data-section" style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:15px;">
                <h3 style="color:#1296CE;margin-top:0;border-bottom:1px solid #f0f0f0;padding-bottom:8px;">Flow Requirements
                </h3>
                <table style="width:100%;">
                    <tr>
                        <td style="padding:8px 0;"><strong>CIPHE Flow Rate:</strong></td>
                        <td style="padding:8px 0;"><span
                                style="color:#1296CE;font-weight:bold;font-size:16px;"><?php echo esc_html($calculation_data['ciphe_flow'] ?? 0); ?>
                                L/Sec</span></td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;"><strong>CIPHE Storage (15min):</strong></td>
                        <td style="padding:8px 0;"><span
                                style="color:#1296CE;font-weight:bold;font-size:16px;"><?php echo esc_html($calculation_data['ciphe_storage'] ?? 0); ?>
                                Litres</span></td>
                    </tr>
                    <?php if (isset($calculation_data['en_flow'])): ?>
                        <tr>
                            <td style="padding:8px 0;"><strong>EN 806-3 Flow Rate:</strong></td>
                            <td style="padding:8px 0;"><?php echo esc_html($calculation_data['en_flow']); ?> L/Sec</td>
                        </tr>
                        <tr>
                            <td style="padding:8px 0;"><strong>EN Storage (15min):</strong></td>
                            <td style="padding:8px 0;"><?php echo esc_html($calculation_data['en_storage'] ?? 0); ?> Litres</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>

            <!-- Pressure Data -->
            <div class="data-section" style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:15px;">
                <h3 style="color:#1296CE;margin-top:0;border-bottom:1px solid #f0f0f0;padding-bottom:8px;">Pressure
                    Requirements</h3>
                <table style="width:100%;">
                    <tr>
                        <td style="padding:8px 0;"><strong>Static Lift:</strong></td>
                        <td style="padding:8px 0;"><?php echo esc_html($calculation_data['static_lift'] ?? 0); ?> m</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;"><strong>Pipe Friction Loss:</strong></td>
                        <td style="padding:8px 0;"><?php echo esc_html($calculation_data['pipe_loss'] ?? 0); ?> m</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;"><strong>Outlet Pressure:</strong></td>
                        <td style="padding:8px 0;"><?php echo esc_html($calculation_data['outlet_pressure'] ?? 0); ?> m</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;"><strong>Total Required Head:</strong></td>
                        <td style="padding:8px 0;"><span
                                style="color:#1296CE;font-weight:bold;font-size:16px;"><?php echo esc_html($calculation_data['total_head'] ?? 0); ?>
                                m</span></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Fixture Count -->
        <?php if (!empty($fixture_data) && is_array($fixture_data)): ?>
            <div class="data-section"
                style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:15px;margin-top:20px;">
                <h3 style="color:#1296CE;margin-top:0;border-bottom:1px solid #f0f0f0;padding-bottom:8px;">Fixture Count</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 10px;">
                    <?php foreach ($fixture_data as $fixture): ?>
                        <div style="background: #f8f9fa; padding: 8px 12px; border-radius: 4px; border-left: 3px solid #1296CE;">
                            <?php echo esc_html($fixture); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

function render_files_data($post)
{
    $uploaded_files = get_post_meta($post->ID, 'uploaded_files', true);

    if (empty($uploaded_files)) {
        echo '<p>No files uploaded.</p>';
        return;
    }
    ?>
    <div class="files-container">
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
            <?php foreach ($uploaded_files as $file): ?>
                <div class="file-card"
                    style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:10px;text-align:center;">
                    <?php
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $is_image = in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                    ?>

                    <?php if ($is_image): ?>
                        <div class="file-preview">
                            <a href="<?php echo esc_url($file['url']); ?>" target="_blank">
                                <img src="<?php echo esc_url($file['url']); ?>"
                                    style="max-width: 100%; height: 120px; object-fit: cover; border-radius: 4px;">
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="file-icon" style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 4px;">
                            <span style="font-size: 48px;">📄</span>
                        </div>
                    <?php endif; ?>

                    <div class="file-info" style="margin-top: 8px;">
                        <div style="font-size: 12px; color: #666; word-break: break-all;">
                            <?php echo esc_html($file['name']); ?>
                        </div>
                        <div style="font-size: 11px; color: #999;">
                            <?php echo size_format($file['size']); ?>
                        </div>
                        <a href="<?php echo esc_url($file['url']); ?>" target="_blank" class="button button-small"
                            style="margin-top: 5px;">
                            View File
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

function render_engineer_notes($post)
{
    $status = get_post_meta($post->ID, 'status', true) ?: 'new';
    $assigned_to = get_post_meta($post->ID, 'assigned_to', true);
    $engineer_notes = get_post_meta($post->ID, 'engineer_notes', true);

    // Nonce for security
    wp_nonce_field('save_engineer_notes', 'engineer_notes_nonce');
    ?>
    <div class="engineer-notes-container">
        <p>
            <label for="enquiry_status"><strong>Status:</strong></label>
            <select name="enquiry_status" id="enquiry_status" style="width: 100%; margin-top: 5px;">
                <option value="new" <?php selected($status, 'new'); ?>>New</option>
                <option value="review" <?php selected($status, 'review'); ?>>Under Review</option>
                <option value="contacted" <?php selected($status, 'contacted'); ?>>Contacted</option>
                <option value="quoted" <?php selected($status, 'quoted'); ?>>Quoted</option>
                <option value="won" <?php selected($status, 'won'); ?>>Won</option>
                <option value="lost" <?php selected($status, 'lost'); ?>>Lost</option>
                <option value="closed" <?php selected($status, 'closed'); ?>>Closed</option>
            </select>
        </p>

        <p>
            <label for="assigned_to"><strong>Assigned To:</strong></label>
            <input type="text" name="assigned_to" id="assigned_to" value="<?php echo esc_attr($assigned_to); ?>"
                placeholder="Engineer name" style="width: 100%; margin-top: 5px;">
        </p>

        <p>
            <label for="engineer_notes"><strong>Internal Notes:</strong></label>
            <textarea name="engineer_notes" id="engineer_notes" rows="10" style="width: 100%; margin-top: 5px;"
                placeholder="Add internal notes here..."><?php echo esc_textarea($engineer_notes); ?></textarea>
        </p>

        <p>
            <input type="submit" name="save" class="button button-primary" value="Update Enquiry">
        </p>
    </div>
    <?php
}

function render_actions_meta_box($post)
{
    $email = get_post_meta($post->ID, 'contact_email', true);
    $phone = get_post_meta($post->ID, 'contact_phone', true);
    $reference = 'ENQ-' . $post->ID;
    ?>
    <div class="actions-container">
        <p>
            <strong>Enquiry Reference:</strong><br>
            <code style="background:#f1f1f1;padding:5px;display:inline-block;margin:5px 0;"><?php echo $reference; ?></code>
        </p>

        <p>
            <a href="mailto:<?php echo esc_attr($email); ?>?subject=Re: Your Booster Set Enquiry (<?php echo $reference; ?>)"
                class="button button-primary" style="width: 100%; text-align: center; margin-bottom: 5px;">
                📧 Email Customer
            </a>
        </p>

        <?php if ($phone): ?>
            <p>
                <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>" class="button"
                    style="width: 100%; text-align: center; margin-bottom: 5px;">
                    📞 Call Customer
                </a>
            </p>
        <?php endif; ?>

        <p>
            <button type="button" class="button" style="width: 100%; margin-bottom: 5px;" onclick="window.print();">
                🖨️ Print Enquiry
            </button>
        </p>

        <hr style="margin: 15px 0;">

        <div style="font-size: 12px; color: #666;">
            <p><strong>Quick Actions:</strong></p>
            <ul style="margin-left: 15px;">
                <li>Update status to track progress</li>
                <li>Assign to engineer</li>
                <li>Add internal notes</li>
                <li>Contact customer directly</li>
            </ul>
        </div>
    </div>
    <?php
}

// Save meta box data
add_action('save_post_booster_enquiry', function ($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;
    if (
        !isset($_POST['engineer_notes_nonce']) ||
        !wp_verify_nonce($_POST['engineer_notes_nonce'], 'save_engineer_notes')
    )
        return;

    // Save status
    if (isset($_POST['enquiry_status'])) {
        update_post_meta($post_id, 'status', sanitize_text_field($_POST['enquiry_status']));
    }

    // Save assigned to
    if (isset($_POST['assigned_to'])) {
        update_post_meta($post_id, 'assigned_to', sanitize_text_field($_POST['assigned_to']));
    }

    // Save engineer notes
    if (isset($_POST['engineer_notes'])) {
        update_post_meta($post_id, 'engineer_notes', sanitize_textarea_field($_POST['engineer_notes']));
    }
});

// ========================
// 4. ADMIN STYLES
// ========================

add_action('admin_head', function () {
    global $post_type;

    if ($post_type !== 'booster_enquiry')
        return;
    ?>
    <style>
        /* List view styles */
        .column-total_lu,
        .column-flow_rate,
        .column-pressure {
            width: 120px;
        }

        .column-status {
            width: 100px;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            color: white;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .flow-data .small-text,
        .pressure-data .small-text {
            font-size: 11px;
            color: #666;
            margin-top: 2px;
        }

        /* Edit view styles */
        .enquiry-details-container table,
        .calculation-data-container table {
            border: none;
            background: none;
        }

        .enquiry-details-container table tr,
        .calculation-data-container table tr {
            border-bottom: 1px solid #f0f0f0;
        }

        .enquiry-details-container table td,
        .calculation-data-container table td {
            padding: 10px;
            vertical-align: top;
        }

        .data-section {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 15px;
        }

        .data-section h3 {
            margin-top: 0;
            color: #1296CE;
            font-size: 14px;
            border-bottom: 1px solid #f0f0f0;
            padding-bottom: 8px;
        }

        .highlight {
            color: #1296CE;
            font-weight: bold;
            font-size: 16px;
        }

        .file-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            text-align: center;
        }

        .file-card .button-small {
            margin-top: 5px;
        }

        /* Make room for meta boxes */
        #post-body-content {
            float: none;
            width: auto;
        }

        #postbox-container-1 {
            float: right;
            width: 280px;
        }

        #post-body.columns-2 #postbox-container-2 {
            float: left;
            width: calc(100% - 300px);
        }

        /* Print styles */
        @media print {

            #adminmenumain,
            #wpadminbar,
            #screen-meta-links,
            #submitdiv,
            .postbox-container:not(:first-child) {
                display: none !important;
            }

            #wpcontent {
                margin-left: 0 !important;
            }

            .postbox {
                border: none;
                box-shadow: none;
            }
        }
    </style>
    <?php
});

// ========================
// 5. CALCULATOR SHORTCODE (YOUR EXISTING CODE - Keep exactly as is)
// ========================

add_shortcode('booster_set_builder', 'booster_set_builder_shortcode');

function booster_set_builder_shortcode()
{
    // [Your existing calculator shortcode function remains EXACTLY THE SAME]
    // Generate nonce for security
    $nonce = wp_create_nonce('booster_enquiry_nonce');

    ob_start(); ?>

    <div class="booster-calculator-wrapper">
        <div class="booster-intro">
            <h3>Booster Set Builder</h3>
            <p>Calculate your flow requirements and submit an enquiry to our engineering team.</p>
        </div>

        <div class="calculator-box">
            <!-- CALCULATOR SECTION -->
            <div class="calc-section">
                <h4>FLOW RATE CALCULATOR</h4>

                <div class="field-group">
                    <label for="frequency">Frequency of Use</label>
                    <select id="frequency" class="form-select" onchange="updateFixtureValues();">
                        <option value="low">Low Frequency (e.g., offices, small commercial)</option>
                        <option value="medium" selected>Medium Frequency (e.g., hotels, restaurants)</option>
                        <option value="high">High Frequency (e.g., hospitals, schools)</option>
                    </select>
                    <small class="field-hint">Select based on how intensively the system will be used</small>
                </div>

                <hr class="section-divider">

                <h5>Fixture Count</h5>
                <p class="section-description">Enter the number of each fixture type in your system:</p>

                <div class="fixture-grid" id="fixtureGrid">
                    <!-- Fixture inputs will be generated here -->
                </div>

                <button class="btn btn-secondary" onclick="calculateFlow();">
                    <span class="btn-icon">📊</span> Calculate Flow Rate
                </button>

                <div class="results-box" id="calculationResults" style="display:none;">
                    <h5>Calculation Results</h5>
                    <div id="resultsContent"></div>
                </div>

                <!-- FLOW CURVE GRAPH -->
                <div class="graph-container">
                    <canvas id="flowGraph" height="300"></canvas>
                    <div class="graph-legend">
                        <span class="legend-item"><span class="color-box" style="background:#59b8df;"></span> CIPHE
                            Curve</span>
                        <span class="legend-item" id="enLegend" style="display:none;"><span class="color-box"
                                style="background:#0b5ed7;"></span> EN 806-3 Curve</span>
                        <span class="legend-item"><span class="color-box" style="background:#e53935;"></span> Your
                            System</span>
                    </div>
                </div>
            </div>

            <!-- PRESSURE SECTION -->
            <div class="calc-section">
                <h4>PRESSURE REQUIREMENT</h4>

                <div class="field-group">
                    <label for="staticLift">Static Lift (m)</label>
                    <input type="number" id="staticLift" class="form-input" value="0" min="0" step="0.1"
                        onchange="updatePressure();">
                    <small class="field-hint">Vertical height from pump to highest outlet</small>
                </div>

                <div class="field-group">
                    <label for="pipeLoss">Pipework Friction Loss (m)</label>
                    <input type="number" id="pipeLoss" class="form-input" value="0" min="0" step="0.1"
                        onchange="updatePressure();">
                    <small class="field-hint">Estimated pressure loss in pipework (allow 2-5m for small systems)</small>
                </div>

                <div class="field-group">
                    <label for="outletPressure">Required Pressure at Furthest Outlet (m)</label>
                    <input type="number" id="outletPressure" class="form-input" value="10" min="0" step="0.1"
                        onchange="updatePressure();">
                    <small class="field-hint">Typically 10-15m for good flow (1 bar = 10.2m)</small>
                </div>

                <div class="results-box">
                    <h5>Pressure Requirement</h5>
                    <div class="pressure-result">
                        <div class="pressure-value" id="pressureValue">0.0 m</div>
                        <div class="pressure-label">Total Required Head</div>
                    </div>
                </div>
            </div>

            <!-- ENQUIRY FORM SECTION -->
            <div class="calc-section enquiry-form" id="enquiryForm">
                <h4>GET RESULTS OF SUITABLE BOOSTER SETS</h4>
                <p class="section-description">Our engineering team will review your requirements and contact you within 24
                    hours.</p>
                <div class="field-group required">
                    <label for="propertyType">Property Type *</label>
                    <select id="propertyType" class="form-select" required>
                        <option value="">Select Property Type</option>
                        <option value="Residential">Residential</option>
                        <option value="Commercial">Commercial</option>
                        <option value="Hotel">Hotel</option>
                        <option value="Hospital">Hospital</option>
                        <option value="School">School</option>
                        <option value="Industrial">Industrial</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="field-group required">
                    <label for="propertyLocation">Location *</label>
                    <input type="text" id="propertyLocation" class="form-input" required placeholder="City / Site Address">
                </div>


                <div class="field-group required">
                    <label for="userEmail">Email Address *</label>
                    <input type="email" id="userEmail" class="form-input" required placeholder="your.name@company.co.uk">
                    <small class="field-hint">We'll send confirmation and updates to this address</small>
                </div>

                <div class="field-group">
                    <label for="userPhone">Phone Number</label>
                    <input type="tel" id="userPhone" class="form-input" placeholder="01234 567890">
                     <small class="field-hint" style="visibility:hidden;">placeholder</small>
                   
                </div>

                <div class="field-group">
                    <label for="pumpPhotos">Upload Photos (Optional)</label>
                    <div class="file-upload-area" id="dropZone">
                        <input type="file" id="pumpPhotos" multiple accept="image/*,.pdf,.doc,.docx" style="display:none;">
                        <div class="upload-placeholder">
                            <span class="upload-icon">📎</span>
                            <p>Click to upload or drag & drop</p>
                            <p class="upload-hint">Photos of existing pump, nameplate, or plant room</p>
                            <p class="upload-hint">Max 5MB per file • JPG, PNG, PDF, DOC</p>
                        </div>
                        <div class="file-preview" id="filePreview"></div>
                    </div>
                </div>

                <div class="field-group">
                    <label for="userNotes">Additional Information</label>
                    <textarea id="userNotes" class="form-textarea" rows="4"
                        placeholder="Tell us about your site, existing system, access requirements, or any specific needs..."></textarea>
                </div>

                <div class="privacy-notice">
                    <p>By submitting this enquiry, you agree to our processing of your data for the purpose of providing a
                        quotation. We will not share your details with third parties.</p>
                </div>

                <button class="btn btn-primary" onclick="submitEnquiry();" id="submitBtn">
                    <span class="btn-icon">🚀</span> Submit to Engineering Team
                </button>

                <div class="submission-result" id="submissionResult"></div>
            </div>
        </div>

        <!-- TECHNICAL INFO PANEL -->
        <div class="info-panel">
            <h5>How It Works</h5>
            <ol>
                <li><strong>Calculate:</strong> Enter your fixtures and pressure requirements</li>
                <li><strong>Submit:</strong> Send your enquiry with optional photos</li>
                <li><strong>Review:</strong> Our engineers assess your needs (within 24 hours)</li>
                <li><strong>Consult:</strong> We contact you to discuss solutions</li>
                <li><strong>Quote:</strong> Receive a tailored proposal</li>
            </ol>

            <div class="info-box">
                <h6>💡 Why Choose NT Cloke?</h6>
                <ul>
                    <li>Full supply & installation service</li>
                    <li>Bespoke and off-the-shelf solutions</li>
                    <li>Minimal downtime installations</li>
                    <li>20+ years of engineering experience</li>
                </ul>
            </div>

            <div class="contact-info">
                <p><strong>Prefer to speak to someone?</strong></p>
                <p>Call: <a href="tel:0116 3735496">0116 3735496</a></p>
                <p>Email: <a href="mailto:info@ntclokepumpsandwater.co.uk">info@ntclokepumpsandwater.co.uk</a></p>
            </div>
        </div>
    </div>

    <!-- HIDDEN FIELDS -->
    <input type="hidden" id="totalLU" value="0">
    <input type="hidden" id="cipheFlow" value="0">
    <input type="hidden" id="enFlow" value="0">
    <input type="hidden" id="totalHead" value="0">
    <input type="hidden" id="boosterNonce" value="<?php echo $nonce; ?>">

    <style>
        /* ================= MAIN STYLES ================= */
        .booster-calculator-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            font-family: 'Poppins';
            color: #333;
        }

        .booster-intro {
            background: linear-gradient(135deg, #1296CE 0%, #0a7cb4 100%);
            color: white;
            padding: 25px 30px;
            border-radius: 0px;
            margin-bottom: 25px;
        }

        .booster-intro h3 {
            margin: 0 0 10px 0;
            font-size: 28px;
            font-weight: 600;
        }

        .booster-intro p {
            margin: 0;
            opacity: 0.9;
            font-size: 16px;
        }

        .calculator-box {
            display: grid;
            grid-template-columns: 1fr;
            gap: 25px;
        }

        /* ================= ENQUIRY FORM INPUT STYLING ================= */

        .enquiry-form .form-input,
        .enquiry-form .form-textarea {
            height: 42px;
            padding: 8px 12px;
            border: 1px solid #d1d9e0;
            border-radius: 8px;
            text-align: left;
            font-size: 15px;
            font-weight: 500;
            background: #f9fbfd;
            transition: all 0.2s ease;
            box-sizing: border-box;
        }

        /* Textarea height override */
        .enquiry-form .form-textarea {
            height: auto;
            min-height: 100px;
            resize: vertical;
        }

        /* Hover effect */
        .enquiry-form .form-input:hover,
        .enquiry-form .form-textarea:hover {
            border-color: #1296CE;
        }

        /* Focus effect */
        .enquiry-form .form-input:focus,
        .enquiry-form .form-textarea:focus {
            border-color: #1296CE;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(18, 150, 206, 0.15);
            outline: none;
        }

        /* Pressure section inputs same styling */

        .calc-section input[type="number"] {
            height: 42px;
            padding: 8px 12px;
            border: 1px solid #d1d9e0;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 500;
            background: #f9fbfd;
            box-sizing: border-box;
            transition: all 0.2s ease;
            text-align: left;
        }

        /* Hover */
        .calc-section input[type="number"]:hover {
            border-color: #1296CE;
        }

        /* Focus */
        .calc-section input[type="number"]:focus {
            border-color: #1296CE;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(18, 150, 206, 0.15);
            outline: none;
        }

        @media (min-width: 992px) {
            .calculator-box {
                grid-template-columns: 1fr 1fr;
            }

            .enquiry-form {
                grid-column: span 2;
            }
        }

        .calc-section {
            background: white;
            border: 1px solid #e1e5e9;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .calc-section h4 {
            margin: 0 0 20px 0;
            color: #1296CE;
            font-size: 18px;
            font-weight: 600;
            border-bottom: 2px solid #f0f3f6;
            padding-bottom: 10px;
        }

        .calc-section h5 {
            margin: 20px 0 15px 0;
            color: #2c3e50;
            font-size: 16px;
            font-weight: 600;
        }

        .section-description {
            color: #666;
            font-size: 14px;
            margin: 0 0 15px 0;
            line-height: 1.5;
        }

        .section-divider {
            border: none;
            border-top: 1px solid #e1e5e9;
            margin: 20px 0;
        }

        /* ================= FORM CONTROLS ================= */
        .field-group {
            margin-bottom: 20px;
        }

        .field-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #2c3e50;
            font-size: 14px;
        }

        .field-group.required label:after {
            content: " *";
            color: #e74c3c;
        }

        .field-hint {
            display: block;
            margin-top: 4px;
            color: #7f8c8d;
            font-size: 12px;
            font-style: italic;
        }

        .form-select,
        .form-input,
        .form-textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #d1d9e0;
            border-radius: 4px;
            font-size: 14px;
            color: #333;
            background: white;
            transition: border 0.2s;
            box-sizing: border-box;
            text-align: left;
        }

        .form-select:focus,
        .form-input:focus,
        .form-textarea:focus {
            outline: none;
            border-color: #1296CE;
            box-shadow: 0 0 0 3px rgba(18, 150, 206, 0.1);
        }

        .form-textarea {
            resize: vertical;
            min-height: 80px;
            font-family: 'Poppins';
        }

        /* ================= BUTTONS ================= */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-align: center;
            width: 100%;
            gap: 8px;
        }

        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background: linear-gradient(135deg, #1296CE 0%, #0d7aad 100%);
            color: white;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #0d7aad 0%, #0a6a96 100%);
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #2c3e50;
            border: 1px solid #d1d9e0;
        }

        .btn-secondary:hover {
            background: #e9ecef;
            border-color: #1296CE;
        }

        .btn-icon {
            font-size: 16px;
        }
        
        .privacy-notice p{
   
    margin: 0px;
}
        /* ===== Only adjust 4 specific fields ===== */

@media (min-width: 768px) {

    .enquiry-form {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }

    /* Default full width */
    .enquiry-form .field-group {
        width: 100%;
    }

    /* Only these 4 fields half width */
    .enquiry-form .field-group:has(#propertyType),
    .enquiry-form .field-group:has(#propertyLocation),
    .enquiry-form .field-group:has(#userEmail),
    .enquiry-form .field-group:has(#userPhone) {
        flex: 1 1 calc(50% - 20px);
    }

}

@media (min-width: 768px) {

    /* Move entire phone field block up */
    .enquiry-form .field-group:has(#userPhone) {
        position: relative;
        top: -8px;   /* adjust as needed */
    }

}

        /* ================= RESULTS BOXES ================= */
        .results-box {
            background: #f8fafc;
            border: 1px solid #e1e8f0;
            border-radius: 6px;
            padding: 20px;
            margin-top: 20px;
        }

        .results-box h5 {
            margin-top: 0;
            color: #1296CE;
        }

        .pressure-result {
            text-align: left;
            padding: 15px;
        }

        select#frequency {
            border-radius: 10px;
        }

        .pressure-value {
            font-size: 32px;
            font-weight: 700;
            color: #1296CE;
            line-height: 1;
            margin-bottom: 5px;
        }

        .pressure-label {
            color: #7f8c8d;
            font-size: 14px;
        }

        /* ================= FILE UPLOAD ================= */
        .file-upload-area {
            border: 2px dashed #d1d9e0;
            border-radius: 6px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            background: #fcfdfe;
        }

        .file-upload-area:hover {
            border-color: #1296CE;
            background: #f8fbfd;
        }

        .file-upload-area.dragover {
            border-color: #1296CE;
            background: #e8f4fc;
        }

        .upload-placeholder {
            color: #7f8c8d;
        }

        .upload-icon {
            font-size: 32px;
            display: block;
            margin-bottom: 10px;
            opacity: 0.6;
        }

        .upload-hint {
            font-size: 12px;
            margin: 5px 0;
            color: #95a5a6;
        }

        .file-preview {
            margin-top: 15px;
            text-align: left;
        }

        .file-item {
            display: flex;
            align-items: center;
            padding: 8px;
            background: white;
            border: 1px solid #e1e8f0;
            border-radius: 4px;
            margin-bottom: 5px;
            font-size: 13px;
        }

        .file-item-remove {
            margin-left: auto;
            color: #e74c3c;
            cursor: pointer;
            font-weight: bold;
        }

        /* ================= FIXTURE GRID ================= */
        .fixture-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }

        .fixture-item input[type="number"] {
            height: 42px;
            padding: 8px 10px;
            border: 1px solid #d1d9e0;
            border-radius: 8px;
            /* Rounded corners */
            text-align: left;
            /* Center number */
            font-size: 15px;
            font-weight: 500;
            background: #f9fbfd;
            transition: all 0.2s ease;
        }

        .fixture-item {
            display: flex;
            flex-direction: column;
        }

        .fixture-item label {
            font-size: 13px;
            margin-bottom: 4px;
            color: #2c3e50;
        }

        .fixture-lu {
            font-size: 11px;
            color: #7f8c8d;
            font-weight: normal;
        }

        /* ================= GRAPH ================= */
        .graph-container {
            margin-top: 25px;
            padding: 15px;
            background: white;
            border: 1px solid #e1e5e9;
            border-radius: 6px;
        }

        #flowGraph {
            display: block;
            width: 100%;
        }


        .graph-legend {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid #f0f0f0;
        }

        .legend-item {
            display: flex;
            align-items: center;
            font-size: 13px;
            color: #666;
        }

        .color-box {
            width: 12px;
            height: 12px;
            margin-right: 6px;
            border-radius: 2px;
        }

        /* ================= SUBMISSION RESULT ================= */
        .submission-result {
            margin-top: 20px;
            padding: 20px;
            border-radius: 6px;
            display: none;
        }

        .submission-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .submission-error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        /* ================= INFO PANEL ================= */
        .info-panel {
            background: #f8fafc;
            border: 1px solid #e1e8f0;
            border-radius: 8px;
            padding: 25px;
            margin-top: 25px;
        }

        .info-panel h5 {
            color: #2c3e50;
            margin-top: 0;
            font-size: 18px;
        }

        .info-panel ol,
        .info-panel ul {
            padding-left: 20px;
            color: #555;
        }

        .info-panel li {
            margin-bottom: 10px;
            line-height: 1.5;
        }

        .info-box {
            background: white;
            border: 1px solid #e1e8f0;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }

        .info-box h6 {
            margin-top: 0;
            color: #1296CE;
            font-size: 16px;
        }

        .contact-info {
            border-top: 1px solid #e1e8f0;
            padding-top: 20px;
            font-size: 14px;
        }

        .contact-info a {
            color: #1296CE;
            text-decoration: none;
        }

        .contact-info a:hover {
            text-decoration: underline;
        }
        select#propertyType {
    color: black;
}

input#userEmail {
    color: black;
}
input#propertyLocation {
    color: black;
}
select#propertyType {
    color: black;
    border-radius: 10px;
}

        /* ================= PRIVACY NOTICE ================= */
        .privacy-notice {
            background: #f0f7ff;
            border-left: 3px solid #1296CE;
            padding: 12px 15px;
            margin: 20px 0;
            font-size: 12px;
            color: #5a6c7d;
            line-height: 1.5;
        }

        /* ================= RESPONSIVE ================= */
        @media (max-width: 768px) {
            .booster-intro {
                padding: 20px;
            }

            .booster-intro h3 {
                font-size: 24px;
            }

            .calc-section {
                padding: 20px;
            }

            .fixture-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script>
        // ======================
        // 1. FIXTURE DATA
        // ======================
        const fixtures = [
            "Basin, 15mm sep. taps",
            "Basin, 2 x 8mm mix tap",
            "Sink, 15mm sep/mix tap",
            "Sink, 20mm sep/mix tap",
            "Bath, 15mm sep/mix/tap",
            "Bath, 20mm sep/mix tap",
            "WC Suite, 6 litre cistern",
            "Shower, 15mm head",
            "Urinal, single bowl/stall",
            "Bidet, 15mm mix tap",
            "Hand Spray, 15mm",
            "Bucket Sink, 15mm taps",
            "Slop Hopper, cistern only",
            "Slop Hopper, cistern/taps",
            "Clothes washing m/c, domestic",
            "Dishwash m/c domestic"
        ];

        const LU = {
            low: [2, 1, 2, 7, 4, 11, 1, 2, 1, 1, 1, 1, 3, 5, 2, 2],
            medium: [2, 1, 5, 7, 8, 11, 2, 3, 1, 1, 1, 1, 3, 5, 2, 2],
            high: [4, 2, 10, 10, 16, 11, 5, 6, 1, 1, 1, 1, 3, 5, 2, 2]
        };

        // ======================
        // 2. FLOW CURVES
        // ======================
        const EN806 = [[0, 0], [10, 0.3], [20, 0.6], [50, 1.2], [100, 2.1], [200, 3.5], [400, 5.8]];
        const CIPHE = [[0, 0], [10, 0.25], [20, 0.5], [50, 1], [100, 1.8], [200, 3], [400, 5]];

        function interp(curve, lu) {
            if (lu <= 0) return 0;
            for (let i = 0; i < curve.length - 1; i++) {
                let [x1, y1] = curve[i];
                let [x2, y2] = curve[i + 1];
                if (lu >= x1 && lu <= x2) {
                    return y1 + (lu - x1) * (y2 - y1) / (x2 - x1);
                }
            }
            return curve[curve.length - 1][1];
        }

        // ======================
        // 3. FIXTURE GRID BUILDER
        // ======================
        function updateFixtureValues() {
            const frequency = document.getElementById('frequency').value;
            const grid = document.getElementById('fixtureGrid');
            grid.innerHTML = '';

            fixtures.forEach((name, i) => {
                const luValue = LU[frequency][i];
                grid.innerHTML += `
                <div class="fixture-item">
                    <label for="q${i}">
                        ${name} <span class="fixture-lu">(LU: ${luValue})</span>
                    </label>
                    <input type="number" 
                           id="q${i}" 
                           class="form-input" 
                           min="0" 
                           value="0" 
                           step="1" 
                           onchange="updateCalculation()">
                </div>
            `;
            });
        }

        // ======================
        // 4. CALCULATION FUNCTIONS
        // ======================
        let currentTotalLU = 0;
        let currentCipheFlow = 0;
        let currentEnFlow = 0;

        function calculateFlow() {
            const frequency = document.getElementById('frequency').value;
            let totalLU = 0;

            // Sum up fixture counts
            for (let i = 0; i < fixtures.length; i++) {
                const count = parseFloat(document.getElementById('q' + i).value) || 0;
                totalLU += count * LU[frequency][i];
            }

            currentTotalLU = totalLU;
            currentCipheFlow = interp(CIPHE, totalLU);
            currentEnFlow = (frequency === 'low') ? interp(EN806, totalLU) : 0;

            // Update hidden fields
            document.getElementById('totalLU').value = totalLU.toFixed(0);
            document.getElementById('cipheFlow').value = currentCipheFlow.toFixed(2);
            document.getElementById('enFlow').value = currentEnFlow.toFixed(2);

            // Display results
            const resultsDiv = document.getElementById('calculationResults');
            const resultsContent = document.getElementById('resultsContent');

            let html = `
            <div class="result-item">
                <div class="result-label">Total Loading Units</div>
                <div class="result-value">${totalLU.toFixed(0)} LU</div>
            </div>
            <div class="result-item">
                <div class="result-label">CIPHE Flow Rate</div>
                <div class="result-value">${currentCipheFlow.toFixed(2)} L/Sec</div>
            </div>
            <div class="result-item">
                <div class="result-label">Storage (15 minutes)</div>
                <div class="result-value">${(currentCipheFlow * 900).toFixed(0)} Litres</div>
            </div>
        `;

            if (frequency === 'low') {
                html += `
                <div class="result-item">
                    <div class="result-label">EN 806-3 Flow Rate</div>
                    <div class="result-value">${currentEnFlow.toFixed(2)} L/Sec</div>
                </div>
                <div class="result-item">
                    <div class="result-label">EN Storage (15 minutes)</div>
                    <div class="result-value">${(currentEnFlow * 900).toFixed(0)} Litres</div>
                </div>
            `;
            }

            resultsContent.innerHTML = html;
            resultsDiv.style.display = 'block';

            // Update graph
            drawGraph(totalLU, currentEnFlow, currentCipheFlow);

            // Scroll to results
            resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        function updateCalculation() {
            // Hide results if they were shown
            document.getElementById('calculationResults').style.display = 'none';
        }

        // ======================
        // 5. PRESSURE CALCULATION
        // ======================
        function updatePressure() {
            const staticLift = parseFloat(document.getElementById('staticLift').value) || 0;
            const pipeLoss = parseFloat(document.getElementById('pipeLoss').value) || 0;
            const outletPressure = parseFloat(document.getElementById('outletPressure').value) || 0;

            const totalHead = staticLift + pipeLoss + outletPressure;
            document.getElementById('pressureValue').textContent = totalHead.toFixed(1) + ' m';
            document.getElementById('totalHead').value = totalHead.toFixed(1);
        }

        // Initialize pressure display
        updatePressure();

        // ======================
        // 6. GRAPH DRAWING
        // ======================
        function drawGraph(totalLU, enFlow, cipheFlow) {
            const canvas = document.getElementById('flowGraph');
            if (!canvas) return;

            const ctx = canvas.getContext('2d');

            // ===== FIX BLUR HERE =====
            const rect = canvas.getBoundingClientRect();
            const dpr = window.devicePixelRatio || 1;

            // Set actual canvas resolution
            canvas.width = rect.width * dpr;
            canvas.height = 300 * dpr;

            // Keep visual height fixed
            canvas.style.height = "300px";

            // Scale context for retina
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

            const width = rect.width;
            const height = 300;

            // Clear canvas properly
            ctx.clearRect(0, 0, width, height);

            // Chart dimensions
            const margin = { top: 20, right: 20, bottom: 40, left: 60 };
            const chartWidth = width - margin.left - margin.right;
            const chartHeight = height - margin.top - margin.bottom;

            // Scales
            const maxLU = 400;
            const maxFlow = 6;

            const xScale = lu => margin.left + (lu / maxLU) * chartWidth;
            const yScale = flow => margin.top + chartHeight - (flow / maxFlow) * chartHeight;

            // Draw axes
            ctx.strokeStyle = '#ccc';
            ctx.lineWidth = 1;

            // X-axis
            ctx.beginPath();
            ctx.moveTo(margin.left, margin.top + chartHeight);
            ctx.lineTo(width - margin.right, margin.top + chartHeight);
            ctx.stroke();

            // Y-axis
            ctx.beginPath();
            ctx.moveTo(margin.left, margin.top);
            ctx.lineTo(margin.left, margin.top + chartHeight);
            ctx.stroke();

            // Grid lines
            ctx.strokeStyle = '#eee';
            ctx.setLineDash([5, 3]);

            // Horizontal grid lines (flow)
            for (let flow = 0; flow <= maxFlow; flow += 1) {
                const y = yScale(flow);
                ctx.beginPath();
                ctx.moveTo(margin.left, y);
                ctx.lineTo(width - margin.right, y);
                ctx.stroke();

                // Y-axis labels
                ctx.fillStyle = '#666';
                ctx.font = '12px Arial';
                ctx.textAlign = 'right';
                ctx.fillText(flow + ' L/S', margin.left - 10, y + 4);
            }

            // Vertical grid lines (LU)
            for (let lu = 0; lu <= maxLU; lu += 100) {
                const x = xScale(lu);
                ctx.beginPath();
                ctx.moveTo(x, margin.top);
                ctx.lineTo(x, margin.top + chartHeight);
                ctx.stroke();

                // X-axis labels
                ctx.fillStyle = '#666';
                ctx.font = '12px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(lu + ' LU', x, margin.top + chartHeight + 20);
            }

            ctx.setLineDash([]);

            // Draw curves
            function plotCurve(curve, color, label) {
                ctx.strokeStyle = color;
                ctx.lineWidth = 3;
                ctx.beginPath();

                for (let i = 0; i < curve.length; i++) {
                    const [lu, flow] = curve[i];
                    const x = xScale(lu);
                    const y = yScale(flow);

                    if (i === 0) {
                        ctx.moveTo(x, y);
                    } else {
                        ctx.lineTo(x, y);
                    }
                }
                ctx.stroke();

                // Add label
                const lastPoint = curve[curve.length - 1];
                ctx.fillStyle = color;
                ctx.font = 'bold 12px Arial';
                ctx.fillText(label, xScale(lastPoint[0]) + 10, yScale(lastPoint[1]));
            }

            // Show/hide EN806 curve based on frequency
            const frequency = document.getElementById('frequency').value;
            document.getElementById('enLegend').style.display = frequency === 'low' ? 'flex' : 'none';

            if (frequency === 'low') {
                plotCurve(EN806, '#0b5ed7', 'EN 806-3');
            }
            plotCurve(CIPHE, '#59b8df', 'CIPHE');

            // Plot current point
            if (totalLU > 0) {
                const flow = (frequency === 'low') ? enFlow : cipheFlow;
                const x = xScale(totalLU);
                const y = yScale(flow);

                // Draw vertical line
                ctx.strokeStyle = '#e53935';
                ctx.setLineDash([6, 4]);
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(x, margin.top);
                ctx.lineTo(x, margin.top + chartHeight);
                ctx.stroke();
                ctx.setLineDash([]);

                // Draw point
                ctx.fillStyle = '#e53935';
                ctx.beginPath();
                ctx.arc(x, y, 8, 0, Math.PI * 2);
                ctx.fill();

                // Add label
                ctx.fillStyle = '#e53935';
                ctx.font = 'bold 13px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(`${flow.toFixed(2)} L/S`, x, y - 15);
            }

            // Axis labels
            ctx.fillStyle = '#333';
            ctx.font = 'bold 14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Loading Units (LU)', width / 2, height - 10);

            ctx.save();
            ctx.translate(15, height / 2);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText('Flow Rate (L/Sec)', 0, 0);
            ctx.restore();
        }

        // ======================
        // 7. FILE UPLOAD HANDLING
        // ======================
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('pumpPhotos');
        const filePreview = document.getElementById('filePreview');
        const maxFileSize = 5 * 1024 * 1024; // 5MB
        const maxFiles = 5;

        let uploadedFiles = [];

        // Click to upload
        dropZone.addEventListener('click', () => fileInput.click());

        // Drag and drop
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');

            if (e.dataTransfer.files.length) {
                handleFiles(e.dataTransfer.files);
            }
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length) {
                handleFiles(e.target.files);
            }
        });

        function handleFiles(files) {
            for (let file of files) {
                if (uploadedFiles.length >= maxFiles) {
                    alert(`Maximum ${maxFiles} files allowed`);
                    break;
                }

                if (file.size > maxFileSize) {
                    alert(`File "${file.name}" exceeds 5MB limit`);
                    continue;
                }

                const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf',
                    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                if (!validTypes.includes(file.type)) {
                    alert(`File "${file.name}" must be an image, PDF, or Word document`);
                    continue;
                }

                uploadedFiles.push(file);
                updateFilePreview();
            }

            // Reset file input to allow uploading same file again
            fileInput.value = '';
        }

        function updateFilePreview() {
            filePreview.innerHTML = '';

            if (uploadedFiles.length === 0) {
                filePreview.innerHTML = '<p class="upload-hint">No files selected</p>';
                return;
            }

            uploadedFiles.forEach((file, index) => {
                const fileSize = (file.size / 1024 / 1024).toFixed(2);
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.innerHTML = `
                <span class="file-icon">${getFileIcon(file.type)}</span>
                <span class="file-name" title="${file.name}">${truncateFileName(file.name)}</span>
                <span class="file-size">(${fileSize} MB)</span>
                <span class="file-item-remove" onclick="removeFile(${index})">×</span>
            `;
                filePreview.appendChild(fileItem);
            });
        }

        function getFileIcon(type) {
            if (type.startsWith('image/')) return '🖼️';
            if (type === 'application/pdf') return '📄';
            if (type.includes('word')) return '📝';
            return '📎';
        }

        function truncateFileName(name) {
            if (name.length > 30) {
                return name.substring(0, 27) + '...';
            }
            return name;
        }

        function removeFile(index) {
            uploadedFiles.splice(index, 1);
            updateFilePreview();
        }

        // ======================
        // 8. FORM SUBMISSION
        // ======================
        async function submitEnquiry() {
            // Validate email
            const email = document.getElementById('userEmail').value.trim();
            if (!email || !validateEmail(email)) {
                showMessage('Please enter a valid email address', 'error');
                document.getElementById('userEmail').focus();
                return;
            }
            const propertyType = document.getElementById('propertyType').value;
const propertyLocation = document.getElementById('propertyLocation').value.trim();

if (!propertyType) {
    showMessage('Please select a property type', 'error');
    return;
}

if (!propertyLocation) {
    showMessage('Please enter the property location', 'error');
    return;
}


            // Get all data
            const phone = document.getElementById('userPhone').value.trim();
            const notes = document.getElementById('userNotes').value.trim();
            const frequency = document.getElementById('frequency').value;

            // Get fixture counts
            const fixtureData = [];
            for (let i = 0; i < fixtures.length; i++) {
                const count = document.getElementById('q' + i).value;
                if (count && parseInt(count) > 0) {
                    fixtureData.push(`${fixtures[i]}: ${count}`);
                }
            }

            // Prepare form data
            const formData = new FormData();
            formData.append('action', 'submit_booster_enquiry');
            formData.append('nonce', document.getElementById('boosterNonce').value);
            formData.append('property_type', propertyType);
            formData.append('property_location', propertyLocation);

            formData.append('email', email);
            formData.append('phone', phone);
            formData.append('notes', notes);
            formData.append('frequency', frequency);
            formData.append('total_lu', document.getElementById('totalLU').value);
            formData.append('ciphe_flow', document.getElementById('cipheFlow').value);
            formData.append('ciphe_storage', (parseFloat(document.getElementById('cipheFlow').value) * 900).toFixed(0));
            formData.append('static_lift', document.getElementById('staticLift').value);
            formData.append('pipe_loss', document.getElementById('pipeLoss').value);
            formData.append('outlet_pressure', document.getElementById('outletPressure').value);
            formData.append('total_head', document.getElementById('totalHead').value);

            if (frequency === 'low') {
                formData.append('en_flow', document.getElementById('enFlow').value);
                formData.append('en_storage', (parseFloat(document.getElementById('enFlow').value) * 900).toFixed(0));
            }

            fixtureData.forEach((fixture, index) => {
                formData.append('fixtures[]', fixture);
            });

            // Add files
            uploadedFiles.forEach((file, index) => {
                formData.append('photos[]', file, file.name);
            });

            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<span class="btn-icon">⏳</span> Submitting...';
            submitBtn.disabled = true;

            try {
                const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    // Show success message
                    showMessage(`
                    <h4>✓ Enquiry Submitted Successfully!</h4>
                    <p>Thank you, ${email.split('@')[0]}! Your enquiry has been sent to the NT Cloke engineering team.</p>

                    <p><strong>Reference:</strong> ${result.data.reference}</p>
                    <p><strong>What happens next:</strong></p>
                    <ul>
                        <li>Our team will review your requirements within 24 hours</li>
                        <li>We've sent a confirmation email to ${email} with your calculation details</li>
                        ${uploadedFiles.length > 0 ? '<li>Our engineers will assess your photos</li>' : ''}
                        <li>We'll contact you to discuss the best solution</li>
                    </ul>
                    <p><em>Remember: This is not an automated recommendation. All booster systems are individually engineered by our qualified team.</em></p>
                    <button class="btn btn-secondary" onclick="resetForm()">Submit Another Enquiry</button>
                `, 'success');

                    // Clear form
                    resetFormData();

                    // Scroll to message
                    document.getElementById('submissionResult').scrollIntoView({ behavior: 'smooth' });
                } else {
                    throw new Error(result.data || 'Submission failed');
                }
            } catch (error) {
                console.error('Submission error:', error);
                showMessage(`
                <h4>⚠️ Submission Error</h4>
                <p>Sorry, there was an error submitting your enquiry. Please try again.</p>
                <p><em>Error: ${error.message}</em></p>
                <p>If this persists, please contact us directly at <a href="mailto:enquiries@ntcloke.co.uk">enquiries@ntcloke.co.uk</a></p>
            `, 'error');
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        }

        function showMessage(content, type) {
            const resultDiv = document.getElementById('submissionResult');
            resultDiv.innerHTML = content;
            resultDiv.className = 'submission-result submission-' + type;
            resultDiv.style.display = 'block';
        }

        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        function resetFormData() {
            // Reset fixture counts
            for (let i = 0; i < fixtures.length; i++) {
                document.getElementById('q' + i).value = 0;
            }

            // Reset pressure fields
            document.getElementById('staticLift').value = 0;
            document.getElementById('pipeLoss').value = 0;
            document.getElementById('outletPressure').value = 10;
            updatePressure();

            // Reset contact form
            document.getElementById('userPhone').value = '';
            document.getElementById('userNotes').value = '';

            // Clear files
            uploadedFiles = [];
            updateFilePreview();

            // Hide results
            document.getElementById('calculationResults').style.display = 'none';
        }

        function resetForm() {
            resetFormData();
            document.getElementById('propertyType').value = '';
document.getElementById('propertyLocation').value = '';

            document.getElementById('submissionResult').style.display = 'none';
            document.getElementById('enquiryForm').scrollIntoView({ behavior: 'smooth' });
        }

        // ======================
        // 9. INITIALIZATION
        // ======================
        document.addEventListener('DOMContentLoaded', function () {
            // Initialize fixture grid
            updateFixtureValues();

            // Initialize graph
            setTimeout(() => {
                drawGraph(0, 0, 0);
            }, 100);

            // Update graph on window resize
            window.addEventListener('resize', function () {
                drawGraph(currentTotalLU, currentEnFlow, currentCipheFlow);
            });

            // Add result item styles
            const style = document.createElement('style');
            style.textContent = `
            .result-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 0;
                border-bottom: 1px solid #e1e8f0;
            }
            .result-item:last-child {
                border-bottom: none;
            }
            .result-label {
                color: #666;
                font-size: 14px;
            }
            .result-value {
                color: #1296CE;
                font-weight: bold;
                font-size: 16px;
            }
        `;
            document.head.appendChild(style);
        });
    </script>

    <?php
    return ob_get_clean();
}