<?php
/**
 * Uninstall handler.
 *
 * Runs ONLY when the plugin is deleted via WordPress → Plugins → Delete
 * (WordPress core guarantees this file is never loaded any other way — it
 * checks WP_UNINSTALL_PLUGIN itself before including this file).
 *
 * This file only removes the plugin's OWN operational tables/options — and
 * only if the site owner opted in via Settings → General → "Delete data on
 * uninstall". Posts, terms and media created or modified by imports are
 * never touched here under any circumstance.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'apm_settings', array() );

if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	// Default behaviour: leave everything in place, in case the plugin is
	// reinstalled later or the deletion was accidental.
	return;
}

require_once plugin_dir_path( __FILE__ ) . 'includes/class-apm-installer.php';
APM_Installer::drop_tables();

delete_option( 'apm_settings' );
delete_option( APM_Installer::DB_VERSION_OPTION );

// Clear APM's cron hook.
wp_clear_scheduled_hook( 'apm_daily_maintenance' );

// Remove the private temp-file directory (never contains anything but
// APM's own generated import/export files).
$upload_dir = wp_upload_dir();
$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
if ( is_dir( $tmp_dir ) ) {
	foreach ( glob( trailingslashit( $tmp_dir ) . '*' ) ?: array() as $file ) {
		if ( is_file( $file ) ) {
			@unlink( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
	@rmdir( $tmp_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
}

// Note: the `_apm_external_id` / `_apm_source_system` / `_apm_source_id`
// postmeta this plugin writes to posts is deliberately NOT deleted here —
// those live on the site's own post rows, and this file must never delete
// post data (including its meta).
