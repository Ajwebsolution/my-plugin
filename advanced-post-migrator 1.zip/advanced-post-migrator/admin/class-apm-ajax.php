<?php
/**
 * APM_Ajax
 *
 * All AJAX endpoints backing the admin UI. Every handler verifies the
 * nonce and the manage_apm/manage_options capability before doing
 * anything. Batch endpoints (process_import_batch / process_export_batch)
 * are what the wizard's progress bar polls — each call advances the job
 * by exactly one batch and returns progress, so a large import/export is
 * never handled in a single blocking request.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Ajax {

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	protected function __construct() {
		$actions = array(
			'apm_get_fields'           => 'get_fields',
			'apm_upload_file'          => 'upload_file',
			'apm_preview_import'       => 'preview_import',

			'apm_start_export_job'     => 'start_export_job',
			'apm_process_export_batch' => 'process_export_batch',

			'apm_start_import_job'     => 'start_import_job',
			'apm_process_import_batch' => 'process_import_batch',

			'apm_save_mapping'         => 'save_mapping',
			'apm_get_mapping'          => 'get_mapping',
			'apm_duplicate_mapping'    => 'duplicate_mapping',
			'apm_delete_mapping'       => 'delete_mapping',
			'apm_export_mapping'       => 'export_mapping',
			'apm_import_mapping'       => 'import_mapping',

			'apm_run_tool'             => 'run_tool',

			'apm_rollback_job'         => 'rollback_job',

			'apm_clear_logs'           => 'clear_logs',
			'apm_run_diagnostics'      => 'run_diagnostics',

			'apm_search_posts'         => 'search_posts',
			'apm_search_terms'         => 'search_terms',
		);
		foreach ( $actions as $action => $method ) {
			add_action( 'wp_ajax_' . $action, array( $this, $method ) );
		}

		// Not an AJAX action — a direct GET download endpoint. AJAX actions
		// return JSON, which can't stream a file for the browser to save;
		// admin-post.php is the standard WP way to serve an authenticated
		// file download. Registered here since this class already owns the
		// nonce/capability check pattern the rest of the plugin uses.
		add_action( 'admin_post_apm_download', array( $this, 'download_file' ) );
	}

	protected function verify_request() {
		check_ajax_referer( 'apm_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_apm' ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'advanced-post-migrator' ) ), 403 );
		}
	}

	/**
	 * Authenticated file download for export jobs (admin_post_apm_download).
	 *
	 * Export files live in wp-content/uploads/apm-tmp/, which is
	 * intentionally blocked from direct web access (.htaccess "Deny from
	 * all" — otherwise anyone who guesses/finds a filename could download
	 * a full export). This endpoint is the only sanctioned way to fetch
	 * one: it re-checks capability + nonce, resolves the real file path
	 * from the job row in the database (never trusts a path from the
	 * request), confirms the resolved path is still inside apm-tmp, and
	 * only then streams it. GET + admin-post.php (not admin-ajax.php)
	 * because a JSON AJAX response can't hand the browser a file to save.
	 */
	public function download_file() {
		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'apm_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed. Please go back and try downloading again.', 'advanced-post-migrator' ), '', array( 'response' => 403 ) );
		}
		if ( ! current_user_can( 'manage_apm' ) && ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'advanced-post-migrator' ), '', array( 'response' => 403 ) );
		}

		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : 'export';
		$job_id = isset( $_GET['job_id'] ) ? absint( $_GET['job_id'] ) : 0;

		if ( 'tool' === $type ) {
			// Tools-generated files (currently: the sample export) aren't
			// tied to a job row — only a basename is trusted from the
			// request, reconstructed against the fixed tmp directory so a
			// path-traversal attempt (../../wp-config.php etc.) can't
			// escape it, and required to match the plugin's own naming
			// prefix as a second check.
			$upload_dir = wp_upload_dir();
			$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp/';
			$basename   = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
			$file_path  = $tmp_dir . basename( $basename );

			if ( ! $basename || 0 !== strpos( $basename, 'apm-' ) || ! file_exists( $file_path ) ) {
				wp_die( esc_html__( 'File not found or no longer available.', 'advanced-post-migrator' ), '', array( 'response' => 404 ) );
			}

			$this->stream_file( $file_path, $basename );
		}

		$job = 'import' === $type ? APM_Jobs::get_import_job( $job_id ) : APM_Jobs::get_export_job( $job_id );
		if ( ! $job || empty( $job['file_path'] ) ) {
			wp_die( esc_html__( 'File not found for this job.', 'advanced-post-migrator' ), '', array( 'response' => 404 ) );
		}

		$file_path  = $job['file_path'];
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp/';

		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) || ! file_exists( $file_path ) ) {
			wp_die( esc_html__( 'File not found or no longer available (temporary export/import files are cleaned up automatically after 48 hours — export again if needed).', 'advanced-post-migrator' ), '', array( 'response' => 404 ) );
		}

		$actual_ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		$this->stream_file( $file_path, 'apm-' . $type . '-' . $job_id . '.' . $actual_ext );
	}

	/**
	 * Send the right headers and stream a file to the browser, then exit.
	 * Shared by both branches of download_file().
	 */
	protected function stream_file( $file_path, $download_name ) {
		$ext          = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		$content_type = array( 'json' => 'application/json', 'csv' => 'text/csv', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );

		nocache_headers();
		header( 'Content-Type: ' . ( $content_type[ $ext ] ?? 'application/octet-stream' ) );
		header( 'Content-Disposition: attachment; filename="' . $download_name . '"' );
		header( 'Content-Length: ' . filesize( $file_path ) );

		// A large export can be tens of MB; stream it rather than loading
		// the whole file into PHP memory with file_get_contents().
		$fh = fopen( $file_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( $fh ) {
			fpassthru( $fh );
			fclose( $fh );
		}
		exit;
	}

	/* ------------------------- Field discovery ------------------------- */

	public function get_fields() {
		$this->verify_request();

		$entity    = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'post';
		$post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post';

		if ( 'taxonomies' === $entity ) {
			wp_send_json_success(
				array(
					'core'        => APM_Field_Registry::get_taxonomy_fields(),
					'acf'         => array(),
					'acf_active'  => false,
					'yoast'       => array(),
					'yoast_active'=> false,
					'custom_meta' => array(),
					'taxonomies'  => APM_Tools::scan_taxonomies( $post_type ),
				)
			);
		}

		wp_send_json_success(
			array(
				'core'         => APM_Field_Registry::get_core_fields(),
				'acf'          => APM_ACF_Handler::is_active() ? APM_Field_Registry::get_acf_fields( $post_type ) : array(),
				'acf_active'   => APM_ACF_Handler::is_active(),
				'yoast'        => APM_Yoast_Handler::is_active() ? array_keys( APM_Field_Registry::get_yoast_field_map() ) : array(),
				'yoast_active' => APM_Yoast_Handler::is_active(),
				'custom_meta'  => APM_Field_Registry::discover_custom_meta_keys( 100, $post_type ),
				'taxonomies'   => APM_Tools::scan_taxonomies( $post_type ),
				'post_types'   => APM_Tools::scan_post_types(),
			)
		);
	}

	/* ------------------------- Export (batch job) ------------------------- */

	public function start_export_job() {
		$this->verify_request();

		$entity = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'post';

		if ( 'taxonomies' === $entity ) {
			$args = array(
				'format'        => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
				'post_type'     => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : '',
				'taxonomies'    => $this->texts( $_POST['taxonomies'] ?? array() ),
				'search'        => isset( $_POST['term_search'] ) ? sanitize_text_field( wp_unslash( $_POST['term_search'] ) ) : '',
				'include_empty' => empty( $_POST['hide_empty'] ),
				'limit'         => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
				'offset'        => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
				'batch_size'    => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) APM_Settings::get( 'batch_size', 50 ),
			);
			$exporter = new APM_Taxonomy_Exporter();
			$job_id   = $exporter->start_job( $args );
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		$field_config = json_decode( wp_unslash( $_POST['field_config'] ?? '{}' ), true ); // phpcs:ignore
		$field_config = is_array( $field_config ) ? $field_config : array();

		$args = array(
			'format'     => isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json',
			'post_type'  => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post',
			'selection'  => isset( $_POST['selection'] ) ? sanitize_key( wp_unslash( $_POST['selection'] ) ) : 'all',
			'post_ids'   => $this->ints( $_POST['post_ids'] ?? array() ),
			'slugs'      => $this->texts( $_POST['slugs'] ?? array() ),
			'taxonomy'   => isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '',
			'terms'      => $this->texts( $_POST['terms'] ?? array() ),
			'status'     => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'any',
			'batch_size' => isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) APM_Settings::get( 'batch_size', 50 ),
			'meta_rules' => array( 'mode' => 'export_all' ),
			'field_config' => $field_config,
			'limit'         => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0,
			'offset'        => isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0,
			'title_search'  => $this->texts( $_POST['title_search'] ?? array() ),
			'exclude_titles'=> $this->texts( $_POST['exclude_titles'] ?? array() ),
			'exclude_ids'   => $this->ints( $_POST['exclude_ids'] ?? array() ),
			'date_created_after'  => isset( $_POST['date_created_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_after'] ) ) : '',
			'date_created_before' => isset( $_POST['date_created_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_created_before'] ) ) : '',
			'date_modified_after' => isset( $_POST['date_modified_after'] ) ? sanitize_text_field( wp_unslash( $_POST['date_modified_after'] ) ) : '',
			'date_modified_before'=> isset( $_POST['date_modified_before'] ) ? sanitize_text_field( wp_unslash( $_POST['date_modified_before'] ) ) : '',
		);

		$exporter = new APM_Post_Exporter();
		$job_id   = $exporter->start_job( $args );

		is_wp_error( $job_id )
			? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) )
			: wp_send_json_success( array( 'job_id' => $job_id ) );
	}

	public function process_export_batch() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );

		// The job row itself (not the request) is the source of truth for
		// which entity this job is — the browser just keeps polling the
		// same job_id every tick, so the entity has to be resolvable from
		// the DB alone.
		$job      = APM_Jobs::get_export_job( $job_id );
		$entity   = $job['entity_type'] ?? 'post';
		$exporter = 'taxonomies' === $entity ? new APM_Taxonomy_Exporter() : new APM_Post_Exporter();

		$result = $exporter->process_next_batch( $job_id );

		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( $result );
	}

	/* ------------------------- Import (upload + batch job) ------------------------- */

	public function upload_file() {
		$this->verify_request();

		if ( empty( $_FILES['file'] ) || ! isset( $_FILES['file']['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'advanced-post-migrator' ) ) );
		}

		$file = $_FILES['file']; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$ext  = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		$allowed_exts = array( 'csv', 'json' );
		if ( APM_XLSX_Handler::is_available() ) {
			$allowed_exts[] = 'xlsx';
		}
		if ( ! in_array( $ext, $allowed_exts, true ) ) {
			wp_send_json_error(
				array(
					'message' => APM_XLSX_Handler::is_available()
						? __( 'Only .csv, .json and .xlsx files are supported.', 'advanced-post-migrator' )
						: __( 'Only .csv and .json files are supported (.xlsx needs the ZipArchive PHP extension, which isn\'t available on this server).', 'advanced-post-migrator' ),
				)
			);
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );
		$dest = trailingslashit( $tmp_dir ) . 'apm-import-' . wp_generate_password( 8, false ) . '.' . $ext;

		if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			wp_send_json_error( array( 'message' => __( 'Could not store uploaded file.', 'advanced-post-migrator' ) ) );
		}

		$header = $this->read_header_for_format( $ext, $dest );
		if ( is_wp_error( $header ) ) {
			wp_send_json_error( array( 'message' => $header->get_error_message() ) );
		}

		wp_send_json_success( array( 'file_path' => $dest, 'format' => $ext, 'header' => $header ) );
	}

	protected function read_header_for_format( $format, $file_path ) {
		if ( 'csv' === $format ) {
			return APM_CSV_Handler::read_header( $file_path );
		}
		if ( 'xlsx' === $format ) {
			return APM_XLSX_Handler::read_header( $file_path );
		}
		return array(); // JSON is self-describing — no header/mapping step needed.
	}

	/**
	 * Read-only preview: maps the first N rows and reports create/update/
	 * skip verdicts and key fields, without writing anything.
	 */
	public function preview_import() {
		$this->verify_request();

		$entity    = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'post';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$format    = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json';

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp/';
		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file path.', 'advanced-post-migrator' ) ) );
		}

		$mapping = json_decode( wp_unslash( $_POST['mapping'] ?? '{}' ), true ); // phpcs:ignore
		$mapping = is_array( $mapping ) ? $mapping : array();

		$transforms = json_decode( wp_unslash( $_POST['transforms'] ?? '{}' ), true ); // phpcs:ignore
		$transforms = is_array( $transforms ) ? $transforms : array();

		if ( 'taxonomies' === $entity ) {
			$preview_args = array(
				'file_path'        => $file_path,
				'format'           => $format,
				'mapping'          => $mapping,
				'match_strategy'   => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'slug',
				'default_taxonomy' => isset( $_POST['default_taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['default_taxonomy'] ) ) : 'category',
			);
			$importer = new APM_Taxonomy_Importer();
			$rows = $importer->preview_rows( $preview_args, 20 );
			is_wp_error( $rows ) ? wp_send_json_error( array( 'message' => $rows->get_error_message() ) ) : wp_send_json_success( array( 'rows' => $rows ) );
		}

		$preview_args = array(
			'file_path'      => $file_path,
			'format'         => $format,
			'post_type'      => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post',
			'mapping'        => $mapping,
			'transforms'     => $transforms,
			'match_strategy' => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'slug',
		);

		$importer = new APM_Post_Importer();
		$rows     = $importer->preview_rows( $preview_args, 20 );

		is_wp_error( $rows ) ? wp_send_json_error( array( 'message' => $rows->get_error_message() ) ) : wp_send_json_success( array( 'rows' => $rows ) );
	}

	public function start_import_job() {
		$this->verify_request();

		$entity    = isset( $_POST['entity'] ) ? sanitize_key( wp_unslash( $_POST['entity'] ) ) : 'post';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$format    = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'json';

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp/';
		if ( 0 !== strpos( wp_normalize_path( $file_path ), wp_normalize_path( $tmp_dir ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file path.', 'advanced-post-migrator' ) ) );
		}

		$mapping = json_decode( wp_unslash( $_POST['mapping'] ?? '{}' ), true ); // phpcs:ignore
		$mapping = is_array( $mapping ) ? $mapping : array();

		$transforms = json_decode( wp_unslash( $_POST['transforms'] ?? '{}' ), true ); // phpcs:ignore
		$transforms = is_array( $transforms ) ? $transforms : array();

		$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : (int) APM_Settings::get( 'batch_size', 50 );
		$dry_run    = ! empty( $_POST['dry_run'] );

		if ( 'taxonomies' === $entity ) {
			$importer = new APM_Taxonomy_Importer();
			$job_id   = $importer->start_job(
				array(
					'file_path'               => $file_path,
					'format'                  => $format,
					'mapping'                 => $mapping,
					'match_strategy'          => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'slug',
					'existing_action'         => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'update',
					'default_taxonomy'        => isset( $_POST['default_taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['default_taxonomy'] ) ) : 'category',
					'create_missing_parents'  => ! empty( $_POST['create_missing_parents'] ),
					'batch_size'              => $batch_size,
					'dry_run'                 => $dry_run,
				)
			);
			is_wp_error( $job_id ) ? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) ) : wp_send_json_success( array( 'job_id' => $job_id ) );
		}

		$importer = new APM_Post_Importer();
		$job_id   = $importer->start_job(
			array(
				'file_path'       => $file_path,
				'format'          => $format,
				'post_type'       => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post',
				'mapping'         => $mapping,
				'transforms'      => $transforms,
				'match_strategy'  => isset( $_POST['match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['match_strategy'] ) ) : 'slug',
				'existing_action' => isset( $_POST['existing_action'] ) ? sanitize_key( wp_unslash( $_POST['existing_action'] ) ) : 'update',
				'options'         => array(
					'create_missing_taxonomy_terms' => ! empty( $_POST['create_missing_taxonomy_terms'] ),
					'image_match_strategy'          => isset( $_POST['image_match_strategy'] ) ? sanitize_key( wp_unslash( $_POST['image_match_strategy'] ) ) : 'url_filename_fallback',
					'create_backup'                 => ! empty( $_POST['create_backup'] ),
				),
				'batch_size'      => $batch_size,
				'dry_run'         => $dry_run,
				'mapping_profile_id' => isset( $_POST['mapping_profile_id'] ) ? absint( $_POST['mapping_profile_id'] ) : null,
			)
		);

		is_wp_error( $job_id )
			? wp_send_json_error( array( 'message' => $job_id->get_error_message() ) )
			: wp_send_json_success( array( 'job_id' => $job_id ) );
	}

	public function process_import_batch() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );

		$job      = APM_Jobs::get_import_job( $job_id );
		$entity   = $job['entity_type'] ?? 'post';
		$importer = 'taxonomies' === $entity ? new APM_Taxonomy_Importer() : new APM_Post_Importer();

		$result = $importer->process_next_batch( $job_id );

		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( $result );
	}

	/* ------------------------- Mappings ------------------------- */

	public function save_mapping() {
		$this->verify_request();
		$id     = absint( $_POST['id'] ?? 0 );
		$name   = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$type   = sanitize_key( wp_unslash( $_POST['type'] ?? 'import' ) );
		$config = json_decode( wp_unslash( $_POST['config'] ?? '{}' ), true ); // phpcs:ignore
		$config = is_array( $config ) ? $config : array();

		if ( ! $name ) {
			wp_send_json_error( array( 'message' => __( 'Name is required.', 'advanced-post-migrator' ) ) );
		}

		$id = $id ? ( APM_Mappings::update( $id, $name, $config ) ?: $id ) : APM_Mappings::create( $name, $type, $config );
		wp_send_json_success( array( 'id' => $id ) );
	}

	public function get_mapping() {
		$this->verify_request();
		$row = APM_Mappings::get( absint( $_POST['id'] ?? 0 ) );
		$row ? wp_send_json_success( $row ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-post-migrator' ) ) );
	}

	public function duplicate_mapping() {
		$this->verify_request();
		$id       = absint( $_POST['id'] ?? 0 );
		$new_name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ) ?: __( 'Copy', 'advanced-post-migrator' );
		$new_id   = APM_Mappings::duplicate( $id, $new_name );
		$new_id ? wp_send_json_success( array( 'id' => $new_id ) ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-post-migrator' ) ) );
	}

	public function delete_mapping() {
		$this->verify_request();
		APM_Mappings::delete( absint( $_POST['id'] ?? 0 ) );
		wp_send_json_success();
	}

	public function export_mapping() {
		$this->verify_request();
		$json = APM_Mappings::export_json( absint( $_POST['id'] ?? 0 ) );
		$json ? wp_send_json_success( array( 'json' => $json ) ) : wp_send_json_error( array( 'message' => __( 'Not found.', 'advanced-post-migrator' ) ) );
	}

	public function import_mapping() {
		$this->verify_request();
		$json = wp_unslash( $_POST['json'] ?? '' ); // phpcs:ignore
		$id   = APM_Mappings::import_json( $json );
		is_wp_error( $id ) ? wp_send_json_error( array( 'message' => $id->get_error_message() ) ) : wp_send_json_success( array( 'id' => $id ) );
	}

	/* ------------------------- Tools ------------------------- */

	public function run_tool() {
		$this->verify_request();
		$tool      = sanitize_key( wp_unslash( $_POST['tool'] ?? '' ) );
		$post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post';

		$allowed = array(
			'scan_post_meta', 'scan_acf_fields', 'scan_taxonomies', 'scan_post_types',
			'find_duplicate_slugs', 'validate_post_data',
			'clear_temp_files', 'rebuild_relationship_map', 'generate_sample_export',
		);
		if ( ! in_array( $tool, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown tool.', 'advanced-post-migrator' ) ) );
		}

		$needs_post_type = in_array( $tool, array( 'scan_post_meta', 'scan_acf_fields', 'scan_taxonomies', 'find_duplicate_slugs', 'validate_post_data' ), true );
		$result = $needs_post_type ? call_user_func( array( 'APM_Tools', $tool ), $post_type ) : call_user_func( array( 'APM_Tools', $tool ) );

		is_wp_error( $result ) ? wp_send_json_error( array( 'message' => $result->get_error_message() ) ) : wp_send_json_success( array( 'result' => $result ) );
	}

	/* ------------------------- Rollback ------------------------- */

	public function rollback_job() {
		$this->verify_request();
		$job_id = absint( $_POST['job_id'] ?? 0 );
		if ( ! APM_Settings::get( 'enable_rollback', true ) ) {
			wp_send_json_error( array( 'message' => __( 'Rollback is disabled in Settings.', 'advanced-post-migrator' ) ) );
		}
		wp_send_json_success( APM_Snapshot::rollback_job( $job_id ) );
	}

	/* ------------------------- Logs / diagnostics ------------------------- */

	public function clear_logs() {
		$this->verify_request();
		APM_Logger::clear_all();
		wp_send_json_success();
	}

	public function run_diagnostics() {
		$this->verify_request();
		$post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post';
		$issues    = APM_Tools::validate_post_data( $post_type, 200 );
		wp_send_json_success( array( 'report' => APM_System_Status::get_report(), 'sample_validation_issues' => count( $issues ) ) );
	}

	/* ------------------------- Autocomplete lookups ------------------------- */

	/**
	 * apm_search_posts — q (ID, slug or title words), post_type, limit (<= 20).
	 * Passing `ids` (comma/newline list of IDs or slugs) instead bulk-resolves
	 * exact matches and reports the tokens that didn't match.
	 */
	public function search_posts() {
		$this->verify_request();
		wp_send_json_success( self::search_posts_response( wp_unslash( $_POST ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/** Request -> response shaping for search_posts(), testable without the JSON exit. */
	public static function search_posts_response( $req ) {
		$post_type = isset( $req['post_type'] ) ? sanitize_key( $req['post_type'] ) : 'post';
		if ( ! post_type_exists( $post_type ) ) {
			return array( 'items' => array(), 'unresolved' => array() );
		}
		if ( isset( $req['ids'] ) && '' !== $req['ids'] ) {
			$tokens = APM_Search::split_tokens( is_array( $req['ids'] ) ? array_map( 'sanitize_text_field', $req['ids'] ) : sanitize_textarea_field( $req['ids'] ) );
			return APM_Search::resolve_posts( $tokens, $post_type );
		}
		$q = isset( $req['q'] ) ? sanitize_text_field( $req['q'] ) : '';
		return array( 'items' => APM_Search::search_posts( $q, $post_type, isset( $req['limit'] ) ? absint( $req['limit'] ) : 10 ), 'unresolved' => array() );
	}

	/**
	 * apm_search_terms — q, taxonomy (or post_type = all of its taxonomies),
	 * limit. `ids` bulk-resolves term IDs / slugs / "taxonomy:id".
	 */
	public function search_terms() {
		$this->verify_request();
		wp_send_json_success( self::search_terms_response( wp_unslash( $_POST ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	public static function search_terms_response( $req ) {
		$taxonomy   = isset( $req['taxonomy'] ) ? sanitize_key( $req['taxonomy'] ) : '';
		$post_type  = isset( $req['post_type'] ) ? sanitize_key( $req['post_type'] ) : '';
		$taxonomies = APM_Search::scope_taxonomies( $taxonomy, $post_type );
		if ( isset( $req['ids'] ) && '' !== $req['ids'] ) {
			$tokens = APM_Search::split_tokens( is_array( $req['ids'] ) ? array_map( 'sanitize_text_field', $req['ids'] ) : sanitize_textarea_field( $req['ids'] ) );
			return APM_Search::resolve_terms( $tokens, $taxonomies );
		}
		$q = isset( $req['q'] ) ? sanitize_text_field( $req['q'] ) : '';
		return array( 'items' => APM_Search::search_terms( $q, $taxonomies, isset( $req['limit'] ) ? absint( $req['limit'] ) : 10 ), 'unresolved' => array() );
	}

	/* ------------------------- Helpers ------------------------- */

	protected function ints( $arr ) {
		return array_map( 'absint', (array) $arr );
	}

	protected function texts( $arr ) {
		return array_map( 'sanitize_text_field', (array) wp_unslash( $arr ) );
	}
}
