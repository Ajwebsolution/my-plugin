<?php
/**
 * APM_Settings
 *
 * Registers the single `apm_settings` option via WordPress's Settings API
 * (so nonce/capability/sanitization all run through core, not a custom
 * form handler) and sanitizes every field. Every setting here is actually
 * read somewhere in the plugin — nothing is a UI-only toggle.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Settings {

	const OPTION = 'apm_settings';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function register() {
		register_setting( self::OPTION, self::OPTION, array( __CLASS__, 'sanitize' ) );
	}

	/**
	 * @param array $input Raw $_POST['apm_settings'].
	 * @return array Sanitized settings, merged over existing values so a
	 *               partial submit (one tab's fields) never clobbers other
	 *               tabs' settings.
	 */
	public static function sanitize( $input ) {
		$existing = get_option( self::OPTION, array() );
		$input    = is_array( $input ) ? $input : array();

		$bool_fields = array(
			'create_missing_taxonomy_terms', 'logging_enabled',
			'create_backup_before_update', 'enable_rollback',
			'download_remote_images', 'update_existing_acf', 'update_existing_yoast', 'preserve_empty_values',
			'delete_data_on_uninstall',
		);
		foreach ( $bool_fields as $field ) {
			if ( array_key_exists( $field, $input ) ) {
				$existing[ $field ] = ! empty( $input[ $field ] );
			}
		}

		$text_fields = array( 'default_post_type', 'default_match_strategy', 'image_match_strategy', 'export_filename_pattern', 'csv_delimiter' );
		foreach ( $text_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$existing[ $field ] = sanitize_text_field( $input[ $field ] );
			}
		}

		$int_fields = array( 'batch_size', 'log_retention_days', 'snapshot_retention_days' );
		foreach ( $int_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$existing[ $field ] = max( 1, (int) $input[ $field ] );
			}
		}

		return $existing;
	}

	public static function get( $key, $default = null ) {
		$settings = get_option( self::OPTION, array() );
		return $settings[ $key ] ?? $default;
	}
}
