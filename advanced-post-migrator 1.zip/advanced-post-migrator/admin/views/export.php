<?php
/**
 * Export wizard. Step content for steps 1-3 and 5 is rendered here; Step 4
 * (field selection) is populated by JS from the same apm_get_fields
 * catalog the Import mapping screen uses, so both stay in sync with
 * whatever ACF/Yoast/custom-meta actually exists on this site for the
 * selected post type.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$export_profiles = APM_Mappings::all( 'export' );
$post_types       = get_post_types( array( 'public' => true ), 'objects' );
?>
<div id="apm-export-app" class="apm-panel">

	<div class="apm-wizard-steps">
		<div class="apm-wizard-step active" data-step="1"><span class="apm-step-num">1</span><?php esc_html_e( 'Select Data', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="2"><span class="apm-step-num">2</span><?php esc_html_e( 'Export Method', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="3"><span class="apm-step-num">3</span><?php esc_html_e( 'Filter Data', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="4"><span class="apm-step-num">4</span><?php esc_html_e( 'Field Mapping', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="5"><span class="apm-step-num">5</span><?php esc_html_e( 'Advanced Options', 'advanced-post-migrator' ); ?></div>
	</div>

	<?php if ( $export_profiles ) : ?>
	<p class="apm-profile-bar">
		<label for="apm-export-load-profile"><span class="dashicons dashicons-portfolio" aria-hidden="true"></span> <?php esc_html_e( 'Saved export profile', 'advanced-post-migrator' ); ?></label>
		<select id="apm-export-load-profile">
			<option value=""><?php esc_html_e( '— New export —', 'advanced-post-migrator' ); ?></option>
			<?php foreach ( $export_profiles as $p ) : ?>
				<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php endif; ?>

	<!-- STEP 1: Select data type -->
	<div class="apm-wizard-pane active" data-pane="1">
		<h2><?php esc_html_e( 'What do you want to export?', 'advanced-post-migrator' ); ?></h2>
		<div class="apm-card-grid">
			<div class="apm-card selected" data-value="post">
				<span class="dashicons dashicons-admin-post"></span>
				<span class="apm-card-title"><?php esc_html_e( 'Posts', 'advanced-post-migrator' ); ?></span>
				<span class="apm-card-desc"><?php esc_html_e( 'Posts (or any selected post type), with ACF, Yoast, taxonomies, featured image and custom meta', 'advanced-post-migrator' ); ?></span>
			</div>
			<div class="apm-card" data-value="taxonomies">
				<span class="dashicons dashicons-category"></span>
				<span class="apm-card-title"><?php esc_html_e( 'Categories, Tags & Taxonomies', 'advanced-post-migrator' ); ?></span>
				<span class="apm-card-desc"><?php esc_html_e( 'Standalone taxonomy export, independent of any post', 'advanced-post-migrator' ); ?></span>
			</div>
		</div>

		<table class="form-table" role="presentation" id="apm-export-post-type-row">
			<tr><th scope="row"><label for="apm-export-post-type"><?php esc_html_e( 'Post type', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-export-post-type">
					<?php foreach ( $post_types as $pt ) : ?>
						<option value="<?php echo esc_attr( $pt->name ); ?>" <?php selected( $pt->name, 'post' ); ?>><?php echo esc_html( $pt->labels->name ); ?> (<?php echo esc_html( $pt->name ); ?>)</option>
					<?php endforeach; ?>
				</select>
				<p class="description"><?php esc_html_e( 'Any public post type can be exported — defaults to "post".', 'advanced-post-migrator' ); ?></p>
			</td></tr>
		</table>
	</div>

	<!-- STEP 2: Export method -->
	<div class="apm-wizard-pane" data-pane="2">
		<h2><?php esc_html_e( 'Choose an export format', 'advanced-post-migrator' ); ?></h2>
		<div class="apm-card-grid">
			<div class="apm-card selected" data-format="json">
				<span class="dashicons dashicons-media-code"></span>
				<span class="apm-card-title">JSON</span>
				<span class="apm-card-desc"><?php esc_html_e( 'Recommended — fully lossless, including ACF repeaters & flexible content', 'advanced-post-migrator' ); ?></span>
			</div>
			<div class="apm-card" data-format="csv">
				<span class="dashicons dashicons-media-spreadsheet"></span>
				<span class="apm-card-title">CSV</span>
				<span class="apm-card-desc"><?php esc_html_e( 'Spreadsheet-friendly — one column per field, editable in Excel/Sheets', 'advanced-post-migrator' ); ?></span>
			</div>
			<div class="apm-card" data-format="xlsx">
				<span class="dashicons dashicons-media-spreadsheet"></span>
				<span class="apm-card-title">XLSX</span>
				<span class="apm-card-desc"><?php echo APM_XLSX_Handler::is_available() ? esc_html__( 'Native Excel format — opens directly in Excel/Sheets without conversion', 'advanced-post-migrator' ) : esc_html__( 'Requires the ZipArchive PHP extension, which is not available on this server — will export as CSV instead', 'advanced-post-migrator' ); ?></span>
			</div>
		</div>
		<input type="hidden" id="apm-export-format" value="json">
	</div>

	<!-- STEP 3: Filter data -->
	<div class="apm-wizard-pane" data-pane="3">
		<h2><?php esc_html_e( 'Filter which records to export', 'advanced-post-migrator' ); ?></h2>
		<div class="apm-filter-pane" data-filter-entity="post">
		<table class="form-table" role="presentation">
			<tr><th scope="row"><label for="apm-export-limit"><?php esc_html_e( 'Total number of posts to export', 'advanced-post-migrator' ); ?></label></th><td>
				<input type="number" min="0" id="apm-export-limit" class="small-text" placeholder="<?php esc_attr_e( 'Unlimited', 'advanced-post-migrator' ); ?>">
				<p class="description"><?php esc_html_e( 'Leave blank to export all matching posts.', 'advanced-post-migrator' ); ?></p>
			</td></tr>
			<tr><th scope="row"><label for="apm-export-offset"><?php esc_html_e( 'Skip first N posts', 'advanced-post-migrator' ); ?></label></th><td>
				<input type="number" min="0" id="apm-export-offset" class="small-text" value="0">
			</td></tr>
			<tr><th scope="row"><label for="apm-export-selection"><?php esc_html_e( 'Which posts?', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-export-selection">
					<option value="all"><?php esc_html_e( 'All posts', 'advanced-post-migrator' ); ?></option>
					<option value="ids"><?php esc_html_e( 'Specific posts (by ID)', 'advanced-post-migrator' ); ?></option>
					<option value="slugs"><?php esc_html_e( 'Specific posts (by slug)', 'advanced-post-migrator' ); ?></option>
					<option value="taxonomy"><?php esc_html_e( 'By taxonomy term', 'advanced-post-migrator' ); ?></option>
				</select>

				<div class="apm-selection-sub" data-selection="ids" hidden>
					<div class="apm-ac" data-source="posts" data-value="id" data-scope-post-type="#apm-export-post-type" data-label="<?php esc_attr_e( 'Posts to export', 'advanced-post-migrator' ); ?>" data-placeholder="<?php esc_attr_e( 'Search by title, slug or ID — or paste a list of IDs', 'advanced-post-migrator' ); ?>">
						<input type="hidden" class="apm-ac-value" id="apm-export-ids" value="">
					</div>
					<p class="description"><?php esc_html_e( 'Exports exactly these posts. Pasting comma- or newline-separated IDs/slugs resolves them all at once.', 'advanced-post-migrator' ); ?></p>
				</div>

				<div class="apm-selection-sub" data-selection="slugs" hidden>
					<div class="apm-ac" data-source="posts" data-value="slug" data-scope-post-type="#apm-export-post-type" data-label="<?php esc_attr_e( 'Posts to export', 'advanced-post-migrator' ); ?>" data-placeholder="<?php esc_attr_e( 'Search by title or slug — or paste a list of slugs', 'advanced-post-migrator' ); ?>">
						<input type="hidden" class="apm-ac-value" id="apm-export-slugs" value="">
					</div>
					<p class="description"><?php esc_html_e( 'Matched by slug on export, so the same list also works on another site.', 'advanced-post-migrator' ); ?></p>
				</div>

				<div class="apm-selection-sub" data-selection="taxonomy" hidden>
					<div class="apm-inline-fields">
						<label class="apm-mini-label" for="apm-export-selection-taxonomy"><?php esc_html_e( 'Taxonomy', 'advanced-post-migrator' ); ?></label>
						<select id="apm-export-selection-taxonomy" class="apm-taxonomy-select" data-scope-post-type="#apm-export-post-type"></select>
					</div>
					<div class="apm-ac" data-source="terms" data-value="term_id" data-scope-post-type="#apm-export-post-type" data-scope-taxonomy="#apm-export-selection-taxonomy" data-label="<?php esc_attr_e( 'Terms', 'advanced-post-migrator' ); ?>" data-placeholder="<?php esc_attr_e( 'Search terms by name, slug or ID', 'advanced-post-migrator' ); ?>">
						<input type="hidden" class="apm-ac-value" id="apm-export-terms" value="">
					</div>
					<p class="description"><?php esc_html_e( 'Exports posts assigned to any of these terms.', 'advanced-post-migrator' ); ?></p>
				</div>
				<p class="apm-field-error" id="apm-export-selection-error" role="alert" hidden></p>
			</td></tr>
			<tr><th scope="row"><label for="apm-export-title-search-ac"><?php esc_html_e( 'Only posts matching', 'advanced-post-migrator' ); ?></label></th><td>
				<div class="apm-ac" data-source="posts" data-value="title" data-free-text="1" data-input-id="apm-export-title-search-ac" data-scope-post-type="#apm-export-post-type" data-placeholder="<?php esc_attr_e( 'Type a title keyword and press Enter, or pick a post', 'advanced-post-migrator' ); ?>">
					<input type="hidden" class="apm-ac-value" id="apm-export-title-search" value="">
				</div>
				<p class="description"><?php esc_html_e( 'Title search keywords — narrows the selection above to posts whose title/content matches any of them.', 'advanced-post-migrator' ); ?></p>
			</td></tr>
			<tr><th scope="row"><label for="apm-export-exclude-titles-ac"><?php esc_html_e( 'Exclude posts matching', 'advanced-post-migrator' ); ?></label></th><td>
				<div class="apm-ac" data-source="posts" data-value="title" data-free-text="1" data-input-id="apm-export-exclude-titles-ac" data-scope-post-type="#apm-export-post-type" data-placeholder="<?php esc_attr_e( 'Title keywords to leave out', 'advanced-post-migrator' ); ?>">
					<input type="hidden" class="apm-ac-value" id="apm-export-exclude-titles" value="">
				</div>
			</td></tr>
			<tr><th scope="row"><label for="apm-export-exclude-ids-ac"><?php esc_html_e( 'Exclude specific posts', 'advanced-post-migrator' ); ?></label></th><td>
				<div class="apm-ac" data-source="posts" data-value="id" data-input-id="apm-export-exclude-ids-ac" data-scope-post-type="#apm-export-post-type" data-placeholder="<?php esc_attr_e( 'Search by title, slug or ID', 'advanced-post-migrator' ); ?>">
					<input type="hidden" class="apm-ac-value" id="apm-export-exclude-ids" value="">
				</div>
			</td></tr>
			<tr><th scope="row"><label for="apm-export-status"><?php esc_html_e( 'Post status', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-export-status">
					<option value="any"><?php esc_html_e( 'Any', 'advanced-post-migrator' ); ?></option>
					<option value="publish"><?php esc_html_e( 'Published', 'advanced-post-migrator' ); ?></option>
					<option value="draft"><?php esc_html_e( 'Draft', 'advanced-post-migrator' ); ?></option>
					<option value="pending"><?php esc_html_e( 'Pending', 'advanced-post-migrator' ); ?></option>
					<option value="private"><?php esc_html_e( 'Private', 'advanced-post-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Date created', 'advanced-post-migrator' ); ?></th><td>
				<input type="date" id="apm-export-created-after"> <?php esc_html_e( 'to', 'advanced-post-migrator' ); ?> <input type="date" id="apm-export-created-before">
				<p class="description"><?php esc_html_e( 'Leave both blank for no date filter.', 'advanced-post-migrator' ); ?></p>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Date modified', 'advanced-post-migrator' ); ?></th><td>
				<input type="date" id="apm-export-modified-after"> <?php esc_html_e( 'to', 'advanced-post-migrator' ); ?> <input type="date" id="apm-export-modified-before">
			</td></tr>
		</table>
		</div>

		<div class="apm-filter-pane" data-filter-entity="taxonomies" style="display:none;">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="apm-export-tax-list-ac"><?php esc_html_e( 'Taxonomies', 'advanced-post-migrator' ); ?></label></th><td>
					<div class="apm-ac" data-source="taxonomies" data-value="name" data-input-id="apm-export-tax-list-ac" data-min-chars="0" data-scope-post-type="#apm-export-post-type" data-placeholder="<?php esc_attr_e( 'All taxonomies of the selected post type', 'advanced-post-migrator' ); ?>">
						<input type="hidden" class="apm-ac-value" id="apm-export-tax-list" value="">
					</div>
					<p class="description"><?php esc_html_e( 'Leave empty to export every taxonomy registered for the selected post type.', 'advanced-post-migrator' ); ?></p>
				</td></tr>
				<tr><th scope="row"><label for="apm-export-term-search"><?php esc_html_e( 'Name/slug search', 'advanced-post-migrator' ); ?></label></th><td>
					<input type="text" id="apm-export-term-search" class="regular-text" placeholder="<?php esc_attr_e( 'Leave blank to export every term', 'advanced-post-migrator' ); ?>">
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Empty terms', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" id="apm-export-hide-empty"> <?php esc_html_e( 'Only export terms with at least one post', 'advanced-post-migrator' ); ?></label></td></tr>
			</table>
			<p class="description"><?php esc_html_e( 'Hierarchical taxonomies (e.g. Categories) export with their full parent path so it can be rebuilt on the destination site; flat taxonomies (e.g. Tags) export as a plain list.', 'advanced-post-migrator' ); ?></p>
		</div>
	</div>

	<!-- STEP 4: Field mapping / selection -->
	<div class="apm-wizard-pane" data-pane="4">
		<h2><?php esc_html_e( 'Choose which fields to export', 'advanced-post-migrator' ); ?></h2>
		<p class="apm-detected" id="apm-export-detected-badges">
			<?php if ( APM_ACF_Handler::is_active() ) : ?>
				<span class="apm-badge apm-badge-ok">✓ <?php esc_html_e( 'ACF detected', 'advanced-post-migrator' ); ?></span>
			<?php else : ?>
				<span class="apm-badge apm-badge-warn"><?php esc_html_e( 'ACF not detected', 'advanced-post-migrator' ); ?></span>
			<?php endif; ?>
			<?php if ( APM_Yoast_Handler::is_active() ) : ?>
				<span class="apm-badge apm-badge-ok">✓ <?php esc_html_e( 'Yoast SEO detected', 'advanced-post-migrator' ); ?></span>
			<?php else : ?>
				<span class="apm-badge apm-badge-warn"><?php esc_html_e( 'Yoast SEO not detected', 'advanced-post-migrator' ); ?></span>
			<?php endif; ?>
		</p>
		<div class="apm-field-toolbar">
			<input type="search" id="apm-export-field-search" placeholder="<?php esc_attr_e( 'Search fields…', 'advanced-post-migrator' ); ?>">
			<button type="button" class="button" id="apm-export-select-all"><?php esc_html_e( 'Select All', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-export-select-none"><?php esc_html_e( 'Select None', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-export-reset-defaults"><?php esc_html_e( 'Reset Defaults', 'advanced-post-migrator' ); ?></button>
		</div>
		<div id="apm-export-field-groups"><p><?php esc_html_e( 'Loading fields…', 'advanced-post-migrator' ); ?></p></div>
	</div>

	<!-- STEP 5: Advanced options + run -->
	<div class="apm-wizard-pane" data-pane="5">
		<h2><?php esc_html_e( 'Advanced options', 'advanced-post-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><label for="apm-export-batch-size"><?php esc_html_e( 'Batch size', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-export-batch-size">
					<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?><option value="<?php echo esc_attr( $n ); ?>" <?php selected( $n, 50 ); ?>><?php echo esc_html( $n ); ?></option><?php endforeach; ?>
				</select>
			</td></tr>
		</table>

		<p class="apm-run-actions">
			<button type="button" class="button button-primary button-hero" id="apm-run-export"><?php esc_html_e( 'Start Export', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-save-export-profile"><?php esc_html_e( 'Save as Profile', 'advanced-post-migrator' ); ?></button>
		</p>

		<div id="apm-export-progress" class="apm-progress" hidden>
			<div class="apm-progress-head"><strong class="apm-progress-title"><?php esc_html_e( 'Exporting…', 'advanced-post-migrator' ); ?></strong><span class="apm-progress-pct">0%</span></div>
			<div class="apm-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="apm-progress-fill" id="apm-export-progress-fill"></div></div>
			<div class="apm-progress-meta" id="apm-export-progress-text" aria-live="polite"></div>
		</div>

		<div id="apm-export-result"></div>
	</div>

	<div class="apm-wizard-footer">
		<button type="button" class="button" id="apm-export-back" style="visibility:hidden;"><?php esc_html_e( '← Back', 'advanced-post-migrator' ); ?></button>
		<div class="apm-footer-right">
			<button type="button" class="button button-primary" id="apm-export-next"><?php esc_html_e( 'Next →', 'advanced-post-migrator' ); ?></button>
		</div>
	</div>
</div>
