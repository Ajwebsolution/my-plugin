<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $wpdb;
$settings = get_option( 'apm_settings', array() );
$sub_tab  = isset( $_GET['stab'] ) ? sanitize_key( wp_unslash( $_GET['stab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$sub_tabs = array(
	'general'     => __( 'General', 'advanced-post-migrator' ),
	'media'       => __( 'Media', 'advanced-post-migrator' ),
	'backup'      => __( 'Backup & Rollback', 'advanced-post-migrator' ),
	'logging'     => __( 'Logging', 'advanced-post-migrator' ),
	'performance' => __( 'Performance', 'advanced-post-migrator' ),
	'status'      => __( 'Plugin Status', 'advanced-post-migrator' ),
);

function apm_val( $settings, $key, $default = '' ) {
	return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}
function apm_checked( $settings, $key, $default = false ) {
	return ! empty( $settings[ $key ] ?? $default ) ? 'checked' : '';
}
?>
<div class="apm-panel">
	<div class="apm-subtabs">
		<?php foreach ( $sub_tabs as $slug => $label ) : ?>
			<a class="<?php echo $slug === $sub_tab ? 'active' : ''; ?>" href="?page=apm-settings&stab=<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</div>

	<?php if ( 'status' === $sub_tab ) : ?>

		<?php $r = APM_System_Status::get_report(); ?>
		<h2><?php esc_html_e( 'Plugin Status', 'advanced-post-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th><?php esc_html_e( 'Plugin', 'advanced-post-migrator' ); ?></th><td><?php esc_html_e( 'Advanced Post Migrator', 'advanced-post-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Status', 'advanced-post-migrator' ); ?></th><td><?php esc_html_e( 'Active', 'advanced-post-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Version', 'advanced-post-migrator' ); ?></th><td><?php echo esc_html( $r['plugin_version'] ); ?></td></tr>
			<tr><th>ACF</th><td><?php echo $r['acf_active'] ? esc_html__( 'Detected', 'advanced-post-migrator' ) : esc_html__( 'Not installed', 'advanced-post-migrator' ); ?></td></tr>
			<tr><th>ACF Pro</th><td><?php echo $r['acf_pro'] ? esc_html__( 'Detected', 'advanced-post-migrator' ) : esc_html__( 'Not detected', 'advanced-post-migrator' ); ?></td></tr>
			<tr><th>Yoast SEO</th><td><?php echo $r['yoast_active'] ? esc_html__( 'Detected', 'advanced-post-migrator' ) : esc_html__( 'Not installed', 'advanced-post-migrator' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'PHP Version', 'advanced-post-migrator' ); ?></th><td><?php echo esc_html( $r['php_version'] ); ?></td></tr>
			<tr><th><?php esc_html_e( 'WordPress Version', 'advanced-post-migrator' ); ?></th><td><?php echo esc_html( $r['wordpress_version'] ); ?></td></tr>
		</table>
		<p>
			<button type="button" class="button" id="apm-check-compat"><?php esc_html_e( 'Check System Compatibility', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-run-diagnostics-2"><?php esc_html_e( 'Run Diagnostics', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button apm-tool apm-tool-confirm" data-tool="clear_temp_files"><?php esc_html_e( 'Clear Temporary Data', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-clear-logs-2"><?php esc_html_e( 'Clear Logs', 'advanced-post-migrator' ); ?></button>
			<a class="button" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Manage Plugin (Activate/Deactivate)', 'advanced-post-migrator' ); ?></a>
		</p>
		<p class="description"><?php esc_html_e( 'Deactivating this plugin is done through the standard WordPress Plugins screen above — this plugin never deactivates itself through a custom endpoint.', 'advanced-post-migrator' ); ?></p>
		<div id="apm-status-result"></div>

	<?php else : ?>

	<form method="post" action="options.php">
		<?php settings_fields( 'apm_settings' ); ?>

		<?php if ( 'general' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Default post type', 'advanced-post-migrator' ); ?></th><td>
					<select name="apm_settings[default_post_type]">
						<?php foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) : ?>
							<option value="<?php echo esc_attr( $pt->name ); ?>" <?php selected( apm_val( $settings, 'default_post_type', 'post' ), $pt->name ); ?>><?php echo esc_html( $pt->labels->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Default match strategy', 'advanced-post-migrator' ); ?></th><td>
					<select name="apm_settings[default_match_strategy]">
						<?php foreach ( array( 'slug' => 'Slug', 'post_id' => 'Post ID', 'external_id' => 'External ID', 'none' => 'Always create new' ) as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( apm_val( $settings, 'default_match_strategy', 'slug' ), $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Preserve existing values when source is empty', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[preserve_empty_values]" <?php echo apm_checked( $settings, 'preserve_empty_values' ); ?>> <?php esc_html_e( 'Enabled', 'advanced-post-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'On uninstall', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[delete_data_on_uninstall]" <?php echo apm_checked( $settings, 'delete_data_on_uninstall' ); ?>> <?php esc_html_e( 'Delete this plugin\'s own tables, logs and settings when fully removed (via Plugins → Delete). Your posts are never touched by this option.', 'advanced-post-migrator' ); ?></label></td></tr>
			</table>
		<?php elseif ( 'media' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Image matching method', 'advanced-post-migrator' ); ?></th><td>
					<select name="apm_settings[image_match_strategy]">
						<?php foreach ( array( 'url_filename_fallback' => 'URL → Filename fallback', 'attachment_id' => 'Attachment ID', 'url' => 'URL', 'filename' => 'Filename' ) as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( apm_val( $settings, 'image_match_strategy', 'url_filename_fallback' ), $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th><?php esc_html_e( 'Download remote images by default', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[download_remote_images]" <?php echo apm_checked( $settings, 'download_remote_images', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-post-migrator' ); ?></label></td></tr>
			</table>
		<?php elseif ( 'backup' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Create post snapshot before update', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[create_backup_before_update]" <?php echo apm_checked( $settings, 'create_backup_before_update' ); ?>> <?php esc_html_e( 'Enabled', 'advanced-post-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Enable rollback', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[enable_rollback]" <?php echo apm_checked( $settings, 'enable_rollback', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-post-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Keep snapshots for (days)', 'advanced-post-migrator' ); ?></th><td><input type="number" min="1" name="apm_settings[snapshot_retention_days]" value="<?php echo esc_attr( apm_val( $settings, 'snapshot_retention_days', 14 ) ); ?>"></td></tr>
			</table>
		<?php elseif ( 'logging' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Enable logging', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" name="apm_settings[logging_enabled]" <?php echo apm_checked( $settings, 'logging_enabled', true ); ?>> <?php esc_html_e( 'Enabled', 'advanced-post-migrator' ); ?></label></td></tr>
				<tr><th><?php esc_html_e( 'Log retention (days)', 'advanced-post-migrator' ); ?></th><td><input type="number" min="1" name="apm_settings[log_retention_days]" value="<?php echo esc_attr( apm_val( $settings, 'log_retention_days', 30 ) ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Log location', 'advanced-post-migrator' ); ?></th><td><code><?php echo esc_html( $wpdb->prefix ?? 'wp_' ); ?>apm_logs</code> <?php esc_html_e( '(database table — not flat files, so it survives file-based server backups/restores cleanly).', 'advanced-post-migrator' ); ?></td></tr>
			</table>
		<?php elseif ( 'performance' === $sub_tab ) : ?>
			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Default batch size', 'advanced-post-migrator' ); ?></th><td>
					<select name="apm_settings[batch_size]">
						<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?>
							<option value="<?php echo esc_attr( $n ); ?>" <?php selected( (int) apm_val( $settings, 'batch_size', 50 ), $n ); ?>><?php echo esc_html( $n ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
			</table>
		<?php endif; ?>

		<?php submit_button(); ?>
	</form>

	<?php endif; ?>
</div>
