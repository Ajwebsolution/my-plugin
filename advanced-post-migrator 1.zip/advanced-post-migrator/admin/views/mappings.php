<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mappings = APM_Mappings::all();
?>
<div class="apm-panel">
	<h2><?php esc_html_e( 'Saved Mappings', 'advanced-post-migrator' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Mapping profiles are created from the Export or Import wizard ("Save as Profile") and reused here for repeat migrations.', 'advanced-post-migrator' ); ?></p>

	<div class="apm-table-wrap"<?php echo empty( $mappings ) ? ' hidden' : ''; ?> id="apm-mappings-table-wrap">
	<table class="widefat striped apm-table">
		<thead><tr><th><?php esc_html_e( 'Name', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Type', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Updated', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Actions', 'advanced-post-migrator' ); ?></th></tr></thead>
		<tbody id="apm-mappings-tbody">
			<?php foreach ( $mappings as $m ) : ?>
				<tr data-id="<?php echo esc_attr( $m['id'] ); ?>">
					<td><?php echo esc_html( $m['name'] ); ?></td>
					<td><span class="apm-badge-sm apm-type-<?php echo esc_attr( $m['type'] ); ?>"><?php echo esc_html( ucfirst( $m['type'] ) ); ?></span></td>
					<td><?php echo esc_html( $m['updated_at'] ); ?></td>
					<td>
						<a href="#" class="apm-mapping-duplicate" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Duplicate', 'advanced-post-migrator' ); ?></a> |
						<a href="#" class="apm-mapping-export" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Export', 'advanced-post-migrator' ); ?></a> |
						<a href="#" class="apm-mapping-delete apm-link-danger" data-id="<?php echo esc_attr( $m['id'] ); ?>"><?php esc_html_e( 'Delete', 'advanced-post-migrator' ); ?></a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<div id="apm-mappings-empty"<?php echo empty( $mappings ) ? '' : ' hidden'; ?>>
		<?php echo APM_Admin::empty_state( 'portfolio', __( 'No saved mappings yet', 'advanced-post-migrator' ), __( 'Use "Save as Profile" on the last step of the Export or Import wizard to reuse settings and column mappings for repeat migrations.', 'advanced-post-migrator' ), admin_url( 'admin.php?page=apm-import' ), __( 'Open the Import wizard', 'advanced-post-migrator' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</div>

	<h3><?php esc_html_e( 'Import a mapping file', 'advanced-post-migrator' ); ?></h3>
	<p class="description"><?php esc_html_e( 'A .json file previously downloaded with "Export" above.', 'advanced-post-migrator' ); ?></p>
	<input type="file" id="apm-mapping-import-file" accept=".json">
	<button type="button" class="button" id="apm-mapping-import-btn"><?php esc_html_e( 'Import Mapping', 'advanced-post-migrator' ); ?></button>
	<div id="apm-mappings-result"></div>
</div>
