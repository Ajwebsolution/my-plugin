<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$r = APM_System_Status::get_report();
function apm_status_dot( $status ) {
	$map = array( 'good' => '🟢', 'warning' => '🟡', 'critical' => '🔴' );
	return $map[ $status ] ?? '⚪';
}
?>
<div class="apm-panel">
	<h2><?php esc_html_e( 'System Status', 'advanced-post-migrator' ); ?></h2>

	<table class="widefat striped">
		<tbody>
			<tr><td><?php esc_html_e( 'Plugin Version', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( $r['plugin_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'WordPress', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( $r['wordpress_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'PHP', 'advanced-post-migrator' ); ?></td><td><?php echo apm_status_dot( $r['php_status'] ); ?> <?php echo esc_html( $r['php_version'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'MySQL', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( $r['mysql_version'] ); ?></td></tr>
			<tr><td>ACF</td><td><?php echo $r['acf_active'] ? '🟢 ' . esc_html( ( $r['acf_pro'] ? 'Pro ' : '' ) . $r['acf_version'] ) : '⚪ ' . esc_html__( 'Not installed', 'advanced-post-migrator' ); ?></td></tr>
			<tr><td>Yoast SEO</td><td><?php echo $r['yoast_active'] ? '🟢 ' . esc_html( $r['yoast_version'] ) : '⚪ ' . esc_html__( 'Not installed', 'advanced-post-migrator' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'REST API', 'advanced-post-migrator' ); ?></td><td>🟢</td></tr>
			<tr><td><?php esc_html_e( 'Memory Limit', 'advanced-post-migrator' ); ?></td><td><?php echo apm_status_dot( $r['memory_status'] ); ?> <?php echo esc_html( $r['memory_limit'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Max Execution Time', 'advanced-post-migrator' ); ?></td><td><?php echo apm_status_dot( $r['exec_time_status'] ); ?> <?php echo esc_html( $r['max_execution_time'] ); ?>s</td></tr>
			<tr><td><?php esc_html_e( 'Upload Max Filesize', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( $r['upload_max_filesize'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Post Max Size', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( $r['post_max_size'] ); ?></td></tr>
			<tr><td><?php esc_html_e( 'Registered Public Post Types', 'advanced-post-migrator' ); ?></td><td><?php echo esc_html( implode( ', ', $r['registered_post_types'] ) ); ?></td></tr>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'Detected Integrations', 'advanced-post-migrator' ); ?></h3>
	<table class="widefat striped">
		<thead><tr><th><?php esc_html_e( 'Plugin', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Detected', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Version', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Supported', 'advanced-post-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $r['integrations'] as $name => $info ) : ?>
				<tr>
					<td><?php echo esc_html( $name ); ?></td>
					<td><?php echo $info['detected'] ? '✓' : '—'; ?></td>
					<td><?php echo esc_html( $info['version'] ?: '—' ); ?></td>
					<td><?php echo $info['supported'] ? '✓' : '—'; ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<p>
		<button type="button" class="button" id="apm-copy-report"><?php esc_html_e( 'Copy System Report', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button" id="apm-run-diagnostics"><?php esc_html_e( 'Run Diagnostics', 'advanced-post-migrator' ); ?></button>
	</p>
	<textarea id="apm-report-text" style="position:absolute;left:-9999px;"><?php echo esc_textarea( APM_System_Status::as_text() ); ?></textarea>
	<div id="apm-status-result"></div>
</div>
