<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$post_types = get_post_types( array( 'public' => true ), 'objects' );
?>
<div class="apm-panel">
	<h2><?php esc_html_e( 'Tools', 'advanced-post-migrator' ); ?></h2>

	<p>
		<label for="apm-tools-post-type"><?php esc_html_e( 'Post type for the tools below:', 'advanced-post-migrator' ); ?></label>
		<select id="apm-tools-post-type">
			<?php foreach ( $post_types as $pt ) : ?>
				<option value="<?php echo esc_attr( $pt->name ); ?>" <?php selected( $pt->name, 'post' ); ?>><?php echo esc_html( $pt->labels->name ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>

	<div class="apm-tools-grid">
		<button type="button" class="button apm-tool" data-tool="scan_post_meta"><?php esc_html_e( 'Scan Post Meta', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="scan_acf_fields"><?php esc_html_e( 'Scan ACF Fields', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="scan_taxonomies"><?php esc_html_e( 'Scan Taxonomies', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="scan_post_types"><?php esc_html_e( 'Scan Post Types', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="find_duplicate_slugs"><?php esc_html_e( 'Find Duplicate Slugs', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="validate_post_data"><?php esc_html_e( 'Validate Post Data', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool apm-tool-confirm" data-tool="clear_temp_files"><?php esc_html_e( 'Clear Temporary Files', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button apm-tool" data-tool="rebuild_relationship_map"><?php esc_html_e( 'Rebuild Relationship Map', 'advanced-post-migrator' ); ?></button>
		<button type="button" class="button button-primary apm-tool" data-tool="generate_sample_export"><?php esc_html_e( 'Generate Sample Export', 'advanced-post-migrator' ); ?></button>
	</div>

	<div id="apm-tools-result"></div>
</div>
