<?php
/**
 * Import wizard: Select Source -> Post Handling -> Map Columns (CSV only)
 * -> Advanced Options -> Preview & Run. Preview (Step 5) calls the real,
 * read-only APM_Post_Importer::preview_rows() — same find_existing_post()
 * logic the actual import uses — so what's shown is not a separate guess.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$import_profiles = APM_Mappings::all( 'import' );
$post_types       = get_post_types( array( 'public' => true ), 'objects' );
?>
<div id="apm-import-app" class="apm-panel">

	<div class="apm-wizard-steps">
		<div class="apm-wizard-step active" data-step="1"><span class="apm-step-num">1</span><?php esc_html_e( 'Select Source', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="2"><span class="apm-step-num">2</span><?php esc_html_e( 'Post Handling', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="3"><span class="apm-step-num">3</span><?php esc_html_e( 'Map Columns', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="4"><span class="apm-step-num">4</span><?php esc_html_e( 'Advanced Options', 'advanced-post-migrator' ); ?></div>
		<div class="apm-wizard-connector"></div>
		<div class="apm-wizard-step" data-step="5"><span class="apm-step-num">5</span><?php esc_html_e( 'Preview & Run', 'advanced-post-migrator' ); ?></div>
	</div>

	<?php if ( $import_profiles ) : ?>
	<p class="apm-profile-bar">
		<label for="apm-load-profile"><span class="dashicons dashicons-portfolio" aria-hidden="true"></span> <?php esc_html_e( 'Saved mapping profile', 'advanced-post-migrator' ); ?></label>
		<select id="apm-load-profile">
			<option value=""><?php esc_html_e( '— Start fresh —', 'advanced-post-migrator' ); ?></option>
			<?php foreach ( $import_profiles as $p ) : ?>
				<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php endif; ?>

	<!-- STEP 1: Source -->
	<div class="apm-wizard-pane active" data-pane="1">
		<h2><?php esc_html_e( 'What are you importing?', 'advanced-post-migrator' ); ?></h2>
		<div class="apm-card-grid">
			<div class="apm-card selected" data-entity="post">
				<span class="dashicons dashicons-admin-post"></span>
				<span class="apm-card-title"><?php esc_html_e( 'Posts', 'advanced-post-migrator' ); ?></span>
				<span class="apm-card-desc"><?php esc_html_e( 'Posts (or any selected post type), with ACF, Yoast, taxonomies, featured image and custom meta', 'advanced-post-migrator' ); ?></span>
			</div>
			<div class="apm-card" data-entity="taxonomies">
				<span class="dashicons dashicons-category"></span>
				<span class="apm-card-title"><?php esc_html_e( 'Categories, Tags & Taxonomies', 'advanced-post-migrator' ); ?></span>
				<span class="apm-card-desc"><?php esc_html_e( 'Standalone taxonomy import, independent of any post', 'advanced-post-migrator' ); ?></span>
			</div>
		</div>
		<input type="hidden" id="apm-import-entity" value="post">

		<table class="form-table" role="presentation" id="apm-import-post-type-row">
			<tr><th scope="row"><label for="apm-import-post-type"><?php esc_html_e( 'Target post type', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-import-post-type">
					<?php foreach ( $post_types as $pt ) : ?>
						<option value="<?php echo esc_attr( $pt->name ); ?>" <?php selected( $pt->name, 'post' ); ?>><?php echo esc_html( $pt->labels->name ); ?> (<?php echo esc_html( $pt->name ); ?>)</option>
					<?php endforeach; ?>
				</select>
			</td></tr>
		</table>

		<table class="form-table" role="presentation" id="apm-import-default-taxonomy-row" style="display:none;">
			<tr><th scope="row"><label for="apm-import-default-taxonomy"><?php esc_html_e( 'Default taxonomy', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-import-default-taxonomy" class="apm-taxonomy-select" data-all="1" data-default="category"><option value="category">category</option></select>
				<p class="description"><?php esc_html_e( 'Used for rows that don\'t specify their own "taxonomy" column/field.', 'advanced-post-migrator' ); ?></p>
			</td></tr>
		</table>

		<h2><?php esc_html_e( 'Where is your file?', 'advanced-post-migrator' ); ?></h2>
		<div class="apm-source-pane active" data-source-pane="upload">
			<label class="apm-dropzone" id="apm-dropzone" for="apm-import-file">
				<span class="dashicons dashicons-upload" aria-hidden="true"></span>
				<span class="apm-dropzone-title"><?php esc_html_e( 'Drop your file here, or click to browse', 'advanced-post-migrator' ); ?></span>
				<span class="apm-dropzone-hint"><?php echo esc_html( APM_XLSX_Handler::is_available() ? __( 'CSV, JSON or XLSX — including files exported by this plugin or other tools', 'advanced-post-migrator' ) : __( 'CSV or JSON — including files exported by this plugin or other tools', 'advanced-post-migrator' ) ); ?></span>
				<input type="file" id="apm-import-file" class="apm-visually-hidden" accept=".csv,.json<?php echo APM_XLSX_Handler::is_available() ? ',.xlsx' : ''; ?>">
			</label>
			<div class="apm-file-card" id="apm-file-card" hidden>
				<span class="apm-file-icon" aria-hidden="true"></span>
				<div class="apm-file-info">
					<strong class="apm-file-name"></strong>
					<span class="apm-file-meta"></span>
				</div>
				<span class="apm-file-state"></span>
				<button type="button" class="button button-small" id="apm-file-replace"><?php esc_html_e( 'Replace', 'advanced-post-migrator' ); ?></button>
			</div>
		</div>

		<div id="apm-upload-status"></div>
	</div>

	<!-- STEP 2: Post handling -->
	<div class="apm-wizard-pane" data-pane="2">
		<h2 id="apm-step2-heading"><?php esc_html_e( 'What should happen to existing posts?', 'advanced-post-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><?php esc_html_e( 'If it already exists', 'advanced-post-migrator' ); ?></th><td>
				<select id="apm-match-strategy">
					<option value="slug" selected><?php esc_html_e( 'Update by Slug', 'advanced-post-migrator' ); ?></option>
					<option value="post_id"><?php esc_html_e( 'Update by Post ID', 'advanced-post-migrator' ); ?></option>
					<option value="external_id"><?php esc_html_e( 'Update by External ID (falls back to Slug)', 'advanced-post-migrator' ); ?></option>
					<option value="none"><?php esc_html_e( 'Never match — always create new', 'advanced-post-migrator' ); ?></option>
				</select>
				<p class="description" id="apm-match-strategy-help"></p>
			</td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Action for existing records', 'advanced-post-migrator' ); ?></th><td>
				<select id="apm-existing-action">
					<option value="update" selected><?php esc_html_e( 'Update existing', 'advanced-post-migrator' ); ?></option>
					<option value="skip"><?php esc_html_e( 'Skip existing', 'advanced-post-migrator' ); ?></option>
					<option value="duplicate"><?php esc_html_e( 'Create duplicate', 'advanced-post-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr class="apm-post-only-row"><th scope="row"><?php esc_html_e( 'Missing taxonomy terms', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" id="apm-create-taxonomy-terms" checked> <?php esc_html_e( 'Create missing taxonomy terms (and parent levels) automatically', 'advanced-post-migrator' ); ?></label></td></tr>
			<tr class="apm-taxonomies-only-row" style="display:none;"><th scope="row"><?php esc_html_e( 'Missing parent terms', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" id="apm-create-missing-parents" checked> <?php esc_html_e( 'Create missing parent levels of a hierarchy path automatically', 'advanced-post-migrator' ); ?></label></td></tr>
		</table>
	</div>

	<!-- STEP 3: Map columns -->
	<div class="apm-wizard-pane" data-pane="3">
		<h2><?php esc_html_e( 'Map import columns', 'advanced-post-migrator' ); ?></h2>
		<div id="apm-json-no-mapping-notice" style="display:none;">
			<p class="description"><?php esc_html_e( 'This is a JSON file with canonical field names (e.g. exported by this plugin) — no column mapping is needed. Continue to the next step.', 'advanced-post-migrator' ); ?></p>
		</div>
		<div id="apm-csv-mapping-ui" style="display:none;">
			<div class="apm-field-toolbar">
				<input type="search" id="apm-mapping-search" placeholder="<?php esc_attr_e( 'Search columns…', 'advanced-post-migrator' ); ?>">
			</div>
			<div id="apm-mapping-groups"></div>
		</div>
	</div>

	<!-- STEP 4: Advanced options -->
	<div class="apm-wizard-pane" data-pane="4">
		<h2><?php esc_html_e( 'Advanced options', 'advanced-post-migrator' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr class="apm-post-only-row"><th scope="row"><?php esc_html_e( 'Image matching strategy', 'advanced-post-migrator' ); ?></th><td>
				<select id="apm-image-strategy">
					<option value="url_filename_fallback" selected><?php esc_html_e( 'URL → filename fallback (recommended)', 'advanced-post-migrator' ); ?></option>
					<option value="attachment_id"><?php esc_html_e( 'Attachment ID (same-site only)', 'advanced-post-migrator' ); ?></option>
					<option value="url"><?php esc_html_e( 'URL', 'advanced-post-migrator' ); ?></option>
					<option value="filename"><?php esc_html_e( 'Filename', 'advanced-post-migrator' ); ?></option>
				</select>
			</td></tr>
			<tr class="apm-post-only-row"><th scope="row"><?php esc_html_e( 'Create backup before update', 'advanced-post-migrator' ); ?></th><td><label><input type="checkbox" id="apm-create-backup"> <?php esc_html_e( 'Enable rollback for this import (snapshots each updated post first)', 'advanced-post-migrator' ); ?></label></td></tr>
			<tr><th scope="row"><label for="apm-batch-size"><?php esc_html_e( 'Batch size', 'advanced-post-migrator' ); ?></label></th><td>
				<select id="apm-batch-size">
					<?php foreach ( array( 10, 25, 50, 100, 250 ) as $n ) : ?><option value="<?php echo esc_attr( $n ); ?>" <?php selected( $n, 50 ); ?>><?php echo esc_html( $n ); ?></option><?php endforeach; ?>
				</select>
			</td></tr>
		</table>
	</div>

	<!-- STEP 5: Preview & Run -->
	<div class="apm-wizard-pane" data-pane="5">
		<h2><?php esc_html_e( 'Preview', 'advanced-post-migrator' ); ?></h2>
		<p class="apm-run-actions">
			<button type="button" class="button" id="apm-load-preview"><span class="dashicons dashicons-visibility" aria-hidden="true"></span> <?php esc_html_e( 'Load Preview (first 20 rows, writes nothing)', 'advanced-post-migrator' ); ?></button>
		</p>
		<div id="apm-preview-table-wrap"></div>

		<p class="apm-run-actions">
			<button type="button" class="button" id="apm-dry-run-btn"><?php esc_html_e( 'Run Full Dry Run (all rows, writes nothing)', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button button-primary button-hero" id="apm-run-import-btn"><?php esc_html_e( 'Confirm & Run Import', 'advanced-post-migrator' ); ?></button>
			<button type="button" class="button" id="apm-save-import-profile"><?php esc_html_e( 'Save as Profile', 'advanced-post-migrator' ); ?></button>
		</p>

		<div id="apm-import-progress" class="apm-progress" hidden>
			<div class="apm-progress-head"><strong class="apm-progress-title"><?php esc_html_e( 'Importing…', 'advanced-post-migrator' ); ?></strong><span class="apm-progress-pct">0%</span></div>
			<div class="apm-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="apm-progress-fill" id="apm-import-progress-fill"></div></div>
			<div class="apm-progress-meta" id="apm-import-progress-text" aria-live="polite"></div>
		</div>

		<div id="apm-rollback-wrap"></div>

		<div id="apm-import-result"></div>
	</div>

	<div class="apm-wizard-footer">
		<button type="button" class="button" id="apm-import-back" style="visibility:hidden;"><?php esc_html_e( '← Back', 'advanced-post-migrator' ); ?></button>
		<div class="apm-footer-right">
			<button type="button" class="button button-primary" id="apm-import-next"><?php esc_html_e( 'Next →', 'advanced-post-migrator' ); ?></button>
		</div>
	</div>
</div>
