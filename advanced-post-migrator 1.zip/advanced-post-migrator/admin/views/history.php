<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$imports = APM_Jobs::list_import_jobs( 50 );
$exports = APM_Jobs::list_export_jobs( 50 );
?>
<div class="apm-panel">
	<h2><?php esc_html_e( 'Import History', 'advanced-post-migrator' ); ?></h2>
	<?php if ( empty( $imports ) ) : ?>
		<?php echo APM_Admin::empty_state( 'upload', __( 'No imports yet', 'advanced-post-migrator' ), __( 'Every import job — with its created/updated/failed counts and a rollback option — will be listed here.', 'advanced-post-migrator' ), admin_url( 'admin.php?page=apm-import' ), __( 'Start an import', 'advanced-post-migrator' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php else : ?>
	<div class="apm-table-wrap">
	<table class="widefat striped apm-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Job ID', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Type', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Date', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Created', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Updated', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Skipped', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Failed', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Status', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'advanced-post-migrator' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $imports as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $job['entity_type'] ?? 'post' ) ); ?></td>
					<td><?php echo esc_html( $job['created_at'] ); ?></td>
					<td><?php echo esc_html( $job['created_count'] ); ?></td>
					<td><?php echo esc_html( $job['updated_count'] ); ?></td>
					<td><?php echo esc_html( $job['skipped_count'] ); ?></td>
					<td><?php echo esc_html( $job['failed_count'] ); ?></td>
					<td><?php echo APM_Admin::status_badge( $job['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></td>
					<td>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=apm-logs&job_id=' . $job['id'] ) ); ?>"><?php esc_html_e( 'View Details', 'advanced-post-migrator' ); ?></a>
						<?php if ( 'completed' === $job['status'] ) : ?>
							<span class="apm-sep" aria-hidden="true">·</span> <a href="#" class="apm-rollback-link apm-link-danger" data-job-id="<?php echo esc_attr( $job['id'] ); ?>"><?php esc_html_e( 'Rollback', 'advanced-post-migrator' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Export History', 'advanced-post-migrator' ); ?></h2>
	<?php if ( empty( $exports ) ) : ?>
		<?php echo APM_Admin::empty_state( 'download', __( 'No exports yet', 'advanced-post-migrator' ), __( 'Finished exports appear here with a secure download link for 48 hours.', 'advanced-post-migrator' ), admin_url( 'admin.php?page=apm-export' ), __( 'Start an export', 'advanced-post-migrator' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php else : ?>
	<div class="apm-table-wrap">
	<table class="widefat striped apm-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Job ID', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Type', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Date', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Format', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Records', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'Status', 'advanced-post-migrator' ); ?></th>
				<th><?php esc_html_e( 'File', 'advanced-post-migrator' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $exports as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php echo esc_html( ucfirst( $job['entity_type'] ?? 'post' ) ); ?></td>
					<td><?php echo esc_html( $job['created_at'] ); ?></td>
					<td><?php echo esc_html( strtoupper( $job['format'] ) ); ?></td>
					<td><?php echo esc_html( $job['processed_count'] ); ?></td>
					<td><?php echo APM_Admin::status_badge( $job['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></td>
					<td><?php if ( ! empty( $job['file_path'] ) && 'completed' === $job['status'] ) : ?><a href="<?php echo esc_url( admin_url( 'admin-post.php?action=apm_download&type=export&job_id=' . $job['id'] . '&_wpnonce=' . wp_create_nonce( 'apm_nonce' ) ) ); ?>" class="button button-small"><span class="dashicons dashicons-download" aria-hidden="true"></span> <?php esc_html_e( 'Download', 'advanced-post-migrator' ); ?></a><?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php endif; ?>
</div>
