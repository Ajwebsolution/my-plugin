<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$stats             = APM_Jobs::get_dashboard_stats();
$default_post_type = $stats['post_type'] ?? 'post';
$acf_fields        = APM_ACF_Handler::is_active() ? count( APM_Field_Registry::get_acf_fields( $default_post_type ) ) : 0;
$custom_meta_count = count( APM_Field_Registry::discover_custom_meta_keys( 200, $default_post_type ) );
?>
<div class="apm-panel apm-dashboard">

	<div class="apm-stat-grid">
		<div class="apm-stat"><span class="apm-stat-num"><?php echo esc_html( number_format_i18n( $stats['posts'] ) ); ?></span><span class="apm-stat-label"><?php printf( esc_html__( '%s (default type)', 'advanced-post-migrator' ), esc_html( ucfirst( $default_post_type ) ) ); ?></span></div>
		<div class="apm-stat"><span class="apm-stat-num"><?php echo esc_html( number_format_i18n( $acf_fields ) ); ?></span><span class="apm-stat-label"><?php esc_html_e( 'ACF Fields Detected', 'advanced-post-migrator' ); ?></span></div>
		<div class="apm-stat"><span class="apm-stat-num"><?php echo esc_html( number_format_i18n( $custom_meta_count ) ); ?></span><span class="apm-stat-label"><?php esc_html_e( 'Custom Meta Keys (sampled)', 'advanced-post-migrator' ); ?></span></div>
		<div class="apm-stat"><span class="apm-stat-num"><?php echo esc_html( number_format_i18n( $stats['total_created'] + $stats['total_updated'] ) ); ?></span><span class="apm-stat-label"><?php esc_html_e( 'Successful Imports', 'advanced-post-migrator' ); ?></span></div>
		<div class="apm-stat"><span class="apm-stat-num"><?php echo esc_html( number_format_i18n( $stats['total_failed'] ) ); ?></span><span class="apm-stat-label"><?php esc_html_e( 'Failed', 'advanced-post-migrator' ); ?></span></div>
	</div>

	<p class="apm-last-run">
		<?php if ( $stats['last_import'] ) : ?>
			<?php printf( esc_html__( 'Last Import: %s', 'advanced-post-migrator' ), esc_html( $stats['last_import']['finished_at'] ) ); ?>
		<?php else : ?>
			<?php esc_html_e( 'No imports run yet.', 'advanced-post-migrator' ); ?>
		<?php endif; ?>
		&nbsp;·&nbsp;
		<?php if ( $stats['last_export'] ) : ?>
			<?php printf( esc_html__( 'Last Export: %s', 'advanced-post-migrator' ), esc_html( $stats['last_export']['finished_at'] ) ); ?>
		<?php else : ?>
			<?php esc_html_e( 'No exports run yet.', 'advanced-post-migrator' ); ?>
		<?php endif; ?>
	</p>

	<div class="apm-quick-actions">
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=apm-export' ) ); ?>"><?php esc_html_e( 'Export Posts', 'advanced-post-migrator' ); ?></a>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=apm-import' ) ); ?>"><?php esc_html_e( 'Import Posts', 'advanced-post-migrator' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=apm-mappings' ) ); ?>"><?php esc_html_e( 'Create Mapping', 'advanced-post-migrator' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=apm-tools' ) ); ?>"><?php esc_html_e( 'Tools', 'advanced-post-migrator' ); ?></a>
	</div>

	<h2><?php esc_html_e( 'Recent Activity', 'advanced-post-migrator' ); ?></h2>
	<div class="apm-table-wrap"><table class="widefat striped apm-table">
		<thead><tr><th><?php esc_html_e( 'Job', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Type', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Result', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Status', 'advanced-post-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $stats['recent_imports'] as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php esc_html_e( 'Import', 'advanced-post-migrator' ); ?></td>
					<td><?php printf( esc_html__( '%1$d created, %2$d updated, %3$d failed', 'advanced-post-migrator' ), (int) $job['created_count'], (int) $job['updated_count'], (int) $job['failed_count'] ); ?></td>
					<td><?php echo APM_Admin::status_badge( $job['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				</tr>
			<?php endforeach; ?>
			<?php foreach ( $stats['recent_exports'] as $job ) : ?>
				<tr>
					<td>#<?php echo esc_html( $job['id'] ); ?></td>
					<td><?php esc_html_e( 'Export', 'advanced-post-migrator' ); ?></td>
					<td><?php printf( esc_html__( '%d records, %s', 'advanced-post-migrator' ), (int) $job['processed_count'], esc_html( strtoupper( $job['format'] ) ) ); ?></td>
					<td><?php echo APM_Admin::status_badge( $job['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $stats['recent_imports'] ) && empty( $stats['recent_exports'] ) ) : ?>
				<tr><td colspan="4"><?php esc_html_e( 'No activity yet.', 'advanced-post-migrator' ); ?></td></tr>
			<?php endif; ?>
		</tbody>
	</table></div>

	<h2><?php esc_html_e( 'System Status', 'advanced-post-migrator' ); ?></h2>
	<?php $report = APM_System_Status::get_report(); ?>
	<ul class="apm-status-list">
		<li class="<?php echo 'good' === $report['php_status'] ? 'ok' : 'critical'; ?>">PHP <?php echo esc_html( $report['php_version'] ); ?> <?php echo 'good' === $report['php_status'] ? '✓' : '✕'; ?></li>
		<li class="<?php echo $report['acf_active'] ? 'ok' : 'muted'; ?>">ACF <?php echo $report['acf_active'] ? '✓' : '—'; ?></li>
		<li class="<?php echo $report['yoast_active'] ? 'ok' : 'muted'; ?>">Yoast <?php echo $report['yoast_active'] ? '✓' : '—'; ?></li>
		<li class="ok"><?php esc_html_e( 'REST API', 'advanced-post-migrator' ); ?> ✓</li>
	</ul>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=apm-status' ) ); ?>"><?php esc_html_e( 'View full System Status →', 'advanced-post-migrator' ); ?></a></p>
</div>
