<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$job_id = isset( $_GET['job_id'] ) ? absint( $_GET['job_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$level  = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : ''; // phpcs:ignore
$logs   = APM_Logger::query( array( 'job_id' => $job_id, 'level' => $level, 'limit' => 200 ) );
$items  = $job_id ? APM_Jobs::get_import_items( $job_id, '', 200 ) : array();
?>
<div class="apm-panel">
	<h2><?php esc_html_e( 'Import / Export Logs', 'advanced-post-migrator' ); ?><?php if ( $job_id ) printf( ' — ' . esc_html__( 'Job #%d', 'advanced-post-migrator' ), $job_id ); ?></h2>

	<p class="apm-filter-bar">
		<a class="button <?php echo '' === $level ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'level', '', '' ) ); ?>"><?php esc_html_e( 'All', 'advanced-post-migrator' ); ?></a>
		<a class="button <?php echo 'error' === $level ? 'button-primary' : ''; ?>" href="?page=apm-logs&job_id=<?php echo esc_attr( $job_id ); ?>&level=error"><?php esc_html_e( 'Errors', 'advanced-post-migrator' ); ?></a>
		<a class="button <?php echo 'warning' === $level ? 'button-primary' : ''; ?>" href="?page=apm-logs&job_id=<?php echo esc_attr( $job_id ); ?>&level=warning"><?php esc_html_e( 'Warnings', 'advanced-post-migrator' ); ?></a>
		<a class="button apm-button-danger" id="apm-clear-logs" href="#" role="button"><?php esc_html_e( 'Clear Logs', 'advanced-post-migrator' ); ?></a>
	</p>

	<?php if ( $job_id && $items ) : ?>
		<h3><?php esc_html_e( 'Per-Row Results', 'advanced-post-migrator' ); ?></h3>
		<table class="widefat striped apm-table">
			<thead><tr><th><?php esc_html_e( 'Slug', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Post ID', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Result', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Message', 'advanced-post-migrator' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
					<tr>
						<td><?php echo esc_html( $item['slug'] ); ?></td>
						<td><?php echo $item['post_id'] ? '<a href="' . esc_url( get_edit_post_link( $item['post_id'] ) ) . '">#' . esc_html( $item['post_id'] ) . '</a>' : '—'; ?></td>
						<td><span class="apm-badge-sm apm-result-<?php echo esc_attr( $item['result'] ); ?>"><?php echo esc_html( $item['result'] ); ?></span></td>
						<td><?php echo esc_html( $item['message'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<h3><?php esc_html_e( 'Event Log', 'advanced-post-migrator' ); ?></h3>
	<?php if ( empty( $logs ) ) : ?>
		<?php echo APM_Admin::empty_state( 'list-view', $level ? __( 'No matching log entries', 'advanced-post-migrator' ) : __( 'The log is empty', 'advanced-post-migrator' ), $level ? __( 'Nothing at this level — try "All".', 'advanced-post-migrator' ) : __( 'Import and export events are recorded here as jobs run.', 'advanced-post-migrator' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php else : ?>
	<div class="apm-table-wrap">
	<table class="widefat striped apm-table">
		<thead><tr><th><?php esc_html_e( 'Time', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Level', 'advanced-post-migrator' ); ?></th><th><?php esc_html_e( 'Message', 'advanced-post-migrator' ); ?></th></tr></thead>
		<tbody>
			<?php foreach ( $logs as $entry ) : ?>
				<tr>
					<td><?php echo esc_html( $entry['created_at'] ); ?></td>
					<td><span class="apm-badge-sm apm-level-<?php echo esc_attr( $entry['level'] ); ?>"><?php echo esc_html( $entry['level'] ); ?></span></td>
					<td><?php echo esc_html( $entry['message'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php endif; ?>
</div>
