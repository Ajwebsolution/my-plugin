<?php
/**
 * APM_Admin
 *
 * Registers a fully separate top-level admin menu (Dashboard, Export,
 * Import, History, Logs, Mappings, Tools, Settings, System Status). Not
 * nested under any other plugin's menu, and not dependent on WooCommerce
 * or any other plugin being active. Enqueues assets only on our own
 * screens.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Admin {

	protected static $instance = null;
	const CAPABILITY = 'manage_options'; // Also accepted: manage_apm (see class-apm-installer.php).
	const SLUG        = 'apm';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	protected function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function current_user_can_manage() {
		return current_user_can( 'manage_apm' ) || current_user_can( self::CAPABILITY );
	}

	protected function pages() {
		return array(
			'dashboard' => __( 'Dashboard', 'advanced-post-migrator' ),
			'export'    => __( 'Export', 'advanced-post-migrator' ),
			'import'    => __( 'Import', 'advanced-post-migrator' ),
			'history'   => __( 'History', 'advanced-post-migrator' ),
			'logs'      => __( 'Logs', 'advanced-post-migrator' ),
			'mappings'  => __( 'Mappings', 'advanced-post-migrator' ),
			'tools'     => __( 'Tools', 'advanced-post-migrator' ),
			'settings'  => __( 'Settings', 'advanced-post-migrator' ),
			'status'    => __( 'System Status', 'advanced-post-migrator' ),
		);
	}

	/**
	 * A genuinely separate top-level menu item (add_menu_page). The
	 * Dashboard page IS the top-level entry (WordPress requires the parent
	 * slug's own page to be one of its submenus for the URL to resolve
	 * cleanly), and every other screen is registered as its own submenu
	 * under that same top-level slug.
	 */
	public function register_menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="#a7aaad"><path d="M4 3h8l4 4v10H4V3zm7 1.5V8h3.5L11 4.5zM6 11h8v1.4H6V11zm0 3h8v1.4H6V14z"/></svg>'
		);

		add_menu_page(
			__( 'Post Migrator', 'advanced-post-migrator' ),
			__( 'Post Migrator', 'advanced-post-migrator' ),
			self::CAPABILITY,
			self::SLUG . '-dashboard',
			array( $this, 'render_page' ),
			$icon,
			58
		);

		foreach ( $this->pages() as $slug => $label ) {
			add_submenu_page(
				self::SLUG . '-dashboard',
				sprintf( '%s — %s', __( 'Post Migrator', 'advanced-post-migrator' ), $label ),
				$label,
				self::CAPABILITY,
				self::SLUG . '-' . $slug,
				array( $this, 'render_page' )
			);
		}
	}

	/**
	 * Which of our pages the current request is on. Reads $_GET['page']
	 * directly rather than parsing $screen->id, since the screen ID prefix
	 * differs between a top-level page ("toplevel_page_apm-dashboard") and
	 * its submenus and isn't worth keeping in lockstep with WordPress's own
	 * naming.
	 */
	protected function current_page_slug() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = 0 === strpos( $page, self::SLUG . '-' ) ? substr( $page, strlen( self::SLUG ) + 1 ) : '';
		return isset( $this->pages()[ $page ] ) ? $page : 'dashboard';
	}

	/**
	 * Friendly empty-state block (icon, title, text, optional call to action)
	 * shared by History / Logs / Mappings.
	 */
	public static function empty_state( $icon, $title, $text, $cta_url = '', $cta_label = '' ) {
		$html  = '<div class="apm-empty">';
		$html .= '<span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
		$html .= '<h3>' . esc_html( $title ) . '</h3>';
		$html .= '<p>' . esc_html( $text ) . '</p>';
		if ( $cta_url ) {
			$html .= '<a class="button button-primary" href="' . esc_url( $cta_url ) . '">' . esc_html( $cta_label ) . '</a>';
		}
		return $html . '</div>';
	}

	/** Status badge markup for a job status string. */
	public static function status_badge( $status ) {
		$labels = array(
			'completed'   => __( 'Completed', 'advanced-post-migrator' ),
			'failed'      => __( 'Failed', 'advanced-post-migrator' ),
			'running'     => __( 'Running', 'advanced-post-migrator' ),
			'pending'     => __( 'Pending', 'advanced-post-migrator' ),
			'rolled_back' => __( 'Rolled back', 'advanced-post-migrator' ),
		);
		$label = $labels[ $status ] ?? ucfirst( str_replace( '_', ' ', (string) $status ) );
		return '<span class="apm-status-pill apm-status-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
	}

	public function render_page() {
		if ( ! $this->current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advanced-post-migrator' ) );
		}

		$page = $this->current_page_slug();

		echo '<div class="wrap apm-wrap">';
		echo '<div class="apm-header"><h1 class="apm-title">' . esc_html__( 'Advanced Post Migrator', 'advanced-post-migrator' ) . '</h1><span class="apm-version">v' . esc_html( APM_VERSION ) . '</span></div>';
		// Core admin notices are moved after the first .wrap h1 / hr.wp-header-end by WP's common.js.
		echo '<hr class="wp-header-end">';

		echo '<nav class="apm-tabs" aria-label="' . esc_attr__( 'Post Migrator sections', 'advanced-post-migrator' ) . '">';
		foreach ( $this->pages() as $slug => $label ) {
			$class = ( $slug === $page ) ? 'apm-tab apm-tab-active' : 'apm-tab';
			printf(
				'<a href="%s" class="%s"%s>%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-' . $slug ) ),
				esc_attr( $class ),
				$slug === $page ? ' aria-current="page"' : '',
				esc_html( $label )
			);
		}
		echo '</nav>';

		$view_file = APM_PLUGIN_DIR . 'admin/views/' . sanitize_file_name( $page ) . '.php';
		if ( file_exists( $view_file ) ) {
			include $view_file;
		} else {
			echo '<div class="apm-panel"><p>' . esc_html__( 'This screen is not available.', 'advanced-post-migrator' ) . '</p></div>';
		}

		echo '<div class="apm-toasts" id="apm-toasts" aria-live="polite" aria-atomic="false"></div>';
		echo '</div>';
	}

	/**
	 * Loads our CSS/JS only on our own screens. Checks $_GET['page']
	 * rather than the $hook suffix for the same reason current_page_slug()
	 * does — robust regardless of top-level vs submenu hook naming.
	 */
	public function enqueue_assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 0 !== strpos( $page, self::SLUG . '-' ) ) {
			return;
		}

		wp_enqueue_style( 'apm-admin', APM_PLUGIN_URL . 'assets/css/apm-admin.css', array(), APM_VERSION );
		wp_enqueue_script( 'apm-admin', APM_PLUGIN_URL . 'assets/js/apm-admin.js', array( 'jquery', 'jquery-ui-sortable' ), APM_VERSION, true );

		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$post_type_options = array();
		foreach ( $post_types as $pt ) {
			$post_type_options[ $pt->name ] = $pt->labels->singular_name;
		}

		wp_localize_script(
			'apm-admin',
			'APM',
			array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'apm_nonce' ),
				'post_types' => $post_type_options,
				'transforms' => class_exists( 'APM_Transformer' ) ? APM_Transformer::get_available_transforms() : array(),
				'taxonomies' => class_exists( 'APM_Search' ) ? APM_Search::taxonomies_by_post_type() : array(),
				'i18n'       => array(
					'confirm_import'      => __( 'This will write changes to your site. Continue?', 'advanced-post-migrator' ),
					'confirm_destructive'  => __( 'This action cannot be undone. Continue?', 'advanced-post-migrator' ),
					'confirm_rollback'    => __( 'This will restore posts to their state before this import. Continue?', 'advanced-post-migrator' ),
				),
			)
		);
	}
}
