=== Advanced Post Migrator ===
Contributors: yourcompany
Tags: import, export, migration, acf, yoast seo, posts, custom post types
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Full-fidelity import/export for WordPress Posts (and any registered post type), including ACF, Yoast SEO, taxonomies, featured images and custom meta.

== Description ==

Advanced Post Migrator (APM) moves WordPress content between sites — or
re-imports it into the same site — without the data loss that plagues
off-the-shelf CSV/JSON importers. It works against core WordPress Posts by
default, but any registered public post type can be selected in the
Export/Import wizards (pages, and any custom post type your theme or other
plugins register).

It is a completely standalone plugin: it does not require, extend, or
modify WooCommerce or the separate "Advanced Woo Product Migrator" (AWPM)
plugin, and is safe to run on a site that also has AWPM active — all of
its classes, database tables, options and the `manage_apm` capability use
an `APM_` / `apm_` prefix distinct from AWPM's `AWPM_` / `awpm_`.

= What's exported/imported with full fidelity =

* Core post fields: title, slug, content, excerpt, status, author,
  dates, parent, menu order, comment status, ping status.
* **ACF** (Advanced Custom Fields), when active: every field type,
  including repeater, flexible content, gallery, relationship,
  post object, group, clone and taxonomy fields — read and written
  through ACF's own field API (`get_field_objects()` / `update_field()`),
  never raw postmeta, so nested/serialized structures round-trip intact.
* **Yoast SEO** meta, when active (meta title, description, focus
  keyphrase, canonical, robots directives, Open Graph/Twitter fields,
  etc. — the exact key map is filterable via `apm_yoast_field_map`).
* **Any taxonomy registered for the selected post type.** Hierarchical
  taxonomies (e.g. Categories) export/import the full ancestor path and
  resolve it level-by-level on the destination, creating only the
  branches that don't already exist — re-running an import never
  duplicates a category tree. Flat taxonomies (e.g. Tags) match/create
  by name.
* **Featured image**, resolved across sites by a configurable strategy
  (attachment ID / URL / filename / URL-then-filename fallback), with
  automatic download-and-sideload when no local match is found.
* **Auto-discovered custom postmeta** — any meta key not already handled
  by ACF, Yoast, or WordPress core is exported automatically, with an
  include/exclude/rename rule set available from the field-mapping UI.

= Safety features =

* **Dry run** — preview exactly what an import will create, update, or
  skip before anything is written.
* **Snapshots & rollback** — before an existing post is updated, its
  full state (core fields, every meta key, every taxonomy term) is
  snapshotted. Rolling back a completed import job restores updated
  posts to their prior state and trashes (never hard-deletes) posts the
  job created.
* **Relationship mapping** — ACF relationship/post_object fields and
  post-matching by "External ID" never trust a raw source post ID; they
  resolve through a persistent source→target map keyed by an external ID,
  so repeated migrations stay consistent even when source and
  destination IDs differ.
* **Background batch processing** with a configurable batch size, so
  large imports/exports don't time out.
* **History & Logs** — every import/export job is recorded with
  created/updated/skipped/failed counts, and a searchable activity log.
* **Saved mapping profiles** — save a field mapping/configuration once
  and reuse it for repeat migrations.

= Supported file formats =

CSV, JSON, and a true XLSX (Excel) format, for both export and import.
Nested data (ACF structures, taxonomy paths) is preserved losslessly in
CSV/XLSX cells as JSON, and natively in JSON exports.

== What this plugin deliberately does NOT do ==

In the interest of never shipping a button that doesn't work, the
following were left out of this 1.0.0 release rather than included in a
non-functional or partial state:

* **No Scheduled Jobs / recurring migrations.** Every import/export runs
  on demand from the admin UI; there is no cron-based "run this import
  every night" feature.
* **No Webhooks.** The plugin does not call out to an external URL on
  job completion/failure.
* **No REST API.** All functionality is exposed through the WordPress
  admin UI (AJAX), not a public or authenticated REST endpoint.
* **No WP-CLI commands.**
* **No remote-URL or FTP import source.** Import reads only from a file
  you upload through the browser; pulling a source file from a remote
  URL or an FTP/SFTP server is not implemented. (Export downloads are,
  of course, supported — Tools → History lets you download any
  completed export file.)

If any of the above matter for your workflow, please confirm before
relying on this plugin for production migrations.

== Requirements ==

* PHP 7.4 or higher.
* WordPress 5.8 or higher.
* No required third-party plugin dependency. **Advanced Custom Fields**
  (free or Pro) and **Yoast SEO** are optional — if either is not
  active, APM simply skips that part of the export/import and continues
  with everything else (core fields, taxonomies, featured image, custom
  meta) without error.

== Installation ==

1. Upload the `advanced-post-migrator` folder to `/wp-content/plugins/`,
   or install the zip through Plugins → Add New → Upload Plugin.
2. Activate the plugin through the 'Plugins' screen.
3. Go to the new **Post Migrator** menu in the WordPress admin sidebar.

== Frequently Asked Questions ==

= Does this touch WooCommerce products? =

No. APM works with WordPress's native Posts API (`wp_insert_post()`,
`get_posts()`, etc.) against any registered post type you select —
`product` happens to be a valid post type if you choose it, but APM has
no WooCommerce-specific logic (no SKU/price/stock/variation handling).
If you need full-fidelity WooCommerce product migration, see the
separate "Advanced Woo Product Migrator" plugin.

= What happens to my data if I uninstall the plugin? =

By default, nothing is deleted — your posts, terms and media are never
touched by this plugin at any point, and even APM's own database tables
(logs, snapshots, job history, relationship map) are left in place so
reinstalling the plugin picks up where you left off. If you explicitly
enable "Delete this plugin's own tables, logs and settings" under
Settings → General and then fully delete the plugin via Plugins →
Delete, APM's own tables and settings are removed — your post content
is still never touched.

= Is it safe to run alongside Advanced Woo Product Migrator? =

Yes. The two plugins use entirely separate class names, database
tables, options and capabilities (`APM_`/`apm_` vs `AWPM_`/`awpm_`), and
neither plugin requires or references the other.

== Changelog ==

= 1.1.0 =
* New: autocomplete token fields with keyboard navigation, highlighted matches and removable chips for every post / term / taxonomy input on the Export screen — specific posts by ID or slug, taxonomy terms (with parent path and post count), title keyword include/exclude, a new "Exclude specific posts" picker (uses the existing exclude_ids export filter) and the taxonomy list for taxonomy exports.
* New: pasting a comma- or newline-separated list of IDs/slugs resolves them in one request and flags entries that don't match.
* New: AJAX lookups apm_search_posts and apm_search_terms (nonce + capability checked, max 20 results, lightweight queries).
* New: the taxonomy for "By taxonomy term" exports and the Import "Default taxonomy" are now dropdowns of registered taxonomies instead of free text.
* Improved: wizard stepper with done/current/upcoming states and a sticky Back/Next footer; inline validation instead of alert(); in-page confirm/name dialogs instead of confirm()/prompt(); toast notifications.
* Improved: drag-and-drop import upload with file name, size and format check; progress bars show processed/total, ETA and live counts; color-coded preview table with sticky header and per-verdict summary.
* Improved: empty states and status badges on History, Logs and Mappings; responsive down to 782px; accent color follows the admin color scheme where available.
* Fixed: server- and file-supplied text (CSV column names, preview values, error messages) is now escaped before being inserted into the page.
* Fixed: uploading a different file now rebuilds the column-mapping step; loading a saved import profile now applies its saved column mapping to CSV files.

= 1.0.0 =
* Initial release.
