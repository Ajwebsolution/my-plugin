<?php
/**
 * APM_Image_Handler
 *
 * Single source of truth for resolving an exported image reference
 * (source attachment ID + URL + filename) to a local attachment ID on the
 * destination site. Used by the ACF handler (image/file/gallery fields),
 * the product exporter/importer (featured image, gallery), and the
 * variation importer (variation image).
 *
 * Matching strategy is configurable per the spec:
 *   attachment_id | url | filename | sku_filename | url_filename_fallback
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Image_Handler {

	/** @var array In-request cache: source URL/ID => resolved local attachment ID. */
	protected static $cache = array();

	/**
	 * Resolve an image reference to a local attachment ID: match existing
	 * media first (per strategy), download only if nothing matches.
	 *
	 * @param array $ref {
	 *     @type int    $id          Source-site attachment ID (informational only across sites).
	 *     @type string $url         Source image URL.
	 *     @type string $filename    Source filename.
	 *     @type string $alt         Alt text to apply.
	 *     @type string $title       Attachment title.
	 *     @type string $caption     Attachment caption.
	 *     @type string $description Attachment description.
	 *     @type string $sku         Optional: owning post slug, for the sku_filename strategy (kept for parity with image file-naming conventions).
	 * }
	 * @param array $options {
	 *     @type string $image_match_strategy One of: attachment_id, url, filename, sku_filename, url_filename_fallback.
	 *     @type bool   $same_site            True when importing back into the very same install (source IDs are valid).
	 * }
	 * @return int|null Local attachment ID, or null if it couldn't be resolved/downloaded.
	 */
	public static function resolve_attachment( $ref, $options = array() ) {
		if ( empty( $ref['url'] ) && empty( $ref['id'] ) ) {
			return null;
		}

		$strategy  = $options['image_match_strategy'] ?? 'url_filename_fallback';
		$cache_key = $strategy . '|' . ( $ref['url'] ?? '' ) . '|' . ( $ref['id'] ?? '' );
		if ( isset( self::$cache[ $cache_key ] ) ) {
			return self::$cache[ $cache_key ];
		}

		$attachment_id = null;

		if ( ! empty( $options['same_site'] ) && ! empty( $ref['id'] ) && get_post( $ref['id'] ) ) {
			$attachment_id = (int) $ref['id'];
		}

		if ( ! $attachment_id ) {
			switch ( $strategy ) {
				case 'attachment_id':
					$attachment_id = self::match_by_id( $ref['id'] ?? null );
					break;
				case 'url':
					$attachment_id = self::match_by_url( $ref['url'] ?? '' );
					break;
				case 'filename':
					$attachment_id = self::match_by_filename( $ref['filename'] ?? '' );
					break;
				case 'sku_filename':
					$attachment_id = self::match_by_sku_filename( $ref['sku'] ?? '', $ref['filename'] ?? '' );
					break;
				case 'url_filename_fallback':
				default:
					$attachment_id = self::match_by_url( $ref['url'] ?? '' );
					if ( ! $attachment_id ) {
						$attachment_id = self::match_by_filename( $ref['filename'] ?? '' );
					}
					break;
			}
		}

		if ( ! $attachment_id && ! empty( $ref['url'] ) ) {
			$attachment_id = self::download_and_insert( $ref );
		}

		if ( $attachment_id && ! empty( $ref['alt'] ) && ! get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $ref['alt'] ) );
		}

		self::$cache[ $cache_key ] = $attachment_id;
		return $attachment_id;
	}

	protected static function match_by_id( $id ) {
		if ( ! $id ) {
			return null;
		}
		$post = get_post( $id );
		return ( $post && 'attachment' === $post->post_type ) ? (int) $id : null;
	}

	protected static function match_by_url( $url ) {
		if ( ! $url ) {
			return null;
		}
		global $wpdb;
		$filename = wp_basename( wp_parse_url( $url, PHP_URL_PATH ) );
		if ( ! $filename ) {
			return null;
		}
		// attachment_url_to_postid() only works for URLs on THIS install; for a
		// cross-site import the URL never matches locally, so we go straight to
		// a GUID/filename lookup instead.
		$local_id = attachment_url_to_postid( $url );
		if ( $local_id ) {
			return (int) $local_id;
		}
		return self::match_by_filename( $filename );
	}

	protected static function match_by_filename( $filename ) {
		if ( ! $filename ) {
			return null;
		}
		global $wpdb;
		$like = '%' . $wpdb->esc_like( $filename );
		$id   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
				$like
			)
		);
		return $id ? (int) $id : null;
	}

	protected static function match_by_sku_filename( $sku, $filename ) {
		if ( ! $sku || ! $filename ) {
			return self::match_by_filename( $filename );
		}
		global $wpdb;
		$like = '%' . $wpdb->esc_like( $sku . '-' . $filename ) . '%';
		$id   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
				$like
			)
		);
		return $id ? (int) $id : self::match_by_filename( $filename );
	}

	/**
	 * Download a remote image and insert it into the media library.
	 *
	 * @param array $ref
	 * @return int|null New attachment ID, or null on failure.
	 */
	protected static function download_and_insert( $ref ) {
		if ( empty( $ref['url'] ) || ! filter_var( $ref['url'], FILTER_VALIDATE_URL ) ) {
			return null;
		}

		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url( $ref['url'], 30 );
		if ( is_wp_error( $tmp ) ) {
			APM_Logger::log( 'error', sprintf( 'Image download failed for %s: %s', $ref['url'], $tmp->get_error_message() ) );
			return null;
		}

		$filename = ! empty( $ref['filename'] ) ? $ref['filename'] : wp_basename( $tmp );
		$file_array = array(
			'name'     => sanitize_file_name( $filename ),
			'tmp_name' => $tmp,
		);

		$attachment_id = media_handle_sideload( $file_array, 0, $ref['title'] ?? '' );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp );
			APM_Logger::log( 'error', sprintf( 'Media sideload failed for %s: %s', $ref['url'], $attachment_id->get_error_message() ) );
			return null;
		}

		if ( ! empty( $ref['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $ref['alt'] ) );
		}
		if ( ! empty( $ref['caption'] ) || ! empty( $ref['description'] ) ) {
			wp_update_post(
				array(
					'ID'           => $attachment_id,
					'post_excerpt' => $ref['caption'] ?? '',
					'post_content' => $ref['description'] ?? '',
				)
			);
		}

		return (int) $attachment_id;
	}

	/**
	 * Resolve a whole gallery (ordered list of refs) to an ordered list of
	 * local attachment IDs (e.g. for an ACF gallery field).
	 *
	 * @param array $refs
	 * @param array $options
	 * @return int[]
	 */
	public static function resolve_gallery( $refs, $options = array() ) {
		$ids = array();
		foreach ( (array) $refs as $ref ) {
			$id = self::resolve_attachment( $ref, $options );
			if ( $id ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}
}
