<?php
/**
 * APM_Exporter_File_Writer
 *
 * Shared batch-append file writer used by the Post and Taxonomy exporters
 * (JSON streamed between wrapper brackets, CSV written with a flattened
 * header on the first batch, true XLSX staged as NDJSON and assembled on
 * the last batch since a ZIP archive can't be appended to incrementally).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Exporter_File_Writer {

	/**
	 * @param string $file_path
	 * @param string $format          json|csv|xlsx
	 * @param array  $records
	 * @param bool   $is_first_batch
	 * @param bool   $is_last_batch
	 * @param string $entity_key      Used to namespace the XLSX/CSV column-cache option per job+entity.
	 */
	public static function append( $file_path, $format, $records, $is_first_batch, $is_last_batch, $entity_key = 'entity' ) {
		if ( 'json' === $format ) {
			$fh = fopen( $file_path, $is_first_batch ? 'w' : 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $is_first_batch ) {
				fwrite( $fh, '{"generator":"Advanced Post Migrator","version":"' . APM_VERSION . '","' . $entity_key . '":[' );
			}
			foreach ( $records as $i => $record ) {
				if ( ! $is_first_batch || $i > 0 ) {
					fwrite( $fh, ',' );
				}
				fwrite( $fh, wp_json_encode( $record, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
			}
			if ( $is_last_batch ) {
				fwrite( $fh, ']}' );
			}
			fclose( $fh );
			return;
		}

		$columns_key = 'apm_export_cols_' . $entity_key . '_' . basename( $file_path );

		if ( 'xlsx' === $format && APM_XLSX_Handler::is_available() ) {
			$scratch_path = $file_path . '.scratch.ndjson';
			$rows         = array_map( array( 'APM_CSV_Handler', 'flatten_record' ), $records );

			if ( $is_first_batch ) {
				$columns = self::collect_columns( $rows );
				update_option( $columns_key, $columns, false );
				$sfh = fopen( $scratch_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			} else {
				$columns = get_option( $columns_key, array() );
				$sfh     = fopen( $scratch_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}

			foreach ( $rows as $row ) {
				$line = array();
				foreach ( $columns as $col ) {
					$line[] = $row[ $col ] ?? '';
				}
				fwrite( $sfh, wp_json_encode( $line ) . "\n" );
			}
			fclose( $sfh );

			if ( $is_last_batch ) {
				APM_XLSX_Handler::write_from_ndjson( $scratch_path, $columns, $file_path );
				@unlink( $scratch_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				delete_option( $columns_key );
			}
			return;
		}

		// CSV (also the xlsx-unavailable fallback).
		$rows = array_map( array( 'APM_CSV_Handler', 'flatten_record' ), $records );
		if ( $is_first_batch ) {
			$columns = self::collect_columns( $rows );
			update_option( $columns_key, $columns, false );
			$fh = fopen( $file_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fwrite( $fh, "\xEF\xBB\xBF" );
			fputcsv( $fh, $columns );
		} else {
			$columns = get_option( $columns_key, array() );
			$fh      = fopen( $file_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = $row[ $col ] ?? '';
			}
			fputcsv( $fh, $line );
		}
		fclose( $fh );

		if ( $is_last_batch ) {
			delete_option( $columns_key );
		}
	}

	protected static function collect_columns( $rows ) {
		$columns = array();
		foreach ( $rows as $row ) {
			$columns = array_merge( $columns, array_keys( $row ) );
		}
		return array_values( array_unique( $columns ) );
	}
}
