<?php
/**
 * APM_XLSX_Handler
 *
 * A genuine, native .xlsx writer and reader using PHP's built-in
 * ZipArchive extension — no Composer/PhpSpreadsheet dependency needed. An
 * .xlsx file is just a ZIP archive of a handful of small XML parts; this
 * writes the minimum valid set (content types, relationships, workbook,
 * one worksheet) using OOXML's "inline string" cell type so no separate
 * shared-strings table has to be built and kept in sync. Verified against
 * the OOXML spec's minimum-viable-workbook shape; opens cleanly in Excel,
 * LibreOffice Calc, and Google Sheets.
 *
 * Uses the exact same row shape as APM_CSV_Handler::flatten_record() —
 * ACF/Yoast/custom-meta sub-arrays exploded into their own columns — so
 * XLSX and CSV exports are column-for-column identical, and a column's
 * header name round-trips through the same mapping-UI auto-guess heuristic
 * on import either way.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_XLSX_Handler {

	public static function is_available() {
		return class_exists( 'ZipArchive' );
	}

	/**
	 * Write an array of export records directly to a .xlsx file in one
	 * pass (used by the synchronous export() path — Tools/REST/CLI/
	 * scheduled exports, and any export small enough not to need batching).
	 *
	 * @param array  $records
	 * @param string $file_path
	 * @return bool
	 */
	public static function write( $records, $file_path ) {
		$rows = array_map( array( 'APM_CSV_Handler', 'flatten_record' ), $records );

		$columns = array();
		foreach ( $rows as $row ) {
			$columns = array_merge( $columns, array_keys( $row ) );
		}
		$columns = array_values( array_unique( $columns ) );

		return self::assemble( $columns, self::row_generator_from_array( $rows, $columns ), $file_path );
	}

	/**
	 * Write from an NDJSON scratch file (one flattened-row-as-JSON per
	 * line) — used by the batch export job path, which accumulates rows
	 * batch-by-batch into the scratch file (see
	 * APM_Post_Exporter::append_records_to_file()) rather than holding
	 * the whole export in memory across AJAX ticks, then converts the
	 * scratch file to a real .xlsx once the last batch has landed.
	 *
	 * @param string   $scratch_path
	 * @param string[] $columns
	 * @param string   $output_path
	 * @return bool
	 */
	public static function write_from_ndjson( $scratch_path, $columns, $output_path ) {
		return self::assemble( $columns, self::row_generator_from_ndjson( $scratch_path ), $output_path );
	}

	protected static function row_generator_from_array( $rows, $columns ) {
		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = $row[ $col ] ?? '';
			}
			yield $line;
		}
	}

	protected static function row_generator_from_ndjson( $scratch_path ) {
		$fh = fopen( $scratch_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			return;
		}
		while ( ( $line = fgets( $fh ) ) !== false ) {
			$decoded = json_decode( $line, true );
			if ( is_array( $decoded ) ) {
				yield $decoded; // Already ordered to match columns — written that way by the caller.
			}
		}
		fclose( $fh );
	}

	/**
	 * Build the actual .xlsx (a ZIP of a few XML parts) from a header row
	 * and a generator of data rows.
	 *
	 * @param string[]    $columns
	 * @param \Generator  $row_generator Yields arrays of cell values, one per row, in column order.
	 * @param string      $file_path
	 * @return bool
	 */
	protected static function assemble( $columns, $row_generator, $file_path ) {
		if ( ! self::is_available() ) {
			return false;
		}

		$sheet_xml  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
		$sheet_xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
		$sheet_xml .= '<sheetData>';

		$sheet_xml .= self::build_row_xml( 1, $columns );

		$row_num = 2;
		foreach ( $row_generator as $row ) {
			$sheet_xml .= self::build_row_xml( $row_num, $row );
			$row_num++;
		}

		$sheet_xml .= '</sheetData></worksheet>';

		$zip = new ZipArchive();
		if ( true !== $zip->open( $file_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}

		$zip->addEmptyDir( '_rels' );
		$zip->addEmptyDir( 'xl' );
		$zip->addEmptyDir( 'xl/_rels' );
		$zip->addEmptyDir( 'xl/worksheets' );

		$zip->addFromString( '[Content_Types].xml', self::content_types_xml() );
		$zip->addFromString( '_rels/.rels', self::root_rels_xml() );
		$zip->addFromString( 'xl/workbook.xml', self::workbook_xml() );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', self::workbook_rels_xml() );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $sheet_xml );

		return $zip->close();
	}

	/**
	 * One <row> element, escaping text and using OOXML's inline-string
	 * cell type (t="inlineStr") for anything non-numeric so no shared
	 * strings table is needed. Numeric-looking scalars are written as
	 * real numbers so Excel sorts/sums them correctly instead of treating
	 * every column as text.
	 */
	protected static function build_row_xml( $row_num, $cells ) {
		$xml = '<row r="' . $row_num . '">';
		$col_letter = 'A';
		foreach ( $cells as $value ) {
			$ref = $col_letter . $row_num;
			if ( '' === $value || null === $value ) {
				$xml .= '<c r="' . $ref . '"/>';
			} elseif ( is_numeric( $value ) && ! preg_match( '/^0[0-9]/', (string) $value ) ) {
				// Skip the numeric fast-path for values with a leading zero
				// (e.g. a SKU "0012") — those should stay text, not become 12.
				$xml .= '<c r="' . $ref . '"><v>' . esc_html( (string) ( 0 + $value ) ) . '</v></c>';
			} else {
				$xml .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . esc_html( (string) $value ) . '</t></is></c>';
			}
			$col_letter++;
		}
		$xml .= '</row>';
		return $xml;
	}

	protected static function content_types_xml() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '</Types>';
	}

	protected static function root_rels_xml() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
	}

	protected static function workbook_xml() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="Records" sheetId="1" r:id="rId1"/></sheets>'
			. '</workbook>';
	}

	protected static function workbook_rels_xml() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '</Relationships>';
	}

	/* -------------------------------------------------------------------
	 * READ — for XLSX import support, mirroring APM_CSV_Handler's API.
	 * ---------------------------------------------------------------- */

	/**
	 * @param string $file_path
	 * @return array[]|WP_Error Rows as column => value (header taken from row 1), same shape as APM_CSV_Handler::read().
	 */
	public static function read( $file_path ) {
		$grid = self::read_grid( $file_path );
		if ( is_wp_error( $grid ) ) {
			return $grid;
		}

		$header = array_shift( $grid );
		if ( ! $header ) {
			return new WP_Error( 'apm_empty_xlsx', __( 'XLSX file has no header row.', 'advanced-post-migrator' ) );
		}

		$rows = array();
		foreach ( $grid as $data_row ) {
			$row = array();
			foreach ( $header as $i => $col ) {
				$raw = $data_row[ $i ] ?? '';
				$row[ $col ] = self::maybe_decode( $raw );
			}
			$rows[] = $row;
		}

		return $rows;
	}

	public static function read_header( $file_path ) {
		$grid = self::read_grid( $file_path, 1 );
		return is_wp_error( $grid ) ? $grid : ( $grid[0] ?? array() );
	}

	/**
	 * Parse sheet1.xml into a plain grid of strings (row => [cell, cell, ...]).
	 *
	 * @param string $file_path
	 * @param int    $max_rows 0 = all rows.
	 * @return array[]|WP_Error
	 */
	protected static function read_grid( $file_path, $max_rows = 0 ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'apm_xlsx_unavailable', __( 'The ZipArchive PHP extension is not available on this server, so .xlsx files cannot be read.', 'advanced-post-migrator' ) );
		}
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'apm_file_missing', __( 'XLSX file not found.', 'advanced-post-migrator' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $file_path ) ) {
			return new WP_Error( 'apm_xlsx_open_failed', __( 'Could not open the XLSX file — it may be corrupt.', 'advanced-post-migrator' ) );
		}

		// Real-world .xlsx files (from Excel/Sheets, not just our own writer)
		// use a shared-strings table instead of inline strings — read it if
		// present so we can still decode their text cells correctly.
		$shared_strings = array();
		$shared_xml     = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( $shared_xml ) {
			$shared_strings = self::parse_shared_strings( $shared_xml );
		}

		$sheet_xml = $zip->getFromName( 'xl/worksheets/sheet1.xml' );
		$zip->close();

		if ( ! $sheet_xml ) {
			return new WP_Error( 'apm_xlsx_no_sheet', __( 'Could not find a worksheet inside this XLSX file.', 'advanced-post-migrator' ) );
		}

		libxml_use_internal_errors( true );
		$xml = simplexml_load_string( $sheet_xml );
		if ( ! $xml ) {
			return new WP_Error( 'apm_xlsx_parse_failed', __( 'Could not parse the XLSX worksheet XML.', 'advanced-post-migrator' ) );
		}

		$grid = array();
		$row_count = 0;
		foreach ( $xml->sheetData->row as $row ) {
			$cells = array();
			$col_index = 0;
			foreach ( $row->c as $c ) {
				$ref = (string) $c['r'];
				$target_index = $ref ? self::column_letters_to_index( preg_replace( '/[0-9]/', '', $ref ) ) : $col_index;
				while ( $col_index < $target_index ) {
					$cells[ $col_index ] = '';
					$col_index++;
				}

				$type = (string) $c['t'];
				if ( 's' === $type ) {
					$idx = (int) $c->v;
					$cells[ $col_index ] = $shared_strings[ $idx ] ?? '';
				} elseif ( 'inlineStr' === $type ) {
					$cells[ $col_index ] = (string) $c->is->t;
				} else {
					$cells[ $col_index ] = (string) $c->v;
				}
				$col_index++;
			}
			$grid[] = array_values( $cells );
			$row_count++;
			if ( $max_rows && $row_count >= $max_rows ) {
				break;
			}
		}

		return $grid;
	}

	protected static function parse_shared_strings( $xml_string ) {
		libxml_use_internal_errors( true );
		$xml = simplexml_load_string( $xml_string );
		if ( ! $xml ) {
			return array();
		}
		$out = array();
		foreach ( $xml->si as $si ) {
			// A shared string entry can be a plain <t> or multiple <r><t> runs (rich text) — concatenate either way.
			if ( isset( $si->t ) ) {
				$out[] = (string) $si->t;
			} else {
				$text = '';
				foreach ( $si->r as $run ) {
					$text .= (string) $run->t;
				}
				$out[] = $text;
			}
		}
		return $out;
	}

	protected static function column_letters_to_index( $letters ) {
		$letters = strtoupper( $letters );
		$index   = 0;
		for ( $i = 0; $i < strlen( $letters ); $i++ ) {
			$index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
		}
		return $index - 1; // 0-based.
	}

	protected static function maybe_decode( $raw ) {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return $raw;
		}
		$first = $raw[0];
		if ( '{' === $first || '[' === $first ) {
			$decoded = json_decode( $raw, true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				return $decoded;
			}
		}
		return $raw;
	}
}
