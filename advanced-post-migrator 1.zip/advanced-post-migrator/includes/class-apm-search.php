<?php
/**
 * APM_Search
 *
 * Lookup helpers behind the admin autocomplete fields (apm_search_posts /
 * apm_search_terms AJAX actions). Kept free of any request handling so the
 * query-building and result-shaping logic can be tested in isolation.
 *
 * Every query is deliberately lightweight: small LIMIT, no SQL_CALC_FOUND_ROWS,
 * no meta/term cache priming — an autocomplete fires on every keystroke.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Search {

	const MAX_LIMIT     = 20;
	const MAX_RESOLVE   = 200;
	const PATH_SEPARATOR = ' › ';

	/** Clamp a requested limit into 1..MAX_LIMIT. */
	public static function clamp_limit( $limit ) {
		$limit = (int) $limit;
		return max( 1, min( self::MAX_LIMIT, $limit ? $limit : 10 ) );
	}

	/** Statuses an autocomplete may return (everything but auto-drafts). */
	public static function post_statuses() {
		$statuses = function_exists( 'get_post_stati' ) ? array_values( (array) get_post_stati() ) : array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' );
		return array_values( array_diff( $statuses, array( 'auto-draft', 'inherit' ) ) );
	}

	/** Shared fast-query flags. */
	protected static function fast_flags() {
		return array(
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'ignore_sticky_posts'    => true,
			'suppress_filters'       => false,
		);
	}

	/**
	 * The get_posts() argument sets used for a search query, in priority
	 * order: exact slug match, then title/content search.
	 *
	 * @return array[] keyed 'slug' / 'title'.
	 */
	public static function build_post_query_args( $q, $post_type, $limit ) {
		$q      = trim( (string) $q );
		$limit  = self::clamp_limit( $limit );
		$base   = array_merge(
			self::fast_flags(),
			array(
				'post_type'   => $post_type,
				'post_status' => self::post_statuses(),
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);
		$sets = array();
		$slug = sanitize_title( $q );
		if ( '' !== $slug ) {
			$sets['slug'] = array_merge( $base, array( 'name' => $slug, 'posts_per_page' => 1 ) );
		}
		if ( '' !== $q ) {
			$sets['title'] = array_merge( $base, array( 's' => $q, 'posts_per_page' => $limit, 'orderby' => 'relevance' ) );
		}
		return $sets;
	}

	/** Shape one WP_Post into the autocomplete row format. */
	public static function shape_post( $post ) {
		$status_obj = function_exists( 'get_post_status_object' ) ? get_post_status_object( $post->post_status ) : null;
		$link       = function_exists( 'get_edit_post_link' ) ? get_edit_post_link( $post->ID, 'raw' ) : '';
		return array(
			'id'           => (int) $post->ID,
			'title'        => '' !== (string) $post->post_title ? html_entity_decode( (string) $post->post_title, ENT_QUOTES, 'UTF-8' ) : '(no title)',
			'slug'         => (string) $post->post_name,
			'status'       => (string) $post->post_status,
			'status_label' => $status_obj && ! empty( $status_obj->label ) ? $status_obj->label : ucfirst( (string) $post->post_status ),
			'post_type'    => (string) $post->post_type,
			'date'         => substr( (string) $post->post_date, 0, 10 ),
			'edit_link'    => $link ? $link : '',
		);
	}

	/** Is this post acceptable for the requested scope? */
	protected static function post_in_scope( $post, $post_type ) {
		return $post && $post->post_type === $post_type && 'auto-draft' !== $post->post_status;
	}

	/**
	 * Search posts by exact ID (numeric q), exact slug, and title.
	 *
	 * @return array[] shaped rows, de-duplicated, at most $limit.
	 */
	public static function search_posts( $q, $post_type, $limit = 10 ) {
		$q     = trim( (string) $q );
		$limit = self::clamp_limit( $limit );
		if ( '' === $q ) {
			return array();
		}
		$found = array();

		if ( ctype_digit( $q ) ) {
			$p = get_post( (int) $q );
			if ( self::post_in_scope( $p, $post_type ) ) {
				$found[ $p->ID ] = $p;
			}
		}

		foreach ( self::build_post_query_args( $q, $post_type, $limit ) as $args ) {
			if ( count( $found ) >= $limit ) {
				break;
			}
			foreach ( (array) get_posts( $args ) as $p ) {
				if ( ! isset( $found[ $p->ID ] ) && self::post_in_scope( $p, $post_type ) ) {
					$found[ $p->ID ] = $p;
				}
			}
		}

		return array_map( array( __CLASS__, 'shape_post' ), array_slice( array_values( $found ), 0, $limit ) );
	}

	/** Split "1, 2\nfoo" into a unique, trimmed token list (capped). */
	public static function split_tokens( $raw ) {
		$parts = is_array( $raw ) ? $raw : preg_split( '/[\s,;]+/', (string) $raw );
		$out   = array();
		foreach ( (array) $parts as $p ) {
			$p = trim( (string) $p );
			if ( '' !== $p && ! in_array( $p, $out, true ) ) {
				$out[] = $p;
			}
		}
		return array_slice( $out, 0, self::MAX_RESOLVE );
	}

	/**
	 * Bulk-resolve pasted IDs/slugs to exact matches.
	 *
	 * @return array { items: shaped rows (with 'token'), unresolved: string[] }
	 */
	public static function resolve_posts( $tokens, $post_type ) {
		$items      = array();
		$unresolved = array();
		foreach ( self::split_tokens( $tokens ) as $token ) {
			$post = null;
			if ( ctype_digit( $token ) ) {
				$p = get_post( (int) $token );
				$post = self::post_in_scope( $p, $post_type ) ? $p : null;
			}
			if ( ! $post ) {
				$slug = sanitize_title( $token );
				if ( '' !== $slug ) {
					$args = array_merge(
						self::fast_flags(),
						array( 'post_type' => $post_type, 'post_status' => self::post_statuses(), 'name' => $slug, 'posts_per_page' => 1 )
					);
					$res  = get_posts( $args );
					$post = $res ? reset( $res ) : null;
				}
			}
			if ( $post ) {
				$row          = self::shape_post( $post );
				$row['token'] = $token;
				$items[]      = $row;
			} else {
				$unresolved[] = $token;
			}
		}
		return array( 'items' => $items, 'unresolved' => $unresolved );
	}

	/* ------------------------------ Terms ------------------------------ */

	/**
	 * Which taxonomies a term search covers: the requested one (if it
	 * exists), else every taxonomy registered for $post_type.
	 */
	public static function scope_taxonomies( $taxonomy, $post_type ) {
		if ( $taxonomy ) {
			return taxonomy_exists( $taxonomy ) ? array( $taxonomy ) : array();
		}
		$list = $post_type ? get_object_taxonomies( $post_type, 'names' ) : array();
		return array_values( array_filter( (array) $list, 'taxonomy_exists' ) );
	}

	/** "Parent › Child › Leaf" for a term. */
	public static function term_path( $term ) {
		$names     = array();
		$ancestors = function_exists( 'get_ancestors' ) ? (array) get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) : array();
		foreach ( array_reverse( $ancestors ) as $aid ) {
			$a = get_term( (int) $aid, $term->taxonomy );
			if ( $a && ! is_wp_error( $a ) ) {
				$names[] = $a->name;
			}
		}
		$names[] = $term->name;
		return implode( self::PATH_SEPARATOR, array_map( 'wp_specialchars_decode', $names ) );
	}

	public static function shape_term( $term ) {
		$tax = get_taxonomy( $term->taxonomy );
		return array(
			'id'             => $term->taxonomy . ':' . (int) $term->term_id,
			'term_id'        => (int) $term->term_id,
			'name'           => wp_specialchars_decode( (string) $term->name ),
			'slug'           => (string) $term->slug,
			'taxonomy'       => (string) $term->taxonomy,
			'taxonomy_label' => $tax && isset( $tax->labels->singular_name ) ? $tax->labels->singular_name : $term->taxonomy,
			'path'           => self::term_path( $term ),
			'count'          => (int) $term->count,
		);
	}

	public static function search_terms( $q, $taxonomies, $limit = 10 ) {
		$q     = trim( (string) $q );
		$limit = self::clamp_limit( $limit );
		if ( '' === $q || empty( $taxonomies ) ) {
			return array();
		}
		$found = array();
		$add   = function ( $t ) use ( &$found, $taxonomies ) {
			if ( $t && ! is_wp_error( $t ) && in_array( $t->taxonomy, $taxonomies, true ) ) {
				$found[ $t->taxonomy . ':' . $t->term_id ] = $t;
			}
		};

		if ( ctype_digit( $q ) ) {
			$add( get_term( (int) $q ) );
		}
		$base = array( 'taxonomy' => $taxonomies, 'hide_empty' => false, 'number' => $limit, 'update_term_meta_cache' => false );
		foreach ( array( array( 'slug' => sanitize_title( $q ) ), array( 'search' => $q, 'orderby' => 'count', 'order' => 'DESC' ) ) as $extra ) {
			if ( count( $found ) >= $limit || ( isset( $extra['slug'] ) && '' === $extra['slug'] ) ) {
				continue;
			}
			$terms = get_terms( array_merge( $base, $extra ) );
			if ( is_array( $terms ) ) {
				array_map( $add, $terms );
			}
		}
		return array_map( array( __CLASS__, 'shape_term' ), array_slice( array_values( $found ), 0, $limit ) );
	}

	/**
	 * Bulk-resolve pasted term IDs / slugs / "taxonomy:id" composites.
	 */
	public static function resolve_terms( $tokens, $taxonomies ) {
		$items      = array();
		$unresolved = array();
		foreach ( self::split_tokens( $tokens ) as $token ) {
			$term = null;
			if ( preg_match( '/^([a-z0-9_\-]+):(\d+)$/', $token, $m ) && in_array( $m[1], $taxonomies, true ) ) {
				$term = get_term( (int) $m[2], $m[1] );
			} elseif ( ctype_digit( $token ) ) {
				$term = get_term( (int) $token );
			} else {
				foreach ( $taxonomies as $tax ) {
					$term = get_term_by( 'slug', sanitize_title( $token ), $tax );
					if ( ! $term ) {
						$term = get_term_by( 'name', $token, $tax );
					}
					if ( $term ) {
						break;
					}
				}
			}
			if ( $term && ! is_wp_error( $term ) && in_array( $term->taxonomy, $taxonomies, true ) ) {
				$row          = self::shape_term( $term );
				$row['token'] = $token;
				$items[]      = $row;
			} else {
				$unresolved[] = $token;
			}
		}
		return array( 'items' => $items, 'unresolved' => $unresolved );
	}

	/**
	 * Taxonomies (name, label, hierarchical) for each public post type —
	 * localized to the admin JS so taxonomy pickers need no round trip.
	 */
	public static function taxonomies_by_post_type() {
		$out = array( '__all' => array() );
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $pt ) {
			$out[ $pt ] = array();
			foreach ( (array) get_object_taxonomies( $pt, 'objects' ) as $tax ) {
				if ( empty( $tax->show_ui ) && empty( $tax->public ) ) {
					continue;
				}
				$row          = array( 'name' => $tax->name, 'label' => $tax->labels->singular_name ?? $tax->label, 'hierarchical' => ! empty( $tax->hierarchical ) );
				$out[ $pt ][] = $row;
				$out['__all'][ $tax->name ] = $row;
			}
		}
		$out['__all'] = array_values( $out['__all'] );
		return $out;
	}
}
