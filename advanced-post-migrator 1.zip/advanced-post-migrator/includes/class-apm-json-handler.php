<?php
/**
 * APM_JSON_Handler
 *
 * JSON is the "lossless" export format — nested ACF repeater/flexible
 * content structures are written exactly as produced by APM_ACF_Handler,
 * with no flattening. Preferred format when round-tripping between two
 * APM-powered sites.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_JSON_Handler {

	/**
	 * Write an array of post export records to a JSON file.
	 *
	 * @param array  $records
	 * @param string $file_path
	 * @return bool
	 */
	public static function write( $records, $file_path ) {
		$payload = array(
			'generator'   => 'Advanced Post Migrator',
			'version'     => APM_VERSION,
			'exported_at' => current_time( 'mysql' ),
			'site_url'    => site_url(),
			'record_count'=> count( $records ),
			'records'     => $records,
		);

		$json = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return false !== file_put_contents( $file_path, $json ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Read a previously exported (or hand-authored) JSON file back into an
	 * array of post records.
	 *
	 * @param string $file_path
	 * @return array|WP_Error
	 */
	public static function read( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'apm_file_missing', __( 'JSON file not found.', 'advanced-post-migrator' ) );
		}

		$raw  = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = json_decode( $raw, true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error( 'apm_invalid_json', sprintf( __( 'Invalid JSON: %s', 'advanced-post-migrator' ), json_last_error_msg() ) );
		}

		// Accept either our wrapped export format, or a bare array of post records.
		if ( isset( $data['records'] ) && is_array( $data['records'] ) ) {
			return $data['records'];
		}
		if ( isset( $data['products'] ) && is_array( $data['products'] ) ) {
			return $data['products']; // Backward-compat with older exports.
		}

		return is_array( $data ) ? $data : array();
	}
}
