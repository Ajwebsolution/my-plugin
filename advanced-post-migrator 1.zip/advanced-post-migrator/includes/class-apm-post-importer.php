<?php
/**
 * APM_Post_Importer
 *
 * Reads rows from CSV/JSON/XLSX, applies the user's field mapping,
 * resolves existing-post matching (slug / post ID / external ID), and
 * creates or updates WordPress posts of the selected post type —
 * including every taxonomy registered for it, featured image, ACF, Yoast
 * and custom meta. Supports a dry-run mode that reports exactly what
 * would happen without writing anything.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Post_Importer {

	/**
	 * Read a source file into an array of raw rows, dispatching on format.
	 * The one place all four import entry points (import(), start_job(),
	 * process_next_batch(), preview_rows()) go through, so JSON/CSV/XLSX
	 * support stays in exactly one spot.
	 *
	 * @param string $file_path
	 * @param string $format json|csv|xlsx
	 * @return array[]|WP_Error
	 */
	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return APM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return APM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return APM_CSV_Handler::read( $file_path );
		}
	}

	/**
	 * @param array $args {
	 *     @type string $file_path
	 *     @type string $format          csv|json|xlsx
	 *     @type string $post_type       Target post type. Default 'post'.
	 *     @type array  $mapping         source_column => target_field.
	 *     @type string $match_strategy  slug|post_id|external_id|none (none = always create).
	 *     @type string $existing_action skip|update|duplicate
	 *     @type array  $options {
	 *         create_missing_taxonomy_terms: bool,
	 *         image_match_strategy: string,
	 *     }
	 *     @type bool   $dry_run
	 * }
	 * @return array|WP_Error Summary: { new, updated, skipped, errors[], run_id, dry_run }
	 */
	public function import( $args ) {
		$args = wp_parse_args( $args, $this->default_args() );

		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$run_id = APM_Logger::start_run();

		$summary = array(
			'new'       => 0,
			'updated'   => 0,
			'skipped'   => 0,
			'duplicated'=> 0,
			'errors'    => array(),
			'terms_to_create' => array(),
			'run_id'    => $run_id,
			'dry_run'   => (bool) $args['dry_run'],
			'total'     => count( $rows ),
		);

		foreach ( $rows as $i => $raw_row ) {
			try {
				$record             = $this->apply_mapping( $raw_row, $args['mapping'], $args['format'], $args['transforms'] ?? array() );
				$args['_row_index'] = $i;
				$this->process_record( $record, $args, $summary );
			} catch ( Exception $e ) {
				$summary['errors'][] = sprintf( 'Row %d: %s', $i + 1, $e->getMessage() );
				APM_Logger::log( 'error', sprintf( 'Row %d failed: %s', $i + 1, $e->getMessage() ) );
				if ( ! empty( $args['job_id'] ) ) {
					APM_Jobs::add_import_item( $args['job_id'], $i, $raw_row['slug'] ?? '', null, 'error', $e->getMessage() );
					APM_Jobs::increment_import_counts( $args['job_id'], 0, 0, 0, 1 );
				}
			}
		}

		return $summary;
	}

	protected function default_args() {
		return array(
			'file_path'       => '',
			'format'          => 'json',
			'post_type'       => 'post',
			'mapping'         => array(),
			'match_strategy'  => 'slug',
			'existing_action' => 'update',
			'options'         => array(),
			'dry_run'         => false,
		);
	}

	/* ---------------------------------------------------------------
	 * Batch/background job processing — a large import is never run in a
	 * single blocking PHP request. APM_Ajax::process_import_batch() calls
	 * process_next_batch() once per AJAX tick from the browser.
	 * ------------------------------------------------------------- */

	/**
	 * Create a tracked job row and return its ID. The file is read once
	 * here just to get an accurate total row count for the progress bar;
	 * actual row data is re-read per batch in process_next_batch() so we
	 * never hold the whole dataset in PHP memory across requests.
	 *
	 * @param array $args Same shape as import(), minus dry_run (set per-call to process_next_batch if needed).
	 * @return int|WP_Error Job ID.
	 */
	public function start_job( $args ) {
		$args = wp_parse_args( $args, $this->default_args() );

		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = APM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'entity_type' => $args['post_type'],
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array_merge(
					$args['options'] ?? array(),
					array(
						'post_type'       => $args['post_type'],
						'match_strategy'  => $args['match_strategy'] ?? 'slug',
						'existing_action' => $args['existing_action'] ?? 'update',
						'transforms'      => $args['transforms'] ?? array(),
					)
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 50,
				'total_rows'  => count( $rows ),
				'mapping_profile_id' => $args['mapping_profile_id'] ?? null,
			)
		);

		APM_Logger::set_run_id( 'apm_run_job_' . $job_id, 'import', $job_id );
		set_transient( 'apm_run_job_' . $job_id, array(), 6 * HOUR_IN_SECONDS );

		return $job_id;
	}

	/**
	 * Advance one job by exactly `batch_size` rows and persist progress.
	 * Idempotent to call repeatedly — always resumes from the job's own
	 * `offset_row`, so a page reload / lost connection mid-import just
	 * means the next poll picks up where it left off.
	 *
	 * @param int $job_id
	 * @return array|WP_Error { done: bool, job: array }
	 */
	public function process_next_batch( $job_id ) {
		$job = APM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'apm_job_not_found', __( 'Import job not found.', 'advanced-post-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}

		if ( 'pending' === $job['status'] ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		APM_Logger::set_run_id( 'apm_run_job_' . $job_id, 'import', $job_id );

		$rows = $this->read_rows( $job['file_path'], $job['format'] );

		if ( is_wp_error( $rows ) ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			return $rows;
		}

		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $rows, $offset, (int) $job['batch_size'] );

		$options = $job['options'];
		$args    = array(
			'post_type'       => $options['post_type'] ?? 'post',
			'mapping'         => $job['mapping'],
			'match_strategy'  => $options['match_strategy'] ?? 'slug',
			'existing_action' => $options['existing_action'] ?? 'update',
			'options'         => $options,
			'dry_run'         => (bool) $job['dry_run'],
			'job_id'          => $job_id,
		);

		$summary = array( 'new' => 0, 'updated' => 0, 'skipped' => 0, 'duplicated' => 0, 'errors' => array(), 'terms_to_create' => array() );

		foreach ( $batch as $i => $raw_row ) {
			$row_index          = $offset + $i;
			$args['_row_index'] = $row_index;
			try {
				$record = $this->apply_mapping( $raw_row, $args['mapping'], $job['format'], $job['options']['transforms'] ?? array() );
				$this->process_record( $record, $args, $summary );
			} catch ( Exception $e ) {
				APM_Jobs::add_import_item( $job_id, $row_index, $raw_row['slug'] ?? '', null, 'error', $e->getMessage() );
				$summary['errors'][] = $e->getMessage();
			}
		}

		APM_Jobs::increment_import_counts( $job_id, $summary['new'], $summary['updated'], $summary['skipped'], count( $summary['errors'] ), count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			APM_Logger::log( 'info', sprintf( 'Import job #%d complete.', $job_id ) );
		}

		return array(
			'done' => $done,
			'job'  => APM_Jobs::get_import_job( $job_id ),
			'batch_terms_to_create' => $summary['terms_to_create'],
		);
	}

	/**
	 * For JSON exported by this plugin, the record is already in our
	 * canonical shape — no mapping needed. For CSV (or a foreign
	 * CSV/JSON whose columns don't match our field keys 1:1), apply the
	 * user-defined source_column => target_field mapping to rename keys
	 * into our canonical shape before processing, running each column's
	 * configured transform first.
	 *
	 * @param array  $raw_row
	 * @param array  $mapping     source_column => target_field.
	 * @param string $format
	 * @param array  $transforms  source_column => transform config, applied before mapping.
	 * @return array
	 */
	protected function apply_mapping( $raw_row, $mapping, $format, $transforms = array() ) {
		if ( ! empty( $transforms ) ) {
			foreach ( $transforms as $source_column => $config ) {
				if ( array_key_exists( $source_column, $raw_row ) ) {
					$raw_row[ $source_column ] = APM_Transformer::apply( $raw_row[ $source_column ], $config );
				}
			}
		}

		if ( empty( $mapping ) ) {
			return $raw_row; // Assume native/canonical column names already.
		}

		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$this->set_dotted( $record, $target_field, $raw_row[ $source_column ] );
		}

		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}

		return $record;
	}

	/**
	 * Set a value into a nested array using "acf.material" style dotted
	 * target field notation from the mapping UI.
	 */
	protected function set_dotted( &$array, $dotted_key, $value ) {
		$parts = explode( '.', $dotted_key );
		$ref   = &$array;
		foreach ( $parts as $i => $part ) {
			if ( $i === count( $parts ) - 1 ) {
				$ref[ $part ] = $value;
			} else {
				if ( ! isset( $ref[ $part ] ) || ! is_array( $ref[ $part ] ) ) {
					$ref[ $part ] = array();
				}
				$ref = &$ref[ $part ];
			}
		}
	}

	/**
	 * Process one mapped post record: resolve existing/new, and either
	 * simulate (dry run) or write it.
	 *
	 * @param array $record
	 * @param array $args
	 * @param array $summary (by reference)
	 * @return void
	 */
	protected function process_record( $record, $args, &$summary ) {
		$post_type   = $args['post_type'] ?: 'post';
		$existing_id = $this->find_existing_post( $record, $args['match_strategy'], $post_type );

		if ( $existing_id ) {
			switch ( $args['existing_action'] ) {
				case 'skip':
					$summary['skipped']++;
					return;
				case 'duplicate':
					$existing_id = null; // Fall through to create-new below.
					$summary['duplicated']++;
					break;
				case 'update':
				default:
					$summary['updated']++;
					break;
			}
		} else {
			$summary['new']++;
		}

		// Track taxonomy terms that don't exist yet, for the dry-run report.
		foreach ( (array) ( $record['taxonomies'] ?? array() ) as $taxonomy => $tax_data ) {
			if ( ! empty( $tax_data['hierarchical'] ) ) {
				foreach ( (array) ( $tax_data['terms'] ?? array() ) as $path ) {
					$leaf = is_array( $path ) ? end( $path ) : $path;
					$name = is_array( $leaf ) ? ( $leaf['name'] ?? '' ) : $leaf;
					if ( $name && ! APM_Taxonomy_Handler::resolve_path( $path, $taxonomy, false ) ) {
						$summary['terms_to_create'][] = $name;
					}
				}
			} else {
				foreach ( (array) ( $tax_data['terms'] ?? array() ) as $name ) {
					if ( $name && ! APM_Taxonomy_Handler::resolve_flat_term( $name, $taxonomy, false ) ) {
						$summary['terms_to_create'][] = $name;
					}
				}
			}
		}

		if ( $args['dry_run'] ) {
			$this->log_item( $args, $record, 'success', $existing_id ? 'Would update' : 'Would create' );
			return; // Report-only — nothing written.
		}

		// Real rollback support: snapshot the post's current state before we
		// overwrite it, so a later "Rollback" actually restores it rather
		// than just being a label.
		if ( $existing_id && ! empty( $args['job_id'] ) && ! empty( $args['options']['create_backup'] ) ) {
			APM_Snapshot::capture( $args['job_id'], $existing_id );
		}

		$post_id = $this->write_post( $record, $existing_id, $args['options'], $post_type );

		if ( ! $existing_id && ! empty( $args['job_id'] ) ) {
			APM_Snapshot::record_created( $args['job_id'], $post_id );
		}

		// Maintain the source->target relationship map so a repeated import
		// from the same source always resolves back to the same post, and
		// so ACF relationship/post_object fields referencing this post from
		// another import can be resolved on a future migration.
		$external_id = $record['external_id'] ?? ( $record['post_id'] ?? '' );
		if ( $external_id ) {
			APM_Relationship_Map::set_mapping( 'default', (string) $external_id, $post_id, 'post', (string) $external_id );
		}

		APM_Logger::log( 'info', sprintf( '%s post #%d (%s)', $existing_id ? 'Updated' : 'Created', $post_id, $record['slug'] ?? '' ) );
		$this->log_item( $args, $record, 'success', $existing_id ? 'Updated' : 'Created', $post_id );
	}

	/**
	 * Persist a per-row outcome to wp_apm_import_items when running as a
	 * tracked job (Import Logs / Import Preview screens read this table).
	 */
	protected function log_item( $args, $record, $result, $message, $post_id = null ) {
		if ( empty( $args['job_id'] ) ) {
			return;
		}
		APM_Jobs::add_import_item( $args['job_id'], $args['_row_index'] ?? 0, $record['slug'] ?? '', $post_id, $result, $message );
	}

	/**
	 * @param array  $record
	 * @param string $strategy slug|post_id|external_id|none
	 * @param string $post_type
	 * @return int|null
	 */
	protected function find_existing_post( $record, $strategy, $post_type ) {
		switch ( $strategy ) {
			case 'external_id':
				$external_id = $record['external_id'] ?? '';
				if ( $external_id ) {
					$id = APM_Relationship_Map::resolve( 'default', $external_id, 'post' );
					if ( $id ) {
						return $id;
					}
				}
				return $this->find_existing_post( $record, 'slug', $post_type );

			case 'post_id':
				if ( ! empty( $record['post_id'] ) && get_post_type( $record['post_id'] ) === $post_type ) {
					return (int) $record['post_id'];
				}
				return null;

			case 'slug':
				if ( ! empty( $record['slug'] ) ) {
					$page = get_page_by_path( $record['slug'], OBJECT, $post_type );
					return $page ? $page->ID : null;
				}
				return null;

			case 'none':
			default:
				return null;
		}
	}

	/**
	 * Create or update the WordPress post from a mapped record.
	 *
	 * @param array    $record
	 * @param int|null $existing_id
	 * @param array    $options
	 * @param string   $post_type
	 * @return int Post ID.
	 */
	protected function write_post( $record, $existing_id, $options, $post_type ) {
		$postarr = array(
			'post_type' => $post_type,
		);

		if ( $existing_id ) {
			$postarr['ID'] = $existing_id;
		}

		if ( array_key_exists( 'title', $record ) ) {
			$postarr['post_title'] = $record['title'];
		}
		if ( array_key_exists( 'content', $record ) ) {
			$postarr['post_content'] = $record['content'];
		}
		if ( array_key_exists( 'excerpt', $record ) ) {
			$postarr['post_excerpt'] = $record['excerpt'];
		}
		if ( array_key_exists( 'slug', $record ) && '' !== $record['slug'] ) {
			$postarr['post_name'] = $record['slug'];
		}
		if ( array_key_exists( 'status', $record ) && '' !== $record['status'] ) {
			$postarr['post_status'] = $record['status'];
		}
		if ( array_key_exists( 'date', $record ) && '' !== $record['date'] ) {
			$postarr['post_date'] = $record['date'];
		}
		if ( array_key_exists( 'menu_order', $record ) ) {
			$postarr['menu_order'] = (int) $record['menu_order'];
		}
		if ( array_key_exists( 'comment_status', $record ) && '' !== $record['comment_status'] ) {
			$postarr['comment_status'] = $record['comment_status'];
		}
		if ( array_key_exists( 'ping_status', $record ) && '' !== $record['ping_status'] ) {
			$postarr['ping_status'] = $record['ping_status'];
		}

		$author_id = $this->resolve_author( $record['author'] ?? null );
		if ( $author_id ) {
			$postarr['post_author'] = $author_id;
		}

		if ( is_post_type_hierarchical( $post_type ) && ! empty( $record['parent'] ) ) {
			$postarr['post_parent'] = $this->resolve_parent( $record['parent'] );
		}

		if ( ! $existing_id && empty( $postarr['post_status'] ) ) {
			$postarr['post_status'] = 'draft';
		}

		if ( $existing_id ) {
			$post_id = wp_update_post( $postarr, true );
		} else {
			$post_id = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $post_id ) ) {
			throw new Exception( $post_id->get_error_message() );
		}

		$this->apply_taxonomy( $post_id, $record, $options, $post_type );
		$this->apply_images( $post_id, $record, $options );

		if ( ! empty( $record['acf'] ) ) {
			APM_ACF_Handler::import_fields( $post_id, $record['acf'], $options );
		}
		if ( ! empty( $record['yoast'] ) ) {
			APM_Yoast_Handler::import_fields( $post_id, $record['yoast'] );
		}
		if ( ! empty( $record['custom_meta'] ) ) {
			APM_Meta_Handler::import_meta( $post_id, $record['custom_meta'], array_merge( $options, array( 'post_type' => $post_type ) ) );
		}

		return $post_id;
	}

	/**
	 * Resolve an exported author reference (login/email) to a local user
	 * ID, falling back to the current user when no match is found.
	 *
	 * @param array|null $author { login, email }
	 * @return int|null
	 */
	protected function resolve_author( $author ) {
		if ( empty( $author ) || ! is_array( $author ) ) {
			return null;
		}
		if ( ! empty( $author['login'] ) ) {
			$user = get_user_by( 'login', $author['login'] );
			if ( $user ) {
				return $user->ID;
			}
		}
		if ( ! empty( $author['email'] ) ) {
			$user = get_user_by( 'email', $author['email'] );
			if ( $user ) {
				return $user->ID;
			}
		}
		return get_current_user_id() ?: null;
	}

	/**
	 * Resolve an exported parent reference (slug/external_id) to a local
	 * post ID.
	 *
	 * @param array $parent { slug, external_id }
	 * @return int
	 */
	protected function resolve_parent( $parent ) {
		if ( ! empty( $parent['external_id'] ) ) {
			$id = APM_Relationship_Map::resolve( 'default', $parent['external_id'], 'post' );
			if ( $id ) {
				return $id;
			}
		}
		if ( ! empty( $parent['slug'] ) ) {
			$page = get_page_by_path( $parent['slug'] );
			if ( $page ) {
				return $page->ID;
			}
		}
		return 0;
	}

	/**
	 * Apply every taxonomy registered for this post type: hierarchical
	 * taxonomies resolve each exported path (creating missing levels as
	 * configured), flat taxonomies resolve each name.
	 */
	protected function apply_taxonomy( $post_id, $record, $options, $post_type ) {
		if ( ! isset( $record['taxonomies'] ) || ! is_array( $record['taxonomies'] ) ) {
			return;
		}

		$create_missing = $options['create_missing_taxonomy_terms'] ?? true;

		foreach ( get_object_taxonomies( $post_type ) as $taxonomy ) {
			if ( ! isset( $record['taxonomies'][ $taxonomy ] ) ) {
				continue;
			}
			$tax_data = $record['taxonomies'][ $taxonomy ];
			$term_ids = array();

			if ( ! empty( $tax_data['hierarchical'] ) ) {
				foreach ( (array) ( $tax_data['terms'] ?? array() ) as $path ) {
					$id = APM_Taxonomy_Handler::resolve_path( $path, $taxonomy, $create_missing );
					if ( $id ) {
						$term_ids[] = $id;
					}
				}
			} else {
				foreach ( (array) ( $tax_data['terms'] ?? array() ) as $name ) {
					$id = APM_Taxonomy_Handler::resolve_flat_term( $name, $taxonomy, $create_missing );
					if ( $id ) {
						$term_ids[] = $id;
					}
				}
			}

			wp_set_object_terms( $post_id, $term_ids, $taxonomy, false );
		}
	}

	protected function apply_images( $post_id, $record, $options ) {
		if ( ! empty( $record['featured_image'] ) ) {
			$id = APM_Image_Handler::resolve_attachment( $record['featured_image'], $options );
			if ( $id ) {
				set_post_thumbnail( $post_id, $id );
			}
		}
	}

	/* ---------------------------------------------------------------
	 * Preview — read the first N rows, apply mapping, and report what
	 * WOULD happen (create/update/skip + key fields) without touching the
	 * database at all. This is what backs the wizard's preview table; it
	 * reuses find_existing_post() (read-only) so the create/update verdict
	 * shown here is the exact same logic the real import uses.
	 * ------------------------------------------------------------- */

	/**
	 * @param array $args   Same shape as import()/start_job().
	 * @param int   $limit  Rows to preview.
	 * @return array|WP_Error List of preview rows.
	 */
	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$post_type = $args['post_type'] ?? 'post';
		$rows      = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview   = array();

		foreach ( $rows as $raw_row ) {
			$record      = $this->apply_mapping( $raw_row, $args['mapping'] ?? array(), $args['format'], $args['transforms'] ?? array() );
			$existing_id = $this->find_existing_post( $record, $args['match_strategy'] ?? 'slug', $post_type );

			$tax_summary = array();
			foreach ( (array) ( $record['taxonomies'] ?? array() ) as $taxonomy => $tax_data ) {
				foreach ( (array) ( $tax_data['terms'] ?? array() ) as $path ) {
					$leaf          = is_array( $path ) ? end( $path ) : $path;
					$tax_summary[] = is_array( $leaf ) ? ( $leaf['name'] ?? '' ) : $leaf;
				}
			}

			$preview[] = array(
				'title'       => $record['title'] ?? '',
				'slug'        => $record['slug'] ?? '',
				'status'      => $record['status'] ?? '',
				'taxonomies'  => implode( ', ', array_filter( $tax_summary ) ),
				'has_image'   => ! empty( $record['featured_image'] ),
				'has_acf'     => ! empty( $record['acf'] ),
				'has_yoast'   => ! empty( $record['yoast'] ),
				'meta_count'  => count( (array) ( $record['custom_meta'] ?? array() ) ),
				'result'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $this->quick_validate( $record ),
			);
		}

		return $preview;
	}

	/**
	 * Cheap, read-only sanity checks for the preview table — flags rows
	 * the real import would likely fail or warn on, before anything is
	 * written.
	 */
	protected function quick_validate( $record ) {
		$issues = array();
		if ( empty( $record['slug'] ) && empty( $record['title'] ) ) {
			$issues[] = __( 'No slug or title — row may be unusable.', 'advanced-post-migrator' );
		}
		if ( ! empty( $record['status'] ) && ! in_array( $record['status'], array( 'publish', 'draft', 'pending', 'private', 'future' ), true ) ) {
			$issues[] = __( 'Unrecognized post status.', 'advanced-post-migrator' );
		}
		return $issues;
	}
}
