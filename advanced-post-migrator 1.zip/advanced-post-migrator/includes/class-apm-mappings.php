<?php
/**
 * APM_Mappings
 *
 * CRUD for saved mapping/export profiles (wp_apm_mappings). A profile
 * bundles field mapping + transforms + import/export options into a named,
 * reusable config — "Vayati Full Product Import" etc. — so repeat
 * migrations are a single click.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Mappings {

	public static function create( $name, $type, $config ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'apm_mappings',
			array(
				'name'       => sanitize_text_field( $name ),
				'type'       => in_array( $type, array( 'import', 'export' ), true ) ? $type : 'import',
				'config'     => wp_json_encode( $config ),
				'created_by' => get_current_user_id(),
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function update( $id, $name, $config ) {
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'apm_mappings',
			array(
				'name'       => sanitize_text_field( $name ),
				'config'     => wp_json_encode( $config ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}apm_mappings WHERE id = %d", $id ), ARRAY_A );
		if ( $row ) {
			$row['config'] = json_decode( $row['config'], true ) ?: array();
		}
		return $row;
	}

	public static function all( $type = '' ) {
		global $wpdb;
		if ( $type ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}apm_mappings WHERE type = %s ORDER BY name ASC", $type ), ARRAY_A );
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}apm_mappings ORDER BY name ASC", ARRAY_A );
		}
		foreach ( $rows as &$row ) {
			$row['config'] = json_decode( $row['config'], true ) ?: array();
		}
		return $rows;
	}

	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'apm_mappings', array( 'id' => $id ), array( '%d' ) );
	}

	public static function duplicate( $id, $new_name ) {
		$row = self::get( $id );
		if ( ! $row ) {
			return null;
		}
		return self::create( $new_name, $row['type'], $row['config'] );
	}

	/**
	 * Export a mapping profile as a portable JSON string (for the
	 * "Export mapping" / "Import mapping" spec requirement).
	 */
	public static function export_json( $id ) {
		$row = self::get( $id );
		return $row ? wp_json_encode( array( 'name' => $row['name'], 'type' => $row['type'], 'config' => $row['config'] ), JSON_PRETTY_PRINT ) : null;
	}

	public static function import_json( $json ) {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) || empty( $data['name'] ) || empty( $data['config'] ) ) {
			return new WP_Error( 'apm_invalid_mapping_json', __( 'Invalid mapping file.', 'advanced-post-migrator' ) );
		}
		return self::create( $data['name'], $data['type'] ?? 'import', $data['config'] );
	}
}
