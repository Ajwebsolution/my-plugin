<?php
/**
 * APM_Taxonomy_Importer
 *
 * Creates/updates terms of ANY registered taxonomy from CSV/JSON/XLSX,
 * independent of any post import. Hierarchy resolution/creation reuses
 * APM_Taxonomy_Handler::resolve_path() — the exact same logic the Post
 * importer already relies on for hierarchical taxonomies, so a
 * re-imported path matches existing branches level-by-level instead of
 * duplicating them. Mirrors APM_Post_Importer's shape.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Taxonomy_Importer {

	protected function read_rows( $file_path, $format ) {
		switch ( $format ) {
			case 'json':
				return APM_JSON_Handler::read( $file_path );
			case 'xlsx':
				return APM_XLSX_Handler::read( $file_path );
			case 'csv':
			default:
				return APM_CSV_Handler::read( $file_path );
		}
	}

	public function start_job( $args ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$job_id = APM_Jobs::create_import_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'taxonomies',
				'file_path'   => $args['file_path'],
				'format'      => $args['format'],
				'mapping'     => $args['mapping'] ?? array(),
				'options'     => array(
					'existing_action'        => $args['existing_action'] ?? 'update',
					'match_strategy'         => $args['match_strategy'] ?? 'slug',
					'default_taxonomy'       => $args['default_taxonomy'] ?? 'category',
					'create_missing_parents' => array_key_exists( 'create_missing_parents', $args ) ? ! empty( $args['create_missing_parents'] ) : true,
				),
				'dry_run'     => ! empty( $args['dry_run'] ) ? 1 : 0,
				'batch_size'  => ! empty( $args['batch_size'] ) ? (int) $args['batch_size'] : 50,
				'total_rows'  => count( $rows ),
			)
		);

		APM_Logger::set_run_id( 'apm_run_job_' . $job_id, 'import', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = APM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'apm_job_not_found', __( 'Import job not found.', 'advanced-post-migrator' ) );
		}
		if ( in_array( $job['status'], array( 'completed', 'failed', 'rolled_back' ), true ) ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$rows = $this->read_rows( $job['file_path'], $job['format'] );
		if ( is_wp_error( $rows ) ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			return $rows;
		}

		$offset  = (int) $job['offset_row'];
		$batch   = array_slice( $rows, $offset, (int) $job['batch_size'] );
		$options = $job['options'];

		$created = 0; $updated = 0; $skipped = 0; $failed = 0;

		foreach ( $batch as $i => $raw_row ) {
			$row_index = $offset + $i;
			try {
				$record = $this->apply_mapping( $raw_row, $job['mapping'] );
				$result = $this->process_record( $record, $options, (bool) $job['dry_run'] );
				if ( 'created' === $result['verdict'] ) { $created++; }
				elseif ( 'updated' === $result['verdict'] ) { $updated++; }
				else { $skipped++; }
				APM_Jobs::add_import_item( $job_id, $row_index, $record['name'] ?? '', $result['id'] ?? null, 'success', $result['message'] );
			} catch ( Exception $e ) {
				$failed++;
				APM_Jobs::add_import_item( $job_id, $row_index, '', null, 'error', $e->getMessage() );
			}
		}

		APM_Jobs::increment_import_counts( $job_id, $created, $updated, $skipped, $failed, count( $batch ) );

		$new_offset = $offset + count( $batch );
		$done       = $new_offset >= (int) $job['total_rows'] || empty( $batch );

		if ( $done ) {
			APM_Jobs::update_import_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			APM_Logger::log( 'info', sprintf( 'Taxonomies import job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => APM_Jobs::get_import_job( $job_id ) );
	}

	protected function apply_mapping( $raw_row, $mapping ) {
		if ( empty( $mapping ) ) {
			return $raw_row;
		}
		$record = array();
		foreach ( $mapping as $source_column => $target_field ) {
			if ( '' === $target_field || ! array_key_exists( $source_column, $raw_row ) ) {
				continue;
			}
			$record[ $target_field ] = $raw_row[ $source_column ];
		}
		foreach ( $raw_row as $key => $value ) {
			if ( ! isset( $mapping[ $key ] ) && ! isset( $record[ $key ] ) ) {
				$record[ $key ] = $value;
			}
		}
		return $record;
	}

	/**
	 * Existing-term lookup WITHOUT creating anything — used both for the
	 * "skip existing" check and for the preview table, so what preview
	 * shows is the same logic the real import uses, never a separate guess.
	 */
	protected function find_existing_term( $record, $strategy, $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return 0;
		}

		if ( 'external_id' === $strategy && ! empty( $record['external_id'] ) ) {
			$id = APM_Relationship_Map::resolve( 'default', $taxonomy . ':' . $record['external_id'], 'term' );
			if ( $id && get_term( $id, $taxonomy ) && ! is_wp_error( get_term( $id, $taxonomy ) ) ) {
				return (int) $id;
			}
		}

		$tax_obj = get_taxonomy( $taxonomy );
		if ( $tax_obj && $tax_obj->hierarchical ) {
			$path = ! empty( $record['path'] ) ? $record['path'] : ( $record['name'] ?? '' );
			$id   = APM_Taxonomy_Handler::resolve_path( $path, $taxonomy, false );
			return $id ? (int) $id : 0;
		}

		// Flat taxonomy — match by slug first (stable across renames), then name.
		if ( ! empty( $record['slug'] ) ) {
			$term = get_term_by( 'slug', $record['slug'], $taxonomy );
			if ( $term ) {
				return (int) $term->term_id;
			}
		}
		if ( ! empty( $record['name'] ) ) {
			$term = get_term_by( 'name', $record['name'], $taxonomy );
			if ( $term ) {
				return (int) $term->term_id;
			}
		}
		return 0;
	}

	protected function process_record( $record, $options, $dry_run ) {
		$taxonomy = ! empty( $record['taxonomy'] ) && taxonomy_exists( $record['taxonomy'] )
			? $record['taxonomy']
			: ( $options['default_taxonomy'] ?? 'category' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			throw new Exception( sprintf( __( 'Taxonomy "%s" is not registered on this site.', 'advanced-post-migrator' ), $taxonomy ) );
		}

		if ( empty( $record['name'] ) && empty( $record['path'] ) ) {
			throw new Exception( __( 'A name (or hierarchy path) is required to import a taxonomy term.', 'advanced-post-migrator' ) );
		}

		$strategy    = $options['match_strategy'] ?? 'slug';
		$existing_id = $this->find_existing_term( $record, $strategy, $taxonomy );

		if ( $existing_id && 'skip' === ( $options['existing_action'] ?? 'update' ) ) {
			return array( 'verdict' => 'skipped', 'id' => $existing_id, 'message' => __( 'Term already exists — skipped.', 'advanced-post-migrator' ) );
		}

		if ( $dry_run ) {
			return array(
				'verdict' => $existing_id ? 'updated' : 'created',
				'id'      => $existing_id,
				'message' => $existing_id ? __( 'Would update existing term.', 'advanced-post-migrator' ) : __( 'Would create new term (and any missing parent levels).', 'advanced-post-migrator' ),
			);
		}

		$create_missing = array_key_exists( 'create_missing_parents', $options ) ? ! empty( $options['create_missing_parents'] ) : true;
		$tax_obj        = get_taxonomy( $taxonomy );

		if ( $tax_obj && $tax_obj->hierarchical ) {
			$path    = ! empty( $record['path'] ) ? $record['path'] : ( $record['name'] ?? '' );
			$term_id = APM_Taxonomy_Handler::resolve_path( $path, $taxonomy, true );
			if ( ! $term_id ) {
				throw new Exception( __( 'Could not create or resolve this term.', 'advanced-post-migrator' ) );
			}
		} else {
			$term_id = $existing_id;
			if ( ! $term_id ) {
				if ( ! $create_missing ) {
					throw new Exception( __( 'Term does not exist and "create missing" is disabled.', 'advanced-post-migrator' ) );
				}
				$inserted = wp_insert_term( $record['name'], $taxonomy, ! empty( $record['slug'] ) ? array( 'slug' => $record['slug'] ) : array() );
				if ( is_wp_error( $inserted ) ) {
					throw new Exception( $inserted->get_error_message() );
				}
				$term_id = $inserted['term_id'];
			}
		}

		// Update the leaf term's own name/slug/description — never touched
		// for a brand-new term just created above, only for an existing match.
		if ( $existing_id && 'update' === ( $options['existing_action'] ?? 'update' ) ) {
			$update_args = array();
			if ( isset( $record['description'] ) ) {
				$update_args['description'] = $record['description'];
			}
			if ( ! empty( $record['name'] ) ) {
				$update_args['name'] = $record['name'];
			}
			if ( $update_args ) {
				wp_update_term( $term_id, $taxonomy, $update_args );
			}
		} elseif ( ! $existing_id && isset( $record['description'] ) && $record['description'] ) {
			wp_update_term( $term_id, $taxonomy, array( 'description' => $record['description'] ) );
		}

		$external_id = $record['external_id'] ?? ( $record['term_id'] ?? '' );
		if ( $external_id ) {
			update_term_meta( $term_id, '_apm_external_id', $external_id );
			APM_Relationship_Map::set_mapping( 'default', $taxonomy . ':' . $external_id, $term_id, 'term', $taxonomy . ':' . $external_id );
		}

		return array(
			'verdict' => $existing_id ? 'updated' : 'created',
			'id'      => $term_id,
			'message' => $existing_id ? __( 'Updated existing term.', 'advanced-post-migrator' ) : __( 'Created new term.', 'advanced-post-migrator' ),
		);
	}

	public function preview_rows( $args, $limit = 20 ) {
		$rows = $this->read_rows( $args['file_path'], $args['format'] );
		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		$rows    = array_slice( $rows, 0, max( 1, (int) $limit ) );
		$preview = array();
		$default_taxonomy = $args['default_taxonomy'] ?? 'category';

		foreach ( $rows as $raw_row ) {
			$record      = $this->apply_mapping( $raw_row, $args['mapping'] ?? array() );
			$taxonomy    = ! empty( $record['taxonomy'] ) && taxonomy_exists( $record['taxonomy'] ) ? $record['taxonomy'] : $default_taxonomy;
			$existing_id = $this->find_existing_term( $record, $args['match_strategy'] ?? 'slug', $taxonomy );

			$issues = array();
			if ( empty( $record['name'] ) && empty( $record['path'] ) ) {
				$issues[] = __( 'Missing name/path.', 'advanced-post-migrator' );
			}
			if ( ! taxonomy_exists( $taxonomy ) ) {
				$issues[] = sprintf( __( 'Taxonomy "%s" is not registered.', 'advanced-post-migrator' ), $taxonomy );
			}

			$path_display = '';
			if ( ! empty( $record['path'] ) && is_array( $record['path'] ) ) {
				$path_display = implode( ' > ', array_map( function ( $step ) { return is_array( $step ) ? ( $step['name'] ?? '' ) : $step; }, $record['path'] ) );
			} elseif ( ! empty( $record['path'] ) ) {
				$path_display = (string) $record['path'];
			}

			$preview[] = array(
				'name'        => $record['name'] ?? ( $path_display ?: '' ),
				'slug'        => $record['slug'] ?? '',
				'taxonomy'    => $taxonomy,
				'path'        => $path_display,
				'count'       => (int) ( $record['count'] ?? 0 ),
				'result'      => $existing_id ? 'will_update' : 'will_create',
				'existing_id' => $existing_id,
				'issues'      => $issues,
			);
		}

		return $preview;
	}
}
