<?php
/**
 * APM_System_Status
 *
 * Real environment introspection — every value below is read live from PHP/
 * WordPress, not hardcoded. Backs Settings -> System Status and the
 * dashboard's status strip. No WooCommerce or any other plugin dependency.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_System_Status {

	public static function get_report() {
		global $wpdb;

		$memory_limit = self::to_bytes( ini_get( 'memory_limit' ) );
		$exec_time    = (int) ini_get( 'max_execution_time' );

		return array(
			'plugin_version'      => APM_VERSION,
			'wordpress_version'   => get_bloginfo( 'version' ),
			'php_version'         => PHP_VERSION,
			'php_status'          => version_compare( PHP_VERSION, '8.0', '>=' ) ? 'good' : ( version_compare( PHP_VERSION, APM_MIN_PHP, '>=' ) ? 'warning' : 'critical' ),
			'mysql_version'       => $wpdb->db_version(),
			'acf_active'          => APM_ACF_Handler::is_active(),
			'acf_pro'             => defined( 'ACF_PRO' ) && ACF_PRO,
			'acf_version'         => defined( 'ACF_VERSION' ) ? ACF_VERSION : null,
			'yoast_active'        => APM_Yoast_Handler::is_active(),
			'yoast_version'       => APM_Yoast_Handler::get_version(),
			'rest_api_enabled'    => true, // WP core REST is always available >= 4.7.
			'memory_limit'        => ini_get( 'memory_limit' ),
			'memory_status'       => $memory_limit >= 256 * MB_IN_BYTES ? 'good' : ( $memory_limit >= 128 * MB_IN_BYTES ? 'warning' : 'critical' ),
			'max_execution_time'  => $exec_time,
			'exec_time_status'    => ( 0 === $exec_time || $exec_time >= 300 ) ? 'good' : ( $exec_time >= 60 ? 'warning' : 'critical' ),
			'upload_max_filesize' => ini_get( 'upload_max_filesize' ),
			'post_max_size'       => ini_get( 'post_max_size' ),
			'curl_available'      => function_exists( 'curl_init' ),
			'zip_available'       => class_exists( 'ZipArchive' ),
			'wp_debug'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'multisite'           => is_multisite(),
			'active_theme'        => wp_get_theme()->get( 'Name' ),
			'registered_post_types' => array_keys( get_post_types( array( 'public' => true ) ) ),
			'integrations'        => self::detect_integrations(),
		);
	}

	/**
	 * Dynamically detected third-party integrations relevant to post data
	 * (never hardcoded).
	 */
	public static function detect_integrations() {
		$integrations = array();

		$integrations['ACF'] = array(
			'detected' => APM_ACF_Handler::is_active(),
			'version'  => defined( 'ACF_VERSION' ) ? ACF_VERSION : null,
			'supported'=> true,
		);
		$integrations['Yoast SEO'] = array(
			'detected' => APM_Yoast_Handler::is_active(),
			'version'  => APM_Yoast_Handler::get_version(),
			'supported'=> true,
		);
		$integrations['WooCommerce'] = array(
			'detected' => class_exists( 'WooCommerce' ),
			'version'  => defined( 'WC_VERSION' ) ? WC_VERSION : null,
			'supported'=> false, // APM migrates posts/pages/custom post types — use Advanced Woo Product Migrator for WooCommerce products.
		);

		/**
		 * Let other plugins declare themselves as detected/supported
		 * integrations without APM needing to know about them in advance.
		 */
		return apply_filters( 'apm_detected_integrations', $integrations );
	}

	/**
	 * Plain-text report for the "Copy System Report" button.
	 */
	public static function as_text() {
		$r    = self::get_report();
		$lines = array(
			'### Advanced Post Migrator — System Report ###',
			'Plugin Version: ' . $r['plugin_version'],
			'WordPress: ' . $r['wordpress_version'],
			'PHP: ' . $r['php_version'],
			'MySQL: ' . $r['mysql_version'],
			'ACF: ' . ( $r['acf_active'] ? ( $r['acf_pro'] ? 'Pro ' : '' ) . $r['acf_version'] : 'not detected' ),
			'Yoast SEO: ' . ( $r['yoast_active'] ? $r['yoast_version'] : 'not detected' ),
			'Memory Limit: ' . $r['memory_limit'],
			'Max Execution Time: ' . $r['max_execution_time'],
			'Upload Max Filesize: ' . $r['upload_max_filesize'],
			'Post Max Size: ' . $r['post_max_size'],
			'cURL: ' . ( $r['curl_available'] ? 'yes' : 'no' ),
			'ZipArchive: ' . ( $r['zip_available'] ? 'yes' : 'no' ),
			'Multisite: ' . ( $r['multisite'] ? 'yes' : 'no' ),
			'Active Theme: ' . $r['active_theme'],
			'Registered Public Post Types: ' . implode( ', ', $r['registered_post_types'] ),
		);
		return implode( "\n", $lines );
	}

	protected static function to_bytes( $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return 0;
		}
		$last  = strtolower( $value[ strlen( $value ) - 1 ] );
		$num   = (int) $value;
		switch ( $last ) {
			case 'g': $num *= 1024;
			case 'm': $num *= 1024;
			case 'k': $num *= 1024;
		}
		return $num;
	}
}
