<?php
/**
 * APM_Snapshot
 *
 * Real rollback support: before an existing post is updated, its full core
 * post fields (get_post()), all postmeta (get_post_meta()), and its current
 * terms per taxonomy are serialized into wp_apm_snapshots keyed to the
 * import job. Rolling back a job restores every "update" snapshot via
 * wp_update_post() for core fields, per-key update_post_meta()/
 * delete_post_meta() to restore the exact prior meta state, and
 * wp_set_object_terms() to restore the prior terms (never deletes
 * production data), and safely trash-deletes posts that were newly
 * "created" by that job. This is exactly what the spec requires: "For
 * updated posts: restore snapshot rather than deleting the post. Do NOT
 * blindly delete existing production data."
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Snapshot {

	/**
	 * Snapshot a post's current state before it gets overwritten by an
	 * update. No-op (and returns false) for a brand-new post, since
	 * there's nothing to roll back to but deletion — which the importer
	 * tracks separately via the import_items 'created' record.
	 *
	 * @param int $job_id
	 * @param int $post_id
	 * @return bool
	 */
	public static function capture( $job_id, $post_id ) {
		$post = get_post( $post_id, ARRAY_A );
		if ( ! $post ) {
			return false;
		}

		global $wpdb;

		$meta = get_post_meta( $post_id );
		// get_post_meta() without a key returns key => array_of_values (each
		// serialized value already unserialized); keep the raw multi-value
		// shape so a repeated meta key restores exactly, not just its first value.
		$meta_data = array();
		foreach ( $meta as $key => $values ) {
			$meta_data[ $key ] = $values;
		}

		$terms = array();
		foreach ( get_object_taxonomies( $post['post_type'] ) as $taxonomy ) {
			$term_ids = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $term_ids ) ) {
				$terms[ $taxonomy ] = $term_ids;
			}
		}

		$data = array(
			'post'  => $post,
			'meta'  => $meta_data,
			'terms' => $terms,
		);

		$settings = get_option( 'apm_settings', array() );
		$days     = ! empty( $settings['snapshot_retention_days'] ) ? (int) $settings['snapshot_retention_days'] : 14;

		$wpdb->insert(
			$wpdb->prefix . 'apm_snapshots',
			array(
				'job_id'     => $job_id,
				'post_id'    => $post_id,
				'action'     => 'update',
				'snapshot'   => wp_json_encode( $data ),
				'created_at' => current_time( 'mysql' ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $days * DAY_IN_SECONDS ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s' )
		);

		return true;
	}

	/**
	 * Record that a post was newly created by this job (so rollback knows
	 * it's safe to remove, unlike an "update" snapshot).
	 */
	public static function record_created( $job_id, $post_id ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'apm_snapshots',
			array(
				'job_id'     => $job_id,
				'post_id'    => $post_id,
				'action'     => 'create',
				'snapshot'   => wp_json_encode( array() ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s' )
		);
	}

	/**
	 * Roll back every snapshot recorded for a job: restore "update"
	 * snapshots, trash "create" snapshots. Returns a summary.
	 *
	 * @param int $job_id
	 * @return array { restored, trashed, errors }
	 */
	public static function rollback_job( $job_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}apm_snapshots WHERE job_id = %d ORDER BY id ASC", $job_id ), ARRAY_A );

		$summary = array( 'restored' => 0, 'trashed' => 0, 'errors' => array() );

		foreach ( $rows as $row ) {
			try {
				if ( 'create' === $row['action'] ) {
					if ( get_post( $row['post_id'] ) ) {
						wp_delete_post( $row['post_id'], false ); // Trash, not force-delete — recoverable, never a hard destroy.
						$summary['trashed']++;
					}
				} else {
					$data = json_decode( $row['snapshot'], true );
					if ( ! is_array( $data ) || empty( $data['post'] ) ) {
						continue;
					}
					if ( ! get_post( $row['post_id'] ) ) {
						continue;
					}

					$post_arr = $data['post'];
					$post_arr['ID'] = (int) $row['post_id'];
					unset( $post_arr['post_modified'], $post_arr['post_modified_gmt'], $post_arr['guid'] );

					wp_update_post( $post_arr, true );

					// Restore postmeta to exactly the prior state: delete any
					// key added since, then rewrite every prior key/value.
					$prior_meta  = (array) ( $data['meta'] ?? array() );
					$current_all = get_post_meta( $row['post_id'] );
					foreach ( array_keys( $current_all ) as $key ) {
						if ( ! array_key_exists( $key, $prior_meta ) ) {
							delete_post_meta( $row['post_id'], $key );
						}
					}
					foreach ( $prior_meta as $key => $values ) {
						delete_post_meta( $row['post_id'], $key );
						foreach ( (array) $values as $value ) {
							add_post_meta( $row['post_id'], $key, maybe_unserialize( $value ) );
						}
					}

					// Restore prior taxonomy terms per taxonomy.
					$prior_terms = (array) ( $data['terms'] ?? array() );
					foreach ( $prior_terms as $taxonomy => $term_ids ) {
						if ( taxonomy_exists( $taxonomy ) ) {
							wp_set_object_terms( $row['post_id'], array_map( 'intval', $term_ids ), $taxonomy, false );
						}
					}

					$summary['restored']++;
				}
			} catch ( Exception $e ) {
				$summary['errors'][] = sprintf( 'Post #%d: %s', $row['post_id'], $e->getMessage() );
			}
		}

		APM_Jobs::update_import_job( $job_id, array( 'status' => 'rolled_back' ) );
		APM_Logger::log( 'info', sprintf( 'Rollback of job #%d: %d restored, %d trashed', $job_id, $summary['restored'], $summary['trashed'] ) );

		return $summary;
	}

	/**
	 * Purge expired snapshots. Hooked to a daily cron event — "Do not
	 * create unlimited snapshots."
	 */
	public static function prune_expired() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->prefix}apm_snapshots WHERE expires_at IS NOT NULL AND expires_at < NOW()" ); // phpcs:ignore
	}
}
