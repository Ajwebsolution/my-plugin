<?php
/**
 * APM_CSV_Handler
 *
 * CSV is a flat format; our post export records are not. Rather than lossily
 * flattening repeaters into numbered columns (repeater_0_material,
 * repeater_1_material, ... which breaks the moment row counts differ
 * between products and produces enormous sparse sheets), each column
 * holds either a plain scalar OR a JSON string for anything structured
 * (attributes, categories, gallery, ACF repeater/flexible content/
 * gallery/relationship). This keeps the sheet readable for the 90% of
 * columns that are plain text/numbers while still being 100% lossless for
 * nested data — a cell either round-trips as a string or as a JSON blob
 * that import_row() decodes back into the same nested structure.
 *
 * XLSX export/import follows the same row shape and can be produced with
 * the same rows via a spreadsheet library (e.g. PhpSpreadsheet) on the
 * live WordPress host — see readme.txt for wiring it in via Composer.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_CSV_Handler {

	/**
	 * Flatten one export record (as produced by APM_Post_Exporter)
	 * into a single associative row: column => cell value.
	 *
	 * ACF, Yoast and custom-meta sub-arrays are exploded into their own
	 * top-level columns (acf_<name>, <yoast_key>, <raw_meta_key>) rather
	 * than nested under one 'acf'/'yoast'/'custom_meta' JSON blob column.
	 * This is what lets the mapping UI show "ACF → Material" as its own
	 * row instead of one opaque "acf" column, and it's exactly the naming
	 * convention the importer's auto-mapping heuristic already expects
	 * (acf_* / yoast_* / underscore-prefixed columns). A field whose value
	 * is itself structured (an ACF repeater, for instance) still lands in
	 * its own single column as a JSON string — still one column, still
	 * losslessly round-trippable, just named after the field instead of
	 * the container.
	 *
	 * @param array $record
	 * @return array
	 */
	public static function flatten_record( $record ) {
		$row = array();
		foreach ( $record as $key => $value ) {
			if ( 'acf' === $key && is_array( $value ) ) {
				foreach ( $value as $sub_key => $sub_value ) {
					$row[ 'acf_' . $sub_key ] = self::cell_value( $sub_value );
				}
				continue;
			}
			if ( 'yoast' === $key && is_array( $value ) ) {
				foreach ( $value as $sub_key => $sub_value ) {
					$row[ $sub_key ] = self::cell_value( $sub_value ); // Yoast keys already read "yoast_title" etc.
				}
				continue;
			}
			if ( 'custom_meta' === $key && is_array( $value ) ) {
				foreach ( $value as $sub_key => $sub_value ) {
					$row[ $sub_key ] = self::cell_value( $sub_value ); // Raw meta key, e.g. "_supplier_code".
				}
				continue;
			}
			$row[ $key ] = self::cell_value( $value );
		}
		return $row;
	}

	protected static function cell_value( $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			return wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		}
		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}
		return (string) $value;
	}

	/**
	 * Write an array of export records to a CSV file. Column set is the
	 * union of all keys across all records (products of different types
	 * won't share every column, e.g. simple vs. variable).
	 *
	 * @param array  $records
	 * @param string $file_path
	 * @return bool
	 */
	public static function write( $records, $file_path ) {
		$rows = array_map( array( __CLASS__, 'flatten_record' ), $records );

		$columns = array();
		foreach ( $rows as $row ) {
			$columns = array_merge( $columns, array_keys( $row ) );
		}
		$columns = array_values( array_unique( $columns ) );

		$fh = fopen( $file_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			return false;
		}

		// UTF-8 BOM so Excel opens accented/unicode text correctly.
		fwrite( $fh, "\xEF\xBB\xBF" );
		fputcsv( $fh, $columns );

		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = $row[ $col ] ?? '';
			}
			fputcsv( $fh, $line );
		}

		fclose( $fh );
		return true;
	}

	/**
	 * Read a CSV file into an array of raw rows (column => string value),
	 * decoding any JSON-looking cells back into arrays.
	 *
	 * @param string $file_path
	 * @return array[]|WP_Error
	 */
	public static function read( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'apm_file_missing', __( 'CSV file not found.', 'advanced-post-migrator' ) );
		}

		$fh = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			return new WP_Error( 'apm_file_unreadable', __( 'Could not open CSV file.', 'advanced-post-migrator' ) );
		}

		// Strip UTF-8 BOM if present.
		$bom = fread( $fh, 3 );
		if ( "\xEF\xBB\xBF" !== $bom ) {
			rewind( $fh );
		}

		$header = fgetcsv( $fh );
		if ( ! $header ) {
			fclose( $fh );
			return new WP_Error( 'apm_empty_csv', __( 'CSV file has no header row.', 'advanced-post-migrator' ) );
		}

		$rows = array();
		while ( ( $data = fgetcsv( $fh ) ) !== false ) {
			$row = array();
			foreach ( $header as $i => $col ) {
				$raw = $data[ $i ] ?? '';
				$row[ $col ] = self::maybe_decode( $raw );
			}
			$rows[] = $row;
		}

		fclose( $fh );
		return $rows;
	}

	/**
	 * Return just the header row (for building the mapping UI).
	 *
	 * @param string $file_path
	 * @return string[]|WP_Error
	 */
	public static function read_header( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'apm_file_missing', __( 'CSV file not found.', 'advanced-post-migrator' ) );
		}
		$fh  = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$bom = fread( $fh, 3 );
		if ( "\xEF\xBB\xBF" !== $bom ) {
			rewind( $fh );
		}
		$header = fgetcsv( $fh );
		fclose( $fh );
		return $header ?: array();
	}

	protected static function maybe_decode( $raw ) {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return $raw;
		}
		$first = $raw[0];
		if ( '{' === $first || '[' === $first ) {
			$decoded = json_decode( $raw, true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				return $decoded;
			}
		}
		return $raw;
	}
}
