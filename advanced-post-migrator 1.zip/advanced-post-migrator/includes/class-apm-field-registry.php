<?php
/**
 * APM_Field_Registry
 *
 * Builds the full catalogue of fields available for export selection and
 * import mapping: core WordPress Post fields, ACF fields (recursively,
 * incl. repeater/flexible content sub-fields), Yoast SEO fields, and raw/
 * custom post meta discovered by scanning real posts.
 *
 * This is what powers the "SOURCE FIELD -> TARGET FIELD" mapping UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Field_Registry {

	/**
	 * Core WordPress Post fields, grouped, with a stable "key" used
	 * throughout the exporter/importer to address the field.
	 *
	 * @return array
	 */
	public static function get_core_fields() {
		return array(
			'general' => array(
				'id'            => __( 'Post ID', 'advanced-post-migrator' ),
				'external_id'   => __( 'External ID (source system business ID)', 'advanced-post-migrator' ),
				'title'         => __( 'Title', 'advanced-post-migrator' ),
				'slug'          => __( 'Slug', 'advanced-post-migrator' ),
				'content'       => __( 'Content', 'advanced-post-migrator' ),
				'excerpt'       => __( 'Excerpt', 'advanced-post-migrator' ),
				'status'        => __( 'Status', 'advanced-post-migrator' ),
				'author'        => __( 'Author', 'advanced-post-migrator' ),
				'date'          => __( 'Date', 'advanced-post-migrator' ),
				'modified'      => __( 'Modified Date', 'advanced-post-migrator' ),
				'parent'        => __( 'Parent (hierarchical post types)', 'advanced-post-migrator' ),
				'menu_order'    => __( 'Menu Order', 'advanced-post-migrator' ),
				'comment_status' => __( 'Comment Status', 'advanced-post-migrator' ),
				'ping_status'   => __( 'Ping Status', 'advanced-post-migrator' ),
			),
			'taxonomy'  => array(
				'taxonomies' => __( 'Categories, Tags & Other Taxonomies', 'advanced-post-migrator' ),
			),
			'images'    => array(
				'featured_image' => __( 'Featured Image', 'advanced-post-migrator' ),
			),
		);
	}

	/**
	 * Fields for the standalone Taxonomies entity (Categories, Tags, and
	 * any other taxonomy registered for the selected post type). The
	 * 'path' field carries the full "Parent > Child" ancestor chain for
	 * hierarchical taxonomies so hierarchy round-trips; for flat
	 * taxonomies it's just the term's own name.
	 *
	 * @return array
	 */
	public static function get_taxonomy_fields() {
		return array(
			'general' => array(
				'term_id'      => __( 'Term ID', 'advanced-post-migrator' ),
				'external_id'  => __( 'External ID', 'advanced-post-migrator' ),
				'taxonomy'     => __( 'Taxonomy', 'advanced-post-migrator' ),
				'name'         => __( 'Name', 'advanced-post-migrator' ),
				'slug'         => __( 'Slug', 'advanced-post-migrator' ),
				'description'  => __( 'Description', 'advanced-post-migrator' ),
				'path'         => __( 'Full Hierarchy Path (hierarchical taxonomies only)', 'advanced-post-migrator' ),
				'count'        => __( 'Post Count', 'advanced-post-migrator' ),
			),
		);
	}

	/**
	 * Discover every ACF field group/field relevant to the selected post
	 * type (location rule: Post Type == $post_type, or a group with no
	 * location restriction, included defensively).
	 *
	 * Returns a flat list of field definitions with dotted "selector" keys
	 * such as: specifications (repeater) -> specifications.material
	 *
	 * @param string $post_type Post type to resolve ACF field groups for.
	 * @return array
	 */
	public static function get_acf_fields( $post_type = 'post' ) {
		if ( ! function_exists( 'acf_get_field_groups' ) ) {
			return array();
		}

		$groups = acf_get_field_groups( array( 'post_type' => $post_type ) );
		// Fall back to ALL groups if location targeting can't be resolved
		// (some setups use complex/OR location logic acf_get_field_groups
		// won't match against a bare post_type argument).
		if ( empty( $groups ) ) {
			$groups = acf_get_field_groups();
		}

		$fields = array();

		foreach ( $groups as $group ) {
			$group_fields = function_exists( 'acf_get_fields' ) ? acf_get_fields( $group['key'] ) : array();
			foreach ( (array) $group_fields as $field ) {
				$fields = array_merge( $fields, self::flatten_acf_field( $field, $group['title'] ) );
			}
		}

		return $fields;
	}

	/**
	 * Recursively flatten an ACF field (and sub_fields for repeater / group,
	 * and layouts/sub_fields for flexible_content) into a list of
	 * { selector, label, type, group } entries used by the mapping UI.
	 *
	 * The "selector" here is the dotted path passed straight to ACF's own
	 * get_field()/update_field() — ACF understands "repeater_name" as a
	 * whole (returns array of rows); we expose sub-selectors purely for
	 * display/mapping convenience in CSV mode, where each repeater row's
	 * sub-field can be targeted individually.
	 *
	 * @param array  $field ACF field array.
	 * @param string $group_label Parent field group title, for display grouping.
	 * @param string $prefix Dotted selector prefix (for nested calls).
	 * @return array
	 */
	protected static function flatten_acf_field( $field, $group_label, $prefix = '' ) {
		$selector = $prefix ? $prefix . '.' . $field['name'] : $field['name'];

		$entry = array(
			'selector' => $selector,
			'name'     => $field['name'],
			'key'      => $field['key'],
			'label'    => $field['label'],
			'type'     => $field['type'],
			'group'    => $group_label,
		);

		$out = array( $entry );

		if ( in_array( $field['type'], array( 'repeater', 'group' ), true ) && ! empty( $field['sub_fields'] ) ) {
			foreach ( $field['sub_fields'] as $sub ) {
				$out = array_merge( $out, self::flatten_acf_field( $sub, $group_label, $selector ) );
			}
		}

		if ( 'flexible_content' === $field['type'] && ! empty( $field['layouts'] ) ) {
			foreach ( $field['layouts'] as $layout ) {
				if ( empty( $layout['sub_fields'] ) ) {
					continue;
				}
				$layout_prefix = $selector . '.' . $layout['name'];
				foreach ( $layout['sub_fields'] as $sub ) {
					$out = array_merge( $out, self::flatten_acf_field( $sub, $group_label, $layout_prefix ) );
				}
			}
		}

		return $out;
	}

	/**
	 * Yoast SEO field map: our internal key => Yoast's actual postmeta key.
	 * Centralized here (rather than hardcoded scattered constants) so it's
	 * the single configurable source the spec asks for.
	 *
	 * @return array
	 */
	public static function get_yoast_field_map() {
		/**
		 * Filterable so site owners can add/rename keys for custom Yoast
		 * add-ons or future Yoast schema changes without touching code.
		 */
		return apply_filters(
			'apm_yoast_field_map',
			array(
				'yoast_title'        => '_yoast_wpseo_title',
				'yoast_metadesc'     => '_yoast_wpseo_metadesc',
				'yoast_focuskw'      => '_yoast_wpseo_focuskw',
				'yoast_linkdex'      => '_yoast_wpseo_linkdex',
				'yoast_canonical'    => '_yoast_wpseo_canonical',
				'yoast_meta_robots_noindex'  => '_yoast_wpseo_meta-robots-noindex',
				'yoast_meta_robots_nofollow' => '_yoast_wpseo_meta-robots-nofollow',
				'yoast_opengraph_title'   => '_yoast_wpseo_opengraph-title',
				'yoast_opengraph_desc'    => '_yoast_wpseo_opengraph-description',
				'yoast_opengraph_image'   => '_yoast_wpseo_opengraph-image',
				'yoast_twitter_title'     => '_yoast_wpseo_twitter-title',
				'yoast_twitter_desc'      => '_yoast_wpseo_twitter-description',
				'yoast_twitter_image'     => '_yoast_wpseo_twitter-image',
			)
		);
	}

	/**
	 * Scan a sample of real posts' postmeta to build a list of "unknown"
	 * custom meta keys the exporter should surface for include/exclude/
	 * rename/map decisions. Internal/reserved keys (_edit_lock, ACF's own
	 * "_fieldname" key-reference rows, Yoast keys, core WP meta) are
	 * excluded since those are handled by their own dedicated systems.
	 *
	 * @param int    $sample_size Number of posts to sample.
	 * @param string $post_type   Post type to sample. Default 'post'.
	 * @return array List of meta_key => example value.
	 */
	public static function discover_custom_meta_keys( $sample_size = 100, $post_type = 'post' ) {
		global $wpdb;

		$excluded_exact = APM_Meta_Handler::reserved_keys( $post_type );

		$post_ids = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => 'any',
				'posts_per_page' => $sample_size,
				'fields'         => 'ids',
				'orderby'        => 'rand',
			)
		);

		if ( empty( $post_ids ) ) {
			return array();
		}

		$ids_sql = implode( ',', array_map( 'intval', $post_ids ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $ids_sql is int-cast above.
		$rows = $wpdb->get_results( "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$ids_sql})" );

		$discovered = array();

		foreach ( $rows as $row ) {
			$key = $row->meta_key;

			if ( isset( $discovered[ $key ] ) ) {
				continue;
			}
			if ( in_array( $key, $excluded_exact, true ) ) {
				continue;
			}
			// ACF stores a shadow "_field_name" reference row per field; skip those,
			// ACF's own field data (by real field name) is handled by the ACF handler.
			if ( 0 === strpos( $key, '_' ) && function_exists( 'acf_get_field' ) ) {
				$maybe_field_key = get_post_meta( $post_ids[0], $key, true );
				if ( is_string( $maybe_field_key ) && 0 === strpos( $maybe_field_key, 'field_' ) ) {
					continue;
				}
			}

			$discovered[ $key ] = $row->meta_value;
		}

		return $discovered;
	}
}
