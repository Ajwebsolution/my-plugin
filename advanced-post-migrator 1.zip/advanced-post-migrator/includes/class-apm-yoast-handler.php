<?php
/**
 * APM_Yoast_Handler
 *
 * Detects Yoast SEO and exports/imports the meta keys defined in
 * APM_Field_Registry::get_yoast_field_map(). Deliberately meta-key-driven
 * (not a fixed set of hardcoded fields) so new Yoast keys can be added via
 * the `apm_yoast_field_map` filter without touching this class.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Yoast_Handler {

	/**
	 * Is Yoast SEO (free or Premium) active?
	 *
	 * @return bool
	 */
	public static function is_active() {
		return defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' );
	}

	/**
	 * @return string|null Installed Yoast version, if detectable.
	 */
	public static function get_version() {
		return defined( 'WPSEO_VERSION' ) ? WPSEO_VERSION : null;
	}

	/**
	 * Export all mapped Yoast meta for a product.
	 *
	 * @param int $post_id
	 * @return array internal_key => value (only keys with a non-empty value).
	 */
	public static function export_fields( $post_id ) {
		if ( ! self::is_active() ) {
			return array();
		}

		$map = APM_Field_Registry::get_yoast_field_map();
		$out = array();

		foreach ( $map as $internal_key => $meta_key ) {
			$value = get_post_meta( $post_id, $meta_key, true );
			if ( '' !== $value && null !== $value ) {
				$out[ $internal_key ] = $value;
			}
		}

		return $out;
	}

	/**
	 * Import mapped Yoast fields onto a product.
	 *
	 * @param int   $post_id
	 * @param array $data internal_key => value.
	 * @return void
	 */
	public static function import_fields( $post_id, $data ) {
		if ( ! self::is_active() || empty( $data ) || ! is_array( $data ) ) {
			return;
		}

		$map = APM_Field_Registry::get_yoast_field_map();

		foreach ( $data as $internal_key => $value ) {
			if ( ! isset( $map[ $internal_key ] ) ) {
				continue; // Unknown key (e.g. exported from a newer plugin version) — skip safely.
			}
			update_post_meta( $post_id, $map[ $internal_key ], $value );
		}

		// Yoast keeps a readability/SEO "linkdex" score cache; invalidate it so
		// it's recalculated rather than showing a stale score from the source site.
		delete_post_meta( $post_id, '_yoast_wpseo_content_score' );
	}
}
