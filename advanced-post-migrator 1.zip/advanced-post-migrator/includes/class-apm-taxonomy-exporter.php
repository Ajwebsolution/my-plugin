<?php
/**
 * APM_Taxonomy_Exporter
 *
 * Exports terms from ANY registered taxonomy (categories, tags, and any
 * custom taxonomy) as a standalone, independent dataset — not tied to any
 * one post export. Reuses APM_Taxonomy_Handler's own export_term_path()
 * logic (already battle-tested by the Post exporter/importer's taxonomy
 * handling) so hierarchy is captured and later rebuilt the same way it
 * already is for posts. Mirrors APM_Post_Exporter's export()/start_job()/
 * process_next_batch() shape.
 *
 * A term's id is exported/consumed as a composite "taxonomy:term_id"
 * string (e.g. "category:12") rather than a bare int, because WordPress
 * term IDs are only unique per-taxonomy — two different taxonomies can
 * (rarely, after a term split) share the same term_id.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Taxonomy_Exporter {

	/**
	 * @param array $args {
	 *     @type string $format       csv|xlsx|json
	 *     @type string $post_type    Restrict the taxonomy list to this post type's registered taxonomies. Empty = all public taxonomies.
	 *     @type array  $taxonomies   subset of taxonomy names; empty = every taxonomy registered for $post_type (or every public taxonomy)
	 *     @type array  $term_ids     composite "taxonomy:id" strings — exact terms to export
	 *     @type string $search       term name/slug search
	 *     @type bool   $include_empty default true — include terms with 0 posts
	 *     @type int    $limit
	 *     @type int    $offset
	 * }
	 */
	public function export( $args ) {
		$args   = $this->parse_args( $args );
		$run_id = APM_Logger::start_run();

		$term_ids = $this->resolve_term_ids( $args );
		if ( empty( $term_ids ) ) {
			return new WP_Error( 'apm_no_terms', __( 'No taxonomy terms matched the export criteria.', 'advanced-post-migrator' ) );
		}

		$records = array();
		foreach ( $term_ids as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );

		$write_true_xlsx = 'xlsx' === $args['format'] && APM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename        = 'apm-export-taxonomies-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path       = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = APM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = APM_XLSX_Handler::write( $records, $file_path );
		} else {
			$ok = APM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'apm_write_failed', __( 'Could not write export file.', 'advanced-post-migrator' ) );
		}

		return array(
			'file_path'    => $file_path,
			'file_url'     => trailingslashit( $upload_dir['baseurl'] ) . 'apm-tmp/' . $filename,
			'record_count' => count( $records ),
			'run_id'       => $run_id,
		);
	}

	public function start_job( $args ) {
		$args = $this->parse_args( $args );

		$term_ids = $this->resolve_term_ids( $args );
		if ( empty( $term_ids ) ) {
			return new WP_Error( 'apm_no_terms', __( 'No taxonomy terms matched the export criteria.', 'advanced-post-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = APM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => 'taxonomies',
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_ids' => $term_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $term_ids ),
			)
		);

		$xlsx_ok  = 'xlsx' === $args['format'] && APM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename  = 'apm-export-taxonomies-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		APM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'apm-tmp/' . $filename ) );

		APM_Logger::set_run_id( 'apm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = APM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'apm_job_not_found', __( 'Export job not found.', 'advanced-post-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			APM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$ids    = $job['args']['_ids'] ?? array();
		$offset = (int) $job['offset_row'];
		$batch  = array_slice( $ids, $offset, (int) $job['batch_size'] );

		$records = array();
		foreach ( $batch as $id ) {
			$record = $this->build_record( $id );
			if ( $record ) {
				$records[] = $record;
			}
		}

		APM_Exporter_File_Writer::append( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch ) ) >= count( $ids ), 'records' );

		APM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch ) ) >= count( $ids ) || empty( $batch );

		if ( $done ) {
			APM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			APM_Logger::log( 'info', sprintf( 'Taxonomies export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => APM_Jobs::get_export_job( $job_id ) );
	}

	protected function parse_args( $args ) {
		return wp_parse_args(
			$args,
			array(
				'format'        => 'json',
				'post_type'     => '',
				'taxonomies'    => array(),
				'term_ids'      => array(),
				'search'        => '',
				'include_empty' => true,
				'limit'         => 0,
				'offset'        => 0,
				'batch_size'    => 50,
			)
		);
	}

	/**
	 * The taxonomy list to export from: an explicit list, or every taxonomy
	 * registered for the given post type, or (with no post type) every
	 * public taxonomy on the site.
	 *
	 * @param array $args
	 * @return string[]
	 */
	protected function resolve_taxonomies( $args ) {
		if ( ! empty( $args['taxonomies'] ) ) {
			return array_values( (array) $args['taxonomies'] );
		}
		if ( ! empty( $args['post_type'] ) ) {
			return get_object_taxonomies( $args['post_type'] );
		}
		return array_keys( get_taxonomies( array( 'public' => true ) ) );
	}

	protected function resolve_term_ids( $args ) {
		if ( ! empty( $args['term_ids'] ) ) {
			return array_values( (array) $args['term_ids'] );
		}

		$taxonomies = $this->resolve_taxonomies( $args );

		$ids = array();
		foreach ( $taxonomies as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}
			$query_args = array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => empty( $args['include_empty'] ),
				'fields'     => 'ids',
			);
			if ( ! empty( $args['search'] ) ) {
				$query_args['search'] = $args['search'];
			}
			$terms = get_terms( $query_args );
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			foreach ( $terms as $term_id ) {
				$ids[] = $taxonomy . ':' . $term_id;
			}
		}

		if ( ! empty( $args['offset'] ) ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	/**
	 * @param string $composite_id "taxonomy:term_id", e.g. "category:12".
	 */
	public function build_record( $composite_id ) {
		list( $taxonomy, $term_id ) = array_pad( explode( ':', (string) $composite_id, 2 ), 2, '' );
		$term_id = (int) $term_id;
		if ( ! $taxonomy || ! $term_id ) {
			return null;
		}

		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return null;
		}

		$tax_obj = get_taxonomy( $taxonomy );
		$path    = ( $tax_obj && $tax_obj->hierarchical )
			? APM_Taxonomy_Handler::export_term_path( $term_id, $taxonomy )
			: array( array( 'id' => $term->term_id, 'slug' => $term->slug, 'name' => $term->name ) );

		return array(
			'source_site' => site_url(),
			'term_id'     => $term_id,
			'external_id' => get_term_meta( $term_id, '_apm_external_id', true ) ?: ( $taxonomy . ':' . $term_id ),
			'taxonomy'    => $taxonomy,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'description' => $term->description,
			'path'        => $path,
			'count'       => (int) $term->count,
		);
	}
}
