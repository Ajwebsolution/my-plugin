<?php
/**
 * APM_Tools
 *
 * Real implementations behind the Tools menu — each one actually scans/
 * validates/generates against the live site, none are placeholders.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Tools {

	public static function scan_post_meta( $post_type = 'post' ) {
		return APM_Field_Registry::discover_custom_meta_keys( 300, $post_type );
	}

	public static function scan_acf_fields( $post_type = 'post' ) {
		return APM_Field_Registry::get_acf_fields( $post_type );
	}

	public static function scan_taxonomies( $post_type = 'post' ) {
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );
		$out = array();
		foreach ( $taxonomies as $tax ) {
			$out[] = array(
				'name'         => $tax->name,
				'label'        => $tax->label,
				'hierarchical' => $tax->hierarchical,
				'term_count'   => wp_count_terms( array( 'taxonomy' => $tax->name, 'hide_empty' => false ) ),
			);
		}
		return $out;
	}

	public static function scan_post_types() {
		$types = get_post_types( array( 'public' => true ), 'objects' );
		$out   = array();
		foreach ( $types as $slug => $obj ) {
			$counts = wp_count_posts( $slug );
			$out[ $slug ] = array(
				'label' => $obj->labels->singular_name,
				'count' => (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ),
			);
		}
		return $out;
	}

	public static function find_duplicate_slugs( $post_type = 'post' ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_name as slug, COUNT(*) as cnt, GROUP_CONCAT(ID) as post_ids
				FROM {$wpdb->posts}
				WHERE post_type = %s AND post_status IN ('publish','draft','pending') AND post_name != ''
				GROUP BY post_name
				HAVING cnt > 1
				ORDER BY cnt DESC
				LIMIT 200",
				$post_type
			),
			ARRAY_A
		);
		return $rows;
	}

	/**
	 * Validate post data across the site: missing slug, broken parent
	 * reference, missing taxonomy terms, broken featured image reference.
	 */
	public static function validate_post_data( $post_type = 'post', $limit = 500 ) {
		$issues = array();

		$post_ids = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => $limit,
				'fields'         => 'ids',
			)
		);

		foreach ( $post_ids as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post ) {
				continue;
			}

			if ( ! $post->post_name ) {
				$issues[] = array( 'post_id' => $post_id, 'type' => 'missing_slug', 'message' => __( 'Post has no slug.', 'advanced-post-migrator' ) );
			}

			if ( $post->post_parent && get_post( $post->post_parent ) === null ) {
				$issues[] = array( 'post_id' => $post_id, 'type' => 'broken_parent', 'message' => __( 'Parent post reference is broken.', 'advanced-post-migrator' ) );
			}

			$image_id = get_post_thumbnail_id( $post_id );
			if ( $image_id && ! wp_get_attachment_url( $image_id ) ) {
				$issues[] = array( 'post_id' => $post_id, 'type' => 'broken_image', 'message' => __( 'Featured image attachment is missing.', 'advanced-post-migrator' ) );
			}

			$has_any_terms = false;
			foreach ( get_object_taxonomies( $post_type ) as $taxonomy ) {
				if ( has_term( '', $taxonomy, $post_id ) ) {
					$has_any_terms = true;
					break;
				}
			}
			if ( ! $has_any_terms && ! empty( get_object_taxonomies( $post_type ) ) ) {
				$issues[] = array( 'post_id' => $post_id, 'type' => 'no_terms', 'message' => __( 'Post has no taxonomy terms assigned.', 'advanced-post-migrator' ) );
			}
		}

		return $issues;
	}

	public static function clear_temp_files() {
		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		$count      = 0;
		foreach ( glob( trailingslashit( $tmp_dir ) . 'apm-*' ) ?: array() as $file ) {
			if ( is_file( $file ) && @unlink( $file ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$count++;
			}
		}
		return $count;
	}

	public static function rebuild_relationship_map() {
		return APM_Relationship_Map::rebuild();
	}

	/**
	 * Attempt to repair a job left in "running" state (e.g. server crash
	 * mid-batch) by nudging it forward one more batch and re-checking.
	 */
	public static function repair_import_job( $job_id ) {
		$job = APM_Jobs::get_import_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'apm_job_not_found', __( 'Job not found.', 'advanced-post-migrator' ) );
		}
		if ( 'running' !== $job['status'] && 'pending' !== $job['status'] ) {
			return new WP_Error( 'apm_job_not_repairable', __( 'Only pending/running jobs can be repaired.', 'advanced-post-migrator' ) );
		}
		$importer = new APM_Post_Importer();
		return $importer->process_next_batch( $job_id );
	}

	/**
	 * Generate a self-contained sample JSON export covering every data
	 * category the plugin supports (core fields, hierarchical + flat
	 * taxonomies, featured image, ACF incl. repeater/flexible content,
	 * Yoast, custom meta) — purely synthetic, no real site data — so the
	 * importer can be exercised end-to-end on a fresh install.
	 *
	 * @return array File path/url of the generated sample.
	 */
	public static function generate_sample_export() {
		$sample = array(
			array(
				'source_site' => 'sample-generator',
				'post_id'     => 0,
				'external_id' => 'sample-001',
				'post_type'   => 'post',
				'title'       => 'Sample Post: Getting Started',
				'slug'        => 'sample-post-getting-started',
				'content'     => '<p>This is a sample post generated for testing the importer. It exercises core fields, taxonomies, ACF and Yoast.</p>',
				'excerpt'     => 'A sample post for testing the importer.',
				'status'      => 'draft',
				'author'      => array( 'login' => 'admin', 'email' => '' ),
				'date'        => gmdate( 'Y-m-d H:i:s' ),
				'menu_order'  => 0,
				'comment_status' => 'open',
				'ping_status'    => 'open',
				'parent'      => null,
				'taxonomies'  => array(
					'category' => array(
						'hierarchical' => true,
						'terms'        => array( array( array( 'slug' => 'news', 'name' => 'News' ), array( 'slug' => 'announcements', 'name' => 'Announcements' ) ) ),
					),
					'post_tag' => array(
						'hierarchical' => false,
						'terms'        => array( 'sample', 'demo' ),
					),
				),
				'featured_image' => null,
				'acf' => array(
					'subtitle'      => 'A sample subtitle',
					'specifications' => array(
						array( 'label' => 'Reading time', 'value' => '2 minutes' ),
						array( 'label' => 'Category', 'value' => 'Demo' ),
					),
				),
				'yoast' => array(
					'yoast_title'    => 'Sample Post | Example Site',
					'yoast_metadesc' => 'A sample post for testing the Advanced Post Migrator importer.',
				),
				'custom_meta' => array( '_supplier_code' => 'SUPP-001', '_demo_flag' => '1' ),
			),
			array(
				'source_site' => 'sample-generator',
				'post_id'     => 0,
				'external_id' => 'sample-002',
				'post_type'   => 'post',
				'title'       => 'Sample Post: Second Example',
				'slug'        => 'sample-post-second-example',
				'content'     => '<p>A second sample post, with a different set of taxonomy terms.</p>',
				'excerpt'     => '',
				'status'      => 'draft',
				'author'      => array( 'login' => 'admin', 'email' => '' ),
				'date'        => gmdate( 'Y-m-d H:i:s' ),
				'menu_order'  => 1,
				'comment_status' => 'open',
				'ping_status'    => 'open',
				'parent'      => null,
				'taxonomies'  => array(
					'category' => array(
						'hierarchical' => true,
						'terms'        => array( array( array( 'slug' => 'news', 'name' => 'News' ) ) ),
					),
					'post_tag' => array(
						'hierarchical' => false,
						'terms'        => array( 'sample' ),
					),
				),
				'featured_image' => null,
				'custom_meta' => array( '_demo_flag' => '1' ),
			),
		);

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );
		$file_path = trailingslashit( $tmp_dir ) . 'apm-sample-export-' . gmdate( 'Y-m-d-His' ) . '.json';
		APM_JSON_Handler::write( $sample, $file_path );

		return array(
			'file_path' => $file_path,
			'file_url'  => trailingslashit( $upload_dir['baseurl'] ) . 'apm-tmp/' . basename( $file_path ),
		);
	}
}
