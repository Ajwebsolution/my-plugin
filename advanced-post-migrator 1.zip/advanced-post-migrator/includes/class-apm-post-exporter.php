<?php
/**
 * APM_Post_Exporter
 *
 * Builds the full, structured export record for a WordPress post of any
 * selected post type, pulling core fields, every registered taxonomy,
 * featured image, ACF, Yoast and custom meta together, then writes the
 * whole set out via the CSV, XLSX or JSON handler.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Post_Exporter {

	/**
	 * Field-selection config from the wizard's Step 4 (field mapping)
	 * screen, set once per export() / start_job() call and read by
	 * apply_field_selection() inside build_record(). Empty means "export
	 * everything".
	 *
	 * @var array
	 */
	protected $field_config = array();

	/**
	 * @param array $args {
	 *     @type string   $format      csv|xlsx|json
	 *     @type string   $post_type   Any public post type. Default 'post'.
	 *     @type string   $selection   all|selected|ids|slugs|taxonomy
	 *     @type array    $post_ids
	 *     @type array    $slugs
	 *     @type string   $taxonomy    Taxonomy name, when selection = taxonomy.
	 *     @type array    $terms       Term slugs/ids, when selection = taxonomy.
	 *     @type string   $status      publish|draft|pending|private|any
	 *     @type string   $date_created_after   Y-m-d.
	 *     @type string   $date_created_before  Y-m-d.
	 *     @type string   $date_modified_after  Y-m-d.
	 *     @type string   $date_modified_before Y-m-d.
	 *     @type array    $meta_rules  Passed straight through to APM_Meta_Handler::export_meta().
	 * }
	 * @return array { file_path, file_url, record_count }|WP_Error
	 */
	public function export( $args ) {
		$args = wp_parse_args( $args, $this->default_args() );

		$this->field_config = $args['field_config'];

		$run_id = APM_Logger::start_run();

		$post_ids = $this->resolve_post_ids( $args );
		if ( empty( $post_ids ) ) {
			return new WP_Error( 'apm_no_posts', __( 'No posts matched the export criteria.', 'advanced-post-migrator' ) );
		}

		$records = array();
		foreach ( $post_ids as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post ) {
				continue;
			}
			$records[] = $this->build_record( $post, $args['meta_rules'] );
			APM_Logger::log( 'info', sprintf( 'Exported post #%d (%s)', $post_id, $post->post_title ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );

		// True .xlsx needs the ZipArchive PHP extension (bundled with PHP by
		// default, but not universally enabled on every host) — fall back to
		// CSV with an explicit log entry rather than silently mislabeling a
		// CSV file as .xlsx.
		$write_true_xlsx = 'xlsx' === $args['format'] && APM_XLSX_Handler::is_available();
		$file_ext        = 'xlsx' === $args['format'] && ! $write_true_xlsx ? 'csv' : $args['format'];
		$filename         = 'apm-export-' . gmdate( 'Y-m-d-His' ) . '.' . $file_ext;
		$file_path        = trailingslashit( $tmp_dir ) . $filename;

		if ( 'json' === $args['format'] ) {
			$ok = APM_JSON_Handler::write( $records, $file_path );
		} elseif ( $write_true_xlsx ) {
			$ok = APM_XLSX_Handler::write( $records, $file_path );
		} else {
			if ( 'xlsx' === $args['format'] ) {
				APM_Logger::log( 'warning', 'ZipArchive PHP extension not available — XLSX export was written as CSV instead.' );
			}
			$ok = APM_CSV_Handler::write( $records, $file_path );
		}

		if ( ! $ok ) {
			return new WP_Error( 'apm_write_failed', __( 'Could not write export file.', 'advanced-post-migrator' ) );
		}

		return array(
			'file_path'    => $file_path,
			'file_url'     => trailingslashit( $upload_dir['baseurl'] ) . 'apm-tmp/' . $filename,
			'record_count' => count( $records ),
			'run_id'       => $run_id,
		);
	}

	protected function default_args() {
		return array(
			'format'       => 'json',
			'post_type'    => 'post',
			'selection'    => 'all',
			'post_ids'     => array(),
			'slugs'        => array(),
			'taxonomy'     => '',
			'terms'        => array(),
			'status'       => 'any',
			'date_created_after'   => '',
			'date_created_before'  => '',
			'date_modified_after'  => '',
			'date_modified_before' => '',
			'meta_rules'   => array( 'mode' => 'export_all' ),
			'field_config' => array(),
			'limit'        => 0,
			'offset'       => 0,
			'title_search' => array(),
			'exclude_titles' => array(),
			'exclude_ids'  => array(),
		);
	}

	/* ---------------------------------------------------------------
	 * Batch/background job processing for large sets of posts — post
	 * IDs are resolved once up front (cheap — it's just a list of IDs),
	 * then records are built and appended to the export file batch_size
	 * at a time so memory stays flat regardless of how many posts exist.
	 * ------------------------------------------------------------- */

	public function start_job( $args ) {
		$args = wp_parse_args( $args, array_merge( $this->default_args(), array( 'batch_size' => 50 ) ) );

		$post_ids = $this->resolve_post_ids( $args );
		if ( empty( $post_ids ) ) {
			return new WP_Error( 'apm_no_posts', __( 'No posts matched the export criteria.', 'advanced-post-migrator' ) );
		}

		$upload_dir = wp_upload_dir();
		$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
		wp_mkdir_p( $tmp_dir );

		$job_id = APM_Jobs::create_export_job(
			array(
				'status'      => 'pending',
				'entity_type' => $args['post_type'],
				'format'      => $args['format'],
				'args'        => array_merge( $args, array( '_post_ids' => $post_ids ) ),
				'batch_size'  => (int) $args['batch_size'],
				'total_rows'  => count( $post_ids ),
			)
		);

		// Seed the (initially empty) JSON array file / CSV header so batches
		// can append. For true XLSX, the final file only gets assembled on
		// the last batch (see append_records_to_file()) — a ZIP archive's
		// central directory can't be incrementally appended to the way a
		// CSV/JSON file can — so the extension here reflects what the
		// FINISHED file will be, not what exists on disk mid-job.
		$xlsx_ok  = 'xlsx' === $args['format'] && APM_XLSX_Handler::is_available();
		$file_ext = 'xlsx' === $args['format'] && ! $xlsx_ok ? 'csv' : $args['format'];
		$filename  = 'apm-export-job-' . $job_id . '.' . $file_ext;
		$file_path = trailingslashit( $tmp_dir ) . $filename;
		APM_Jobs::update_export_job( $job_id, array( 'file_path' => $file_path, 'file_url' => trailingslashit( $upload_dir['baseurl'] ) . 'apm-tmp/' . $filename ) );

		APM_Logger::set_run_id( 'apm_run_export_job_' . $job_id, 'export', $job_id );
		return $job_id;
	}

	public function process_next_batch( $job_id ) {
		$job = APM_Jobs::get_export_job( $job_id );
		if ( ! $job ) {
			return new WP_Error( 'apm_job_not_found', __( 'Export job not found.', 'advanced-post-migrator' ) );
		}
		if ( 'completed' === $job['status'] ) {
			return array( 'done' => true, 'job' => $job );
		}
		if ( 'pending' === $job['status'] ) {
			APM_Jobs::update_export_job( $job_id, array( 'status' => 'running', 'started_at' => current_time( 'mysql' ) ) );
		}

		$post_ids = $job['args']['_post_ids'] ?? array();
		$offset   = (int) $job['offset_row'];
		$batch_ids = array_slice( $post_ids, $offset, (int) $job['batch_size'] );

		try {
			$records = array();
			foreach ( $batch_ids as $post_id ) {
				$post = get_post( $post_id );
				if ( $post ) {
					$this->field_config = $job['args']['field_config'] ?? array();
					$records[] = $this->build_record( $post, $job['args']['meta_rules'] ?? array( 'mode' => 'export_all' ) );
				}
			}

			$this->append_records_to_file( $job['file_path'], $job['format'], $records, 0 === $offset, ( $offset + count( $batch_ids ) ) >= count( $post_ids ) );
		} catch ( Exception $e ) {
			APM_Jobs::update_export_job( $job_id, array( 'status' => 'failed', 'finished_at' => current_time( 'mysql' ) ) );
			APM_Logger::log( 'error', sprintf( 'Export job #%d failed: %s', $job_id, $e->getMessage() ) );
			return new WP_Error( 'apm_export_batch_failed', $e->getMessage() );
		}

		APM_Jobs::update_export_job(
			$job_id,
			array(
				'offset_row'      => $offset + count( $batch_ids ),
				'processed_count' => (int) $job['processed_count'] + count( $records ),
			)
		);

		$done = ( $offset + count( $batch_ids ) ) >= count( $post_ids ) || empty( $batch_ids );

		if ( $done ) {
			APM_Jobs::update_export_job( $job_id, array( 'status' => 'completed', 'finished_at' => current_time( 'mysql' ) ) );
			APM_Logger::log( 'info', sprintf( 'Export job #%d complete.', $job_id ) );
		}

		return array( 'done' => $done, 'job' => APM_Jobs::get_export_job( $job_id ) );
	}

	/**
	 * Append a batch of records to the export file, streaming rather than
	 * holding the whole export in memory. JSON is appended as raw array
	 * elements between the wrapper's opening/closing brackets (written on
	 * the first/last batch); CSV appends rows after writing the header on
	 * the first batch (column set is taken from the first batch). XLSX
	 * can't be appended to incrementally the way CSV/JSON can (a ZIP
	 * archive's central directory has to be finalized in one go), so rows
	 * are staged in an NDJSON scratch file batch-by-batch and only
	 * assembled into a real .xlsx on the final batch.
	 */
	protected function append_records_to_file( $file_path, $format, $records, $is_first_batch, $is_last_batch ) {
		if ( 'json' === $format ) {
			$fh = fopen( $file_path, $is_first_batch ? 'w' : 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $is_first_batch ) {
				fwrite( $fh, '{"generator":"Advanced Post Migrator","version":"' . APM_VERSION . '","records":[' );
			}
			foreach ( $records as $i => $record ) {
				if ( ! $is_first_batch || $i > 0 ) {
					fwrite( $fh, ',' );
				}
				fwrite( $fh, wp_json_encode( $record, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
			}
			if ( $is_last_batch ) {
				fwrite( $fh, ']}' );
			}
			fclose( $fh );
			return;
		}

		if ( 'xlsx' === $format && APM_XLSX_Handler::is_available() ) {
			$scratch_path  = $file_path . '.scratch.ndjson';
			$rows          = array_map( array( 'APM_CSV_Handler', 'flatten_record' ), $records );
			$columns_key   = 'apm_export_job_columns_' . basename( $file_path );

			if ( $is_first_batch ) {
				$columns = array();
				foreach ( $rows as $row ) {
					$columns = array_merge( $columns, array_keys( $row ) );
				}
				$columns = array_values( array_unique( $columns ) );
				update_option( $columns_key, $columns, false );
				$sfh = fopen( $scratch_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			} else {
				$columns = get_option( $columns_key, array() );
				$sfh     = fopen( $scratch_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}

			foreach ( $rows as $row ) {
				$line = array();
				foreach ( $columns as $col ) {
					$line[] = $row[ $col ] ?? '';
				}
				fwrite( $sfh, wp_json_encode( $line ) . "\n" );
			}
			fclose( $sfh );

			if ( $is_last_batch ) {
				APM_XLSX_Handler::write_from_ndjson( $scratch_path, $columns, $file_path );
				@unlink( $scratch_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				delete_option( $columns_key );
			}
			return;
		}

		// CSV (also the fallback for xlsx when ZipArchive isn't available —
		// $file_path already carries a .csv extension in that case, set by
		// start_job()): build rows for this batch, write header + rows on
		// the first batch, append rows thereafter.
		$rows = array_map( array( 'APM_CSV_Handler', 'flatten_record' ), $records );
		if ( $is_first_batch ) {
			$columns = array();
			foreach ( $rows as $row ) {
				$columns = array_merge( $columns, array_keys( $row ) );
			}
			$columns = array_values( array_unique( $columns ) );
			update_option( 'apm_export_job_columns_' . basename( $file_path ), $columns, false );

			$fh = fopen( $file_path, 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fwrite( $fh, "\xEF\xBB\xBF" );
			fputcsv( $fh, $columns );
		} else {
			$columns = get_option( 'apm_export_job_columns_' . basename( $file_path ), array() );
			$fh      = fopen( $file_path, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $columns as $col ) {
				$line[] = $row[ $col ] ?? '';
			}
			fputcsv( $fh, $line );
		}
		fclose( $fh );

		if ( $is_last_batch ) {
			delete_option( 'apm_export_job_columns_' . basename( $file_path ) );
		}
	}

	/**
	 * Resolve the selection criteria to a flat list of post IDs.
	 *
	 * @param array $args
	 * @return int[]
	 */
	protected function resolve_post_ids( $args ) {
		$ids = $this->resolve_base_selection( $args );
		$ids = $this->apply_cross_filters( $ids, $args );

		if ( ! empty( $args['offset'] ) && (int) $args['offset'] > 0 ) {
			$ids = array_slice( $ids, (int) $args['offset'] );
		}
		if ( ! empty( $args['limit'] ) && (int) $args['limit'] > 0 ) {
			$ids = array_slice( $ids, 0, (int) $args['limit'] );
		}

		return $ids;
	}

	/**
	 * The primary targeting query.
	 *
	 * @param array $args
	 * @return int[]
	 */
	protected function resolve_base_selection( $args ) {
		$post_type = $args['post_type'] ?: 'post';

		if ( 'ids' === $args['selection'] && ! empty( $args['post_ids'] ) ) {
			return array_map( 'absint', $args['post_ids'] );
		}

		if ( 'slugs' === $args['selection'] && ! empty( $args['slugs'] ) ) {
			$ids = array();
			foreach ( $args['slugs'] as $slug ) {
				$post = get_page_by_path( $slug, OBJECT, $post_type );
				if ( $post ) {
					$ids[] = $post->ID;
				}
			}
			return $ids;
		}

		$query_args = array(
			'post_type'      => $post_type,
			'post_status'    => 'any' === $args['status'] ? array( 'publish', 'draft', 'pending', 'private' ) : array( $args['status'] ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);

		if ( 'taxonomy' === $args['selection'] && ! empty( $args['taxonomy'] ) && ! empty( $args['terms'] ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => $args['taxonomy'],
					'field'    => is_numeric( reset( $args['terms'] ) ) ? 'term_id' : 'slug',
					'terms'    => $args['terms'],
				),
			);
		}
		if ( 'selected' === $args['selection'] && ! empty( $args['post_ids'] ) ) {
			$query_args['post__in'] = array_map( 'absint', $args['post_ids'] );
		}

		return get_posts( $query_args );
	}

	/**
	 * Secondary narrowing filters that apply on top of whatever the
	 * primary selection returned, regardless of which selection mode was
	 * used: title search, exclude list, and date created/modified range.
	 *
	 * @param int[] $ids
	 * @param array $args
	 * @return int[]
	 */
	protected function apply_cross_filters( $ids, $args ) {
		$post_type = $args['post_type'] ?: 'post';

		if ( ! empty( $args['title_search'] ) ) {
			$matched = array();
			foreach ( $args['title_search'] as $name ) {
				$name = trim( $name );
				if ( '' === $name ) {
					continue;
				}
				$found = get_posts(
					array(
						'post_type'      => $post_type,
						'post_status'    => 'any',
						's'              => $name,
						'posts_per_page' => -1,
						'fields'         => 'ids',
					)
				);
				$matched = array_merge( $matched, $found );
			}
			$ids = array_values( array_intersect( $ids, array_unique( $matched ) ) );
		}

		if ( ! empty( $args['exclude_titles'] ) ) {
			$excluded = array();
			foreach ( $args['exclude_titles'] as $name ) {
				$name = trim( $name );
				if ( '' === $name ) {
					continue;
				}
				$found = get_posts(
					array(
						'post_type'      => $post_type,
						'post_status'    => 'any',
						's'              => $name,
						'posts_per_page' => -1,
						'fields'         => 'ids',
					)
				);
				$excluded = array_merge( $excluded, $found );
			}
			$ids = array_values( array_diff( $ids, $excluded ) );
		}
		if ( ! empty( $args['exclude_ids'] ) ) {
			$ids = array_values( array_diff( $ids, array_map( 'absint', $args['exclude_ids'] ) ) );
		}

		if ( ! empty( $args['date_created_after'] ) || ! empty( $args['date_created_before'] ) ) {
			$ids = array_values( array_filter( $ids, function ( $id ) use ( $args ) {
				return self::date_in_range( get_post_field( 'post_date', $id ), $args['date_created_after'] ?? '', $args['date_created_before'] ?? '' );
			} ) );
		}
		if ( ! empty( $args['date_modified_after'] ) || ! empty( $args['date_modified_before'] ) ) {
			$ids = array_values( array_filter( $ids, function ( $id ) use ( $args ) {
				return self::date_in_range( get_post_field( 'post_modified', $id ), $args['date_modified_after'] ?? '', $args['date_modified_before'] ?? '' );
			} ) );
		}

		return $ids;
	}

	protected static function date_in_range( $date_string, $after, $before ) {
		$ts = strtotime( $date_string );
		if ( ! $ts ) {
			return false;
		}
		if ( $after && $ts < strtotime( $after ) ) {
			return false;
		}
		if ( $before && $ts > strtotime( $before . ' 23:59:59' ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Build the complete portable export record for one post.
	 *
	 * @param WP_Post $post
	 * @param array   $meta_rules
	 * @return array
	 */
	public function build_record( $post, $meta_rules = array() ) {
		$post_id   = $post->ID;
		$post_type = $post->post_type;
		$author    = get_userdata( $post->post_author );
		$pto       = get_post_type_object( $post_type );
		$hierarchical = $pto ? (bool) $pto->hierarchical : false;

		$record = array(
			'source_site'     => site_url(),
			'post_id'         => $post_id,
			'external_id'     => get_post_meta( $post_id, APM_Relationship_Map::META_KEY, true ) ?: (string) $post_id,
			'post_type'       => $post_type,
			'title'           => $post->post_title,
			'slug'            => $post->post_name,
			'content'         => $post->post_content,
			'excerpt'         => $post->post_excerpt,
			'status'          => $post->post_status,
			'author'          => array(
				'login' => $author ? $author->user_login : '',
				'email' => $author ? $author->user_email : '',
			),
			'date'            => $post->post_date,
			'modified'        => $post->post_modified,
			'menu_order'      => (int) $post->menu_order,
			'comment_status'  => $post->comment_status,
			'ping_status'     => $post->ping_status,
		);

		if ( $hierarchical && $post->post_parent ) {
			$parent = get_post( $post->post_parent );
			$record['parent'] = $parent ? array(
				'slug'        => $parent->post_name,
				'external_id' => get_post_meta( $parent->ID, APM_Relationship_Map::META_KEY, true ) ?: (string) $parent->ID,
			) : null;
		} else {
			$record['parent'] = null;
		}

		$record['taxonomies']    = $this->export_taxonomies( $post_id, $post_type );
		$record['featured_image'] = $this->export_image_id( get_post_thumbnail_id( $post_id ) );

		if ( APM_ACF_Handler::is_active() ) {
			$record['acf'] = APM_ACF_Handler::export_fields( $post_id );
		}
		if ( APM_Yoast_Handler::is_active() ) {
			$record['yoast'] = APM_Yoast_Handler::export_fields( $post_id );
		}

		$record['custom_meta'] = APM_Meta_Handler::export_meta( $post_id, array_merge( $meta_rules, array( 'post_type' => $post_type ) ) );

		if ( ! empty( $this->field_config ) ) {
			$record = $this->apply_field_selection( $record );
		}

		return apply_filters( 'apm_export_record', $record, $post );
	}

	/**
	 * Export every taxonomy registered for this post type: hierarchical
	 * taxonomies export the assigned terms' full ancestor paths, flat
	 * taxonomies export a simple list of names.
	 *
	 * @param int    $post_id
	 * @param string $post_type
	 * @return array taxonomy => array of paths (hierarchical) | names (flat)
	 */
	protected function export_taxonomies( $post_id, $post_type ) {
		$out = array();
		foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy => $tax_obj ) {
			if ( $tax_obj->hierarchical ) {
				$out[ $taxonomy ] = array(
					'hierarchical' => true,
					'terms'        => APM_Taxonomy_Handler::export_post_terms( $post_id, $taxonomy ),
				);
			} else {
				$terms = get_the_terms( $post_id, $taxonomy );
				$out[ $taxonomy ] = array(
					'hierarchical' => false,
					'terms'        => ( $terms && ! is_wp_error( $terms ) ) ? wp_list_pluck( $terms, 'name' ) : array(),
				);
			}
		}
		return $out;
	}

	/**
	 * Filter a fully-built record down to only the fields the user checked
	 * in the Export wizard's field-selection step. Identity fields needed
	 * for any future re-import (source_site, post_id, external_id,
	 * post_type) are always kept regardless of selection.
	 *
	 * $this->field_config['enabled'] is a flat list of dotted keys in the
	 * same vocabulary APM_Field_Registry uses for mapping targets:
	 * top-level keys as-is ('title', 'taxonomies', ...) and
	 * 'acf.<name>' / 'yoast.<key>' / 'custom_meta.<key>' for sub-fields.
	 *
	 * @param array $record
	 * @return array
	 */
	protected function apply_field_selection( $record ) {
		$enabled = array_flip( $this->field_config['enabled'] ?? array() );
		$always_keep = array( 'source_site', 'post_id', 'external_id', 'post_type' );

		foreach ( $record as $key => $value ) {
			if ( in_array( $key, $always_keep, true ) ) {
				continue;
			}
			if ( 'acf' === $key && is_array( $value ) ) {
				$record['acf'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 4 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'acf.' ); } ) ) ) );
				continue;
			}
			if ( 'yoast' === $key && is_array( $value ) ) {
				$record['yoast'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 6 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'yoast.' ); } ) ) ) );
				continue;
			}
			if ( 'custom_meta' === $key && is_array( $value ) ) {
				$record['custom_meta'] = array_intersect_key( $value, array_flip( array_map( function ( $k ) { return substr( $k, 12 ); }, array_filter( array_keys( $enabled ), function ( $k ) { return 0 === strpos( $k, 'custom_meta.' ); } ) ) ) );
				continue;
			}
			if ( ! isset( $enabled[ $key ] ) ) {
				unset( $record[ $key ] );
			}
		}

		return $record;
	}

	protected function export_image_id( $attachment_id ) {
		if ( ! $attachment_id ) {
			return null;
		}
		return APM_ACF_Handler::export_attachment_ref( $attachment_id );
	}
}
