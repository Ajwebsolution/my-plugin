<?php
/**
 * APM_Taxonomy_Handler
 *
 * Preserves taxonomy term hierarchy across import for ANY registered
 * taxonomy (not hardcoded to product_cat/product_tag). Resolves an
 * exported path like "Clothing > Women > Dresses > Summer Dresses" by
 * matching existing terms level-by-level (ID, then slug, then name) and
 * only creates the levels that don't already exist — never duplicates an
 * existing branch. Flat (non-hierarchical) taxonomies use simple
 * name/slug matching via resolve_flat_term().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APM_Taxonomy_Handler {

	/**
	 * Export a term's full ancestor path as an ordered array of
	 * {id, slug, name} — root first, term itself last.
	 *
	 * @param int    $term_id
	 * @param string $taxonomy
	 * @return array
	 */
	public static function export_term_path( $term_id, $taxonomy ) {
		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return array();
		}
		$ancestors = array_reverse( get_ancestors( $term_id, $taxonomy, 'taxonomy' ) );
		$path      = array();
		foreach ( $ancestors as $ancestor_id ) {
			$a = get_term( $ancestor_id, $taxonomy );
			if ( $a && ! is_wp_error( $a ) ) {
				$path[] = array( 'id' => $a->term_id, 'slug' => $a->slug, 'name' => $a->name );
			}
		}
		$path[] = array( 'id' => $term->term_id, 'slug' => $term->slug, 'name' => $term->name );
		return $path;
	}

	/**
	 * Export every term of a given taxonomy assigned to a post as a list
	 * of full hierarchical paths.
	 *
	 * @param int    $post_id
	 * @param string $taxonomy
	 * @return array[]
	 */
	public static function export_post_terms( $post_id, $taxonomy ) {
		$terms = get_the_terms( $post_id, $taxonomy );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return array();
		}
		$paths = array();
		foreach ( $terms as $term ) {
			$paths[] = self::export_term_path( $term->term_id, $taxonomy );
		}
		return $paths;
	}

	/**
	 * Resolve (creating missing levels as needed) a hierarchical path back
	 * to a leaf term ID on the destination site.
	 *
	 * Accepts either:
	 *  - an array of path steps [{id,slug,name}, ...] (as exported above), or
	 *  - a plain "Clothing > Women > Dresses" string.
	 *
	 * @param array|string $path
	 * @param string       $taxonomy
	 * @param bool         $create_missing
	 * @return int|null Leaf term_id.
	 */
	public static function resolve_path( $path, $taxonomy, $create_missing = true ) {
		$steps = is_string( $path ) ? self::string_to_steps( $path ) : $path;
		if ( empty( $steps ) ) {
			return null;
		}

		$parent_id = 0;
		$term_id   = null;

		foreach ( $steps as $step ) {
			$name = is_array( $step ) ? ( $step['name'] ?? '' ) : $step;
			$slug = is_array( $step ) ? ( $step['slug'] ?? '' ) : sanitize_title( $step );
			$id   = is_array( $step ) ? ( $step['id'] ?? null ) : null;

			$found = null;

			// 1. Match by original term ID, only valid if it really is a child of the current parent.
			if ( $id && $t = get_term( $id, $taxonomy ) ) {
				if ( ! is_wp_error( $t ) && (int) $t->parent === (int) $parent_id ) {
					$found = $t;
				}
			}
			// 2. Match by slug within this parent.
			if ( ! $found && $slug ) {
				$found = self::get_term_by_slug_and_parent( $slug, $taxonomy, $parent_id );
			}
			// 3. Match by name within this parent.
			if ( ! $found && $name ) {
				$found = self::get_term_by_name_and_parent( $name, $taxonomy, $parent_id );
			}

			if ( $found ) {
				$term_id   = $found->term_id;
				$parent_id = $found->term_id;
				continue;
			}

			if ( ! $create_missing ) {
				return null;
			}

			$inserted = wp_insert_term( $name ? $name : $slug, $taxonomy, array( 'parent' => $parent_id, 'slug' => $slug ?: null ) );
			if ( is_wp_error( $inserted ) ) {
				// Term may already exist by slug under a race condition — try one more lookup.
				$existing = self::get_term_by_slug_and_parent( $slug, $taxonomy, $parent_id );
				if ( ! $existing ) {
					return null;
				}
				$term_id   = $existing->term_id;
				$parent_id = $existing->term_id;
				continue;
			}

			$term_id   = $inserted['term_id'];
			$parent_id = $inserted['term_id'];
		}

		return $term_id;
	}

	protected static function get_term_by_slug_and_parent( $slug, $taxonomy, $parent_id ) {
		$term = get_term_by( 'slug', $slug, $taxonomy );
		if ( $term && (int) $term->parent === (int) $parent_id ) {
			return $term;
		}
		return null;
	}

	protected static function get_term_by_name_and_parent( $name, $taxonomy, $parent_id ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'name'       => $name,
				'parent'     => $parent_id,
				'hide_empty' => false,
			)
		);
		return ( ! is_wp_error( $terms ) && ! empty( $terms ) ) ? $terms[0] : null;
	}

	protected static function string_to_steps( $string ) {
		$parts = array_map( 'trim', explode( '>', $string ) );
		return array_filter( $parts );
	}

	/**
	 * Simple flat-taxonomy resolver (no hierarchy) — used for any
	 * non-hierarchical taxonomy registered on the selected post type
	 * (tags, and any custom flat taxonomy).
	 *
	 * @param string $name
	 * @param string $taxonomy
	 * @param bool   $create_missing
	 * @return int|null
	 */
	public static function resolve_flat_term( $name, $taxonomy, $create_missing = true ) {
		$name = trim( $name );
		if ( '' === $name ) {
			return null;
		}
		$term = get_term_by( 'name', $name, $taxonomy );
		if ( $term ) {
			return $term->term_id;
		}
		if ( ! $create_missing ) {
			return null;
		}
		$inserted = wp_insert_term( $name, $taxonomy );
		return is_wp_error( $inserted ) ? null : $inserted['term_id'];
	}
}
