<?php
/**
 * Plugin Name: Advanced Post Migrator
 * Plugin URI:  https://example.com/advanced-post-migrator
 * Description: Full-fidelity WordPress Post (and any registered post type) import/export with a professional dashboard, step-by-step wizard, field mapping, dry run, background batch processing, rollback, saved mapping profiles — built to handle complete ACF (repeater, flexible content, gallery, relationship, post object, group, clone, taxonomy, user), Yoast SEO, categories/tags/any taxonomy, featured images and custom meta that off-the-shelf importers drop. Runs standalone, with no dependency on WooCommerce or Advanced Woo Product Migrator, and is safe to run alongside either.
 * Version:     1.1.0
 * Author:      Your Company
 * Text Domain: advanced-post-migrator
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 *
 * @package Advanced_Post_Migrator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

/* -------------------------------------------------------------------------
 * Constants
 * ---------------------------------------------------------------------- */
define( 'APM_VERSION', '1.1.0' );
define( 'APM_PLUGIN_FILE', __FILE__ );
define( 'APM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'APM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'APM_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'APM_MIN_PHP', '7.4' );

/* -------------------------------------------------------------------------
 * Environment checks
 * ---------------------------------------------------------------------- */

/**
 * Advanced Post Migrator has no hard dependency on WooCommerce, ACF or
 * Yoast SEO — it works against core WordPress Posts (or any registered
 * post type) out of the box, and simply enriches its export/import when
 * ACF and/or Yoast SEO are detected active. The only hard requirement is
 * the PHP version.
 */
function apm_environment_check() {
	$errors = array();

	if ( version_compare( PHP_VERSION, APM_MIN_PHP, '<' ) ) {
		$errors[] = sprintf(
			/* translators: 1: required PHP version, 2: current PHP version */
			__( 'Advanced Post Migrator requires PHP %1$s or higher. You are running %2$s.', 'advanced-post-migrator' ),
			APM_MIN_PHP,
			PHP_VERSION
		);
	}

	return $errors;
}

function apm_admin_notice_requirements() {
	$errors = apm_environment_check();
	if ( empty( $errors ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Advanced Post Migrator', 'advanced-post-migrator' ) . ':</strong></p><ul>';
	foreach ( $errors as $error ) {
		echo '<li>' . esc_html( $error ) . '</li>';
	}
	echo '</ul></div>';
}

/* -------------------------------------------------------------------------
 * Boot
 * ---------------------------------------------------------------------- */
function apm_boot() {
	if ( ! empty( apm_environment_check() ) ) {
		add_action( 'admin_notices', 'apm_admin_notice_requirements' );
		return;
	}

	// Foundational / DB classes first for clarity (no file-scope
	// cross-class references exist — every cross-class call happens inside
	// methods — so load order only matters for readability here).
	require_once APM_PLUGIN_DIR . 'includes/class-apm-installer.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-logger.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-jobs.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-mappings.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-snapshot.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-relationship-map.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-system-status.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-tools.php';

	require_once APM_PLUGIN_DIR . 'includes/class-apm-field-registry.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-acf-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-yoast-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-image-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-taxonomy-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-meta-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-transformer.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-csv-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-json-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-xlsx-handler.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-exporter-file-writer.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-post-exporter.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-post-importer.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-taxonomy-exporter.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-taxonomy-importer.php';
	require_once APM_PLUGIN_DIR . 'includes/class-apm-search.php';

	require_once APM_PLUGIN_DIR . 'admin/class-apm-admin.php';
	require_once APM_PLUGIN_DIR . 'admin/class-apm-settings.php';
	require_once APM_PLUGIN_DIR . 'admin/class-apm-ajax.php';

	// Silently bring the DB schema up to date if this is an upgrade from an
	// older plugin version (activation hook only runs on fresh activation).
	APM_Installer::maybe_upgrade();

	APM_Settings::init();

	// Instantiate the admin controller (registers menus, assets, AJAX hooks).
	APM_Admin::instance();
	APM_Ajax::instance();

	// Daily cleanup of expired snapshots (per the configured retention
	// window in Settings -> Backup & Rollback).
	if ( ! wp_next_scheduled( 'apm_daily_maintenance' ) ) {
		wp_schedule_event( time(), 'daily', 'apm_daily_maintenance' );
	}
	add_action( 'apm_daily_maintenance', array( 'APM_Snapshot', 'prune_expired' ) );
}
add_action( 'plugins_loaded', 'apm_boot', 20 );

/* -------------------------------------------------------------------------
 * Activation / Deactivation
 * ---------------------------------------------------------------------- */
function apm_activate() {
	// Create a private uploads subfolder for temporary import/export files.
	$upload_dir = wp_upload_dir();
	$apm_dir    = trailingslashit( $upload_dir['basedir'] ) . 'apm-tmp';
	if ( ! file_exists( $apm_dir ) ) {
		wp_mkdir_p( $apm_dir );
	}
	// Protect the folder from direct web access.
	$htaccess = $apm_dir . '/.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		file_put_contents( $htaccess, "Options -Indexes\nDeny from all\n" );
	}
	$index = $apm_dir . '/index.php';
	if ( ! file_exists( $index ) ) {
		file_put_contents( $index, "<?php\n// Silence is golden.\n" );
	}

	if ( false === get_option( 'apm_settings' ) ) {
		add_option(
			'apm_settings',
			array(
				'default_post_type'          => 'post',
				'default_match_strategy'     => 'slug',
				'preserve_empty_values'      => false,
				'image_match_strategy'       => 'url_filename_fallback',
				'download_remote_images'     => true,
				'batch_size'                 => 50,
				'logging_enabled'            => true,
				'log_retention_days'         => 30,
				'snapshot_retention_days'    => 14,
				'create_backup_before_update' => true,
				'enable_rollback'            => true,
				'delete_data_on_uninstall'   => false,
			)
		);
	}

	// Requires the plugin's own classes directly (autoloading isn't set up
	// this early in the activation hook, since plugins_loaded hasn't fired
	// yet).
	require_once APM_PLUGIN_DIR . 'includes/class-apm-installer.php';
	APM_Installer::install();
}
register_activation_hook( __FILE__, 'apm_activate' );

function apm_deactivate() {
	// Clear APM's own cron hook.
	wp_clear_scheduled_hook( 'apm_daily_maintenance' );

	// Deliberately does NOT delete database tables, options, logs,
	// snapshots, or any post data — deactivation must be non-destructive.
	// Full cleanup only ever happens in uninstall.php, and only if the
	// site owner opts in via Settings -> General -> "Delete data on
	// uninstall".
}
register_deactivation_hook( __FILE__, 'apm_deactivate' );
