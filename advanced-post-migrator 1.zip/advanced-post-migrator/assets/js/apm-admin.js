/* global jQuery, APM */
( function ( $ ) {
	'use strict';

	var state = {
		fieldCatalog: {}, // cached per entity+post_type key: { 'post:post': {...}, 'taxonomies:post': {...}, ... }
		uploadedFile: null,
		importJobId: null,
		exportJobId: null,
		importTransforms: {},
		exportFieldConfig: null, // null = "everything enabled" (not yet touched by the user)
		exportEntity: 'post',
		importEntity: 'post',
	};

	/* =====================================================================
	 * Small UI kit: escaping, toasts, in-page dialogs, inline errors, progress.
	 * =================================================================== */

	var ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	function esc( s ) {
		return String( s === undefined || s === null ? '' : s ).replace( /[&<>"']/g, function ( c ) { return ESC_MAP[ c ]; } );
	}

	function errorMessage( res, fallback ) {
		return ( res && res.data && res.data.message ) ? res.data.message : ( fallback || 'Something went wrong. Please try again.' );
	}

	var UI = {
		toast: function ( message, type ) {
			type = type || 'success';
			var $wrap = $( '#apm-toasts' );
			if ( ! $wrap.length ) $wrap = $( '<div class="apm-toasts" id="apm-toasts" aria-live="polite"></div>' ).appendTo( 'body' );
			var icon = { success: 'yes-alt', error: 'warning', info: 'info-outline', warning: 'flag' }[ type ] || 'info-outline';
			var $t = $( '<div class="apm-toast apm-toast-' + type + '" role="' + ( type === 'error' ? 'alert' : 'status' ) + '">' +
				'<span class="dashicons dashicons-' + icon + '" aria-hidden="true"></span><div class="apm-toast-msg"></div>' +
				'<button type="button" class="apm-toast-close" aria-label="Dismiss">&times;</button></div>' );
			$t.find( '.apm-toast-msg' ).text( message );
			$wrap.append( $t );
			requestAnimationFrame( function () { $t.addClass( 'is-in' ); } );
			var close = function () { $t.removeClass( 'is-in' ); setTimeout( function () { $t.remove(); }, 200 ); };
			$t.find( '.apm-toast-close' ).on( 'click', close );
			setTimeout( close, type === 'error' ? 9000 : 5000 );
		},

		/**
		 * In-page replacement for confirm()/prompt(). Resolves with the input
		 * value (or true) on confirm, rejects on cancel/Escape.
		 */
		dialog: function ( opts ) {
			var d = $.Deferred();
			var lastFocus = document.activeElement;
			var titleId = 'apm-dialog-title-' + Date.now();
			var $overlay = $( '<div class="apm-modal-overlay apm-dialog-overlay"></div>' );
			var $modal = $( '<div class="apm-modal apm-dialog" role="dialog" aria-modal="true" aria-labelledby="' + titleId + '"></div>' );
			$modal.append( $( '<h3></h3>' ).attr( 'id', titleId ).text( opts.title || 'Are you sure?' ) );
			if ( opts.message ) $modal.append( $( '<p class="apm-dialog-msg"></p>' ).text( opts.message ) );
			var $input = null;
			if ( opts.input ) {
				var inputId = titleId + '-input';
				$modal.append( $( '<label class="apm-dialog-label"></label>' ).attr( 'for', inputId ).text( opts.input.label || '' ) );
				$input = $( '<input type="text" class="regular-text apm-dialog-input">' ).attr( { id: inputId, placeholder: opts.input.placeholder || '' } ).val( opts.input.value || '' );
				$modal.append( $input ).append( '<p class="apm-field-error" role="alert" hidden></p>' );
			}
			var $actions = $( '<div class="apm-modal-actions"></div>' );
			var $cancel = $( '<button type="button" class="button"></button>' ).text( opts.cancelLabel || 'Cancel' );
			var $ok = $( '<button type="button" class="button button-primary"></button>' ).text( opts.confirmLabel || 'Confirm' );
			if ( opts.danger ) $ok.addClass( 'apm-button-danger-solid' );
			$actions.append( $cancel, $ok );
			$modal.append( $actions );
			$overlay.append( $modal ).appendTo( 'body' );

			function close() {
				$overlay.remove();
				$( document ).off( 'keydown.apmdialog' );
				if ( lastFocus && lastFocus.focus ) lastFocus.focus();
			}
			function confirm() {
				var val = true;
				if ( $input ) {
					val = $.trim( $input.val() );
					if ( opts.input.required && ! val ) {
						$modal.find( '.apm-field-error' ).text( opts.input.requiredMessage || 'This field is required.' ).prop( 'hidden', false );
						$input.attr( 'aria-invalid', 'true' ).trigger( 'focus' );
						return;
					}
				}
				close();
				d.resolve( val );
			}
			$cancel.on( 'click', function () { close(); d.reject(); } );
			$ok.on( 'click', confirm );
			$overlay.on( 'mousedown', function ( e ) { if ( e.target === $overlay[0] ) { close(); d.reject(); } } );
			$( document ).on( 'keydown.apmdialog', function ( e ) {
				if ( e.key === 'Escape' ) { e.preventDefault(); close(); d.reject(); }
				else if ( e.key === 'Enter' && $input && document.activeElement === $input[0] ) { e.preventDefault(); confirm(); }
				else if ( e.key === 'Tab' ) {
					var $f = $modal.find( 'input,button' ).filter( ':visible' );
					var first = $f[0], last = $f[ $f.length - 1 ];
					if ( e.shiftKey && document.activeElement === first ) { e.preventDefault(); last.focus(); }
					else if ( ! e.shiftKey && document.activeElement === last ) { e.preventDefault(); first.focus(); }
				}
			} );
			( $input || ( opts.danger ? $cancel : $ok ) ).trigger( 'focus' );
			return d.promise();
		},

		fieldError: function ( $el, message ) {
			if ( ! $el.length ) return;
			if ( message ) $el.text( message ).prop( 'hidden', false );
			else $el.text( '' ).prop( 'hidden', true );
		},

		notice: function ( $target, type, html ) {
			$target.html( '<div class="apm-notice apm-notice-' + type + '">' + html + '</div>' );
		},

		/**
		 * Update a .apm-progress block: bar, percentage, processed/total,
		 * elapsed-based ETA and any extra counters.
		 */
		progress: function ( $wrap, info ) {
			var total = Math.max( 0, parseInt( info.total, 10 ) || 0 );
			var done = Math.min( total, Math.max( 0, parseInt( info.processed, 10 ) || 0 ) );
			var pct = total > 0 ? Math.round( ( done / total ) * 100 ) : ( info.finished ? 100 : 0 );
			if ( info.finished ) pct = 100;
			$wrap.prop( 'hidden', false ).toggleClass( 'is-done', !! info.finished );
			$wrap.find( '.apm-progress-fill' ).css( 'width', pct + '%' );
			$wrap.find( '.apm-progress-bar' ).attr( 'aria-valuenow', pct );
			$wrap.find( '.apm-progress-pct' ).text( pct + '%' );
			if ( info.title ) $wrap.find( '.apm-progress-title' ).text( info.title );

			var parts = [ '<span><strong>' + done.toLocaleString() + '</strong> / ' + total.toLocaleString() + ' ' + esc( info.unit || 'records' ) + '</span>' ];
			if ( ! info.finished && info.start && done > 0 && total > done ) {
				var elapsed = ( Date.now() - info.start ) / 1000;
				parts.push( '<span>~' + formatDuration( ( elapsed / done ) * ( total - done ) ) + ' left</span>' );
			} else if ( info.finished && info.start ) {
				parts.push( '<span>Took ' + formatDuration( ( Date.now() - info.start ) / 1000 ) + '</span>' );
			}
			$.each( info.counts || [], function ( i, c ) {
				parts.push( '<span class="apm-count apm-count-' + esc( c[2] || 'neutral' ) + '">' + esc( c[0] ) + ' <strong>' + esc( c[1] ) + '</strong></span>' );
			} );
			$wrap.find( '.apm-progress-meta' ).html( parts.join( '' ) );
		},
	};

	function formatDuration( sec ) {
		sec = Math.max( 0, Math.round( sec ) );
		if ( sec < 60 ) return sec + 's';
		var m = Math.floor( sec / 60 ), s = sec % 60;
		if ( m < 60 ) return m + 'm ' + ( s < 10 ? '0' : '' ) + s + 's';
		return Math.floor( m / 60 ) + 'h ' + ( m % 60 ) + 'm';
	}

	function formatBytes( n ) {
		if ( n < 1024 ) return n + ' B';
		if ( n < 1048576 ) return ( n / 1024 ).toFixed( 1 ) + ' KB';
		return ( n / 1048576 ).toFixed( 1 ) + ' MB';
	}

	window.APMUI = UI; // Exposed for the test harness / other screens.

	/**
	 * Per-entity options for the Import wizard's "If it already exists" /
	 * "Action for existing records" selects (Step 2) — Posts and
	 * Taxonomies each have a different, real set of match strategies (see
	 * each importer's find_existing_*() method), so the dropdown is
	 * rebuilt rather than showing options that don't apply.
	 */
	var MATCH_STRATEGIES = {
		post: { options: [ [ 'slug', 'Update by Slug' ], [ 'post_id', 'Update by Post ID' ], [ 'external_id', 'Update by External ID (falls back to Slug)' ], [ 'none', 'Never match — always create new' ] ], def: 'slug', help: '' },
		taxonomies: { options: [ [ 'slug', 'Match by Slug (recommended)' ], [ 'external_id', 'Match by External ID (falls back to Slug)' ] ], def: 'slug', help: 'Hierarchical taxonomies (e.g. Categories) also match by their full parent path; flat taxonomies (e.g. Tags) match by slug then name.' },
	};
	var ENTITY_LABELS = { post: 'post', taxonomies: 'taxonomy term' };
	var EXISTING_ACTIONS = {
		post: { options: [ [ 'update', 'Update existing' ], [ 'skip', 'Skip existing' ], [ 'duplicate', 'Create duplicate' ] ], def: 'update' },
		taxonomies: { options: [ [ 'update', 'Update existing' ], [ 'skip', 'Skip existing' ] ], def: 'update' },
	};

	function applyEntityToStep2( entity ) {
		var cfg = MATCH_STRATEGIES[ entity ] || MATCH_STRATEGIES.post;
		var $select = $( '#apm-match-strategy' );
		$select.empty();
		$.each( cfg.options, function ( i, opt ) { $select.append( $( '<option></option>' ).attr( 'value', opt[0] ).text( opt[1] ) ); } );
		$select.val( cfg.def );
		$( '#apm-match-strategy-help' ).text( cfg.help );

		var label = ENTITY_LABELS[ entity ] || 'record';
		$( '#apm-step2-heading' ).text( 'What should happen to ' + label + 's that already exist?' );

		$( '.apm-post-only-row' ).toggle( entity === 'post' );
		$( '.apm-taxonomies-only-row' ).toggle( entity === 'taxonomies' );

		var actionCfg = EXISTING_ACTIONS[ entity ] || EXISTING_ACTIONS.post;
		var $action = $( '#apm-existing-action' );
		$action.empty();
		$.each( actionCfg.options, function ( i, opt ) { $action.append( $( '<option></option>' ).attr( 'value', opt[0] ).text( opt[1] ) ); } );
		$action.val( actionCfg.def );
	}

	function post( action, data ) {
		data = data || {};
		data.action = action;
		data.nonce = APM.nonce;
		return $.post( APM.ajax_url, data );
	}

	/** Attach a generic network-failure handler that surfaces a toast. */
	function onFail( xhr ) {
		if ( xhr && xhr.statusText === 'abort' ) return;
		var msg = xhr && xhr.responseJSON ? errorMessage( xhr.responseJSON ) : 'The request failed (' + ( xhr && xhr.status ? 'HTTP ' + xhr.status : 'network error' ) + ').';
		UI.toast( msg, 'error' );
	}

	/**
	 * Build a secure, authenticated download URL for a job's export/import
	 * file (or a Tools-generated file, via type "tool" + a basename). The
	 * apm-tmp folder itself is blocked from direct web access, so every
	 * download goes through this admin-post.php endpoint instead.
	 */
	function downloadUrl( type, jobId, filename ) {
		var base = APM.ajax_url.replace( 'admin-ajax.php', 'admin-post.php' );
		var url = base + '?action=apm_download&type=' + type + '&_wpnonce=' + encodeURIComponent( APM.nonce );
		if ( jobId ) url += '&job_id=' + encodeURIComponent( jobId );
		if ( filename ) url += '&file=' + encodeURIComponent( filename );
		return url;
	}

	function splitList( v ) {
		return String( v || '' ).split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
	}

	/* =====================================================================
	 * Taxonomy <select>s (populated from APM.taxonomies, scoped to a post type)
	 * =================================================================== */

	function taxonomiesFor( postType ) {
		var all = APM.taxonomies || {};
		return postType === '__all' ? ( all.__all || [] ) : ( all[ postType ] || [] );
	}

	function fillTaxonomySelect( $sel ) {
		var scope = $sel.data( 'all' ) ? '__all' : $( $sel.data( 'scope-post-type' ) ).val();
		var list = taxonomiesFor( scope );
		var current = $sel.val() || $sel.data( 'default' ) || '';
		$sel.empty();
		if ( ! list.length ) {
			$sel.append( $( '<option value=""></option>' ).text( '— No taxonomies for this post type —' ) );
			if ( current && $sel.data( 'all' ) ) $sel.append( $( '<option></option>' ).val( current ).text( current ) );
		}
		$.each( list, function ( i, t ) {
			$sel.append( $( '<option></option>' ).val( t.name ).text( t.label + ' (' + t.name + ')' ) );
		} );
		var names = list.map( function ( t ) { return t.name; } );
		$sel.val( names.indexOf( current ) !== -1 ? current : ( names[0] || current ) );
	}

	$( '.apm-taxonomy-select' ).each( function () {
		var $sel = $( this );
		fillTaxonomySelect( $sel );
		var scopeSel = $sel.data( 'scope-post-type' );
		if ( scopeSel ) {
			$( scopeSel ).on( 'change', function () {
				var before = $sel.val();
				fillTaxonomySelect( $sel );
				if ( $sel.val() !== before ) $sel.trigger( 'change' );
			} );
		}
	} );

	/* =====================================================================
	 * Autocomplete / token input
	 *
	 * Markup: <div class="apm-ac" data-source="posts|terms|taxonomies"
	 *   data-value="id|slug|term_id|title|name" [data-free-text]
	 *   [data-scope-post-type="#sel"] [data-scope-taxonomy="#sel"]>
	 *   <input type="hidden" class="apm-ac-value"></div>
	 *
	 * The hidden input always holds the comma-separated list the backend
	 * already expects (IDs / slugs / term IDs / keywords / taxonomy names).
	 * =================================================================== */

	var acCache = {
		max: 60,
		map: new Map(),
		get: function ( k ) {
			if ( ! this.map.has( k ) ) return undefined;
			var v = this.map.get( k );
			this.map.delete( k );
			this.map.set( k, v ); // Refresh recency.
			return v;
		},
		set: function ( k, v ) {
			if ( this.map.has( k ) ) this.map.delete( k );
			this.map.set( k, v );
			if ( this.map.size > this.max ) this.map.delete( this.map.keys().next().value );
		},
	};

	var acUid = 0;
	var ENDPOINTS = { posts: 'apm_search_posts', terms: 'apm_search_terms' };

	function Autocomplete( el ) {
		var self = this;
		this.$root = $( el );
		this.source = this.$root.data( 'source' );
		this.valueField = this.$root.data( 'value' ) || 'id';
		this.freeText = !! this.$root.data( 'free-text' );
		var mc = this.$root.data( 'min-chars' );
		this.minChars = mc === undefined ? 1 : parseInt( mc, 10 );
		this.$scopePostType = $( this.$root.data( 'scope-post-type' ) || [] );
		this.$scopeTaxonomy = $( this.$root.data( 'scope-taxonomy' ) || [] );
		this.$hidden = this.$root.find( '.apm-ac-value' );
		this.items = [];
		this.results = [];
		this.active = -1;
		this.timer = null;
		this.xhr = null;
		this.reqId = 0;

		var uid = ++acUid;
		this.listId = 'apm-ac-list-' + uid;
		var inputId = this.$root.data( 'input-id' ) || 'apm-ac-input-' + uid;

		this.$control = $( '<div class="apm-ac-control"></div>' );
		this.$chips = $( '<ul class="apm-ac-chips" role="list"></ul>' );
		this.$input = $( '<input type="text" class="apm-ac-input" role="combobox" aria-autocomplete="list" aria-expanded="false" autocomplete="off" spellcheck="false">' )
			.attr( { id: inputId, 'aria-controls': this.listId, placeholder: this.$root.data( 'placeholder' ) || '' } );
		if ( this.$root.data( 'label' ) ) this.$input.attr( 'aria-label', this.$root.data( 'label' ) );
		this.$spinner = $( '<span class="apm-ac-spinner" aria-hidden="true"></span>' );
		this.$clear = $( '<button type="button" class="apm-ac-clear" aria-label="Clear all" hidden>&times;</button>' );
		this.$list = $( '<ul class="apm-ac-list" role="listbox" hidden></ul>' ).attr( 'id', this.listId );
		this.$notice = $( '<div class="apm-ac-notice" aria-live="polite" hidden></div>' );

		this.$control.append( this.$chips, this.$input, this.$spinner, this.$clear );
		this.$root.append( this.$control, this.$list, this.$notice ).addClass( 'is-ready' );

		this.$control.on( 'mousedown', function ( e ) {
			if ( e.target === self.$control[0] || e.target === self.$chips[0] ) { e.preventDefault(); self.$input.trigger( 'focus' ); }
		} );
		this.$input.on( 'input', function () { self.onInput(); } );
		this.$input.on( 'keydown', function ( e ) { self.onKeydown( e ); } );
		this.$input.on( 'paste', function ( e ) { self.onPaste( e ); } );
		this.$input.on( 'focus', function () {
			self.$root.addClass( 'is-focused' );
			if ( self.minChars === 0 ) self.schedule( 0 );
		} );
		this.$input.on( 'blur', function () {
			self.$root.removeClass( 'is-focused' );
			setTimeout( function () {
				if ( document.activeElement !== self.$input[0] ) {
					if ( self.freeText && $.trim( self.$input.val() ) ) self.addFreeText( self.$input.val() );
					self.close();
				}
			}, 120 );
		} );
		this.$list.on( 'mousedown', '[role="option"]', function ( e ) {
			e.preventDefault(); // Keep focus in the input.
			self.choose( parseInt( $( this ).attr( 'data-index' ), 10 ) );
		} );
		this.$list.on( 'mousemove', '[role="option"]', function () {
			var i = parseInt( $( this ).attr( 'data-index' ), 10 );
			if ( i !== self.active ) self.setActive( i, true );
		} );
		this.$chips.on( 'click', '.apm-chip-remove', function () {
			self.removeAt( parseInt( $( this ).closest( '.apm-chip' ).attr( 'data-index' ), 10 ) );
			self.$input.trigger( 'focus' );
		} );
		this.$clear.on( 'click', function () { self.clear(); self.$input.trigger( 'focus' ); } );

		this.$scopePostType.on( 'change', function () { self.onScopeChange( 'post_type' ); } );
		this.$scopeTaxonomy.on( 'change', function () { self.onScopeChange( 'taxonomy' ); } );

		this.$root.data( 'apmAc', this );
		if ( this.$hidden.val() ) this.setValues( splitList( this.$hidden.val() ) );
	}

	Autocomplete.prototype = {
		scope: function () {
			return {
				post_type: this.$scopePostType.length ? this.$scopePostType.val() : '',
				taxonomy: this.$scopeTaxonomy.length ? this.$scopeTaxonomy.val() : '',
			};
		},

		valueOf: function ( item ) {
			var v;
			switch ( this.valueField ) {
				case 'slug': v = item.slug; break;
				case 'term_id': v = item.term_id; break;
				case 'title': v = item.title; break;
				case 'name': v = item.name; break;
				default: v = item.id;
			}
			v = String( v === undefined || v === null ? '' : v );
			// The backend splits on commas, so a keyword can't contain one.
			return this.valueField === 'title' ? v.replace( /,/g, ' ' ).replace( /\s+/g, ' ' ).trim() : v;
		},

		labelOf: function ( item ) {
			if ( item.keyword ) return item.title;
			if ( this.source === 'posts' ) return item.title;
			if ( this.source === 'terms' ) return item.path || item.name;
			if ( this.source === 'taxonomies' ) return item.label;
			return String( item.id );
		},

		metaOf: function ( item ) {
			var bits = [];
			if ( this.source === 'posts' ) {
				bits.push( '#' + item.id );
				if ( item.slug ) bits.push( item.slug );
				bits.push( item.status_label || item.status );
				if ( item.date ) bits.push( item.date );
			} else if ( this.source === 'terms' ) {
				bits.push( '#' + item.term_id );
				bits.push( item.slug );
				bits.push( item.taxonomy_label );
				bits.push( item.count + ' ' + ( item.count === 1 ? 'post' : 'posts' ) );
			} else if ( this.source === 'taxonomies' ) {
				bits.push( item.name );
				bits.push( item.hierarchical ? 'Hierarchical' : 'Flat' );
			}
			return bits.filter( Boolean ).join( ' · ' );
		},

		chipTitle: function ( item ) {
			if ( item.unresolved ) return '“' + item.token + '” did not match anything — it will be ignored.';
			return this.labelOf( item ) + ( item.keyword ? ' (keyword)' : ' — ' + this.metaOf( item ) );
		},

		has: function ( item ) {
			var v = this.valueOf( item );
			for ( var i = 0; i < this.items.length; i++ ) {
				if ( ! this.items[ i ].unresolved && this.valueOf( this.items[ i ] ) === v ) return true;
			}
			return false;
		},

		/* ---- Input handling ---- */

		onInput: function () {
			var q = $.trim( this.$input.val() );
			if ( this.freeText && /,/.test( this.$input.val() ) ) {
				var parts = this.$input.val().split( ',' );
				var rest = parts.pop();
				var self = this;
				parts.forEach( function ( p ) { self.addFreeText( p ); } );
				this.$input.val( rest );
				q = $.trim( rest );
			}
			if ( q.length < this.minChars ) { this.abort(); this.close(); return; }
			this.schedule( /^\d+$/.test( q ) ? 0 : 200 );
		},

		schedule: function ( delay ) {
			var self = this;
			clearTimeout( this.timer );
			this.timer = setTimeout( function () { self.search( $.trim( self.$input.val() ) ); }, delay );
		},

		abort: function () {
			clearTimeout( this.timer );
			if ( this.xhr && this.xhr.abort ) this.xhr.abort();
			this.xhr = null;
			this.$root.removeClass( 'is-loading' );
		},

		cacheKey: function ( q ) {
			var s = this.scope();
			return this.source + '|' + s.post_type + '|' + s.taxonomy + '|' + q.toLowerCase();
		},

		search: function ( q ) {
			var self = this;
			if ( q.length < this.minChars ) return;

			if ( this.source === 'taxonomies' ) {
				var ql = q.toLowerCase();
				var list = taxonomiesFor( this.scope().post_type || '__all' ).filter( function ( t ) {
					return ! ql || t.name.toLowerCase().indexOf( ql ) !== -1 || String( t.label ).toLowerCase().indexOf( ql ) !== -1;
				} );
				this.show( q, list );
				return;
			}

			var key = this.cacheKey( q );
			var cached = acCache.get( key );
			if ( cached ) { this.abort(); this.show( q, cached ); return; }

			this.abort();
			var id = ++this.reqId;
			var s = this.scope();
			this.$root.addClass( 'is-loading' );
			this.xhr = post( ENDPOINTS[ this.source ], { q: q, post_type: s.post_type, taxonomy: s.taxonomy, limit: 12 } );
			this.xhr.done( function ( res ) {
				if ( id !== self.reqId ) return; // A newer request superseded this one.
				self.$root.removeClass( 'is-loading' );
				if ( ! res || ! res.success ) { self.showError( errorMessage( res, 'Search failed.' ) ); return; }
				acCache.set( key, res.data.items || [] );
				self.show( q, res.data.items || [] );
			} ).fail( function ( xhr ) {
				if ( id !== self.reqId || ( xhr && xhr.statusText === 'abort' ) ) return;
				self.$root.removeClass( 'is-loading' );
				self.showError( 'Could not load suggestions' + ( xhr && xhr.status ? ' (HTTP ' + xhr.status + ')' : '' ) + '.' );
			} );
		},

		/* ---- Rendering ---- */

		highlight: function ( text, q ) {
			text = String( text );
			if ( ! q ) return esc( text );
			var i = text.toLowerCase().indexOf( q.toLowerCase() );
			if ( i === -1 ) return esc( text );
			return esc( text.slice( 0, i ) ) + '<mark>' + esc( text.slice( i, i + q.length ) ) + '</mark>' + esc( text.slice( i + q.length ) );
		},

		show: function ( q, items ) {
			var self = this;
			this.results = items.filter( function ( it ) { return ! self.has( it ); } );
			if ( this.freeText && q ) {
				var kw = { keyword: true, title: q, id: q };
				if ( ! this.has( kw ) ) this.results.unshift( kw );
			}
			var html = '';
			$.each( this.results, function ( i, it ) {
				var optId = self.listId + '-opt-' + i;
				if ( it.keyword ) {
					html += '<li role="option" class="apm-ac-option apm-ac-keyword" id="' + optId + '" data-index="' + i + '" aria-selected="false">' +
						'<span class="apm-ac-title"><span class="dashicons dashicons-search" aria-hidden="true"></span> Match keyword “' + esc( it.title ) + '”</span>' +
						'<span class="apm-ac-meta">Any post whose title or content contains it</span></li>';
					return;
				}
				var status = self.source === 'posts' && it.status && it.status !== 'publish' ? ' <span class="apm-ac-status apm-ac-status-' + esc( it.status ) + '">' + esc( it.status_label || it.status ) + '</span>' : '';
				html += '<li role="option" class="apm-ac-option" id="' + optId + '" data-index="' + i + '" aria-selected="false">' +
					'<span class="apm-ac-title">' + self.highlight( self.labelOf( it ), q ) + status + '</span>' +
					'<span class="apm-ac-meta">' + self.highlight( self.metaOf( it ), /^\d+$/.test( q ) ? '#' + q : q ) + '</span></li>';
			} );
			if ( ! this.results.length ) {
				html = '<li class="apm-ac-empty" role="presentation">' + ( items.length ? 'Everything matching is already selected' : 'No matches for “' + esc( q ) + '”' ) + '</li>';
			}
			this.$list.html( html ).prop( 'hidden', false );
			this.$input.attr( 'aria-expanded', 'true' );
			this.setActive( this.results.length ? 0 : -1 );
		},

		showError: function ( msg ) {
			this.results = [];
			this.$list.html( '<li class="apm-ac-empty apm-ac-error" role="presentation">' + esc( msg ) + '</li>' ).prop( 'hidden', false );
			this.$input.attr( 'aria-expanded', 'true' ).removeAttr( 'aria-activedescendant' );
		},

		close: function () {
			this.$list.prop( 'hidden', true ).empty();
			this.results = [];
			this.active = -1;
			this.$input.attr( 'aria-expanded', 'false' ).removeAttr( 'aria-activedescendant' );
		},

		isOpen: function () { return ! this.$list.prop( 'hidden' ); },

		setActive: function ( i, fromMouse ) {
			var $opts = this.$list.children( '[role="option"]' );
			$opts.eq( this.active ).removeClass( 'is-active' ).attr( 'aria-selected', 'false' );
			this.active = i;
			if ( i < 0 || i >= $opts.length ) { this.$input.removeAttr( 'aria-activedescendant' ); return; }
			var $o = $opts.eq( i ).addClass( 'is-active' ).attr( 'aria-selected', 'true' );
			this.$input.attr( 'aria-activedescendant', $o.attr( 'id' ) );
			if ( ! fromMouse ) {
				var el = $o[0], list = this.$list[0];
				if ( el.offsetTop < list.scrollTop ) list.scrollTop = el.offsetTop;
				else if ( el.offsetTop + el.offsetHeight > list.scrollTop + list.clientHeight ) list.scrollTop = el.offsetTop + el.offsetHeight - list.clientHeight;
			}
		},

		onKeydown: function ( e ) {
			var n = this.results.length;
			switch ( e.key ) {
				case 'ArrowDown':
					e.preventDefault();
					if ( ! this.isOpen() ) { this.schedule( 0 ); return; }
					if ( n ) this.setActive( ( this.active + 1 ) % n );
					break;
				case 'ArrowUp':
					e.preventDefault();
					if ( n ) this.setActive( ( this.active - 1 + n ) % n );
					break;
				case 'Enter':
					if ( this.isOpen() && this.active >= 0 ) { e.preventDefault(); this.choose( this.active ); }
					else if ( this.freeText && $.trim( this.$input.val() ) ) { e.preventDefault(); this.addFreeText( this.$input.val() ); }
					else if ( this.isOpen() ) e.preventDefault();
					break;
				case 'Tab':
					if ( this.isOpen() && this.active >= 0 && $.trim( this.$input.val() ) ) { e.preventDefault(); this.choose( this.active ); }
					break;
				case 'Escape':
					if ( this.isOpen() ) { e.preventDefault(); e.stopPropagation(); this.abort(); this.close(); }
					else if ( this.$input.val() ) { e.preventDefault(); this.$input.val( '' ); }
					break;
				case 'Backspace':
					if ( ! this.$input.val() && this.items.length ) { e.preventDefault(); this.removeAt( this.items.length - 1 ); }
					break;
			}
		},

		onPaste: function ( e ) {
			var cd = ( e.originalEvent || e ).clipboardData;
			var text = cd ? cd.getData( 'text' ) : '';
			if ( ! text || ! /[,\n\r\t;]/.test( text.trim() ) ) return; // Single value — let it type normally.
			e.preventDefault();
			var tokens = text.split( /[,\n\r\t;]+/ ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
			this.$input.val( '' );
			this.close();
			if ( this.freeText ) { var self = this; tokens.forEach( function ( t ) { self.addFreeText( t ); } ); return; }
			this.setValues( tokens, true );
		},

		/* ---- Selection ---- */

		choose: function ( i ) {
			var it = this.results[ i ];
			if ( ! it ) return;
			this.add( it );
			this.$input.val( '' );
			this.close();
			this.$input.trigger( 'focus' );
		},

		addFreeText: function ( text ) {
			text = $.trim( text );
			if ( ! text ) return;
			var it = { keyword: true, title: text, id: text };
			if ( ! this.has( it ) ) this.add( it );
			this.$input.val( '' );
		},

		add: function ( item, silent ) {
			if ( ! item.unresolved && this.has( item ) ) return;
			item.post_type = item.post_type || ( this.source === 'posts' && ! item.keyword ? this.scope().post_type : item.post_type );
			this.items.push( item );
			if ( ! silent ) { this.renderChips(); this.sync(); }
		},

		removeAt: function ( i ) {
			if ( i < 0 || i >= this.items.length ) return;
			var removed = this.items.splice( i, 1 )[0];
			this.renderChips();
			this.sync();
			this.announce( 'Removed ' + this.labelOf( removed ) + '.' );
		},

		clear: function () {
			this.items = [];
			this.renderChips();
			this.sync();
			this.setNotice( '' );
		},

		renderChips: function () {
			var self = this, html = '';
			$.each( this.items, function ( i, it ) {
				var cls = 'apm-chip' + ( it.unresolved ? ' apm-chip-invalid' : '' ) + ( it.keyword ? ' apm-chip-keyword' : '' );
				var label = it.unresolved ? it.token : self.labelOf( it );
				var sub = '';
				if ( ! it.unresolved && ! it.keyword ) {
					if ( self.source === 'posts' ) sub = self.valueField === 'slug' ? it.slug : '#' + it.id;
					else if ( self.source === 'terms' ) sub = '#' + it.term_id;
				}
				html += '<li class="' + cls + '" data-index="' + i + '" title="' + esc( self.chipTitle( it ) ) + '">' +
					( it.unresolved ? '<span class="dashicons dashicons-warning" aria-hidden="true"></span>' : '' ) +
					'<span class="apm-chip-label">' + esc( label ) + '</span>' +
					( sub ? '<span class="apm-chip-sub">' + esc( sub ) + '</span>' : '' ) +
					( it.unresolved ? '<span class="screen-reader-text"> (not found)</span>' : '' ) +
					'<button type="button" class="apm-chip-remove" aria-label="Remove ' + esc( label ) + '">&times;</button></li>';
			} );
			this.$chips.html( html );
			this.$clear.prop( 'hidden', this.items.length < 2 );
			this.$root.toggleClass( 'has-items', this.items.length > 0 );
			this.$input.attr( 'placeholder', this.items.length ? '' : ( this.$root.data( 'placeholder' ) || '' ) );
			var bad = this.items.filter( function ( it ) { return it.unresolved; } );
			if ( bad.length ) {
				this.setNotice( bad.length + ' ' + ( bad.length === 1 ? 'entry' : 'entries' ) + ' could not be matched and will be ignored: ' + bad.map( function ( b ) { return b.token; } ).join( ', ' ), 'warning' );
			} else if ( this.$notice.hasClass( 'is-warning' ) ) {
				this.setNotice( '' );
			}
		},

		values: function () {
			var self = this;
			return this.items.filter( function ( it ) { return ! it.unresolved; } ).map( function ( it ) { return self.valueOf( it ); } ).filter( Boolean );
		},

		sync: function () {
			this.$hidden.val( this.values().join( ',' ) ).trigger( 'change' );
			this.$root.trigger( 'apm:change', [ this.values() ] );
		},

		setNotice: function ( msg, type ) {
			this.$notice.removeClass( 'is-warning is-info' );
			if ( ! msg ) { this.$notice.prop( 'hidden', true ).text( '' ); return; }
			this.$notice.addClass( 'is-' + ( type || 'info' ) ).text( msg ).prop( 'hidden', false );
		},

		announce: function ( msg ) {
			// Off-screen live region for screen readers only.
			var $sr = this.$root.find( '.apm-ac-sr' );
			if ( ! $sr.length ) $sr = $( '<span class="screen-reader-text apm-ac-sr" aria-live="polite"></span>' ).appendTo( this.$root );
			$sr.text( msg );
		},

		/**
		 * Replace/append chips from a list of raw tokens (IDs, slugs,
		 * keywords) — resolved in ONE request; tokens with no exact match
		 * stay visible as flagged chips but are never submitted.
		 */
		setValues: function ( tokens, append ) {
			var self = this;
			tokens = ( tokens || [] ).map( function ( t ) { return String( t ).trim(); } ).filter( Boolean );
			if ( ! append ) this.items = [];
			if ( ! tokens.length ) { this.renderChips(); this.sync(); return $.Deferred().resolve().promise(); }

			if ( this.freeText ) {
				tokens.forEach( function ( t ) { self.add( { keyword: true, title: t, id: t }, true ); } );
				this.renderChips(); this.sync();
				return $.Deferred().resolve().promise();
			}

			if ( this.source === 'taxonomies' ) {
				var list = taxonomiesFor( this.scope().post_type || '__all' );
				tokens.forEach( function ( t ) {
					var hit = list.filter( function ( x ) { return x.name === t || String( x.label ).toLowerCase() === t.toLowerCase(); } )[0];
					self.add( hit ? $.extend( {}, hit ) : { unresolved: true, token: t }, true );
				} );
				this.renderChips(); this.sync();
				return $.Deferred().resolve().promise();
			}

			var s = this.scope();
			this.$root.addClass( 'is-loading' );
			this.setNotice( 'Matching ' + tokens.length + ' ' + ( tokens.length === 1 ? 'entry' : 'entries' ) + '…', 'info' );
			return post( ENDPOINTS[ this.source ], { ids: tokens.join( '\n' ), post_type: s.post_type, taxonomy: s.taxonomy } ).done( function ( res ) {
				self.$root.removeClass( 'is-loading' );
				if ( ! res || ! res.success ) { self.setNotice( errorMessage( res, 'Could not match the pasted entries.' ), 'warning' ); return; }
				var found = 0;
				( res.data.items || [] ).forEach( function ( it ) { if ( ! self.has( it ) ) { self.add( it, true ); found++; } } );
				( res.data.unresolved || [] ).forEach( function ( t ) { self.add( { unresolved: true, token: t }, true ); } );
				self.setNotice( '' );
				self.renderChips();
				self.sync();
				if ( ! ( res.data.unresolved || [] ).length && found ) self.announce( 'Added ' + found + ' item(s).' );
			} ).fail( function ( xhr ) {
				self.$root.removeClass( 'is-loading' );
				self.setNotice( 'Could not match the pasted entries' + ( xhr && xhr.status ? ' (HTTP ' + xhr.status + ')' : '' ) + '.', 'warning' );
			} );
		},

		/**
		 * The post type / taxonomy this field is scoped to changed: drop
		 * chips that no longer belong and say so.
		 */
		onScopeChange: function ( which ) {
			var self = this;
			this.abort();
			this.close();
			var s = this.scope();
			var allowedTax = taxonomiesFor( s.post_type ).map( function ( t ) { return t.name; } );
			var keep = [], dropped = 0;
			this.items.forEach( function ( it ) {
				var ok = true;
				if ( it.unresolved ) ok = false;
				else if ( self.source === 'posts' && ! it.keyword ) ok = ! it.post_type || it.post_type === s.post_type;
				else if ( self.source === 'terms' ) ok = s.taxonomy ? it.taxonomy === s.taxonomy : allowedTax.indexOf( it.taxonomy ) !== -1;
				else if ( self.source === 'taxonomies' ) ok = allowedTax.indexOf( it.name ) !== -1;
				if ( ok ) keep.push( it ); else dropped++;
			} );
			if ( ! dropped ) return;
			this.items = keep;
			this.renderChips();
			this.sync();
			var label = which === 'taxonomy' ? 'taxonomy' : 'post type';
			this.setNotice( 'Removed ' + dropped + ' ' + ( dropped === 1 ? 'selection that doesn’t' : 'selections that don’t' ) + ' belong to the new ' + label + '.', 'info' );
		},
	};

	$( '.apm-ac' ).each( function () { new Autocomplete( this ); } );

	// Selection cards behave as a radio group for keyboard / AT users.
	$( '.apm-card-grid' ).attr( 'role', 'radiogroup' ).find( '.apm-card' ).each( function () {
		$( this ).attr( { role: 'radio', tabindex: 0, 'aria-checked': $( this ).hasClass( 'selected' ) ? 'true' : 'false' } );
	} );
	window.APMAutocomplete = Autocomplete;

	function acOf( selector ) { return $( selector ).closest( '.apm-ac' ).data( 'apmAc' ); }

	/* =====================================================================
	 * Generic wizard engine — used by both #apm-export-app and #apm-import-app.
	 * =================================================================== */

	function initWizard( $app, opts ) {
		var totalSteps = $app.find( '.apm-wizard-pane' ).length;
		var current = 1;
		var $counter = $( '<span class="apm-step-counter"></span>' );
		$app.find( '.apm-wizard-footer .apm-footer-right' ).prepend( $counter );
		$app.find( '.apm-wizard-steps' ).attr( 'role', 'list' );
		$app.find( '.apm-wizard-step' ).attr( { role: 'listitem', tabindex: 0 } );

		function show( step, noFocus ) {
			$app.find( '.apm-wizard-pane' ).removeClass( 'active' );
			var $pane = $app.find( '.apm-wizard-pane[data-pane="' + step + '"]' ).addClass( 'active' );
			$app.find( '.apm-wizard-step' ).each( function () {
				var s = parseInt( $( this ).data( 'step' ), 10 );
				$( this ).toggleClass( 'done', s < step ).toggleClass( 'active', s === step ).toggleClass( 'upcoming', s > step );
				if ( s === step ) $( this ).attr( 'aria-current', 'step' ); else $( this ).removeAttr( 'aria-current' );
			} );
			$app.find( '.apm-wizard-footer .apm-back-btn' ).css( 'visibility', step === 1 ? 'hidden' : 'visible' );
			$app.find( '.apm-wizard-footer .apm-next-btn' ).toggle( step < totalSteps );
			$counter.text( 'Step ' + step + ' of ' + totalSteps );
			current = step;
			if ( opts.onShow ) opts.onShow( step );
			if ( ! noFocus ) {
				var h = $pane.find( 'h2' ).first().attr( 'tabindex', -1 )[0];
				if ( h ) h.focus( { preventScroll: true } );
				var top = $app.offset().top - 40;
				if ( window.scrollY > top ) window.scrollTo( { top: top, behavior: 'smooth' } );
			}
		}

		function go( target ) {
			if ( target > current ) {
				for ( var s = current; s < target; s++ ) {
					if ( opts.canAdvance && ! opts.canAdvance( s ) ) { if ( s !== current ) show( s ); return; }
				}
			}
			show( target );
		}

		$app.find( '.apm-next-btn' ).on( 'click', function () { if ( current < totalSteps ) go( current + 1 ); } );
		$app.find( '.apm-back-btn' ).on( 'click', function () { if ( current > 1 ) show( current - 1 ); } );
		$app.find( '.apm-wizard-step' ).on( 'click keydown', function ( e ) {
			if ( e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ' ) return;
			e.preventDefault();
			var target = parseInt( $( this ).data( 'step' ), 10 );
			if ( target <= current || ! opts.canJumpTo || opts.canJumpTo( target ) ) go( target );
		} );

		show( 1, true );
		return { show: show, current: function () { return current; } };
	}

	/* =====================================================================
	 * Field catalog (shared by export field-selection and import mapping)
	 * =================================================================== */

	function ensureFieldCatalog( entity, postType, cb ) {
		entity = entity || 'post';
		postType = postType || 'post';
		var key = entity + ':' + postType;
		if ( state.fieldCatalog[ key ] ) { cb( state.fieldCatalog[ key ] ); return; }
		post( 'apm_get_fields', { entity: entity, post_type: postType } ).done( function ( res ) {
			if ( res.success ) { state.fieldCatalog[ key ] = res.data; cb( res.data ); }
			else UI.toast( errorMessage( res, 'Could not load the field list.' ), 'error' );
		} ).fail( onFail );
	}

	/**
	 * Normalizes the catalog into groups: [{ key, label, fields: [{selector,label,source,column}] }]
	 */
	function buildGroups( catalog ) {
		var groups = [];
		var coreLabels = { general: 'Core Fields', taxonomy: 'Taxonomies', images: 'Media' };

		$.each( catalog.core, function ( section, fields ) {
			var groupFields = [];
			$.each( fields, function ( key, label ) {
				groupFields.push( { selector: key, label: label, source: key, exportColumn: key } );
			} );
			groups.push( { key: 'core_' + section, label: coreLabels[ section ] || section, fields: groupFields } );
		} );

		if ( catalog.acf_active && catalog.acf.length ) {
			var acfFields = [];
			$.each( catalog.acf, function ( i, f ) {
				if ( f.selector.indexOf( '.' ) !== -1 ) return; // Only top-level ACF fields are independently selectable (see backend note on repeaters).
				acfFields.push( { selector: 'acf.' + f.selector, label: f.label + ' [' + f.type + ']', source: 'ACF: ' + f.name, exportColumn: 'acf_' + f.name } );
			} );
			groups.push( { key: 'acf', label: 'ACF Fields', fields: acfFields } );
		}

		if ( catalog.yoast_active && catalog.yoast.length ) {
			var yoastFields = [];
			$.each( catalog.yoast, function ( i, key ) {
				yoastFields.push( { selector: 'yoast.' + key, label: key.replace( 'yoast_', '' ).replace( /_/g, ' ' ), source: 'Yoast: ' + key, exportColumn: key } );
			} );
			groups.push( { key: 'yoast', label: 'Yoast SEO', fields: yoastFields } );
		}

		if ( catalog.custom_meta && Object.keys( catalog.custom_meta ).length ) {
			var metaFields = [];
			$.each( catalog.custom_meta, function ( key ) {
				metaFields.push( { selector: 'custom_meta.' + key, label: key, source: 'Meta: ' + key, exportColumn: key } );
			} );
			groups.push( { key: 'custom_meta', label: 'Custom Meta / Hidden Meta', fields: metaFields } );
		}

		return groups;
	}

	function renderFieldGroups( $container, groups, mode ) {
		var html = '';
		$.each( groups, function ( gi, group ) {
			if ( ! group.fields.length ) return;
			html += '<div class="apm-field-group" data-group="' + esc( group.key ) + '">' +
				'<div class="apm-field-group-header"><span><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span> ' + esc( group.label ) +
				' <span class="apm-group-count">' + group.fields.length + '</span></span>' +
				'<label><input type="checkbox" class="apm-group-toggle" checked> ' + ( mode === 'export' ? 'All' : '' ) + '</label></div><div class="apm-field-group-body">';
			$.each( group.fields, function ( fi, field ) {
				html += '<label class="apm-field-row" data-selector="' + esc( field.selector ) + '">' +
					( mode === 'export' ? '<input type="checkbox" class="apm-field-check" checked>' : '' ) +
					'<span class="apm-field-label">' + esc( field.label ) + '</span>' +
					'<span class="apm-field-source">' + esc( field.source ) + '</span>' +
					'<span class="apm-field-column">' + ( mode === 'export' ? esc( field.exportColumn ) : '→' ) + '</span></label>';
			} );
			html += '</div></div>';
		} );
		$container.html( html || '<p class="description">No fields found for this selection.</p>' );
		updateGroupCounts( $container );
	}

	function updateGroupCounts( $container ) {
		$container.find( '.apm-field-group' ).each( function () {
			var $g = $( this );
			var $checks = $g.find( '.apm-field-check' );
			if ( ! $checks.length ) return;
			var on = $checks.filter( ':checked' ).length;
			$g.find( '.apm-group-count' ).text( on + ' / ' + $checks.length );
			$g.find( '.apm-group-toggle' ).prop( { checked: on === $checks.length, indeterminate: on > 0 && on < $checks.length } );
		} );
	}

	// Delegated once for every field-group container.
	$( document ).on( 'click', '.apm-field-group-header', function ( e ) {
		if ( $( e.target ).is( 'input, label' ) ) return;
		$( this ).closest( '.apm-field-group' ).toggleClass( 'collapsed' );
	} );
	$( document ).on( 'change', '.apm-group-toggle', function () {
		var $g = $( this ).closest( '.apm-field-group' );
		$g.find( '.apm-field-check' ).prop( 'checked', $( this ).is( ':checked' ) );
		updateGroupCounts( $g.parent() );
	} );
	$( document ).on( 'change', '.apm-field-check', function () { updateGroupCounts( $( this ).closest( '.apm-field-group' ).parent() ); } );

	function filterFieldGroups( $container, term ) {
		term = term.toLowerCase();
		$container.find( '.apm-field-row' ).each( function () {
			this.hidden = term ? this.textContent.toLowerCase().indexOf( term ) === -1 : false;
		} );
		$container.find( '.apm-field-group' ).each( function () {
			var anyVisible = $( this ).find( '.apm-field-row' ).filter( function () { return ! this.hidden; } ).length > 0;
			this.hidden = ! anyVisible;
			if ( term ) $( this ).removeClass( 'collapsed' );
		} );
	}

	/* =====================================================================
	 * EXPORT WIZARD
	 * =================================================================== */

	var $exportApp = $( '#apm-export-app' );
	if ( $exportApp.length ) {

		$( '#apm-export-back' ).addClass( 'apm-back-btn' );
		$( '#apm-export-next' ).addClass( 'apm-next-btn' );

		var SELECTION_TARGETS = { ids: '#apm-export-ids', slugs: '#apm-export-slugs', taxonomy: '#apm-export-terms' };
		var SELECTION_ERRORS = { ids: 'Pick at least one post to export, or choose “All posts”.', slugs: 'Pick at least one post to export, or choose “All posts”.', taxonomy: 'Pick at least one term, or choose “All posts”.' };

		function validateExportSelection() {
			if ( state.exportEntity !== 'post' ) return true;
			var sel = $( '#apm-export-selection' ).val();
			var target = SELECTION_TARGETS[ sel ];
			if ( target && ! $( target ).val() ) {
				UI.fieldError( $( '#apm-export-selection-error' ), SELECTION_ERRORS[ sel ] );
				$exportApp.find( '.apm-selection-sub[data-selection="' + sel + '"] .apm-ac-input' ).trigger( 'focus' );
				return false;
			}
			UI.fieldError( $( '#apm-export-selection-error' ), '' );
			return true;
		}

		var exportWizard = initWizard( $exportApp, {
			canAdvance: function ( step ) { return step !== 3 || validateExportSelection(); },
			onShow: function ( step ) { if ( step === 4 ) loadExportFieldGroups(); },
		} );

		$exportApp.on( 'click keydown', '.apm-card:not(.disabled)', function ( e ) {
			if ( e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ' ) return;
			e.preventDefault();
			$( this ).siblings().removeClass( 'selected' ).attr( 'aria-checked', 'false' );
			$( this ).addClass( 'selected' ).attr( 'aria-checked', 'true' );
			if ( $( this ).data( 'format' ) ) {
				$( '#apm-export-format' ).val( $( this ).data( 'format' ) );
			}
			if ( $( this ).data( 'value' ) && $( this ).closest( '.apm-wizard-pane' ).data( 'pane' ) == 1 ) {
				state.exportEntity = $( this ).data( 'value' );
				applyEntityToExportFilters( state.exportEntity );
				$( '#apm-export-field-groups' ).data( 'loaded', false ); // Field catalog depends on the entity — force a reload.
			}
		} );

		function applyEntityToExportFilters( entity ) {
			$exportApp.find( '.apm-filter-pane' ).hide();
			$exportApp.find( '.apm-filter-pane[data-filter-entity="' + entity + '"]' ).show();
			$( '#apm-export-detected-badges' ).toggle( entity === 'post' );
			$( '#apm-export-post-type-row' ).toggle( true );
		}

		$( '#apm-export-selection' ).on( 'change', function () {
			var val = $( this ).val();
			$exportApp.find( '.apm-selection-sub' ).each( function () { this.hidden = $( this ).data( 'selection' ) !== val; } );
			UI.fieldError( $( '#apm-export-selection-error' ), '' );
		} );
		$exportApp.on( 'apm:change', '.apm-selection-sub .apm-ac', function () { UI.fieldError( $( '#apm-export-selection-error' ), '' ); } );

		$( '#apm-export-post-type' ).on( 'change', function () {
			$( '#apm-export-field-groups' ).data( 'loaded', false ); // ACF/custom-meta catalog depends on the post type too.
		} );

		function loadExportFieldGroups() {
			if ( $( '#apm-export-field-groups' ).data( 'loaded' ) ) return;
			$( '#apm-export-field-groups' ).html( '<p class="apm-loading"><span class="spinner is-active"></span> Loading fields…</p>' );
			ensureFieldCatalog( state.exportEntity, $( '#apm-export-post-type' ).val(), function ( catalog ) {
				renderFieldGroups( $( '#apm-export-field-groups' ), buildGroups( catalog ), 'export' );
				$( '#apm-export-field-groups' ).data( 'loaded', true );
			} );
		}

		function setAllFields( on ) {
			$( '#apm-export-field-groups .apm-field-check, #apm-export-field-groups .apm-group-toggle' ).prop( 'checked', on );
			updateGroupCounts( $( '#apm-export-field-groups' ) );
		}
		$( '#apm-export-field-search' ).on( 'input', function () { filterFieldGroups( $( '#apm-export-field-groups' ), $( this ).val() ); } );
		$( '#apm-export-select-all, #apm-export-reset-defaults' ).on( 'click', function () { setAllFields( true ); } );
		$( '#apm-export-select-none' ).on( 'click', function () { setAllFields( false ); } );

		function collectFieldConfig() {
			// If the field-selection step was never opened, treat as "export everything" (empty enabled array = no filtering, per backend default).
			if ( ! $( '#apm-export-field-groups' ).data( 'loaded' ) ) return { enabled: [] };
			var enabled = [];
			$( '#apm-export-field-groups .apm-field-row' ).each( function () {
				if ( $( this ).find( '.apm-field-check' ).is( ':checked' ) ) enabled.push( $( this ).data( 'selector' ) );
			} );
			return { enabled: enabled };
		}

		function exportArgs() {
			var entity = state.exportEntity;

			if ( 'taxonomies' === entity ) {
				return {
					entity: entity,
					format: $( '#apm-export-format' ).val(),
					post_type: $( '#apm-export-post-type' ).val(),
					taxonomies: splitList( $( '#apm-export-tax-list' ).val() ),
					term_search: $( '#apm-export-term-search' ).val(),
					hide_empty: $( '#apm-export-hide-empty' ).is( ':checked' ) ? 1 : 0,
					batch_size: $( '#apm-export-batch-size' ).val(),
				};
			}

			var selection = $( '#apm-export-selection' ).val();
			var payload = {
				entity: entity,
				format: $( '#apm-export-format' ).val(),
				post_type: $( '#apm-export-post-type' ).val(),
				selection: selection,
				status: $( '#apm-export-status' ).val(),
				batch_size: $( '#apm-export-batch-size' ).val(),
				field_config: JSON.stringify( collectFieldConfig() ),
				limit: $( '#apm-export-limit' ).val() || 0,
				offset: $( '#apm-export-offset' ).val() || 0,
				title_search: splitList( $( '#apm-export-title-search' ).val() ),
				exclude_titles: splitList( $( '#apm-export-exclude-titles' ).val() ),
				exclude_ids: splitList( $( '#apm-export-exclude-ids' ).val() ),
				date_created_after: $( '#apm-export-created-after' ).val(),
				date_created_before: $( '#apm-export-created-before' ).val(),
				date_modified_after: $( '#apm-export-modified-after' ).val(),
				date_modified_before: $( '#apm-export-modified-before' ).val(),
			};
			if ( selection === 'ids' ) payload.post_ids = splitList( $( '#apm-export-ids' ).val() );
			if ( selection === 'slugs' ) payload.slugs = splitList( $( '#apm-export-slugs' ).val() );
			if ( selection === 'taxonomy' ) {
				payload.terms = splitList( $( '#apm-export-terms' ).val() );
				payload.taxonomy = $( '#apm-export-selection-taxonomy' ).val();
			}
			return payload;
		}
		window.APMExportArgs = exportArgs; // Used by the UI test harness.

		$( '#apm-export-load-profile' ).on( 'change', function () {
			var id = $( this ).val();
			if ( ! id ) return;
			post( 'apm_get_mapping', { id: id } ).done( function ( res ) {
				if ( ! res.success ) { UI.toast( errorMessage( res ), 'error' ); return; }
				var cfg = res.data.config || {};
				var a = cfg.export_args;
				if ( ! a ) return;
				if ( a.entity ) $exportApp.find( '.apm-card[data-value="' + a.entity + '"]' ).trigger( 'click' );
				if ( a.post_type && $( '#apm-export-post-type option[value="' + a.post_type + '"]' ).length ) $( '#apm-export-post-type' ).val( a.post_type ).trigger( 'change' );
				if ( a.format ) $exportApp.find( '.apm-card[data-format="' + a.format + '"]' ).trigger( 'click' );
				if ( a.selection ) $( '#apm-export-selection' ).val( a.selection ).trigger( 'change' );
				if ( a.status ) $( '#apm-export-status' ).val( a.status );
				if ( a.taxonomy ) $( '#apm-export-selection-taxonomy' ).val( a.taxonomy ).trigger( 'change' );
				[ [ '#apm-export-ids', a.post_ids ], [ '#apm-export-slugs', a.slugs ], [ '#apm-export-terms', a.terms ], [ '#apm-export-title-search', a.title_search ],
					[ '#apm-export-exclude-titles', a.exclude_titles ], [ '#apm-export-exclude-ids', a.exclude_ids ], [ '#apm-export-tax-list', a.taxonomies ] ].forEach( function ( pair ) {
					var ac = acOf( pair[0] );
					if ( ac && pair[1] && pair[1].length ) ac.setValues( pair[1] );
				} );
				$.each( { '#apm-export-limit': a.limit, '#apm-export-offset': a.offset, '#apm-export-batch-size': a.batch_size, '#apm-export-term-search': a.term_search,
					'#apm-export-created-after': a.date_created_after, '#apm-export-created-before': a.date_created_before,
					'#apm-export-modified-after': a.date_modified_after, '#apm-export-modified-before': a.date_modified_before }, function ( sel, v ) {
					if ( v !== undefined && v !== null && v !== '' && v !== '0' && v !== 0 ) $( sel ).val( v );
				} );
				if ( a.hide_empty !== undefined ) $( '#apm-export-hide-empty' ).prop( 'checked', !! parseInt( a.hide_empty, 10 ) );
				UI.toast( 'Profile “' + res.data.name + '” loaded.', 'info' );
			} ).fail( onFail );
		} );

		var exportStart = 0;
		$( '#apm-run-export' ).on( 'click', function () {
			if ( ! validateExportSelection() ) { exportWizard.show( 3 ); validateExportSelection(); return; }
			var $btn = $( this ).prop( 'disabled', true ).addClass( 'is-busy' );
			$( '#apm-export-result' ).empty();
			exportStart = Date.now();
			UI.progress( $( '#apm-export-progress' ), { processed: 0, total: 0, title: 'Preparing export…' } );
			post( 'apm_start_export_job', exportArgs() ).done( function ( res ) {
				if ( ! res.success ) {
					$btn.prop( 'disabled', false ).removeClass( 'is-busy' );
					$( '#apm-export-progress' ).prop( 'hidden', true );
					UI.notice( $( '#apm-export-result' ), 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' );
					UI.toast( errorMessage( res ), 'error' );
					return;
				}
				state.exportJobId = res.data.job_id;
				pollExportBatch( $btn );
			} ).fail( function ( xhr ) { $btn.prop( 'disabled', false ).removeClass( 'is-busy' ); $( '#apm-export-progress' ).prop( 'hidden', true ); onFail( xhr ); } );
		} );

		function pollExportBatch( $btn ) {
			post( 'apm_process_export_batch', { job_id: state.exportJobId } ).done( function ( res ) {
				if ( ! res.success ) {
					$btn.prop( 'disabled', false ).removeClass( 'is-busy' );
					UI.notice( $( '#apm-export-result' ), 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' );
					UI.toast( 'Export failed.', 'error' );
					return;
				}
				var job = res.data.job;
				UI.progress( $( '#apm-export-progress' ), {
					processed: job.offset_row, total: job.total_rows, start: exportStart, finished: !! res.data.done,
					title: res.data.done ? 'Export complete' : 'Exporting…', counts: [ [ 'Exported', job.processed_count, 'success' ] ],
				} );

				if ( res.data.done ) {
					$btn.prop( 'disabled', false ).removeClass( 'is-busy' );
					var dlUrl = downloadUrl( 'export', job.id );
					UI.notice( $( '#apm-export-result' ), 'success', '<p><strong>' + esc( job.processed_count ) + ' record(s) exported.</strong> <a class="button button-primary" href="' + esc( dlUrl ) + '"><span class="dashicons dashicons-download" aria-hidden="true"></span> Download file</a></p>' );
					UI.toast( 'Export finished — ' + job.processed_count + ' record(s).', 'success' );
				} else {
					setTimeout( function () { pollExportBatch( $btn ); }, 300 );
				}
			} ).fail( function ( xhr ) { $btn.prop( 'disabled', false ).removeClass( 'is-busy' ); onFail( xhr ); } );
		}

		$( '#apm-save-export-profile' ).on( 'click', function () {
			UI.dialog( { title: 'Save export profile', message: 'Saves the current filters, format and options so you can rerun this export later.', input: { label: 'Profile name', required: true, requiredMessage: 'Give the profile a name.' }, confirmLabel: 'Save profile' } ).done( function ( name ) {
				post( 'apm_save_mapping', { name: name, type: 'export', config: JSON.stringify( { export_args: exportArgs() } ) } ).done( function ( res ) {
					if ( res.success ) UI.toast( 'Profile “' + name + '” saved.', 'success' );
					else UI.toast( errorMessage( res ), 'error' );
				} ).fail( onFail );
			} );
		} );
	}

	/* =====================================================================
	 * IMPORT WIZARD
	 * =================================================================== */

	var $importApp = $( '#apm-import-app' );
	if ( $importApp.length ) {

		$( '#apm-import-back' ).addClass( 'apm-back-btn' );
		$( '#apm-import-next' ).addClass( 'apm-next-btn' );

		var uploading = false;
		var importWizard = initWizard( $importApp, {
			canAdvance: function ( step ) {
				if ( step === 1 && ! state.uploadedFile ) {
					UI.fieldError( $( '#apm-upload-status' ).addClass( 'apm-field-error' ).attr( 'role', 'alert' ), uploading ? 'Please wait for the upload to finish.' : 'Choose or drop a file to import first.' );
					$( '#apm-dropzone' ).addClass( 'has-error' );
					return false;
				}
				return true;
			},
			canJumpTo: function () { return !! state.uploadedFile; },
			onShow: function ( step ) {
				if ( step === 3 ) renderImportMappingStep();
			},
		} );

		// --- Step 1: data-type cards (Posts / Taxonomies) ---
		$importApp.on( 'click keydown', '.apm-card[data-entity]', function ( e ) {
			if ( e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ' ) return;
			e.preventDefault();
			$( this ).siblings().removeClass( 'selected' ).attr( 'aria-checked', 'false' );
			$( this ).addClass( 'selected' ).attr( 'aria-checked', 'true' );
			state.importEntity = $( this ).data( 'entity' );
			$( '#apm-import-entity' ).val( state.importEntity );
			$( '#apm-import-post-type-row' ).toggle( state.importEntity === 'post' );
			$( '#apm-import-default-taxonomy-row' ).toggle( state.importEntity === 'taxonomies' );
			applyEntityToStep2( state.importEntity );
			$( '#apm-mapping-groups' ).data( 'rendered', false ); // Field catalog depends on the entity — force a remap on Step 3.
		} );
		applyEntityToStep2( state.importEntity ); // Initialize Step 2 for the default entity (Posts).
		$( '#apm-import-post-type' ).on( 'change', function () { $( '#apm-mapping-groups' ).data( 'rendered', false ); } );

		$( '#apm-load-profile' ).on( 'change', function () {
			var id = $( this ).val();
			if ( ! id ) return;
			post( 'apm_get_mapping', { id: id } ).done( function ( res ) {
				if ( ! res.success ) { UI.toast( errorMessage( res ), 'error' ); return; }
				var cfg = res.data.config || {};
				if ( cfg.match_strategy ) $( '#apm-match-strategy' ).val( cfg.match_strategy );
				if ( cfg.existing_action ) $( '#apm-existing-action' ).val( cfg.existing_action );
				if ( cfg.options && cfg.options.image_match_strategy ) $( '#apm-image-strategy' ).val( cfg.options.image_match_strategy );
				state.loadedMapping = cfg.mapping || {};
				state.importTransforms = cfg.transforms || {};
				$( '#apm-mapping-groups' ).data( 'rendered', false );
				UI.toast( 'Profile “' + res.data.name + '” loaded.', 'info' );
			} ).fail( onFail );
		} );

		// --- Step 1: drag-and-drop upload ---
		var FORMAT_LABELS = { csv: 'CSV', json: 'JSON', xlsx: 'Excel (XLSX)' };
		var allowed = ( $( '#apm-import-file' ).attr( 'accept' ) || '.csv,.json,.xlsx' ).replace( /\./g, '' ).split( ',' );
		var $drop = $( '#apm-dropzone' );
		var $card = $( '#apm-file-card' );

		function setFileState( type, text ) {
			$card.attr( 'data-state', type ).find( '.apm-file-state' ).html(
				( type === 'loading' ? '<span class="spinner is-active"></span>' : '<span class="dashicons dashicons-' + ( type === 'ok' ? 'yes-alt' : 'warning' ) + '" aria-hidden="true"></span>' ) + '<span>' + esc( text ) + '</span>'
			);
		}

		/** Light content sniff, so a mislabeled file is caught before upload. */
		function sniffFormat( file, ext, cb ) {
			if ( ext === 'xlsx' ) {
				file.slice( 0, 4 ).arrayBuffer().then( function ( b ) {
					var u = new Uint8Array( b );
					cb( u[0] === 0x50 && u[1] === 0x4b ? null : 'This doesn’t look like a real .xlsx file (expected a ZIP container).' );
				} ).catch( function () { cb( null ); } );
				return;
			}
			file.slice( 0, 2048 ).text().then( function ( t ) {
				t = t.replace( /^﻿/, '' ).trim();
				if ( ext === 'json' && t && t[0] !== '[' && t[0] !== '{' ) return cb( 'This .json file doesn’t start with [ or { — it may not be valid JSON.' );
				if ( ext === 'csv' && ( t[0] === '[' || t[0] === '{' ) ) return cb( 'This .csv file looks like JSON — rename it to .json if so.' );
				cb( null );
			} ).catch( function () { cb( null ); } );
		}

		function handleFile( file ) {
			if ( ! file ) return;
			UI.fieldError( $( '#apm-upload-status' ), '' );
			$drop.removeClass( 'has-error' );
			var ext = ( file.name.split( '.' ).pop() || '' ).toLowerCase();
			$card.prop( 'hidden', false ).attr( 'data-format', ext );
			$card.find( '.apm-file-icon' ).text( ext.toUpperCase().slice( 0, 4 ) );
			$card.find( '.apm-file-name' ).text( file.name );
			$card.find( '.apm-file-meta' ).text( formatBytes( file.size ) + ' · ' + ( FORMAT_LABELS[ ext ] || 'Unknown format' ) );
			$drop.addClass( 'is-compact' );

			if ( allowed.indexOf( ext ) === -1 ) {
				setFileState( 'error', 'Unsupported file type — use ' + allowed.map( function ( a ) { return '.' + a; } ).join( ', ' ) + '.' );
				state.uploadedFile = null;
				return;
			}
			sniffFormat( file, ext, function ( warning ) {
				if ( warning ) { setFileState( 'error', warning ); state.uploadedFile = null; return; }
				upload( file );
			} );
		}

		function upload( file ) {
			var formData = new FormData();
			formData.append( 'action', 'apm_upload_file' );
			formData.append( 'nonce', APM.nonce );
			formData.append( 'file', file );
			uploading = true;
			state.uploadedFile = null;
			setFileState( 'loading', 'Uploading…' );
			$.ajax( { url: APM.ajax_url, type: 'POST', data: formData, processData: false, contentType: false } ).done( function ( res ) {
				if ( ! res.success ) { setFileState( 'error', errorMessage( res, 'Upload failed.' ) ); return; }
				state.uploadedFile = res.data;
				$( '#apm-mapping-groups' ).data( 'rendered', false ); // New header — rebuild the mapping table.
				setFileState( 'ok', res.data.format === 'json' ? 'Ready — canonical JSON, no mapping needed' : 'Ready — ' + res.data.header.length + ' columns detected' );
				UI.toast( 'File uploaded. Continue to the next step.', 'success' );
			} ).fail( function ( xhr ) {
				setFileState( 'error', 'Upload failed' + ( xhr && xhr.status ? ' (HTTP ' + xhr.status + ')' : '' ) + '. The file may exceed the server’s upload limit.' );
			} ).always( function () { uploading = false; } );
		}

		$( '#apm-import-file' ).on( 'change', function () { handleFile( this.files[0] ); this.value = ''; } );
		$( '#apm-file-replace' ).on( 'click', function () { $( '#apm-import-file' ).trigger( 'click' ); } );
		$drop.on( 'dragenter dragover', function ( e ) { e.preventDefault(); $drop.addClass( 'is-dragover' ); } );
		$drop.on( 'dragleave dragend', function ( e ) { if ( ! e.relatedTarget || ! $drop[0].contains( e.relatedTarget ) ) $drop.removeClass( 'is-dragover' ); } );
		$drop.on( 'drop', function ( e ) {
			e.preventDefault();
			$drop.removeClass( 'is-dragover' );
			var dt = e.originalEvent.dataTransfer;
			if ( dt && dt.files && dt.files.length ) handleFile( dt.files[0] );
		} );
		$drop.on( 'keydown', function ( e ) { if ( e.key === 'Enter' || e.key === ' ' ) { e.preventDefault(); $( '#apm-import-file' ).trigger( 'click' ); } } ).attr( { tabindex: 0, role: 'button' } );

		// --- Step 3: mapping table ---
		function renderImportMappingStep() {
			if ( ! state.uploadedFile ) return;
			if ( state.uploadedFile.format === 'json' ) {
				$( '#apm-json-no-mapping-notice' ).show();
				$( '#apm-csv-mapping-ui' ).hide();
				return;
			}
			$( '#apm-json-no-mapping-notice' ).hide();
			$( '#apm-csv-mapping-ui' ).show();
			if ( $( '#apm-mapping-groups' ).data( 'rendered' ) ) return;

			$( '#apm-mapping-groups' ).html( '<p class="apm-loading"><span class="spinner is-active"></span> Loading fields…</p>' );
			ensureFieldCatalog( state.importEntity, $( '#apm-import-post-type' ).val(), function ( catalog ) {
				var groups = buildGroups( catalog );
				var $container = $( '#apm-mapping-groups' ).empty();
				renderSourceMappingTable( $container, state.uploadedFile.header, groups );
				$( '#apm-mapping-groups' ).data( 'rendered', true );
			} );
		}

		function flattenTargetOptions( groups ) {
			var opts = [ { value: '', label: '— Do not import / Skip —' } ];
			$.each( groups, function ( gi, group ) {
				$.each( group.fields, function ( fi, f ) { opts.push( { value: f.selector, label: group.label + ' → ' + f.label } ); } );
			} );
			return opts;
		}

		function guessTarget( sourceColumn ) {
			var known = [ 'title', 'slug', 'content', 'excerpt', 'status', 'date', 'menu_order', 'comment_status', 'ping_status' ];
			if ( known.indexOf( sourceColumn ) !== -1 ) return sourceColumn;
			if ( sourceColumn.indexOf( 'acf_' ) === 0 ) return 'acf.' + sourceColumn.substring( 4 );
			if ( sourceColumn.indexOf( 'yoast_' ) === 0 ) return 'yoast.' + sourceColumn;
			if ( sourceColumn.indexOf( '_' ) === 0 ) return 'custom_meta.' + sourceColumn;
			return '';
		}

		function renderSourceMappingTable( $container, header, groups ) {
			var options = flattenTargetOptions( groups );
			var optionsHtml = options.map( function ( o ) { return '<option value="' + esc( o.value ) + '">' + esc( o.label ) + '</option>'; } ).join( '' );
			var saved = state.loadedMapping || {};
			var $list = $( '<div class="apm-field-group" data-group="mapping"></div>' );
			var $header = $( '<div class="apm-field-group-header"><span><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span> Source Columns <span class="apm-group-count">' + header.length + '</span></span><span class="apm-mapped-count"></span></div>' );
			var $body = $( '<div class="apm-field-group-body" id="apm-sortable-mapping"></div>' );

			$.each( header, function ( i, column ) {
				var $select = $( '<select class="apm-target-select"></select>' ).html( optionsHtml ).attr( 'aria-label', 'Target field for ' + column );
				var target = saved[ column ] !== undefined ? saved[ column ] : guessTarget( column );
				$select.val( target );
				if ( $select.val() === null ) $select.val( '' );

				var $row = $( '<div class="apm-field-row apm-map-row"></div>' ).attr( 'data-source', column );
				$row.append( '<span class="apm-drag-handle dashicons dashicons-menu" aria-hidden="true"></span>' );
				$row.append( $( '<span class="apm-field-label"></span>' ).text( column ) );
				$row.append( '<span class="apm-map-arrow" aria-hidden="true">→</span>' );
				$row.append( $select );
				$row.append( $( '<button type="button" class="apm-transform-btn" title="Transform values"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span><span class="screen-reader-text">Transform</span></button>' ).toggleClass( 'has-transform', !! state.importTransforms[ column ] ) );
				$body.append( $row );
			} );

			$list.append( $header ).append( $body );
			$container.append( $list );
			updateMappedCount();

			if ( $.fn.sortable ) $body.sortable( { handle: '.apm-drag-handle', axis: 'y' } );
		}

		function updateMappedCount() {
			var $s = $( '#apm-mapping-groups .apm-target-select' );
			var mapped = $s.filter( function () { return !! this.value; } ).length;
			$( '#apm-mapping-groups .apm-mapped-count' ).text( mapped + ' of ' + $s.length + ' mapped' );
			$s.each( function () { $( this ).closest( '.apm-field-row' ).toggleClass( 'is-skipped', ! this.value ); } );
		}
		$( '#apm-mapping-groups' ).on( 'change', '.apm-target-select', updateMappedCount );
		$( '#apm-mapping-groups' ).on( 'click', '.apm-transform-btn', function () { openTransformModal( $( this ).closest( '.apm-field-row' ).attr( 'data-source' ), $( this ) ); } );

		$( '#apm-mapping-search' ).on( 'input', function () { filterFieldGroups( $( '#apm-mapping-groups' ), $( this ).val() ); } );

		function collectMapping() {
			var mapping = {};
			$( '#apm-mapping-groups .apm-field-row' ).each( function () {
				var source = $( this ).attr( 'data-source' );
				var target = $( this ).find( '.apm-target-select' ).val();
				if ( target ) mapping[ source ] = target;
			} );
			return mapping;
		}

		// --- Transform modal ---
		function openTransformModal( sourceColumn, $btn ) {
			var existing = state.importTransforms[ sourceColumn ] || {};
			var $overlay = $( '<div class="apm-modal-overlay"></div>' );
			var $modal = $( '<div class="apm-modal" role="dialog" aria-modal="true" aria-label="Transform values"></div>' );
			$modal.append( $( '<h3></h3>' ).text( 'Transform: ' + sourceColumn ) );

			var $optionsWrap = $( '<div></div>' );
			var options = APM.transforms || {};
			$optionsWrap.append( '<div class="apm-transform-option"><label><input type="radio" name="apm-transform-type" value="" ' + ( ! existing.type ? 'checked' : '' ) + '> No transform</label></div>' );
			$.each( options, function ( type, label ) {
				var checked = existing.type === type ? 'checked' : '';
				var $opt = $( '<div class="apm-transform-option"><label><input type="radio" name="apm-transform-type" value="' + esc( type ) + '" ' + checked + '> ' + esc( label ) + '</label></div>' );
				var $extra = $( '<div class="apm-transform-extra' + ( checked ? ' visible' : '' ) + '"></div>' ).attr( 'data-for', type );
				function field( cls, ph, val ) { return $( '<input type="text">' ).addClass( cls ).attr( 'placeholder', ph ).val( val || '' ); }

				if ( type === 'find_replace' || type === 'regex_replace' ) {
					$extra.append( field( 'apm-t-find', type === 'regex_replace' ? 'Pattern (e.g. /foo/i)' : 'Find', existing[ type === 'regex_replace' ? 'pattern' : 'find' ] ) );
					$extra.append( field( 'apm-t-replace', 'Replace', existing.replace ) );
				} else if ( type === 'prefix' ) {
					$extra.append( field( 'apm-t-prefix', 'Prefix text', existing.prefix ) );
				} else if ( type === 'suffix' ) {
					$extra.append( field( 'apm-t-suffix', 'Suffix text', existing.suffix ) );
				} else if ( type === 'to_date' ) {
					$extra.append( field( 'apm-t-format', 'Output format, e.g. Y-m-d', existing.format || 'Y-m-d' ) );
				}

				$opt.append( $extra );
				$optionsWrap.append( $opt );
			} );

			$modal.append( $optionsWrap );
			$modal.append( '<div class="apm-modal-actions"><button type="button" class="button apm-transform-cancel">Cancel</button><button type="button" class="button button-primary apm-transform-apply">Apply</button></div>' );
			$overlay.append( $modal );
			$( 'body' ).append( $overlay );
			$modal.find( 'input:checked' ).trigger( 'focus' );

			function close() { $overlay.remove(); $( document ).off( 'keydown.apmtransform' ); if ( $btn ) $btn.trigger( 'focus' ); }
			$( document ).on( 'keydown.apmtransform', function ( e ) { if ( e.key === 'Escape' ) close(); } );

			$modal.on( 'change', 'input[name="apm-transform-type"]', function () {
				var v = $( this ).val();
				$modal.find( '.apm-transform-extra' ).removeClass( 'visible' ).filter( function () { return $( this ).attr( 'data-for' ) === v; } ).addClass( 'visible' );
			} );

			$modal.find( '.apm-transform-cancel' ).on( 'click', close );
			$overlay.on( 'mousedown', function ( e ) { if ( e.target === $overlay[0] ) close(); } );
			$modal.find( '.apm-transform-apply' ).on( 'click', function () {
				var type = $modal.find( 'input[name="apm-transform-type"]:checked' ).val();
				if ( ! type ) {
					delete state.importTransforms[ sourceColumn ];
					if ( $btn ) $btn.removeClass( 'has-transform' );
					close();
					return;
				}
				var $extra = $modal.find( '.apm-transform-extra' ).filter( function () { return $( this ).attr( 'data-for' ) === type; } );
				var config = { type: type };
				if ( type === 'find_replace' ) { config.find = $extra.find( '.apm-t-find' ).val(); config.replace = $extra.find( '.apm-t-replace' ).val(); }
				if ( type === 'regex_replace' ) { config.pattern = $extra.find( '.apm-t-find' ).val(); config.replace = $extra.find( '.apm-t-replace' ).val(); }
				if ( type === 'prefix' ) config.prefix = $extra.find( '.apm-t-prefix' ).val();
				if ( type === 'suffix' ) config.suffix = $extra.find( '.apm-t-suffix' ).val();
				if ( type === 'to_date' ) config.format = $extra.find( '.apm-t-format' ).val();

				state.importTransforms[ sourceColumn ] = config;
				if ( $btn ) $btn.addClass( 'has-transform' );
				close();
			} );
		}

		// --- Payload builder shared by preview / dry-run / real run ---
		function importPayload( extra ) {
			var mapping = state.uploadedFile.format !== 'json' ? collectMapping() : ( state.loadedMapping || {} );
			var base = {
				entity: state.importEntity,
				file_path: state.uploadedFile.file_path,
				format: state.uploadedFile.format,
				post_type: $( '#apm-import-post-type' ).val(),
				mapping: JSON.stringify( mapping ),
				transforms: JSON.stringify( state.importTransforms ),
				match_strategy: $( '#apm-match-strategy' ).val(),
				existing_action: $( '#apm-existing-action' ).val(),
				batch_size: $( '#apm-batch-size' ).val(),
			};
			if ( 'post' === state.importEntity ) {
				$.extend( base, {
					image_match_strategy: $( '#apm-image-strategy' ).val(),
					create_missing_taxonomy_terms: $( '#apm-create-taxonomy-terms' ).is( ':checked' ) ? 1 : 0,
					create_backup: $( '#apm-create-backup' ).is( ':checked' ) ? 1 : 0,
				} );
			} else if ( 'taxonomies' === state.importEntity ) {
				base.default_taxonomy = $( '#apm-import-default-taxonomy' ).val() || 'category';
				base.create_missing_parents = $( '#apm-create-missing-parents' ).is( ':checked' ) ? 1 : 0;
			}
			return $.extend( base, extra || {} );
		}

		function requireFile() {
			if ( state.uploadedFile ) return true;
			UI.toast( 'Upload a file in Step 1 first.', 'error' );
			importWizard.show( 1 );
			return false;
		}

		// --- Step 5: preview table ---
		$( '#apm-load-preview' ).on( 'click', function () {
			if ( ! requireFile() ) return;
			var $btn = $( this ).prop( 'disabled', true );
			var $wrap = $( '#apm-preview-table-wrap' ).html( '<p class="apm-loading"><span class="spinner is-active"></span> Loading preview…</p>' );
			post( 'apm_preview_import', importPayload() ).done( function ( res ) {
				if ( ! res.success ) { UI.notice( $wrap, 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' ); return; }
				renderPreviewTable( $wrap, res.data.rows );
			} ).fail( function ( xhr ) { $wrap.empty(); onFail( xhr ); } ).always( function () { $btn.prop( 'disabled', false ); } );
		} );

		function previewVerdict( r ) {
			var skip = $( '#apm-existing-action' ).val() === 'skip';
			if ( r.result === 'will_update' && skip ) return { cls: 'skip', label: 'Will skip (#' + r.existing_id + ' exists)' };
			if ( r.result === 'will_update' && $( '#apm-existing-action' ).val() === 'duplicate' ) return { cls: 'create', label: 'Will create duplicate' };
			if ( r.result === 'will_update' ) return { cls: 'update', label: 'Will update #' + r.existing_id };
			return { cls: 'create', label: 'Will create' };
		}

		function renderPreviewTable( $wrap, rows ) {
			var isTax = state.importEntity === 'taxonomies';
			var tally = { create: 0, update: 0, skip: 0, issue: 0 };
			var body = '';
			$.each( rows, function ( i, r ) {
				var v = previewVerdict( r );
				var issues = r.issues || [];
				tally[ v.cls ]++;
				if ( issues.length ) tally.issue++;
				var issueHtml = issues.map( function ( m ) { return '<span class="apm-preview-issue"><span class="dashicons dashicons-warning" aria-hidden="true"></span>' + esc( m ) + '</span>'; } ).join( '' );
				var check = function ( b ) { return '<td class="' + ( b ? 'apm-preview-yes' : 'apm-preview-no' ) + '">' + ( b ? '✓' : '—' ) + '</td>'; };
				body += '<tr class="apm-row-' + v.cls + ( issues.length ? ' apm-row-issue' : '' ) + '">';
				if ( isTax ) {
					body += '<td><strong>' + esc( r.name || '—' ) + '</strong>' + issueHtml + '</td><td><code>' + esc( r.slug || '—' ) + '</code></td><td>' + esc( r.taxonomy || '—' ) + '</td><td>' + esc( r.path || '—' ) + '</td><td>' + esc( r.count ) + '</td>';
				} else {
					body += '<td><strong>' + esc( r.title || '—' ) + '</strong>' + issueHtml + '</td><td><code>' + esc( r.slug || '—' ) + '</code></td><td>' + esc( r.status || '—' ) + '</td><td>' + esc( r.taxonomies || '—' ) + '</td>' +
						check( r.has_image ) + check( r.has_acf ) + check( r.has_yoast ) + '<td>' + esc( r.meta_count ) + '</td>';
				}
				body += '<td><span class="apm-verdict apm-verdict-' + v.cls + '">' + esc( v.label ) + '</span></td></tr>';
			} );
			var head = isTax ? '<th>Name</th><th>Slug</th><th>Taxonomy</th><th>Path</th><th>Count</th><th>Result</th>'
				: '<th>Title</th><th>Slug</th><th>Status</th><th>Taxonomies</th><th>Image</th><th>ACF</th><th>Yoast</th><th>Meta</th><th>Result</th>';
			var summary = '<div class="apm-preview-summary">' +
				'<span class="apm-verdict apm-verdict-create">' + tally.create + ' to create</span>' +
				'<span class="apm-verdict apm-verdict-update">' + tally.update + ' to update</span>' +
				( tally.skip ? '<span class="apm-verdict apm-verdict-skip">' + tally.skip + ' to skip</span>' : '' ) +
				( tally.issue ? '<span class="apm-verdict apm-verdict-issue">' + tally.issue + ' with issues</span>' : '' ) +
				'<span class="apm-muted">First ' + rows.length + ' row(s) · run the full dry run for totals</span></div>';
			if ( ! rows.length ) { UI.notice( $wrap, 'warning', '<p>No rows found in this file.</p>' ); return; }
			$wrap.html( summary + '<div class="apm-preview-scroll"><table class="widefat apm-preview-table"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>' );
		}

		function renderSummary( job, isDryRun ) {
			var type = job.failed_count > 0 ? 'warning' : 'success';
			var html = '<p><strong>' + ( isDryRun ? 'Dry run complete — nothing was written.' : 'Import complete.' ) + '</strong> <span class="apm-muted">Job #' + esc( job.id ) + '</span></p>';
			html += '<div class="apm-summary-grid">';
			[ [ 'Total rows', job.total_rows, '' ], [ 'New', job.created_count, 'create' ], [ 'Updated', job.updated_count, 'update' ], [ 'Skipped', job.skipped_count, 'skip' ], [ 'Failed', job.failed_count, 'issue' ] ].forEach( function ( s ) {
				html += '<div class="apm-summary-stat apm-summary-' + s[2] + '"><span class="apm-summary-num">' + esc( s[1] ) + '</span><span class="apm-summary-label">' + s[0] + '</span></div>';
			} );
			html += '</div>';
			if ( ! isDryRun ) {
				html += '<p><a class="button" href="?page=apm-logs&job_id=' + encodeURIComponent( job.id ) + '">View details</a>';
				if ( job.status === 'completed' ) {
					html += ' <a href="#" class="button apm-button-danger apm-rollback-link" data-job-id="' + esc( job.id ) + '">Rollback this import</a>';
				}
				html += '</p>';
			}
			UI.notice( $( '#apm-import-result' ), type, html );
		}

		var importStart = 0;
		function setRunning( on ) {
			$( '#apm-dry-run-btn, #apm-run-import-btn, #apm-load-preview' ).prop( 'disabled', on );
			$( '#apm-run-import-btn' ).toggleClass( 'is-busy', on );
		}

		function runImportJob( dryRun ) {
			if ( ! requireFile() ) return;
			var go = function () {
				setRunning( true );
				$( '#apm-import-result' ).empty();
				importStart = Date.now();
				UI.progress( $( '#apm-import-progress' ), { processed: 0, total: 0, title: dryRun ? 'Preparing dry run…' : 'Preparing import…' } );
				post( 'apm_start_import_job', importPayload( { dry_run: dryRun ? 1 : 0 } ) ).done( function ( res ) {
					if ( ! res.success ) {
						setRunning( false );
						$( '#apm-import-progress' ).prop( 'hidden', true );
						UI.notice( $( '#apm-import-result' ), 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' );
						UI.toast( errorMessage( res ), 'error' );
						return;
					}
					state.importJobId = res.data.job_id;
					pollImportBatch( dryRun );
				} ).fail( function ( xhr ) { setRunning( false ); $( '#apm-import-progress' ).prop( 'hidden', true ); onFail( xhr ); } );
			};
			if ( dryRun ) { go(); return; }
			UI.dialog( { title: 'Run the import?', message: APM.i18n.confirm_import, confirmLabel: 'Run import' } ).done( go );
		}

		function pollImportBatch( dryRun ) {
			post( 'apm_process_import_batch', { job_id: state.importJobId } ).done( function ( res ) {
				if ( ! res.success ) {
					setRunning( false );
					UI.notice( $( '#apm-import-result' ), 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' );
					UI.toast( 'Import stopped with an error.', 'error' );
					return;
				}
				var job = res.data.job;
				var label = dryRun ? 'Dry run' : 'Import';
				UI.progress( $( '#apm-import-progress' ), {
					processed: job.offset_row, total: job.total_rows, start: importStart, finished: !! res.data.done, unit: 'rows',
					title: res.data.done ? label + ' complete' : ( dryRun ? 'Dry run in progress…' : 'Importing…' ),
					counts: [ [ 'Created', job.created_count, 'create' ], [ 'Updated', job.updated_count, 'update' ], [ 'Skipped', job.skipped_count, 'skip' ], [ 'Failed', job.failed_count, 'issue' ] ],
				} );

				if ( res.data.done ) {
					setRunning( false );
					renderSummary( job, dryRun );
					UI.toast( label + ' finished' + ( job.failed_count > 0 ? ' with ' + job.failed_count + ' failure(s).' : '.' ), job.failed_count > 0 ? 'warning' : 'success' );
				} else {
					setTimeout( function () { pollImportBatch( dryRun ); }, 250 );
				}
			} ).fail( function ( xhr ) { setRunning( false ); onFail( xhr ); } );
		}

		$( '#apm-dry-run-btn' ).on( 'click', function () { runImportJob( true ); } );
		$( '#apm-run-import-btn' ).on( 'click', function () { runImportJob( false ); } );

		$( '#apm-save-import-profile' ).on( 'click', function () {
			if ( ! requireFile() ) return;
			UI.dialog( { title: 'Save mapping profile', message: 'Saves the column mapping, transforms and match settings for reuse.', input: { label: 'Profile name', required: true, requiredMessage: 'Give the profile a name.' }, confirmLabel: 'Save profile' } ).done( function ( name ) {
				var payload = importPayload( {} );
				var config = {
					mapping: JSON.parse( payload.mapping ),
					transforms: JSON.parse( payload.transforms ),
					match_strategy: payload.match_strategy,
					existing_action: payload.existing_action,
					options: { image_match_strategy: payload.image_match_strategy, create_missing_taxonomy_terms: !! payload.create_missing_taxonomy_terms },
				};
				post( 'apm_save_mapping', { name: name, type: 'import', config: JSON.stringify( config ) } ).done( function ( res ) {
					if ( res.success ) UI.toast( 'Profile “' + name + '” saved.', 'success' );
					else UI.toast( errorMessage( res ), 'error' );
				} ).fail( onFail );
			} );
		} );
	}

	/* =====================================================================
	 * Mappings page
	 * =================================================================== */

	$( document ).on( 'click', '.apm-mapping-delete', function ( e ) {
		e.preventDefault();
		var id = $( this ).data( 'id' );
		var name = $( this ).closest( 'tr' ).find( 'td' ).first().text();
		UI.dialog( { title: 'Delete “' + name + '”?', message: APM.i18n.confirm_destructive, confirmLabel: 'Delete', danger: true } ).done( function () {
			post( 'apm_delete_mapping', { id: id } ).done( function ( res ) {
				if ( ! res.success ) { UI.toast( errorMessage( res ), 'error' ); return; }
				$( 'tr[data-id="' + parseInt( id, 10 ) + '"]' ).remove();
				if ( ! $( '#apm-mappings-tbody tr' ).length ) { $( '#apm-mappings-table-wrap' ).prop( 'hidden', true ); $( '#apm-mappings-empty' ).prop( 'hidden', false ); }
				UI.toast( 'Mapping deleted.', 'success' );
			} ).fail( onFail );
		} );
	} );

	$( document ).on( 'click', '.apm-mapping-duplicate', function ( e ) {
		e.preventDefault();
		var id = $( this ).data( 'id' );
		var name = $( this ).closest( 'tr' ).find( 'td' ).first().text();
		UI.dialog( { title: 'Duplicate mapping', input: { label: 'New profile name', value: name + ' (copy)', required: true }, confirmLabel: 'Duplicate' } ).done( function ( newName ) {
			post( 'apm_duplicate_mapping', { id: id, name: newName } ).done( function ( res ) {
				if ( res.success ) { UI.toast( 'Duplicated — reloading…', 'success' ); setTimeout( function () { location.reload(); }, 600 ); }
				else UI.toast( errorMessage( res ), 'error' );
			} ).fail( onFail );
		} );
	} );

	$( document ).on( 'click', '.apm-mapping-export', function ( e ) {
		e.preventDefault();
		post( 'apm_export_mapping', { id: $( this ).data( 'id' ) } ).done( function ( res ) {
			if ( ! res.success ) { UI.toast( errorMessage( res ), 'error' ); return; }
			var blob = new Blob( [ res.data.json ], { type: 'application/json' } );
			var a = document.createElement( 'a' );
			a.href = URL.createObjectURL( blob );
			a.download = 'apm-mapping.json';
			a.click();
			setTimeout( function () { URL.revokeObjectURL( a.href ); }, 1000 );
		} ).fail( onFail );
	} );

	$( '#apm-mapping-import-btn' ).on( 'click', function () {
		var fileInput = document.getElementById( 'apm-mapping-import-file' );
		if ( ! fileInput.files.length ) { UI.notice( $( '#apm-mappings-result' ), 'error', '<p>Choose a mapping .json file first.</p>' ); return; }
		var reader = new FileReader();
		reader.onload = function ( ev ) {
			post( 'apm_import_mapping', { json: ev.target.result } ).done( function ( res ) {
				if ( res.success ) { UI.toast( 'Mapping imported — reloading…', 'success' ); setTimeout( function () { location.reload(); }, 600 ); }
				else UI.notice( $( '#apm-mappings-result' ), 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' );
			} ).fail( onFail );
		};
		reader.readAsText( fileInput.files[0] );
	} );

	/* =====================================================================
	 * Tools page
	 * =================================================================== */

	$( document ).on( 'click', '.apm-tool', function () {
		var $btn = $( this );
		var tool = $btn.data( 'tool' );
		var run = function () {
			var postType = $( '#apm-tools-post-type' ).length ? $( '#apm-tools-post-type' ).val() : 'post';
			var $result = $( '#apm-tools-result' ).length ? $( '#apm-tools-result' ) : $( '#apm-status-result' );
			$btn.prop( 'disabled', true );
			$result.html( '<p class="apm-loading"><span class="spinner is-active"></span> Running ' + esc( $btn.text() ) + '…</p>' );
			post( 'apm_run_tool', { tool: tool, post_type: postType } ).done( function ( res ) {
				if ( ! res.success ) { UI.notice( $result, 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' ); return; }
				var data = res.data.result;
				if ( tool === 'generate_sample_export' && data.file_path ) {
					var fname = data.file_path.split( '/' ).pop();
					UI.notice( $result, 'success', '<p>Sample export generated. <a class="button button-primary" href="' + esc( downloadUrl( 'tool', null, fname ) ) + '">Download</a></p>' );
					return;
				}
				if ( typeof data === 'number' ) {
					UI.notice( $result, 'success', '<p>Done. Result: ' + esc( data ) + '</p>' );
					return;
				}
				$result.html( $( '<pre class="apm-tool-output"></pre>' ).text( JSON.stringify( data, null, 2 ) ) );
			} ).fail( function ( xhr ) { $result.empty(); onFail( xhr ); } ).always( function () { $btn.prop( 'disabled', false ); } );
		};
		if ( $btn.hasClass( 'apm-tool-confirm' ) ) UI.dialog( { title: $btn.text() + '?', message: APM.i18n.confirm_destructive, confirmLabel: 'Continue', danger: true } ).done( run );
		else run();
	} );

	/* =====================================================================
	 * History / rollback
	 * =================================================================== */

	$( document ).on( 'click', '.apm-rollback-link', function ( e ) {
		e.preventDefault();
		var jobId = $( this ).data( 'job-id' );
		UI.dialog( { title: 'Roll back import #' + jobId + '?', message: APM.i18n.confirm_rollback, confirmLabel: 'Roll back', danger: true } ).done( function () {
			post( 'apm_rollback_job', { job_id: jobId } ).done( function ( res ) {
				if ( res.success ) { UI.toast( 'Rolled back: ' + res.data.restored + ' restored, ' + res.data.trashed + ' trashed. Reloading…', 'success' ); setTimeout( function () { location.reload(); }, 1500 ); }
				else UI.toast( errorMessage( res ), 'error' );
			} ).fail( onFail );
		} );
	} );

	/* =====================================================================
	 * Logs page
	 * =================================================================== */

	$( '#apm-clear-logs, #apm-clear-logs-2' ).on( 'click', function ( e ) {
		e.preventDefault();
		UI.dialog( { title: 'Clear all logs?', message: APM.i18n.confirm_destructive, confirmLabel: 'Clear logs', danger: true } ).done( function () {
			post( 'apm_clear_logs' ).done( function () { UI.toast( 'Logs cleared.', 'success' ); setTimeout( function () { location.reload(); }, 600 ); } ).fail( onFail );
		} );
	} );

	/* =====================================================================
	 * Status page
	 * =================================================================== */

	$( '#apm-copy-report' ).on( 'click', function () {
		var text = document.getElementById( 'apm-report-text' );
		var done = function () { UI.toast( 'System report copied to clipboard.', 'success' ); };
		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( text.value ).then( done, function () { UI.toast( 'Could not access the clipboard.', 'error' ); } );
			return;
		}
		text.style.position = 'static';
		text.select();
		document.execCommand( 'copy' );
		text.style.position = 'absolute';
		text.style.left = '-9999px';
		done();
	} );

	$( '#apm-run-diagnostics, #apm-run-diagnostics-2, #apm-check-compat' ).on( 'click', function () {
		var $btn = $( this ).prop( 'disabled', true );
		var $result = $( '#apm-status-result' );
		$result.html( '<p class="apm-loading"><span class="spinner is-active"></span> Running…</p>' );
		post( 'apm_run_diagnostics' ).done( function ( res ) {
			if ( ! res.success ) { UI.notice( $result, 'error', '<p>' + esc( errorMessage( res ) ) + '</p>' ); return; }
			UI.notice( $result, 'success', '<p>Diagnostics complete. ' + esc( res.data.sample_validation_issues ) + ' potential data issues found in a 200-post sample (see Tools → Validate Post Data for the full list).</p>' );
		} ).fail( function ( xhr ) { $result.empty(); onFail( xhr ); } ).always( function () { $btn.prop( 'disabled', false ); } );
	} );

} )( jQuery );
