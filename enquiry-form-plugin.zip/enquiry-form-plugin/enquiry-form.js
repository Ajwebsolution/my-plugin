jQuery(document).ready(function($) {
    // When the form is submitted
    $('#enquiry-form').submit(function(e) {
        e.preventDefault();  // Prevent the form from submitting normally

        var formData = $(this).serialize(); // Get form data

        // Send AJAX request to WordPress admin-ajax.php
        $.post(enquiry_form.ajax_url, formData + '&action=submit_enquiry_form', function(response) {
            if (response.success) {
                // Show the popup after successful submission
                $('#thank-you-popup').fadeIn();
                $('#enquiry-form')[0].reset();  // Reset the form
            } else {
                alert('Something went wrong! Please try again.');
            }
        });
    });

    // Close the popup
    window.closePopup = function() {
        $('#thank-you-popup').fadeOut();  // Hide the popup when closed
    };
});
