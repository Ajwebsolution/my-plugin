<?php
/**
 * Plugin Name: Enquiry Form Plugin
 * Description: A simple enquiry form plugin to send emails and store submissions in the WordPress admin panel.
 * Version: 1.0
 * Author: Amit Chauhan
 * Author URI: mailto:ac926008@gmail.com
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue styles and scripts (Bootstrap and custom styles)
function enquiry_form_styles() {
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style('enquiry-form-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('jquery');
    wp_enqueue_script('enquiry-form-script', plugin_dir_url(__FILE__) . 'enquiry-form.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'enquiry_form_styles');

// Shortcode to display the form
function enquiry_form_shortcode() {
    ob_start();
    ?>
<style>
	.contact-form-wrapper .form-control {
    border-radius: 80px;
    border: 1px solid #DCDCDC;
    background: #FFF;
    box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.07);
    padding: 17px 28px;
    color: #9D9D9D;
  
    font-size: 18px;
    font-style: normal;
    font-weight: 400;
    line-height: 24px; / 133.333% /
}

.contact-form-wrapper textarea.form-control {
    border-radius: 28px;
}

.contact-form-wrapper .form-control::placeholder {
    color: #9d9d9d;
}

.contact-form-wrapper .form-group {
    margin-bottom: 16px;
}


.contact-form-wrapper .form-group .submit-application-btn {
    width: 100%;
    padding: 13px 25px;
    border-radius: 37px;
    background: #F00;
    color: #FFF;
    font-family: KoHo;
    font-size: 24px;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
    text-transform: capitalize;
}
</style>
    <section class="enquiry-form-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form id="enquiry-form">
                        <div class="contact-form-wrapper">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="first_name" class="form-control" placeholder="First Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="last_name" class="form-control" placeholder="Last Name">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="youremailid@gmail.com" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea name="project_details" class="form-control" placeholder="Type your message..." rows="7"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Popup Modal -->
                    <div id="thank-you-popup" class="popup" style="display:none;">
                        <div class="popup-content">
                        <section id="wrapper">
        <div class="error-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="error-content">
                            <h2>Thank You :)</h2>
                            <p>You have successfully submitted your form, <br>Our Expert will contact you soon.</p>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="error-img">
                            <img src="https://dev-dream.website/specsavers/wp-content/uploads/2025/01/thankyou-img.svg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
                            <button onclick="closePopup()">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('enquiry_form', 'enquiry_form_shortcode');

// Enqueue AJAX script
function enquiry_form_scripts() {
    wp_add_inline_script('jquery', "
     jQuery(document).ready(function($) {
        // When the form is submitted
        $('#enquiry-form').submit(function(e) {
            e.preventDefault();  // Prevent form from submitting normally

            var formData = $(this).serialize(); // Get form data

            // Send AJAX request
            $.post('" . admin_url('admin-ajax.php') . "', formData + '&action=submit_enquiry_form', function(response) {
                if (response.success) {
                    // Show the popup after successful submission
                    $('#thank-you-popup').fadeIn();
                    $('#enquiry-form')[0].reset();  // Reset the form
                } else {
                    alert('Something went wrong! Please try again.');
                }
            });
        });

        // Close the popup
        window.closePopup = function() {
            $('#thank-you-popup').fadeOut();  // Hide the popup when closed
        }
    });
    ");
}
add_action('wp_enqueue_scripts', 'enquiry_form_scripts');

// Handle form submission (AJAX)
function handle_enquiry_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'enquiry_form';

        // Sanitize input
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $project_details = sanitize_textarea_field($_POST['project_details']);

        // Insert into database
        $wpdb->insert($table_name, [
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'phone' => $phone,
            'project_details' => $project_details,
            'submitted_at' => current_time('mysql'),
        ]);

        // Send email
        $admin_email = get_option('admin_email');
        $custom_email = 'ac926008@gmail.com';

        $subject = "New Enquiry Form Submission";
        $message = "You have received a new enquiry:\n\n";
        $message .= "First Name: $first_name\n";
        $message .= "Last Name: $last_name\n";
        $message .= "Email: $email\n";
        $message .= "Phone: $phone\n";
        $message .= "Message: $project_details\n";

        $headers = ['Content-Type: text/plain; charset=UTF-8'];

        wp_mail($admin_email, $subject, $message, $headers);
        wp_mail($custom_email, $subject, $message, $headers);

        // Return success response
        wp_send_json_success();
    }
}
add_action('wp_ajax_submit_enquiry_form', 'handle_enquiry_form_submission');
add_action('wp_ajax_nopriv_submit_enquiry_form', 'handle_enquiry_form_submission');

// Create the database table on plugin activation
function create_enquiry_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'enquiry_form';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        first_name varchar(255) NOT NULL,
        last_name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(20) NOT NULL,
        project_details text NOT NULL,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'create_enquiry_table');

// Add a submenu to view form submissions
add_action('admin_menu', function () {
    add_menu_page('Enquiry Form Submissions', 'Enquiry Submissions', 'manage_options', 'enquiry-submissions', 'render_enquiry_submissions_page', 'dashicons-email', 20);
});

function render_enquiry_submissions_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'enquiry_form';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");

    // Enqueue DataTables CSS and JS
    wp_enqueue_style('datatable-style', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
    wp_enqueue_script('datatable-script', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['jquery'], null, true);

    // Add inline CSS for table styling
    $custom_css = "
        /* General Table Styling for Admin Page */
        #enquiry-submissions-table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            font-family: Arial, sans-serif;
        }

        #enquiry-submissions-table thead th {
            background-color: #007cba;
            color: #ffffff;
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
            font-weight: bold;
        }

        #enquiry-submissions-table tbody td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        #enquiry-submissions-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        #enquiry-submissions-table tr:hover {
            background-color: #f1f1f1;
        }
    ";
    wp_add_inline_style('datatable-style', $custom_css);

    // Inline script to initialize DataTables
    wp_add_inline_script('datatable-script', "
        jQuery(document).ready(function($) {
            $('#enquiry-submissions-table').DataTable({
                pageLength: 10,
                responsive: true,
                order: [[5, 'desc']]
            });
        });
    ");

    echo '<div class="wrap">';
    echo '<h1>Enquiry Form Submissions</h1>';
    echo '<table id="enquiry-submissions-table" class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>';
    echo '<th>First Name</th>';
    echo '<th>Last Name</th>';
    echo '<th>Email</th>';
    echo '<th>Phone</th>';
    echo '<th>Message</th>';
    echo '<th>Submitted At</th>';
    echo '</tr></thead><tbody>';

    foreach ($submissions as $submission) {
        echo '<tr>';
        echo '<td>' . esc_html($submission->first_name) . '</td>';
        echo '<td>' . esc_html($submission->last_name) . '</td>';
        echo '<td>' . esc_html($submission->email) . '</td>';
        echo '<td>' . esc_html($submission->phone) . '</td>';
        echo '<td>' . esc_html($submission->project_details) . '</td>';
        echo '<td>' . esc_html($submission->submitted_at) . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
}
