<?php
/**
 * Plugin Name: Subscription Plugin
 * Description: Custom subscription plugin with admin dashboard, welcome email editor, email notifications, email templates, and post/page notifications.
 * Version: 2.5
 * Author: Amit Chauhan
 */

// Enqueue styles and scripts (Bootstrap, custom styles, and DataTables)
function lr_subscription_styles() {
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style('lr-subscription-style', plugin_dir_url(__FILE__) . 'style.css'); // Ensure style.css exists
    wp_enqueue_script('jquery');
    wp_enqueue_script('enquiry-form-script', plugin_dir_url(__FILE__) . 'subscription-form.js', ['jquery'], null, true);
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['jquery'], null, true);
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
}
add_action('admin_enqueue_scripts', 'lr_subscription_styles');

// Subscription Form Shortcode
function lr_subscription_form_shortcode() {
    ob_start(); ?>
    <style>
        table#lr-subscribers-table {
            text-align: left !important;
        }
    </style>
    <form id="lr-subscription-form" class="lr-unique-subscription-form">
        <input type="email" name="lr_email" class="lr-unique-email-input" placeholder="Enter your email" required />
        <?php wp_nonce_field('lr_subscribe_nonce', 'lr_subscribe_nonce_field'); ?>
        <button type="submit" class="lr-unique-subscribe-button">
            <span class="btn-text">Subscribe</span>
            <span class="spinner" style="display:none;">&#x21bb;</span>
        </button>
    </form>
    <div id="lr-subscription-message"></div>
    <script>
        document.getElementById('lr-subscription-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = e.target;
            const button = form.querySelector('.lr-unique-subscribe-button');
            const spinner = button.querySelector('.spinner');
            const btnText = button.querySelector('.btn-text');
            const email = form.lr_email.value;

            spinner.style.display = 'inline-block';
            btnText.style.display = 'none';

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=lr_subscribe&email=' + encodeURIComponent(email) + '&lr_subscribe_nonce_field=' + encodeURIComponent(form.lr_subscribe_nonce_field.value)
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('lr-subscription-message').innerText = data.message;
            })
            .finally(() => {
                spinner.style.display = 'none';
                btnText.style.display = 'inline';
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('lr_subscription_form', 'lr_subscription_form_shortcode');

// Handle Subscription
add_action('wp_ajax_lr_subscribe', 'lr_handle_subscription');
add_action('wp_ajax_nopriv_lr_subscribe', 'lr_handle_subscription');
function lr_handle_subscription() {
    if (!isset($_POST['lr_subscribe_nonce_field']) || !wp_verify_nonce($_POST['lr_subscribe_nonce_field'], 'lr_subscribe_nonce')) {
        wp_send_json(['message' => 'Security check failed.']);
        return;
    }

    global $wpdb;
    $email = sanitize_email($_POST['email']);

    if (!is_email($email)) {
        wp_send_json(['message' => 'Invalid email address.']);
        return;
    }

    $table_name = $wpdb->prefix . 'lr_subscribers';
    $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE email = %s", $email));

    if ($existing) {
        wp_send_json(['message' => 'You are already subscribed.']);
        return;
    }

    $wpdb->insert($table_name, [
        'email' => $email,
        'subscribed_at' => current_time('mysql')
    ]);

    // Send welcome email to subscriber
    $welcome_email_content = get_option('lr_welcome_email_content', 'Welcome to Heritage Gold!');
    $domain_name = parse_url(home_url(), PHP_URL_HOST);

    $formatted_email = '<h1>Welcome to Heritage Gold</h1>';
    $formatted_email .= preg_replace_callback('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/', function($matches) {
        $image_url = esc_url($matches[1]);
        return '<img src="' . $image_url . '" alt="Welcome Image" style="max-width:100%; height:auto;" />';
    }, $welcome_email_content);

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <no-reply@' . $domain_name . '>',
        'Reply-To: no-reply@' . $domain_name
    ];

    wp_mail($email, 'Welcome to ' . $domain_name, $formatted_email, $headers);

    // Send notification email to admin(s)
    $admin_emails = get_option('lr_admin_notification_email', get_option('admin_email'));
    $admin_emails = array_map('trim', explode(',', $admin_emails)); // Split multiple emails

    $notification_subject = 'New Subscriber Notification';
    $notification_message = 'A new subscriber has joined: ' . $email;

    foreach ($admin_emails as $admin_email) {
        if (is_email($admin_email)) {
            wp_mail($admin_email, $notification_subject, $notification_message, $headers);
        }
    }

    wp_send_json(['message' => 'Thank you for subscribing!']);
}

// Create Database Table on Plugin Activation
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'lr_subscribers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        subscribed_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Admin Menu for Subscription List, Welcome Email Editor, Notification Settings, Email Templates, and Shortcode Info
add_action('admin_menu', function() {
    add_menu_page('Subscribers', 'Subscribers', 'manage_options', 'lr-subscribers', 'lr_subscribers_page');
    add_submenu_page('lr-subscribers', 'Welcome Email', 'Welcome Email', 'manage_options', 'lr-welcome-email', 'lr_welcome_email_page');
    add_submenu_page('lr-subscribers', 'Send Email', 'Send Email', 'manage_options', 'lr-send-email', 'lr_send_email_page');
    add_submenu_page('lr-subscribers', 'Notification Settings', 'Notification Settings', 'manage_options', 'lr-notification-settings', 'lr_notification_settings_page');
    add_submenu_page('lr-subscribers', 'Email Templates', 'Email Templates', 'manage_options', 'lr-email-templates', 'lr_email_templates_page');
    add_submenu_page('lr-subscribers', 'Post Type Notifications', 'Post Type Notifications', 'manage_options', 'lr-post-type-notifications', 'lr_post_type_notifications_page');
    add_submenu_page('lr-subscribers', 'Shortcode Info', 'Shortcode Info', 'manage_options', 'lr-shortcode-info', 'lr_shortcode_info_page');
});

// Subscribers List Page with Delete Option
function lr_subscribers_page() {
    global $wpdb;

    // Handle bulk delete
    if (isset($_POST['bulk_delete_subscribers']) && !empty($_POST['subscriber_ids'])) {
        $subscriber_ids = array_map('intval', $_POST['subscriber_ids']);
        $wpdb->query("DELETE FROM {$wpdb->prefix}lr_subscribers WHERE id IN (" . implode(',', $subscriber_ids) . ")");
        echo '<div class="updated"><p>Selected subscribers deleted!</p></div>';
    }

    // Handle single delete
    if (isset($_GET['delete_subscriber']) && isset($_GET['_wpnonce'])) {
        $subscriber_id = intval($_GET['delete_subscriber']);
        if (wp_verify_nonce($_GET['_wpnonce'], 'delete_subscriber_' . $subscriber_id)) {
            $wpdb->delete("{$wpdb->prefix}lr_subscribers", ['id' => $subscriber_id]);
            echo '<div class="updated"><p>Subscriber deleted!</p></div>';
        } else {
            echo '<div class="error"><p>Security check failed.</p></div>';
        }
    }

    $subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}lr_subscribers ORDER BY subscribed_at DESC");
    ?>
    <h1>Subscribers List</h1>
    <form method="post">
        <table id="lr-subscribers-table" class="display">
            <thead>
                <tr>
                    <th><input type="checkbox" id="select-all"></th>
                    <th>Email</th>
                    <th>Subscribed At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subscribers as $subscriber) : ?>
                    <tr>
                        <td><input type="checkbox" name="subscriber_ids[]" value="<?php echo esc_attr($subscriber->id); ?>"></td>
                        <td><?php echo esc_html($subscriber->email); ?></td>
                        <td><?php echo esc_html($subscriber->subscribed_at); ?></td>
                        <td>
                            <a href="<?php echo esc_url(wp_nonce_url(
                                add_query_arg('delete_subscriber', $subscriber->id),
                                'delete_subscriber_' . $subscriber->id
                            )); ?>" 
                            class="button button-danger" 
                            onclick="return confirm('Are you sure you want to delete this subscriber?');">
                                Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit" name="bulk_delete_subscribers" class="button button-danger">Delete All Selected</button>
    </form>
    <script>
        jQuery(document).ready(function($) {
            $('#lr-subscribers-table').DataTable({
                paging: true,
                searching: true,
                ordering: true,
                responsive: true
            });
            
            // Select all checkbox functionality
            $('#select-all').click(function() {
                $('input[name="subscriber_ids[]"]').prop('checked', this.checked);
            });
        });
    </script>
    <?php
}

// Welcome Email Editor Page
function lr_welcome_email_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $template_name = sanitize_text_field($_POST['template_name']);
        update_option('lr_welcome_email_content', get_option('lr_email_templates', [])[$template_name]);
        echo '<div class="updated"><p>Welcome email updated!</p></div>';
    }

    $templates = get_option('lr_email_templates', []);
    $current_template = get_option('lr_welcome_email_content', 'Welcome to Heritage Gold!');
    ?>
    <h1>Welcome Email Editor</h1>
    <form method="post">
        <p>
            <label for="template_name">Select Template:</label>
            <select name="template_name" id="template_name" required>
                <?php foreach ($templates as $name => $content) : ?>
                    <option value="<?php echo esc_attr($name); ?>" <?php selected($content, $current_template); ?>><?php echo esc_html($name); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <button type="submit" class="button button-primary">Save Changes</button>
    </form>
    <?php
}

// Send Email to Subscribers Page
function lr_send_email_page() {
    global $wpdb;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email'])) {
        $subscribers = isset($_POST['subscribers']) ? array_map('intval', $_POST['subscribers']) : [];
        $template_name = sanitize_text_field($_POST['template_name']);
        $templates = get_option('lr_email_templates', []);
        $message = $templates[$template_name];

        if (!empty($subscribers) && !empty($message)) {
            $emails = $wpdb->get_col("SELECT email FROM {$wpdb->prefix}lr_subscribers WHERE id IN (" . implode(',', $subscribers) . ")");

            $headers = [
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . get_bloginfo('name') . ' <no-reply@' . parse_url(home_url(), PHP_URL_HOST) . '>',
                'Reply-To: no-reply@' . parse_url(home_url(), PHP_URL_HOST)
            ];

            foreach ($emails as $email) {
                wp_mail($email, 'Custom Email', $message, $headers);
            }

            echo '<div class="updated"><p>Email sent to selected subscribers!</p></div>';
        } else {
            echo '<div class="error"><p>Please select subscribers and a template.</p></div>';
        }
    }

    $subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}lr_subscribers ORDER BY subscribed_at DESC");
    $templates = get_option('lr_email_templates', []);
    ?>
    <h1>Send Email to Subscribers</h1>
    <form method="post">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Email</th>
                    <th>Subscribed At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subscribers as $subscriber) : ?>
                    <tr>
                        <td><input type="checkbox" name="subscribers[]" value="<?php echo esc_attr($subscriber->id); ?>"></td>
                        <td><?php echo esc_html($subscriber->email); ?></td>
                        <td><?php echo esc_html($subscriber->subscribed_at); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <h2>Email Content</h2>
        <p>
            <label for="template_name">Select Template:</label>
            <select name="template_name" id="template_name" required>
                <?php foreach ($templates as $name => $content) : ?>
                    <option value="<?php echo esc_attr($name); ?>"><?php echo esc_html($name); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <button type="submit" name="send_email" class="button button-primary">Send Email</button>
    </form>
    <?php
}

// Notification Settings Page
function lr_notification_settings_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        update_option('lr_admin_notification_email', sanitize_text_field($_POST['lr_admin_notification_email']));
        echo '<div class="updated"><p>Notification settings updated!</p></div>';
    }
    $admin_email = get_option('lr_admin_notification_email', get_option('admin_email'));
    ?>
    <h1>Notification Settings</h1>
    <form method="post">
        <p>
            <label for="lr_admin_notification_email">Admin Notification Email(s):</label>
            <input type="text" name="lr_admin_notification_email" id="lr_admin_notification_email" value="<?php echo esc_attr($admin_email); ?>" required>
            <small>Enter multiple emails separated by commas (e.g., admin1@example.com, admin2@example.com).</small>
        </p>
        <p>
            <strong>Note:</strong> To prevent emails from going to spam, consider using an SMTP plugin like <a href="https://wordpress.org/plugins/wp-mail-smtp/" target="_blank">WP Mail SMTP</a>.
        </p>
        <button type="submit" class="button button-primary">Save Changes</button>
    </form>
    <?php
}

// Email Templates Page
function lr_email_templates_page() {
    $templates = get_option('lr_email_templates', []);

    // Handle template deletion
    if (isset($_GET['delete_template']) && isset($_GET['_wpnonce'])) {
        $template_name = sanitize_text_field($_GET['delete_template']);
        if (wp_verify_nonce($_GET['_wpnonce'], 'delete_template_' . $template_name)) {
            unset($templates[$template_name]);
            update_option('lr_email_templates', $templates);
            echo '<div class="updated"><p>Template deleted successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Security check failed. Please try again.</p></div>';
        }
    }

    // Handle template editing
    if (isset($_POST['edit_template'])) {
        $template_name = sanitize_text_field($_POST['template_name']);
        $new_template_name = sanitize_text_field($_POST['new_template_name']);
        $template_content = wp_kses_post($_POST['template_content']);

        if (isset($templates[$template_name])) {
            unset($templates[$template_name]);
            $templates[$new_template_name] = $template_content;
            update_option('lr_email_templates', $templates);
            echo '<div class="updated"><p>Template updated successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Template not found. Please try again.</p></div>';
        }
    }

    // Handle new template creation
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_template'])) {
        $template_name = sanitize_text_field($_POST['template_name']);
        $template_content = wp_kses_post($_POST['template_content']);
        $templates[$template_name] = $template_content;
        update_option('lr_email_templates', $templates);
        echo '<div class="updated"><p>Template saved!</p></div>';
    }

    ?>
    <h1>Email Templates</h1>
    <form method="post">
        <p>
            <label for="template_name">Template Name:</label>
            <input type="text" name="template_name" id="template_name" required>
        </p>
        <p>
            <label for="template_content">Template Content:</label>
            <?php wp_editor('', 'template_content', ['textarea_name' => 'template_content']); ?>
        </p>
        <button type="submit" name="save_template" class="button button-primary">Save Template</button>
    </form>

    <h2>Saved Templates</h2>
    <ul>
        <?php foreach ($templates as $name => $content) : ?>
            <li>
                <strong><?php echo esc_html($name); ?>:</strong> <?php echo wp_kses_post($content); ?>
                <a href="#" onclick="document.getElementById('edit-form-<?php echo esc_attr($name); ?>').style.display='block';">Edit</a>
                <a href="<?php echo esc_url(wp_nonce_url(add_query_arg('delete_template', $name), 'delete_template_' . $name)); ?>" onclick="return confirm('Are you sure you want to delete this template?');">Delete</a>
                
                <div id="edit-form-<?php echo esc_attr($name); ?>" style="display:none;">
                    <form method="post">
                        <input type="hidden" name="template_name" value="<?php echo esc_attr($name); ?>">
                        <p>
                            <label for="new_template_name">New Template Name:</label>
                            <input type="text" name="new_template_name" id="new_template_name" value="<?php echo esc_attr($name); ?>" required>
                        </p>
                        <p>
                            <label for="template_content">Template Content:</label>
                            <?php wp_editor($content, 'edit_template_content_' . esc_attr($name), ['textarea_name' => 'template_content']); ?>
                        </p>
                        <button type="submit" name="edit_template" class="button button-primary">Update Template</button>
                    </form>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
}

// Post Type Notifications Page
function lr_post_type_notifications_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        update_option('lr_notification_post_types', $_POST['post_types'] ?? []);
        echo '<div class="updated"><p>Settings saved!</p></div>';
    }

    $post_types = get_post_types(['public' => true], 'objects');
    $selected_post_types = get_option('lr_notification_post_types', []);
    ?>
    <h1>Post Type Notifications</h1>
    <form method="post">
        <p>Select the post types for which you want to send notifications:</p>
        <?php foreach ($post_types as $post_type) : ?>
            <label>
                <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($post_type->name); ?>" <?php checked(in_array($post_type->name, $selected_post_types)); ?>>
                <?php echo esc_html($post_type->label); ?>
            </label><br>
        <?php endforeach; ?>
        <button type="submit" class="button button-primary">Save Settings</button>
    </form>
    <?php
}

// Send Notifications When a Post/Page is Published
add_action('publish_post', 'lr_send_post_notification');
add_action('publish_page', 'lr_send_post_notification');

function lr_send_post_notification($post_id) {
    $post = get_post($post_id);
    $selected_post_types = get_option('lr_notification_post_types', []);

    // Check if the post type is selected for notifications
    if (!in_array($post->post_type, $selected_post_types)) {
        return;
    }

    global $wpdb;
    $subscribers = $wpdb->get_col("SELECT email FROM {$wpdb->prefix}lr_subscribers");

    if (empty($subscribers)) {
        return;
    }

    $post_title = get_the_title($post_id);
    $post_url = get_permalink($post_id);
    $post_excerpt = get_the_excerpt($post_id);
    $featured_image = get_the_post_thumbnail_url($post_id, 'medium');

    $subject = 'New ' . ucfirst($post->post_type) . ': ' . $post_title;
    $message = '<h1>' . $post_title . '</h1>';

    if ($featured_image) {
        $message .= '<img src="' . esc_url($featured_image) . '" alt="' . esc_attr($post_title) . '" style="max-width:100%; height:auto;">';
    }

    $message .= '<p>' . $post_excerpt . '</p>';
    $message .= '<p><a href="' . esc_url($post_url) . '">Read more</a></p>';

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <no-reply@' . parse_url(home_url(), PHP_URL_HOST) . '>',
        'Reply-To: no-reply@' . parse_url(home_url(), PHP_URL_HOST)
    ];

    foreach ($subscribers as $email) {
        wp_mail($email, $subject, $message, $headers);
    }
}

// Shortcode Info Page
function lr_shortcode_info_page() {
    echo '<h1>Shortcode Information</h1>';
    echo '<p>Use the following shortcode to display the subscription form on any page or post:</p>';
    echo '<code>[lr_subscription_form]</code>';
}