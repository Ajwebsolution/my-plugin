<?php
/**
 * Admin endpoints for direct site-to-site transfer (wstm/v1/transfers/*).
 *
 * Keys are generated on one site and pasted into the other:
 *  - "pull" key: issued by the SOURCE; the destination pulls the source into itself.
 *  - "push" key: issued by the DESTINATION; the source pushes itself into the destination.
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Handlers\TransferPullHandler;
use WSTM\Jobs\Handlers\TransferPushHandler;
use WSTM\Security\Crypto;
use WSTM\Security\Security;
use WSTM\Transfer\TransferKeys;

defined( 'ABSPATH' ) || exit;

/**
 * Transfer admin controller.
 */
class TransferController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$r    = fn( string $route, string $method, callable $cb, array $args = array() ) => register_rest_route(
			$ns,
			$route,
			array(
				'methods'             => $method,
				'permission_callback' => $perm,
				'args'                => $args,
				'callback'            => fn( \WP_REST_Request $q ) => $this->wrap( fn() => $cb( $q ) ),
			)
		);
		$r( '/transfers', 'GET', fn() => array( 'keys' => ( new TransferKeys( $this->plugin ) )->list(), 'ttl' => (int) $this->plugin->settings()->get( 'transfer_key_ttl' ) ) );
		$r(
			'/transfers/key',
			'POST',
			fn( $q ) => ( new TransferKeys( $this->plugin ) )->issue( (string) $q['mode'], (int) $q['minutes'] ),
			array(
				'mode'    => array( 'type' => 'string', 'enum' => TransferKeys::MODES, 'required' => true ),
				'minutes' => array( 'type' => 'integer', 'enum' => array( 15, 30, 60 ), 'default' => 30 ),
			)
		);
		$r(
			'/transfers/(?P<id>[a-f0-9]{32})/revoke',
			'POST',
			function ( $q ) {
				( new TransferKeys( $this->plugin ) )->revoke( (string) $q['id'] );
				return array( 'revoked' => true );
			}
		);
		$start = array(
			'key'                => array( 'type' => 'string', 'required' => true ),
			'confirm'            => array( 'type' => 'boolean', 'default' => false ),
			'keep_users'         => array( 'type' => 'boolean', 'default' => false ),
			'skip'               => array( 'type' => 'object', 'default' => array() ),
			'allow_unknown_disk' => array( 'type' => 'boolean', 'default' => false ),
		);
		$r( '/transfers/pull', 'POST', fn( $q ) => $this->start( $q, 'pull' ), $start );
		$r( '/transfers/push', 'POST', fn( $q ) => $this->start( $q, 'push' ), $start );
	}

	/**
	 * Start a pull or push job.
	 *
	 * @param \WP_REST_Request $q    Request.
	 * @param string           $mode pull|push.
	 * @throws WstmException On invalid key or missing confirmation.
	 */
	private function start( \WP_REST_Request $q, string $mode ): array {
		$key = TransferKeys::parse( (string) $q['key'] );
		if ( $key['m'] !== $mode ) {
			throw new WstmException(
				'wrong_key',
				'pull' === $mode ? 'This key was created for pushing, not pulling.' : 'This key was created for pulling, not pushing.',
				array( 'action' => 'pull' === $mode ? 'On the SOURCE site generate a key with “Allow this site to be pulled”.' : 'On the DESTINATION site generate a key with “Allow another site to push into this one”.' )
			);
		}
		if ( untrailingslashit( (string) wp_parse_url( (string) $key['u'], PHP_URL_HOST ) . (string) wp_parse_url( (string) $key['u'], PHP_URL_PORT ) ) === untrailingslashit( (string) wp_parse_url( rest_url(), PHP_URL_HOST ) . (string) wp_parse_url( rest_url(), PHP_URL_PORT ) ) && str_starts_with( (string) $key['u'], rest_url() ) ) {
			throw new WstmException( 'same_site', 'This key belongs to this same site.', array( 'action' => 'Paste the key into the OTHER site.' ) );
		}
		if ( true !== $q['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'pull' === $mode ? 'Pulling replaces this site — please confirm.' : 'Pushing replaces the other site — please confirm.' );
		}
		( new PackageController( $this->plugin ) )->assert_idle();
		$token = Security::random_token( 32 );
		$job   = $this->plugin->jobs()->create(
			'pull' === $mode ? TransferPullHandler::TYPE : TransferPushHandler::TYPE,
			array(
				'key_enc'            => Crypto::encrypt( (string) $q['key'] ),
				'remote'             => (string) wp_parse_url( (string) $key['u'], PHP_URL_HOST ),
				'confirmed'          => true,
				'keep_users'         => (bool) $q['keep_users'],
				'skip'               => array_map( 'boolval', (array) $q['skip'] ),
				'allow_unknown_disk' => (bool) $q['allow_unknown_disk'],
				'token_hash'         => hash( 'sha256', $token ),
			)
		);
		return array_merge( $job->to_array(), array( 'token' => $token ) );
	}

	/**
	 * Error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
