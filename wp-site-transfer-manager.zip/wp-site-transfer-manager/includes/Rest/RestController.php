<?php
/**
 * REST API (namespace wstm/v1) for the admin UI.
 *
 * Phase 1 endpoints: diagnostics, jobs (list/get/run/pause/resume/cancel), logs.
 * Transfer endpoints (Phase 8) will use a separate HMAC permission callback.
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * REST controller.
 */
class RestController {

	public const NS = 'wstm/v1';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$perm = array( Security::class, 'rest_permission' );
		$id   = array(
			'id' => array(
				'type'              => 'integer',
				'required'          => true,
				'minimum'           => 1,
				'sanitize_callback' => 'absint',
			),
		);

		register_rest_route(
			self::NS,
			'/diagnostics',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'args'                => array( 'refresh' => array( 'type' => 'boolean', 'default' => false ) ),
				'callback'            => fn( \WP_REST_Request $r ) => rest_ensure_response( $this->plugin->diagnostics()->run( (bool) $r['refresh'] ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/jobs',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'args'                => array(
					'status'   => array( 'type' => 'string' ),
					'page'     => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
					'per_page' => array( 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ),
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap(
					fn() => array_map(
						static fn( $j ) => $j->to_array(),
						$this->plugin->jobs()->list(
							array(
								'status'   => $r['status'] ? explode( ',', sanitize_text_field( $r['status'] ) ) : array(),
								'page'     => $r['page'],
								'per_page' => $r['per_page'],
							)
						)
					)
				),
			)
		);

		register_rest_route(
			self::NS,
			'/jobs/(?P<id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'args'                => $id,
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->plugin->jobs()->get( (int) $r['id'] )->to_array() ),
			)
		);

		foreach ( array( 'run', 'pause', 'resume', 'cancel' ) as $action ) {
			register_rest_route(
				self::NS,
				'/jobs/(?P<id>\d+)/' . $action,
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'permission_callback' => $perm,
					'args'                => $id,
					'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->job_action( $action, (int) $r['id'] ) ),
				)
			);
		}

		register_rest_route(
			self::NS,
			'/logs',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'permission_callback' => $perm,
				'args'                => array(
					'level'    => array( 'type' => 'string', 'enum' => array( '', 'debug', 'info', 'warning', 'error', 'critical' ), 'default' => '' ),
					'job_id'   => array( 'type' => 'integer', 'default' => 0 ),
					'page'     => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
					'per_page' => array( 'type' => 'integer', 'default' => 50, 'minimum' => 1, 'maximum' => 500 ),
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->plugin->logger()->query( $r->get_params() ) ),
			)
		);

		/**
		 * Register additional routes (later phases).
		 *
		 * @param RestController $controller Controller.
		 */
		do_action( 'wstm_register_rest_routes', $this );
	}

	/**
	 * Execute a job action.
	 *
	 * @param string $action Action.
	 * @param int    $id     Job id.
	 */
	private function job_action( string $action, int $id ): array {
		$jobs = $this->plugin->jobs();
		switch ( $action ) {
			case 'run':
				$job = $jobs->run( $id, (int) $this->plugin->settings()->get( 'time_budget' ) );
				break;
			case 'pause':
				$job = $jobs->pause( $id );
				break;
			case 'resume':
				$job = $jobs->resume( $id );
				break;
			case 'cancel':
				$job = $jobs->cancel( $id );
				break;
			default:
				throw new WstmException( 'bad_action', 'Unknown job action.', array( 'why' => (string) $action ) );
		}
		return $job->to_array();
	}

	/**
	 * Convert exceptions to structured REST errors.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			$err = $e->to_wp_error();
			$err->add_data( array_merge( $e->to_array(), array( 'status' => 'job_not_found' === $e->get_error_code() ? 404 : 400 ) ) );
			return $err;
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
