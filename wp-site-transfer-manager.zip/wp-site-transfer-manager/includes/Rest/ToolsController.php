<?php
/**
 * Post-migration tools (wstm/v1/tools/*): health check, caches, Elementor CSS, permalinks, link audit, history.
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Compatibility\PostMigration;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Diagnostics\HealthCheck;
use WSTM\Jobs\Handlers\LinkAuditHandler;
use WSTM\Jobs\JobStatus;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Tools controller.
 */
class ToolsController {

	/** Job types shown in migration history. */
	public const HISTORY_TYPES = array( 'package_export', 'site_restore', 'rollback', 'transfer_pull', 'transfer_push', 'backup_create', 'url_replace', 'db_import', 'db_export' );

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$r    = fn( string $route, string $method, callable $cb, array $args = array() ) => register_rest_route(
			$ns,
			$route,
			array(
				'methods'             => $method,
				'permission_callback' => $perm,
				'args'                => $args,
				'callback'            => function ( \WP_REST_Request $q ) use ( $cb ) {
					try {
						return rest_ensure_response( $cb( $q ) );
					} catch ( WstmException $e ) {
						return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
					}
				},
			)
		);
		$r( '/tools/health', 'GET', fn() => HealthCheck::run( $this->plugin->db() ) );
		$r( '/tools/clear-cache', 'POST', fn() => array( 'message' => PostMigration::clear_caches() ) );
		$r( '/tools/elementor', 'POST', fn() => array( 'message' => PostMigration::elementor() ) );
		$r( '/tools/permalinks', 'POST', fn() => array( 'message' => PostMigration::flush_permalinks() ) );
		$r(
			'/tools/link-audit',
			'POST',
			fn( $q ) => $this->plugin->jobs()->create( LinkAuditHandler::TYPE, array( 'old_hosts' => $this->old_hosts( (array) $q['old_hosts'] ) ) )->to_array(),
			array( 'old_hosts' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array() ) )
		);
		$r( '/tools/history', 'GET', fn() => $this->history() );
	}

	/**
	 * Old hosts: given ones plus sources of previous imports.
	 *
	 * @param array $given Hosts or URLs.
	 */
	private function old_hosts( array $given ): array {
		$out = array();
		foreach ( $given as $g ) {
			$g = trim( (string) $g );
			if ( '' !== $g ) {
				$out[] = strtolower( (string) ( wp_parse_url( str_contains( $g, '//' ) ? $g : 'http://' . $g, PHP_URL_HOST ) ?: $g ) );
			}
		}
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::COMPLETED ), 'type' => 'site_restore', 'per_page' => 20 ) ) as $j ) {
			$h = (string) wp_parse_url( (string) ( $j->metadata['source_url'] ?? '' ), PHP_URL_HOST );
			if ( $h && $h !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				$out[] = strtolower( $h );
			}
		}
		return array_values( array_unique( $out ) );
	}

	/** Migration / backup history from the job log. */
	private function history(): array {
		$out = array();
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::COMPLETED, JobStatus::FAILED, JobStatus::CANCELLED ), 'per_page' => 100 ) ) as $j ) {
			if ( ! in_array( $j->type, self::HISTORY_TYPES, true ) ) {
				continue;
			}
			$m     = $j->metadata;
			$start = $j->started_at ? strtotime( $j->started_at . ' UTC' ) : null;
			$end   = $j->finished_at ? strtotime( $j->finished_at . ' UTC' ) : null;
			$out[] = array(
				'id'       => $j->id,
				'type'     => $j->type,
				'status'   => $j->status,
				'source'   => $m['source_url'] ?? ( in_array( $j->type, array( 'package_export', 'backup_create', 'transfer_push' ), true ) ? home_url() : ( isset( $m['remote'] ) ? $m['remote'] : '' ) ),
				'target'   => $m['site_url'] ?? ( $m['remote_url'] ?? ( 'package_export' === $j->type ? ( $m['file'] ?? '' ) : home_url() ) ),
				'size'     => (int) ( $m['size'] ?? ( $m['bytes_total'] ?? 0 ) ),
				'date'     => $j->finished_at ?: $j->updated_at,
				'duration' => $start && $end ? $end - $start : null,
				'warnings' => count( (array) ( $m['warnings'] ?? array() ) ),
				'error'    => $j->error['what'] ?? null,
			);
		}
		return $out;
	}
}
