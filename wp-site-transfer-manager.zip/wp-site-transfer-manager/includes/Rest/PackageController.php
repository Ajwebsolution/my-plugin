<?php
/**
 * REST endpoints for packages and uploads (wstm/v1/packages/*, wstm/v1/uploads/*).
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Files\SiteRoots;
use WSTM\Files\UploadManager;
use WSTM\Jobs\Handlers\DbExportHandler;
use WSTM\Jobs\Handlers\DbImportHandler;
use WSTM\Jobs\Handlers\PackageExportHandler;
use WSTM\Jobs\Handlers\PackageImportHandler;
use WSTM\Jobs\JobStatus;
use WSTM\Package\PackageBuilder;
use WSTM\Package\PackageInfo;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Package REST controller.
 */
class PackageController {

	/** Job types that must not run concurrently. */
	public const EXCLUSIVE = array( DbExportHandler::TYPE, DbImportHandler::TYPE, PackageExportHandler::TYPE, PackageImportHandler::TYPE_IMPORT, 'url_replace', 'site_restore', 'backup_create', 'rollback', 'transfer_pull', 'transfer_push' );

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$b    = array( 'type' => 'boolean', 'default' => false );
		$file = array( 'type' => 'string', 'required' => true, 'pattern' => '^[A-Za-z0-9._-]+\.wpmig$' );
		$id   = array( 'type' => 'string', 'required' => true, 'pattern' => '^[a-f0-9]{32}$' );
		$r    = fn( string $route, string $method, callable $cb, array $args = array() ) => register_rest_route(
			$ns,
			$route,
			array(
				'methods'             => $method,
				'permission_callback' => $perm,
				'args'                => $args,
				'callback'            => fn( \WP_REST_Request $req ) => $this->wrap( fn() => $cb( $req ) ),
			)
		);

		$r( '/packages', 'GET', fn() => $this->list_packages() );
		$r(
			'/packages/export',
			'POST',
			fn( $q ) => $this->start_export( $q ),
			array(
				'components'         => array( 'type' => 'object', 'default' => array() ),
				'exclusions'         => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array() ),
				'gzip'               => array( 'type' => 'boolean', 'default' => true ),
				'allow_unknown_disk' => $b,
			)
		);
		$r( '/packages/validate', 'POST', fn( $q ) => $this->start_validate( $q ), array( 'file' => $file ) );
		$r(
			'/packages/import',
			'POST',
			fn( $q ) => $this->start_import( $q ),
			array(
				'file'               => $file,
				'confirm'            => $b,
				'import_database'    => array( 'type' => 'boolean', 'default' => true ),
				'safety_backup'      => array( 'type' => 'boolean', 'default' => true ),
				'allow_uploads_exec' => $b,
				'allow_unknown_disk' => $b,
			)
		);
		$r( '/packages/delete', 'POST', fn( $q ) => $this->delete_package( $q ), array( 'file' => $file, 'confirm' => $b ) );

		$r(
			'/uploads/start',
			'POST',
			fn( $q ) => self::upload_view( $this->uploads()->start( (string) $q['name'], (int) $q['size'], (string) $q['fingerprint'], (bool) $q['allow_unknown_disk'] ) ),
			array(
				'name'               => array( 'type' => 'string', 'required' => true ),
				'size'               => array( 'type' => 'integer', 'required' => true, 'minimum' => 1 ),
				'fingerprint'        => array( 'type' => 'string', 'default' => '' ),
				'allow_unknown_disk' => $b,
			)
		);
		$r(
			'/uploads/(?P<id>[a-f0-9]{32})/chunk',
			'POST',
			fn( $q ) => self::upload_view( $this->uploads()->chunk( (string) $q['id'], (int) $q['offset'], (string) $q->get_body(), $q->get_header( 'x-wstm-sha256' ) ?: null ) ),
			array(
				'id'     => $id,
				'offset' => array( 'type' => 'integer', 'required' => true, 'minimum' => 0 ),
			)
		);
		$r( '/uploads/(?P<id>[a-f0-9]{32})', 'GET', fn( $q ) => self::upload_view( $this->uploads()->get( (string) $q['id'] ) ), array( 'id' => $id ) );
		$r( '/uploads/(?P<id>[a-f0-9]{32})/finish', 'POST', fn( $q ) => $this->uploads()->finish( (string) $q['id'] ), array( 'id' => $id ) );
		$r(
			'/uploads/(?P<id>[a-f0-9]{32})/abort',
			'POST',
			function ( $q ) {
				$this->uploads()->abort( (string) $q['id'] );
				return array( 'aborted' => true );
			},
			array( 'id' => $id )
		);
	}

	/** Upload manager. */
	private function uploads(): UploadManager {
		return new UploadManager( $this->plugin->storage() );
	}

	/**
	 * Refuse while another exclusive job is active.
	 *
	 * @throws WstmException If busy.
	 */
	public function assert_idle(): void {
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::PENDING, JobStatus::RUNNING, JobStatus::PAUSED ), 'per_page' => 50 ) ) as $job ) {
			if ( in_array( $job->type, self::EXCLUSIVE, true ) ) {
				throw new WstmException( 'busy', 'Another migration job is in progress.', array( 'why' => 'Job #' . $job->id . ' (' . $job->type . ') is ' . $job->status, 'action' => 'Wait for it to finish, or cancel it.' ) );
			}
		}
	}

	/** Packages in storage. */
	private function list_packages(): array {
		$dir = $this->plugin->storage()->area( 'packages' );
		$out = array();
		foreach ( glob( $dir . '/*.' . PackageBuilder::EXT ) ?: array() as $f ) {
			if ( is_link( $f ) ) {
				continue;
			}
			$info  = PackageInfo::read( $f );
			$out[] = array(
				'file'      => basename( $f ),
				'size'      => (int) filesize( $f ),
				'modified'  => gmdate( 'c', (int) filemtime( $f ) ),
				'info'      => $info,
				'validated' => (bool) ( $info['validated'] ?? false ),
				'download'  => add_query_arg( array( 'action' => 'wstm_download', 'area' => 'packages', 'file' => rawurlencode( basename( $f ) ), '_wstm_nonce' => Security::create_nonce( 'download' ) ), admin_url( 'admin-post.php' ) ),
			);
		}
		usort( $out, static fn( $a, $b ) => strcmp( $b['modified'], $a['modified'] ) );
		return array(
			'packages'   => $out,
			'components' => SiteRoots::COMPONENTS,
			'exclusions' => (array) $this->plugin->settings()->get( 'default_exclusions' ),
			'prefix'     => $this->plugin->db()->base_prefix(),
		);
	}

	/**
	 * Upload state for the browser: no server paths or internal fingerprints.
	 *
	 * @param array $s Upload state.
	 */
	private static function upload_view( array $s ): array {
		unset( $s['part'], $s['fp'] );
		return $s;
	}

	/**
	 * Start a package export.
	 *
	 * @param \WP_REST_Request $q Request.
	 */
	private function start_export( \WP_REST_Request $q ): array {
		$this->assert_idle();
		$components = array();
		foreach ( SiteRoots::COMPONENTS as $c ) {
			$components[ $c ] = ! empty( $q['components'][ $c ] );
		}
		if ( ! array_filter( $components ) ) {
			throw new WstmException( 'nothing_selected', 'Select at least one component.' );
		}
		$exclusions = array();
		foreach ( (array) $q['exclusions'] as $e ) {
			$e = trim( sanitize_text_field( (string) $e ) );
			if ( '' === $e ) {
				continue;
			}
			if ( str_contains( $e, '..' ) ) {
				throw new WstmException( 'bad_exclusion', 'Exclusions may not contain "..".', array( 'why' => $e ) );
			}
			$exclusions[] = $e;
		}
		return $this->plugin->jobs()->create(
			PackageExportHandler::TYPE,
			array(
				'components'         => $components,
				'exclusions'         => $exclusions,
				'gzip'               => (bool) $q['gzip'],
				'allow_unknown_disk' => (bool) $q['allow_unknown_disk'],
			)
		)->to_array();
	}

	/**
	 * Start validation.
	 *
	 * @param \WP_REST_Request $q Request.
	 */
	private function start_validate( \WP_REST_Request $q ): array {
		PackageImportHandler::resolve( $this->plugin, (string) $q['file'] );
		return $this->plugin->jobs()->create( PackageImportHandler::TYPE_VALIDATE, array( 'file' => (string) $q['file'] ) )->to_array();
	}

	/**
	 * Start import.
	 *
	 * @param \WP_REST_Request $q Request.
	 * @throws WstmException If not confirmed.
	 */
	private function start_import( \WP_REST_Request $q ): array {
		if ( true !== $q['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Import must be confirmed.', array( 'action' => 'Tick "I understand that existing destination data may be overwritten."' ) );
		}
		$this->assert_idle();
		PackageImportHandler::resolve( $this->plugin, (string) $q['file'] );
		return $this->plugin->jobs()->create(
			PackageImportHandler::TYPE_IMPORT,
			array(
				'file'               => (string) $q['file'],
				'confirmed'          => true,
				'import_database'    => (bool) $q['import_database'],
				'safety_backup'      => (bool) $q['safety_backup'],
				'allow_uploads_exec' => (bool) $q['allow_uploads_exec'],
				'allow_unknown_disk' => (bool) $q['allow_unknown_disk'],
			)
		)->to_array();
	}

	/**
	 * Delete a package.
	 *
	 * @param \WP_REST_Request $q Request.
	 * @throws WstmException If not confirmed / in use.
	 */
	private function delete_package( \WP_REST_Request $q ): array {
		if ( ! $q['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Deletion must be confirmed.' );
		}
		$path = PackageImportHandler::resolve( $this->plugin, (string) $q['file'] );
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::PENDING, JobStatus::RUNNING, JobStatus::PAUSED, JobStatus::FAILED ), 'per_page' => 100 ) ) as $job ) {
			if ( basename( (string) ( $job->checkpoint['package'] ?? $job->checkpoint['final'] ?? '' ) ) === basename( $path ) ) {
				throw new WstmException( 'busy', 'This package is used by an unfinished job.', array( 'action' => 'Cancel or finish job #' . $job->id . ' first.' ) );
			}
		}
		wp_delete_file( $path );
		PackageInfo::delete( $path );
		$this->plugin->logger()->info( 'Package deleted: ' . basename( $path ), array(), 'package' );
		return array( 'deleted' => true );
	}

	/**
	 * Structured error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			$status = in_array( $e->get_error_code(), array( 'chunk_gap', 'upload_incomplete' ), true ) ? 409 : 400;
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => $status, 'detail' => $e->get_context()['data'] ?? null ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
