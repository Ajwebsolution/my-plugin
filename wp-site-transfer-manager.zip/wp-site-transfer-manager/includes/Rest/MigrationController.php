<?php
/**
 * One-click Export / Import endpoints (wstm/v1/migration/*).
 *
 * The import job can be driven with a per-job secret token instead of the
 * login cookie, because restoring another site's database replaces the user
 * table (and therefore invalidates the current login) near the end.
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Handlers\PackageExportHandler;
use WSTM\Jobs\Handlers\PackageImportHandler;
use WSTM\Jobs\Handlers\SiteRestoreHandler;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Migration controller.
 */
class MigrationController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		register_rest_route(
			$ns,
			'/migration/export',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array(
					'skip'               => array( 'type' => 'object', 'default' => array() ),
					'exclusions'         => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array() ),
					'allow_unknown_disk' => array( 'type' => 'boolean', 'default' => false ),
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->export( $r ) ),
			)
		);
		register_rest_route(
			$ns,
			'/migration/import',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array(
					'file'               => array( 'type' => 'string', 'required' => true, 'pattern' => '^[A-Za-z0-9._-]+\.wpmig$' ),
					'confirm'            => array( 'type' => 'boolean', 'default' => false ),
					'safety_backup'      => array( 'type' => 'boolean', 'default' => true ),
					'allow_uploads_exec' => array( 'type' => 'boolean', 'default' => false ),
					'allow_unknown_disk' => array( 'type' => 'boolean', 'default' => false ),
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->import( $r ) ),
			)
		);
		register_rest_route(
			$ns,
			'/migration/run/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( $this, 'token_permission' ),
				'args'                => array(
					'id'    => array( 'type' => 'integer', 'required' => true ),
					'token' => array( 'type' => 'string', 'required' => true, 'pattern' => '^[a-f0-9]{64}$' ),
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->plugin->jobs()->run( (int) $r['id'], (int) $this->plugin->settings()->get( 'time_budget' ) )->to_array() ),
			)
		);
	}

	/**
	 * Token permission for driving a restore job without a login cookie.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	public function token_permission( \WP_REST_Request $r ) {
		// Only failed attempts are rate-limited: a long job legitimately polls this endpoint thousands of times.
		$bucket = 'wstm_tokfail_' . md5( Security::client_fingerprint() );
		if ( (int) get_site_transient( $bucket ) >= 20 ) {
			return new \WP_Error( 'wstm_rate_limited', 'Too many invalid tokens. Try again later.', array( 'status' => 429 ) );
		}
		$deny = static function () use ( $bucket ) {
			set_site_transient( $bucket, (int) get_site_transient( $bucket ) + 1, 10 * MINUTE_IN_SECONDS );
			return new \WP_Error( 'wstm_forbidden', 'Invalid token.', array( 'status' => 403 ) );
		};
		try {
			$job = $this->plugin->jobs()->get( (int) $r['id'] );
		} catch ( WstmException $e ) {
			return $deny();
		}
		$hash = (string) ( $job->metadata['token_hash'] ?? '' );
		if ( ! in_array( $job->type, array( SiteRestoreHandler::TYPE, 'rollback', 'transfer_pull', 'transfer_push' ), true ) || '' === $hash || ! hash_equals( $hash, hash( 'sha256', (string) $r['token'] ) ) ) {
			return $deny();
		}
		return true;
	}

	/**
	 * Simple export: everything except what the user chose to skip.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function export( \WP_REST_Request $r ): array {
		( new PackageController( $this->plugin ) )->assert_idle();
		return $this->plugin->jobs()->create( PackageExportHandler::TYPE, self::export_meta( $this->plugin, (array) $r['skip'], (array) $r['exclusions'], (bool) $r['allow_unknown_disk'] ) )->to_array();
	}

	/**
	 * Package-export job metadata from simple "skip" options (shared with direct transfer).
	 *
	 * @param Plugin $plugin        Plugin.
	 * @param array  $skip          Flags.
	 * @param array  $extra_excl    Extra exclusions.
	 * @param bool   $unknown_disk  Allow unknown disk space.
	 */
	public static function export_meta( Plugin $plugin, array $skip, array $extra_excl = array(), bool $unknown_disk = false ): array {
		$skip = array_map( 'boolval', $skip );
		$comp = array(
			'database' => empty( $skip['database'] ),
			'uploads'  => empty( $skip['media'] ),
			'themes'   => empty( $skip['themes'] ),
			'plugins'  => empty( $skip['plugins'] ),
			'content'  => true,
			'core'     => false,
			'root'     => false,
		);
		$excl = (array) $plugin->settings()->get( 'default_exclusions' );
		foreach ( $extra_excl as $e ) {
			$e = trim( sanitize_text_field( (string) $e ) );
			if ( '' !== $e && ! str_contains( $e, '..' ) ) {
				$excl[] = $e;
			}
		}
		if ( ! empty( $skip['cache'] ) ) {
			$excl[] = 'content:cache/';
		}
		if ( ! empty( $skip['inactive_plugins'] ) ) {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$active = array_merge( (array) get_option( 'active_plugins', array() ), array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
			foreach ( array_keys( get_plugins() ) as $file ) {
				if ( ! in_array( $file, $active, true ) && WSTM_BASENAME !== $file ) {
					$excl[] = 'plugins:' . ( str_contains( $file, '/' ) ? dirname( $file ) . '/' : $file );
				}
			}
		}
		if ( ! empty( $skip['inactive_themes'] ) ) {
			foreach ( array_keys( wp_get_themes() ) as $slug ) {
				if ( $slug !== get_stylesheet() && $slug !== get_template() ) {
					$excl[] = 'themes:' . $slug . '/';
				}
			}
		}
		return array(
			'components'         => $comp,
			'exclusions'         => array_values( array_unique( $excl ) ),
			'skip'               => array(
				'revisions'     => ! empty( $skip['revisions'] ),
				'spam_comments' => ! empty( $skip['spam_comments'] ),
				'woo_orders'    => ! empty( $skip['woo_orders'] ),
				'woo_customers' => ! empty( $skip['woo_customers'] ),
			),
			'gzip'               => true,
			'allow_unknown_disk' => $unknown_disk,
		);
	}

	/**
	 * Start a one-click restore. Returns the job plus a one-time driver token.
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException If not confirmed.
	 */
	private function import( \WP_REST_Request $r ): array {
		if ( true !== $r['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Import must be confirmed.', array( 'action' => 'Tick "I understand that existing destination data may be overwritten."' ) );
		}
		( new PackageController( $this->plugin ) )->assert_idle();
		PackageImportHandler::resolve( $this->plugin, (string) $r['file'] );
		$token = Security::random_token( 32 );
		$job   = $this->plugin->jobs()->create(
			SiteRestoreHandler::TYPE,
			array(
				'file'               => (string) $r['file'],
				'confirmed'          => true,
				'safety_backup'      => (bool) $r['safety_backup'],
				'allow_uploads_exec' => (bool) $r['allow_uploads_exec'],
				'allow_unknown_disk' => (bool) $r['allow_unknown_disk'],
				'token_hash'         => hash( 'sha256', $token ),
			)
		);
		return array_merge( $job->to_array(), array( 'token' => $token ) );
	}

	/**
	 * Error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
