<?php
/**
 * REST endpoints for backups, restore and undo (wstm/v1/backups/*, wstm/v1/rollback/*).
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Backup\BackupManager;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Handlers\BackupHandler;
use WSTM\Jobs\Handlers\DbImportHandler;
use WSTM\Jobs\Handlers\PackageImportHandler;
use WSTM\Jobs\Handlers\RollbackHandler;
use WSTM\Jobs\Handlers\SiteRestoreHandler;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Backup controller.
 */
class BackupController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$id   = array( 'id' => array( 'type' => 'integer', 'required' => true ) );
		$r    = fn( string $route, string $method, callable $cb, array $args = array() ) => register_rest_route(
			$ns,
			$route,
			array(
				'methods'             => $method,
				'permission_callback' => $perm,
				'args'                => $args,
				'callback'            => fn( \WP_REST_Request $q ) => $this->wrap( fn() => $cb( $q ) ),
			)
		);

		$r( '/backups', 'GET', fn() => $this->index() );
		$r(
			'/backups/create',
			'POST',
			fn( $q ) => $this->create( $q ),
			array(
				'type'  => array( 'type' => 'string', 'enum' => BackupManager::TYPES, 'default' => 'full' ),
				'mode'  => array( 'type' => 'string', 'enum' => BackupManager::MODES, 'default' => 'full' ),
				'label' => array( 'type' => 'string', 'default' => '' ),
				'cloud' => array( 'type' => 'string', 'default' => '' ),
			)
		);
		$r(
			'/backups/(?P<id>\d+)/restore',
			'POST',
			fn( $q ) => $this->restore( $q ),
			array_merge(
				$id,
				array(
					'confirm'       => array( 'type' => 'boolean', 'default' => false ),
					'keep_users'    => array( 'type' => 'boolean', 'default' => false ),
					'skip_database' => array( 'type' => 'boolean', 'default' => false ),
				)
			)
		);
		$r( '/backups/(?P<id>\d+)/verify', 'POST', fn( $q ) => $this->verify( (int) $q['id'] ), $id );
		$r(
			'/backups/(?P<id>\d+)/delete',
			'POST',
			function ( $q ) {
				if ( true !== $q['confirm'] ) {
					throw new WstmException( 'not_confirmed', 'Deletion must be confirmed.' );
				}
				( new BackupManager( $this->plugin ) )->delete( (int) $q['id'] );
				return array( 'deleted' => true );
			},
			array_merge( $id, array( 'confirm' => array( 'type' => 'boolean', 'default' => false ) ) )
		);
		$r(
			'/rollback/(?P<point>files-replaced-[0-9]{8}-[0-9]{6}-[a-f0-9]{8})',
			'POST',
			fn( $q ) => $this->rollback( $q ),
			array( 'confirm' => array( 'type' => 'boolean', 'default' => false ) )
		);
	}

	/** Listing. */
	private function index(): array {
		$mg   = new BackupManager( $this->plugin );
		$list = array();
		foreach ( $mg->all() as $b ) {
			$b['download'] = $b['exists'] ? add_query_arg( array( 'action' => 'wstm_download', 'area' => 'backups', 'file' => rawurlencode( $b['file'] ), '_wstm_nonce' => Security::create_nonce( 'download' ) ), admin_url( 'admin-post.php' ) ) : null;
			unset( $b['file_path'] );
			$list[] = $b;
		}
		return array(
			'backups'   => $list,
			'rollbacks' => $mg->rollback_points(),
			'schedule'  => array(
				'frequency' => $this->plugin->settings()->get( 'backup_schedule' ),
				'type'      => $this->plugin->settings()->get( 'backup_schedule_type' ),
				'mode'      => $this->plugin->settings()->get( 'backup_schedule_mode' ),
				'next'      => ( $t = wp_next_scheduled( \WSTM\Backup\Scheduler::HOOK ) ) ? gmdate( 'c', $t ) : null,
				'retention' => (int) $this->plugin->settings()->get( 'backup_retention' ),
			),
			'clouds'    => apply_filters( 'wstm_cloud_destinations', array() ),
		);
	}

	/**
	 * Create a backup.
	 *
	 * @param \WP_REST_Request $q Request.
	 */
	private function create( \WP_REST_Request $q ): array {
		( new PackageController( $this->plugin ) )->assert_idle();
		return $this->plugin->jobs()->create(
			BackupHandler::TYPE,
			array(
				'type'  => (string) $q['type'],
				'mode'  => (string) $q['mode'],
				'label' => sanitize_text_field( (string) $q['label'] ),
				'cloud' => sanitize_key( (string) $q['cloud'] ),
			)
		)->to_array();
	}

	/**
	 * Restore a backup (whole chain for differential/incremental backups).
	 *
	 * @param \WP_REST_Request $q Request.
	 * @throws WstmException If not confirmed.
	 */
	private function restore( \WP_REST_Request $q ): array {
		if ( true !== $q['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Restore must be confirmed.', array( 'action' => 'Tick the confirmation box.' ) );
		}
		( new PackageController( $this->plugin ) )->assert_idle();
		$mg = new BackupManager( $this->plugin );
		$b  = $mg->get( (int) $q['id'] );
		if ( ! $b['exists'] ) {
			throw new WstmException( 'backup_missing', 'The backup file is missing.' );
		}
		$token = Security::random_token( 32 );
		if ( 'sql' === $b['kind'] ) {
			// Pre-import safety dump: database-only restore with the safe importer.
			return $this->plugin->jobs()->create(
				DbImportHandler::TYPE,
				array( 'area' => 'backups', 'file' => $b['file'], 'confirmed' => true, 'safety_backup' => true )
			)->to_array();
		}
		$chain = array_map( static fn( $x ) => $x['file'], $mg->chain( $b['id'] ) );
		$job   = $this->plugin->jobs()->create(
			SiteRestoreHandler::TYPE,
			array(
				'chain'         => $chain,
				'confirmed'     => true,
				'safety_backup' => true,
				'keep_users'    => (bool) $q['keep_users'],
				'skip_database' => (bool) $q['skip_database'],
				'label'         => 'Restore of ' . $b['label'],
				'token_hash'    => hash( 'sha256', $token ),
			)
		);
		return array_merge( $job->to_array(), array( 'token' => $token ) );
	}

	/**
	 * Verify a backup.
	 *
	 * @param int $id Id.
	 * @throws WstmException For non-package backups.
	 */
	private function verify( int $id ): array {
		$b = ( new BackupManager( $this->plugin ) )->get( $id );
		if ( 'package' !== $b['kind'] ) {
			throw new WstmException( 'not_package', 'Only package backups can be verified here.', array( 'action' => 'Database safety dumps are verified automatically when restored.' ) );
		}
		return $this->plugin->jobs()->create( PackageImportHandler::TYPE_VALIDATE, array( 'area' => 'backups', 'file' => $b['file'], 'backup_id' => $id ) )->to_array();
	}

	/**
	 * Undo an import.
	 *
	 * @param \WP_REST_Request $q Request.
	 * @throws WstmException If not confirmed.
	 */
	private function rollback( \WP_REST_Request $q ): array {
		if ( true !== $q['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Undo must be confirmed.' );
		}
		( new PackageController( $this->plugin ) )->assert_idle();
		RollbackHandler::resolve( $this->plugin, (string) $q['point'] );
		$token = Security::random_token( 32 );
		$job   = $this->plugin->jobs()->create( RollbackHandler::TYPE, array( 'point' => (string) $q['point'], 'token_hash' => hash( 'sha256', $token ) ) );
		return array_merge( $job->to_array(), array( 'token' => $token ) );
	}

	/**
	 * Error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
