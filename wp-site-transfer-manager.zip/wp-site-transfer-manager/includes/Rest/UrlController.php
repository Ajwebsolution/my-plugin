<?php
/**
 * REST endpoints for the URL engine (wstm/v1/url/*).
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\TableScanner;
use WSTM\Jobs\Handlers\UrlReplaceHandler;
use WSTM\Security\Security;
use WSTM\URL\UrlReplaceEngine;

defined( 'ABSPATH' ) || exit;

/**
 * URL REST controller.
 */
class UrlController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns     = RestController::NS;
		$perm   = array( Security::class, 'rest_permission' );
		$common = array(
			'pairs'       => array( 'type' => 'array', 'required' => true ),
			'tables'      => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array() ),
			'skip_guid'   => array( 'type' => 'boolean', 'default' => true ),
			'url_encoded' => array( 'type' => 'boolean', 'default' => false ),
		);
		register_rest_route(
			$ns,
			'/url/defaults',
			array(
				'methods'             => 'GET',
				'permission_callback' => $perm,
				'callback'            => fn() => $this->wrap( fn() => $this->defaults() ),
			)
		);
		register_rest_route(
			$ns,
			'/url/scan',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array_merge( $common, array( 'mode' => array( 'type' => 'string', 'enum' => array( 'scan', 'dry_run' ), 'default' => 'scan' ) ) ),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->start( $r, UrlReplaceHandler::TYPE_SCAN ) ),
			)
		);
		register_rest_route(
			$ns,
			'/url/replace',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array_merge(
					$common,
					array(
						'confirm'       => array( 'type' => 'boolean', 'default' => false ),
						'safety_backup' => array( 'type' => 'boolean', 'default' => true ),
					)
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->start( $r, UrlReplaceHandler::TYPE_REPLACE ) ),
			)
		);
	}

	/** Defaults for the form. */
	private function defaults(): array {
		$tables = array_values(
			array_map(
				static fn( $t ) => array( 'name' => $t['name'], 'rows' => $t['rows'] ),
				array_filter( ( new TableScanner( $this->plugin->db() ) )->tables(), static fn( $t ) => 'site' === $t['group'] && ! $t['is_view'] )
			)
		);
		return array(
			'home_url' => home_url(),
			'site_url' => site_url(),
			'tables'   => $tables,
		);
	}

	/**
	 * Start a scan/dry-run/replace job.
	 *
	 * @param \WP_REST_Request $r    Request.
	 * @param string           $type Job type.
	 * @throws WstmException On invalid input.
	 */
	private function start( \WP_REST_Request $r, string $type ): array {
		$pairs = UrlReplaceEngine::clean_pairs( (array) $r['pairs'] );
		$meta  = array(
			'pairs'       => $pairs,
			'tables'      => array_values( array_map( 'sanitize_text_field', (array) $r['tables'] ) ),
			'skip_guid'   => (bool) $r['skip_guid'],
			'url_encoded' => (bool) $r['url_encoded'],
		);
		if ( UrlReplaceHandler::TYPE_REPLACE === $type ) {
			if ( true !== $r['confirm'] ) {
				throw new WstmException( 'not_confirmed', 'Replacement must be confirmed.', array( 'action' => 'Tick the confirmation box.' ) );
			}
			( new PackageController( $this->plugin ) )->assert_idle();
			$meta['confirmed']     = true;
			$meta['safety_backup'] = (bool) $r['safety_backup'];
		} else {
			$meta['mode'] = (string) $r['mode'];
		}
		return $this->plugin->jobs()->create( $type, $meta )->to_array();
	}

	/**
	 * Error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
