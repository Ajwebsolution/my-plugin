<?php
/**
 * REST endpoints for the database engine (wstm/v1/database/*).
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DbImporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\SqlEscaper;
use WSTM\Database\TableScanner;
use WSTM\Jobs\Handlers\DbExportHandler;
use WSTM\Jobs\Handlers\DbImportHandler;
use WSTM\Jobs\JobStatus;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Database REST controller.
 */
class DatabaseController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$bool = array( 'type' => 'boolean', 'default' => false );
		$file = array(
			'area' => array( 'type' => 'string', 'enum' => DbImportHandler::AREAS, 'required' => true ),
			'file' => array( 'type' => 'string', 'required' => true, 'pattern' => '^[A-Za-z0-9._-]+\.sql(\.gz)?$' ),
		);

		register_rest_route( $ns, '/database/tables', array( 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => fn() => $this->wrap( fn() => $this->tables() ) ) );

		register_rest_route(
			$ns,
			'/database/export',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array(
					'tables'             => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array() ),
					'gzip'               => array( 'type' => 'boolean', 'default' => true ),
					'drop_table'         => array( 'type' => 'boolean', 'default' => true ),
					'allow_unknown_disk' => $bool,
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->start_export( $r ) ),
			)
		);

		register_rest_route( $ns, '/database/dumps', array( 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => fn() => $this->wrap( fn() => $this->dumps() ) ) );

		register_rest_route(
			$ns,
			'/database/dumps/delete',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array_merge( $file, array( 'confirm' => $bool ) ),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->delete_dump( $r ) ),
			)
		);

		register_rest_route(
			$ns,
			'/database/import',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array_merge(
					$file,
					array(
						'confirm'            => $bool,
						'safety_backup'      => array( 'type' => 'boolean', 'default' => true ),
						'allow_unknown_disk' => $bool,
					)
				),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->start_import( $r ) ),
			)
		);

		register_rest_route( $ns, '/database/previous', array( 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => fn() => $this->wrap( fn() => $this->previous_tables() ) ) );

		register_rest_route(
			$ns,
			'/database/previous/delete',
			array(
				'methods'             => 'POST',
				'permission_callback' => $perm,
				'args'                => array( 'confirm' => $bool ),
				'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->drop_previous( $r ) ),
			)
		);
	}

	/** Table list with size estimate. */
	private function tables(): array {
		$scanner = new TableScanner( $this->plugin->db() );
		return array(
			'prefix' => $this->plugin->db()->base_prefix(),
			'tables' => $scanner->tables(),
			'gzip'   => function_exists( 'gzopen' ),
		);
	}

	/**
	 * Refuse to start a database job while another one is active.
	 *
	 * @throws WstmException If busy.
	 */
	private function assert_idle(): void {
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::PENDING, JobStatus::RUNNING, JobStatus::PAUSED ), 'per_page' => 50 ) ) as $job ) {
			if ( in_array( $job->type, PackageController::EXCLUSIVE, true ) ) {
				throw new WstmException( 'busy', 'Another migration job is in progress.', array( 'why' => 'Job #' . $job->id . ' (' . $job->type . ') is ' . $job->status, 'action' => 'Wait for it to finish, or cancel it.' ) );
			}
		}
	}

	/**
	 * Start an export.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function start_export( \WP_REST_Request $r ): array {
		$this->assert_idle();
		$tables = array_values( array_filter( array_map( 'sanitize_text_field', (array) $r['tables'] ) ) );
		$job    = $this->plugin->jobs()->create(
			DbExportHandler::TYPE,
			array(
				'tables'             => $tables,
				'gzip'               => (bool) $r['gzip'],
				'drop_table'         => (bool) $r['drop_table'],
				'allow_unknown_disk' => (bool) $r['allow_unknown_disk'],
			)
		);
		return $job->to_array();
	}

	/**
	 * Basenames of files belonging to unfinished jobs (never offered for import/delete).
	 */
	private function busy_files(): array {
		$busy = array();
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::PENDING, JobStatus::RUNNING, JobStatus::PAUSED, JobStatus::FAILED ), 'per_page' => 100 ) ) as $job ) {
			foreach ( array( 'file', 'safety_file' ) as $k ) {
				if ( ! empty( $job->checkpoint[ $k ] ) ) {
					$busy[ basename( (string) $job->checkpoint[ $k ] ) ] = $job->id;
				}
			}
		}
		return $busy;
	}

	/** List available dumps. */
	private function dumps(): array {
		$busy = $this->busy_files();
		$out  = array();
		foreach ( DbImportHandler::AREAS as $area ) {
			$dir = $this->plugin->storage()->area( $area );
			foreach ( new \DirectoryIterator( $dir ) as $f ) {
				if ( ! $f->isFile() || $f->isLink() || ! preg_match( '/\.sql(\.gz)?$/i', $f->getFilename() ) || isset( $busy[ $f->getFilename() ] ) ) {
					continue;
				}
				$manifest = null;
				$mpath    = DumpManifest::path_for( $f->getPathname() );
				if ( is_file( $mpath ) ) {
					try {
						$m        = DumpManifest::read( $mpath );
						$manifest = array(
							'created_at'   => $m['created_at'] ?? '',
							'site_url'     => $m['site_url'] ?? '',
							'table_prefix' => $m['table_prefix'] ?? '',
							'tables'       => count( $m['tables'] ),
							'rows'         => (int) ( $m['rows'] ?? 0 ),
							'checksum'     => $m['checksum']['hash'],
							'compatible'   => ( $m['table_prefix'] ?? '' ) === $this->plugin->db()->base_prefix(),
						);
					} catch ( WstmException $e ) {
						$manifest = array( 'error' => $e->getMessage() );
					}
				}
				$out[] = array(
					'area'     => $area,
					'file'     => $f->getFilename(),
					'size'     => $f->getSize(),
					'modified' => gmdate( 'c', $f->getMTime() ),
					'manifest' => $manifest,
					'download' => add_query_arg( array( 'action' => 'wstm_download', 'area' => $area, 'file' => rawurlencode( $f->getFilename() ), '_wstm_nonce' => Security::create_nonce( 'download' ) ), admin_url( 'admin-post.php' ) ),
				);
			}
		}
		usort( $out, static fn( $a, $b ) => strcmp( $b['modified'], $a['modified'] ) );
		return $out;
	}

	/**
	 * Delete a dump (+ manifest).
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException If not confirmed / busy.
	 */
	private function delete_dump( \WP_REST_Request $r ): array {
		if ( ! $r['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Deletion must be confirmed.' );
		}
		if ( isset( $this->busy_files()[ (string) $r['file'] ] ) ) {
			throw new WstmException( 'busy', 'This file belongs to an unfinished job.', array( 'action' => 'Cancel or finish the job first.' ) );
		}
		$src = DbImportHandler::resolve( $this->plugin, (string) $r['area'], (string) $r['file'] );
		wp_delete_file( $src['source'] );
		if ( $src['manifest'] ) {
			wp_delete_file( $src['manifest'] );
		}
		$this->plugin->logger()->info( 'Dump deleted: ' . $r['file'], array(), 'database' );
		return array( 'deleted' => true );
	}

	/**
	 * Start an import (validation only; destructive work happens in the job).
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException If not confirmed or invalid.
	 */
	private function start_import( \WP_REST_Request $r ): array {
		if ( true !== $r['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Import must be confirmed.', array( 'why' => 'This operation replaces database tables on this site.', 'action' => 'Tick "I understand that existing destination data may be overwritten."' ) );
		}
		$this->assert_idle();
		if ( isset( $this->busy_files()[ (string) $r['file'] ] ) ) {
			throw new WstmException( 'busy', 'This file belongs to an unfinished job.' );
		}
		$src = DbImportHandler::resolve( $this->plugin, (string) $r['area'], (string) $r['file'] );
		if ( $src['manifest'] ) {
			$m = DumpManifest::read( $src['manifest'] );
			if ( (string) $m['table_prefix'] !== $this->plugin->db()->base_prefix() ) {
				throw new WstmException( 'prefix_mismatch', 'The dump uses a different table prefix.', array( 'why' => sprintf( '"%s" vs "%s"', $m['table_prefix'], $this->plugin->db()->base_prefix() ), 'action' => 'Prefix conversion arrives with full migration (Phase 6).' ) );
			}
		}
		$job = $this->plugin->jobs()->create(
			DbImportHandler::TYPE,
			array(
				'area'               => (string) $r['area'],
				'file'               => (string) $r['file'],
				'confirmed'          => true,
				'safety_backup'      => (bool) $r['safety_backup'],
				'allow_unknown_disk' => (bool) $r['allow_unknown_disk'],
			)
		);
		return $job->to_array();
	}

	/** Rollback copies left by the last import. */
	private function previous_tables(): array {
		$db  = $this->plugin->db();
		$out = array();
		foreach ( $db->list_tables( DbImporter::OLD_PREFIX ) as $t ) {
			$out[] = array( 'name' => $t, 'original' => substr( $t, strlen( DbImporter::OLD_PREFIX ) ) );
		}
		return $out;
	}

	/**
	 * Drop rollback copies.
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException If not confirmed.
	 */
	private function drop_previous( \WP_REST_Request $r ): array {
		if ( ! $r['confirm'] ) {
			throw new WstmException( 'not_confirmed', 'Deletion must be confirmed.' );
		}
		$this->assert_idle();
		$n = 0;
		foreach ( $this->plugin->db()->list_tables( DbImporter::OLD_PREFIX ) as $t ) {
			$this->plugin->db()->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( $t ) );
			++$n;
		}
		$this->plugin->logger()->warning( sprintf( 'Deleted %d rollback tables', $n ), array(), 'database' );
		return array( 'dropped' => $n );
	}

	/**
	 * Structured error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'REST error: ' . $e->getMessage(), array(), 'rest' );
			return new \WP_Error( 'wstm_internal', __( 'An internal error occurred. See logs for details.', 'wp-site-transfer-manager' ), array( 'status' => 500 ) );
		}
	}
}
