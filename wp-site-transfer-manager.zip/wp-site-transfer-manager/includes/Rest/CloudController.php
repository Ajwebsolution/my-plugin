<?php
/**
 * Cloud destinations REST (wstm/v1/cloud/*). Secrets are write-only: never returned.
 *
 * @package WSTM\Rest
 */

namespace WSTM\Rest;

use WSTM\Cloud\CloudManager;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Handlers\CloudFetchHandler;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Cloud controller.
 */
class CloudController {

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Manager. */
	private function mg(): CloudManager {
		return new CloudManager( $this->plugin );
	}

	/** Register routes. */
	public function register_routes(): void {
		$ns   = RestController::NS;
		$perm = array( Security::class, 'rest_permission' );
		$r    = fn( string $route, string $method, callable $cb, array $args = array() ) => register_rest_route(
			$ns,
			$route,
			array(
				'methods'             => $method,
				'permission_callback' => $perm,
				'args'                => $args,
				'callback'            => function ( \WP_REST_Request $q ) use ( $cb ) {
					try {
						return rest_ensure_response( $cb( $q ) );
					} catch ( WstmException $e ) {
						return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
					} catch ( \Throwable $e ) {
						$this->plugin->logger()->error( 'Cloud REST error: ' . $e->getMessage(), array(), 'cloud' );
						return new \WP_Error( 'wstm_internal', 'An internal error occurred. See logs for details.', array( 'status' => 500 ) );
					}
				},
			)
		);
		$id = '(?P<id>[a-z0-9-]+)';
		$r( '/cloud', 'GET', fn() => array( 'destinations' => $this->mg()->public_list(), 'presets' => CloudManager::PRESETS ) );
		$r( '/cloud', 'POST', fn( $q ) => $this->mg()->save( $q->get_params() ) );
		$r( '/cloud/' . $id . '/delete', 'POST', function ( $q ) {
			$this->mg()->remove( (string) $q['id'] );
			return array( 'deleted' => true );
		} );
		$r( '/cloud/' . $id . '/test', 'POST', function ( $q ) {
			$res = $this->mg()->destination( (string) $q['id'] )->test_connection();
			return is_wp_error( $res ) ? array( 'ok' => false, 'message' => $res->get_error_message() ) : array( 'ok' => true, 'message' => 'Connection works: list, upload and delete permissions confirmed.' );
		} );
		$r( '/cloud/' . $id . '/files', 'GET', function ( $q ) {
			$files = $this->mg()->destination( (string) $q['id'] )->list();
			return array( 'files' => array_values( array_filter( $files, static fn( $f ) => str_ends_with( $f['name'], '.wpmig' ) ) ) );
		} );
		$r(
			'/cloud/' . $id . '/fetch',
			'POST',
			function ( $q ) {
				CloudFetchHandler::local_name( (string) $q['key'] );
				$this->mg()->destination( (string) $q['id'] );
				return $this->plugin->jobs()->create( CloudFetchHandler::TYPE, array( 'destination' => (string) $q['id'], 'key' => (string) $q['key'] ) )->to_array();
			},
			array( 'key' => array( 'type' => 'string', 'required' => true ) )
		);
		$r(
			'/cloud/' . $id . '/files/delete',
			'POST',
			function ( $q ) {
				if ( true !== $q['confirm'] ) {
					throw new WstmException( 'not_confirmed', 'Deleting a cloud backup must be confirmed.', array() );
				}
				$d   = $this->mg()->destination( (string) $q['id'] );
				$key = (string) $q['key'];
				if ( ! str_starts_with( $key, $d->key( '' ) ) ) {
					throw new WstmException( 'cloud_outside', 'That file is outside this destination\'s folder.', array() );
				}
				$d->delete( $key );
				$this->plugin->logger()->info( 'Cloud backup deleted', array( 'key' => $key ), 'cloud' );
				return array( 'deleted' => true );
			},
			array(
				'key'     => array( 'type' => 'string', 'required' => true ),
				'confirm' => array( 'type' => 'boolean', 'default' => false ),
			)
		);
	}
}
