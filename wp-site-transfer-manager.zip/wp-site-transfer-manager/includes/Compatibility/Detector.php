<?php
/**
 * Detects popular plugins/cache systems WITHOUT depending on them.
 * Full integrations arrive in Phase 9; this provides the shared detection API.
 *
 * @package WSTM\Compatibility
 */

namespace WSTM\Compatibility;

defined( 'ABSPATH' ) || exit;

/**
 * Ecosystem detector.
 */
final class Detector {

	/**
	 * Detect ecosystem components.
	 *
	 * @return array<string,array{label:string,active:bool,version:string}>
	 */
	public static function detect(): array {
		$defs = array(
			'elementor'     => array( 'Elementor', static fn() => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null ),
			'elementor_pro' => array( 'Elementor Pro', static fn() => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null ),
			'acf'           => array( 'Advanced Custom Fields', static fn() => defined( 'ACF_VERSION' ) ? ACF_VERSION : ( class_exists( 'ACF' ) ? '?' : null ) ),
			'woocommerce'   => array( 'WooCommerce', static fn() => defined( 'WC_VERSION' ) ? WC_VERSION : null ),
			'object_cache'  => array( __( 'Persistent object cache', 'wp-site-transfer-manager' ), static fn() => wp_using_ext_object_cache() ? 'drop-in' : null ),
			'page_cache'    => array( __( 'Page cache (advanced-cache.php)', 'wp-site-transfer-manager' ), static fn() => ( defined( 'WP_CACHE' ) && WP_CACHE && file_exists( WP_CONTENT_DIR . '/advanced-cache.php' ) ) ? 'drop-in' : null ),
		);

		$out = array();
		foreach ( $defs as $id => $d ) {
			$v          = ( $d[1] )();
			$out[ $id ] = array(
				'label'   => $d[0],
				'active'  => null !== $v,
				'version' => (string) ( $v ?? '' ),
			);
		}

		/**
		 * Filter detected ecosystem components.
		 *
		 * @param array $out Detected components.
		 */
		return apply_filters( 'wstm_detected_ecosystem', $out );
	}

	/**
	 * Whether a component is active.
	 *
	 * @param string $id Component id.
	 */
	public static function is_active( string $id ): bool {
		$all = self::detect();
		return ! empty( $all[ $id ]['active'] );
	}
}
