<?php
/**
 * Post-migration clean-up for common WordPress ecosystems (no hard dependencies).
 *
 * Every integration is guarded by function/class checks; nothing here requires
 * Elementor, WooCommerce, ACF or any cache plugin to be installed.
 *
 * @package WSTM\Compatibility
 */

namespace WSTM\Compatibility;

use WSTM\Core\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Post-migration tasks.
 */
final class PostMigration {

	/**
	 * Run everything that is safe after a restore / URL change.
	 *
	 * @param Logger|null $logger Logger.
	 * @return array<string,string> task => result
	 */
	public static function run_all( ?Logger $logger = null ): array {
		$out = array(
			'permalinks' => self::flush_permalinks(),
			'caches'     => self::clear_caches(),
			'elementor'  => self::elementor(),
			'woocommerce'=> self::woocommerce(),
		);
		if ( $logger ) {
			$logger->info( 'Post-migration clean-up done', $out, 'compat' );
		}
		return $out;
	}

	/**
	 * Regenerate rewrite rules on the next request (safe even mid-restore).
	 */
	public static function flush_permalinks(): string {
		delete_option( 'rewrite_rules' );
		return 'Permalinks will be regenerated on the next page load.';
	}

	/**
	 * Clear WordPress and known page/object caches.
	 */
	public static function clear_caches(): string {
		$done = array( 'WordPress object cache' );
		wp_cache_flush();
		global $wpdb;
		// Transients may hold URLs/HTML of the old site.
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE ( option_name LIKE '\\_transient\\_%' OR option_name LIKE '\\_site\\_transient\\_%' ) AND option_name NOT LIKE '%wstm%'" ); // phpcs:ignore WordPress.DB
		if ( is_multisite() ) {
			$wpdb->query( "DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE '\\_site\\_transient\\_%' AND meta_key NOT LIKE '%wstm%'" ); // phpcs:ignore WordPress.DB
		}
		$done[] = 'transients';
		$calls = array(
			'WP Rocket'        => static fn() => function_exists( 'rocket_clean_domain' ) ? rocket_clean_domain() || true : null,
			'W3 Total Cache'   => static fn() => function_exists( 'w3tc_flush_all' ) ? w3tc_flush_all() || true : null,
			'WP Super Cache'   => static fn() => function_exists( 'wp_cache_clear_cache' ) ? wp_cache_clear_cache() || true : null,
			'LiteSpeed Cache'  => static fn() => defined( 'LSCWP_V' ) ? do_action( 'litespeed_purge_all' ) || true : null,
			'WP Fastest Cache' => static fn() => isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ? $GLOBALS['wp_fastest_cache']->deleteCache( true ) || true : null,
			'Autoptimize'      => static fn() => class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ? \autoptimizeCache::clearall() || true : null,
			'SiteGround'       => static fn() => function_exists( 'sg_cachepress_purge_cache' ) ? sg_cachepress_purge_cache() || true : null,
			'Hummingbird'      => static fn() => has_action( 'wphb_clear_page_cache' ) ? do_action( 'wphb_clear_page_cache' ) || true : null,
			'Breeze'           => static fn() => has_action( 'breeze_clear_all_cache' ) ? do_action( 'breeze_clear_all_cache' ) || true : null,
			'Cache Enabler'    => static fn() => class_exists( 'Cache_Enabler' ) && method_exists( 'Cache_Enabler', 'clear_complete_cache' ) ? \Cache_Enabler::clear_complete_cache() || true : null,
		);
		foreach ( $calls as $name => $fn ) {
			try {
				if ( null !== $fn() ) {
					$done[] = $name;
				}
			} catch ( \Throwable $e ) {
				unset( $e ); // A third-party cache failing must never break the migration.
			}
		}
		/**
		 * Let other plugins clear their caches after a migration.
		 */
		do_action( 'wstm_clear_caches' );
		return 'Cleared: ' . implode( ', ', $done ) . '.';
	}

	/**
	 * Make Elementor rebuild its CSS (works whether or not Elementor is active right now).
	 */
	public static function elementor(): string {
		global $wpdb;
		$has_data = (bool) $wpdb->get_var( "SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = '_elementor_data' LIMIT 1" ); // phpcs:ignore WordPress.DB
		if ( ! $has_data && ! defined( 'ELEMENTOR_VERSION' ) ) {
			return 'Elementor not used.';
		}
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
			return 'Elementor CSS cache cleared (regenerated on next view).';
		}
		// Elementor inactive: remove generated CSS so it is rebuilt when Elementor runs again.
		$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ('_elementor_css','_elementor_element_cache','_elementor_page_assets')" ); // phpcs:ignore WordPress.DB
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name IN ('_elementor_global_css','elementor-custom-breakpoints-files','_elementor_assets_data') OR option_name LIKE '\\_elementor\\_css\\_%'" ); // phpcs:ignore WordPress.DB
		$dir = wp_upload_dir( null, false )['basedir'] . '/elementor/css';
		if ( is_dir( $dir ) ) {
			foreach ( glob( $dir . '/*.css' ) ?: array() as $f ) {
				wp_delete_file( $f );
			}
		}
		return 'Elementor generated CSS removed (rebuilt on next view).';
	}

	/**
	 * WooCommerce caches and lookup data.
	 */
	public static function woocommerce(): string {
		if ( ! function_exists( 'WC' ) ) {
			return 'WooCommerce not active.';
		}
		if ( function_exists( 'wc_delete_product_transients' ) ) {
			wc_delete_product_transients();
		}
		if ( function_exists( 'wc_delete_shop_order_transients' ) ) {
			wc_delete_shop_order_transients();
		}
		if ( class_exists( '\WC_Cache_Helper' ) ) {
			\WC_Cache_Helper::get_transient_version( 'product', true );
			\WC_Cache_Helper::get_transient_version( 'shipping', true );
		}
		delete_transient( 'wc_attribute_taxonomies' );
		return 'WooCommerce caches cleared.';
	}
}
