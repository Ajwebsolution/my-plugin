<?php
/**
 * Deactivation routine. Never deletes data.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Handles plugin deactivation.
 */
final class Deactivator {

	/**
	 * Deactivate: unschedule cron only.
	 */
	public static function deactivate(): void {
		wp_clear_scheduled_hook( Plugin::CRON_CLEANUP );
	}
}
