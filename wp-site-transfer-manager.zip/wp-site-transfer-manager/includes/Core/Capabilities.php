<?php
/**
 * Capability system.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Dedicated migration capability.
 */
final class Capabilities {

	public const MANAGE = 'manage_site_migration';

	/**
	 * Grant capability to administrators (per site on multisite).
	 */
	public static function grant_defaults(): void {
		$grant = static function () {
			$role = get_role( 'administrator' );
			if ( $role && ! $role->has_cap( self::MANAGE ) ) {
				$role->add_cap( self::MANAGE );
			}
		};

		if ( is_multisite() ) {
			// Super admins implicitly have every cap; grant to site admins only on the main site.
			switch_to_blog( get_main_site_id() );
			$grant();
			restore_current_blog();
		} else {
			$grant();
		}
	}

	/**
	 * Remove capability from all roles (used on uninstall).
	 */
	public static function revoke_all(): void {
		$roles = wp_roles();
		foreach ( array_keys( $roles->roles ) as $name ) {
			$role = get_role( $name );
			if ( $role && $role->has_cap( self::MANAGE ) ) {
				$role->remove_cap( self::MANAGE );
			}
		}
	}

	/**
	 * Whether the current user may run migration operations.
	 * On multisite only super admins may migrate (operations affect the network).
	 */
	public static function current_user_can_manage(): bool {
		if ( is_multisite() ) {
			return is_super_admin();
		}
		return current_user_can( self::MANAGE );
	}

	/**
	 * Capability string used for admin menu registration.
	 */
	public static function menu_cap(): string {
		return is_multisite() ? 'manage_network_options' : self::MANAGE;
	}
}
