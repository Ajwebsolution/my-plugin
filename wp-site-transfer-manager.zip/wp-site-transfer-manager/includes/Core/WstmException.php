<?php
/**
 * Structured plugin exception.
 *
 * Carries the "what / why / completed / resumable / action" contract required
 * for every migration failure instead of die()/exit().
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Structured exception.
 */
class WstmException extends \RuntimeException {

	/**
	 * Machine readable error code.
	 *
	 * @var string
	 */
	protected string $error_code;

	/**
	 * Structured context.
	 *
	 * @var array{what?:string,why?:string,completed?:string,resumable?:bool,action?:string,data?:array}
	 */
	protected array $context;

	/**
	 * Constructor.
	 *
	 * @param string          $error_code Error code e.g. "db_import_failed".
	 * @param string          $message    Human message (what failed).
	 * @param array           $context    Structured context.
	 * @param \Throwable|null $previous   Previous exception.
	 */
	public function __construct( string $error_code, string $message, array $context = array(), ?\Throwable $previous = null ) {
		parent::__construct( $message, 0, $previous );
		$this->error_code = $error_code;
		$this->context    = $context;
	}

	/**
	 * Error code.
	 */
	public function get_error_code(): string {
		return $this->error_code;
	}

	/**
	 * Structured context.
	 */
	public function get_context(): array {
		return $this->context;
	}

	/**
	 * Whether the failed operation can be resumed.
	 */
	public function is_resumable(): bool {
		return ! empty( $this->context['resumable'] );
	}

	/**
	 * Export as a structured array (safe for UI / job error storage).
	 */
	public function to_array(): array {
		return array(
			'code'      => $this->error_code,
			'what'      => $this->context['what'] ?? $this->getMessage(),
			'why'       => $this->context['why'] ?? '',
			'completed' => $this->context['completed'] ?? '',
			'resumable' => $this->is_resumable(),
			'action'    => $this->context['action'] ?? '',
		);
	}

	/**
	 * Convert to WP_Error for REST/AJAX responses.
	 */
	public function to_wp_error(): \WP_Error {
		return new \WP_Error( $this->error_code, $this->getMessage(), $this->to_array() );
	}
}
