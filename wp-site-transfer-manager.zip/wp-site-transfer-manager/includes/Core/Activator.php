<?php
/**
 * Activation routine.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

use WSTM\Database\Schema;
use WSTM\Files\TempStorage;

defined( 'ABSPATH' ) || exit;

/**
 * Handles plugin activation.
 */
final class Activator {

	/**
	 * Activate.
	 */
	public static function activate(): void {
		if ( version_compare( get_bloginfo( 'version' ), WSTM_MIN_WP, '<' ) ) {
			deactivate_plugins( WSTM_BASENAME );
			wp_die(
				esc_html__( 'WP Site Transfer Manager requires WordPress 6.0 or newer.', 'wp-site-transfer-manager' ),
				esc_html__( 'Activation failed', 'wp-site-transfer-manager' ),
				array( 'back_link' => true )
			);
		}

		Schema::install();
		Capabilities::grant_defaults();

		$settings = new Settings();
		$settings->ensure_defaults();

		// Create protected storage root early so diagnostics are meaningful.
		( new TempStorage( $settings ) )->ensure_root();

		if ( ! wp_next_scheduled( Plugin::CRON_CLEANUP ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', Plugin::CRON_CLEANUP );
		}
	}
}
