<?php
/**
 * Structured logger with secret redaction.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

use WSTM\Database\Database;
use WSTM\Security\Redactor;

defined( 'ABSPATH' ) || exit;

/**
 * Logs to the {prefix}wstm_logs table. Never throws.
 */
class Logger {

	public const LEVELS = array(
		'debug'    => 100,
		'info'     => 200,
		'warning'  => 300,
		'error'    => 400,
		'critical' => 500,
	);

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var Settings
	 */
	private Settings $settings;

	/**
	 * Constructor.
	 *
	 * @param Database $db       Database.
	 * @param Settings $settings Settings.
	 */
	public function __construct( Database $db, Settings $settings ) {
		$this->db = $db;
		$this->settings = $settings;
	}

	/**
	 * Write a log entry.
	 *
	 * @param string   $level   Level.
	 * @param string   $message Message.
	 * @param array    $context Context data (redacted).
	 * @param string   $channel Channel e.g. "jobs", "database".
	 * @param int|null $job_id  Related job id.
	 */
	public function log( string $level, string $message, array $context = array(), string $channel = 'general', ?int $job_id = null ): bool {
		$level = strtolower( $level );
		if ( ! isset( self::LEVELS[ $level ] ) ) {
			$level = 'info';
		}
		$min = self::LEVELS[ (string) $this->settings->get( 'log_level' ) ] ?? 200;
		if ( self::LEVELS[ $level ] < $min ) {
			return false;
		}

		try {
			$row = array(
				'level'      => $level,
				'channel'    => substr( sanitize_key( $channel ), 0, 32 ),
				'job_id'     => $job_id,
				'message'    => Redactor::redact_string( mb_substr( $message, 0, 2000 ) ),
				'context'    => empty( $context ) ? null : wp_json_encode( Redactor::redact( $context ) ),
				'user_id'    => get_current_user_id() ?: null,
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
			);
			return (bool) $this->db->insert( 'logs', $row );
		} catch ( \Throwable $e ) {
			// Logging must never break a migration.
			return false;
		}
	}

	/** @param array $c Context. */
	public function debug( string $m, array $c = array(), string $ch = 'general', ?int $j = null ): bool {
		return $this->log( 'debug', $m, $c, $ch, $j );
	}
	/** @param array $c Context. */
	public function info( string $m, array $c = array(), string $ch = 'general', ?int $j = null ): bool {
		return $this->log( 'info', $m, $c, $ch, $j );
	}
	/** @param array $c Context. */
	public function warning( string $m, array $c = array(), string $ch = 'general', ?int $j = null ): bool {
		return $this->log( 'warning', $m, $c, $ch, $j );
	}
	/** @param array $c Context. */
	public function error( string $m, array $c = array(), string $ch = 'general', ?int $j = null ): bool {
		return $this->log( 'error', $m, $c, $ch, $j );
	}
	/** @param array $c Context. */
	public function critical( string $m, array $c = array(), string $ch = 'general', ?int $j = null ): bool {
		return $this->log( 'critical', $m, $c, $ch, $j );
	}

	/**
	 * Paginated query.
	 *
	 * @param array $args level, job_id, page, per_page.
	 * @return array{rows:array,total:int}
	 */
	public function query( array $args = array() ): array {
		$table  = $this->db->table( 'logs' );
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['level'] ) && isset( self::LEVELS[ $args['level'] ] ) ) {
			$where[]  = 'level = %s';
			$params[] = $args['level'];
		}
		if ( ! empty( $args['job_id'] ) ) {
			$where[]  = 'job_id = %d';
			$params[] = (int) $args['job_id'];
		}
		$per_page = max( 1, min( 500, (int) ( $args['per_page'] ?? 50 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;
		$sql_w    = implode( ' AND ', $where );

		$total = (int) $this->db->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$sql_w}", $params );
		$rows  = $this->db->get_results(
			"SELECT * FROM {$table} WHERE {$sql_w} ORDER BY id DESC LIMIT %d OFFSET %d",
			array_merge( $params, array( $per_page, $offset ) )
		);
		return array(
			'rows'  => $rows,
			'total' => $total,
		);
	}

	/**
	 * Stream logs as a text download (chunked, low memory).
	 */
	public function stream_download(): void {
		$table   = $this->db->table( 'logs' );
		$last_id = 0;
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wstm-logs-' . gmdate( 'Ymd-His' ) . '.log"' );
		header( 'X-Content-Type-Options: nosniff' );
		do {
			$rows = $this->db->get_results( "SELECT * FROM {$table} WHERE id > %d ORDER BY id ASC LIMIT 1000", array( $last_id ) );
			foreach ( $rows as $r ) {
				$last_id = (int) $r['id'];
				echo sprintf( "%s\t%s\t%s\t%s%s\n", $r['created_at'], strtoupper( $r['level'] ), $r['channel'], $r['message'], $r['context'] ? "\t" . $r['context'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text download, already redacted.
			}
			flush();
		} while ( count( $rows ) === 1000 );
	}

	/** Clear all logs. */
	public function clear(): void {
		$this->db->query( 'TRUNCATE TABLE ' . $this->db->table( 'logs' ) );
	}

	/**
	 * Delete logs older than N days.
	 *
	 * @param int $days Days.
	 */
	public function delete_older_than( int $days ): int {
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - max( 1, $days ) * DAY_IN_SECONDS );
		return (int) $this->db->query( 'DELETE FROM ' . $this->db->table( 'logs' ) . ' WHERE created_at < %s', array( $cutoff ) );
	}
}
