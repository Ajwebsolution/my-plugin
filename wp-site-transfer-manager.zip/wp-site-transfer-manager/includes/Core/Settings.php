<?php
/**
 * Settings framework: schema-driven defaults, typed sanitization.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Settings store (network-wide option on multisite).
 */
class Settings {

	public const OPTION = 'wstm_settings';

	/**
	 * Cached values.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $cache = null;

	/**
	 * Settings schema. Each field: type, default, label, section, [choices|min|max], description.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function schema(): array {
		$schema = array(
			'chunk_size'           => array(
				'type'    => 'enum',
				'default' => 'auto',
				'choices' => array( 'auto', '1', '5', '10', '25' ),
				'label'   => __( 'Transfer chunk size (MB)', 'wp-site-transfer-manager' ),
				'section' => 'performance',
			),
			'db_batch_rows'        => array(
				'type'    => 'int',
				'default' => 1000,
				'min'     => 50,
				'max'     => 50000,
				'label'   => __( 'Database rows per batch', 'wp-site-transfer-manager' ),
				'section' => 'performance',
			),
			'time_budget'          => array(
				'type'        => 'int',
				'default'     => 20,
				'min'         => 5,
				'max'         => 120,
				'label'       => __( 'Seconds of work per request', 'wp-site-transfer-manager' ),
				'description' => __( 'Jobs checkpoint and yield after this many seconds to avoid host timeouts.', 'wp-site-transfer-manager' ),
				'section'     => 'performance',
			),
			'default_exclusions'   => array(
				'type'    => 'textarea_list',
				'default' => array( 'wp-content/cache/', 'wp-content/upgrade/', 'wp-content/backups/', '.git/', 'node_modules/' ),
				'label'   => __( 'Default excluded paths (one per line)', 'wp-site-transfer-manager' ),
				'section' => 'migration',
			),
			'safety_backup'        => array(
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Always create a safety backup before destructive operations', 'wp-site-transfer-manager' ),
				'section' => 'migration',
			),
			'backup_retention'     => array(
				'type'    => 'int',
				'default' => 5,
				'min'     => 1,
				'max'     => 100,
				'label'   => __( 'Backups to keep', 'wp-site-transfer-manager' ),
				'section' => 'backups',
			),
			'backup_schedule'      => array(
				'type'    => 'enum',
				'default' => 'off',
				'choices' => array( 'off', 'daily', 'weekly' ),
				'label'   => __( 'Automatic backups', 'wp-site-transfer-manager' ),
				'section' => 'backups',
			),
			'backup_schedule_type' => array(
				'type'    => 'enum',
				'default' => 'full',
				'choices' => array( 'full', 'database', 'files' ),
				'label'   => __( 'Automatic backup contents', 'wp-site-transfer-manager' ),
				'section' => 'backups',
			),
			'backup_schedule_mode' => array(
				'type'        => 'enum',
				'default'     => 'incremental',
				'choices'     => array( 'full', 'differential', 'incremental' ),
				'label'       => __( 'Automatic backup mode', 'wp-site-transfer-manager' ),
				'description' => __( 'Incremental/differential backups only store files changed since their base backup; the database is always complete.', 'wp-site-transfer-manager' ),
				'section'     => 'backups',
			),
			'storage_path'         => array(
				'type'        => 'path',
				'default'     => '',
				'label'       => __( 'Custom storage directory (optional, absolute path)', 'wp-site-transfer-manager' ),
				'description' => __( 'Prefer a directory outside the web root. Leave empty to use a protected folder inside wp-content.', 'wp-site-transfer-manager' ),
				'section'     => 'backups',
			),
			'transfer_key_ttl'     => array(
				'type'    => 'enum',
				'default' => '30',
				'choices' => array( '15', '30', '60' ),
				'label'   => __( 'Transfer key lifetime (minutes)', 'wp-site-transfer-manager' ),
				'section' => 'transfer',
			),
			'log_level'            => array(
				'type'    => 'enum',
				'default' => 'info',
				'choices' => array( 'debug', 'info', 'warning', 'error', 'critical' ),
				'label'   => __( 'Minimum log level', 'wp-site-transfer-manager' ),
				'section' => 'logging',
			),
			'log_retention_days'   => array(
				'type'    => 'int',
				'default' => 30,
				'min'     => 1,
				'max'     => 365,
				'label'   => __( 'Delete logs older than (days)', 'wp-site-transfer-manager' ),
				'section' => 'logging',
			),
			'temp_retention_hours' => array(
				'type'    => 'int',
				'default' => 48,
				'min'     => 1,
				'max'     => 720,
				'label'   => __( 'Delete abandoned temporary files after (hours)', 'wp-site-transfer-manager' ),
				'section' => 'logging',
			),
			'uninstall_cleanup'    => array(
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Remove plugin database tables on uninstall', 'wp-site-transfer-manager' ),
				'description' => __( 'Backups and website files are never deleted automatically.', 'wp-site-transfer-manager' ),
				'section'     => 'advanced',
			),
		);

		/**
		 * Filter the settings schema so later phases can register fields.
		 *
		 * @param array $schema Schema.
		 */
		return apply_filters( 'wstm_settings_schema', $schema );
	}

	/**
	 * Default values.
	 */
	public static function defaults(): array {
		return array_map( static fn( $f ) => $f['default'], self::schema() );
	}

	/**
	 * Ensure option exists with defaults merged in.
	 */
	public function ensure_defaults(): void {
		$current = get_site_option( self::OPTION, array() );
		update_site_option( self::OPTION, array_merge( self::defaults(), is_array( $current ) ? $current : array() ) );
		$this->cache = null;
	}

	/**
	 * All values.
	 */
	public function all(): array {
		if ( null === $this->cache ) {
			$stored      = get_site_option( self::OPTION, array() );
			$this->cache = array_merge( self::defaults(), is_array( $stored ) ? $stored : array() );
		}
		return $this->cache;
	}

	/**
	 * Get one value.
	 *
	 * @param string $key Key.
	 */
	public function get( string $key ) {
		$all = $this->all();
		return $all[ $key ] ?? null;
	}

	/**
	 * Sanitize and save raw input. Returns field errors (empty on success).
	 *
	 * @param array $input Raw input (already unslashed).
	 * @return array<string,string>
	 */
	public function save( array $input ): array {
		$schema = self::schema();
		$clean  = $this->all();
		$errors = array();

		foreach ( $schema as $key => $field ) {
			if ( ! array_key_exists( $key, $input ) && 'bool' !== $field['type'] ) {
				continue; // Partial save: keep the current value (checkbox fields are absent when unticked).
			}
			$raw = $input[ $key ] ?? null;
			switch ( $field['type'] ) {
				case 'bool':
					$clean[ $key ] = ! empty( $raw );
					break;
				case 'int':
					$val = (int) $raw;
					if ( $val < $field['min'] || $val > $field['max'] ) {
						/* translators: 1: field, 2: min, 3: max */
						$errors[ $key ] = sprintf( __( '%1$s must be between %2$d and %3$d.', 'wp-site-transfer-manager' ), $field['label'], $field['min'], $field['max'] );
						break;
					}
					$clean[ $key ] = $val;
					break;
				case 'enum':
					$val = sanitize_key( (string) $raw );
					if ( ! in_array( $val, $field['choices'], true ) ) {
						/* translators: %s: field label */
						$errors[ $key ] = sprintf( __( 'Invalid value for %s.', 'wp-site-transfer-manager' ), $field['label'] );
						break;
					}
					$clean[ $key ] = $val;
					break;
				case 'textarea_list':
					$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
					$list  = array();
					foreach ( $lines as $line ) {
						$line = trim( sanitize_text_field( $line ) );
						if ( '' === $line ) {
							continue;
						}
						if ( str_contains( $line, '..' ) ) {
							/* translators: %s: path */
							$errors[ $key ] = sprintf( __( 'Exclusion "%s" may not contain "..".', 'wp-site-transfer-manager' ), $line );
							continue;
						}
						$list[] = ltrim( str_replace( '\\', '/', $line ), '/' );
					}
					$clean[ $key ] = array_values( array_unique( $list ) );
					break;
				case 'path':
					$val = trim( sanitize_text_field( (string) $raw ) );
					if ( '' !== $val ) {
						$val = wp_normalize_path( $val );
						if ( str_contains( $val, '..' ) || ! path_is_absolute( $val ) ) {
							$errors[ $key ] = __( 'Storage directory must be an absolute path without "..".', 'wp-site-transfer-manager' );
							break;
						}
						if ( ! is_dir( $val ) || ! wp_is_writable( $val ) ) {
							$errors[ $key ] = __( 'Storage directory must exist and be writable.', 'wp-site-transfer-manager' );
							break;
						}
					}
					$clean[ $key ] = untrailingslashit( $val );
					break;
			}
		}

		if ( empty( $errors ) ) {
			update_site_option( self::OPTION, $clean );
			$this->cache = $clean;
		}
		return $errors;
	}
}
