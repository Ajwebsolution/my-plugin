<?php
/**
 * Main plugin container / service locator.
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

use WSTM\Admin\Admin;
use WSTM\Database\Database;
use WSTM\Database\Schema;
use WSTM\Diagnostics\Diagnostics;
use WSTM\Files\TempStorage;
use WSTM\Jobs\BackgroundRunner;
use WSTM\Jobs\Handlers\DbExportHandler;
use WSTM\Jobs\Handlers\DbImportHandler;
use WSTM\Jobs\Handlers\PackageExportHandler;
use WSTM\Jobs\Handlers\PackageImportHandler;
use WSTM\Jobs\Handlers\UrlReplaceHandler;
use WSTM\Jobs\JobManager;
use WSTM\Rest\DatabaseController;
use WSTM\Rest\PackageController;
use WSTM\Rest\UrlController;
use WSTM\Rest\RestController;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin bootstrap. Services are lazily created and shared.
 */
final class Plugin {

	public const CRON_CLEANUP = 'wstm_cleanup_cron';

	/**
	 * Singleton.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Shared services.
	 *
	 * @var array<string,object>
	 */
	private array $services = array();

	/**
	 * Get instance and boot on first call.
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	/**
	 * Boot hooks.
	 */
	private function boot(): void {
		load_plugin_textdomain( 'wp-site-transfer-manager', false, dirname( WSTM_BASENAME ) . '/languages' );

		// Upgrade schema if needed (cheap option comparison).
		if ( get_site_option( Schema::VERSION_OPTION ) !== WSTM_DB_VERSION ) {
			Schema::install();
			Capabilities::grant_defaults();
		}

		add_action( self::CRON_CLEANUP, array( $this, 'run_cleanup' ) );
		if ( ! wp_next_scheduled( self::CRON_CLEANUP ) ) {
			// Self-heal if the event was lost (e.g. cron option reset by a database import).
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_CLEANUP );
		}
		add_action(
			'wstm_register_job_handlers',
			function ( JobManager $jobs ) {
				$jobs->register_handler( new DbExportHandler( $this ) );
				$jobs->register_handler( new DbImportHandler( $this ) );
				$jobs->register_handler( new PackageExportHandler( $this ) );
				$jobs->register_handler( new PackageImportHandler( $this, PackageImportHandler::TYPE_VALIDATE ) );
				$jobs->register_handler( new PackageImportHandler( $this, PackageImportHandler::TYPE_IMPORT ) );
				$jobs->register_handler( new UrlReplaceHandler( $this, UrlReplaceHandler::TYPE_SCAN ) );
				$jobs->register_handler( new UrlReplaceHandler( $this, UrlReplaceHandler::TYPE_REPLACE ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\SiteRestoreHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\BackupHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\RollbackHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\TransferPullHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\TransferPushHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\LinkAuditHandler( $this ) );
				$jobs->register_handler( new \WSTM\Jobs\Handlers\CloudFetchHandler( $this ) );
			}
		);
		( new BackgroundRunner( $this ) )->hooks();
		add_action( 'wstm_register_rest_routes', array( new DatabaseController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new PackageController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new UrlController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Rest\MigrationController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Rest\BackupController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Rest\TransferController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Rest\ToolsController( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Transfer\TransferServer( $this ), 'register_routes' ) );
		add_action( 'wstm_register_rest_routes', array( new \WSTM\Rest\CloudController( $this ), 'register_routes' ) );
		( new \WSTM\Cloud\CloudManager( $this ) )->hooks();
		( new \WSTM\Backup\Scheduler( $this ) )->hooks();
		add_action( 'rest_api_init', array( $this->rest(), 'register_routes' ) );

		if ( is_admin() ) {
			require_once WSTM_PATH . 'admin/class-admin.php';
			( new Admin( $this ) )->hooks();
		}

		/**
		 * Fires once the plugin is fully booted. Later phases/modules hook here.
		 *
		 * @param Plugin $plugin Plugin container.
		 */
		do_action( 'wstm_loaded', $this );
	}

	/**
	 * Generic lazy service resolver.
	 *
	 * @param string   $id      Service id.
	 * @param callable $factory Factory.
	 */
	private function service( string $id, callable $factory ): object {
		if ( ! isset( $this->services[ $id ] ) ) {
			$this->services[ $id ] = $factory();
		}
		return $this->services[ $id ];
	}

	/** Database abstraction. */
	public function db(): Database {
		return $this->service( 'db', static fn() => new Database() );
	}

	/** Settings. */
	public function settings(): Settings {
		return $this->service( 'settings', static fn() => new Settings() );
	}

	/** Logger. */
	public function logger(): Logger {
		return $this->service( 'logger', fn() => new Logger( $this->db(), $this->settings() ) );
	}

	/** Job manager. */
	public function jobs(): JobManager {
		return $this->service( 'jobs', fn() => new JobManager( $this->db(), $this->logger() ) );
	}

	/** Temp storage. */
	public function storage(): TempStorage {
		return $this->service( 'storage', fn() => new TempStorage( $this->settings() ) );
	}

	/** Diagnostics. */
	public function diagnostics(): Diagnostics {
		return $this->service( 'diagnostics', fn() => new Diagnostics( $this->db(), $this->storage() ) );
	}

	/** REST controller. */
	public function rest(): RestController {
		return $this->service( 'rest', fn() => new RestController( $this ) );
	}

	/**
	 * Scheduled cleanup: old logs, stale temp files, finished job pruning.
	 */
	public function run_cleanup(): void {
		try {
			$days = (int) $this->settings()->get( 'log_retention_days' );
			$this->logger()->delete_older_than( $days );
			$this->storage()->purge_stale( (int) $this->settings()->get( 'temp_retention_hours' ) * HOUR_IN_SECONDS );
			$this->jobs()->mark_stale_running_as_failed( 6 * HOUR_IN_SECONDS );
			( new \WSTM\Files\UploadManager( $this->storage() ) )->purge( 7 * DAY_IN_SECONDS );
		} catch ( \Throwable $e ) {
			$this->logger()->error( 'Scheduled cleanup failed: ' . $e->getMessage(), array(), 'cron' );
		}
	}
}
