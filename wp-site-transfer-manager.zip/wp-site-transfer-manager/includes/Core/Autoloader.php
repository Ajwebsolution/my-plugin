<?php
/**
 * PSR-4 style autoloader (no Composer required).
 *
 * WSTM\Jobs\JobManager -> includes/Jobs/JobManager.php
 *
 * @package WSTM\Core
 */

namespace WSTM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Lightweight namespace autoloader.
 */
final class Autoloader {

	/**
	 * Registered prefix => base directory map.
	 *
	 * @var array<string,string>
	 */
	private static array $prefixes = array();

	/**
	 * Register a namespace prefix.
	 *
	 * @param string $prefix   Namespace prefix with trailing backslash.
	 * @param string $base_dir Absolute base directory with trailing slash.
	 */
	public static function register( string $prefix, string $base_dir ): void {
		if ( empty( self::$prefixes ) ) {
			spl_autoload_register( array( self::class, 'load' ) );
		}
		self::$prefixes[ $prefix ] = rtrim( $base_dir, '/\\' ) . '/';
	}

	/**
	 * Load a class file.
	 *
	 * @param string $class Fully qualified class name.
	 */
	public static function load( string $class ): void {
		foreach ( self::$prefixes as $prefix => $base_dir ) {
			$len = strlen( $prefix );
			if ( 0 !== strncmp( $prefix, $class, $len ) ) {
				continue;
			}
			$relative = substr( $class, $len );
			// Only allow safe class-name characters; prevents path manipulation.
			if ( ! preg_match( '/^[A-Za-z0-9_\\\\]+$/', $relative ) ) {
				return;
			}
			$file = $base_dir . str_replace( '\\', '/', $relative ) . '.php';
			if ( is_readable( $file ) ) {
				require_once $file;
			}
			return;
		}
	}
}
