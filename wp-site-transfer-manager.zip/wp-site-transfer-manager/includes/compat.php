<?php
/**
 * PHP 8.0 string helpers for PHP 7.4. WordPress 5.9+ already defines these; this only fills a gap.
 *
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'str_contains' ) ) {
	/**
	 * Polyfill.
	 *
	 * @param string $haystack Haystack.
	 * @param string $needle   Needle.
	 */
	function str_contains( $haystack, $needle ) {
		return '' === $needle || false !== strpos( (string) $haystack, (string) $needle );
	}
}
if ( ! function_exists( 'str_starts_with' ) ) {
	/**
	 * Polyfill.
	 *
	 * @param string $haystack Haystack.
	 * @param string $needle   Needle.
	 */
	function str_starts_with( $haystack, $needle ) {
		return 0 === strncmp( (string) $haystack, (string) $needle, strlen( (string) $needle ) );
	}
}
if ( ! function_exists( 'str_ends_with' ) ) {
	/**
	 * Polyfill.
	 *
	 * @param string $haystack Haystack.
	 * @param string $needle   Needle.
	 */
	function str_ends_with( $haystack, $needle ) {
		$needle = (string) $needle;
		return '' === $needle || substr( (string) $haystack, -strlen( $needle ) ) === $needle;
	}
}
