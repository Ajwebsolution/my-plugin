<?php
/**
 * Backup catalogue: listing, chains (differential/incremental), retention, deletion.
 *
 * Backups are .wpmig packages (or .sql.gz safety dumps) in the protected
 * "backups" storage area, recorded in the {prefix}wstm_backups table.
 *
 * @package WSTM\Backup
 */

namespace WSTM\Backup;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DumpManifest;
use WSTM\Package\PackageInfo;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Backup manager.
 */
class BackupManager {

	public const TYPES = array( 'full', 'database', 'files' );
	public const MODES = array( 'full', 'differential', 'incremental' );

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Table name. */
	private function table(): string {
		return $this->plugin->db()->table( 'backups' );
	}

	/**
	 * Decode a row.
	 *
	 * @param array $r Row.
	 */
	private function hydrate( array $r ): array {
		$m              = json_decode( (string) $r['manifest'], true ) ?: array();
		$r['id']        = (int) $r['id'];
		$r['parent_backup_id'] = $r['parent_backup_id'] ? (int) $r['parent_backup_id'] : null;
		$r['verified']  = (bool) $r['verified'];
		$r['is_safety'] = (bool) $r['is_safety'];
		$r['size_bytes'] = (int) $r['size_bytes'];
		$r['meta']      = $m;
		$r['file']      = basename( (string) $r['file_path'] );
		$r['exists']    = is_file( (string) $r['file_path'] );
		$r['kind']      = str_ends_with( $r['file'], '.wpmig' ) ? 'package' : 'sql';
		unset( $r['manifest'] );
		return $r;
	}

	/**
	 * All backups, newest first.
	 */
	public function all(): array {
		return array_map( array( $this, 'hydrate' ), $this->plugin->db()->get_results( 'SELECT * FROM ' . $this->table() . ' ORDER BY id DESC LIMIT 500' ) );
	}

	/**
	 * One backup.
	 *
	 * @param int $id Id.
	 * @throws WstmException If missing.
	 */
	public function get( int $id ): array {
		$r = $this->plugin->db()->get_row( 'SELECT * FROM ' . $this->table() . ' WHERE id = %d', array( $id ) );
		if ( ! $r ) {
			throw new WstmException( 'backup_missing', 'Backup not found.', array( 'why' => '#' . $id ) );
		}
		return $this->hydrate( $r );
	}

	/**
	 * Record a backup.
	 *
	 * @param array $data Fields: type, label, file_path, size_bytes, checksum, verified, is_safety, parent_backup_id, job_id, meta.
	 */
	public function record( array $data ): int {
		return $this->plugin->db()->insert(
			'backups',
			array(
				'uuid'             => wp_generate_uuid4(),
				'type'             => $data['type'],
				'label'            => mb_substr( (string) ( $data['label'] ?? '' ), 0, 191 ),
				'file_path'        => $data['file_path'],
				'size_bytes'       => (int) $data['size_bytes'],
				'checksum'         => $data['checksum'] ?? null,
				'verified'         => empty( $data['verified'] ) ? 0 : 1,
				'is_safety'        => empty( $data['is_safety'] ) ? 0 : 1,
				'parent_backup_id' => $data['parent_backup_id'] ?? null,
				'job_id'           => $data['job_id'] ?? null,
				'manifest'         => wp_json_encode( $data['meta'] ?? array() ),
				'created_at'       => gmdate( 'Y-m-d H:i:s' ),
			)
		);
	}

	/**
	 * Mark verification result.
	 *
	 * @param int  $id Id.
	 * @param bool $ok Verified.
	 */
	public function set_verified( int $id, bool $ok ): void {
		$this->plugin->db()->update( 'backups', array( 'verified' => $ok ? 1 : 0 ), array( 'id' => $id ) );
	}

	/**
	 * Base for a new differential (latest full) or incremental (latest package with a snapshot) backup.
	 *
	 * @param string $type Backup type.
	 * @param string $mode Mode.
	 */
	public function base_for( string $type, string $mode ): ?array {
		foreach ( $this->all() as $b ) {
			if ( $b['is_safety'] || 'package' !== $b['kind'] || $b['type'] !== $type || ! $b['exists'] || ! $b['verified'] || ! is_file( $b['file_path'] . '.idx' ) ) {
				continue;
			}
			if ( 'incremental' === $mode || 'full' === ( $b['meta']['mode'] ?? 'full' ) ) {
				return $b;
			}
		}
		return null;
	}

	/**
	 * Chain from the root full backup to $id (oldest first).
	 *
	 * @param int $id Id.
	 * @throws WstmException If a link is missing.
	 */
	public function chain( int $id ): array {
		$chain = array();
		$seen  = array();
		$b     = $this->get( $id );
		while ( true ) {
			if ( isset( $seen[ $b['id'] ] ) ) {
				throw new WstmException( 'chain_loop', 'Backup chain is corrupted.' );
			}
			$seen[ $b['id'] ] = true;
			if ( ! $b['exists'] ) {
				throw new WstmException( 'chain_broken', 'A backup this restore depends on is missing.', array( 'why' => $b['file'], 'action' => 'Restore an older full backup instead.' ) );
			}
			array_unshift( $chain, $b );
			if ( ! $b['parent_backup_id'] ) {
				break;
			}
			$b = $this->get( $b['parent_backup_id'] );
		}
		return $chain;
	}

	/**
	 * Delete a backup and its sidecars.
	 *
	 * @param int  $id    Id.
	 * @param bool $force Delete even if other backups depend on it.
	 * @throws WstmException If dependents exist.
	 */
	public function delete( int $id, bool $force = false ): void {
		$b    = $this->get( $id );
		$deps = (int) $this->plugin->db()->get_var( 'SELECT COUNT(*) FROM ' . $this->table() . ' WHERE parent_backup_id = %d', array( $id ) );
		if ( $deps && ! $force ) {
			throw new WstmException( 'has_dependents', 'Other backups depend on this one.', array( 'why' => $deps . ' differential/incremental backup(s) use it as their base.', 'action' => 'Delete those first.' ) );
		}
		$area = $this->plugin->storage()->area( 'backups' );
		$path = (string) $b['file_path'];
		if ( PathGuard::is_within( $area, wp_normalize_path( dirname( $path ) ) ) ) {
			foreach ( array( $path, $path . '.json', $path . '.idx', DumpManifest::path_for( $path ) ) as $f ) {
				if ( is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
		}
		$this->plugin->db()->delete( 'backups', array( 'id' => $id ) );
		$this->plugin->logger()->info( 'Backup deleted: ' . $b['file'], array(), 'backup' );
	}

	/**
	 * Keep the newest $keep restore points (and safety backups); delete older
	 * ones that no kept backup depends on.
	 *
	 * @param int $keep Number to keep.
	 */
	public function apply_retention( int $keep ): int {
		$keep    = max( 1, $keep );
		$all     = $this->all();
		$needed  = array();
		$deleted = 0;
		foreach ( array( false, true ) as $safety ) {
			$group = array_values( array_filter( $all, static fn( $b ) => $b['is_safety'] === $safety ) );
			foreach ( array_slice( $group, 0, $keep ) as $b ) {
				$cur = $b;
				$guard = 0;
				while ( $cur && $guard++ < 1000 ) {
					$needed[ $cur['id'] ] = true;
					$cur = $cur['parent_backup_id'] ? ( array_values( array_filter( $all, static fn( $x ) => $x['id'] === $cur['parent_backup_id'] ) )[0] ?? null ) : null;
				}
			}
			foreach ( array_slice( $group, $keep ) as $b ) {
				if ( isset( $needed[ $b['id'] ] ) ) {
					continue;
				}
				try {
					$this->delete( $b['id'], true );
					++$deleted;
				} catch ( \Throwable $e ) {
					$this->plugin->logger()->warning( 'Retention could not delete backup #' . $b['id'] . ': ' . $e->getMessage(), array(), 'backup' );
				}
			}
		}
		if ( $deleted ) {
			$this->plugin->logger()->info( sprintf( 'Retention removed %d old backup(s)', $deleted ), array(), 'backup' );
		}
		return $deleted;
	}

	/**
	 * Rollback points created by imports (newest first).
	 */
	public function rollback_points(): array {
		$out = array();
		foreach ( glob( $this->plugin->storage()->area( 'backups' ) . '/files-replaced-*/rollback.json' ) ?: array() as $f ) {
			$d = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( is_array( $d ) ) {
				$d['dir']  = basename( dirname( $f ) );
				$out[]     = $d;
			}
		}
		usort( $out, static fn( $a, $b ) => strcmp( (string) $b['created_at'], (string) $a['created_at'] ) );
		return $out;
	}

	/**
	 * Summary for packages listing of a backup file.
	 *
	 * @param string $path Path.
	 */
	public static function info( string $path ): ?array {
		return PackageInfo::read( $path );
	}
}
