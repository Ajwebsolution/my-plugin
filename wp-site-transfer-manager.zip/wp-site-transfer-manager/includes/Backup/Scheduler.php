<?php
/**
 * Automatic (scheduled) backups via WP-Cron.
 *
 * @package WSTM\Backup
 */

namespace WSTM\Backup;

use WSTM\Core\Plugin;
use WSTM\Jobs\Handlers\BackupHandler;
use WSTM\Jobs\JobStatus;

defined( 'ABSPATH' ) || exit;

/**
 * Scheduler.
 */
class Scheduler {

	public const HOOK = 'wstm_scheduled_backup';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Hooks. */
	public function hooks(): void {
		add_action( self::HOOK, array( $this, 'run' ) );
		add_filter( 'cron_schedules', array( $this, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		add_action( 'init', array( $this, 'sync' ) );
	}

	/**
	 * Weekly recurrence.
	 *
	 * @param array $s Schedules.
	 */
	public function schedules( array $s ): array {
		$s['wstm_weekly'] ??= array( 'interval' => WEEK_IN_SECONDS, 'display' => 'Weekly (WP Site Transfer)' );
		return $s;
	}

	/**
	 * Make the cron event match the setting.
	 */
	public function sync(): void {
		$want = (string) $this->plugin->settings()->get( 'backup_schedule' );
		$rec  = array( 'daily' => 'daily', 'weekly' => 'wstm_weekly' )[ $want ] ?? null;
		$next = wp_next_scheduled( self::HOOK );
		$cur  = $next ? wp_get_schedule( self::HOOK ) : null;
		if ( $cur === $rec ) {
			return;
		}
		wp_clear_scheduled_hook( self::HOOK );
		if ( $rec ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $rec, self::HOOK );
		}
	}

	/**
	 * Create a scheduled backup job (skipped if a migration job is active).
	 */
	public function run(): void {
		foreach ( $this->plugin->jobs()->list( array( 'status' => array( JobStatus::PENDING, JobStatus::RUNNING, JobStatus::PAUSED ), 'per_page' => 50 ) ) as $job ) {
			if ( in_array( $job->type, \WSTM\Rest\PackageController::EXCLUSIVE, true ) || BackupHandler::TYPE === $job->type ) {
				$this->plugin->logger()->warning( 'Scheduled backup skipped: another job is running (#' . $job->id . ')', array(), 'backup' );
				return;
			}
		}
		$this->plugin->jobs()->create(
			BackupHandler::TYPE,
			array(
				'type'      => (string) $this->plugin->settings()->get( 'backup_schedule_type' ),
				'mode'      => (string) $this->plugin->settings()->get( 'backup_schedule_mode' ),
				'label'     => 'Scheduled backup',
				'scheduled' => true,
				'cloud'     => (string) $this->plugin->settings()->get( 'backup_cloud' ),
			)
		);
	}
}
