<?php
/**
 * Diagnostics engine: environment pre-flight checks + compatibility score.
 *
 * Results are cached (site transient) so admin pages never re-run expensive
 * checks on every load. Pre-flight before destructive operations calls
 * run( true ) to force a fresh result.
 *
 * @package WSTM\Diagnostics
 */

namespace WSTM\Diagnostics;

use WSTM\Compatibility\Detector;
use WSTM\Database\Database;
use WSTM\Files\TempStorage;

defined( 'ABSPATH' ) || exit;

/**
 * Diagnostics.
 */
class Diagnostics {

	public const CACHE_KEY = 'wstm_diagnostics';
	public const CACHE_TTL = 10 * MINUTE_IN_SECONDS;

	public const PASS = 'pass';
	public const WARN = 'warning';
	public const FAIL = 'error';
	public const INFO = 'info';

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var TempStorage
	 */
	private TempStorage $storage;

	/**
	 * Constructor.
	 *
	 * @param Database    $db      Database.
	 * @param TempStorage $storage Storage.
	 */
	public function __construct( Database $db, TempStorage $storage ) {
		$this->db = $db;
		$this->storage = $storage;
	}

	/**
	 * Get report (cached unless forced).
	 *
	 * @param bool $force Force refresh.
	 * @return array{score:int,generated_at:string,checks:array,blocking:bool}
	 */
	public function run( bool $force = false ): array {
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$checks = array();
		foreach ( array( 'php', 'wordpress', 'database', 'filesystem', 'archive', 'network', 'ecosystem' ) as $group ) {
			try {
				$checks = array_merge( $checks, $this->{'check_' . $group}() );
			} catch ( \Throwable $e ) {
				$checks[] = $this->item( $group, $group . '_error', ucfirst( $group ), self::FAIL, $e->getMessage(), __( 'Review the logs for details.', 'wp-site-transfer-manager' ) );
			}
		}

		/**
		 * Filter diagnostic checks so later modules can add their own.
		 *
		 * @param array $checks Checks.
		 */
		$checks = apply_filters( 'wstm_diagnostic_checks', $checks );

		$report = array(
			'score'        => self::score( $checks ),
			'generated_at' => gmdate( 'c' ),
			'checks'       => $checks,
			'blocking'     => (bool) array_filter( $checks, static fn( $c ) => self::FAIL === $c['status'] && ! empty( $c['blocking'] ) ),
		);
		set_site_transient( self::CACHE_KEY, $report, self::CACHE_TTL );
		return $report;
	}

	/**
	 * Compatibility score: weighted pass ratio (info items excluded).
	 *
	 * @param array $checks Checks.
	 */
	public static function score( array $checks ): int {
		$total = 0.0;
		$got   = 0.0;
		foreach ( $checks as $c ) {
			if ( self::INFO === $c['status'] ) {
				continue;
			}
			$w      = (float) ( $c['weight'] ?? 1 );
			$total += $w;
			if ( self::PASS === $c['status'] ) {
				$got += $w;
			} elseif ( self::WARN === $c['status'] ) {
				$got += $w * 0.5;
			}
		}
		return $total > 0 ? (int) round( $got / $total * 100 ) : 0;
	}

	/**
	 * Build a check item.
	 *
	 * @param string $group          Group.
	 * @param string $id             Id.
	 * @param string $label          Label.
	 * @param string $status         Status.
	 * @param string $value          Display value.
	 * @param string $recommendation Recommendation.
	 * @param float  $weight         Weight.
	 * @param bool   $blocking       Blocks migrations when failing.
	 */
	private function item( string $group, string $id, string $label, string $status, string $value, string $recommendation = '', float $weight = 1.0, bool $blocking = false ): array {
		return compact( 'group', 'id', 'label', 'status', 'value', 'recommendation', 'weight', 'blocking' );
	}

	/**
	 * Parse ini size like "256M" into bytes. -1 means unlimited.
	 *
	 * @param string|false $v Value.
	 */
	public static function ini_bytes( $v ): int {
		if ( false === $v || '' === $v ) {
			return 0;
		}
		if ( '-1' === trim( $v ) ) {
			return -1;
		}
		return (int) wp_convert_hr_to_bytes( $v );
	}

	/** PHP checks. */
	private function check_php(): array {
		$out = array();
		$out[] = $this->item(
			'php',
			'php_version',
			__( 'PHP version', 'wp-site-transfer-manager' ),
			version_compare( PHP_VERSION, WSTM_MIN_PHP, '>=' ) ? self::PASS : self::FAIL,
			PHP_VERSION,
			sprintf( /* translators: %s: PHP version. */ __( 'PHP %s or newer is required.', 'wp-site-transfer-manager' ), WSTM_MIN_PHP ),
			2,
			true
		);

		$mem   = self::ini_bytes( ini_get( 'memory_limit' ) );
		$out[] = $this->item(
			'php',
			'memory_limit',
			__( 'PHP memory limit', 'wp-site-transfer-manager' ),
			( -1 === $mem || $mem >= 256 * MB_IN_BYTES ) ? self::PASS : ( $mem >= 128 * MB_IN_BYTES ? self::WARN : self::FAIL ),
			-1 === $mem ? __( 'Unlimited', 'wp-site-transfer-manager' ) : size_format( $mem ),
			__( '256 MB recommended. Lower limits work but use smaller batches.', 'wp-site-transfer-manager' )
		);

		$exec  = (int) ini_get( 'max_execution_time' );
		$out[] = $this->item(
			'php',
			'max_execution_time',
			__( 'Max execution time', 'wp-site-transfer-manager' ),
			( 0 === $exec || $exec >= 60 ) ? self::PASS : self::WARN,
			0 === $exec ? __( 'Unlimited', 'wp-site-transfer-manager' ) : $exec . 's',
			__( 'Short limits are handled by chunked, resumable jobs; consider lowering "Seconds of work per request".', 'wp-site-transfer-manager' ),
			0.5
		);

		$upload = self::ini_bytes( ini_get( 'upload_max_filesize' ) );
		$post   = self::ini_bytes( ini_get( 'post_max_size' ) );
		$eff    = min( $upload > 0 ? $upload : PHP_INT_MAX, $post > 0 ? $post : PHP_INT_MAX );
		$out[]  = $this->item(
			'php',
			'upload_limit',
			__( 'Upload limit (effective)', 'wp-site-transfer-manager' ),
			$eff >= 8 * MB_IN_BYTES ? self::PASS : self::WARN,
			sprintf( 'upload_max_filesize %s / post_max_size %s', size_format( $upload ), size_format( $post ) ),
			__( 'Uploads are chunked, but each chunk must fit under this limit. Choose a chunk size below it.', 'wp-site-transfer-manager' ),
			0.5
		);

		foreach ( array(
			'hash'   => array( 'hash_algos', true ),
			'json'   => array( 'json_encode', true ),
			'mbstring' => array( 'mb_strlen', false ),
			'openssl'  => array( 'openssl_encrypt', false ),
		) as $ext => $def ) {
			$ok    = function_exists( $def[0] ) && ( 'hash' !== $ext || in_array( 'sha256', hash_algos(), true ) );
			$out[] = $this->item(
				'php',
				'ext_' . $ext,
				sprintf( /* translators: %s: extension */ __( 'PHP %s extension', 'wp-site-transfer-manager' ), $ext ),
				$ok ? self::PASS : ( $def[1] ? self::FAIL : self::WARN ),
				$ok ? __( 'Available', 'wp-site-transfer-manager' ) : __( 'Missing', 'wp-site-transfer-manager' ),
				$ok ? '' : sprintf( /* translators: %s: extension */ __( 'Ask your host to enable the %s extension.', 'wp-site-transfer-manager' ), $ext ),
				$def[1] ? 1 : 0.5,
				$def[1]
			);
		}
		return $out;
	}

	/** WordPress checks. */
	private function check_wordpress(): array {
		global $wp_version;
		$out   = array();
		$out[] = $this->item( 'wordpress', 'wp_version', __( 'WordPress version', 'wp-site-transfer-manager' ), version_compare( $wp_version, WSTM_MIN_WP, '>=' ) ? self::PASS : self::FAIL, $wp_version, '', 1, true );
		$out[] = $this->item( 'wordpress', 'site_url', __( 'Site URL', 'wp-site-transfer-manager' ), self::INFO, site_url() );
		$out[] = $this->item( 'wordpress', 'home_url', __( 'Home URL', 'wp-site-transfer-manager' ), self::INFO, home_url() );
		$out[] = $this->item( 'wordpress', 'multisite', __( 'Multisite', 'wp-site-transfer-manager' ), self::INFO, is_multisite() ? sprintf( /* translators: %d: count */ __( 'Yes (%d sites)', 'wp-site-transfer-manager' ), get_blog_count() ) : __( 'No', 'wp-site-transfer-manager' ) );
		$out[] = $this->item(
			'wordpress',
			'wp_cron',
			__( 'WP-Cron', 'wp-site-transfer-manager' ),
			( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? self::WARN : self::PASS,
			( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? __( 'Disabled', 'wp-site-transfer-manager' ) : __( 'Enabled', 'wp-site-transfer-manager' ),
			__( 'If disabled, ensure a real system cron calls wp-cron.php so cleanup runs.', 'wp-site-transfer-manager' ),
			0.25
		);
		return $out;
	}

	/** Database checks. */
	private function check_database(): array {
		$out   = array();
		$alive = $this->db->ping();
		$out[] = $this->item( 'database', 'db_connection', __( 'Database connection', 'wp-site-transfer-manager' ), $alive ? self::PASS : self::FAIL, $alive ? __( 'Connected', 'wp-site-transfer-manager' ) : __( 'Failed', 'wp-site-transfer-manager' ), '', 2, true );
		if ( ! $alive ) {
			return $out;
		}
		$ver    = $this->db->server_version();
		$maria  = $this->db->is_mariadb();
		$num    = preg_replace( '/[^0-9.].*$/', '', $ver );
		$ok     = $maria ? version_compare( $num, '10.4', '>=' ) : version_compare( $num, '5.7', '>=' );
		$out[]  = $this->item( 'database', 'db_version', __( 'Database version', 'wp-site-transfer-manager' ), $ok ? self::PASS : self::WARN, ( $maria ? 'MariaDB ' : 'MySQL ' ) . $ver, __( 'MySQL 5.7+ / MariaDB 10.4+ recommended.', 'wp-site-transfer-manager' ) );

		global $wpdb;
		$charset = $wpdb->charset ?: 'unknown';
		$out[]   = $this->item( 'database', 'db_charset', __( 'Database charset', 'wp-site-transfer-manager' ), str_starts_with( $charset, 'utf8mb4' ) ? self::PASS : self::WARN, $charset . ( $wpdb->collate ? ' / ' . $wpdb->collate : '' ), __( 'utf8mb4 recommended; other charsets may need conversion on import.', 'wp-site-transfer-manager' ), 0.5 );

		$packet = $this->db->max_allowed_packet();
		$out[]  = $this->item( 'database', 'max_allowed_packet', __( 'max_allowed_packet', 'wp-site-transfer-manager' ), $packet >= 16 * MB_IN_BYTES ? self::PASS : self::WARN, size_format( $packet ), __( 'Small packet sizes require smaller import batches.', 'wp-site-transfer-manager' ), 0.5 );

		$out[] = $this->item( 'database', 'db_size', __( 'Database size', 'wp-site-transfer-manager' ), self::INFO, size_format( $this->db->size_bytes() ) . ' / ' . count( $this->db->list_tables() ) . ' ' . __( 'tables', 'wp-site-transfer-manager' ) );
		return $out;
	}

	/** Filesystem checks. */
	private function check_filesystem(): array {
		$out     = array();
		$uploads = wp_upload_dir( null, false );
		$targets = array(
			'wp_content_writable' => array( __( 'wp-content writable', 'wp-site-transfer-manager' ), WP_CONTENT_DIR, true ),
			'uploads_writable'    => array( __( 'Uploads writable', 'wp-site-transfer-manager' ), $uploads['basedir'], true ),
			'root_writable'       => array( __( 'WordPress root writable', 'wp-site-transfer-manager' ), ABSPATH, false ),
		);
		foreach ( $targets as $id => $t ) {
			$ok    = wp_is_writable( $t[1] );
			$out[] = $this->item( 'filesystem', $id, $t[0], $ok ? self::PASS : ( $t[2] ? self::FAIL : self::WARN ), $ok ? __( 'Writable', 'wp-site-transfer-manager' ) : __( 'Not writable', 'wp-site-transfer-manager' ), $ok ? '' : __( 'Fix file permissions (usually 755 for directories) or ownership.', 'wp-site-transfer-manager' ), 1, $t[2] );
		}

		try {
			$root  = $this->storage->ensure_root();
			$probe = $root . '/tmp/.probe-' . bin2hex( random_bytes( 4 ) );
			$ok    = false !== file_put_contents( $probe, 'ok' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $ok ) {
				wp_delete_file( $probe );
			}
		} catch ( \Throwable $e ) {
			$ok = false;
		}
		$out[] = $this->item( 'filesystem', 'temp_writable', __( 'Temporary storage writable', 'wp-site-transfer-manager' ), $ok ? self::PASS : self::FAIL, $ok ? __( 'Writable', 'wp-site-transfer-manager' ) : __( 'Not writable', 'wp-site-transfer-manager' ), __( 'Set a writable custom storage directory in Settings.', 'wp-site-transfer-manager' ), 1.5, true );

		$out[] = $this->item(
			'filesystem',
			'storage_location',
			__( 'Backup storage location', 'wp-site-transfer-manager' ),
			$this->storage->is_publicly_located() ? self::WARN : self::PASS,
			$this->storage->is_publicly_located() ? __( 'Inside web root (protected, random name)', 'wp-site-transfer-manager' ) : __( 'Outside web root', 'wp-site-transfer-manager' ),
			__( 'For maximum safety set a storage directory outside the public web root.', 'wp-site-transfer-manager' ),
			0.5
		);

		$free  = $this->storage->free_space();
		$out[] = $this->item(
			'filesystem',
			'disk_free',
			__( 'Available disk space', 'wp-site-transfer-manager' ),
			null === $free ? self::WARN : ( $free > 2 * GB_IN_BYTES ? self::PASS : ( $free > 500 * MB_IN_BYTES ? self::WARN : self::FAIL ) ),
			null === $free ? __( 'Unknown (disk_free_space disabled)', 'wp-site-transfer-manager' ) : size_format( $free ),
			__( 'Migrations need roughly 2–3× the site size in free space. Exact requirements are calculated before each operation.', 'wp-site-transfer-manager' ),
			1.5
		);

		$fs_method = function_exists( 'get_filesystem_method' ) ? get_filesystem_method() : 'direct';
		$out[]     = $this->item( 'filesystem', 'fs_method', __( 'Filesystem method', 'wp-site-transfer-manager' ), 'direct' === $fs_method ? self::PASS : self::WARN, $fs_method, __( 'Direct file access is recommended; FTP-based methods are slower.', 'wp-site-transfer-manager' ), 0.5 );
		return $out;
	}

	/** Archive checks. */
	private function check_archive(): array {
		$zip  = class_exists( 'ZipArchive' );
		$phar = class_exists( 'PharData' );
		$gz   = function_exists( 'gzopen' ) && function_exists( 'gzencode' );
		return array(
			$this->item( 'archive', 'ziparchive', __( 'ZipArchive', 'wp-site-transfer-manager' ), $zip ? self::PASS : self::WARN, $zip ? __( 'Available', 'wp-site-transfer-manager' ) : __( 'Unavailable', 'wp-site-transfer-manager' ), $zip ? '' : __( 'The native .wpmig stream format will be used instead (Phase 3/4).', 'wp-site-transfer-manager' ) ),
			$this->item( 'archive', 'phardata', __( 'PharData', 'wp-site-transfer-manager' ), $phar ? self::PASS : self::INFO, $phar ? __( 'Available', 'wp-site-transfer-manager' ) : __( 'Unavailable', 'wp-site-transfer-manager' ) ),
			$this->item( 'archive', 'gzip', __( 'Gzip (zlib)', 'wp-site-transfer-manager' ), $gz ? self::PASS : self::WARN, $gz ? __( 'Available', 'wp-site-transfer-manager' ) : __( 'Unavailable', 'wp-site-transfer-manager' ), $gz ? '' : __( 'Database dumps will be stored uncompressed.', 'wp-site-transfer-manager' ) ),
		);
	}

	/** Network checks (local only; no external calls). */
	private function check_network(): array {
		$ssl   = is_ssl() || str_starts_with( home_url(), 'https://' );
		$out   = array(
			$this->item( 'network', 'ssl', __( 'HTTPS', 'wp-site-transfer-manager' ), $ssl ? self::PASS : self::WARN, $ssl ? __( 'Enabled', 'wp-site-transfer-manager' ) : __( 'Not enabled', 'wp-site-transfer-manager' ), __( 'Direct transfers between servers should use HTTPS.', 'wp-site-transfer-manager' ) ),
			$this->item( 'network', 'curl', __( 'cURL / HTTP transport', 'wp-site-transfer-manager' ), function_exists( 'curl_init' ) ? self::PASS : self::WARN, function_exists( 'curl_init' ) ? __( 'Available', 'wp-site-transfer-manager' ) : __( 'Streams fallback', 'wp-site-transfer-manager' ), '', 0.5 ),
		);
		$hooked = false;
		global $wp_filter;
		if ( isset( $wp_filter['rest_authentication_errors'] ) ) {
			foreach ( $wp_filter['rest_authentication_errors']->callbacks as $callbacks ) {
				foreach ( $callbacks as $cb ) {
					// Ignore WordPress core's own authentication handlers.
					if ( ! in_array( $cb['function'], array( 'rest_cookie_check_errors', 'rest_application_password_check_errors' ), true ) ) {
						$hooked = true;
					}
				}
			}
		}
		$out[]  = $this->item( 'network', 'rest_api', __( 'REST API', 'wp-site-transfer-manager' ), $hooked ? self::WARN : self::PASS, rest_url() . ( $hooked ? ' (' . __( 'filtered by another plugin', 'wp-site-transfer-manager' ) . ')' : '' ), __( 'The migration UI and direct transfer use the REST API. Make sure security plugins do not block /wp-json/wstm/.', 'wp-site-transfer-manager' ) );
		return $out;
	}

	/** Ecosystem detection (informational; never dependencies). */
	private function check_ecosystem(): array {
		$out = array();
		foreach ( Detector::detect() as $id => $info ) {
			$out[] = $this->item( 'ecosystem', $id, $info['label'], self::INFO, $info['active'] ? sprintf( /* translators: %s: version */ __( 'Active %s', 'wp-site-transfer-manager' ), $info['version'] ) : __( 'Not detected', 'wp-site-transfer-manager' ) );
		}
		return $out;
	}

	/**
	 * Throw if any of the given checks fails (fresh run). Scopes pre-flight
	 * requirements to what an operation actually needs.
	 *
	 * @param string[] $ids       Check ids required by the operation.
	 * @param string   $operation Operation label.
	 * @throws \WSTM\Core\WstmException When a required check fails.
	 */
	public function assert_ready( array $ids, string $operation ): void {
		$failed = array();
		foreach ( $this->run( true )['checks'] as $c ) {
			if ( in_array( $c['id'], $ids, true ) && self::FAIL === $c['status'] ) {
				$failed[] = $c['label'] . ': ' . $c['value'] . ( $c['recommendation'] ? ' (' . $c['recommendation'] . ')' : '' );
			}
		}
		if ( $failed ) {
			throw new \WSTM\Core\WstmException(
				'preflight_failed',
				'Pre-flight checks failed.',
				array(
					'what'   => $operation . ' pre-flight',
					'why'    => implode( '; ', $failed ),
					'action' => 'Fix the listed problems (see Diagnostics). Nothing was changed.',
				)
			);
		}
	}

	/** Clear cached report. */
	public function flush(): void {
		delete_site_transient( self::CACHE_KEY );
	}
}
