<?php
/**
 * Post-migration health check: is the site actually working?
 *
 * Loopback requests can be blocked by some hosts/firewalls; those failures
 * are reported as warnings with an explanation rather than hard errors.
 *
 * @package WSTM\Diagnostics
 */

namespace WSTM\Diagnostics;

use WSTM\Database\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Health check.
 */
final class HealthCheck {

	/**
	 * Run all checks.
	 *
	 * @param Database $db           Database.
	 * @param string   $expected_url Expected home URL (optional).
	 * @return array{status:string,checks:array,generated_at:string}
	 */
	public static function run( Database $db, string $expected_url = '' ): array {
		$c    = array();
		$add  = static function ( string $id, string $label, string $status, string $value, string $hint = '' ) use ( &$c ) {
			$c[] = compact( 'id', 'label', 'status', 'value', 'hint' );
		};
		$home = home_url();
		$site = site_url();

		$add( 'database', 'Database connection', $db->ping() ? 'pass' : 'error', $db->ping() ? 'Connected' : 'Failed' );
		$valid = wp_http_validate_url( $home ) || preg_match( '#^https?://#', $home );
		$add( 'home_url', 'Home URL', $valid && ( '' === $expected_url || untrailingslashit( $expected_url ) === untrailingslashit( $home ) ) ? 'pass' : 'error', $home, '' !== $expected_url && untrailingslashit( $expected_url ) !== untrailingslashit( $home ) ? 'Expected ' . $expected_url : '' );
		$add( 'site_url', 'WordPress address', ( wp_http_validate_url( $site ) || preg_match( '#^https?://#', $site ) ) ? 'pass' : 'error', $site );
		$https = str_starts_with( $home, 'https://' );
		$add( 'https', 'HTTPS', $https ? 'pass' : 'warning', $https ? 'Enabled' : 'Not enabled', $https ? '' : 'Use HTTPS on live sites.' );

		global $wp_version;
		$add( 'wp_version', 'WordPress version', 'pass', $wp_version );

		$theme = wp_get_theme();
		$add( 'theme', 'Active theme', $theme->exists() && ! $theme->errors() ? 'pass' : 'error', $theme->exists() ? $theme->get( 'Name' ) : get_stylesheet() . ' (missing)', $theme->exists() ? '' : 'The active theme folder is missing — restore themes or switch theme.' );

		$missing = array();
		foreach ( (array) get_option( 'active_plugins', array() ) as $p ) {
			if ( ! is_file( WP_PLUGIN_DIR . '/' . $p ) ) {
				$missing[] = $p;
			}
		}
		$add( 'plugins', 'Active plugins', $missing ? 'warning' : 'pass', $missing ? 'Missing: ' . implode( ', ', $missing ) : count( (array) get_option( 'active_plugins', array() ) ) . ' active', $missing ? 'WordPress deactivates missing plugins automatically; restore them if needed.' : '' );

		$up = wp_upload_dir( null, false );
		$add( 'uploads', 'Uploads folder', is_dir( $up['basedir'] ) && wp_is_writable( $up['basedir'] ) ? 'pass' : 'error', $up['basedir'], 'Must exist and be writable.' );

		$perma = (string) get_option( 'permalink_structure' );
		$add( 'permalinks', 'Permalinks', 'pass', '' === $perma ? 'Plain' : $perma );

		$sslverify = (bool) apply_filters( 'https_local_ssl_verify', false );
		$probe     = static function ( string $url ) use ( $sslverify ) {
			$r = wp_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3, 'sslverify' => $sslverify, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
			return is_wp_error( $r ) ? $r : array( (int) wp_remote_retrieve_response_code( $r ), (string) wp_remote_retrieve_body( $r ) );
		};
		$loop_hint = 'The server could not reach itself (loopback). If the site opens fine in your browser this is a hosting restriction, not a migration problem.';

		$r = $probe( add_query_arg( 'wstm_health', time(), $home . '/' ) );
		if ( is_wp_error( $r ) ) {
			$add( 'homepage', 'Homepage', 'warning', $r->get_error_message(), $loop_hint );
		} else {
			$broken = $r[0] >= 500 || str_contains( $r[1], 'Error establishing a database connection' ) || str_contains( $r[1], 'There has been a critical error' );
			$add( 'homepage', 'Homepage', $broken ? 'error' : ( $r[0] >= 400 ? 'warning' : 'pass' ), 'HTTP ' . $r[0], $broken ? 'The homepage shows an error — check the Logs page and PHP error log.' : '' );
		}
		$r = $probe( admin_url( 'admin-ajax.php' ) );
		$add( 'admin', 'WP Admin', is_wp_error( $r ) ? 'warning' : ( $r[0] >= 500 ? 'error' : 'pass' ), is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . $r[0], is_wp_error( $r ) ? $loop_hint : '' );
		$r = $probe( rest_url() );
		$ok_rest = ! is_wp_error( $r ) && 200 === $r[0] && is_array( json_decode( $r[1], true ) );
		$add( 'rest', 'REST API', $ok_rest ? 'pass' : 'warning', is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . $r[0], $ok_rest ? '' : 'A security plugin or server rule may block the REST API.' );

		$statuses = array_column( $c, 'status' );
		return array(
			'status'       => in_array( 'error', $statuses, true ) ? 'error' : ( in_array( 'warning', $statuses, true ) ? 'warning' : 'pass' ),
			'checks'       => $c,
			'generated_at' => gmdate( 'c' ),
		);
	}
}
