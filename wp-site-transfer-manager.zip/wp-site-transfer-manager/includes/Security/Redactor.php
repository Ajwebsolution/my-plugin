<?php
/**
 * Secret redaction for logs and error output.
 *
 * @package WSTM\Security
 */

namespace WSTM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Removes passwords, keys, secrets and tokens from data before persistence.
 */
final class Redactor {

	public const MASK = '[REDACTED]';

	/**
	 * Key fragments that mark a value as secret.
	 */
	private const SENSITIVE_KEYS = array(
		'password', 'passwd', 'pass', 'pwd', 'secret', 'token', 'api_key', 'apikey',
		'auth', 'key', 'salt', 'signature', 'hmac', 'credential', 'private', 'nonce',
		'cookie', 'session', 'db_password', 'access_key',
	);

	/**
	 * Recursively redact an array.
	 *
	 * @param mixed $data Data.
	 */
	public static function redact( $data ) {
		if ( is_array( $data ) ) {
			$out = array();
			foreach ( $data as $k => $v ) {
				$out[ $k ] = ( is_string( $k ) && self::is_sensitive_key( $k ) ) ? self::MASK : self::redact( $v );
			}
			return $out;
		}
		if ( is_object( $data ) ) {
			return self::redact( get_object_vars( $data ) );
		}
		if ( is_string( $data ) ) {
			return self::redact_string( $data );
		}
		return $data;
	}

	/**
	 * Whether a key name denotes a secret.
	 *
	 * @param string $key Key.
	 */
	public static function is_sensitive_key( string $key ): bool {
		$key = strtolower( $key );
		foreach ( self::SENSITIVE_KEYS as $frag ) {
			if ( str_contains( $key, $frag ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Redact secrets embedded inside free text.
	 *
	 * @param string $text Text.
	 */
	public static function redact_string( string $text ): string {
		$patterns = array(
			// define( 'DB_PASSWORD', '...' ) and *_KEY / *_SALT constants.
			'/(define\s*\(\s*[\'"](?:DB_PASSWORD|[A-Z_]*(?:KEY|SALT|SECRET|TOKEN))[\'"]\s*,\s*)([\'"]).*?\2/i' => '$1$2' . self::MASK . '$2',
			// key=value / key: value pairs.
			'/\b(password|passwd|pwd|secret|token|api[_-]?key|signature|hmac)(\s*[=:]\s*)([^\s&,;"\']+)/i' => '$1$2' . self::MASK,
			// Credentials in URLs.
			'#(\b[a-z][a-z0-9+.-]*://[^:/\s@]+:)[^@\s/]+@#i' => '$1' . self::MASK . '@',
			// Bearer tokens.
			'/(Bearer\s+)[A-Za-z0-9\-._~+\/]+=*/i' => '$1' . self::MASK,
			// Transfer keys (wstm_ prefix, see Phase 8).
			'/\bwstm_[A-Za-z0-9]{24,}\b/' => self::MASK,
		);
		return (string) preg_replace( array_keys( $patterns ), array_values( $patterns ), $text );
	}
}
