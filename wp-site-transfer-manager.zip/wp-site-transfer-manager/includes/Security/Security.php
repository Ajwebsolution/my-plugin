<?php
/**
 * Nonce, capability and request security helpers.
 *
 * @package WSTM\Security
 */

namespace WSTM\Security;

use WSTM\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Security helpers. Authorization is ALWAYS capability + nonce, never nonce alone.
 */
final class Security {

	public const NONCE_PREFIX = 'wstm_';

	/**
	 * Build a nonce action name.
	 *
	 * @param string $action Action.
	 */
	public static function nonce_action( string $action ): string {
		return self::NONCE_PREFIX . sanitize_key( $action );
	}

	/**
	 * Create a nonce.
	 *
	 * @param string $action Action.
	 */
	public static function create_nonce( string $action ): string {
		return wp_create_nonce( self::nonce_action( $action ) );
	}

	/**
	 * Output a nonce field.
	 *
	 * @param string $action Action.
	 */
	public static function nonce_field( string $action ): void {
		wp_nonce_field( self::nonce_action( $action ), '_wstm_nonce' );
	}

	/**
	 * Verify capability and nonce for an admin POST/GET request.
	 *
	 * @param string $action Nonce action.
	 * @return true|\WP_Error
	 */
	public static function verify_request( string $action ) {
		if ( ! Capabilities::current_user_can_manage() ) {
			return new \WP_Error( 'wstm_forbidden', __( 'You are not allowed to perform migration operations.', 'wp-site-transfer-manager' ), array( 'status' => 403 ) );
		}
		$nonce = isset( $_REQUEST['_wstm_nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wstm_nonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- this IS the verification.
		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::nonce_action( $action ) ) ) {
			return new \WP_Error( 'wstm_bad_nonce', __( 'Security check failed. Please reload the page and try again.', 'wp-site-transfer-manager' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * REST permission callback: capability + REST nonce (cookie auth).
	 *
	 * @return true|\WP_Error
	 */
	public static function rest_permission() {
		if ( ! Capabilities::current_user_can_manage() ) {
			return new \WP_Error( 'wstm_forbidden', __( 'You are not allowed to perform migration operations.', 'wp-site-transfer-manager' ), array( 'status' => rest_authorization_required_code() ) );
		}
		return true;
	}

	/**
	 * Constant-time string comparison.
	 *
	 * @param string $known Known.
	 * @param string $user  User supplied.
	 */
	public static function equals( string $known, string $user ): bool {
		return hash_equals( $known, $user );
	}

	/**
	 * Cryptographically secure random token (hex).
	 *
	 * @param int $bytes Bytes.
	 */
	public static function random_token( int $bytes = 32 ): string {
		return bin2hex( random_bytes( $bytes ) );
	}

	/**
	 * Simple transient-backed rate limiter.
	 *
	 * @param string $bucket  Bucket name (e.g. "transfer_auth_" . ip hash).
	 * @param int    $max     Max attempts.
	 * @param int    $window  Window seconds.
	 * @return bool True if allowed, false if limit exceeded.
	 */
	public static function rate_limit( string $bucket, int $max, int $window ): bool {
		$key   = 'wstm_rl_' . md5( $bucket );
		$count = (int) get_site_transient( $key );
		if ( $count >= $max ) {
			return false;
		}
		set_site_transient( $key, $count + 1, $window );
		return true;
	}

	/**
	 * Hashed client IP for rate-limit buckets (no raw IP stored).
	 */
	public static function client_fingerprint(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0.0.0.0';
		return hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}
}
