<?php
/**
 * Symmetric encryption for secrets at rest (transfer secrets, cloud credentials).
 *
 * Key: derived from this site's wp-config.php salts (never stored in the database),
 * so a database copy alone cannot decrypt the secrets. Uses libsodium
 * (XSalsa20-Poly1305) when available, otherwise OpenSSL AES-256-GCM.
 *
 * @package WSTM\Security
 */

namespace WSTM\Security;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Crypto helper.
 */
final class Crypto {

	/** Derived 32-byte key. */
	private static function key(): string {
		$material = ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' ) . ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' );
		if ( '' === $material ) {
			$material = wp_salt( 'secure_auth' );
		}
		return hash_hmac( 'sha256', 'wstm-secrets-v1', $material, true );
	}

	/**
	 * Encrypt.
	 *
	 * @param string $plain Plain text.
	 * @throws WstmException If no cipher is available.
	 */
	public static function encrypt( string $plain ): string {
		$key = self::key();
		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			return 's1:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, $key ) );
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv  = random_bytes( 12 );
			$tag = '';
			$ct  = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
			if ( false !== $ct ) {
				return 'o1:' . base64_encode( $iv . $tag . $ct );
			}
		}
		throw new WstmException( 'no_crypto', 'This server has neither libsodium nor OpenSSL; secrets cannot be stored safely.', array( 'action' => 'Ask your host to enable the sodium or openssl PHP extension.' ) );
	}

	/**
	 * Decrypt; null when the value cannot be authenticated (tampered or salts changed).
	 *
	 * @param string $enc Encrypted value.
	 */
	public static function decrypt( string $enc ): ?string {
		$key = self::key();
		if ( str_starts_with( $enc, 's1:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$raw = base64_decode( substr( $enc, 3 ), true );
			if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
				return null;
			}
			$out = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $key );
			return false === $out ? null : $out;
		}
		if ( str_starts_with( $enc, 'o1:' ) && function_exists( 'openssl_decrypt' ) ) {
			$raw = base64_decode( substr( $enc, 3 ), true );
			if ( false === $raw || strlen( $raw ) < 29 ) {
				return null;
			}
			$out = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
			return false === $out ? null : $out;
		}
		return null;
	}
}
