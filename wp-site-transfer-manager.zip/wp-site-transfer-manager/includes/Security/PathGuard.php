<?php
/**
 * Path validation: traversal, absolute paths, drive letters, symlink escape.
 *
 * Used by temp storage now and by archive extraction / package validation later.
 *
 * @package WSTM\Security
 */

namespace WSTM\Security;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Path guard.
 */
final class PathGuard {

	/**
	 * Validate a RELATIVE path (e.g. an archive entry). Returns normalized path.
	 *
	 * @param string $path Relative path.
	 * @throws WstmException On unsafe path.
	 */
	public static function safe_relative( string $path ): string {
		$fail = static function ( string $why ) use ( $path ) {
			throw new WstmException(
				'unsafe_path',
				'Rejected unsafe path.',
				array(
					'what'   => 'Path validation',
					'why'    => $why . ' (' . mb_substr( $path, 0, 200 ) . ')',
					'action' => 'The package or input may be corrupted or malicious. Do not import it.',
				)
			);
		};

		if ( '' === $path || str_contains( $path, "\0" ) ) {
			$fail( 'Empty path or null byte' );
		}
		$p = str_replace( '\\', '/', $path );

		if ( str_starts_with( $p, '/' ) ) {
			$fail( 'Absolute path' );
		}
		if ( preg_match( '#^[A-Za-z]:#', $p ) ) {
			$fail( 'Windows drive path' );
		}
		if ( preg_match( '#^[a-z][a-z0-9+.-]*://#i', $p ) ) {
			$fail( 'Stream wrapper' );
		}

		$parts = array();
		foreach ( explode( '/', $p ) as $seg ) {
			if ( '' === $seg || '.' === $seg ) {
				continue;
			}
			if ( '..' === $seg ) {
				$fail( 'Parent directory traversal' );
			}
			$parts[] = $seg;
		}
		if ( empty( $parts ) ) {
			$fail( 'Path resolves to nothing' );
		}
		return implode( '/', $parts );
	}

	/**
	 * Join base + relative and ensure the result stays within base, including
	 * after resolving any existing symlinks in the parent chain.
	 *
	 * @param string $base     Absolute base directory (must exist).
	 * @param string $relative Relative path.
	 * @throws WstmException On escape.
	 */
	public static function resolve_within( string $base, string $relative ): string {
		$real_base = realpath( $base );
		if ( false === $real_base ) {
			throw new WstmException( 'base_missing', 'Base directory does not exist.', array( 'what' => 'Path resolution', 'why' => 'Base directory missing' ) );
		}
		$real_base = rtrim( str_replace( '\\', '/', $real_base ), '/' );
		$target    = $real_base . '/' . self::safe_relative( $relative );

		// Walk up to the deepest existing ancestor and resolve it.
		$probe = $target;
		while ( ! file_exists( $probe ) && $probe !== $real_base ) {
			$probe = dirname( $probe );
		}
		$real_probe = realpath( $probe );
		if ( false === $real_probe || ! self::is_within( $real_base, str_replace( '\\', '/', $real_probe ) ) ) {
			throw new WstmException(
				'path_escape',
				'Path escapes the allowed directory.',
				array(
					'what'   => 'Path resolution',
					'why'    => 'Resolved location (possibly via symlink) is outside the target directory',
					'action' => 'Remove the offending symlink or entry and retry.',
				)
			);
		}
		if ( is_link( $target ) ) {
			throw new WstmException( 'symlink_target', 'Refusing to write through a symlink.', array( 'what' => 'Path resolution', 'why' => 'Target is a symbolic link' ) );
		}
		return $target;
	}

	/**
	 * Whether $path is $base or inside it (both already normalized, no trailing slash).
	 *
	 * @param string $base Base.
	 * @param string $path Path.
	 */
	public static function is_within( string $base, string $path ): bool {
		$base = rtrim( $base, '/' );
		$path = rtrim( $path, '/' );
		return $path === $base || str_starts_with( $path, $base . '/' );
	}
}
