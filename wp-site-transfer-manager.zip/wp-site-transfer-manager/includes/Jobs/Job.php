<?php
/**
 * Job value object.
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

defined( 'ABSPATH' ) || exit;

/**
 * Immutable snapshot of a job row.
 */
final class Job {

	/**
	 * @var int
	 */
	public int $id;

	/**
	 * @var string
	 */
	public string $uuid;

	/**
	 * @var string
	 */
	public string $type;

	/**
	 * @var string
	 */
	public string $status;

	/**
	 * @var string
	 */
	public string $current_step;

	/**
	 * @var float
	 */
	public float $progress;

	/**
	 * @var array
	 */
	public array $checkpoint;

	/**
	 * @var array
	 */
	public array $metadata;

	/**
	 * @var array|null
	 */
	public ?array $error;

	/**
	 * @var int
	 */
	public int $attempts;

	/**
	 * @var string|null
	 */
	public ?string $started_at;

	/**
	 * @var string
	 */
	public string $updated_at;

	/**
	 * @var string|null
	 */
	public ?string $finished_at;

	/**
	 * @var string
	 */
	public string $created_at;

	/**
	 * @var int|null
	 */
	public ?int $parent_id;

	/**
	 * Constructor.
	 *
	 * @param int         $id           Id.
	 * @param string      $uuid         UUID.
	 * @param string      $type         Type.
	 * @param string      $status       Status.
	 * @param string      $current_step Step.
	 * @param float       $progress     0-100.
	 * @param array       $checkpoint   Resume checkpoint.
	 * @param array       $metadata     Metadata.
	 * @param array|null  $error        Structured error.
	 * @param int         $attempts     Attempts.
	 * @param string|null $started_at   Started.
	 * @param string      $updated_at   Updated.
	 * @param string|null $finished_at  Finished.
	 * @param string      $created_at   Created.
	 * @param int|null    $parent_id    Parent job.
	 */
	public function __construct(
		int $id,
		string $uuid,
		string $type,
		string $status,
		string $current_step,
		float $progress,
		array $checkpoint,
		array $metadata,
		?array $error,
		int $attempts,
		?string $started_at,
		string $updated_at,
		?string $finished_at,
		string $created_at,
		?int $parent_id = null
	) {
		$this->id = $id;
		$this->uuid = $uuid;
		$this->type = $type;
		$this->status = $status;
		$this->current_step = $current_step;
		$this->progress = $progress;
		$this->checkpoint = $checkpoint;
		$this->metadata = $metadata;
		$this->error = $error;
		$this->attempts = $attempts;
		$this->started_at = $started_at;
		$this->updated_at = $updated_at;
		$this->finished_at = $finished_at;
		$this->created_at = $created_at;
		$this->parent_id = $parent_id;
	}

	/**
	 * Hydrate from DB row.
	 *
	 * @param array $r Row.
	 */
	public static function from_row( array $r ): self {
		$decode = static function ( $v ): array {
			if ( null === $v || '' === $v ) {
				return array();
			}
			$d = json_decode( (string) $v, true );
			return is_array( $d ) ? $d : array();
		};
		$err = $decode( $r['error'] ?? null );
		return new self(
			(int) $r['id'],
			(string) $r['uuid'],
			(string) $r['type'],
			(string) $r['status'],
			(string) $r['current_step'],
			(float) $r['progress'],
			$decode( $r['checkpoint'] ?? null ),
			$decode( $r['metadata'] ?? null ),
			$err ?: null,
			(int) $r['attempts'],
			$r['started_at'] ?? null,
			(string) $r['updated_at'],
			$r['finished_at'] ?? null,
			(string) $r['created_at'],
			isset( $r['parent_id'] ) ? (int) $r['parent_id'] : null,
		);
	}

	/** Array for REST/UI. */
	public function to_array(): array {
		return get_object_vars( $this );
	}
}
