<?php
/**
 * Background job runner (WP-Cron). Keeps jobs progressing when the browser tab
 * is closed. The admin UI also drives jobs directly; the per-job lock prevents
 * both from running the same job at once.
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

use WSTM\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Runner.
 */
class BackgroundRunner {

	public const HOOK = 'wstm_run_jobs';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Register hooks. */
	public function hooks(): void {
		add_action( self::HOOK, array( $this, 'run' ) );
		add_action( 'wstm_job_queued', array( $this, 'schedule' ) );
	}

	/** Schedule a run soon (no-op if already scheduled). */
	public function schedule(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 10, self::HOOK );
		}
	}

	/** Run active jobs within the time budget. */
	public function run(): void {
		$budget = (int) $this->plugin->settings()->get( 'time_budget' );
		$jobs   = $this->plugin->jobs()->list(
			array(
				'status'   => array( JobStatus::RUNNING, JobStatus::PENDING ),
				'per_page' => 3,
			)
		);
		$active = false;
		foreach ( $jobs as $job ) {
			try {
				$after = $this->plugin->jobs()->run( $job->id, $budget );
			} catch ( \Throwable $e ) {
				$this->plugin->logger()->error( 'Background run failed: ' . $e->getMessage(), array(), 'cron', $job->id );
				continue;
			}
			if ( in_array( $after->status, array( JobStatus::RUNNING, JobStatus::PENDING ), true ) ) {
				$active = true;
			}
		}
		if ( $active ) {
			$this->schedule();
		}
	}
}
