<?php
/**
 * Contract for resumable job handlers (database export, file archive, etc.).
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

defined( 'ABSPATH' ) || exit;

/**
 * Every long-running operation implements this. A handler performs one
 * bounded slice of work per call and returns a StepResult with a new
 * checkpoint. It must be safe to call again with the last saved checkpoint.
 */
interface JobHandlerInterface {

	/**
	 * Job type identifier this handler serves (e.g. "db_export").
	 */
	public function type(): string;

	/**
	 * Execute one slice of work.
	 *
	 * @param Job $job      Current job snapshot.
	 * @param int $deadline Unix timestamp after which the handler must yield.
	 */
	public function step( Job $job, int $deadline ): StepResult;

	/**
	 * Optional cleanup when a job is cancelled (temp files etc.).
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void;
}
