<?php
/**
 * Job statuses and allowed transitions.
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

defined( 'ABSPATH' ) || exit;

/**
 * Job state machine.
 */
final class JobStatus {

	public const PENDING   = 'pending';
	public const RUNNING   = 'running';
	public const PAUSED    = 'paused';
	public const COMPLETED = 'completed';
	public const FAILED    = 'failed';
	public const CANCELLED = 'cancelled';
	public const ROLLBACK  = 'rollback';

	/**
	 * Allowed transitions.
	 */
	private const TRANSITIONS = array(
		self::PENDING   => array( self::RUNNING, self::CANCELLED, self::PAUSED ),
		self::RUNNING   => array( self::RUNNING, self::PAUSED, self::COMPLETED, self::FAILED, self::CANCELLED, self::ROLLBACK ),
		self::PAUSED    => array( self::RUNNING, self::CANCELLED ),
		self::FAILED    => array( self::RUNNING, self::ROLLBACK, self::CANCELLED ),
		self::ROLLBACK  => array( self::COMPLETED, self::FAILED ),
		self::COMPLETED => array(),
		self::CANCELLED => array(),
	);

	/** All statuses. */
	public static function all(): array {
		return array_keys( self::TRANSITIONS );
	}

	/**
	 * Whether transition is allowed.
	 *
	 * @param string $from From.
	 * @param string $to   To.
	 */
	public static function can( string $from, string $to ): bool {
		return in_array( $to, self::TRANSITIONS[ $from ] ?? array(), true );
	}

	/**
	 * Terminal status?
	 *
	 * @param string $s Status.
	 */
	public static function is_terminal( string $s ): bool {
		return in_array( $s, array( self::COMPLETED, self::CANCELLED ), true );
	}
}
