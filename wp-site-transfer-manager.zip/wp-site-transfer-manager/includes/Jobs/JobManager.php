<?php
/**
 * Central resumable job manager.
 *
 * Responsibilities: create jobs, enforce the state machine, acquire an
 * exclusive lock per job, run handler slices within a time budget, persist
 * checkpoints after every slice, record structured errors.
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

use WSTM\Core\Logger;
use WSTM\Core\WstmException;
use WSTM\Database\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Job manager.
 */
class JobManager {

	public const LOCK_SECONDS = 120;

	/**
	 * Registered handlers keyed by type.
	 *
	 * @var array<string,JobHandlerInterface>
	 */
	private array $handlers = array();

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var Logger
	 */
	private Logger $logger;

	/**
	 * Constructor.
	 *
	 * @param Database $db     Database.
	 * @param Logger   $logger Logger.
	 */
	public function __construct( Database $db, Logger $logger ) {
		$this->db = $db;
		$this->logger = $logger;
		/**
		 * Allow modules to register job handlers.
		 *
		 * @param JobManager $manager Manager.
		 */
		do_action( 'wstm_register_job_handlers', $this );
	}

	/**
	 * Register a handler.
	 *
	 * @param JobHandlerInterface $handler Handler.
	 */
	public function register_handler( JobHandlerInterface $handler ): void {
		$this->handlers[ $handler->type() ] = $handler;
	}

	/**
	 * Whether a handler exists.
	 *
	 * @param string $type Type.
	 */
	public function has_handler( string $type ): bool {
		return isset( $this->handlers[ $type ] );
	}

	/** Now (UTC MySQL). */
	private function now(): string {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * Create a pending job.
	 *
	 * @param string   $type      Type.
	 * @param array    $metadata  Metadata.
	 * @param int|null $parent_id Parent job id.
	 */
	public function create( string $type, array $metadata = array(), ?int $parent_id = null ): Job {
		$type = sanitize_key( $type );
		$now  = $this->now();
		$id   = $this->db->insert(
			'jobs',
			array(
				'uuid'         => wp_generate_uuid4(),
				'type'         => $type,
				'status'       => JobStatus::PENDING,
				'current_step' => 'queued',
				'progress'     => 0,
				'checkpoint'   => wp_json_encode( array() ),
				'metadata'     => wp_json_encode( $metadata ),
				'parent_id'    => $parent_id,
				'created_by'   => get_current_user_id() ?: null,
				'updated_at'   => $now,
				'created_at'   => $now,
			)
		);
		$this->logger->info( sprintf( 'Job #%d (%s) created', $id, $type ), array(), 'jobs', $id );
		$job = $this->get( $id );
		/**
		 * Fires when a job is ready to run (used by the background runner).
		 *
		 * @param Job $job Job.
		 */
		do_action( 'wstm_job_queued', $job );
		return $job;
	}

	/**
	 * Fetch a job.
	 *
	 * @param int $id Id.
	 * @throws WstmException If missing.
	 */
	public function get( int $id ): Job {
		$row = $this->db->get_row( 'SELECT * FROM ' . $this->db->table( 'jobs' ) . ' WHERE id = %d', array( $id ) );
		if ( ! $row ) {
			throw new WstmException( 'job_not_found', 'Job not found.', array( 'what' => 'Job lookup', 'why' => 'No job with id ' . $id ) );
		}
		return Job::from_row( $row );
	}

	/**
	 * List jobs (paginated).
	 *
	 * @param array $args status, type, per_page, page.
	 * @return Job[]
	 */
	public function list( array $args = array() ): array {
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['status'] ) ) {
			$statuses = array_values( array_intersect( (array) $args['status'], JobStatus::all() ) );
			if ( $statuses ) {
				$where[] = 'status IN (' . implode( ',', array_fill( 0, count( $statuses ), '%s' ) ) . ')';
				$params  = array_merge( $params, $statuses );
			}
		}
		if ( ! empty( $args['type'] ) ) {
			$where[]  = 'type = %s';
			$params[] = sanitize_key( $args['type'] );
		}
		$per_page = max( 1, min( 200, (int) ( $args['per_page'] ?? 20 ) ) );
		$offset   = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $per_page;
		$params[] = $per_page;
		$params[] = $offset;

		$rows = $this->db->get_results(
			'SELECT * FROM ' . $this->db->table( 'jobs' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d',
			$params
		);
		return array_map( array( Job::class, 'from_row' ), $rows );
	}

	/**
	 * Transition status with state-machine validation.
	 *
	 * @param int        $id     Job id.
	 * @param string     $to     New status.
	 * @param array|null $error  Structured error.
	 * @throws WstmException On invalid transition.
	 */
	public function transition( int $id, string $to, ?array $error = null ): Job {
		$job = $this->get( $id );
		if ( ! JobStatus::can( $job->status, $to ) ) {
			throw new WstmException(
				'invalid_transition',
				'Invalid job status change.',
				array(
					'what' => 'Job #' . $id,
					'why'  => sprintf( 'Cannot move from "%s" to "%s"', $job->status, $to ),
				)
			);
		}
		$data = array(
			'status'     => $to,
			'updated_at' => $this->now(),
		);
		if ( JobStatus::RUNNING === $to && null === $job->started_at ) {
			$data['started_at'] = $this->now();
		}
		if ( in_array( $to, array( JobStatus::COMPLETED, JobStatus::FAILED, JobStatus::CANCELLED ), true ) ) {
			$data['finished_at'] = $this->now();
			$data['lock_token']  = null;
			$data['locked_until'] = null;
		}
		if ( null !== $error ) {
			$data['error'] = wp_json_encode( \WSTM\Security\Redactor::redact( $error ) );
		} elseif ( JobStatus::RUNNING === $to ) {
			$data['error'] = null;
		}
		$this->db->update( 'jobs', $data, array( 'id' => $id ) );
		$this->logger->info( sprintf( 'Job #%d: %s → %s', $id, $job->status, $to ), array(), 'jobs', $id );

		if ( JobStatus::CANCELLED === $to && isset( $this->handlers[ $job->type ] ) ) {
			try {
				$this->handlers[ $job->type ]->on_cancel( $job );
			} catch ( \Throwable $e ) {
				$this->logger->warning( 'Cancel cleanup failed: ' . $e->getMessage(), array(), 'jobs', $id );
			}
		}
		return $this->get( $id );
	}

	/** @param int $id Job. */
	public function pause( int $id ): Job {
		return $this->transition( $id, JobStatus::PAUSED );
	}

	/** @param int $id Job. */
	public function resume( int $id ): Job {
		$job = $this->transition( $id, JobStatus::RUNNING );
		do_action( 'wstm_job_queued', $job );
		return $job;
	}

	/** @param int $id Job. */
	public function cancel( int $id ): Job {
		return $this->transition( $id, JobStatus::CANCELLED );
	}

	/**
	 * Atomically acquire the job lock (prevents two requests running one job).
	 *
	 * @param int $id Job id.
	 * @return string|null Lock token or null if already locked.
	 */
	public function acquire_lock( int $id ): ?string {
		$token = bin2hex( random_bytes( 16 ) );
		$now   = $this->now();
		$until = gmdate( 'Y-m-d H:i:s', time() + self::LOCK_SECONDS );
		$n     = $this->db->query(
			'UPDATE ' . $this->db->table( 'jobs' ) . ' SET lock_token = %s, locked_until = %s
			 WHERE id = %d AND ( lock_token IS NULL OR locked_until IS NULL OR locked_until < %s )',
			array( $token, $until, $id, $now )
		);
		return 1 === $n ? $token : null;
	}

	/**
	 * Release lock.
	 *
	 * @param int    $id    Job id.
	 * @param string $token Token.
	 */
	public function release_lock( int $id, string $token ): void {
		$this->db->query(
			'UPDATE ' . $this->db->table( 'jobs' ) . ' SET lock_token = NULL, locked_until = NULL WHERE id = %d AND lock_token = %s',
			array( $id, $token )
		);
	}

	/**
	 * Persist checkpoint/progress (only while holding the lock).
	 *
	 * @param int        $id     Job id.
	 * @param string     $token  Lock token.
	 * @param StepResult $result Result.
	 * @param array      $meta   Existing metadata.
	 */
	private function save_step( int $id, string $token, StepResult $result, array $meta ): void {
		$this->db->query(
			'UPDATE ' . $this->db->table( 'jobs' ) . ' SET checkpoint = %s, progress = %f, current_step = %s, metadata = %s, updated_at = %s, locked_until = %s
			 WHERE id = %d AND lock_token = %s',
			array(
				wp_json_encode( $result->checkpoint ),
				max( 0.0, min( 100.0, $result->progress ) ),
				substr( $result->step, 0, 64 ),
				wp_json_encode( array_merge( $meta, $result->metadata ) ),
				$this->now(),
				gmdate( 'Y-m-d H:i:s', time() + self::LOCK_SECONDS ),
				$id,
				$token,
			)
		);
	}

	/**
	 * Run slices of a job until done or time budget exhausted.
	 * Called from REST "tick" requests (and later from cron/loopback runners).
	 *
	 * @param int $id          Job id.
	 * @param int $time_budget Seconds.
	 */
	public function run( int $id, int $time_budget ): Job {
		$job = $this->get( $id );
		if ( JobStatus::PENDING === $job->status ) {
			$job = $this->transition( $id, JobStatus::RUNNING );
		}
		if ( JobStatus::RUNNING !== $job->status ) {
			return $job;
		}
		if ( ! isset( $this->handlers[ $job->type ] ) ) {
			return $this->fail(
				$id,
				new WstmException(
					'no_handler',
					'No handler is registered for this job type.',
					array(
						'what'      => 'Job #' . $id . ' (' . $job->type . ')',
						'why'       => 'The module providing this job type is not available in this version.',
						'resumable' => true,
						'action'    => 'Update the plugin, then resume the job.',
					)
				)
			);
		}

		$token = $this->acquire_lock( $id );
		if ( null === $token ) {
			return $job; // Another request is processing it.
		}

		$handler = $this->handlers[ $job->type ];
		/**
		 * Filter the deadline for this run (e.g. to force single slices in tests).
		 *
		 * @param int $deadline Unix timestamp.
		 * @param Job $job      Job.
		 */
		$deadline = (int) apply_filters( 'wstm_job_deadline', time() + max( 3, $time_budget ), $job );
		$this->db->query( 'UPDATE ' . $this->db->table( 'jobs' ) . ' SET attempts = attempts + 1 WHERE id = %d', array( $id ) );

		try {
			// At least one slice per run, so slow hosts always make progress.
			do {
				$job = $this->get( $id );
				if ( JobStatus::RUNNING !== $job->status ) {
					break; // Paused/cancelled by user mid-run.
				}
				$result = $handler->step( $job, $deadline );
				$this->save_step( $id, $token, $result, $job->metadata );
				if ( $result->done ) {
					$this->release_lock( $id, $token );
					return $this->transition( $id, JobStatus::COMPLETED );
				}
			} while ( time() < $deadline );
		} catch ( WstmException $e ) {
			$this->release_lock( $id, $token );
			return $this->fail( $id, $e );
		} catch ( \Throwable $e ) {
			$this->release_lock( $id, $token );
			return $this->fail(
				$id,
				new WstmException(
					'unexpected',
					'Unexpected error.',
					array(
						'what'      => 'Job #' . $id . ' step "' . $job->current_step . '"',
						'why'       => $e->getMessage(),
						'resumable' => true,
						'action'    => 'Review the logs, then resume from the last checkpoint.',
					),
					$e
				)
			);
		}
		$this->release_lock( $id, $token );
		return $this->get( $id );
	}

	/**
	 * Mark failed with structured error.
	 *
	 * @param int           $id Job id.
	 * @param WstmException $e  Error.
	 */
	public function fail( int $id, WstmException $e ): Job {
		$job   = $this->get( $id );
		$error = $e->to_array();
		if ( '' === $error['completed'] ) {
			$error['completed'] = sprintf( '%.1f%% (step: %s)', $job->progress, $job->current_step );
		}
		$this->logger->error( $error['what'] . ': ' . $error['why'], $error, 'jobs', $id );
		if ( JobStatus::can( $job->status, JobStatus::FAILED ) ) {
			return $this->transition( $id, JobStatus::FAILED, $error );
		}
		return $job;
	}

	/**
	 * Mark jobs stuck in "running" without updates as failed (resumable).
	 *
	 * @param int $older_than_seconds Age.
	 */
	public function mark_stale_running_as_failed( int $older_than_seconds ): int {
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $older_than_seconds );
		$rows   = $this->db->get_results(
			'SELECT id FROM ' . $this->db->table( 'jobs' ) . ' WHERE status = %s AND updated_at < %s LIMIT 100',
			array( JobStatus::RUNNING, $cutoff )
		);
		foreach ( $rows as $r ) {
			$this->fail(
				(int) $r['id'],
				new WstmException(
					'stale',
					'Job stopped responding.',
					array(
						'what'      => 'Job #' . $r['id'],
						'why'       => 'No progress for an extended period (browser closed or request killed).',
						'resumable' => true,
						'action'    => 'Resume the job; it will continue from its last checkpoint.',
					)
				)
			);
		}
		return count( $rows );
	}

	/**
	 * Count jobs by status.
	 *
	 * @param string[] $statuses Statuses.
	 */
	public function count( array $statuses ): int {
		$statuses = array_values( array_intersect( $statuses, JobStatus::all() ) );
		if ( ! $statuses ) {
			return 0;
		}
		return (int) $this->db->get_var(
			'SELECT COUNT(*) FROM ' . $this->db->table( 'jobs' ) . ' WHERE status IN (' . implode( ',', array_fill( 0, count( $statuses ), '%s' ) ) . ')',
			$statuses
		);
	}
}
