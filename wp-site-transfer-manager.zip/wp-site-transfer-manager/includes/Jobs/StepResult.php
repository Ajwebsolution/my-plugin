<?php
/**
 * Result of a single job slice.
 *
 * @package WSTM\Jobs
 */

namespace WSTM\Jobs;

defined( 'ABSPATH' ) || exit;

/**
 * Step result.
 */
final class StepResult {

	/**
	 * @var bool
	 */
	public bool $done;

	/**
	 * @var array
	 */
	public array $checkpoint;

	/**
	 * @var float
	 */
	public float $progress;

	/**
	 * @var string
	 */
	public string $step;

	/**
	 * @var array
	 */
	public array $metadata;

	/**
	 * Constructor.
	 *
	 * @param bool   $done       Whether the job is finished.
	 * @param array  $checkpoint New checkpoint.
	 * @param float  $progress   0-100 (must reflect real work, never faked).
	 * @param string $step       Current step label.
	 * @param array  $metadata   Metadata to merge.
	 */
	public function __construct(
		bool $done,
		array $checkpoint,
		float $progress,
		string $step = '',
		array $metadata = array()
	) {
		$this->done = $done;
		$this->checkpoint = $checkpoint;
		$this->progress = $progress;
		$this->step = $step;
		$this->metadata = $metadata;
	}

	/**
	 * More work remains.
	 *
	 * @param array  $checkpoint Checkpoint.
	 * @param float  $progress   Progress.
	 * @param string $step       Step.
	 * @param array  $metadata   Metadata.
	 */
	public static function continue( array $checkpoint, float $progress, string $step = '', array $metadata = array() ): self {
		return new self( false, $checkpoint, $progress, $step, $metadata );
	}

	/**
	 * Finished.
	 *
	 * @param array $metadata Metadata.
	 */
	public static function complete( array $metadata = array() ): self {
		return new self( true, array(), 100.0, 'complete', $metadata );
	}
}
