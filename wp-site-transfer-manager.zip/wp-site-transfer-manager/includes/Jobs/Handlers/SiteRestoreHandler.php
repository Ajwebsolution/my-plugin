<?php
/**
 * Job handler: one-click full site restore / migration from a .wpmig package ("site_restore").
 *
 * Stages:
 *   validate → plan → extract → database → urls → files → switch → done
 *
 * Safety design:
 *  - Nothing on the live site changes until the package is verified and
 *    extracted, and a safety backup of the database exists.
 *  - The database is imported into temporary tables, prefix-converted and
 *    URL-replaced THERE, then switched in with one atomic RENAME at the end.
 *  - Files replaced on the live site are moved into a rollback folder.
 *  - The running plugin, wp-config.php and plugin storage are never overwritten.
 *
 * Metadata: file, confirmed, safety_backup, allow_uploads_exec, allow_unknown_disk, token_hash.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Archive\ArchiveExtractor;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DbImporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\TableScanner;
use WSTM\Files\DiskSpace;
use WSTM\Files\FileApplier;
use WSTM\Files\SiteRoots;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageInfo;
use WSTM\Package\PackageValidator;
use WSTM\URL\UrlReplaceEngine;

defined( 'ABSPATH' ) || exit;

/**
 * Full restore handler.
 */
class SiteRestoreHandler implements JobHandlerInterface {

	public const TYPE = 'site_restore';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Initial state.
	 *
	 * @param Job $job Job.
	 * @throws WstmException If not confirmed.
	 */
	private function init( Job $job ): array {
		$m = $job->metadata;
		if ( true !== ( $m['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Import was not confirmed.', array( 'action' => 'Start again and tick the confirmation box.' ) );
		}
		// A restore may apply a chain of packages (full backup + differential/incremental backups), oldest first.
		$chain = array();
		if ( ! empty( $m['chain'] ) ) {
			foreach ( (array) $m['chain'] as $f ) {
				$chain[] = self::resolve_in( $this->plugin, 'backups', (string) $f );
			}
		} else {
			$chain[] = self::resolve_in( $this->plugin, (string) ( $m['area'] ?? 'packages' ), (string) ( $m['file'] ?? '' ) );
		}
		$package = $chain[0];
		$dir     = $this->plugin->storage()->job_dir( $job->uuid );
		$uploads = wp_upload_dir( null, false );
		return array(
			'stage'      => 'validate',
			'chain'      => $chain,
			'ci'         => 0,
			'package'    => $package,
			'skip_db'    => ! empty( $m['skip_database'] ),
			'keep_users' => ! empty( $m['keep_users'] ),
			'label'      => (string) ( $m['label'] ?? '' ),
			'job_dir'    => $dir,
			'staging'    => $dir . '/staging',
			'pkg_dir'    => $dir . '/package',
			// Kept outside the tmp area so cleanup never removes it.
			'rollback'   => $this->plugin->storage()->area( 'backups' ) . '/files-replaced-' . gmdate( 'Ymd-His' ) . '-' . substr( $job->uuid, 0, 8 ),
			'safety'     => ! array_key_exists( 'safety_backup', $m ) || ! empty( $m['safety_backup'] ),
			'allow_exec' => ! empty( $m['allow_uploads_exec'] ),
			'unknown_ok' => ! empty( $m['allow_unknown_disk'] ),
			// Destination identity captured BEFORE anything changes.
			'dest'       => array(
				'home_url'    => home_url(),
				'site_url'    => site_url(),
				'content_url' => content_url(),
				'uploads_url' => $uploads['baseurl'],
				'paths'       => SiteRoots::dirs(),
			),
			'v'          => PackageValidator::init_state( $package ),
			'manifest'   => null,
			'migration'  => null,
			'x'          => null,
			'db'         => null,
			'url'        => null,
			'files'      => null,
			'suspicious' => array(),
			'warnings'   => array(),
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s  = $job->checkpoint ?: $this->init( $job );
		$dl = min( $deadline, time() + DbExportHandler::SLICE_SECONDS );

		switch ( $s['stage'] ) {
			case 'validate':
				$s['v'] = PackageValidator::step( $s['v'], $dl );
				if ( $s['v']['done'] ) {
					$s['manifest']   = $s['v']['manifest'];
					$s['suspicious'] = array_flip( $s['v']['suspicious'] );
					$s['warnings']   = $s['v']['warnings'];
					$s['v']          = array( 'done' => true, 'seal' => $s['v']['hash']['hash'] );
					$s['stage']      = 'plan';
				}
				break;

			case 'plan':
				$s = $this->plan( $s );
				break;

			case 'extract':
				$staging = $s['staging'];
				$pkg_dir = $s['pkg_dir'];
				$skip    = $s['allow_exec'] ? array() : $s['suspicious'];
				$s['x']  = ArchiveExtractor::step(
					$s['x'],
					static function ( array $h ) use ( $staging, $pkg_dir, $skip ) {
						if ( str_starts_with( $h['path'], 'files/' ) ) {
							return isset( $skip[ $h['path'] ] ) ? null : array( $staging, substr( $h['path'], 6 ) );
						}
						return array( $pkg_dir, $h['path'] );
					},
					$dl
				);
				if ( $s['x']['done'] ) {
					$s['warnings']  = array_merge( $s['warnings'], $s['x']['warnings'] );
					$s['migration'] = json_decode( (string) @file_get_contents( $s['pkg_dir'] . '/migration.json' ), true ) ?: array(); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
					$last           = $s['ci'] === count( $s['chain'] ) - 1;
					$s['stage']     = ( $last && ! $s['skip_db'] && ! empty( $s['manifest']['database'] ) ) ? 'database' : 'files';
				}
				break;

			case 'database':
				$s = $this->database( $job, $s, $dl );
				break;

			case 'urls':
				$s = $this->urls( $job, $s, $dl );
				break;

			case 'files':
				if ( null === $s['files'] ) {
					$s['files'] = FileApplier::init_state( $s['staging'], $s['rollback'], $s['job_dir'] . '/apply-' . $s['ci'] . '.idx' );
					$this->write_rollback_info( $job, $s );
				}
				$s['files'] = FileApplier::step( $s['files'], $dl, $this->plugin->storage()->root() );
				if ( $s['files']['done'] && $s['ci'] < count( $s['chain'] ) - 1 ) {
					// Next package of the chain.
					$s['applied_total']  = ( $s['applied_total'] ?? 0 ) + $s['files']['applied'];
					$s['replaced_total'] = ( $s['replaced_total'] ?? 0 ) + $s['files']['replaced'];
					foreach ( array( $s['staging'], $s['pkg_dir'] ) as $d ) {
						if ( is_dir( $d ) ) {
							$this->plugin->storage()->delete_dir( $d );
						}
					}
					++$s['ci'];
					$s['package'] = $s['chain'][ $s['ci'] ];
					$s['v']       = PackageValidator::init_state( $s['package'] );
					$s['x']       = null;
					$s['files']   = null;
					$s['stage']   = 'validate';
					break;
				}
				if ( $s['files']['done'] ) {
					$s['files']['applied']  += (int) ( $s['applied_total'] ?? 0 );
					$s['files']['replaced'] += (int) ( $s['replaced_total'] ?? 0 );
					$s['stage'] = $s['db'] ? 'switch' : 'done';
					if ( ! $s['db'] ) {
						$this->finalize( $s, false );
					}
				}
				break;

			case 'switch':
				$s = $this->switch_database( $job, $s, $dl );
				break;
		}

		$meta = array(
			'file'          => basename( $s['package'] ),
			'stage'         => $s['stage'],
			'current_file'  => $s['x']['cur']['h']['path'] ?? '',
			'current_table' => 'database' === $s['stage'] ? ( $s['db']['current'] ?? '' ) : ( 'urls' === $s['stage'] ? ( $s['url']['tables'][ $s['url']['t'] ?? 0 ]['name'] ?? '' ) : '' ),
			'files_done'    => (int) ( 'files' === $s['stage'] ? ( $s['files']['applied'] ?? 0 ) : ( $s['x']['entries'] ?? 0 ) ),
			'files_total'   => (int) ( 'files' === $s['stage'] ? ( $s['files']['total'] ?? 0 ) : ( $s['manifest']['entries'] ?? 0 ) ),
			'warnings'      => array_slice( $s['warnings'], 0, 100 ),
			'rollback_id'   => is_file( $s['rollback'] . '/rollback.json' ) ? basename( $s['rollback'] ) : null,
		);

		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->info( 'Site restored from ' . basename( $s['package'] ), array( 'source' => $s['migration']['home_url'] ?? '' ), 'migration', $job->id );
			return StepResult::complete(
				array_merge(
					$meta,
					array(
						'health'          => \WSTM\Diagnostics\HealthCheck::run( $this->plugin->db(), (string) $s['dest']['home_url'] ),
						'current_file'    => '',
						'current_table'   => '',
						'source_url'      => $s['migration']['home_url'] ?? '',
						'site_url'        => $s['dest']['home_url'],
						'files_applied'   => (int) ( $s['files']['applied'] ?? 0 ),
						'files_replaced'  => (int) ( $s['files']['replaced'] ?? 0 ),
						'database'        => (bool) $s['db'],
						'replacements'    => (int) ( $s['url']['totals']['replacements'] ?? 0 ),
						'safety_backup'   => ! empty( $s['db']['safety_file'] ) ? basename( $s['db']['safety_file'] ) : null,
						'rollback_folder' => $s['rollback'],
						'rollback_id'     => basename( $s['rollback'] ),
						'chain'           => count( $s['chain'] ),
						'login_url'       => $s['dest']['site_url'] . '/wp-login.php',
					)
				)
			);
		}

		$labels = array(
			'validate' => 'Verifying package integrity',
			'plan'     => 'Checking compatibility and disk space',
			'extract'  => 'Extracting ' . $meta['current_file'],
			'database' => 'Importing database ' . $meta['current_table'],
			'urls'     => 'Updating URLs ' . $meta['current_table'],
			'files'    => 'Restoring files',
			'switch'   => 'Switching to the restored database',
		);
		$progress = array(
			'validate' => isset( $s['v']['stage'] ) ? 0.1 * PackageValidator::progress( $s['v'] ) : 10,
			'plan'     => 10,
			'extract'  => 11 + 24 * ( (int) ( $s['x']['offset'] ?? 0 ) / max( 1, (int) @filesize( $s['package'] ) ) ), // phpcs:ignore WordPress.PHP.NoSilencedErrors
			'database' => 35 + 0.3 * ( $s['db'] ? DbImporter::progress( $s['db'] ) : 0 ),
			'urls'     => 65 + 0.15 * ( $s['url'] ? UrlReplaceEngine::progress( $s['url'] ) : 0 ),
			'files'    => 80 + 17 * ( ( $s['files']['applied'] ?? 0 ) / max( 1, (int) ( $s['files']['total'] ?? 1 ) ) ),
			'switch'   => 98,
		);
		return StepResult::continue( $s, round( (float) ( $progress[ $s['stage'] ] ?? 0 ), 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Resolve a .wpmig file in the packages or backups area.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $area   packages|backups.
	 * @param string $file   Basename.
	 * @throws WstmException If invalid.
	 */
	public static function resolve_in( Plugin $plugin, string $area, string $file ): string {
		if ( 'packages' === $area ) {
			return PackageImportHandler::resolve( $plugin, $file );
		}
		if ( 'backups' !== $area || ! preg_match( '/^[A-Za-z0-9._-]+\.wpmig$/', $file ) ) {
			throw new WstmException( 'bad_source', 'Invalid backup file.' );
		}
		$path = $plugin->storage()->path( 'backups', $file );
		if ( ! is_file( $path ) || is_link( $path ) ) {
			throw new WstmException( 'source_missing', 'The backup file does not exist.', array( 'why' => $file ) );
		}
		return $path;
	}

	/**
	 * Write/refresh rollback metadata so "Undo import" knows how to revert.
	 *
	 * @param Job   $job      Job.
	 * @param array $s        State.
	 * @param array $previous Live tables replaced by the switch (after switching).
	 */
	private function write_rollback_info( Job $job, array $s, array $previous = array() ): void {
		if ( ! is_dir( $s['rollback'] ) ) {
			wp_mkdir_p( $s['rollback'] );
			$this->plugin->storage()->protect( $s['rollback'] );
		}
		$file = $s['rollback'] . '/rollback.json';
		$old  = is_file( $file ) ? ( json_decode( (string) file_get_contents( $file ), true ) ?: array() ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$info = array_merge(
			$old,
			array(
				'job_id'        => $job->id,
				'created_at'    => $old['created_at'] ?? gmdate( 'c' ),
				'source'        => $s['migration']['home_url'] ?? '',
				'package'       => basename( $s['package'] ),
				'label'         => $s['label'] ?? '',
				'safety_backup' => $s['db']['safety_file'] ?? null,
				'prefix'        => $this->plugin->db()->base_prefix(),
			)
		);
		if ( $previous ) {
			$info['previous_tables'] = $previous;
			$info['imported_tables'] = array_keys( (array) ( $s['db']['tables'] ?? array() ) );
			$info['switched_at']     = gmdate( 'c' );
		}
		file_put_contents( $file, wp_json_encode( $info, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Compatibility and disk checks; nothing is modified.
	 *
	 * @param array $s State.
	 * @throws WstmException When the restore is unsafe.
	 */
	private function plan( array $s ): array {
		$m  = $s['manifest'];
		$db = $m['database'] ?? null;
		// "requires.php" records the plugin's own minimum when the package was built, not anything about the
		// site content, so it never asks for more than this plugin version needs (older packages said 8.1).
		$need = (string) ( $m['requires']['php'] ?? WSTM_MIN_PHP );
		if ( version_compare( $need, WSTM_MIN_PHP, '>' ) ) {
			$need = WSTM_MIN_PHP;
		}
		if ( version_compare( PHP_VERSION, $need, '<' ) ) {
			throw new WstmException( 'php_too_old', 'This server\'s PHP version is too old for the package.', array( 'why' => 'Requires PHP ' . $need ) );
		}
		if ( $db && is_multisite() ) {
			throw new WstmException( 'multisite_restore', 'One-click restore of a database into a multisite network is not supported yet.', array( 'action' => 'Use Advanced import on a single site, or wait for multisite support.' ) );
		}
		$this->plugin->diagnostics()->assert_ready( array( 'php_version', 'db_connection', 'temp_writable', 'ext_hash', 'ext_json' ), 'Import' );
		$parts = array( 'Extracted package' => (int) ( $m['file_bytes'] ?? 0 ) + (int) ( $db['size'] ?? 0 ) );
		if ( $db ) {
			$parts['Database work files'] = (int) ( $db['size'] ?? 0 ) * 8;
			if ( $s['safety'] ) {
				$parts['Safety backup'] = DbExportHandler::estimate( new TableScanner( $this->plugin->db() ), array(), true );
			}
		}
		$parts['Replaced files (rollback copies)'] = (int) ( $m['file_bytes'] ?? 0 );
		DiskSpace::require( $this->plugin->storage(), $parts, $s['unknown_ok'] );
		$s['x']     = ArchiveExtractor::init_state( $s['package'] );
		$s['stage'] = 'extract';
		return $s;
	}

	/**
	 * Commit callback writing the full job checkpoint with a sub-state.
	 *
	 * @param Job    $job Job.
	 * @param array  $s   State.
	 * @param string $key Sub-state key.
	 */
	private function committer( Job $job, array $s, string $key ): callable {
		$db  = $this->plugin->db();
		$tbl = $db->table( 'jobs' );
		return static function ( array $sub ) use ( $db, $tbl, $job, $s, $key ) {
			$s[ $key ] = $sub;
			$db->query( "UPDATE {$tbl} SET checkpoint = %s, updated_at = %s WHERE id = %d", array( wp_json_encode( $s ), gmdate( 'Y-m-d H:i:s' ), $job->id ) );
		};
	}

	/**
	 * Database into temporary tables (prefix-converted), not yet switched.
	 *
	 * @param Job   $job Job.
	 * @param array $s   State.
	 * @param int   $dl  Deadline.
	 */
	private function database( Job $job, array $s, int $dl ): array {
		$db       = $this->plugin->db();
		$importer = new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id );
		if ( null === $s['db'] ) {
			$file    = (string) $s['manifest']['database']['file'];
			$source  = $s['pkg_dir'] . '/' . $file;
			$storage = $this->plugin->storage();
			if ( ! is_file( DumpManifest::path_for( $source ) ) ) {
				copy( $s['pkg_dir'] . '/database.manifest.json', DumpManifest::path_for( $source ) );
			}
			$s['db'] = DbImporter::init_state(
				array(
					'source'              => $source,
					'manifest'            => DumpManifest::path_for( $source ),
					'work_dir'            => $s['job_dir'] . '/dbwork',
					'safety_file'         => $s['safety'] ? $storage->area( 'backups' ) . '/' . $storage->random_filename( 'before-import', function_exists( 'gzopen' ) ? 'sql.gz' : 'sql' ) : null,
					'batch_rows'          => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
					'allow_prefix_change' => true,
					'defer_swap'          => true,
					'skip_tables'         => $s['keep_users'] ? array( $db->base_prefix() . 'users', $db->base_prefix() . 'usermeta' ) : array(),
				)
			);
		}
		$safety  = ( new DbImportHandler( $this->plugin ) )->safety_runner( $job, (string) $s['db']['safety_file'], (int) $s['db']['batch_rows'] );
		$s['db'] = $importer->slice( $s['db'], $dl, $this->committer( $job, $s, 'db' ), $safety );
		if ( 'ready' === $s['db']['stage'] ) {
			$s['warnings'] = array_merge( $s['warnings'], $s['db']['warnings'] );
			$s['stage']    = 'urls';
		}
		return $s;
	}

	/**
	 * Old → new URL and path pairs.
	 *
	 * @param array $s State.
	 */
	public static function url_pairs( array $s ): array {
		$src   = $s['migration'] ?? array();
		$dst   = $s['dest'];
		$pairs = array();
		$add   = static function ( $old, $new ) use ( &$pairs ) {
			$old = untrailingslashit( (string) $old );
			$new = untrailingslashit( (string) $new );
			if ( strlen( $old ) >= 4 && $old !== $new && ! isset( $pairs[ $old ] ) ) {
				$pairs[ $old ] = $new;
			}
		};
		foreach ( array( 'uploads_url', 'content_url', 'site_url', 'home_url' ) as $k ) {
			if ( empty( $src[ $k ] ) ) {
				continue;
			}
			$add( $src[ $k ], $dst[ $k ] );
			// The other protocol of the old URL (sites often contain both).
			if ( preg_match( '#^(https?)://(.+)$#i', (string) $src[ $k ], $mm ) ) {
				$add( ( 'http' === strtolower( $mm[1] ) ? 'https' : 'http' ) . '://' . $mm[2], $dst[ $k ] );
			}
		}
		// Protocol-relative and bare-host references when the host changes.
		$oh = wp_parse_url( (string) ( $src['home_url'] ?? '' ) );
		$nh = wp_parse_url( (string) $dst['home_url'] );
		if ( ! empty( $oh['host'] ) && ! empty( $nh['host'] ) && $oh['host'] !== $nh['host'] ) {
			$add( '//' . $oh['host'] . ( isset( $oh['port'] ) ? ':' . $oh['port'] : '' ) . ( $oh['path'] ?? '' ), '//' . $nh['host'] . ( isset( $nh['port'] ) ? ':' . $nh['port'] : '' ) . ( $nh['path'] ?? '' ) );
		}
		// Server paths (serialized in some plugin settings).
		foreach ( array( 'uploads', 'content', 'abspath' ) as $k ) {
			if ( ! empty( $src['paths'][ $k ] ) && ! empty( $dst['paths'][ $k ] ) ) {
				$add( $src['paths'][ $k ], $dst['paths'][ $k ] );
			}
		}
		$out = array();
		foreach ( $pairs as $o => $n ) {
			$out[] = array( $o, $n );
		}
		return $out;
	}

	/**
	 * URL replacement on the temporary tables.
	 *
	 * @param Job   $job Job.
	 * @param array $s   State.
	 * @param int   $dl  Deadline.
	 */
	private function urls( Job $job, array $s, int $dl ): array {
		$pairs = self::url_pairs( $s );
		if ( ! $pairs ) {
			$s['stage'] = 'files';
			return $s;
		}
		$db = $this->plugin->db();
		if ( null === $s['url'] ) {
			$tmp      = array_map( static fn( $t ) => DbImporter::TMP_PREFIX . $t, array_keys( $s['db']['tables'] ) );
			$s['url'] = UrlReplaceEngine::init_state(
				array(
					'mode'            => 'replace',
					'pairs'           => $pairs,
					'tables'          => $tmp,
					'explicit_tables' => true,
					'guid_tables'     => array( DbImporter::TMP_PREFIX . $db->base_prefix() . 'posts' ),
					'skip_guid'       => false, // A moved site's GUIDs point at the old domain; AIO-style migrations rewrite them.
					'url_encoded'     => true,
				)
			);
		}
		$engine   = new UrlReplaceEngine( $db, new TableScanner( $db ) );
		$s['url'] = $engine->slice( $s['url'], $dl, $this->committer( $job, $s, 'url' ) );
		if ( in_array( $s['url']['stage'], array( 'verify', 'done' ), true ) ) {
			$s['warnings'] = array_merge( $s['warnings'], array_slice( $s['url']['warnings'], 0, 20 ) );
			$s['stage']    = 'files';
		}
		return $s;
	}

	/**
	 * Atomically switch to the restored database and finalise.
	 *
	 * @param Job   $job Job.
	 * @param array $s   State.
	 * @param int   $dl  Deadline.
	 */
	private function switch_database( Job $job, array $s, int $dl ): array {
		$db       = $this->plugin->db();
		$importer = new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id );
		if ( in_array( $s['db']['stage'], array( 'ready', 'swap' ), true ) ) {
			$s['db']['stage'] = 'swap';
			$s['db']          = $importer->slice( $s['db'], $dl, static fn() => null, static fn( $x ) => $x );
		}
		if ( in_array( $s['db']['stage'], array( 'cleanup', 'done' ), true ) ) {
			$this->write_rollback_info( $job, $s, $s['db']['previous'] ?: array( '_none_' ) );
			$this->finalize( $s, true );
			$s['stage'] = 'done';
		}
		return $s;
	}

	/**
	 * Post-restore fixes.
	 *
	 * @param array $s  State.
	 * @param bool  $db Whether the database was replaced.
	 */
	private function finalize( array $s, bool $db ): void {
		if ( $db ) {
			wp_cache_flush();
			// Keep this site's address even if the package hard-coded the old one somewhere we skipped.
			update_option( 'home', $s['dest']['home_url'] );
			update_option( 'siteurl', $s['dest']['site_url'] );
			delete_option( 'rewrite_rules' );
		}
		$storage = $this->plugin->storage();
		foreach ( array( $s['staging'], $s['pkg_dir'], $s['job_dir'] . '/dbwork' ) as $d ) {
			if ( is_dir( $d ) ) {
				$storage->delete_dir( $d );
			}
		}
		wp_cache_flush();
		// Ecosystem clean-up: caches, Elementor CSS, WooCommerce transients, permalinks.
		\WSTM\Compatibility\PostMigration::run_all( $this->plugin->logger() );
		$this->plugin->diagnostics()->flush();
	}

	/**
	 * Cancel: drop temp tables, remove staging. Files already applied stay (rollback copies remain in the job folder).
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$s  = $job->checkpoint;
		$db = $this->plugin->db();
		( new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id ) )->drop_temp_tables();
		$storage = $this->plugin->storage();
		foreach ( array( 'staging', 'pkg_dir' ) as $k ) {
			if ( ! empty( $s[ $k ] ) && is_dir( $s[ $k ] ) ) {
				$storage->delete_dir( $s[ $k ] );
			}
		}
		if ( ! empty( $s['files']['applied'] ) ) {
			$this->plugin->logger()->warning( 'Restore cancelled after files were applied; replaced files are in ' . $s['rollback'], array(), 'migration', $job->id );
		}
	}
}
