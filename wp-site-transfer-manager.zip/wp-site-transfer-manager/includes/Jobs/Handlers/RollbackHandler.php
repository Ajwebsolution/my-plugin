<?php
/**
 * Job handler: undo an import ("rollback").
 *
 * Uses the rollback point written by a restore (files-replaced-* folder):
 *  1. Files the import created are removed.
 *  2. Files the import replaced are moved back.
 *  3. The database is switched back to the tables kept as rollback copies
 *     (wstmo_*) with one atomic RENAME; if those copies are gone, the
 *     pre-import safety backup is imported instead.
 *
 * Metadata: point (folder name), token_hash.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DbImporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\SqlEscaper;
use WSTM\Database\TableScanner;
use WSTM\Files\FileApplier;
use WSTM\Files\FileScanner;
use WSTM\Files\SiteRoots;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Rollback handler.
 */
class RollbackHandler implements JobHandlerInterface {

	public const TYPE = 'rollback';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Resolve a rollback point folder.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $point  Folder name.
	 * @throws WstmException If invalid.
	 */
	public static function resolve( Plugin $plugin, string $point ): array {
		if ( ! preg_match( '/^files-replaced-[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$/', $point ) ) {
			throw new WstmException( 'bad_point', 'Invalid rollback point.' );
		}
		$dir  = $plugin->storage()->area( 'backups' ) . '/' . $point;
		$info = is_file( $dir . '/rollback.json' ) ? json_decode( (string) file_get_contents( $dir . '/rollback.json' ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $info ) ) {
			throw new WstmException( 'point_missing', 'Rollback information not found.', array( 'why' => $point ) );
		}
		if ( ! empty( $info['undone_at'] ) ) {
			throw new WstmException( 'already_undone', 'This import has already been undone.' );
		}
		return array( $dir, $info );
	}

	/**
	 * Initial state.
	 *
	 * @param Job $job Job.
	 */
	private function init( Job $job ): array {
		[ $dir, $info ] = self::resolve( $this->plugin, (string) ( $job->metadata['point'] ?? '' ) );
		$roots          = array();
		foreach ( SiteRoots::KEYS as $k ) {
			if ( is_dir( $dir . '/' . $k ) ) {
				$roots[ $k ] = $dir . '/' . $k;
			}
		}
		$work = $this->plugin->storage()->job_dir( $job->uuid );
		return array(
			'stage'    => 'created',
			'dir'      => $dir,
			'info'     => $info,
			'c_offset' => 0,
			'scan'     => FileScanner::init_state( $roots, array( '*.wstmprev-*' ), $work . '/rollback.idx' ),
			'offset'   => 0,
			'restored' => 0,
			'removed'  => 0,
			'db'       => null,
			'work'     => $work,
			'warnings' => array(),
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s    = $job->checkpoint ?: $this->init( $job );
		$dl   = min( $deadline, time() + DbExportHandler::SLICE_SECONDS );
		$live = SiteRoots::dirs();
		$prot = FileApplier::protected_paths();

		switch ( $s['stage'] ) {
			case 'created':
				$list = $s['dir'] . '/created.lst';
				if ( is_file( $list ) ) {
					$fh = fopen( $list, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					fseek( $fh, $s['c_offset'] );
					while ( false !== ( $line = fgets( $fh ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
						$s['c_offset'] = ftell( $fh );
						[ $root, $rel ] = array_pad( explode( '/', rtrim( $line, "\n" ), 2 ), 2, '' );
						if ( isset( $live[ $root ] ) && '' !== $rel ) {
							try {
								$path = PathGuard::resolve_within( $live[ $root ], $rel );
								if ( is_file( $path ) && ! self::is_protected( $prot, $root, $rel ) ) {
									wp_delete_file( $path );
									++$s['removed'];
								}
							} catch ( WstmException $e ) {
								$s['warnings'][] = 'Skipped ' . $root . '/' . $rel . ': ' . $e->getMessage();
							}
						}
						if ( time() >= $dl ) {
							break;
						}
					}
					$eof = feof( $fh );
					fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( ! $eof ) {
						break;
					}
				}
				$s['stage'] = 'files';
				break;

			case 'files':
				if ( ! $s['scan']['done'] ) {
					$s['scan'] = FileScanner::step( $s['scan'], $dl );
					break;
				}
				$gen   = FileScanner::read_index( $s['scan']['index'], (int) $s['offset'] );
				$first = true;
				while ( $gen->valid() && ( $first || time() < $dl ) ) {
					$first = false;
					$e     = $gen->current();
					$s['offset'] = $gen->key();
					$gen->next();
					if ( 'f' !== $e['t'] || self::is_protected( $prot, $e['r'], $e['p'] ) ) {
						continue;
					}
					$src  = $s['dir'] . '/' . $e['r'] . '/' . $e['p'];
					$dest = PathGuard::resolve_within( $live[ $e['r'] ], $e['p'] );
					if ( ! is_dir( dirname( $dest ) ) ) {
						wp_mkdir_p( dirname( $dest ) );
					}
					if ( is_file( $dest ) ) {
						wp_delete_file( $dest );
					}
					if ( ! @rename( $src, $dest ) && ! ( @copy( $src, $dest ) && @unlink( $src ) ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
						throw new WstmException( 'rollback_failed', 'Could not restore a file.', array( 'why' => $e['r'] . '/' . $e['p'], 'resumable' => true, 'action' => 'Check permissions, then resume.' ) );
					}
					++$s['restored'];
				}
				if ( ! $gen->valid() ) {
					$s['stage'] = ! empty( $s['info']['previous_tables'] ) ? 'database' : 'finish';
				}
				break;

			case 'database':
				$s = $this->database( $job, $s, $dl );
				break;

			case 'finish':
				$info              = $s['info'];
				$info['undone_at'] = gmdate( 'c' );
				file_put_contents( $s['dir'] . '/rollback.json', wp_json_encode( $info, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				$this->plugin->storage()->delete_dir( $s['work'] );
				delete_option( 'rewrite_rules' );
				wp_cache_flush();
				$s['stage'] = 'done';
				break;
		}

		$meta = array( 'stage' => $s['stage'], 'files_done' => $s['restored'], 'removed' => $s['removed'], 'warnings' => array_slice( $s['warnings'], 0, 50 ) );
		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->warning( 'Import undone: ' . basename( $s['dir'] ), array(), 'rollback', $job->id );
			\WSTM\Compatibility\PostMigration::run_all( $this->plugin->logger() );
			return StepResult::complete( array_merge( $meta, array( 'login_url' => site_url( 'wp-login.php' ), 'database' => ! empty( $s['info']['previous_tables'] ) ) ) );
		}
		$labels = array( 'created' => 'Removing files added by the import', 'files' => 'Restoring replaced files', 'database' => 'Restoring the previous database', 'finish' => 'Finishing' );
		$pct    = array( 'created' => 5, 'files' => 10 + 50 * ( $s['offset'] / max( 1, (int) @filesize( $s['scan']['index'] ) ) ), 'database' => 70, 'finish' => 99 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return StepResult::continue( $s, round( (float) $pct[ $s['stage'] ], 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Protected path check.
	 *
	 * @param array  $prot Protected map.
	 * @param string $root Root.
	 * @param string $rel  Relative.
	 */
	private static function is_protected( array $prot, string $root, string $rel ): bool {
		foreach ( $prot[ $root ] ?? array() as $p ) {
			if ( $rel === $p || str_starts_with( $rel, $p . '/' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Switch the database back (rollback copies) or re-import the safety backup.
	 *
	 * @param Job   $job Job.
	 * @param array $s   State.
	 * @param int   $dl  Deadline.
	 * @throws WstmException If neither is possible.
	 */
	private function database( Job $job, array $s, int $dl ): array {
		$db       = $this->plugin->db();
		$prev     = array_values( array_diff( (array) $s['info']['previous_tables'], array( '_none_' ) ) );
		$imported = (array) ( $s['info']['imported_tables'] ?? array() );
		$existing = array_flip( $db->list_tables() );

		if ( null === $s['db'] ) {
			$have_copies = (bool) $prev;
			foreach ( $prev as $t ) {
				if ( ! isset( $existing[ DbImporter::OLD_PREFIX . $t ] ) ) {
					$have_copies = false;
				}
			}
			if ( $have_copies ) {
				$preserved = array();
				foreach ( DbImporter::PRESERVED_OPTIONS as $opt ) {
					$preserved[ $opt ] = get_site_option( $opt, null );
				}
				$pairs = array();
				$drop  = array();
				foreach ( array_unique( array_merge( $prev, $imported ) ) as $t ) {
					if ( isset( $existing[ $t ] ) ) {
						$db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( DbImporter::TMP_PREFIX . $t ) );
						$pairs[] = SqlEscaper::identifier( $t ) . ' TO ' . SqlEscaper::identifier( DbImporter::TMP_PREFIX . $t );
						$drop[]  = DbImporter::TMP_PREFIX . $t;
					}
					if ( in_array( $t, $prev, true ) ) {
						$pairs[] = SqlEscaper::identifier( DbImporter::OLD_PREFIX . $t ) . ' TO ' . SqlEscaper::identifier( $t );
					}
				}
				$db->raw_query( 'RENAME TABLE ' . implode( ', ', $pairs ) );
				foreach ( $drop as $t ) {
					$db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( $t ) );
				}
				wp_cache_flush();
				foreach ( $preserved as $opt => $val ) {
					null === $val ? delete_site_option( $opt ) : update_site_option( $opt, $val );
				}
				$active = (array) get_option( 'active_plugins', array() );
				if ( defined( 'WSTM_BASENAME' ) && ! in_array( WSTM_BASENAME, $active, true ) ) {
					$active[] = WSTM_BASENAME;
					update_option( 'active_plugins', $active );
				}
				$s['stage'] = 'finish';
				return $s;
			}
			$safety = (string) ( $s['info']['safety_backup'] ?? '' );
			if ( '' === $safety || ! is_file( $safety ) ) {
				throw new WstmException( 'rollback_db_unavailable', 'The previous database cannot be restored automatically.', array( 'why' => 'Rollback table copies were removed and no safety backup exists.', 'action' => 'Files were restored. Restore a database backup from the Backups page.' ) );
			}
			if ( ! is_file( DumpManifest::path_for( $safety ) ) ) {
				throw new WstmException( 'rollback_db_unavailable', 'The safety backup manifest is missing.' );
			}
			$s['db'] = DbImporter::init_state(
				array(
					'source'     => $safety,
					'manifest'   => DumpManifest::path_for( $safety ),
					'work_dir'   => $s['work'] . '/db',
					'batch_rows' => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
				)
			);
		}
		$tbl     = $db->table( 'jobs' );
		$commit  = static function ( array $sub ) use ( $db, $tbl, $job, $s ) {
			$s['db'] = $sub;
			$db->query( "UPDATE {$tbl} SET checkpoint = %s WHERE id = %d", array( wp_json_encode( $s ), $job->id ) );
		};
		$s['db'] = ( new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id ) )->slice( $s['db'], $dl, $commit, static fn( $x ) => $x );
		if ( 'done' === $s['db']['stage'] ) {
			$s['stage'] = 'finish';
		}
		return $s;
	}

	/**
	 * Cancel.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		( new DbImporter( $this->plugin->db(), new TableScanner( $this->plugin->db() ), $this->plugin->logger(), $job->id ) )->drop_temp_tables();
	}
}
