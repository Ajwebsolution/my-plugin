<?php
/**
 * Job handlers: validate ("package_validate") and import ("package_import") a .wpmig package.
 *
 * Import stages: validate → disk → extract → database → done
 *  - Files are extracted into a protected staging area (never over the live
 *    site); applying staged files is part of full migration (Phase 6).
 *  - The database (if selected) is imported with the safe temp-table + atomic
 *    swap importer, including a safety backup.
 *
 * Metadata: file (basename in packages area), confirmed, import_database, safety_backup,
 *           allow_uploads_exec, allow_unknown_disk.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Archive\ArchiveExtractor;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DbImporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\TableScanner;
use WSTM\Files\DiskSpace;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageBuilder;
use WSTM\Package\PackageInfo;
use WSTM\Package\PackageValidator;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Package validate/import handler.
 */
class PackageImportHandler implements JobHandlerInterface {

	public const TYPE_VALIDATE = 'package_validate';
	public const TYPE_IMPORT   = 'package_import';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * @var string
	 */
	private string $type;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $type   Job type served.
	 */
	public function __construct( Plugin $plugin, string $type ) {
		$this->plugin = $plugin;
		$this->type = $type;
	}

	/** Type. */
	public function type(): string {
		return $this->type;
	}

	/**
	 * Resolve a package file in the packages area.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $file   Basename.
	 * @throws WstmException If invalid.
	 */
	public static function resolve( Plugin $plugin, string $file ): string {
		if ( ! preg_match( '/^[A-Za-z0-9._-]+\.' . PackageBuilder::EXT . '$/', $file ) ) {
			throw new WstmException( 'bad_source', 'Invalid package name.', array( 'why' => 'Only .wpmig files inside plugin storage can be used.' ) );
		}
		$path = $plugin->storage()->path( 'packages', $file );
		if ( ! is_file( $path ) || is_link( $path ) ) {
			throw new WstmException( 'source_missing', 'The package does not exist.', array( 'why' => $file ) );
		}
		return $path;
	}

	/**
	 * Initial state.
	 *
	 * @param Job $job Job.
	 * @throws WstmException If not confirmed.
	 */
	private function init( Job $job ): array {
		$m       = $job->metadata;
		$package = SiteRestoreHandler::resolve_in( $this->plugin, (string) ( $m['area'] ?? 'packages' ), (string) ( $m['file'] ?? '' ) );
		$import  = self::TYPE_IMPORT === $this->type;
		if ( $import && true !== ( $m['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Import was not confirmed.', array( 'action' => 'Start again and tick the confirmation box.' ) );
		}
		$dir = $import ? $this->plugin->storage()->job_dir( $job->uuid ) : '';
		return array(
			'stage'       => 'validate',
			'package'     => $package,
			'import'      => $import,
			'job_dir'     => $dir,
			'staging'     => $dir ? $dir . '/staging' : '',
			'pkg_dir'     => $dir ? $dir . '/package' : '',
			'import_db'   => ! empty( $m['import_database'] ),
			'safety'      => ! array_key_exists( 'safety_backup', $m ) || ! empty( $m['safety_backup'] ),
			'allow_exec'  => ! empty( $m['allow_uploads_exec'] ),
			'unknown_ok'  => ! empty( $m['allow_unknown_disk'] ),
			'v'           => PackageValidator::init_state( $package ),
			'x'           => null,
			'db'          => null,
			'manifest'    => null,
			'warnings'    => array(),
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s  = $job->checkpoint ?: $this->init( $job );
		$dl = min( $deadline, time() + DbExportHandler::SLICE_SECONDS );

		switch ( $s['stage'] ) {
			case 'validate':
				$bid = (int) ( $job->metadata['backup_id'] ?? 0 );
				try {
					$s['v'] = PackageValidator::step( $s['v'], $dl );
				} catch ( WstmException $e ) {
					if ( $bid ) {
						( new \WSTM\Backup\BackupManager( $this->plugin ) )->set_verified( $bid, false );
					}
					throw $e;
				}
				if ( $s['v']['done'] && $bid ) {
					( new \WSTM\Backup\BackupManager( $this->plugin ) )->set_verified( $bid, true );
				}
				if ( $s['v']['done'] ) {
					$s['manifest'] = $s['v']['manifest'];
					$s['warnings'] = $s['v']['warnings'];
					PackageInfo::write(
						$s['package'],
						array(
							'format'     => PackageBuilder::FORMAT,
							'version'    => (int) $s['manifest']['version'],
							'created_at' => $s['manifest']['created_at'] ?? '',
							'source'     => $s['manifest']['source'] ?? '',
							'components' => $s['manifest']['components'] ?? array(),
							'files'      => (int) $s['manifest']['files'],
							'entries'    => (int) $s['manifest']['entries'],
							'database'   => ! empty( $s['manifest']['database'] ),
							'prefix'     => $s['manifest']['database']['prefix'] ?? '',
							'seal'       => $s['v']['hash']['hash'],
							'validated'  => true,
							'suspicious' => count( $s['v']['suspicious'] ),
						)
					);
					$s['suspicious'] = array_flip( $s['v']['suspicious'] );
					$s['v']          = array( 'done' => true );
					$s['stage']      = $s['import'] ? 'disk' : 'done';
				}
				break;

			case 'disk':
				$db = $s['manifest']['database'] ?? null;
				if ( $s['import_db'] ) {
					if ( ! $db ) {
						throw new WstmException( 'no_database', 'This package does not contain a database.', array( 'action' => 'Import again without the database option.' ) );
					}
					if ( (string) $db['prefix'] !== $this->plugin->db()->base_prefix() ) {
						throw new WstmException( 'prefix_mismatch', 'The package database uses a different table prefix.', array( 'why' => sprintf( '"%s" vs "%s"', $db['prefix'], $this->plugin->db()->base_prefix() ), 'action' => 'Prefix conversion arrives with full migration (Phase 6). Nothing was changed.' ) );
					}
				}
				$parts = array( 'Extracted files' => (int) ( $s['manifest']['file_bytes'] ?? 0 ) + (int) ( $db['size'] ?? 0 ) );
				if ( $s['import_db'] ) {
					$parts['Database work files'] = (int) ( $db['size'] ?? 0 ) * 8;
					if ( $s['safety'] ) {
						$parts['Safety backup'] = DbExportHandler::estimate( new TableScanner( $this->plugin->db() ), array(), true );
					}
				}
				DiskSpace::require( $this->plugin->storage(), $parts, $s['unknown_ok'] );
				$s['x']     = ArchiveExtractor::init_state( $s['package'] );
				$s['stage'] = 'extract';
				break;

			case 'extract':
				$staging = $s['staging'];
				$pkg_dir = $s['pkg_dir'];
				$skip    = $s['allow_exec'] ? array() : $s['suspicious'];
				$s['x']  = ArchiveExtractor::step(
					$s['x'],
					static function ( array $h ) use ( $staging, $pkg_dir, $skip ) {
						if ( str_starts_with( $h['path'], 'files/' ) ) {
							if ( isset( $skip[ $h['path'] ] ) ) {
								return null;
							}
							return array( $staging, substr( $h['path'], 6 ) );
						}
						return array( $pkg_dir, $h['path'] );
					},
					$dl
				);
				if ( $s['x']['done'] ) {
					$s['warnings'] = array_merge( $s['warnings'], $s['x']['warnings'] );
					if ( $s['suspicious'] && ! $s['allow_exec'] ) {
						$s['warnings'][] = count( $s['suspicious'] ) . ' executable file(s) in uploads were not extracted.';
					}
					$s['stage'] = $s['import_db'] ? 'database' : 'done';
				}
				break;

			case 'database':
				$s = $this->import_database( $job, $s, $dl );
				break;
		}

		$meta = array(
			'file'         => basename( $s['package'] ),
			'stage'        => $s['stage'],
			'files_done'   => (int) ( $s['x']['entries'] ?? 0 ),
			'files_total'  => (int) ( $s['manifest']['entries'] ?? 0 ),
			'bytes'        => (int) ( $s['x']['bytes'] ?? ( $s['v']['hash']['offset'] ?? 0 ) ),
			'current_file' => $s['x']['cur']['h']['path'] ?? '',
			'current_table'=> $s['db']['current'] ?? '',
			'warnings'     => array_slice( $s['warnings'], 0, 100 ),
		);

		if ( 'done' === $s['stage'] ) {
			$extra = array( 'current_file' => '', 'current_table' => '', 'validated' => true, 'seal' => PackageInfo::read( $s['package'] )['seal'] ?? '' );
			if ( $s['import'] ) {
				$extra['staging']         = $s['staging'];
				$extra['staged_files']    = (int) ( $s['x']['entries'] ?? 0 );
				$extra['database_import'] = $s['import_db'];
				$extra['safety_backup']   = $s['db']['safety_file'] ?? null ? basename( $s['db']['safety_file'] ) : null;
				$extra['previous_tables'] = $s['db']['previous'] ?? array();
			}
			$this->plugin->logger()->info( ( $s['import'] ? 'Package imported: ' : 'Package validated: ' ) . basename( $s['package'] ), array(), 'package', $job->id );
			return StepResult::complete( array_merge( $meta, $extra ) );
		}

		switch ( $s['stage'] ) {
			case 'validate':
				$progress = ( $s['import'] ? 0.2 : 1 ) * PackageValidator::progress( $s['v'] );
				break;
			case 'disk':
				$progress = 20;
				break;
			case 'extract':
				$progress = 20 + ( $s['import_db'] ? 30 : 79 ) * ( (int) ( $s['x']['offset'] ?? 0 ) / max( 1, (int) filesize( $s['package'] ) ) );
				break;
			case 'database':
				$progress = 50 + ( $s['db'] ? 0.49 * DbImporter::progress( $s['db'] ) : 0 );
				break;
			default:
				$progress = 0;
		}
		$labels = array(
			'validate' => 'Verifying package integrity',
			'disk'     => 'Checking disk space',
			'extract'  => 'Extracting ' . $meta['current_file'],
			'database' => 'Importing database ' . $meta['current_table'],
		);
		return StepResult::continue( $s, round( $progress, 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Database stage (embedded safe importer).
	 *
	 * @param Job   $job Job.
	 * @param array $s   State.
	 * @param int   $dl  Deadline.
	 */
	private function import_database( Job $job, array $s, int $dl ): array {
		$db       = $this->plugin->db();
		$importer = new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id );
		if ( null === $s['db'] ) {
			$file    = $s['manifest']['database']['file'];
			$storage = $this->plugin->storage();
			$gz      = function_exists( 'gzopen' );
			$s['db'] = DbImporter::init_state(
				array(
					'source'      => $s['pkg_dir'] . '/' . $file,
					'manifest'    => $s['pkg_dir'] . '/database.manifest.json',
					'work_dir'    => $s['job_dir'] . '/dbwork',
					'safety_file' => $s['safety'] ? $storage->area( 'backups' ) . '/' . $storage->random_filename( 'safety-database', $gz ? 'sql.gz' : 'sql' ) : null,
					'batch_rows'  => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
				)
			);
			// DbImporter expects a manifest beside the dump.
			if ( ! is_file( DumpManifest::path_for( $s['db']['source'] ) ) ) {
				copy( $s['pkg_dir'] . '/database.manifest.json', DumpManifest::path_for( $s['db']['source'] ) );
			}
			$s['db']['manifest'] = DumpManifest::path_for( $s['db']['source'] );
		}
		$jobs_tbl = $db->table( 'jobs' );
		$commit   = static function ( array $sub ) use ( $db, $jobs_tbl, $job, $s ) {
			$s['db'] = $sub;
			$db->query( "UPDATE {$jobs_tbl} SET checkpoint = %s, updated_at = %s WHERE id = %d", array( wp_json_encode( $s ), gmdate( 'Y-m-d H:i:s' ), $job->id ) );
		};
		$safety  = ( new DbImportHandler( $this->plugin ) )->safety_runner( $job, (string) $s['db']['safety_file'], (int) $s['db']['batch_rows'] );
		$s['db'] = $importer->slice( $s['db'], $dl, $commit, $safety );
		if ( 'done' === $s['db']['stage'] ) {
			$s['warnings'] = array_merge( $s['warnings'], $s['db']['warnings'] );
			$this->plugin->diagnostics()->flush();
			$s['stage'] = 'done';
		}
		return $s;
	}

	/**
	 * Cancel: remove staging and temp tables.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$s = $job->checkpoint;
		if ( ! empty( $s['db'] ) ) {
			$db = $this->plugin->db();
			( new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id ) )->drop_temp_tables();
			$safety = (string) ( $s['db']['safety_file'] ?? '' );
			if ( $safety && 'done' !== ( $s['db']['safety']['stage'] ?? '' ) && PathGuard::is_within( $this->plugin->storage()->area( 'backups' ), wp_normalize_path( dirname( $safety ) ) ) && is_file( $safety ) ) {
				wp_delete_file( $safety );
			}
		}
		if ( ! empty( $s['job_dir'] ) && is_dir( $s['job_dir'] ) ) {
			$this->plugin->storage()->delete_dir( $s['job_dir'] );
		}
	}
}
