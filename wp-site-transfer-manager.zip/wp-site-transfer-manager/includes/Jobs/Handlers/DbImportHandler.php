<?php
/**
 * Job handler: database import ("db_import").
 *
 * Metadata: area (packages|backups), file (basename), confirmed (must be true),
 * safety_backup (default from settings), allow_unknown_disk.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\DbExporter;
use WSTM\Database\DbImporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\TableScanner;
use WSTM\Files\DiskSpace;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Import handler.
 */
class DbImportHandler implements JobHandlerInterface {

	public const TYPE  = 'db_import';
	public const AREAS = array( 'packages', 'backups' );

	/** Diagnostics that must pass before importing. */
	public const REQUIRED_CHECKS = array( 'php_version', 'wp_version', 'db_connection', 'temp_writable', 'ext_hash', 'ext_json' );

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Resolve and validate a dump selection.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $area   Area.
	 * @param string $file   Basename.
	 * @return array{source:string,manifest:?string}
	 * @throws WstmException If invalid.
	 */
	public static function resolve( Plugin $plugin, string $area, string $file ): array {
		if ( ! in_array( $area, self::AREAS, true ) || str_contains( $file, '/' ) || str_contains( $file, '\\' ) || ! preg_match( '/\.sql(\.gz)?$/i', $file ) ) {
			throw new WstmException( 'bad_source', 'Invalid dump selection.', array( 'why' => 'Only .sql or .sql.gz files inside plugin storage can be imported.' ) );
		}
		$path = $plugin->storage()->path( $area, PathGuard::safe_relative( $file ) );
		if ( ! is_file( $path ) || is_link( $path ) ) {
			throw new WstmException( 'source_missing', 'The selected dump does not exist.', array( 'why' => $file ) );
		}
		$manifest = DumpManifest::path_for( $path );
		return array(
			'source'   => $path,
			'manifest' => is_file( $manifest ) ? $manifest : null,
		);
	}

	/**
	 * Initial state; refuses unless confirmed, diagnostics pass and disk space suffices.
	 *
	 * @param Job $job Job.
	 * @throws WstmException When unsafe.
	 */
	private function init( Job $job ): array {
		$m = $job->metadata;
		if ( true !== ( $m['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Import was not confirmed.', array( 'what' => 'Database import', 'why' => 'Replacing the database requires explicit confirmation.', 'action' => 'Start the import again and tick the confirmation box.' ) );
		}
		$this->plugin->diagnostics()->assert_ready( self::REQUIRED_CHECKS, 'Database import' );

		$src     = self::resolve( $this->plugin, (string) ( $m['area'] ?? '' ), (string) ( $m['file'] ?? '' ) );
		$storage = $this->plugin->storage();
		$scanner = new TableScanner( $this->plugin->db() );
		$safety  = array_key_exists( 'safety_backup', $m ) ? (bool) $m['safety_backup'] : (bool) $this->plugin->settings()->get( 'safety_backup' );
		$gzip_ok = function_exists( 'gzopen' );

		$parts = array();
		if ( str_ends_with( strtolower( $src['source'] ), '.gz' ) ) {
			$raw                          = $src['manifest'] ? (int) ( DumpManifest::read( $src['manifest'] )['raw_size'] ?? 0 ) : 0;
			$parts['Decompressed dump'] = $raw ?: (int) filesize( $src['source'] ) * 8;
		}
		if ( $safety ) {
			$parts['Safety backup'] = DbExportHandler::estimate( $scanner, array(), $gzip_ok );
		}
		DiskSpace::require( $storage, $parts, ! empty( $m['allow_unknown_disk'] ) );

		$safety_file = $safety ? $storage->area( 'backups' ) . '/' . $storage->random_filename( 'safety-database', $gzip_ok ? 'sql.gz' : 'sql' ) : null;

		return DbImporter::init_state(
			array(
				'source'      => $src['source'],
				'manifest'    => $src['manifest'],
				'work_dir'    => $storage->job_dir( $job->uuid ),
				'safety_file' => $safety_file,
				'batch_rows'  => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
			)
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s        = $job->checkpoint ?: $this->init( $job );
		$db       = $this->plugin->db();
		$scanner  = new TableScanner( $db );
		$importer = new DbImporter( $db, $scanner, $this->plugin->logger(), $job->id );
		$jobs_tbl = $db->table( 'jobs' );

		$commit = static function ( array $state ) use ( $db, $jobs_tbl, $job ) {
			$db->query( "UPDATE {$jobs_tbl} SET checkpoint = %s, updated_at = %s WHERE id = %d", array( wp_json_encode( $state ), gmdate( 'Y-m-d H:i:s' ), $job->id ) );
		};

		$safety = $this->safety_runner( $job, (string) $s['safety_file'], (int) $s['batch_rows'] );

		$s = $importer->slice( $s, min( $deadline, time() + DbExportHandler::SLICE_SECONDS ), $commit, $safety );

		$meta = array(
			'file'          => basename( $s['source'] ),
			'stage'         => $s['stage'],
			'current_table' => 'safety' === $s['stage'] ? ( $s['safety']['tables'][ $s['safety']['t'] ?? 0 ]['name'] ?? '' ) : $s['current'],
			'tables_done'   => count( $s['tables'] ),
			'statements'    => (int) $s['statements'],
			'bytes'         => (int) $s['offset'],
			'bytes_total'   => (int) $s['sql_size'],
			'warnings'      => $s['warnings'],
			'safety_backup' => $s['safety_file'] ? basename( $s['safety_file'] ) : null,
		);

		if ( 'done' === $s['stage'] ) {
			$this->plugin->diagnostics()->flush();
			return StepResult::complete(
				array_merge(
					$meta,
					array(
						'current_table'   => '',
						'tables_imported' => count( $s['tables'] ),
						'row_counts'      => $s['counts'],
						'previous_tables' => $s['previous'],
					)
				)
			);
		}

		$labels = array(
			'precheck'    => 'Checking dump',
			'verify'      => 'Verifying checksum',
			'safety'      => 'Creating safety backup',
			'decompress'  => 'Decompressing',
			'import'      => 'Importing ' . $s['current'],
			'verify_rows' => 'Verifying row counts',
			'swap'        => 'Activating imported tables',
			'cleanup'     => 'Cleaning up',
		);
		return StepResult::continue( $s, DbImporter::progress( $s ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Callback that runs one slice of the pre-import safety backup and records it when done.
	 *
	 * @param Job    $job   Job.
	 * @param string $file  Safety backup path.
	 * @param int    $batch Batch rows.
	 */
	public function safety_runner( Job $job, string $file, int $batch ): callable {
		$exporter = new DbExporter( $this->plugin->db(), new TableScanner( $this->plugin->db() ) );
		return function ( ?array $st, int $dl ) use ( $exporter, $file, $batch, $job ) {
			if ( null === $st ) {
				$st = DbExporter::init_state(
					array(
						'file'       => $file,
						'tables'     => array(),
						'gzip'       => str_ends_with( $file, '.gz' ),
						'batch_rows' => $batch,
					)
				);
			}
			$st = $exporter->slice( $st, $dl );
			if ( 'done' === $st['stage'] ) {
				$manifest = $exporter->manifest( $st );
				DumpManifest::write( DumpManifest::path_for( $st['file'] ), $manifest );
				$this->plugin->db()->insert(
					'backups',
					array(
						'uuid'       => wp_generate_uuid4(),
						'type'       => 'database',
						'label'      => 'Safety backup before job #' . $job->id,
						'file_path'  => $st['file'],
						'size_bytes' => (int) $st['committed'],
						'checksum'   => $manifest['checksum']['hash'],
						'verified'   => 0,
						'is_safety'  => 1,
						'job_id'     => $job->id,
						'manifest'   => wp_json_encode( array( 'tables' => count( $st['tables'] ), 'rows' => $st['rows_done'] ) ),
						'created_at' => gmdate( 'Y-m-d H:i:s' ),
					)
				);
				$this->plugin->logger()->info( 'Safety backup created: ' . basename( $st['file'] ), array(), 'database', $job->id );
			}
			return $st;
		};
	}

	/**
	 * Cancel: drop temporary tables, remove work files and incomplete safety backup.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$db = $this->plugin->db();
		( new DbImporter( $db, new TableScanner( $db ), $this->plugin->logger(), $job->id ) )->drop_temp_tables();
		$s       = $job->checkpoint;
		$storage = $this->plugin->storage();
		if ( ! empty( $s['work_dir'] ) && is_dir( $s['work_dir'] ) ) {
			$storage->delete_dir( $s['work_dir'] );
		}
		$safety = (string) ( $s['safety_file'] ?? '' );
		if ( $safety && 'done' !== ( $s['safety']['stage'] ?? '' ) && PathGuard::is_within( $storage->area( 'backups' ), wp_normalize_path( dirname( $safety ) ) ) && is_file( $safety ) ) {
			wp_delete_file( $safety );
		}
	}
}
