<?php
/**
 * Job handlers: URL scan / dry run ("url_scan") and replace ("url_replace").
 *
 * Metadata: pairs [[old,new]...], tables[], skip_guid, url_encoded,
 *           mode (scan|dry_run) for url_scan; confirmed + safety_backup for url_replace.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\TableScanner;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\URL\UrlReplaceEngine;

defined( 'ABSPATH' ) || exit;

/**
 * URL handler.
 */
class UrlReplaceHandler implements JobHandlerInterface {

	public const TYPE_SCAN    = 'url_scan';
	public const TYPE_REPLACE = 'url_replace';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * @var string
	 */
	private string $type;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $type   Type.
	 */
	public function __construct( Plugin $plugin, string $type ) {
		$this->plugin = $plugin;
		$this->type = $type;
	}

	/** Type. */
	public function type(): string {
		return $this->type;
	}

	/**
	 * Initial state.
	 *
	 * @param Job $job Job.
	 * @throws WstmException If not confirmed.
	 */
	private function init( Job $job ): array {
		$m       = $job->metadata;
		$replace = self::TYPE_REPLACE === $this->type;
		if ( $replace && true !== ( $m['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Replacement was not confirmed.', array( 'action' => 'Start again and tick the confirmation box.' ) );
		}
		$safety = null;
		if ( $replace && ( ! array_key_exists( 'safety_backup', $m ) || ! empty( $m['safety_backup'] ) ) ) {
			$this->plugin->diagnostics()->assert_ready( array( 'db_connection', 'temp_writable' ), 'URL replace' );
			$storage = $this->plugin->storage();
			$safety  = $storage->area( 'backups' ) . '/' . $storage->random_filename( 'safety-database', function_exists( 'gzopen' ) ? 'sql.gz' : 'sql' );
		}
		return UrlReplaceEngine::init_state(
			array(
				'mode'        => $replace ? 'replace' : ( 'dry_run' === ( $m['mode'] ?? '' ) ? 'dry_run' : 'scan' ),
				'pairs'       => (array) ( $m['pairs'] ?? array() ),
				'tables'      => (array) ( $m['tables'] ?? array() ),
				'skip_guid'   => $m['skip_guid'] ?? true,
				'url_encoded' => ! empty( $m['url_encoded'] ),
				'safety_file' => $safety,
			)
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s      = $job->checkpoint ?: $this->init( $job );
		$db     = $this->plugin->db();
		$engine = new UrlReplaceEngine( $db, new TableScanner( $db ) );
		$tbl    = $db->table( 'jobs' );
		$commit = static function ( array $state ) use ( $db, $tbl, $job ) {
			$db->query( "UPDATE {$tbl} SET checkpoint = %s, updated_at = %s WHERE id = %d", array( wp_json_encode( $state ), gmdate( 'Y-m-d H:i:s' ), $job->id ) );
		};
		$safety = $s['safety_file'] ? ( new DbImportHandler( $this->plugin ) )->safety_runner( $job, (string) $s['safety_file'], (int) $this->plugin->settings()->get( 'db_batch_rows' ) ) : null;

		$s = $engine->slice( $s, min( $deadline, time() + DbExportHandler::SLICE_SECONDS ), $commit, $safety );

		$meta = array(
			'mode'          => $s['mode'],
			'current_table' => $s['tables'][ $s['t'] ]['name'] ?? '',
			'tables_done'   => (int) $s['t'],
			'tables_total'  => count( $s['tables'] ),
			'totals'        => $s['totals'],
			'warnings'      => $s['warnings'],
			'safety_backup' => $s['safety_file'] ? basename( $s['safety_file'] ) : null,
		);
		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->info(
				sprintf( 'URL %s finished: %d rows, %d values, %d replacements', $s['mode'], $s['totals']['rows'], $s['totals']['values'], $s['totals']['replacements'] ),
				array( 'pairs' => $s['pairs'] ),
				'url',
				$job->id
			);
			if ( 'replace' === $s['mode'] ) {
				\WSTM\Compatibility\PostMigration::run_all( $this->plugin->logger() );
			}
			return StepResult::complete(
				array_merge(
					$meta,
					array(
						'current_table' => '',
						'pairs'         => $s['pairs'],
						'report'        => $s['report'],
						'samples'       => $s['samples'],
						'remaining'     => $s['remaining'],
					)
				)
			);
		}
		$labels = array(
			'prepare' => 'Preparing',
			'safety'  => 'Creating safety backup',
			'process' => ( 'replace' === $s['mode'] ? 'Replacing in ' : 'Scanning ' ) . $meta['current_table'],
			'verify'  => 'Verifying',
		);
		return StepResult::continue( $s, UrlReplaceEngine::progress( $s ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Cancel: nothing partial to clean except an incomplete safety backup.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$f = (string) ( $job->checkpoint['safety_file'] ?? '' );
		if ( $f && 'done' !== ( $job->checkpoint['safety']['stage'] ?? '' ) && is_file( $f ) ) {
			wp_delete_file( $f );
		}
	}
}
