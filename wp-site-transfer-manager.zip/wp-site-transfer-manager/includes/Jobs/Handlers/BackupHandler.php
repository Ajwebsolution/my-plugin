<?php
/**
 * Job handler: create a backup ("backup_create").
 *
 * Stages: plan → build → verify → record → retention → cloud → done
 * A backup is only reported as successful after the finished file passes
 * full verification (seal, structure, manifest).
 *
 * Metadata: type (full|database|files), mode (full|differential|incremental),
 *           label, scheduled, cloud (destination id or ''), allow_unknown_disk.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Backup\BackupManager;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageBuilder;
use WSTM\Package\PackageValidator;

defined( 'ABSPATH' ) || exit;

/**
 * Backup handler.
 */
class BackupHandler implements JobHandlerInterface {

	public const TYPE = 'backup_create';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Initial state.
	 *
	 * @param Job $job Job.
	 * @throws WstmException On invalid options.
	 */
	private function init( Job $job ): array {
		$m    = $job->metadata;
		$type = in_array( $m['type'] ?? 'full', BackupManager::TYPES, true ) ? $m['type'] ?? 'full' : 'full';
		$mode = in_array( $m['mode'] ?? 'full', BackupManager::MODES, true ) ? $m['mode'] ?? 'full' : 'full';
		if ( 'database' === $type ) {
			$mode = 'full'; // Database backups are always complete.
		}
		$base = null;
		if ( 'full' !== $mode ) {
			$base = ( new BackupManager( $this->plugin ) )->base_for( $type, $mode );
			if ( ! $base ) {
				$mode = 'full'; // No usable base yet: the first backup in a chain is a full one.
			}
		}
		$components = array(
			'database' => 'files' !== $type,
			'uploads'  => 'database' !== $type,
			'themes'   => 'database' !== $type,
			'plugins'  => 'database' !== $type,
			'content'  => 'database' !== $type,
			'core'     => false,
			'root'     => false,
		);
		return array(
			'stage'    => 'build',
			'type'     => $type,
			'mode'     => $mode,
			'base'     => $base ? $base['id'] : null,
			'label'    => sanitize_text_field( (string) ( $m['label'] ?? '' ) ) ?: ucfirst( $type ) . ' backup' . ( 'full' !== $mode ? ' (' . $mode . ')' : '' ),
			'cloud'    => (string) ( $m['cloud'] ?? '' ),
			'b'        => ( new PackageBuilder( $this->plugin ) )->init_state(
				array(
					'components'         => $components,
					'exclusions'         => (array) $this->plugin->settings()->get( 'default_exclusions' ),
					'output_area'        => 'backups',
					'name_prefix'        => 'backup-' . $type . '-',
					'since_index'        => $base ? $base['file_path'] . '.idx' : null,
					'keep_index'         => 'database' !== $type,
					'mode'               => $mode,
					'base'               => $base ? $base['uuid'] : '',
					'allow_unknown_disk' => ! empty( $m['allow_unknown_disk'] ),
				),
				$this->plugin->storage()->job_dir( $job->uuid )
			),
			'v'        => null,
			'id'       => null,
			'cloud_st' => null,
			'warnings' => array(),
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s  = $job->checkpoint ?: $this->init( $job );
		$dl = min( $deadline, time() + DbExportHandler::SLICE_SECONDS );
		$mg = new BackupManager( $this->plugin );

		switch ( $s['stage'] ) {
			case 'build':
				$s['b'] = ( new PackageBuilder( $this->plugin ) )->slice( $s['b'], $dl );
				if ( 'done' === $s['b']['stage'] ) {
					$s['warnings'] = array_slice( $s['b']['warnings'], 0, 100 );
					$s['v']        = PackageValidator::init_state( $s['b']['final'] );
					$s['stage']    = 'verify';
				}
				break;

			case 'verify':
				try {
					$s['v'] = PackageValidator::step( $s['v'], $dl );
				} catch ( WstmException $e ) {
					// Never report success for an unverifiable backup; keep the file for inspection.
					throw new WstmException( 'backup_unverified', 'The backup failed verification and is not usable.', array( 'what' => 'Backup verification', 'why' => $e->getMessage() . ' ' . ( $e->get_context()['why'] ?? '' ), 'action' => 'Check disk health/free space and create the backup again.' ), $e );
				}
				if ( $s['v']['done'] ) {
					$s['stage'] = 'record';
				}
				break;

			case 'record':
				$file    = $s['b']['final'];
				$s['id'] = $mg->record(
					array(
						'type'             => $s['type'],
						'label'            => $s['label'],
						'file_path'        => $file,
						'size_bytes'       => (int) filesize( $file ),
						'checksum'         => $s['v']['hash']['hash'],
						'verified'         => true,
						'parent_backup_id' => $s['base'],
						'job_id'           => $job->id,
						'meta'             => array(
							'mode'       => $s['mode'],
							'components' => $s['b']['components'],
							'files'      => (int) $s['b']['files_done'],
							'unchanged'  => (int) $s['b']['unchanged'],
							'scheduled'  => ! empty( $job->metadata['scheduled'] ),
						),
					)
				);
				$this->plugin->storage()->delete_dir( $s['b']['job_dir'] );
				$s['v']     = array( 'done' => true, 'seal' => $s['v']['hash']['hash'] );
				$s['stage'] = 'retention';
				break;

			case 'retention':
				$mg->apply_retention( (int) $this->plugin->settings()->get( 'backup_retention' ) );
				$s['stage'] = $s['cloud'] ? 'cloud' : 'done';
				break;

			case 'cloud':
				/**
				 * Upload a finished backup to a cloud destination (Phase 10). Returns updated sub-state;
				 * the filter must set ['done' => true] when finished.
				 *
				 * @param array|null $st     Upload state.
				 * @param string     $dest   Destination id.
				 * @param string     $file   Backup file.
				 * @param int        $dl     Deadline.
				 * @param int        $backup Backup id.
				 */
				$s['cloud_st'] = apply_filters( 'wstm_cloud_upload_step', $s['cloud_st'], $s['cloud'], $s['b']['final'], $dl, (int) $s['id'] );
				if ( ! is_array( $s['cloud_st'] ) || ! empty( $s['cloud_st']['done'] ) ) {
					$s['stage'] = 'done';
				}
				break;
		}

		$meta = array(
			'type'         => $s['type'],
			'mode'         => $s['mode'],
			'stage'        => $s['stage'],
			'current_file' => $s['b']['arc']['cur']['path'] ?? '',
			'files_done'   => (int) ( $s['b']['files_done'] ?? 0 ),
			'files_total'  => (int) ( $s['b']['scan']['files'] ?? 0 ),
			'warnings'     => $s['warnings'],
		);
		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->info( sprintf( '%s backup created and verified: %s', ucfirst( $s['type'] ), basename( $s['b']['final'] ) ), array( 'mode' => $s['mode'] ), 'backup', $job->id );
			return StepResult::complete( array_merge( $meta, array( 'current_file' => '', 'backup_id' => $s['id'], 'file' => basename( $s['b']['final'] ), 'size' => (int) filesize( $s['b']['final'] ), 'verified' => true, 'cloud' => $s['cloud_st']['remote'] ?? null ) ) );
		}
		switch ( $s['stage'] ) {
			case 'build':
				$progress = 0.9 * PackageBuilder::progress( $s['b'] );
				break;
			case 'verify':
				$progress = 90 + 0.08 * PackageValidator::progress( $s['v'] );
				break;
			case 'cloud':
				$progress = 98 + 1.9 * (float) ( $s['cloud_st']['progress'] ?? 0 );
				break;
			default:
				$progress = 98;
		}
		$labels = array(
			'build'     => 'Building backup',
			'verify'    => 'Verifying backup',
			'record'    => 'Recording backup',
			'retention' => 'Applying retention',
			'cloud'     => 'Uploading to cloud storage',
		);
		return StepResult::continue( $s, round( $progress, 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Cancel: remove partial output.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$s = $job->checkpoint;
		if ( empty( $s['b'] ) ) {
			return;
		}
		if ( ! empty( $s['b']['part'] ) && is_file( $s['b']['part'] ) ) {
			wp_delete_file( $s['b']['part'] );
		}
		if ( empty( $s['id'] ) && ! empty( $s['b']['final'] ) && is_file( $s['b']['final'] ) ) {
			foreach ( array( $s['b']['final'], $s['b']['final'] . '.json', $s['b']['final'] . '.idx' ) as $f ) {
				if ( is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
		}
		if ( ! empty( $s['b']['job_dir'] ) && is_dir( $s['b']['job_dir'] ) ) {
			$this->plugin->storage()->delete_dir( $s['b']['job_dir'] );
		}
	}
}
