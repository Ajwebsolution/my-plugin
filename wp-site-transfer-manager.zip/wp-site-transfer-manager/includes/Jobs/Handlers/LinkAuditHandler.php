<?php
/**
 * Job handler: broken URL scanner ("link_audit").
 *
 * Scans published content for URLs and reports:
 *  - references to old domains (e.g. the site you migrated from),
 *  - internal links to uploads/assets whose files are missing on disk,
 *  - internal page links that do not resolve (checked with HEAD requests, capped).
 * It never modifies content and never touches external URLs.
 *
 * Metadata: old_hosts[] (optional).
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;

defined( 'ABSPATH' ) || exit;

/**
 * Link audit.
 */
class LinkAuditHandler implements JobHandlerInterface {

	public const TYPE        = 'link_audit';
	public const MAX_PROBES  = 150;
	public const MAX_SAMPLES = 100;

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		global $wpdb;
		$home = wp_parse_url( home_url() );
		$s    = $job->checkpoint ?: array(
			'stage'     => 'scan',
			'last_id'   => 0,
			'posts'     => 0,
			'total'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status IN ('publish','private','future') AND post_type NOT IN ('revision','nav_menu_item','shop_order')" ), // phpcs:ignore WordPress.DB
			'urls'      => 0,
			'internal'  => 0,
			'external'  => 0,
			'old'       => array(),
			'missing'   => array(),
			'queue'     => array(),
			'broken'    => array(),
			'probed'    => 0,
			'old_hosts' => array_values( array_filter( array_map( 'strtolower', (array) ( $job->metadata['old_hosts'] ?? array() ) ) ) ),
		);
		$host  = strtolower( (string) ( $home['host'] ?? '' ) );
		$up    = wp_upload_dir( null, false );
		$dl    = min( $deadline, time() + 5 );

		if ( 'scan' === $s['stage'] ) {
			do {
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE ID > %d AND post_status IN ('publish','private','future') AND post_type NOT IN ('revision','nav_menu_item','shop_order') ORDER BY ID LIMIT 200", $s['last_id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB
				if ( ! $rows ) {
					$s['stage'] = 'probe';
					break;
				}
				foreach ( $rows as $r ) {
					$s['last_id'] = (int) $r['ID'];
					++$s['posts'];
					if ( ! preg_match_all( '#(?:href|src|srcset|data-src)\s*=\s*["\']([^"\']+)["\']#i', (string) $r['post_content'], $m ) ) {
						continue;
					}
					foreach ( $m[1] as $raw ) {
						foreach ( preg_split( '/\s*,\s*/', $raw ) as $candidate ) {
							$url = trim( (string) preg_replace( '/\s+\d+[wx]$/', '', $candidate ) );
							if ( '' === $url || ! preg_match( '#^(https?:)?//#i', $url ) ) {
								continue;
							}
							++$s['urls'];
							$h = strtolower( (string) wp_parse_url( str_starts_with( $url, '//' ) ? 'http:' . $url : $url, PHP_URL_HOST ) );
							if ( in_array( $h, $s['old_hosts'], true ) ) {
								$s['old'][] = array( 'post' => (int) $r['ID'], 'title' => $r['post_title'], 'url' => $url );
								continue;
							}
							if ( $h !== $host ) {
								++$s['external'];
								continue;
							}
							++$s['internal'];
							$s = $this->check_internal( $s, $url, $r, $up );
						}
					}
				}
			} while ( time() < $dl );
		} elseif ( 'probe' === $s['stage'] ) {
			while ( $s['queue'] && $s['probed'] < self::MAX_PROBES && time() < $dl ) {
				$item = array_shift( $s['queue'] );
				++$s['probed'];
				$res  = wp_remote_head( $item['url'], array( 'timeout' => 10, 'redirection' => 3, 'sslverify' => false ) );
				$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
				if ( 404 === $code || 410 === $code ) {
					$s['broken'][] = $item + array( 'status' => $code );
				}
			}
			if ( ! $s['queue'] || $s['probed'] >= self::MAX_PROBES ) {
				$s['stage'] = 'done';
			}
		}

		foreach ( array( 'old', 'missing', 'broken' ) as $k ) {
			$s[ $k ] = array_slice( $s[ $k ], 0, self::MAX_SAMPLES );
		}
		$meta = array(
			'posts'    => $s['posts'],
			'urls'     => $s['urls'],
			'internal' => $s['internal'],
			'external' => $s['external'],
			'old'      => count( $s['old'] ),
			'missing'  => count( $s['missing'] ),
			'broken'   => count( $s['broken'] ),
		);
		if ( 'done' === $s['stage'] ) {
			return StepResult::complete(
				array_merge(
					$meta,
					array(
						'old_samples'     => $s['old'],
						'missing_samples' => $s['missing'],
						'broken_samples'  => $s['broken'],
						'probe_capped'    => $s['probed'] >= self::MAX_PROBES,
					)
				)
			);
		}
		$pct = 'scan' === $s['stage'] ? 90 * $s['posts'] / max( 1, $s['total'] ) : 90 + 9 * $s['probed'] / max( 1, min( self::MAX_PROBES, $s['probed'] + count( $s['queue'] ) ) );
		return StepResult::continue( $s, round( min( 99, $pct ), 2 ), 'scan' === $s['stage'] ? 'Scanning content' : 'Checking internal links', $meta );
	}

	/**
	 * Classify an internal URL: uploads/assets are checked on disk, pages are queued for a HEAD request.
	 *
	 * @param array  $s   State.
	 * @param string $url URL.
	 * @param array  $r   Post row.
	 * @param array  $up  wp_upload_dir().
	 */
	private function check_internal( array $s, string $url, array $r, array $up ): array {
		$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
		$path  = rawurldecode( $path );
		$base  = (string) wp_parse_url( $up['baseurl'], PHP_URL_PATH );
		$root  = (string) wp_parse_url( home_url(), PHP_URL_PATH );
		$entry = array( 'post' => (int) $r['ID'], 'title' => $r['post_title'], 'url' => $url );
		if ( '' !== $base && str_starts_with( $path, $base . '/' ) ) {
			$file = $up['basedir'] . substr( $path, strlen( $base ) );
			if ( ! str_contains( $file, '..' ) && ! is_file( $file ) ) {
				$s['missing'][] = $entry + array( 'kind' => 'upload' );
			}
			return $s;
		}
		if ( preg_match( '#\.(css|js|png|jpe?g|gif|webp|svg|woff2?|ttf|ico|pdf|mp4)$#i', $path ) ) {
			$rel  = ltrim( substr( $path, strlen( rtrim( $root, '/' ) ) ), '/' );
			$file = ABSPATH . $rel;
			if ( ! str_contains( $rel, '..' ) && ! is_file( $file ) ) {
				$s['missing'][] = $entry + array( 'kind' => 'asset' );
			}
			return $s;
		}
		if ( url_to_postid( $url ) || untrailingslashit( $url ) === untrailingslashit( home_url() ) || str_contains( $path, '/wp-' ) ) {
			return $s;
		}
		$key = md5( strtok( $url, '#' ) );
		if ( ! isset( $s['queued'][ $key ] ) && count( $s['queue'] ) < self::MAX_PROBES ) {
			$s['queued'][ $key ] = 1;
			$s['queue'][]        = $entry;
		}
		return $s;
	}

	/**
	 * Nothing to clean up.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {}
}
