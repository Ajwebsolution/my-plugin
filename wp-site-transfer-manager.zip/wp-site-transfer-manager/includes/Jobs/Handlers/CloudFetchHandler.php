<?php
/**
 * Job "cloud_fetch": download a .wpmig backup from a cloud destination into the packages area
 * (resumable, ranged), then it can be restored from the Import screen.
 *
 * Metadata: destination, key.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Cloud\CloudManager;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageBuilder;

defined( 'ABSPATH' ) || exit;

/**
 * Cloud fetch handler.
 */
class CloudFetchHandler implements JobHandlerInterface {

	public const TYPE  = 'cloud_fetch';
	public const CHUNK = 8 * 1024 * 1024;

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Local file name for a remote key (must be a plain .wpmig name).
	 *
	 * @param string $key Key.
	 * @throws WstmException If not a package.
	 */
	public static function local_name( string $key ): string {
		$name = basename( $key );
		if ( ! preg_match( '/^[A-Za-z0-9._-]+\.' . PackageBuilder::EXT . '$/', $name ) ) {
			throw new WstmException( 'cloud_not_package', 'Only .' . PackageBuilder::EXT . ' backup files can be downloaded to this site.', array( 'why' => $name ) );
		}
		return $name;
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 * @throws WstmException On failure.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$m    = $job->metadata;
		$dest = ( new CloudManager( $this->plugin ) )->destination( (string) ( $m['destination'] ?? '' ) );
		$key  = (string) ( $m['key'] ?? '' );
		$s    = $job->checkpoint;
		if ( ! $s ) {
			$name  = self::local_name( $key );
			$final = $this->plugin->storage()->path( 'packages', $name );
			if ( file_exists( $final ) ) {
				throw new WstmException( 'cloud_exists', 'A package with this name already exists on this site.', array( 'why' => $name, 'action' => 'Use the existing package from the Import screen, or delete it first.' ) );
			}
			$size = $dest->size( $key );
			$free = $this->plugin->storage()->free_space();
			if ( null !== $free && $free < $size * 1.1 ) {
				throw new WstmException( 'disk_space', 'Not enough disk space to download this backup.', array( 'why' => size_format( $size ) . ' needed, ' . size_format( $free ) . ' free.' ) );
			}
			$s = array( 'name' => $name, 'part' => $final . '.part', 'size' => $size, 'offset' => 0 );
			file_put_contents( $s['part'], '' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		clearstatcache();
		if ( (int) @filesize( $s['part'] ) !== (int) $s['offset'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$fh = fopen( $s['part'], 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			ftruncate( $fh, (int) $s['offset'] );
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$fh = fopen( $s['part'], 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		do {
			$len = (int) min( self::CHUNK, $s['size'] - $s['offset'] );
			if ( $len <= 0 ) {
				break;
			}
			$got = $dest->download_range( $key, $fh, (int) $s['offset'], $len );
			fflush( $fh );
			if ( $got <= 0 ) {
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				throw new WstmException( 'cloud_error', 'The download returned no data.', array( 'resumable' => true ) );
			}
			$s['offset'] += $got;
		} while ( time() < $deadline );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( $s['offset'] < $s['size'] ) {
			return StepResult::continue( $s, $s['offset'] / max( 1, $s['size'] ) * 100, 'Downloading ' . size_format( $s['offset'] ) . ' of ' . size_format( $s['size'] ), array( 'file' => $s['name'] ) );
		}
		$final = $this->plugin->storage()->path( 'packages', $s['name'] );
		if ( ! rename( $s['part'], $final ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			throw new WstmException( 'cloud_finalize', 'Could not move the downloaded file into place.', array( 'resumable' => true ) );
		}
		$this->plugin->logger()->info( 'Downloaded backup from cloud: ' . $s['name'], array( 'size' => $s['size'] ), 'cloud', $job->id );
		return StepResult::complete( array( 'file' => $s['name'], 'size' => $s['size'] ) );
	}

	/**
	 * Cancel: remove the partial file.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$p = (string) ( $job->checkpoint['part'] ?? '' );
		if ( $p && str_ends_with( $p, '.part' ) && is_file( $p ) ) {
			wp_delete_file( $p );
		}
	}
}
