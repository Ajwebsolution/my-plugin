<?php
/**
 * Job handler: pull another site into this one ("transfer_pull").
 *
 * Stages: handshake → remote_export → download → finish_remote → restore → done
 * The final stage hands over to a normal one-click restore job (same safety
 * guarantees) whose id is returned in the result as child_job.
 *
 * Metadata: key_enc (encrypted transfer key), skip (export options), keep_users,
 *           confirmed, token_hash.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Security\Crypto;
use WSTM\Transfer\TransferClient;
use WSTM\Transfer\TransferKeys;

defined( 'ABSPATH' ) || exit;

/**
 * Pull handler.
 */
class TransferPullHandler implements JobHandlerInterface {

	public const TYPE = 'transfer_pull';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Client from encrypted key in metadata.
	 *
	 * @param Job $job Job.
	 * @throws WstmException If the key cannot be read.
	 */
	public static function client( Job $job ): TransferClient {
		$key = Crypto::decrypt( (string) ( $job->metadata['key_enc'] ?? '' ) );
		if ( null === $key ) {
			throw new WstmException( 'key_unreadable', 'The stored transfer key cannot be read.', array( 'action' => 'Start the transfer again with a new key.' ) );
		}
		return new TransferClient( TransferKeys::parse( $key ) );
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s = $job->checkpoint ?: array(
			'stage'   => 'handshake',
			'remote'  => null,
			'file'    => null,
			'size'    => 0,
			'local'   => null,
			'progress'=> 0,
			'child'   => null,
		);
		if ( true !== ( $job->metadata['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Transfer was not confirmed.' );
		}
		$c     = self::client( $job );
		$dl    = min( $deadline, time() + 10 );
		$chunk = min( 4 * MB_IN_BYTES, max( MB_IN_BYTES, (int) \WSTM\Archive\Archive::chunk_bytes( $this->plugin->settings()->get( 'chunk_size' ) ) ) );

		switch ( $s['stage'] ) {
			case 'handshake':
				$s['remote'] = $c->request( 'POST', 'handshake' );
				if ( 'pull' !== ( $s['remote']['mode'] ?? '' ) ) {
					throw new WstmException( 'wrong_key', 'This key does not allow pulling from the other site.', array( 'action' => 'On the other site, generate a key with “Allow this site to be pulled”.' ) );
				}
				if ( ! empty( $s['remote']['multisite'] ) ) {
					throw new WstmException( 'multisite_source', 'Pulling a multisite network is not supported.' );
				}
				$c->request( 'POST', 'export/start', array( 'skip' => (array) ( $job->metadata['skip'] ?? array() ) ) );
				$s['stage'] = 'remote_export';
				break;

			case 'remote_export':
				$r = $c->request( 'POST', 'export/run', array(), array(), 120 );
				$s['progress'] = (float) $r['progress'];
				$s['step']     = (string) $r['step'];
				if ( 'failed' === $r['status'] ) {
					$e = (array) $r['error'];
					throw new WstmException( 'remote_export_failed', 'The other site could not create its package.', array( 'what' => 'Export on ' . $c->host(), 'why' => ( $e['what'] ?? '' ) . ': ' . ( $e['why'] ?? '' ), 'resumable' => ! empty( $e['resumable'] ), 'action' => $e['action'] ?? 'See the other site\'s Logs.' ) );
				}
				if ( 'completed' === $r['status'] ) {
					$s['file']  = (string) $r['file'];
					$s['size']  = (int) $r['size'];
					$s['local'] = $this->plugin->storage()->area( 'packages' ) . '/' . $this->plugin->storage()->random_filename( 'pulled-' . sanitize_title( $c->host() ), 'wpmig' );
					\WSTM\Files\DiskSpace::require( $this->plugin->storage(), array( 'Downloaded package' => $s['size'], 'Restore work space' => $s['size'] * 2 ), ! empty( $job->metadata['allow_unknown_disk'] ) );
					$s['stage'] = 'download';
				}
				break;

			case 'download':
				$part = $s['local'] . '.part';
				clearstatcache( true, $part );
				$have = is_file( $part ) ? (int) filesize( $part ) : 0;
				do {
					if ( $have >= $s['size'] ) {
						break;
					}
					$r    = null;
					$tries = 0;
					while ( null === $r ) {
						try {
							$r = $c->request( 'GET', 'package', array(), array( 'offset' => $have, 'length' => $chunk ), 120 );
							$data = base64_decode( (string) $r['data'], true );
							if ( false === $data || '' === $data || ! hash_equals( (string) $r['sha256'], hash( 'sha256', $data ) ) || (int) $r['offset'] !== $have ) {
								throw new WstmException( 'chunk_corrupt', 'A downloaded chunk failed its checksum.', array( 'resumable' => true ) );
							}
						} catch ( WstmException $e ) {
							$r = null;
							if ( ++$tries >= 3 || empty( $e->get_context()['resumable'] ) && 'chunk_corrupt' !== $e->get_error_code() ) {
								throw $e;
							}
							sleep( 1 );
						}
					}
					if ( file_put_contents( $part, $data, FILE_APPEND ) !== strlen( $data ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
						throw new WstmException( 'write_failed', 'Saving the downloaded package failed (disk full?).', array( 'resumable' => true ) );
					}
					$have += strlen( $data );
				} while ( time() < $dl );
				$s['progress'] = 100 * $have / max( 1, $s['size'] );
				if ( $have >= $s['size'] ) {
					if ( $have !== $s['size'] || ! rename( $part, $s['local'] ) ) {
						wp_delete_file( $part );
						throw new WstmException( 'download_size', 'The downloaded package has the wrong size.', array( 'resumable' => true, 'action' => 'Resume to download it again.' ) );
					}
					$s['stage'] = 'finish_remote';
				}
				break;

			case 'finish_remote':
				try {
					$c->request( 'POST', 'finish', array( 'delete_package' => true ) );
				} catch ( WstmException $e ) {
					$this->plugin->logger()->warning( 'Could not close the transfer on the other site: ' . $e->getMessage(), array(), 'transfer', $job->id );
				}
				$s['stage'] = 'restore';
				break;

			case 'restore':
				$child = $this->plugin->jobs()->create(
					SiteRestoreHandler::TYPE,
					array(
						'file'          => basename( $s['local'] ),
						'confirmed'     => true,
						'safety_backup' => true,
						'keep_users'    => ! empty( $job->metadata['keep_users'] ),
						'label'         => 'Pulled from ' . $c->host(),
						'token_hash'    => (string) ( $job->metadata['token_hash'] ?? '' ),
					)
				);
				$s['child'] = $child->id;
				$s['stage'] = 'done';
				break;
		}

		$meta = array( 'stage' => $s['stage'], 'remote' => $c->host(), 'bytes' => is_string( $s['local'] ) && is_file( $s['local'] . '.part' ) ? (int) filesize( $s['local'] . '.part' ) : 0, 'bytes_total' => (int) $s['size'] );
		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->info( 'Pulled package from ' . $c->host() . ' (' . size_format( $s['size'] ) . ')', array(), 'transfer', $job->id );
			return StepResult::complete( array_merge( $meta, array( 'child_job' => $s['child'], 'file' => basename( $s['local'] ) ) ) );
		}
		$labels = array( 'handshake' => 'Connecting to ' . $c->host(), 'remote_export' => 'Packing the other site: ' . ( $s['step'] ?? '' ), 'download' => 'Downloading package', 'finish_remote' => 'Closing the transfer', 'restore' => 'Starting import' );
		$pct    = array( 'handshake' => 0, 'remote_export' => 0.4 * $s['progress'], 'download' => 40 + 0.55 * $s['progress'], 'finish_remote' => 96, 'restore' => 98 );
		return StepResult::continue( $s, round( (float) $pct[ $s['stage'] ], 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Cancel: remove partial download.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$l = (string) ( $job->checkpoint['local'] ?? '' );
		if ( $l && is_file( $l . '.part' ) ) {
			wp_delete_file( $l . '.part' );
		}
	}
}
