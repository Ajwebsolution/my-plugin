<?php
/**
 * Job handler: push this site into another one ("transfer_push").
 *
 * Stages: handshake → export → upload → remote_restore → finish → done
 * This site is never modified. The other site restores the package with its
 * own one-click restore (safety backup, atomic database switch, undo point).
 *
 * Metadata: key_enc, skip, keep_users, confirmed.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageBuilder;
use WSTM\Rest\MigrationController;

defined( 'ABSPATH' ) || exit;

/**
 * Push handler.
 */
class TransferPushHandler implements JobHandlerInterface {

	public const TYPE = 'transfer_push';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		if ( true !== ( $job->metadata['confirmed'] ?? false ) ) {
			throw new WstmException( 'not_confirmed', 'Transfer was not confirmed.' );
		}
		$c  = TransferPullHandler::client( $job );
		$s  = $job->checkpoint ?: array( 'stage' => 'handshake', 'b' => null, 'sent' => 0, 'size' => 0, 'progress' => 0, 'remote' => null, 'result' => null );
		$dl = min( $deadline, time() + 10 );

		switch ( $s['stage'] ) {
			case 'handshake':
				$s['remote'] = $c->request( 'POST', 'handshake' );
				if ( 'push' !== ( $s['remote']['mode'] ?? '' ) ) {
					throw new WstmException( 'wrong_key', 'This key does not allow pushing to the other site.', array( 'action' => 'On the other site, generate a key with “Allow another site to push into this one”.' ) );
				}
				if ( ! empty( $s['remote']['multisite'] ) ) {
					throw new WstmException( 'multisite_dest', 'Pushing into a multisite network is not supported.' );
				}
				$builder    = new PackageBuilder( $this->plugin );
				$s['b']     = $builder->init_state( MigrationController::export_meta( $this->plugin, (array) ( $job->metadata['skip'] ?? array() ) ), $this->plugin->storage()->job_dir( $job->uuid ) );
				$s['stage'] = 'export';
				break;

			case 'export':
				$s['b']        = ( new PackageBuilder( $this->plugin ) )->slice( $s['b'], min( $dl, time() + 3 ) );
				$s['progress'] = PackageBuilder::progress( $s['b'] );
				if ( 'done' === $s['b']['stage'] ) {
					$s['size']  = (int) filesize( $s['b']['final'] );
					$up         = $c->request( 'POST', 'upload/start', array( 'size' => $s['size'] ) );
					$s['sent']  = (int) $up['received'];
					$s['stage'] = 'upload';
				}
				break;

			case 'upload':
				$max = min( (int) ( $s['remote']['max_chunk'] ?? 4 * MB_IN_BYTES ), 4 * MB_IN_BYTES );
				$fh  = fopen( $s['b']['final'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				try {
					do {
						if ( $s['sent'] >= $s['size'] ) {
							break;
						}
						fseek( $fh, $s['sent'] );
						$data = (string) fread( $fh, $max ); // phpcs:ignore WordPress.WP.AlternativeFunctions
						$r    = $c->request( 'POST', 'upload/chunk', array( 'offset' => $s['sent'], 'sha256' => hash( 'sha256', $data ), 'data' => base64_encode( $data ) ), array(), 120 );
						$s['sent'] = (int) $r['received'];
					} while ( time() < $dl );
				} finally {
					fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				}
				$s['progress'] = 100 * $s['sent'] / max( 1, $s['size'] );
				if ( $s['sent'] >= $s['size'] ) {
					$c->request( 'POST', 'upload/finish' );
					$c->request( 'POST', 'restore/start', array( 'keep_users' => ! empty( $job->metadata['keep_users'] ), 'source' => home_url() ) );
					$s['stage'] = 'remote_restore';
				}
				break;

			case 'remote_restore':
				$r             = $c->request( 'POST', 'restore/run', array(), array(), 180 );
				$s['progress'] = (float) $r['progress'];
				$s['step']     = (string) $r['step'];
				if ( 'failed' === $r['status'] ) {
					$e = (array) $r['error'];
					throw new WstmException( 'remote_restore_failed', 'The other site could not import the package.', array( 'what' => 'Import on ' . $c->host(), 'why' => ( $e['what'] ?? '' ) . ': ' . ( $e['why'] ?? '' ), 'resumable' => ! empty( $e['resumable'] ), 'action' => ( $e['action'] ?? '' ) . ' You can resume here; the other site keeps an undo point.' ) );
				}
				if ( 'completed' === $r['status'] ) {
					$s['result'] = $r['result'];
					$s['stage']  = 'finish';
				}
				break;

			case 'finish':
				try {
					$c->request( 'POST', 'finish' );
				} catch ( WstmException $e ) {
					unset( $e ); // Key expires on its own.
				}
				foreach ( array( $s['b']['final'], $s['b']['final'] . '.json' ) as $f ) {
					if ( is_file( $f ) ) {
						wp_delete_file( $f );
					}
				}
				if ( ! empty( $s['b']['job_dir'] ) && is_dir( $s['b']['job_dir'] ) ) {
					$this->plugin->storage()->delete_dir( $s['b']['job_dir'] );
				}
				$s['stage'] = 'done';
				break;
		}

		$meta = array( 'stage' => $s['stage'], 'remote' => $c->host(), 'bytes' => (int) $s['sent'], 'bytes_total' => (int) $s['size'] );
		if ( 'done' === $s['stage'] ) {
			$this->plugin->logger()->info( 'Pushed this site to ' . $c->host(), array(), 'transfer', $job->id );
			return StepResult::complete( array_merge( $meta, array( 'remote_result' => $s['result'], 'remote_url' => $s['remote']['home_url'] ?? '' ) ) );
		}
		$labels = array( 'handshake' => 'Connecting to ' . $c->host(), 'export' => 'Packing this site', 'upload' => 'Sending to ' . $c->host(), 'remote_restore' => 'Importing on ' . $c->host() . ': ' . ( $s['step'] ?? '' ), 'finish' => 'Finishing' );
		$pct    = array( 'handshake' => 0, 'export' => 0.35 * $s['progress'], 'upload' => 35 + 0.3 * $s['progress'], 'remote_restore' => 65 + 0.34 * $s['progress'], 'finish' => 99 );
		return StepResult::continue( $s, round( (float) $pct[ $s['stage'] ], 2 ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Cancel: remove the local package.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$b = $job->checkpoint['b'] ?? null;
		if ( $b ) {
			foreach ( array( $b['part'] ?? '', $b['final'] ?? '' ) as $f ) {
				if ( $f && is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
			if ( ! empty( $b['job_dir'] ) && is_dir( $b['job_dir'] ) ) {
				$this->plugin->storage()->delete_dir( $b['job_dir'] );
			}
		}
	}
}
