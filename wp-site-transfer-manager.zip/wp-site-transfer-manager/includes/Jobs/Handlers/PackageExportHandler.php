<?php
/**
 * Job handler: build a .wpmig package ("package_export").
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Package\PackageBuilder;
use WSTM\Package\PackageInfo;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Package export handler.
 */
class PackageExportHandler implements JobHandlerInterface {

	public const TYPE = 'package_export';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$builder = new PackageBuilder( $this->plugin );
		$s       = $job->checkpoint ?: $builder->init_state( $job->metadata, $this->plugin->storage()->job_dir( $job->uuid ) );
		$s       = $builder->slice( $s, min( $deadline, time() + DbExportHandler::SLICE_SECONDS ) );

		$meta = array(
			'file'          => basename( $s['final'] ),
			'stage'         => $s['stage'],
			'current_table' => 'db' === $s['stage'] && $s['db'] ? ( $s['db']['tables'][ $s['db']['t'] ]['name'] ?? '' ) : '',
			'current_file'  => $s['arc']['cur']['path'] ?? '',
			'files_done'    => (int) $s['files_done'],
			'files_total'   => (int) ( $s['scan']['files'] ?? 0 ),
			'bytes'         => (int) ( $s['arc']['committed'] ?? ( $s['db']['committed'] ?? 0 ) ),
			'bytes_total'   => (int) ( $s['scan']['bytes'] ?? 0 ),
			'warnings'      => array_slice( $s['warnings'], 0, 100 ),
		);

		if ( 'done' === $s['stage'] ) {
			$this->plugin->storage()->delete_dir( $s['job_dir'] );
			$this->plugin->logger()->info( sprintf( 'Package created: %s (%d files, %s)', basename( $s['final'] ), $s['files_done'], size_format( filesize( $s['final'] ) ) ), array( 'seal' => $s['hash']['hash'] ), 'package', $job->id );
			return StepResult::complete( array_merge( $meta, array( 'current_file' => '', 'size' => (int) filesize( $s['final'] ), 'seal' => $s['hash']['hash'] ) ) );
		}

		$labels = array(
			'prepare'   => 'Pre-flight checks',
			'db'        => 'Exporting database ' . $meta['current_table'],
			'scan'      => sprintf( 'Scanning files (%d found)', (int) ( $s['scan']['files'] ?? 0 ) ),
			'disk'      => 'Checking disk space',
			'meta'      => 'Writing metadata',
			'files'     => 'Archiving ' . $meta['current_file'],
			'tail'      => 'Writing manifest',
			'seal_hash' => 'Sealing package (SHA-256)',
			'seal'      => 'Finalising',
		);
		return StepResult::continue( $s, PackageBuilder::progress( $s ), $labels[ $s['stage'] ] ?? $s['stage'], $meta );
	}

	/**
	 * Cancel: remove partial package and working files.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$s       = $job->checkpoint;
		$storage = $this->plugin->storage();
		if ( ! empty( $s['part'] ) && PathGuard::is_within( $storage->area( 'packages' ), wp_normalize_path( dirname( $s['part'] ) ) ) && is_file( $s['part'] ) ) {
			wp_delete_file( $s['part'] );
		}
		if ( ! empty( $s['job_dir'] ) && is_dir( $s['job_dir'] ) ) {
			$storage->delete_dir( $s['job_dir'] );
		}
		if ( ! empty( $s['final'] ) ) {
			PackageInfo::delete( $s['final'] );
		}
	}
}
