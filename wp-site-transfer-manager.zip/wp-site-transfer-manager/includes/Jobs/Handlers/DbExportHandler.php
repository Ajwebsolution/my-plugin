<?php
/**
 * Job handler: database export ("db_export").
 *
 * Metadata: tables[] (empty = all site tables), gzip, drop_table, allow_unknown_disk.
 *
 * @package WSTM\Jobs\Handlers
 */

namespace WSTM\Jobs\Handlers;

use WSTM\Core\Plugin;
use WSTM\Database\DbExporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\TableScanner;
use WSTM\Files\DiskSpace;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobHandlerInterface;
use WSTM\Jobs\StepResult;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Export handler.
 */
class DbExportHandler implements JobHandlerInterface {

	public const TYPE = 'db_export';

	/** Seconds per slice so checkpoints are saved frequently. */
	public const SLICE_SECONDS = 3;

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Type. */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * Estimate dump size for the selected tables.
	 *
	 * @param TableScanner $scanner Scanner.
	 * @param string[]     $tables  Tables (empty = defaults).
	 * @param bool         $gzip    Compressed.
	 */
	public static function estimate( TableScanner $scanner, array $tables, bool $gzip ): int {
		$sel   = $tables ? array_flip( $tables ) : null;
		$bytes = 0;
		foreach ( $scanner->tables() as $t ) {
			if ( ( null === $sel && $t['default'] ) || isset( $sel[ $t['name'] ] ) ) {
				$bytes += $t['data_bytes'];
			}
		}
		// SQL text is usually larger than InnoDB data pages; gzip typically shrinks it 4–10×.
		return (int) ( $gzip ? $bytes * 0.5 : $bytes * 1.3 );
	}

	/**
	 * Initial state from job metadata (runs disk check before writing anything).
	 *
	 * @param Job $job Job.
	 */
	private function init( Job $job ): array {
		$m       = $job->metadata;
		$gzip    = ! empty( $m['gzip'] ) && function_exists( 'gzopen' );
		$tables  = array_values( array_filter( array_map( 'strval', (array) ( $m['tables'] ?? array() ) ) ) );
		$scanner = new TableScanner( $this->plugin->db() );
		$storage = $this->plugin->storage();

		$this->plugin->diagnostics()->assert_ready( array( 'php_version', 'db_connection', 'temp_writable', 'ext_hash', 'ext_json' ), 'Database export' );
		DiskSpace::require( $storage, array( 'Database dump' => self::estimate( $scanner, $tables, $gzip ) ), ! empty( $m['allow_unknown_disk'] ) );

		$file = $storage->area( 'packages' ) . '/' . $storage->random_filename( 'database', $gzip ? 'sql.gz' : 'sql' );
		return DbExporter::init_state(
			array(
				'file'       => $file,
				'tables'     => $tables,
				'gzip'       => $gzip,
				'drop_table' => $m['drop_table'] ?? true,
				'batch_rows' => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
			)
		);
	}

	/**
	 * One slice.
	 *
	 * @param Job $job      Job.
	 * @param int $deadline Deadline.
	 */
	public function step( Job $job, int $deadline ): StepResult {
		$s        = $job->checkpoint ?: $this->init( $job );
		$exporter = new DbExporter( $this->plugin->db(), new TableScanner( $this->plugin->db() ) );
		$s        = $exporter->slice( $s, min( $deadline, time() + self::SLICE_SECONDS ) );

		$meta = array(
			'file'          => basename( $s['file'] ),
			'current_table' => $s['tables'][ $s['t'] ]['name'] ?? '',
			'tables_done'   => (int) $s['t'],
			'tables_total'  => count( $s['tables'] ),
			'rows_done'     => (int) $s['rows_done'],
			'rows_total'    => (int) $s['rows_est'],
			'bytes'         => (int) $s['committed'],
			'warnings'      => $s['warnings'],
		);

		if ( 'done' === $s['stage'] ) {
			$manifest = $exporter->manifest( $s );
			DumpManifest::write( DumpManifest::path_for( $s['file'] ), $manifest );
			$this->plugin->logger()->info(
				sprintf( 'Database export complete: %d tables, %d rows, %s', count( $s['tables'] ), $s['rows_done'], size_format( $s['committed'] ) ),
				array( 'file' => basename( $s['file'] ), 'sha256' => $manifest['checksum']['hash'] ),
				'database',
				$job->id
			);
			return StepResult::complete( array_merge( $meta, array( 'current_table' => '', 'checksum' => $manifest['checksum']['hash'] ) ) );
		}

		$label = 'hash' === $s['stage'] ? 'Calculating checksum' : 'Exporting ' . $meta['current_table'];
		return StepResult::continue( $s, DbExporter::progress( $s ), $label, $meta );
	}

	/**
	 * Remove partial output on cancel.
	 *
	 * @param Job $job Job.
	 */
	public function on_cancel( Job $job ): void {
		$file = (string) ( $job->checkpoint['file'] ?? '' );
		if ( '' === $file ) {
			return;
		}
		$area = $this->plugin->storage()->area( 'packages' );
		if ( PathGuard::is_within( $area, wp_normalize_path( dirname( $file ) ) ) ) {
			foreach ( array( $file, DumpManifest::path_for( $file ) ) as $f ) {
				if ( is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
		}
	}
}
