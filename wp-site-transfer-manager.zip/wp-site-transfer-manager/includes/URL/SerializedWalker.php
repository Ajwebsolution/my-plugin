<?php
/**
 * PHP-serialized data rewriter that never calls unserialize().
 *
 * Walks the serialized grammar token by token, passes every string VALUE
 * through a callback and rebuilds the payload with correct byte lengths.
 * Objects are never instantiated (no __wakeup/__destruct side effects, no
 * object-injection risk) and unknown classes are preserved byte-for-byte.
 * Array keys are left unchanged. Custom-serialized objects (C:) are copied
 * verbatim and reported, because their inner format is class-defined.
 *
 * @package WSTM\URL
 */

namespace WSTM\URL;

defined( 'ABSPATH' ) || exit;

/**
 * Serialized walker.
 */
final class SerializedWalker {

	/** Input. */
	private string $in = '';

	/** Position. */
	private int $i = 0;

	/** Value callback. @var callable */
	private $cb;

	/** Nesting guard. */
	private int $depth = 0;

	/** Set when a C: payload containing a search term was copied unchanged. */
	public bool $opaque_hit = false;

	/** Needles used to detect matches inside opaque payloads. @var string[] */
	private array $needles = array();

	/**
	 * Whether a string looks like PHP-serialized data.
	 *
	 * @param string $s String.
	 */
	public static function looks_serialized( string $s ): bool {
		$s = trim( $s );
		if ( 'N;' === $s ) {
			return true;
		}
		return strlen( $s ) >= 4 && 1 === preg_match( '/^(?:[aOsCE]:\d+:|[bid]:[^;]*;$|[bid]:)/', $s ) && in_array( substr( $s, -1 ), array( ';', '}' ), true );
	}

	/**
	 * Rewrite a serialized string.
	 *
	 * @param string   $data    Serialized data.
	 * @param callable $cb      fn(string $value): string.
	 * @param string[] $needles Search terms (for opaque payload detection).
	 * @return string|null Rewritten data, or null if the input is not valid serialized data.
	 */
	public function rewrite( string $data, callable $cb, array $needles = array() ): ?string {
		$this->in         = $data;
		$this->i          = 0;
		$this->cb         = $cb;
		$this->depth      = 0;
		$this->opaque_hit = false;
		$this->needles    = $needles;
		try {
			$out = $this->value();
		} catch ( \UnexpectedValueException $e ) {
			return null;
		}
		return $this->i === strlen( $data ) ? $out : null;
	}

	/**
	 * Fail parsing.
	 *
	 * @throws \UnexpectedValueException Always.
	 */
	private function fail(): void {
		throw new \UnexpectedValueException( 'bad serialized data at ' . $this->i );
	}

	/**
	 * Expect a literal.
	 *
	 * @param string $lit Literal.
	 */
	private function expect( string $lit ): void {
		if ( substr( $this->in, $this->i, strlen( $lit ) ) !== $lit ) {
			$this->fail();
		}
		$this->i += strlen( $lit );
	}

	/**
	 * Read until a delimiter (exclusive) and consume the delimiter.
	 *
	 * @param string $delim Delimiter char.
	 * @param string $re    Validation regex for the token.
	 */
	private function until( string $delim, string $re ): string {
		$p = strpos( $this->in, $delim, $this->i );
		if ( false === $p ) {
			$this->fail();
		}
		$tok = substr( $this->in, $this->i, $p - $this->i );
		if ( ! preg_match( $re, $tok ) ) {
			$this->fail();
		}
		$this->i = $p + 1;
		return $tok;
	}

	/**
	 * Read a length-prefixed quoted string body: <len>:"<bytes>".
	 */
	private function lenstr(): string {
		$len = (int) $this->until( ':', '/^\d+$/' );
		$this->expect( '"' );
		if ( $this->i + $len > strlen( $this->in ) ) {
			$this->fail();
		}
		$s        = substr( $this->in, $this->i, $len );
		$this->i += $len;
		$this->expect( '"' );
		return $s;
	}

	/**
	 * Parse and rebuild one value.
	 *
	 * @param bool $is_key Whether this is an array key (left unchanged).
	 */
	private function value( bool $is_key = false ): string {
		if ( ++$this->depth > 512 ) {
			$this->fail();
		}
		$t = $this->in[ $this->i ] ?? '';
		$this->i++;
		switch ( $t ) {
			case 'N':
				$this->expect( ';' );
				$out = 'N;';
				break;
			case 'b':
				$this->expect( ':' );
				$out = 'b:' . $this->until( ';', '/^[01]$/' ) . ';';
				break;
			case 'i':
				$this->expect( ':' );
				$out = 'i:' . $this->until( ';', '/^[+-]?\d+$/' ) . ';';
				break;
			case 'd':
				$this->expect( ':' );
				$out = 'd:' . $this->until( ';', '/^(?:[+-]?(?:\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)|NAN|-?INF)$/' ) . ';';
				break;
			case 'r':
			case 'R':
				$this->expect( ':' );
				$out = $t . ':' . $this->until( ';', '/^\d+$/' ) . ';';
				break;
			case 's':
				$this->expect( ':' );
				$s = $this->lenstr();
				$this->expect( ';' );
				if ( ! $is_key ) {
					$s = (string) ( $this->cb )( $s );
				}
				$out = 's:' . strlen( $s ) . ':"' . $s . '";';
				break;
			case 'E':
				$this->expect( ':' );
				$s = $this->lenstr();
				$this->expect( ';' );
				$out = 'E:' . strlen( $s ) . ':"' . $s . '";';
				break;
			case 'a':
				$this->expect( ':' );
				$n = (int) $this->until( ':', '/^\d+$/' );
				$this->expect( '{' );
				$out = 'a:' . $n . ':{';
				for ( $k = 0; $k < $n; $k++ ) {
					$out .= $this->value( true ) . $this->value();
				}
				$this->expect( '}' );
				$out .= '}';
				break;
			case 'O':
				$this->expect( ':' );
				$class = $this->lenstr();
				$this->expect( ':' );
				$n = (int) $this->until( ':', '/^\d+$/' );
				$this->expect( '{' );
				$out = 'O:' . strlen( $class ) . ':"' . $class . '":' . $n . ':{';
				for ( $k = 0; $k < $n; $k++ ) {
					$out .= $this->value( true ) . $this->value();
				}
				$this->expect( '}' );
				$out .= '}';
				break;
			case 'C':
				$this->expect( ':' );
				$class = $this->lenstr();
				$this->expect( ':' );
				$len = (int) $this->until( ':', '/^\d+$/' );
				$this->expect( '{' );
				$raw      = substr( $this->in, $this->i, $len );
				$this->i += $len;
				$this->expect( '}' );
				foreach ( $this->needles as $n ) {
					if ( '' !== $n && str_contains( $raw, $n ) ) {
						$this->opaque_hit = true;
					}
				}
				$out = 'C:' . strlen( $class ) . ':"' . $class . '":' . $len . ':{' . $raw . '}';
				break;
			default:
				$this->fail();
				$out = '';
		}
		if ( $is_key && ! in_array( $t, array( 'i', 's' ), true ) ) {
			$this->fail();
		}
		--$this->depth;
		return $out;
	}
}
