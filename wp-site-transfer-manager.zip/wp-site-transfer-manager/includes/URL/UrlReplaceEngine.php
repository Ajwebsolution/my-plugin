<?php
/**
 * Database URL scanner / dry run / replacer (resumable state machine).
 *
 * Modes:
 *   scan     count matching rows/values per table (read-only)
 *   dry_run  compute every replacement, validate it and collect samples (read-only)
 *   replace  safety backup → replace in batches → verify remaining references
 *
 * Rows are pre-filtered with LIKE on all text columns, walked by primary key,
 * and (in replace mode) each batch of UPDATEs is committed atomically together
 * with the job checkpoint, so a killed request never re-applies a batch.
 * Tables without a primary key are reported, never modified.
 *
 * @package WSTM\URL
 */

namespace WSTM\URL;

use WSTM\Core\WstmException;
use WSTM\Database\Database;
use WSTM\Database\SqlEscaper;
use WSTM\Database\TableScanner;

defined( 'ABSPATH' ) || exit;

/**
 * URL replace engine.
 */
class UrlReplaceEngine {

	public const MODES       = array( 'scan', 'dry_run', 'replace' );
	public const MAX_SAMPLES = 40;
	private const TEXT_RE    = '/^(char|varchar|tinytext|text|mediumtext|longtext|json)\b/i';

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var TableScanner
	 */
	private TableScanner $scanner;

	/**
	 * Constructor.
	 *
	 * @param Database     $db      Database.
	 * @param TableScanner $scanner Scanner.
	 */
	public function __construct( Database $db, TableScanner $scanner ) {
		$this->db = $db;
		$this->scanner = $scanner;
	}

	/**
	 * Normalise and validate replacement pairs.
	 *
	 * @param array $pairs Raw [[old,new],...] or [{old,new}].
	 * @throws WstmException On invalid input.
	 */
	public static function clean_pairs( array $pairs ): array {
		$out = array();
		foreach ( $pairs as $p ) {
			$old = trim( (string) ( $p['old'] ?? $p[0] ?? '' ) );
			$new = trim( (string) ( $p['new'] ?? $p[1] ?? '' ) );
			if ( '' === $old && '' === $new ) {
				continue;
			}
			if ( strlen( $old ) < 4 ) {
				throw new WstmException( 'bad_pair', 'The text to search for is too short.', array( 'why' => '"' . $old . '" would match too much.', 'action' => 'Use a full URL such as https://old-site.com' ) );
			}
			if ( $old === $new ) {
				continue;
			}
			if ( str_contains( $old, "\0" ) || str_contains( $new, "\0" ) || strlen( $old ) > 2000 || strlen( $new ) > 2000 ) {
				throw new WstmException( 'bad_pair', 'Invalid search or replacement text.' );
			}
			$out[] = array( rtrim( $old, '/' ) === $old ? $old : rtrim( $old, '/' ), rtrim( $new, '/' ) === $new ? $new : rtrim( $new, '/' ) );
		}
		if ( ! $out ) {
			throw new WstmException( 'bad_pair', 'Enter at least one old → new URL pair.' );
		}
		return $out;
	}

	/**
	 * Initial state.
	 *
	 * @param array $o mode, pairs, tables[], skip_guid, url_encoded, safety_file.
	 */
	public static function init_state( array $o ): array {
		return array(
			'mode'        => in_array( $o['mode'] ?? '', self::MODES, true ) ? $o['mode'] : 'scan',
			'pairs'       => self::clean_pairs( (array) $o['pairs'] ),
			'requested'   => array_values( array_map( 'strval', (array) ( $o['tables'] ?? array() ) ) ),
			'explicit'    => ! empty( $o['explicit_tables'] ), // Process exactly these tables (e.g. temporary import tables).
			'guid_tables' => array_values( (array) ( $o['guid_tables'] ?? array() ) ),
			'skip_guid'   => ! array_key_exists( 'skip_guid', $o ) || ! empty( $o['skip_guid'] ),
			'url_encoded' => ! empty( $o['url_encoded'] ),
			'batch'       => max( 50, min( 2000, (int) ( $o['batch'] ?? 500 ) ) ),
			'safety_file' => $o['safety_file'] ?? null,
			'safety'      => null,
			'stage'       => 'prepare',
			'tables'      => array(),
			't'           => 0,
			'cursor'      => null,
			'report'      => array(),
			'totals'      => array( 'rows' => 0, 'values' => 0, 'serialized' => 0, 'json' => 0, 'plain' => 0, 'replacements' => 0, 'unparseable' => 0, 'opaque' => 0 ),
			'samples'     => array(),
			'remaining'   => array(),
			'vi'          => 0,
			'warnings'    => array(),
		);
	}

	/**
	 * One slice.
	 *
	 * @param array         $s        State.
	 * @param int           $deadline Deadline.
	 * @param callable|null $commit   fn(array $state) persisting the checkpoint (replace mode).
	 * @param callable|null $safety   fn(?array $st, int $dl): array running the safety backup.
	 * @throws WstmException On failure.
	 */
	public function slice( array $s, int $deadline, ?callable $commit = null, ?callable $safety = null ): array {
		switch ( $s['stage'] ) {
			case 'prepare':
				$s          = $this->prepare( $s );
				$s['stage'] = ( 'replace' === $s['mode'] && $s['safety_file'] ) ? 'safety' : 'process';
				return $s;

			case 'safety':
				$s['safety'] = $safety( $s['safety'], $deadline );
				if ( 'done' === ( $s['safety']['stage'] ?? '' ) ) {
					$s['stage'] = 'process';
				}
				return $s;

			case 'process':
				do {
					if ( $s['t'] >= count( $s['tables'] ) ) {
						$s['stage'] = 'replace' === $s['mode'] ? 'verify' : 'done';
						return $s;
					}
					$s = $this->batch( $s, $commit );
				} while ( time() < $deadline );
				return $s;

			case 'verify':
				return $this->verify( $s, $deadline );
		}
		return $s;
	}

	/**
	 * Collect candidate tables/columns.
	 *
	 * @param array $s State.
	 */
	private function prepare( array $s ): array {
		$base = $this->db->base_prefix();
		$want = $s['requested'] ? array_flip( $s['requested'] ) : null;
		foreach ( $this->scanner->tables() as $t ) {
			if ( ! empty( $s['explicit'] ) ) {
				if ( ! isset( $want[ $t['name'] ] ) || $t['is_view'] ) {
					continue;
				}
			} elseif ( 'site' !== $t['group'] || $t['is_view'] || ( null !== $want && ! isset( $want[ $t['name'] ] ) ) ) {
				continue;
			}
			$cols = array();
			foreach ( $this->scanner->columns( $t['name'] ) as $c => $type ) {
				if ( ! preg_match( self::TEXT_RE, $type ) ) {
					continue;
				}
				if ( $s['skip_guid'] && 'guid' === $c && ( preg_match( '/^' . preg_quote( $base, '/' ) . '(\d+_)?posts$/', $t['name'] ) || in_array( $t['name'], $s['guid_tables'] ?? array(), true ) ) ) {
					continue;
				}
				$cols[] = $c;
			}
			if ( ! $cols ) {
				continue;
			}
			$pk = $this->scanner->primary_key( $t['name'] );
			if ( ! $pk ) {
				$s['warnings'][] = sprintf( 'Table %s has no primary key and was not processed.', $t['name'] );
				continue;
			}
			$types = $this->scanner->columns( $t['name'] );
			$s['tables'][] = array(
				'name'   => $t['name'],
				'cols'   => $cols,
				'pk'     => $pk,
				'keyset' => 1 === count( $pk ) && preg_match( '/^(tinyint|smallint|mediumint|int|integer|bigint)\b/i', $types[ $pk[0] ] ?? '' ) ? $pk[0] : null,
				'est'    => $t['rows'],
			);
		}
		return $s;
	}

	/**
	 * LIKE pre-filter for a table.
	 *
	 * @param array         $t        Table.
	 * @param ValueReplacer $replacer Replacer.
	 */
	private function where_like( array $t, ValueReplacer $replacer ): string {
		$wpdb  = $this->db->wpdb();
		$parts = array();
		foreach ( $t['cols'] as $c ) {
			foreach ( $replacer->needles() as $n ) {
				$parts[] = SqlEscaper::identifier( $c ) . " LIKE '" . esc_sql( '%' . $wpdb->esc_like( $n ) . '%' ) . "'";
			}
		}
		return '(' . implode( ' OR ', $parts ) . ')';
	}

	/**
	 * Process one batch of the current table.
	 *
	 * @param array         $s      State.
	 * @param callable|null $commit Checkpoint commit (replace mode).
	 * @throws WstmException On update failure.
	 */
	private function batch( array $s, ?callable $commit ): array {
		$t        = $s['tables'][ $s['t'] ];
		$replacer = new ValueReplacer( $s['pairs'], $s['url_encoded'] );
		$q        = SqlEscaper::identifier( $t['name'] );
		$sel      = implode( ',', array_map( array( SqlEscaper::class, 'identifier' ), array_values( array_unique( array_merge( $t['pk'], $t['cols'] ) ) ) ) );
		$where    = $this->where_like( $t, $replacer );
		$limit    = (int) $s['batch'];

		if ( $t['keyset'] ) {
			$k   = SqlEscaper::identifier( $t['keyset'] );
			$sql = "SELECT {$sel} FROM {$q} WHERE {$where}" . ( null !== $s['cursor'] ? " AND {$k} > " . $s['cursor'] : '' ) . " ORDER BY {$k} LIMIT {$limit}";
		} else {
			$order = implode( ',', array_map( array( SqlEscaper::class, 'identifier' ), $t['pk'] ) );
			$sql   = "SELECT {$sel} FROM {$q} WHERE {$where} ORDER BY {$order} LIMIT {$limit} OFFSET " . (int) $s['cursor'];
		}
		$rows = $this->db->get_results( $sql );

		$r       = $s['report'][ $t['name'] ] ?? array( 'rows' => 0, 'values' => 0, 'serialized' => 0, 'json' => 0, 'plain' => 0, 'replacements' => 0, 'unparseable' => 0, 'opaque' => 0 );
		$updates = array();
		foreach ( $rows as $row ) {
			$changes = array();
			foreach ( $t['cols'] as $c ) {
				$v = $row[ $c ];
				if ( null === $v || ! $replacer->matches( (string) $v ) ) {
					continue;
				}
				$new  = $replacer->replace( (string) $v );
				$last = $replacer->last;
				if ( 'unparseable' === $last['error'] ) {
					++$r['unparseable'];
					$s = $this->warn( $s, sprintf( 'Corrupt serialized value left unchanged: %s.%s (%s)', $t['name'], $c, $this->pk_label( $t, $row ) ) );
					continue;
				}
				if ( 'opaque' === $last['error'] ) {
					++$r['opaque'];
					$s = $this->warn( $s, sprintf( 'Custom-serialized object not modified: %s.%s (%s)', $t['name'], $c, $this->pk_label( $t, $row ) ) );
				}
				if ( $new === $v ) {
					continue;
				}
				// Self-check: serialized output must stay structurally valid.
				if ( 'serialized' === $last['kind'] && null === ( new SerializedWalker() )->rewrite( $new, static fn( $x ) => $x ) ) {
					throw new WstmException( 'replace_invalid', 'Replacement produced invalid serialized data.', array( 'what' => $t['name'] . '.' . $c, 'why' => 'Internal safety check failed for ' . $this->pk_label( $t, $row ), 'action' => 'Report this; no data was changed for this row.' ) );
				}
				++$r['values'];
				++$r[ $last['kind'] ];
				$r['replacements'] += $last['count'];
				$changes[ $c ]      = $new;
				if ( 'dry_run' === $s['mode'] && count( $s['samples'] ) < self::MAX_SAMPLES ) {
					$s['samples'][] = $this->sample( $t['name'], $c, $this->pk_label( $t, $row ), (string) $v, $new, $replacer, $last['kind'] );
				}
			}
			if ( $changes ) {
				++$r['rows'];
				$updates[] = array( $row, $changes );
			}
		}

		$n = count( $rows );
		if ( $t['keyset'] ) {
			if ( $n ) {
				$s['cursor'] = (string) $rows[ $n - 1 ][ $t['keyset'] ];
			}
		} elseif ( 'replace' === $s['mode'] ) {
			$s['cursor'] = (int) $s['cursor'] + $n - count( $updates ); // Updated rows leave the filtered set.
		} else {
			$s['cursor'] = (int) $s['cursor'] + $n;
		}
		$s['report'][ $t['name'] ] = $r;
		foreach ( array( 'values', 'serialized', 'json', 'plain', 'replacements', 'unparseable', 'opaque' ) as $k ) {
			$s['totals'][ $k ] = array_sum( array_column( $s['report'], $k ) );
		}
		$s['totals']['rows'] = array_sum( array_column( $s['report'], 'rows' ) );
		if ( $n < $limit ) {
			++$s['t'];
			$s['cursor'] = null;
		}

		if ( 'replace' === $s['mode'] && $updates ) {
			$this->apply( $t, $updates, $s, $commit );
		}
		return $s;
	}

	/**
	 * Apply a batch of updates atomically with the checkpoint.
	 *
	 * @param array         $t       Table.
	 * @param array         $updates [row, changes][].
	 * @param array         $s       New state (committed with the batch).
	 * @param callable|null $commit  Commit callback.
	 * @throws WstmException On failure (batch rolled back).
	 */
	private function apply( array $t, array $updates, array $s, ?callable $commit ): void {
		$wpdb = $this->db->wpdb();
		$this->db->raw_query( 'START TRANSACTION' );
		try {
			foreach ( $updates as [ $row, $changes ] ) {
				$where = array();
				foreach ( $t['pk'] as $k ) {
					$where[ $k ] = $row[ $k ];
				}
				$wpdb->last_error = '';
				if ( false === $wpdb->update( $t['name'], $changes, $where ) || '' !== $wpdb->last_error ) { // phpcs:ignore WordPress.DB
					throw new WstmException( 'update_failed', 'Updating a row failed.', array( 'what' => 'URL replace in ' . $t['name'], 'why' => $wpdb->last_error ?: 'The value contains characters the table charset cannot store.', 'resumable' => true, 'action' => 'This batch was rolled back. Review the error, then resume.' ) );
				}
			}
			if ( $commit ) {
				$commit( $s );
			}
			$this->db->raw_query( 'COMMIT' );
		} catch ( \Throwable $e ) {
			$this->db->raw_query( 'ROLLBACK' );
			throw $e;
		}
	}

	/**
	 * Count remaining references to the old URLs after replacement.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 */
	private function verify( array $s, int $deadline ): array {
		$plain = new ValueReplacer( $s['pairs'] );
		while ( $s['vi'] < count( $s['tables'] ) ) {
			$t     = $s['tables'][ $s['vi'] ];
			$count = (int) $this->db->get_var( 'SELECT COUNT(*) FROM ' . SqlEscaper::identifier( $t['name'] ) . ' WHERE ' . $this->where_like( $t, $plain ) );
			if ( $count ) {
				$s['remaining'][ $t['name'] ] = $count;
			}
			++$s['vi'];
			if ( time() >= $deadline ) {
				return $s;
			}
		}
		if ( $s['remaining'] ) {
			$s['warnings'][] = sprintf( '%d row(s) still contain the old text — usually longer domains (e.g. old-site.com.au), corrupt serialized values or custom objects that were intentionally left unchanged.', array_sum( $s['remaining'] ) );
		}
		wp_cache_flush();
		$s['stage'] = 'done';
		return $s;
	}

	/**
	 * Build a before/after sample around the first match.
	 *
	 * @param string        $table    Table.
	 * @param string        $col      Column.
	 * @param string        $id       Row label.
	 * @param string        $before   Before.
	 * @param string        $after    After.
	 * @param ValueReplacer $replacer Replacer.
	 * @param string        $kind     Kind.
	 */
	private function sample( string $table, string $col, string $id, string $before, string $after, ValueReplacer $replacer, string $kind ): array {
		$pos = PHP_INT_MAX;
		foreach ( $replacer->needles() as $n ) {
			$p = strpos( $before, $n );
			if ( false !== $p ) {
				$pos = min( $pos, $p );
			}
		}
		$start = max( 0, $pos - 50 );
		return array(
			'table'  => $table,
			'column' => $col,
			'row'    => $id,
			'kind'   => $kind,
			'before' => mb_strcut( $before, $start, 200 ),
			'after'  => mb_strcut( $after, $start, 200 ),
		);
	}

	/**
	 * Row label from primary key.
	 *
	 * @param array $t   Table.
	 * @param array $row Row.
	 */
	private function pk_label( array $t, array $row ): string {
		return implode( ',', array_map( static fn( $k ) => $k . '=' . $row[ $k ], $t['pk'] ) );
	}

	/**
	 * Bounded warning.
	 *
	 * @param array  $s   State.
	 * @param string $msg Message.
	 */
	private function warn( array $s, string $msg ): array {
		if ( count( $s['warnings'] ) < 100 ) {
			$s['warnings'][] = $msg;
		}
		return $s;
	}

	/**
	 * Progress 0–100.
	 *
	 * @param array $s State.
	 */
	public static function progress( array $s ): float {
		$n = max( 1, count( $s['tables'] ) );
		switch ( $s['stage'] ) {
			case 'prepare':
				return 0;
			case 'safety':
				return 2;
			case 'process':
				return round( ( 'replace' === $s['mode'] ? 10 : 0 ) + ( 'replace' === $s['mode'] ? 80 : 99 ) * $s['t'] / $n, 2 );
			case 'verify':
				return round( 90 + 9 * $s['vi'] / $n, 2 );
			default:
				return 100;
		}
	}
}
