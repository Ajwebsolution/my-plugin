<?php
/**
 * Serialization-safe, JSON-safe, boundary-aware search & replace for one value.
 *
 * For each pair old → new, these forms are replaced:
 *   - literal                          https://dev.example.com
 *   - JSON-escaped slashes            https:\/\/dev.example.com   (Elementor, block attributes)
 *   - URL-encoded (optional)           https%3A%2F%2Fdev.example.com
 * A match is skipped when the host continues after it (so "example.com" never
 * rewrites "example.com.au" or "example.community").
 *
 * Serialized values are rewritten structurally (lengths recalculated, nested
 * serialized/JSON strings handled recursively). Values that look serialized but
 * do not parse are left untouched and reported, never string-replaced.
 *
 * @package WSTM\URL
 */

namespace WSTM\URL;

defined( 'ABSPATH' ) || exit;

/**
 * Value replacer.
 */
final class ValueReplacer {

	/** Compiled [regex, replacement] list. @var array<int,array{0:string,1:string}> */
	private array $rules = array();

	/** Literal needles for fast pre-checks. @var string[] */
	private array $needles = array();

	/** Stats of the last replace() call. */
	public array $last = array();

	/** Walker. */
	private SerializedWalker $walker;

	/**
	 * Constructor.
	 *
	 * @param array<int,array{0:string,1:string}> $pairs       old => new pairs.
	 * @param bool                                $url_encoded Also replace URL-encoded forms.
	 */
	public function __construct( array $pairs, bool $url_encoded = false ) {
		$this->walker = new SerializedWalker();
		// Longest first so "https://a.com/sub" wins over "https://a.com".
		usort( $pairs, static fn( $a, $b ) => strlen( $b[0] ) <=> strlen( $a[0] ) );
		foreach ( $pairs as [ $old, $new ] ) {
			$old = (string) $old;
			$new = (string) $new;
			if ( '' === $old || $old === $new ) {
				continue;
			}
			$forms = array( array( $old, $new ) );
			if ( str_contains( $old, '/' ) ) {
				$forms[] = array( str_replace( '/', '\\/', $old ), str_replace( '/', '\\/', $new ) );
			}
			if ( $url_encoded ) {
				$forms[] = array( rawurlencode( $old ), rawurlencode( $new ) );
			}
			foreach ( $forms as [ $o, $n ] ) {
				// The host must not continue after the match (letters, digits, "-" or ".x").
				$tail            = preg_match( '/[A-Za-z0-9]$/', $o ) ? '(?![A-Za-z0-9_-]|\.[A-Za-z0-9])' : '';
				$this->rules[]   = array( '~' . preg_quote( $o, '~' ) . $tail . '~', $n );
				$this->needles[] = $o;
			}
		}
		$this->needles = array_values( array_unique( $this->needles ) );
	}

	/** Literal search forms (for SQL LIKE pre-filtering). */
	public function needles(): array {
		return $this->needles;
	}

	/** Whether any rule exists. */
	public function active(): bool {
		return (bool) $this->rules;
	}

	/**
	 * Quick containment check.
	 *
	 * @param string $value Value.
	 */
	public function matches( string $value ): bool {
		foreach ( $this->needles as $n ) {
			if ( str_contains( $value, $n ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Plain text replacement with boundary checks.
	 *
	 * @param string $value Value.
	 * @param int    $count Replacements (by reference).
	 */
	private function text( string $value, int &$count ): string {
		foreach ( $this->rules as [ $re, $rep ] ) {
			$value  = (string) preg_replace_callback( $re, static fn() => $rep, $value, -1, $n );
			$count += $n;
		}
		return $value;
	}

	/**
	 * Replace inside one value.
	 *
	 * @param string $value Value.
	 * @return string New value (identical if nothing changed).
	 */
	public function replace( string $value ): string {
		$this->last = array( 'kind' => 'plain', 'count' => 0, 'error' => null );
		if ( ! $this->matches( $value ) ) {
			return $value;
		}
		$count = 0;
		$out   = $this->replace_inner( $value, $count, 0 );
		$this->last['count'] = $count;
		return $out;
	}

	/**
	 * Recursive replacement.
	 *
	 * @param string $value Value.
	 * @param int    $count Count.
	 * @param int    $depth Depth.
	 */
	private function replace_inner( string $value, int &$count, int $depth ): string {
		if ( $depth > 8 || ! $this->matches( $value ) ) {
			return $value;
		}
		if ( SerializedWalker::looks_serialized( $value ) ) {
			$walker = new SerializedWalker();
			$res    = $walker->rewrite(
				$value,
				function ( string $s ) use ( &$count, $depth ) {
					return $this->replace_inner( $s, $count, $depth + 1 );
				},
				$this->needles
			);
			if ( null !== $res ) {
				if ( 0 === $depth ) {
					$this->last['kind'] = 'serialized';
				}
				if ( $walker->opaque_hit ) {
					$this->last['error'] = 'opaque';
				}
				return $res;
			}
			if ( function_exists( 'is_serialized' ) && is_serialized( $value ) ) {
				// Looks serialized but is corrupt: never risk a raw replace.
				$this->last['error'] = 'unparseable';
				return $value;
			}
		}
		$trim = ltrim( $value );
		if ( 0 === $depth && ( str_starts_with( $trim, '{' ) || str_starts_with( $trim, '[' ) ) && null !== json_decode( $value ) ) {
			$this->last['kind'] = 'json';
		}
		return $this->text( $value, $count );
	}
}
