<?php
/**
 * WSTM streaming archive format (used by .wpmig packages and file archives).
 *
 * Designed for resumable, append-only writing and streaming extraction on
 * shared hosting — no central directory, no whole-file buffering, no 4 GB limits.
 *
 *   magic     "WSTMARC1\n"
 *   record    type(1 byte) + length(4 bytes, big-endian) + JSON header
 *     'E'  entry header  {"path","type":"f|d","size","mtime","mode","chunk"}  followed by <size> raw bytes
 *     'T'  entry trailer {"hashes":[sha256 per chunk],"sha256":hash-list digest,"ok":bool}
 *     'Z'  end record    {"entries","bytes","seal":sha256 of every byte before this record (block hash list)}
 *
 * @package WSTM\Archive
 */

namespace WSTM\Archive;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Format constants and record helpers.
 */
final class Archive {

	public const MAGIC         = "WSTMARC1\n";
	public const MAX_HEADER    = 1048576;
	public const DEFAULT_CHUNK = 5242880; // 5 MB.

	/**
	 * Encode a record.
	 *
	 * @param string $type   E|T|Z.
	 * @param array  $header Header.
	 */
	public static function record( string $type, array $header ): string {
		$json = wp_json_encode( $header, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return $type . pack( 'N', strlen( $json ) ) . $json;
	}

	/**
	 * Read a record at the current handle position.
	 *
	 * @param resource $fh Handle.
	 * @return array{type:string,header:array,length:int}|null Null at EOF.
	 * @throws WstmException On malformed data.
	 */
	public static function read_record( $fh ): ?array {
		$head = fread( $fh, 5 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( '' === $head || false === $head ) {
			return null;
		}
		if ( 5 !== strlen( $head ) || ! in_array( $head[0], array( 'E', 'T', 'Z' ), true ) ) {
			throw self::corrupt( 'Invalid record marker' );
		}
		$len = unpack( 'N', substr( $head, 1 ) )[1];
		if ( $len < 2 || $len > self::MAX_HEADER ) {
			throw self::corrupt( 'Invalid record length' );
		}
		$json = fread( $fh, $len ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = is_string( $json ) && strlen( $json ) === $len ? json_decode( $json, true ) : null;
		if ( ! is_array( $data ) ) {
			throw self::corrupt( 'Unreadable record header' );
		}
		return array(
			'type'   => $head[0],
			'header' => $data,
			'length' => 5 + $len,
		);
	}

	/**
	 * Corruption error.
	 *
	 * @param string $why Why.
	 */
	public static function corrupt( string $why ): WstmException {
		return new WstmException(
			'archive_corrupt',
			'The archive is corrupted or incomplete.',
			array(
				'what'   => 'Archive read',
				'why'    => $why,
				'action' => 'Re-create or re-upload the package. Nothing was changed.',
			)
		);
	}

	/**
	 * Resolve chunk size from the "chunk_size" setting (MB or "auto").
	 *
	 * @param string|int $setting Setting.
	 */
	public static function chunk_bytes( $setting ): int {
		$mb = (int) $setting;
		return $mb > 0 ? $mb * 1048576 : self::DEFAULT_CHUNK;
	}
}
