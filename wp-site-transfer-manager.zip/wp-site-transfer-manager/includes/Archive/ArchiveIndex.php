<?php
/**
 * Fast archive walker: reads headers and trailers only, seeking over data.
 *
 * @package WSTM\Archive
 */

namespace WSTM\Archive;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Archive index.
 */
final class ArchiveIndex {

	/**
	 * Iterate entries from a record offset.
	 *
	 * @param string $archive Archive path.
	 * @param int    $offset  Record offset (default: after magic).
	 * @return \Generator<int,array> yields entry arrays with path,type,size,data_at,next,ok,sha256; returns the Z header.
	 * @throws WstmException On corruption.
	 */
	public static function entries( string $archive, int $offset = 0 ): \Generator {
		$fh = fopen( $archive, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			throw new WstmException( 'io_error', 'Could not open the archive.', array( 'why' => basename( $archive ) ) );
		}
		try {
			$size = (int) fstat( $fh )['size'];
			if ( 0 === $offset ) {
				if ( Archive::MAGIC !== fread( $fh, strlen( Archive::MAGIC ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
					throw Archive::corrupt( 'Not a WSTM archive (bad magic)' );
				}
				$offset = strlen( Archive::MAGIC );
			}
			while ( true ) {
				fseek( $fh, $offset );
				$rec = Archive::read_record( $fh );
				if ( null === $rec ) {
					throw Archive::corrupt( 'Archive ends without an end record (truncated)' );
				}
				if ( 'Z' === $rec['type'] ) {
					return $rec['header'] + array( 'z_offset' => $offset, 'z_end' => $offset + $rec['length'] );
				}
				if ( 'E' !== $rec['type'] ) {
					throw Archive::corrupt( 'Unexpected record at byte ' . $offset );
				}
				$h       = $rec['header'];
				$sz      = (int) ( $h['size'] ?? -1 );
				$data_at = $offset + $rec['length'];
				if ( $sz < 0 || $data_at + $sz > $size ) {
					throw Archive::corrupt( 'Entry data exceeds archive size' );
				}
				fseek( $fh, $data_at + $sz );
				$t = Archive::read_record( $fh );
				if ( null === $t || 'T' !== $t['type'] ) {
					throw Archive::corrupt( 'Missing trailer after ' . ( $h['path'] ?? '?' ) );
				}
				$next = $data_at + $sz + $t['length'];
				yield $offset => array(
					'path'    => (string) ( $h['path'] ?? '' ),
					'type'    => (string) ( $h['type'] ?? '' ),
					'size'    => $sz,
					'mtime'   => (int) ( $h['mtime'] ?? 0 ),
					'data_at' => $data_at,
					'next'    => $next,
					'ok'      => ! empty( $t['header']['ok'] ),
					'sha256'  => (string) ( $t['header']['sha256'] ?? '' ),
				);
				$offset = $next;
			}
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}
}
