<?php
/**
 * Resumable, verifying archive extractor.
 *
 * - Every entry path is validated (no traversal, absolute or drive paths) and
 *   resolved inside its destination with symlink-escape protection.
 * - Data is written to "<dest>.wstmpart", hashed chunk by chunk against the
 *   entry trailer, and renamed into place only when verified.
 * - A mapper callback decides where each entry goes (or skips it), so the
 *   same extractor serves packages, staging and restores.
 *
 * State: archive, offset (next record), entries, bytes, done, skipped, warnings,
 *        cur => null | {header, data_at, written, hashes[], dest, tmp}
 *
 * @package WSTM\Archive
 */

namespace WSTM\Archive;

use WSTM\Core\WstmException;
use WSTM\Database\BlockHasher;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Extractor.
 */
final class ArchiveExtractor {

	/**
	 * Initial state.
	 *
	 * @param string $archive Archive path.
	 */
	public static function init_state( string $archive ): array {
		return array(
			'archive'  => $archive,
			'offset'   => strlen( Archive::MAGIC ),
			'entries'  => 0,
			'bytes'    => 0,
			'skipped'  => 0,
			'done'     => false,
			'cur'      => null,
			'end'      => null,
			'warnings' => array(),
		);
	}

	/**
	 * Extract until done or deadline.
	 *
	 * @param array    $s        State.
	 * @param callable $mapper   fn(array $header): ?array{0:string base dir,1:string relative path} — null = skip.
	 * @param int      $deadline Deadline.
	 * @throws WstmException On corruption, unsafe paths or I/O failure.
	 */
	public static function step( array $s, callable $mapper, int $deadline ): array {
		$fh = fopen( $s['archive'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			throw new WstmException( 'io_error', 'Could not open the archive.', array( 'resumable' => true ) );
		}
		try {
			if ( strlen( Archive::MAGIC ) === $s['offset'] ) {
				if ( Archive::MAGIC !== fread( $fh, strlen( Archive::MAGIC ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
					throw Archive::corrupt( 'Not a WSTM archive (bad magic)' );
				}
			}
			do {
				if ( null === $s['cur'] ) {
					fseek( $fh, $s['offset'] );
					$rec = Archive::read_record( $fh );
					if ( null === $rec ) {
						throw Archive::corrupt( 'Archive ends without an end record (truncated)' );
					}
					if ( 'Z' === $rec['type'] ) {
						$s['end']  = $rec['header'];
						$s['done'] = true;
						break;
					}
					if ( 'E' !== $rec['type'] ) {
						throw Archive::corrupt( 'Unexpected trailer record' );
					}
					$h        = $rec['header'];
					$h['path'] = PathGuard::safe_relative( (string) ( $h['path'] ?? '' ) );
					$size     = (int) ( $h['size'] ?? -1 );
					$chunk    = (int) ( $h['chunk'] ?? 0 );
					if ( $size < 0 || $chunk < 1 || ! in_array( $h['type'] ?? '', array( 'f', 'd' ), true ) ) {
						throw Archive::corrupt( 'Invalid entry header for ' . $h['path'] );
					}
					$data_at = $s['offset'] + $rec['length'];
					$map     = $mapper( $h );
					$dest    = null;
					if ( null !== $map ) {
						[ $base, $rel ] = $map;
						if ( ! is_dir( $base ) && ! wp_mkdir_p( $base ) ) {
							throw new WstmException( 'io_error', 'Could not create extraction directory.', array( 'resumable' => true ) );
						}
						$dest = PathGuard::resolve_within( $base, $rel );
					}
					$s['cur'] = array(
						'h'       => $h,
						'data_at' => $data_at,
						'written' => 0,
						'hashes'  => array(),
						'dest'    => $dest,
					);
				}

				$s = self::continue_entry( $s, $fh, $deadline );
			} while ( time() < $deadline && ! $s['done'] );
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		return $s;
	}

	/**
	 * Copy/verify the current entry.
	 *
	 * @param array    $s        State.
	 * @param resource $fh       Archive handle.
	 * @param int      $deadline Deadline.
	 * @throws WstmException On failure.
	 */
	private static function continue_entry( array $s, $fh, int $deadline ): array {
		$c    = $s['cur'];
		$h    = $c['h'];
		$size = (int) $h['size'];
		$dest = $c['dest'];

		if ( 'd' === $h['type'] ) {
			if ( $dest && ! is_dir( $dest ) && ! wp_mkdir_p( $dest ) ) {
				throw new WstmException( 'io_error', 'Could not create directory ' . $h['path'], array( 'resumable' => true ) );
			}
		} else {
			$out = null;
			if ( $dest ) {
				$tmp = $dest . '.wstmpart';
				if ( ! is_dir( dirname( $dest ) ) && ! wp_mkdir_p( dirname( $dest ) ) ) {
					throw new WstmException( 'io_error', 'Could not create directory for ' . $h['path'], array( 'resumable' => true ) );
				}
				if ( is_link( $tmp ) ) {
					throw new WstmException( 'symlink_target', 'Refusing to write through a symlink.', array( 'why' => $h['path'] ) );
				}
				$out = fopen( $tmp, 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( ! $out ) {
					throw new WstmException( 'io_error', 'Could not write ' . $h['path'], array( 'resumable' => true, 'action' => 'Check folder permissions, then resume.' ) );
				}
				ftruncate( $out, $c['written'] );
				fseek( $out, $c['written'] );
			}
			fseek( $fh, $c['data_at'] + $c['written'] );
			try {
				while ( $c['written'] < $size ) {
					$want = (int) min( (int) $h['chunk'], $size - $c['written'] );
					$data = '';
					while ( strlen( $data ) < $want ) {
						$part = fread( $fh, $want - strlen( $data ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
						if ( false === $part || '' === $part ) {
							throw Archive::corrupt( 'Unexpected end of data in ' . $h['path'] );
						}
						$data .= $part;
					}
					if ( $out && fwrite( $out, $data ) !== $want ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
						throw new WstmException( 'write_failed', 'Writing extracted data failed.', array( 'why' => 'Disk full?', 'resumable' => true, 'action' => 'Free disk space, then resume.' ) );
					}
					$c['hashes'][] = hash( 'sha256', $data );
					$c['written'] += $want;
					if ( time() >= $deadline && $c['written'] < $size ) {
						break;
					}
				}
			} finally {
				if ( $out ) {
					fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				}
			}
			if ( $c['written'] < $size ) {
				$s['cur'] = $c;
				return $s;
			}
		}

		// Trailer.
		fseek( $fh, $c['data_at'] + $size );
		$rec = Archive::read_record( $fh );
		if ( null === $rec || 'T' !== $rec['type'] ) {
			throw Archive::corrupt( 'Missing trailer for ' . $h['path'] );
		}
		$t = $rec['header'];
		if ( 'f' === $h['type'] ) {
			if ( ( $t['hashes'] ?? null ) !== $c['hashes'] || BlockHasher::combine( $c['hashes'] ) !== ( $t['sha256'] ?? '' ) ) {
				if ( $dest ) {
					wp_delete_file( $dest . '.wstmpart' );
				}
				throw new WstmException( 'checksum_mismatch', 'A file in the archive failed checksum verification.', array( 'what' => 'Extract ' . $h['path'], 'why' => 'SHA-256 mismatch — the archive is corrupted.', 'action' => 'Re-create or re-upload the package.' ) );
			}
			if ( $dest ) {
				if ( empty( $t['ok'] ) ) {
					wp_delete_file( $dest . '.wstmpart' );
					$s = self::warn( $s, 'Skipped (changed while archiving on the source): ' . $h['path'] );
				} else {
					if ( ! @rename( $dest . '.wstmpart', $dest ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
						throw new WstmException( 'io_error', 'Could not move extracted file into place.', array( 'why' => $h['path'], 'resumable' => true, 'action' => 'Check permissions, then resume.' ) );
					}
					if ( ! empty( $h['mtime'] ) ) {
						@touch( $dest, (int) $h['mtime'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
					}
				}
			}
		}
		if ( $dest ) {
			++$s['entries'];
			$s['bytes'] += $size;
		} else {
			++$s['skipped'];
		}
		$s['offset'] = $c['data_at'] + $size + $rec['length'];
		$s['cur']    = null;
		return $s;
	}

	/**
	 * Bounded warning.
	 *
	 * @param array  $s   State.
	 * @param string $msg Message.
	 */
	private static function warn( array $s, string $msg ): array {
		if ( count( $s['warnings'] ) < 200 ) {
			$s['warnings'][] = $msg;
		}
		return $s;
	}

	/**
	 * Read an entry's full content (small entries only, e.g. manifest.json).
	 *
	 * @param string $archive Archive.
	 * @param string $path    Entry path.
	 * @param int    $max     Max bytes.
	 * @return string|null
	 * @throws WstmException On corruption.
	 */
	public static function read_entry( string $archive, string $path, int $max = 8388608 ): ?string {
		foreach ( ArchiveIndex::entries( $archive ) as $e ) {
			if ( $e['path'] === $path && 'f' === $e['type'] ) {
				if ( $e['size'] > $max ) {
					throw Archive::corrupt( 'Entry too large: ' . $path );
				}
				$fh = fopen( $archive, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				fseek( $fh, $e['data_at'] );
				$data = $e['size'] > 0 ? (string) fread( $fh, $e['size'] ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				return $data;
			}
		}
		return null;
	}
}
