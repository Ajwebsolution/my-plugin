<?php
/**
 * Resumable archive writer.
 *
 * State (persisted in the job checkpoint):
 *   file, committed (bytes known good), entries, bytes, chunk,
 *   cur => null | {path, abs, size, mtime, mode, offset, hashes[]}
 *
 * A large file is copied chunk by chunk across many requests; each chunk is
 * hashed so the trailer can be verified on extraction without re-reading.
 * On resume the archive is truncated to the committed size, discarding any
 * output from a killed request.
 *
 * @package WSTM\Archive
 */

namespace WSTM\Archive;

use WSTM\Core\WstmException;
use WSTM\Database\BlockHasher;

defined( 'ABSPATH' ) || exit;

/**
 * Writer.
 */
final class ArchiveWriter {

	/**
	 * Handle.
	 *
	 * @var resource
	 */
	private $fh;

	/** State. */
	private array $s;

	/** Last completed file entry. */
	private ?array $last = null;

	/** Current in-memory state. */
	public function state(): array {
		return $this->s;
	}

	/** Last completed file entry {path, sha256, ok} in this session. */
	public function last_entry(): ?array {
		return $this->last;
	}

	/** Path of the entry being copied, or null. */
	public function current_path(): ?string {
		return $this->s['cur']['path'] ?? null;
	}

	/**
	 * Initial state; creates the file with the magic header.
	 *
	 * @param string $file  Archive path.
	 * @param int    $chunk Chunk bytes.
	 * @throws WstmException On failure.
	 */
	public static function init_state( string $file, int $chunk = Archive::DEFAULT_CHUNK ): array {
		if ( false === file_put_contents( $file, Archive::MAGIC ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			throw new WstmException( 'io_error', 'Could not create the archive file.', array( 'why' => basename( $file ), 'resumable' => true ) );
		}
		return array(
			'file'      => $file,
			'committed' => strlen( Archive::MAGIC ),
			'entries'   => 0,
			'bytes'     => 0,
			'chunk'     => max( 65536, $chunk ),
			'cur'       => null,
			'sealed'    => false,
			'warnings'  => array(),
		);
	}

	/**
	 * Open for appending at the committed size.
	 *
	 * @param array $state State.
	 * @throws WstmException On failure.
	 */
	public function __construct( array $state ) {
		$this->s = $state;
		clearstatcache( true, $state['file'] );
		if ( ! is_file( $state['file'] ) ) {
			throw new WstmException( 'archive_missing', 'The partially written archive is missing.', array( 'why' => basename( $state['file'] ), 'action' => 'Cancel this job and start again.' ) );
		}
		$fh = fopen( $state['file'], 'r+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh || ! ftruncate( $fh, $state['committed'] ) || 0 !== fseek( $fh, $state['committed'] ) ) {
			throw new WstmException( 'io_error', 'Could not open the archive for writing.', array( 'resumable' => true ) );
		}
		$this->fh = $fh;
	}

	/**
	 * Write raw bytes.
	 *
	 * @param string $data Data.
	 * @throws WstmException On short write.
	 */
	private function put( string $data ): void {
		if ( '' !== $data && fwrite( $this->fh, $data ) !== strlen( $data ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			throw new WstmException( 'write_failed', 'Writing the archive failed.', array( 'why' => 'Short write — disk full or quota exceeded.', 'resumable' => true, 'action' => 'Free disk space, then resume.' ) );
		}
	}

	/**
	 * Whether an entry is in progress.
	 */
	public function busy(): bool {
		return null !== $this->s['cur'];
	}

	/**
	 * Begin a file entry (copied by continue_entry()).
	 *
	 * @param string $path Archive path.
	 * @param string $abs  Source file.
	 */
	public function begin_file( string $path, string $abs ): void {
		clearstatcache( true, $abs );
		$size = (int) @filesize( $abs ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$this->put(
			Archive::record(
				'E',
				array(
					'path'  => $path,
					'type'  => 'f',
					'size'  => $size,
					'mtime' => (int) @filemtime( $abs ), // phpcs:ignore WordPress.PHP.NoSilencedErrors
					'mode'  => @fileperms( $abs ) & 0777, // phpcs:ignore WordPress.PHP.NoSilencedErrors
					'chunk' => $this->s['chunk'],
				)
			)
		);
		$this->s['cur'] = array(
			'path'   => $path,
			'abs'    => $abs,
			'size'   => $size,
			'offset' => 0,
			'hashes' => array(),
			'ok'     => true,
		);
	}

	/**
	 * Copy chunks of the current entry until finished or deadline.
	 *
	 * @param int $deadline Deadline.
	 * @return bool True when the entry is complete.
	 */
	public function continue_entry( int $deadline ): bool {
		$c   = &$this->s['cur'];
		$src = @fopen( $c['abs'], 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		if ( $src ) {
			fseek( $src, $c['offset'] );
		}
		do {
			if ( $c['offset'] >= $c['size'] ) {
				break;
			}
			$want = (int) min( $this->s['chunk'], $c['size'] - $c['offset'] );
			$data = '';
			if ( $src ) {
				while ( strlen( $data ) < $want && ! feof( $src ) ) {
					$part = fread( $src, $want - strlen( $data ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( false === $part || '' === $part ) {
						break;
					}
					$data .= $part;
				}
			}
			if ( strlen( $data ) < $want ) {
				// File vanished or shrank while archiving: pad so the archive stays well-formed, mark entry bad.
				$data      .= str_repeat( "\0", $want - strlen( $data ) );
				$c['ok']    = false;
				if ( count( $this->s['warnings'] ) < 200 ) {
					$this->s['warnings'][] = 'File changed or became unreadable while archiving (will not be restored): ' . $c['path'];
				}
			}
			$this->put( $data );
			$c['hashes'][] = hash( 'sha256', $data );
			$c['offset']  += $want;
		} while ( time() < $deadline );
		if ( $src ) {
			fclose( $src ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		if ( $c['offset'] < $c['size'] ) {
			return false;
		}
		if ( $c['ok'] ) {
			clearstatcache( true, $c['abs'] );
			if ( (int) @filesize( $c['abs'] ) !== $c['size'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$c['ok'] = false;
				if ( count( $this->s['warnings'] ) < 200 ) {
					$this->s['warnings'][] = 'File changed size while archiving (will not be restored): ' . $c['path'];
				}
			}
		}
		$digest = BlockHasher::combine( $c['hashes'] );
		$this->put( Archive::record( 'T', array( 'hashes' => $c['hashes'], 'sha256' => $digest, 'ok' => $c['ok'] ) ) );
		$this->last = array( 'path' => $c['path'], 'sha256' => $digest, 'ok' => $c['ok'] );
		++$this->s['entries'];
		$this->s['bytes'] += $c['size'];
		unset( $c );
		$this->s['cur'] = null;
		return true;
	}

	/**
	 * Add an in-memory entry (small files: manifests, metadata).
	 *
	 * @param string $path    Archive path.
	 * @param string $content Content.
	 */
	public function add_string( string $path, string $content ): void {
		$chunks = str_split( $content, $this->s['chunk'] ) ?: array( '' );
		$hashes = '' === $content ? array() : array_map( static fn( $c ) => hash( 'sha256', $c ), $chunks );
		$this->put( Archive::record( 'E', array( 'path' => $path, 'type' => 'f', 'size' => strlen( $content ), 'mtime' => time(), 'mode' => 0644, 'chunk' => $this->s['chunk'] ) ) );
		$this->put( $content );
		$this->put( Archive::record( 'T', array( 'hashes' => $hashes, 'sha256' => BlockHasher::combine( $hashes ), 'ok' => true ) ) );
		++$this->s['entries'];
		$this->s['bytes'] += strlen( $content );
	}

	/**
	 * Add a directory entry.
	 *
	 * @param string $path Archive path.
	 */
	public function add_dir( string $path ): void {
		$this->put( Archive::record( 'E', array( 'path' => $path, 'type' => 'd', 'size' => 0, 'mtime' => time(), 'mode' => 0755, 'chunk' => $this->s['chunk'] ) ) );
		$this->put( Archive::record( 'T', array( 'hashes' => array(), 'sha256' => BlockHasher::combine( array() ), 'ok' => true ) ) );
		++$this->s['entries'];
	}

	/**
	 * Write the end record with the seal hash (computed by the caller over all prior bytes).
	 *
	 * @param string $seal SHA-256 hash-list digest of bytes [0, committed).
	 * @param array  $extra Extra fields.
	 */
	public function seal( string $seal, array $extra = array() ): void {
		$this->put( Archive::record( 'Z', array_merge( array( 'entries' => $this->s['entries'], 'bytes' => $this->s['bytes'], 'seal' => $seal, 'block_size' => BlockHasher::BLOCK_SIZE ), $extra ) ) );
		$this->s['sealed'] = true;
	}

	/**
	 * Close and return the new committed state.
	 *
	 * @throws WstmException If flush fails.
	 */
	public function close(): array {
		if ( ! fflush( $this->fh ) ) {
			throw new WstmException( 'write_failed', 'Could not flush the archive (disk full?).', array( 'resumable' => true ) );
		}
		$this->s['committed'] = ftell( $this->fh );
		fclose( $this->fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $this->s;
	}

	/** Abort without committing. */
	public function abort(): void {
		if ( is_resource( $this->fh ) ) {
			fclose( $this->fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}
}
