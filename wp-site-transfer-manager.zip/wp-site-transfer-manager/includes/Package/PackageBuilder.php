<?php
/**
 * Builds a .wpmig migration package (resumable state machine).
 *
 * Package entries, in order:
 *   metadata.json            source environment, components, config summary (no secrets)
 *   migration.json           URLs and paths used by URL/path replacement
 *   database.sql.gz|.sql     database dump (optional)
 *   database.manifest.json   dump manifest (tables, rows, checksum)
 *   files/<root>/<path>      site files
 *   checksums.json           { "path": sha256, ... } for every file entry
 *   manifest.json            package manifest (counts, sizes, components, versions)
 *   Z record                 seal = SHA-256 hash list of every preceding byte
 *
 * Stages: prepare → db → scan → disk → meta → files → tail → seal_hash → seal → done
 *
 * @package WSTM\Package
 */

namespace WSTM\Package;

use WSTM\Archive\Archive;
use WSTM\Archive\ArchiveWriter;
use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Database\BlockHasher;
use WSTM\Database\DbExporter;
use WSTM\Database\DumpManifest;
use WSTM\Database\TableScanner;
use WSTM\Files\DiskSpace;
use WSTM\Files\FileScanner;
use WSTM\Files\SiteRoots;

defined( 'ABSPATH' ) || exit;

/**
 * Package builder.
 */
class PackageBuilder {

	public const FORMAT  = 'wstm-package';
	public const VERSION = 1;
	public const EXT     = 'wpmig';

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Initial state.
	 *
	 * @param array  $opts    components (array of flags), exclusions[], gzip, allow_unknown_disk.
	 * @param string $job_dir Job working directory.
	 */
	public function init_state( array $opts, string $job_dir ): array {
		$components = array();
		foreach ( SiteRoots::COMPONENTS as $c ) {
			$components[ $c ] = ! empty( $opts['components'][ $c ] );
		}
		if ( ! array_filter( $components ) ) {
			throw new WstmException( 'nothing_selected', 'Select at least one component to export.' );
		}
		$host = sanitize_title( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ?: 'site';
		$area = in_array( $opts['output_area'] ?? 'packages', array( 'packages', 'backups' ), true ) ? ( $opts['output_area'] ?? 'packages' ) : 'packages';
		$name = $this->plugin->storage()->random_filename( ( $opts['name_prefix'] ?? '' ) . $host, self::EXT );
		$gzip = ! array_key_exists( 'gzip', $opts ) || ! empty( $opts['gzip'] );
		$gzip = $gzip && function_exists( 'gzopen' );

		return array(
			'stage'      => 'prepare',
			'components' => $components,
			'exclusions' => array_values( array_filter( array_map( 'strval', (array) ( $opts['exclusions'] ?? array() ) ) ) ),
			'db_filters' => self::db_filters( (array) ( $opts['skip'] ?? array() ) ),
			'unknown_ok' => ! empty( $opts['allow_unknown_disk'] ),
			'job_dir'    => $job_dir,
			'final'      => $this->plugin->storage()->area( $area ) . '/' . $name,
			'part'       => $this->plugin->storage()->area( $area ) . '/' . $name . '.part',
			'since'      => ! empty( $opts['since_index'] ) && is_file( $opts['since_index'] ) ? (string) $opts['since_index'] : null,
			'keep_index' => ! empty( $opts['keep_index'] ),
			'mode'       => (string) ( $opts['mode'] ?? 'full' ),
			'base'       => (string) ( $opts['base'] ?? '' ),
			'unchanged'  => 0,
			'db_file'    => $job_dir . '/database.sql' . ( $gzip ? '.gz' : '' ),
			'gzip'       => $gzip,
			'db'         => null,
			'scan'       => null,
			'arc'        => null,
			'idx_offset' => 0,
			'files_done' => 0,
			'ck'         => array( 'file' => $job_dir . '/checksums.json', 'committed' => 0, 'n' => 0 ),
			'hash'       => null,
			'warnings'   => array(),
			'started'    => time(),
		);
	}

	/**
	 * Load a file snapshot (index of a previous backup) as path => "size:mtime".
	 * Cached per request.
	 *
	 * @param string $index Index path.
	 */
	public static function load_snapshot( string $index ): array {
		static $cache = array();
		if ( ! isset( $cache[ $index ] ) ) {
			$map = array();
			foreach ( FileScanner::read_index( $index ) as $e ) {
				if ( 'f' === ( $e['t'] ?? '' ) ) {
					$map[ $e['r'] . '/' . $e['p'] ] = $e['s'] . ':' . $e['m'];
				}
			}
			$cache = array( $index => $map ); // Keep only one snapshot in memory.
		}
		return $cache[ $index ];
	}

	/**
	 * Row filters for "skip" options (post revisions, spam/trashed comments).
	 *
	 * @param array $skip Flags: revisions, spam_comments.
	 */
	public static function db_filters( array $skip ): array {
		global $wpdb;
		$f = array();
		if ( ! empty( $skip['revisions'] ) ) {
			$f[ $wpdb->posts ] = "`post_type` <> 'revision'";
		}
		if ( ! empty( $skip['spam_comments'] ) ) {
			$f[ $wpdb->comments ] = "`comment_approved` NOT IN ('spam','trash')";
		}
		$p = $wpdb->prefix;
		if ( ! empty( $skip['woo_orders'] ) ) {
			// Order tables keep their structure but no rows; legacy (post-based) orders are filtered too.
			foreach ( array( 'wc_orders', 'wc_orders_meta', 'wc_order_addresses', 'wc_order_operational_data', 'woocommerce_order_items', 'woocommerce_order_itemmeta', 'wc_order_stats', 'wc_order_product_lookup', 'wc_order_tax_lookup', 'wc_order_coupon_lookup', 'woocommerce_downloadable_product_permissions' ) as $t ) {
				$f[ $p . $t ] = '1=0';
			}
			$types = "'shop_order','shop_order_refund','shop_order_placehold'";
			$f[ $wpdb->posts ]    = ( isset( $f[ $wpdb->posts ] ) ? $f[ $wpdb->posts ] . ' AND ' : '' ) . "`post_type` NOT IN ({$types})";
			$f[ $wpdb->postmeta ] = "`post_id` NOT IN (SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type` IN ({$types}))";
			$f[ $wpdb->comments ] = ( isset( $f[ $wpdb->comments ] ) ? $f[ $wpdb->comments ] . ' AND ' : '' ) . "`comment_type` <> 'order_note'";
		}
		if ( ! empty( $skip['woo_customers'] ) ) {
			$cust = "SELECT `user_id` FROM `{$wpdb->usermeta}` WHERE `meta_key` = '" . esc_sql( $p . 'capabilities' ) . "' AND `meta_value` LIKE '%\"customer\"%'";
			$f[ $wpdb->users ]    = "`ID` NOT IN ({$cust})";
			$f[ $wpdb->usermeta ] = "`user_id` NOT IN ({$cust})";
			$f[ $p . 'wc_customer_lookup' ] = '1=0';
		}
		return $f;
	}

	/**
	 * One slice.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 * @throws WstmException On failure.
	 */
	public function slice( array $s, int $deadline ): array {
		switch ( $s['stage'] ) {
			case 'prepare':
				$this->plugin->diagnostics()->assert_ready( array( 'php_version', 'db_connection', 'temp_writable', 'ext_hash', 'ext_json' ), 'Package export' );
				$s['stage'] = $s['components']['database'] ? 'db' : 'scan';
				return $s;

			case 'db':
				$exporter = new DbExporter( $this->plugin->db(), new TableScanner( $this->plugin->db() ) );
				if ( null === $s['db'] ) {
					$s['db'] = DbExporter::init_state(
						array(
							'file'       => $s['db_file'],
							'tables'     => array(),
							'filters'    => $s['db_filters'] ?? array(),
							'gzip'       => $s['gzip'],
							'batch_rows' => (int) $this->plugin->settings()->get( 'db_batch_rows' ),
						)
					);
				}
				$s['db'] = $exporter->slice( $s['db'], $deadline );
				if ( 'done' === $s['db']['stage'] ) {
					DumpManifest::write( DumpManifest::path_for( $s['db_file'] ), $exporter->manifest( $s['db'] ) );
					$s['warnings'] = array_merge( $s['warnings'], $s['db']['warnings'] );
					$s['stage']    = 'scan';
				}
				return $s;

			case 'scan':
				if ( null === $s['scan'] ) {
					$plan      = SiteRoots::scan_plan( $s['components'] );
					$rules     = array_merge( SiteRoots::builtin_rules(), SiteRoots::translate_rules( $s['exclusions'] ) );
					$s['scan'] = FileScanner::init_state( $plan['roots'], $rules, $s['job_dir'] . '/files.idx', $plan['skip'] );
					if ( ! $plan['roots'] ) {
						$s['scan']['done'] = true;
					}
				}
				if ( ! $s['scan']['done'] ) {
					$s['scan'] = FileScanner::step( $s['scan'], $deadline, $this->plugin->storage()->root() );
				}
				if ( $s['scan']['done'] ) {
					$s['warnings'] = array_merge( $s['warnings'], $s['scan']['warnings'] );
					$s['stage']    = 'disk';
				}
				return $s;

			case 'disk':
				$db_bytes = is_file( $s['db_file'] ) ? (int) filesize( $s['db_file'] ) : 0;
				DiskSpace::require( $this->plugin->storage(), array( 'Package' => $db_bytes + (int) $s['scan']['bytes'] ), $s['unknown_ok'] );
				$s['arc']   = ArchiveWriter::init_state( $s['part'], Archive::chunk_bytes( $this->plugin->settings()->get( 'chunk_size' ) ) );
				$s['stage'] = 'meta';
				return $s;

			case 'meta':
				return $this->write_meta( $s );

			case 'files':
				return $this->write_files( $s, $deadline );

			case 'tail':
				return $this->write_tail( $s );

			case 'seal_hash':
				$s['hash'] = BlockHasher::step( $s['part'], $s['hash'] ?? BlockHasher::init( (int) $s['arc']['committed'] ), $deadline );
				if ( $s['hash']['done'] ) {
					$s['stage'] = 'seal';
				}
				return $s;

			case 'seal':
				$w = new ArchiveWriter( $s['arc'] );
				$w->seal( $s['hash']['hash'] );
				$s['arc'] = $w->close();
				if ( ! @rename( $s['part'], $s['final'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
					throw new WstmException( 'io_error', 'Could not finalise the package file.', array( 'resumable' => true ) );
				}
				if ( $s['keep_index'] && ! empty( $s['scan']['index'] ) && is_file( $s['scan']['index'] ) ) {
					copy( $s['scan']['index'], $s['final'] . '.idx' ); // File snapshot for later differential/incremental backups.
				}
				PackageInfo::write( $s['final'], $this->summary( $s ) );
				$this->plugin->db()->insert(
					'packages',
					array(
						'uuid'       => wp_generate_uuid4(),
						'file_path'  => $s['final'],
						'size_bytes' => (int) filesize( $s['final'] ),
						'checksum'   => $s['hash']['hash'],
						'source_url' => home_url(),
						'status'     => 'ready',
						'manifest'   => wp_json_encode( $this->summary( $s ) ),
						'created_at' => gmdate( 'Y-m-d H:i:s' ),
					)
				);
				$s['stage'] = 'done';
				return $s;
		}
		return $s;
	}

	/**
	 * Run an ArchiveWriter operation with commit/abort handling.
	 *
	 * @param array    $s  State.
	 * @param callable $fn fn(ArchiveWriter $w, array &$s).
	 */
	private function with_writer( array $s, callable $fn ): array {
		$w = new ArchiveWriter( $s['arc'] );
		try {
			$fn( $w, $s );
		} catch ( \Throwable $e ) {
			$w->abort();
			throw $e;
		}
		$s['arc'] = $w->close();
		return $s;
	}

	/**
	 * Metadata, migration info and database entries.
	 *
	 * @param array $s State.
	 */
	private function write_meta( array $s ): array {
		global $wp_version, $table_prefix;
		$s = $this->with_writer(
			$s,
			function ( ArchiveWriter $w, array &$s ) use ( $wp_version, $table_prefix ) {
				$theme = wp_get_theme();
				$w->add_string(
					'metadata.json',
					wp_json_encode(
						array(
							'format'       => self::FORMAT,
							'version'      => self::VERSION,
							'generator'    => 'WP Site Transfer Manager ' . WSTM_VERSION,
							'created_at'   => gmdate( 'c' ),
							'components'   => $s['components'],
							'exclusions'   => $s['exclusions'],
							'site_url'     => site_url(),
							'home_url'     => home_url(),
							'wp_version'   => $wp_version,
							'php_version'  => PHP_VERSION,
							'db_server'    => $this->plugin->db()->server_version(),
							'multisite'    => is_multisite(),
							'table_prefix' => $table_prefix,
							'base_prefix'  => $this->plugin->db()->base_prefix(),
							'theme'        => array( 'stylesheet' => get_stylesheet(), 'template' => get_template(), 'name' => $theme->get( 'Name' ) ),
							'plugins'      => array_values( (array) get_option( 'active_plugins', array() ) ),
							'config'       => array(
								'WP_HOME'    => defined( 'WP_HOME' ) ? WP_HOME : null,
								'WP_SITEURL' => defined( 'WP_SITEURL' ) ? WP_SITEURL : null,
								'WP_DEBUG'   => defined( 'WP_DEBUG' ) && WP_DEBUG,
								'DB_CHARSET' => defined( 'DB_CHARSET' ) ? DB_CHARSET : null,
								'note'       => 'Database credentials and salts are never included.',
							),
						),
						JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
					)
				);
				$uploads = wp_upload_dir( null, false );
				$roots   = SiteRoots::dirs();
				$w->add_string(
					'migration.json',
					wp_json_encode(
						array(
							'home_url'    => home_url(),
							'site_url'    => site_url(),
							'content_url' => content_url(),
							'uploads_url' => $uploads['baseurl'],
							'paths'       => $roots,
						),
						JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
					)
				);
				if ( $s['components']['database'] ) {
					$w->begin_file( basename( $s['db_file'] ), $s['db_file'] );
				}
			}
		);
		$s['stage'] = 'files';
		return $s;
	}

	/**
	 * Archive the database (if in progress) and files from the index.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 */
	private function write_files( array $s, int $deadline ): array {
		$ck = $s['ck'];
		$fh = fopen( $ck['file'], 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		ftruncate( $fh, $ck['committed'] );
		fseek( $fh, $ck['committed'] );

		try {
			$s = $this->with_writer(
				$s,
				function ( ArchiveWriter $w, array &$s ) use ( $deadline, $fh ) {
					$db_entry = basename( $s['db_file'] );
					$dirs     = SiteRoots::dirs();
					$since    = $s['since'] ? self::load_snapshot( $s['since'] ) : null;
					$gen      = FileScanner::read_index( $s['scan']['index'], (int) $s['idx_offset'] );
					do {
						if ( $w->busy() ) {
							$path = $w->current_path();
							if ( ! $w->continue_entry( $deadline ) ) {
								return;
							}
							$this->record_checksum( $s, $fh, $w );
							if ( $path === $db_entry ) {
								$w->add_string( 'database.manifest.json', (string) file_get_contents( DumpManifest::path_for( $s['db_file'] ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
							}
							continue;
						}
						if ( ! $gen->valid() ) {
							$s['stage'] = 'tail';
							return;
						}
						$after = $gen->key();
						$e     = $gen->current();
						$gen->next();
						$s['idx_offset'] = $after;
						if ( ! SiteRoots::wanted( $e['r'], $e['p'], $s['components'] ) ) {
							continue;
						}
						$path = 'files/' . $e['r'] . '/' . $e['p'];
						if ( 'd' === $e['t'] ) {
							$w->add_dir( $path );
							continue;
						}
						$abs = $dirs[ $e['r'] ] . '/' . $e['p'];
						if ( null !== $since && ( $since[ $e['r'] . '/' . $e['p'] ] ?? null ) === $e['s'] . ':' . $e['m'] ) {
							++$s['unchanged']; // Differential/incremental: unchanged since the base backup.
							continue;
						}
						if ( ! is_file( $abs ) || is_link( $abs ) ) {
							if ( count( $s['warnings'] ) < 300 ) {
								$s['warnings'][] = 'File disappeared before archiving: ' . $path;
							}
							continue;
						}
						$w->begin_file( $path, $abs );
						++$s['files_done'];
					} while ( time() < $deadline );
				}
			);
			fflush( $fh );
			$s['ck']['committed'] = ftell( $fh );
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$s['warnings'] = array_slice( array_merge( $s['warnings'], $s['arc']['warnings'] ), 0, 300 );
		$s['arc']['warnings'] = array();
		return $s;
	}

	/**
	 * Append "path": "sha256" for the entry just finished.
	 *
	 * @param array         $s  State (by reference).
	 * @param resource      $fh Checksums handle.
	 * @param ArchiveWriter $w  Writer.
	 */
	private function record_checksum( array &$s, $fh, ArchiveWriter $w ): void {
		$last = $w->last_entry();
		if ( ! $last ) {
			return;
		}
		$line = ( $s['ck']['n'] ? ",\n" : "{\n" ) . wp_json_encode( $last['path'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ': ' . wp_json_encode( $last['sha256'] );
		fwrite( $fh, $line ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		++$s['ck']['n'];
	}

	/**
	 * checksums.json and manifest.json.
	 *
	 * @param array $s State.
	 */
	private function write_tail( array $s ): array {
		$fh = fopen( $s['ck']['file'], 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		ftruncate( $fh, $s['ck']['committed'] );
		fseek( $fh, $s['ck']['committed'] );
		fwrite( $fh, $s['ck']['n'] ? "\n}\n" : "{}\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$s = $this->with_writer(
			$s,
			function ( ArchiveWriter $w, array &$s ) {
				$w->begin_file( 'checksums.json', $s['ck']['file'] );
				$w->continue_entry( PHP_INT_MAX );
				$db = null;
				if ( $s['components']['database'] ) {
					$m  = DumpManifest::read( DumpManifest::path_for( $s['db_file'] ) );
					$db = array(
						'file'    => basename( $s['db_file'] ),
						'tables'  => count( $m['tables'] ),
						'rows'    => $m['rows'],
						'size'    => $m['size'],
						'sha256'  => $m['checksum']['hash'],
						'prefix'  => $m['table_prefix'],
						'charset' => $m['charset'],
					);
				}
				global $wp_version;
				$w->add_string(
					'manifest.json',
					wp_json_encode(
						array(
							'format'      => self::FORMAT,
							'version'     => self::VERSION,
							'created_at'  => gmdate( 'c' ),
							'source'      => home_url(),
							'components'  => $s['components'],
							'database'    => $db,
							'files'       => $s['files_done'],
							'file_bytes'  => (int) $s['scan']['bytes'],
							'entries'     => $w->state()['entries'] + 1, // + this manifest.
							'requires'    => array( 'php' => WSTM_MIN_PHP, 'wp' => WSTM_MIN_WP, 'source_wp' => $wp_version ),
							'warnings'    => array_slice( $s['warnings'], 0, 100 ),
							'mode'        => $s['mode'] ?? 'full',
							'base'        => $s['base'] ?? '',
							'unchanged'   => (int) ( $s['unchanged'] ?? 0 ),
						),
						JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
					)
				);
			}
		);
		$s['stage'] = 'seal_hash';
		return $s;
	}

	/**
	 * Package summary (sidecar + packages table).
	 *
	 * @param array $s State.
	 */
	public function summary( array $s ): array {
		return array(
			'format'     => self::FORMAT,
			'version'    => self::VERSION,
			'created_at' => gmdate( 'c' ),
			'source'     => home_url(),
			'components' => $s['components'],
			'files'      => $s['files_done'],
			'entries'    => $s['arc']['entries'],
			'bytes'      => (int) filesize( $s['final'] ),
			'seal'       => $s['hash']['hash'],
			'database'   => $s['components']['database'],
			'prefix'     => $this->plugin->db()->base_prefix(),
			'validated'  => true,
		);
	}

	/**
	 * Progress (0–100).
	 *
	 * @param array $s State.
	 */
	public static function progress( array $s ): float {
		switch ( $s['stage'] ) {
			case 'prepare':
				return 0;
			case 'db':
				return $s['db'] ? 0.3 * DbExporter::progress( $s['db'] ) : 0;
			case 'scan':
			case 'disk':
				return 30;
			case 'meta':
			case 'files':
				$total = max( 1, (int) ( $s['scan']['files'] ?? 0 ) );
				return round( 32 + 60 * min( 1, $s['files_done'] / $total ), 2 );
			case 'tail':
				return 92;
			case 'seal_hash':
				return round( 93 + 6 * ( $s['hash'] ? $s['hash']['offset'] / max( 1, $s['arc']['committed'] ) : 0 ), 2 );
			case 'seal':
				return 99;
			case 'done':
				return 100;
		}
		return 0;
	}
}
