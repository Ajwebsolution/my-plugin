<?php
/**
 * Package sidecar summary ("<package>.wpmig.json") — cached result of building
 * or validating a package, so listings never have to walk large archives.
 *
 * @package WSTM\Package
 */

namespace WSTM\Package;

defined( 'ABSPATH' ) || exit;

/**
 * Sidecar helper.
 */
final class PackageInfo {

	/**
	 * Sidecar path.
	 *
	 * @param string $package Package path.
	 */
	public static function path( string $package ): string {
		return $package . '.json';
	}

	/**
	 * Write summary (records file size + mtime so stale summaries are detected).
	 *
	 * @param string $package Package path.
	 * @param array  $data    Summary.
	 */
	public static function write( string $package, array $data ): void {
		clearstatcache( true, $package );
		$data['_size']  = (int) filesize( $package );
		$data['_mtime'] = (int) filemtime( $package );
		file_put_contents( self::path( $package ), wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Read summary; null if missing or stale (package changed since).
	 *
	 * @param string $package Package path.
	 */
	public static function read( string $package ): ?array {
		$p = self::path( $package );
		if ( ! is_file( $p ) ) {
			return null;
		}
		$d = json_decode( (string) file_get_contents( $p ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		clearstatcache( true, $package );
		if ( ! is_array( $d ) || (int) ( $d['_size'] ?? -1 ) !== (int) @filesize( $package ) || (int) ( $d['_mtime'] ?? -1 ) !== (int) @filemtime( $package ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return null;
		}
		return $d;
	}

	/**
	 * Remove sidecar.
	 *
	 * @param string $package Package path.
	 */
	public static function delete( string $package ): void {
		if ( is_file( self::path( $package ) ) ) {
			wp_delete_file( self::path( $package ) );
		}
	}
}
