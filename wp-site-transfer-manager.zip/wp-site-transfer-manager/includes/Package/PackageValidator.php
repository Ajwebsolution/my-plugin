<?php
/**
 * Resumable .wpmig package validator.
 *
 * 1. Seal: SHA-256 over every byte before the end record must match the seal.
 * 2. Structure: every record is walked (headers only); paths must be safe and
 *    inside the allowed layout; sizes must add up.
 * 3. Manifest: counts in manifest.json and the end record must agree; the
 *    format version must be supported; database dump must match its manifest.
 * Executable files inside uploads are reported (and skipped on extraction
 * unless explicitly allowed).
 *
 * @package WSTM\Package
 */

namespace WSTM\Package;

use WSTM\Archive\Archive;
use WSTM\Archive\ArchiveExtractor;
use WSTM\Archive\ArchiveIndex;
use WSTM\Core\WstmException;
use WSTM\Database\BlockHasher;
use WSTM\Files\SiteRoots;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Validator.
 */
final class PackageValidator {

	/** Top-level entries allowed besides files/. */
	public const ALLOWED = array( 'metadata.json', 'migration.json', 'manifest.json', 'checksums.json', 'database.sql', 'database.sql.gz', 'database.manifest.json' );

	/** Executable extensions flagged inside uploads. */
	public const EXEC_RE = '/\.(php\d?|phtml|phar|pht|cgi|pl|py|sh|exe)$/i';

	/**
	 * Initial state.
	 *
	 * @param string $package Package path.
	 */
	public static function init_state( string $package ): array {
		return array(
			'package'    => $package,
			'stage'      => 'locate',
			'z'          => null,
			'hash'       => null,
			'offset'     => 0,
			'entries'    => 0,
			'files'      => 0,
			'bytes'      => 0,
			'seen'       => array(),
			'suspicious' => array(),
			'warnings'   => array(),
			'done'       => false,
		);
	}

	/**
	 * One slice.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 * @throws WstmException When invalid.
	 */
	public static function step( array $s, int $deadline ): array {
		switch ( $s['stage'] ) {
			case 'locate':
				$s['z']     = self::locate_end( $s['package'] );
				$s['hash']  = BlockHasher::init( (int) $s['z']['z_offset'] );
				$s['stage'] = 'seal';
				return $s;

			case 'seal':
				$s['hash'] = BlockHasher::step( $s['package'], $s['hash'], $deadline );
				if ( $s['hash']['done'] ) {
					if ( ! hash_equals( (string) ( $s['z']['seal'] ?? '' ), (string) $s['hash']['hash'] ) ) {
						throw new WstmException(
							'seal_mismatch',
							'The package failed integrity verification.',
							array(
								'what'   => 'Package validation',
								'why'    => 'SHA-256 seal does not match — the file is corrupted, incomplete or was modified.',
								'action' => 'Re-create or re-upload the package. Nothing was changed.',
							)
						);
					}
					$s['stage'] = 'structure';
				}
				return $s;

			case 'structure':
				$gen = ArchiveIndex::entries( $s['package'], (int) $s['offset'] );
				foreach ( $gen as $offset => $e ) {
					$s = self::check_entry( $s, $e );
					$s['offset'] = $e['next'];
					if ( time() >= $deadline ) {
						return $s;
					}
				}
				$s['stage'] = 'manifest';
				return $s;

			case 'manifest':
				return self::check_manifest( $s );
		}
		return $s;
	}

	/**
	 * Find the end record by walking headers (cheap: data is skipped).
	 *
	 * @param string $package Package.
	 * @throws WstmException If missing.
	 */
	private static function locate_end( string $package ): array {
		$fh   = fopen( $package, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$head = $fh ? fread( $fh, strlen( Archive::MAGIC ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( $fh ) {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( Archive::MAGIC !== $head ) {
			throw new WstmException( 'not_package', 'This file is not a WP Site Transfer Manager package.', array( 'what' => 'Package validation', 'why' => 'Unknown file format.' ) );
		}
		$gen = ArchiveIndex::entries( $package );
		foreach ( $gen as $e ) {
			// Walk to the end.
			unset( $e );
		}
		$z = $gen->getReturn();
		clearstatcache( true, $package );
		if ( (int) $z['z_end'] !== (int) filesize( $package ) ) {
			throw Archive::corrupt( 'Unexpected data after the end record' );
		}
		return $z;
	}

	/**
	 * Validate one entry.
	 *
	 * @param array $s State.
	 * @param array $e Entry.
	 * @throws WstmException On unsafe/unknown entries.
	 */
	private static function check_entry( array $s, array $e ): array {
		$path = PathGuard::safe_relative( $e['path'] );
		if ( $path !== $e['path'] ) {
			throw Archive::corrupt( 'Non-canonical path: ' . $e['path'] );
		}
		if ( str_starts_with( $path, 'files/' ) ) {
			$parts = explode( '/', $path, 3 );
			if ( count( $parts ) < 3 || ! in_array( $parts[1], SiteRoots::KEYS, true ) ) {
				throw new WstmException( 'bad_entry', 'The package contains an unexpected path.', array( 'what' => 'Package validation', 'why' => $path, 'action' => 'Do not import this package.' ) );
			}
			if ( 'uploads' === $parts[1] && 'f' === $e['type'] && preg_match( self::EXEC_RE, $path ) && count( $s['suspicious'] ) < 200 ) {
				$s['suspicious'][] = $path;
			}
			if ( 'f' === $e['type'] ) {
				++$s['files'];
				if ( ! $e['ok'] ) {
					$s['warnings'][] = 'Changed during export on source (will be skipped): ' . $path;
				}
			}
		} elseif ( ! in_array( $path, self::ALLOWED, true ) ) {
			throw new WstmException( 'bad_entry', 'The package contains an unexpected file.', array( 'what' => 'Package validation', 'why' => $path, 'action' => 'Do not import this package.' ) );
		} else {
			if ( isset( $s['seen'][ $path ] ) ) {
				throw Archive::corrupt( 'Duplicate entry: ' . $path );
			}
			$s['seen'][ $path ] = $e['data_at'];
		}
		++$s['entries'];
		$s['bytes'] += $e['size'];
		return $s;
	}

	/**
	 * Cross-check manifest and end record.
	 *
	 * @param array $s State.
	 * @throws WstmException On mismatch.
	 */
	private static function check_manifest( array $s ): array {
		foreach ( array( 'metadata.json', 'manifest.json' ) as $req ) {
			if ( ! isset( $s['seen'][ $req ] ) ) {
				throw Archive::corrupt( 'Missing ' . $req );
			}
		}
		$m = json_decode( (string) ArchiveExtractor::read_entry( $s['package'], 'manifest.json' ), true );
		if ( ! is_array( $m ) || PackageBuilder::FORMAT !== ( $m['format'] ?? '' ) ) {
			throw Archive::corrupt( 'Invalid manifest.json' );
		}
		if ( (int) $m['version'] > PackageBuilder::VERSION ) {
			throw new WstmException( 'package_version', 'This package was created by a newer plugin version.', array( 'action' => 'Update WP Site Transfer Manager on this site.' ) );
		}
		if ( (int) $s['z']['entries'] !== $s['entries'] || (int) $s['z']['bytes'] !== $s['bytes'] || (int) $m['entries'] !== $s['entries'] || (int) $m['files'] !== $s['files'] ) {
			throw Archive::corrupt( sprintf( 'Entry counts do not match (manifest %d/%d files, found %d/%d files)', $m['entries'], $m['files'], $s['entries'], $s['files'] ) );
		}
		if ( ! empty( $m['database'] ) && ! isset( $s['seen'][ $m['database']['file'] ], $s['seen']['database.manifest.json'] ) ) {
			throw Archive::corrupt( 'Database dump listed in manifest is missing' );
		}
		if ( $s['suspicious'] ) {
			$s['warnings'][] = count( $s['suspicious'] ) . ' executable file(s) found in uploads; they are skipped on import unless explicitly allowed.';
		}
		$s['manifest'] = $m;
		$s['metadata'] = json_decode( (string) ArchiveExtractor::read_entry( $s['package'], 'metadata.json' ), true );
		$s['done']     = true;
		$s['stage']    = 'done';
		return $s;
	}

	/**
	 * Progress 0–100.
	 *
	 * @param array $s State.
	 */
	public static function progress( array $s ): float {
		if ( 'seal' === $s['stage'] ) {
			return round( 5 + 80 * $s['hash']['offset'] / max( 1, (int) $s['z']['z_offset'] ), 2 );
		}
		return array( 'locate' => 0, 'structure' => 90, 'manifest' => 98, 'done' => 100 )[ $s['stage'] ] ?? 0;
	}
}
