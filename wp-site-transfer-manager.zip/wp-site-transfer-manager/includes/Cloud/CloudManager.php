<?php
/**
 * Cloud destinations: storage of settings (secret encrypted at rest), backup upload hook.
 *
 * Option "wstm_cloud": [ id => {id,label,type,endpoint,region,bucket,prefix,path_style,access_key,secret_enc} ].
 *
 * @package WSTM\Cloud
 */

namespace WSTM\Cloud;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Security\Crypto;

defined( 'ABSPATH' ) || exit;

/**
 * Cloud manager.
 */
class CloudManager {

	public const OPTION = 'wstm_cloud';

	/** Ready-made endpoint presets for the UI. */
	public const PRESETS = array(
		'aws'    => array( 'label' => 'Amazon S3', 'endpoint' => 'https://s3.{region}.amazonaws.com', 'path_style' => false ),
		'r2'     => array( 'label' => 'Cloudflare R2', 'endpoint' => 'https://{account}.r2.cloudflarestorage.com', 'path_style' => true, 'region' => 'auto' ),
		'b2'     => array( 'label' => 'Backblaze B2', 'endpoint' => 'https://s3.{region}.backblazeb2.com', 'path_style' => true ),
		'wasabi' => array( 'label' => 'Wasabi', 'endpoint' => 'https://s3.{region}.wasabisys.com', 'path_style' => true ),
		'do'     => array( 'label' => 'DigitalOcean Spaces', 'endpoint' => 'https://{region}.digitaloceanspaces.com', 'path_style' => false ),
		'minio'  => array( 'label' => 'MinIO / other S3-compatible', 'endpoint' => 'https://minio.example.com', 'path_style' => true ),
	);

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/** Hooks. */
	public function hooks(): void {
		add_filter( 'wstm_cloud_destinations', fn( $list ) => array_merge( (array) $list, $this->public_list() ) );
		add_filter( 'wstm_cloud_upload_step', array( $this, 'upload_step' ), 10, 5 );
	}

	/** Raw stored destinations. */
	private function raw(): array {
		$v = get_option( self::OPTION, array() );
		return is_array( $v ) ? $v : array();
	}

	/** Destinations without secrets. */
	public function public_list(): array {
		$out = array();
		foreach ( $this->raw() as $d ) {
			$has = ! empty( $d['secret_enc'] );
			unset( $d['secret_enc'] );
			$d['has_secret'] = $has;
			$d['access_key'] = self::mask( (string) $d['access_key'] );
			$out[]           = $d;
		}
		return $out;
	}

	/**
	 * Mask an access key id for display.
	 *
	 * @param string $v Value.
	 */
	public static function mask( string $v ): string {
		return strlen( $v ) > 8 ? substr( $v, 0, 4 ) . str_repeat( '•', 6 ) . substr( $v, -2 ) : str_repeat( '•', strlen( $v ) );
	}

	/**
	 * Create or update a destination.
	 *
	 * @param array $in Input (secret_key optional on update = keep).
	 * @throws WstmException On invalid input.
	 */
	public function save( array $in ): array {
		$all = $this->raw();
		$id  = sanitize_key( (string) ( $in['id'] ?? '' ) );
		$old = $id && isset( $all[ $id ] ) ? $all[ $id ] : null;
		if ( ! $old ) {
			$id = 's3-' . strtolower( wp_generate_password( 6, false ) );
		}
		$endpoint = esc_url_raw( trim( (string) ( $in['endpoint'] ?? '' ) ), array( 'https', 'http' ) );
		$host     = (string) wp_parse_url( $endpoint, PHP_URL_HOST );
		if ( '' === $host ) {
			throw new WstmException( 'cloud_bad_endpoint', 'The endpoint must be a full URL such as https://s3.eu-west-1.amazonaws.com.', array() );
		}
		if ( 'http' === wp_parse_url( $endpoint, PHP_URL_SCHEME ) && ! in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true ) && ! apply_filters( 'wstm_cloud_allow_http', false, $host ) ) {
			throw new WstmException( 'cloud_insecure', 'The endpoint must use HTTPS.', array( 'why' => 'Backups would travel unencrypted.', 'action' => 'Use the https:// address of your storage provider.' ) );
		}
		$bucket = trim( (string) ( $in['bucket'] ?? '' ) );
		if ( ! preg_match( '/^[a-z0-9][a-z0-9.\-_]{1,62}$/i', $bucket ) ) {
			throw new WstmException( 'cloud_bad_bucket', 'The bucket name is not valid.', array() );
		}
		$access = trim( (string) ( $in['access_key'] ?? '' ) );
		// Keep the saved key when the field was left empty or still shows the masked value
		// (also if the "•" characters were lost in transit).
		$masked = $old ? self::mask( (string) $old['access_key'] ) : '';
		if ( $old && ( '' === $access || str_contains( $access, '•' ) || $access === $masked || $access === str_replace( '•', '', $masked ) ) ) {
			$access = (string) $old['access_key'];
		}
		$secret = (string) ( $in['secret_key'] ?? '' );
		if ( '' === $access || ( '' === $secret && ! $old ) ) {
			throw new WstmException( 'cloud_missing_keys', 'Access key and secret key are required.', array() );
		}
		$all[ $id ] = array(
			'id'         => $id,
			'label'      => sanitize_text_field( (string) ( $in['label'] ?? '' ) ) ?: $bucket,
			'type'       => 's3',
			'endpoint'   => untrailingslashit( $endpoint ),
			'region'     => preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) ( $in['region'] ?? '' ) ) ) ?: 'us-east-1',
			'bucket'     => $bucket,
			'prefix'     => trim( preg_replace( '#[^A-Za-z0-9/._-]#', '', (string) ( $in['prefix'] ?? '' ) ), '/' ),
			'path_style' => ! empty( $in['path_style'] ),
			'access_key' => $access,
			'secret_enc' => '' !== $secret ? Crypto::encrypt( $secret ) : (string) $old['secret_enc'],
		);
		update_option( self::OPTION, $all, false );
		$this->plugin->logger()->info( 'Cloud destination saved: ' . $all[ $id ]['label'], array( 'id' => $id, 'endpoint' => $all[ $id ]['endpoint'], 'bucket' => $bucket ), 'cloud' );
		return $this->public_list()[ array_search( $id, array_column( $this->public_list(), 'id' ), true ) ];
	}

	/**
	 * Remove a destination (remote files are left untouched).
	 *
	 * @param string $id Id.
	 */
	public function remove( string $id ): void {
		$all = $this->raw();
		unset( $all[ $id ] );
		update_option( self::OPTION, $all, false );
	}

	/**
	 * Destination object.
	 *
	 * @param string $id Id.
	 * @throws WstmException If unknown or secret unreadable.
	 */
	public function destination( string $id ): S3Destination {
		$d = $this->raw()[ $id ] ?? null;
		if ( ! $d ) {
			throw new WstmException( 'cloud_unknown', 'This cloud destination does not exist.', array( 'why' => $id, 'action' => 'Choose another destination or add it again.' ) );
		}
		$secret = Crypto::decrypt( (string) $d['secret_enc'] );
		if ( null === $secret ) {
			throw new WstmException( 'cloud_secret', 'The stored secret key cannot be decrypted.', array( 'why' => 'The security keys in wp-config.php changed since it was saved.', 'action' => 'Edit the destination and enter the secret key again.' ) );
		}
		return new S3Destination( $d, $secret );
	}

	/**
	 * Filter "wstm_cloud_upload_step": push a finished backup to the destination.
	 *
	 * @param mixed  $st       Upload state or null.
	 * @param string $dest     Destination id.
	 * @param string $file     Local backup.
	 * @param int    $deadline Deadline.
	 * @param int    $backup   Backup id.
	 * @throws WstmException On failure (backup itself stays safe on this server).
	 */
	public function upload_step( $st, string $dest, string $file, int $deadline, int $backup ) {
		if ( ! isset( $this->raw()[ $dest ] ) ) {
			return $st; // Another adapter's destination.
		}
		try {
			$d   = $this->destination( $dest );
			$key = $d->key( basename( $file ) );
			$st  = $d->upload_step( $file, $key, is_array( $st ) ? $st : array(), $deadline );
		} catch ( WstmException $e ) {
			$a = $e->to_array();
			throw new WstmException( $e->get_error_code(), $e->getMessage(), array( 'why' => $a['why'] ?? '', 'action' => ( $a['action'] ?? '' ) . ' Resume the job to continue the upload.', 'completed' => 'The backup was created and verified on this server; only the cloud copy is unfinished.', 'resumable' => true ) );
		}
		if ( $st['done'] ) {
			$st['remote'] = array( 'destination' => $dest, 'key' => $key );
			if ( $backup ) {
				$row  = $this->plugin->db()->get_row( 'SELECT manifest FROM ' . $this->plugin->db()->table( 'backups' ) . ' WHERE id = %d', array( $backup ) );
				$meta = $row ? (array) json_decode( (string) $row['manifest'], true ) : array();
				$meta['cloud'] = array( 'destination' => $dest, 'label' => $d->label(), 'key' => $key, 'uploaded' => gmdate( 'c' ) );
				$this->plugin->db()->update( 'backups', array( 'manifest' => wp_json_encode( $meta ) ), array( 'id' => $backup ) );
			}
			$this->plugin->logger()->info( 'Backup uploaded to cloud: ' . $d->label(), array( 'key' => $key ), 'cloud' );
		}
		return $st;
	}
}
