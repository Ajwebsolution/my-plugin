<?php
/**
 * Cloud storage adapter contract (adapters arrive in Phase 10).
 * Defined now so backup/package engines can target it without refactoring.
 *
 * @package WSTM\Cloud
 */

namespace WSTM\Cloud;

defined( 'ABSPATH' ) || exit;

/**
 * Cloud adapter interface. All transfers are streamed / multipart.
 */
interface CloudInterface {

	/** Unique adapter id (e.g. "s3"). */
	public function id(): string;

	/** Human label. */
	public function label(): string;

	/**
	 * Test configured credentials.
	 *
	 * @return true|\WP_Error
	 */
	public function test_connection();

	/**
	 * Upload one chunk of a local file. Returns adapter-specific state for resume.
	 *
	 * @param string $local_path Local file.
	 * @param string $remote_key Remote object key.
	 * @param int    $offset     Byte offset.
	 * @param int    $length     Bytes.
	 * @param array  $state      Previous upload state.
	 */
	public function upload_chunk( string $local_path, string $remote_key, int $offset, int $length, array $state ): array;

	/**
	 * Download a byte range to a local file handle.
	 *
	 * @param string   $remote_key Remote key.
	 * @param resource $handle     Writable handle.
	 * @param int      $offset     Offset.
	 * @param int      $length     Length.
	 */
	public function download_range( string $remote_key, $handle, int $offset, int $length ): int;

	/**
	 * List objects under prefix.
	 *
	 * @param string $prefix Prefix.
	 */
	public function list( string $prefix = '' ): array;

	/**
	 * Delete an object.
	 *
	 * @param string $remote_key Key.
	 */
	public function delete( string $remote_key ): bool;
}
