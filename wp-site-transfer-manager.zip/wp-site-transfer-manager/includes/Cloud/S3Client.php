<?php
/**
 * Minimal S3-compatible REST client (AWS Signature Version 4) built on wp_remote_request().
 *
 * Works with Amazon S3, Cloudflare R2, Backblaze B2 (S3 API), Wasabi, DigitalOcean Spaces and MinIO.
 * No SDK; the secret key is held only in memory and never logged.
 *
 * @package WSTM\Cloud
 */

namespace WSTM\Cloud;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * S3 client.
 */
class S3Client {

	/**
	 * @var string
	 */
	private string $endpoint;

	/**
	 * @var string
	 */
	private string $region;

	/**
	 * @var string
	 */
	private string $bucket;

	/**
	 * @var string
	 */
	private string $access_key;

	/**
	 * @var string
	 */
	private string $secret_key;

	/**
	 * @var bool
	 */
	private bool $path_style;

	/**
	 * Constructor.
	 *
	 * @param string $endpoint   Endpoint base URL (scheme://host[:port]).
	 * @param string $region     Region ("auto" for R2).
	 * @param string $bucket     Bucket.
	 * @param string $access_key Access key id.
	 * @param string $secret_key Secret key.
	 * @param bool   $path_style Path-style addressing (MinIO, B2, most self-hosted).
	 */
	public function __construct(
		string $endpoint,
		string $region,
		string $bucket,
		string $access_key,
		string $secret_key,
		bool $path_style = true
	) {
		$this->endpoint = $endpoint;
		$this->region = $region;
		$this->bucket = $bucket;
		$this->access_key = $access_key;
		$this->secret_key = $secret_key;
		$this->path_style = $path_style;
		$this->endpoint = rtrim( $endpoint, '/' );
		$this->region   = '' === $region ? 'us-east-1' : $region;
	}

	/** Hide the secret from var_dump/print_r. */
	public function __debugInfo(): array {
		return array( 'endpoint' => $this->endpoint, 'bucket' => $this->bucket, 'region' => $this->region );
	}

	/**
	 * Encode an object key path (segments encoded, "/" kept).
	 *
	 * @param string $key Key.
	 */
	public static function encode_key( string $key ): string {
		return implode( '/', array_map( 'rawurlencode', explode( '/', $key ) ) );
	}

	/**
	 * Canonical query string.
	 *
	 * @param array $query Query.
	 */
	public static function canonical_query( array $query ): string {
		$pairs = array();
		foreach ( $query as $k => $v ) {
			$pairs[ rawurlencode( (string) $k ) ] = rawurlencode( (string) $v );
		}
		ksort( $pairs, SORT_STRING );
		$out = array();
		foreach ( $pairs as $k => $v ) {
			$out[] = $k . '=' . $v;
		}
		return implode( '&', $out );
	}

	/**
	 * Build host + path for a key.
	 *
	 * @param string $key Object key ('' for bucket).
	 * @return array{0:string,1:string,2:string} [scheme://host, host header, canonical path]
	 */
	private function target( string $key ): array {
		$p      = wp_parse_url( $this->endpoint );
		$scheme = $p['scheme'] ?? 'https';
		$host   = (string) ( $p['host'] ?? '' );
		$port   = isset( $p['port'] ) ? ':' . $p['port'] : '';
		if ( $this->path_style ) {
			$path = '/' . rawurlencode( $this->bucket ) . ( '' !== $key ? '/' . self::encode_key( $key ) : '' );
		} else {
			$host = $this->bucket . '.' . $host;
			$path = '/' . self::encode_key( $key );
		}
		return array( $scheme . '://' . $host . $port, $host . $port, $path );
	}

	/**
	 * Signed request.
	 *
	 * @param string $method  Method.
	 * @param string $key     Key.
	 * @param array  $query   Query.
	 * @param string $body    Body.
	 * @param array  $headers Extra headers (lower-case names).
	 * @param int    $timeout Timeout.
	 * @return array{code:int,headers:array,body:string}
	 * @throws WstmException On transport errors.
	 */
	public function request( string $method, string $key = '', array $query = array(), string $body = '', array $headers = array(), int $timeout = 60 ): array {
		list( $base, $host, $path ) = $this->target( $key );
		$hash    = hash( 'sha256', $body );
		if ( '' !== $body ) {
			$headers += array( 'content-type' => 'application/octet-stream' ); // WP would default to form-urlencoded.
		}
		$headers = $this->sign( $method, $host, $path, $query, $headers, $hash, time() );
		$cq      = self::canonical_query( $query );
		unset( $headers['host'] );
		$headers['expect'] = ''; // No "100-continue" handshake: some S3-compatible servers drop the body.

		$res = wp_remote_request(
			$base . $path . ( '' !== $cq ? '?' . $cq : '' ),
			array(
				'method'      => $method,
				'headers'     => $headers,
				'body'        => '' === $body ? null : $body,
				'timeout'     => $timeout,
				'redirection' => 0,
				'sslverify'   => true,
			)
		);
		if ( is_wp_error( $res ) ) {
			throw new WstmException( 'cloud_unreachable', 'Could not reach the cloud storage endpoint.', array( 'why' => $res->get_error_message(), 'resumable' => true, 'action' => 'Check the endpoint address and the server\'s internet access, then resume.' ) );
		}
		$out = array(
			'code'    => (int) wp_remote_retrieve_response_code( $res ),
			'headers' => array_change_key_case( (array) wp_remote_retrieve_headers( $res )->getAll(), CASE_LOWER ),
			'body'    => (string) wp_remote_retrieve_body( $res ),
		);
		return $out;
	}

	/**
	 * Add SigV4 headers (x-amz-date, x-amz-content-sha256, authorization).
	 *
	 * @param string $method  Method.
	 * @param string $host    Host header value.
	 * @param string $path    Canonical (encoded) path.
	 * @param array  $query   Query.
	 * @param array  $headers Headers.
	 * @param string $hash    Payload SHA-256 hex.
	 * @param int    $now     Timestamp.
	 * @return array Headers including host.
	 */
	public function sign( string $method, string $host, string $path, array $query, array $headers, string $hash, int $now ): array {
		$amzdate = gmdate( 'Ymd\THis\Z', $now );
		$date    = gmdate( 'Ymd', $now );
		$headers = array_change_key_case( $headers, CASE_LOWER ) + array(
			'host'                 => $host,
			'x-amz-content-sha256' => $hash,
			'x-amz-date'           => $amzdate,
		);
		ksort( $headers, SORT_STRING );
		$canon_headers = '';
		foreach ( $headers as $k => $v ) {
			$canon_headers .= $k . ':' . trim( preg_replace( '/\s+/', ' ', (string) $v ) ) . "\n";
		}
		$signed = implode( ';', array_keys( $headers ) );
		$creq   = implode( "\n", array( $method, $path, self::canonical_query( $query ), $canon_headers, $signed, $hash ) );
		$scope  = $date . '/' . $this->region . '/s3/aws4_request';
		$sts    = "AWS4-HMAC-SHA256\n" . $amzdate . "\n" . $scope . "\n" . hash( 'sha256', $creq );
		$k      = hash_hmac( 'sha256', $date, 'AWS4' . $this->secret_key, true );
		$k      = hash_hmac( 'sha256', $this->region, $k, true );
		$k      = hash_hmac( 'sha256', 's3', $k, true );
		$k      = hash_hmac( 'sha256', 'aws4_request', $k, true );

		$headers['authorization'] = 'AWS4-HMAC-SHA256 Credential=' . $this->access_key . '/' . $scope . ', SignedHeaders=' . $signed . ', Signature=' . hash_hmac( 'sha256', $sts, $k );
		return $headers;
	}

	/**
	 * Request that must succeed.
	 *
	 * @param string $what    Human description.
	 * @param mixed  ...$args request() args.
	 * @throws WstmException On non-2xx.
	 */
	public function ok( string $what, ...$args ): array {
		$r = $this->request( ...$args );
		if ( $r['code'] < 200 || $r['code'] >= 300 ) {
			$code = self::xml_value( $r['body'], 'Code' ) ?: 'HTTP ' . $r['code'];
			$msg  = self::xml_value( $r['body'], 'Message' );
			$hint = array(
				'SignatureDoesNotMatch' => 'The secret key is wrong, or the region does not match the bucket.',
				'InvalidAccessKeyId'    => 'The access key id is wrong.',
				'AccessDenied'          => 'The key does not have permission for this bucket/action.',
				'NoSuchBucket'          => 'The bucket name is wrong or it is in another account/region.',
				'RequestTimeTooSkewed'  => 'This server\'s clock is wrong; ask your host to sync time (NTP).',
				'PermanentRedirect'     => 'The bucket lives in a different region or needs a different endpoint.',
			)[ $code ] ?? 'Check the cloud destination settings.';
			throw new WstmException( 'cloud_error', $what . ' failed (' . $code . ').', array( 'why' => trim( $msg . ' ' . ( $r['code'] >= 500 ? '(server error)' : '' ) ), 'action' => $hint, 'resumable' => $r['code'] >= 500 || 429 === $r['code'] ) );
		}
		return $r;
	}

	/**
	 * Extract the first <Tag> value from an XML string (no external entities, no DOM).
	 *
	 * @param string $xml XML.
	 * @param string $tag Tag.
	 */
	public static function xml_value( string $xml, string $tag ): string {
		return preg_match( '#<' . preg_quote( $tag, '#' ) . '>([^<]*)</' . preg_quote( $tag, '#' ) . '>#', $xml, $m ) ? html_entity_decode( $m[1], ENT_QUOTES | ENT_XML1, 'UTF-8' ) : '';
	}
}
