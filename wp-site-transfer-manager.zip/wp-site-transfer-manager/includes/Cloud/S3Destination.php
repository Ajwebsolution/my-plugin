<?php
/**
 * S3-compatible cloud destination: resumable multipart upload, ranged download, list, delete.
 *
 * @package WSTM\Cloud
 */

namespace WSTM\Cloud;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * S3 destination.
 */
class S3Destination implements CloudInterface {

	/** Multipart part size (S3 minimum is 5 MiB except for the last part). */
	public const PART_SIZE = 8 * 1024 * 1024;

	/** Files at most this size are sent in one PUT. */
	public const SINGLE_MAX = self::PART_SIZE;

	private S3Client $client;

	/**
	 * @var array
	 */
	private array $cfg;

	/**
	 * Constructor.
	 *
	 * @param array  $cfg    Destination config (without secret).
	 * @param string $secret Decrypted secret key.
	 */
	public function __construct( array $cfg,  string $secret ) {
		$this->cfg = $cfg;
		$this->client = new S3Client( (string) $cfg['endpoint'], (string) ( $cfg['region'] ?? '' ), (string) $cfg['bucket'], (string) $cfg['access_key'], $secret, ! empty( $cfg['path_style'] ) );
	}

	/** Id. */
	public function id(): string {
		return (string) $this->cfg['id'];
	}

	/** Label. */
	public function label(): string {
		return (string) $this->cfg['label'];
	}

	/** Raw client (tests). */
	public function client(): S3Client {
		return $this->client;
	}

	/**
	 * Full object key for a file name (destination prefix applied).
	 *
	 * @param string $name Name.
	 */
	public function key( string $name ): string {
		$prefix = trim( (string) ( $this->cfg['prefix'] ?? '' ), '/' );
		return ( '' !== $prefix ? $prefix . '/' : '' ) . ltrim( $name, '/' );
	}

	/** Test: list one key (needs ListBucket) and write+delete a probe object (needs PutObject/DeleteObject). */
	public function test_connection() {
		try {
			$this->client->ok( 'Listing the bucket', 'GET', '', array( 'list-type' => '2', 'max-keys' => '1' ) );
			$probe = $this->key( '.wstm-probe-' . wp_generate_password( 8, false ) );
			$this->client->ok( 'Writing a test file', 'PUT', $probe, array(), 'ok' );
			$this->client->ok( 'Deleting the test file', 'DELETE', $probe );
			return true;
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage() . ' ' . ( $e->to_array()['action'] ?? '' ) );
		}
	}

	/**
	 * Upload as much as fits before the deadline. State is JSON-safe and resumable.
	 *
	 * @param string $local    Local file.
	 * @param string $key      Remote key.
	 * @param array  $state    State (empty to start).
	 * @param int    $deadline Unix deadline.
	 * @throws WstmException On failure.
	 */
	public function upload_step( string $local, string $key, array $state, int $deadline ): array {
		$size = (int) filesize( $local );
		if ( ! $state ) {
			$state = array( 'key' => $key, 'size' => $size, 'offset' => 0, 'upload_id' => null, 'parts' => array(), 'done' => false, 'progress' => 0.0 );
		}
		if ( $state['size'] !== $size ) {
			throw new WstmException( 'cloud_source_changed', 'The local file changed during upload.', array( 'why' => basename( $local ), 'action' => 'Start the upload again.' ) );
		}
		do {
			$state = $this->upload_chunk( $local, $key, (int) $state['offset'], self::PART_SIZE, $state );
		} while ( ! $state['done'] && time() < $deadline );
		return $state;
	}

	/**
	 * Upload one part (or the whole small file / the completion request).
	 *
	 * @param string $local_path Local file.
	 * @param string $remote_key Key.
	 * @param int    $offset     Offset.
	 * @param int    $length     Length.
	 * @param array  $state      State.
	 * @throws WstmException On failure.
	 */
	public function upload_chunk( string $local_path, string $remote_key, int $offset, int $length, array $state ): array {
		$size = (int) $state['size'];
		if ( $size <= self::SINGLE_MAX && null === $state['upload_id'] ) {
			$body = (string) file_get_contents( $local_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$r    = $this->client->ok( 'Uploading', 'PUT', $remote_key, array(), $body, array( 'content-type' => 'application/octet-stream' ), 300 );
			return array_merge( $state, array( 'offset' => $size, 'done' => true, 'progress' => 1.0, 'etag' => trim( (string) ( $r['headers']['etag'] ?? '' ), '"' ) ) );
		}
		if ( null === $state['upload_id'] ) {
			$r  = $this->client->ok( 'Starting multipart upload', 'POST', $remote_key, array( 'uploads' => '' ), '', array( 'content-type' => 'application/octet-stream' ) );
			$id = S3Client::xml_value( $r['body'], 'UploadId' );
			if ( '' === $id ) {
				throw new WstmException( 'cloud_error', 'The storage service did not return an upload id.', array( 'resumable' => true ) );
			}
			$state['upload_id'] = $id;
			return $state;
		}
		if ( $offset < $size ) {
			$fh = fopen( $local_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fseek( $fh, $offset );
			$body = (string) fread( $fh, min( $length, $size - $offset ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$n    = count( $state['parts'] ) + 1;
			$r    = $this->client->ok( 'Uploading part ' . $n, 'PUT', $remote_key, array( 'partNumber' => (string) $n, 'uploadId' => $state['upload_id'] ), $body, array(), 300 );
			$etag = (string) ( $r['headers']['etag'] ?? '' );
			if ( '' === $etag ) {
				throw new WstmException( 'cloud_error', 'The storage service did not confirm part ' . $n . '.', array( 'resumable' => true ) );
			}
			$state['parts'][]  = $etag;
			$state['offset']   = $offset + strlen( $body );
			$state['progress'] = round( $state['offset'] / max( 1, $size ) * 0.99, 4 );
			return $state;
		}
		$xml = '<CompleteMultipartUpload>';
		foreach ( $state['parts'] as $i => $etag ) {
			$xml .= '<Part><PartNumber>' . ( $i + 1 ) . '</PartNumber><ETag>' . esc_html( $etag ) . '</ETag></Part>';
		}
		$xml .= '</CompleteMultipartUpload>';
		$r    = $this->client->ok( 'Finishing upload', 'POST', $remote_key, array( 'uploadId' => $state['upload_id'] ), $xml, array( 'content-type' => 'application/xml' ), 300 );
		if ( str_contains( $r['body'], '<Error>' ) ) { // S3 may report errors with HTTP 200 here.
			throw new WstmException( 'cloud_error', 'Finishing the upload failed (' . S3Client::xml_value( $r['body'], 'Code' ) . ').', array( 'resumable' => true ) );
		}
		return array_merge( $state, array( 'done' => true, 'progress' => 1.0 ) );
	}

	/**
	 * Abort an unfinished multipart upload (frees storage on the provider).
	 *
	 * @param array $state Upload state.
	 */
	public function abort( array $state ): void {
		if ( ! empty( $state['upload_id'] ) && empty( $state['done'] ) ) {
			try {
				$this->client->request( 'DELETE', (string) $state['key'], array( 'uploadId' => $state['upload_id'] ) );
			} catch ( WstmException $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
				// Provider lifecycle rules will clean it up.
			}
		}
	}

	/**
	 * Download a byte range into an open handle.
	 *
	 * @param string   $remote_key Key.
	 * @param resource $handle     Handle positioned at $offset.
	 * @param int      $offset     Offset.
	 * @param int      $length     Length.
	 * @return int Bytes written.
	 * @throws WstmException On failure.
	 */
	public function download_range( string $remote_key, $handle, int $offset, int $length ): int {
		$r = $this->client->ok( 'Downloading', 'GET', $remote_key, array(), '', array( 'range' => 'bytes=' . $offset . '-' . ( $offset + $length - 1 ) ), 300 );
		if ( 206 !== $r['code'] && ! ( 200 === $r['code'] && 0 === $offset ) ) {
			throw new WstmException( 'cloud_error', 'The storage service ignored the download range.', array( 'resumable' => true ) );
		}
		$body = 200 === $r['code'] ? substr( $r['body'], 0, $length ) : $r['body'];
		return (int) fwrite( $handle, $body ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Object size.
	 *
	 * @param string $remote_key Key.
	 */
	public function size( string $remote_key ): int {
		$r = $this->client->ok( 'Reading file info', 'HEAD', $remote_key );
		return (int) ( $r['headers']['content-length'] ?? 0 );
	}

	/**
	 * List objects under the destination prefix (+ $prefix).
	 *
	 * @param string $prefix Extra prefix.
	 * @return array<int,array{key:string,name:string,size:int,modified:string}>
	 */
	public function list( string $prefix = '' ): array {
		$out   = array();
		$token = null;
		$base  = $this->key( $prefix );
		for ( $page = 0; $page < 50; $page++ ) {
			$q = array( 'list-type' => '2', 'prefix' => $base, 'max-keys' => '1000' );
			if ( $token ) {
				$q['continuation-token'] = $token;
			}
			$r = $this->client->ok( 'Listing files', 'GET', '', $q );
			if ( preg_match_all( '#<Contents>(.*?)</Contents>#s', $r['body'], $m ) ) {
				foreach ( $m[1] as $c ) {
					$key   = S3Client::xml_value( $c, 'Key' );
					$out[] = array( 'key' => $key, 'name' => basename( $key ), 'size' => (int) S3Client::xml_value( $c, 'Size' ), 'modified' => S3Client::xml_value( $c, 'LastModified' ) );
				}
			}
			$token = S3Client::xml_value( $r['body'], 'NextContinuationToken' );
			if ( 'true' !== S3Client::xml_value( $r['body'], 'IsTruncated' ) || '' === $token ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Delete an object.
	 *
	 * @param string $remote_key Key.
	 */
	public function delete( string $remote_key ): bool {
		$this->client->ok( 'Deleting', 'DELETE', $remote_key );
		return true;
	}
}
