<?php
/**
 * Database scanner: tables, sizes, classification, structure metadata.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Table scanner.
 */
class TableScanner {

	/** Tables reserved by the import engine. */
	public const RESERVED_PREFIXES = array( 'wstmi_', 'wstmo_' );

	/** WordPress core table suffixes. */
	public const CORE = array(
		'users', 'usermeta', 'posts', 'postmeta', 'comments', 'commentmeta', 'terms', 'termmeta',
		'term_taxonomy', 'term_relationships', 'options', 'links',
		'blogs', 'blogmeta', 'site', 'sitemeta', 'signups', 'registration_log',
	);

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * Constructor.
	 *
	 * @param Database $db Database.
	 */
	public function __construct( Database $db ) {
		$this->db = $db;
	}

	/**
	 * All tables with metadata.
	 *
	 * @return array<int,array{name:string,engine:string,rows:int,data_bytes:int,index_bytes:int,collation:string,is_view:bool,group:string,site_id:int,core:bool,default:bool}>
	 */
	public function tables(): array {
		$base   = $this->db->base_prefix();
		$status = array();
		try {
			foreach ( $this->db->table_status() as $row ) {
				$status[ $row['Name'] ] = $row;
			}
		} catch ( \Throwable $e ) {
			$status = array();
		}
		$names = $status ? array_keys( $status ) : $this->db->list_tables();
		sort( $names, SORT_STRING );

		$out = array();
		foreach ( $names as $name ) {
			$st      = $status[ $name ] ?? array();
			$is_view = isset( $st['Comment'] ) && 'VIEW' === strtoupper( (string) $st['Comment'] );
			$group   = 'other';
			$site_id = 0;
			$core    = false;

			foreach ( self::RESERVED_PREFIXES as $rp ) {
				if ( str_starts_with( $name, $rp ) ) {
					$group = 'reserved';
				}
			}
			if ( 'reserved' !== $group && str_starts_with( $name, $base ) ) {
				$suffix = substr( $name, strlen( $base ) );
				if ( str_starts_with( $suffix, 'wstm_' ) ) {
					$group = 'plugin_internal';
				} else {
					$group = 'site';
					if ( is_multisite() && preg_match( '/^(\d+)_(.+)$/', $suffix, $m ) ) {
						$site_id = (int) $m[1];
						$suffix  = $m[2];
					} elseif ( is_multisite() ) {
						$site_id = 1;
					}
					$core = in_array( $suffix, self::CORE, true );
				}
			}

			$out[] = array(
				'name'        => $name,
				'engine'      => (string) ( $st['Engine'] ?? '' ),
				'rows'        => (int) ( $st['Rows'] ?? 0 ),
				'data_bytes'  => (int) ( $st['Data_length'] ?? 0 ),
				'index_bytes' => (int) ( $st['Index_length'] ?? 0 ),
				'collation'   => (string) ( $st['Collation'] ?? '' ),
				'is_view'     => $is_view,
				'group'       => $group,
				'site_id'     => $site_id,
				'core'        => $core,
				'default'     => 'site' === $group && ! $is_view,
			);
		}
		return $out;
	}

	/**
	 * Names of tables selected by default for a full-site export.
	 */
	public function default_tables(): array {
		return array_values( array_map( static fn( $t ) => $t['name'], array_filter( $this->tables(), static fn( $t ) => $t['default'] ) ) );
	}

	/**
	 * Column name => type.
	 *
	 * @param string $table Table.
	 */
	public function columns( string $table ): array {
		$cols = array();
		foreach ( $this->db->get_results( 'SHOW COLUMNS FROM ' . SqlEscaper::identifier( $table ) ) as $c ) {
			$cols[ $c['Field'] ] = (string) $c['Type'];
		}
		return $cols;
	}

	/**
	 * Primary key columns in index order.
	 *
	 * @param string $table Table.
	 */
	public function primary_key( string $table ): array {
		try {
			$rows = $this->db->get_results( 'SHOW KEYS FROM ' . SqlEscaper::identifier( $table ) . " WHERE Key_name = 'PRIMARY'" );
		} catch ( \Throwable $e ) {
			return array();
		}
		usort( $rows, static fn( $a, $b ) => (int) $a['Seq_in_index'] <=> (int) $b['Seq_in_index'] );
		return array_map( static fn( $r ) => (string) $r['Column_name'], $rows );
	}

	/**
	 * SHOW CREATE TABLE output, or null for views.
	 *
	 * @param string $table Table.
	 */
	public function create_statement( string $table ): ?string {
		$row = $this->db->wpdb()->get_row( 'SHOW CREATE TABLE ' . SqlEscaper::identifier( $table ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row || isset( $row['Create View'] ) ) {
			return null;
		}
		return (string) ( $row['Create Table'] ?? array_values( $row )[1] ?? '' ) ?: null;
	}

	/**
	 * Exact row count.
	 *
	 * @param string $table Table.
	 */
	public function exact_count( string $table ): int {
		return (int) $this->db->get_var( 'SELECT COUNT(*) FROM ' . SqlEscaper::identifier( $table ) );
	}
}
