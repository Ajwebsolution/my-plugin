<?php
/**
 * Resumable SHA-256 hashing of large files.
 *
 * The file is hashed in 64 MB blocks; each block hash is stored in the job
 * checkpoint so hashing can span many requests. The file checksum is
 * sha256( block_hash_1 . block_hash_2 . ... ) — a hash list, deterministic for
 * a given file and block size, and verifiable block-by-block.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Block hasher.
 */
final class BlockHasher {

	public const ALGO       = 'sha256';
	public const BLOCK_SIZE = 67108864; // 64 MB.

	/**
	 * Fresh state.
	 *
	 * @param int|null $limit Hash only the first $limit bytes (null = whole file).
	 */
	public static function init( ?int $limit = null ): array {
		return array(
			'offset' => 0,
			'blocks' => array(),
			'done'   => false,
			'limit'  => $limit,
		);
	}

	/**
	 * Hash blocks until done or deadline.
	 *
	 * @param string $path       File.
	 * @param array  $st         State.
	 * @param int    $deadline   Unix deadline.
	 * @param int    $block_size Block size (tests use small blocks).
	 * @throws WstmException On read failure.
	 */
	public static function step( string $path, array $st, int $deadline, int $block_size = self::BLOCK_SIZE ): array {
		clearstatcache( true, $path );
		$size = (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( isset( $st['limit'] ) && null !== $st['limit'] ) {
			$size = min( $size, (int) $st['limit'] );
		}
		$fh   = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			throw new WstmException( 'io_error', 'Could not read file for checksum.', array( 'why' => basename( $path ), 'resumable' => true ) );
		}
		try {
			while ( $st['offset'] < $size ) {
				fseek( $fh, $st['offset'] );
				$ctx  = hash_init( self::ALGO );
				$len  = min( $block_size, $size - $st['offset'] );
				$read = hash_update_stream( $ctx, $fh, $len );
				if ( $read !== $len ) {
					throw new WstmException( 'io_error', 'Short read while hashing.', array( 'why' => basename( $path ), 'resumable' => true ) );
				}
				$st['blocks'][] = hash_final( $ctx );
				$st['offset']  += $len;
				if ( time() >= $deadline ) {
					break;
				}
			}
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( $st['offset'] >= $size ) {
			$st['done'] = true;
			$st['size'] = $size;
			$st['hash'] = self::combine( $st['blocks'] );
		}
		return $st;
	}

	/**
	 * Combine block hashes into a file checksum.
	 *
	 * @param string[] $blocks Block hashes.
	 */
	public static function combine( array $blocks ): string {
		return hash( self::ALGO, implode( '', $blocks ) );
	}

	/**
	 * Hash a file in one go (small files / tests).
	 *
	 * @param string $path       File.
	 * @param int    $block_size Block size.
	 */
	public static function file( string $path, int $block_size = self::BLOCK_SIZE ): string {
		$st = self::init();
		while ( ! $st['done'] ) {
			$st = self::step( $path, $st, PHP_INT_MAX, $block_size );
		}
		return $st['hash'];
	}
}
