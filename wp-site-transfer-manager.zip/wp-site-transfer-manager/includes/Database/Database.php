<?php
/**
 * Database abstraction over $wpdb.
 *
 * Every method that accepts user values uses prepared statements. Table names
 * are resolved through the site's real base prefix (never assumes "wp_").
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * DB wrapper.
 */
class Database {

	/**
	 * Allowed plugin tables (short names).
	 */
	public const TABLES = array( 'jobs', 'logs', 'transfers', 'backups', 'chunks', 'packages' );

	/**
	 * WPDB instance.
	 *
	 * @var \wpdb
	 */
	private \wpdb $wpdb;

	/**
	 * Constructor.
	 *
	 * @param \wpdb|null $wpdb Optional wpdb.
	 */
	public function __construct( ?\wpdb $wpdb = null ) {
		global $wpdb;
		$this->wpdb = $wpdb ?? $GLOBALS['wpdb'];
	}

	/** Raw wpdb (for later engines needing low-level access). */
	public function wpdb(): \wpdb {
		return $this->wpdb;
	}

	/**
	 * Full name of a plugin table. Uses base_prefix so tables are network-wide.
	 *
	 * @param string $short Short name.
	 * @throws WstmException On unknown table.
	 */
	public function table( string $short ): string {
		if ( ! in_array( $short, self::TABLES, true ) ) {
			throw new WstmException( 'unknown_table', 'Unknown plugin table: ' . $short );
		}
		return $this->wpdb->base_prefix . 'wstm_' . $short;
	}

	/**
	 * Prepare if params given.
	 *
	 * @param string $sql    SQL with placeholders.
	 * @param array  $params Params.
	 */
	private function prepare( string $sql, array $params ): string {
		return empty( $params ) ? $sql : (string) $this->wpdb->prepare( $sql, $params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Throw on DB error.
	 *
	 * @param string $op Operation label.
	 * @throws WstmException On error.
	 */
	private function check( string $op ): void {
		if ( '' !== $this->wpdb->last_error ) {
			$err                    = $this->wpdb->last_error;
			$this->wpdb->last_error = '';
			throw new WstmException(
				'db_error',
				'Database operation failed.',
				array(
					'what'   => $op,
					'why'    => $err,
					'action' => 'Check database connectivity and permissions, then retry.',
				)
			);
		}
	}

	/**
	 * Run a query. Returns affected rows.
	 *
	 * @param string $sql    SQL.
	 * @param array  $params Params.
	 */
	public function query( string $sql, array $params = array() ): int {
		$res = $this->wpdb->query( $this->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB
		$this->check( 'query' );
		return (int) $res;
	}

	/**
	 * Get a single value.
	 *
	 * @param string $sql    SQL.
	 * @param array  $params Params.
	 */
	public function get_var( string $sql, array $params = array() ) {
		$v = $this->wpdb->get_var( $this->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB
		$this->check( 'get_var' );
		return $v;
	}

	/**
	 * Get a single row (assoc).
	 *
	 * @param string $sql    SQL.
	 * @param array  $params Params.
	 */
	public function get_row( string $sql, array $params = array() ): ?array {
		$r = $this->wpdb->get_row( $this->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$this->check( 'get_row' );
		return $r ?: null;
	}

	/**
	 * Get rows (assoc).
	 *
	 * @param string $sql    SQL.
	 * @param array  $params Params.
	 */
	public function get_results( string $sql, array $params = array() ): array {
		$r = $this->wpdb->get_results( $this->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$this->check( 'get_results' );
		return $r ?: array();
	}

	/**
	 * Insert into a plugin table; returns insert id.
	 *
	 * @param string $short Short table name.
	 * @param array  $data  Data.
	 */
	public function insert( string $short, array $data ): int {
		$ok = $this->wpdb->insert( $this->table( $short ), $data ); // phpcs:ignore WordPress.DB
		$this->check( 'insert ' . $short );
		return $ok ? (int) $this->wpdb->insert_id : 0;
	}

	/**
	 * Update a plugin table.
	 *
	 * @param string $short Short table name.
	 * @param array  $data  Data.
	 * @param array  $where Where.
	 */
	public function update( string $short, array $data, array $where ): int {
		$n = $this->wpdb->update( $this->table( $short ), $data, $where ); // phpcs:ignore WordPress.DB
		$this->check( 'update ' . $short );
		return (int) $n;
	}

	/**
	 * Delete from a plugin table.
	 *
	 * @param string $short Short table name.
	 * @param array  $where Where.
	 */
	public function delete( string $short, array $where ): int {
		$n = $this->wpdb->delete( $this->table( $short ), $where ); // phpcs:ignore WordPress.DB
		$this->check( 'delete ' . $short );
		return (int) $n;
	}

	/**
	 * Run callback inside a transaction (InnoDB). Rolls back on exception.
	 *
	 * @param callable $fn Callback.
	 * @throws \Throwable Rethrows.
	 */
	public function transaction( callable $fn ) {
		$this->wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB
		try {
			$r = $fn( $this );
			$this->wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB
			return $r;
		} catch ( \Throwable $e ) {
			$this->wpdb->query( 'ROLLBACK' ); // phpcs:ignore WordPress.DB
			throw $e;
		}
	}

	/**
	 * Quote an identifier (table/column) with backticks. Rejects anything odd.
	 *
	 * @param string $name Identifier.
	 * @throws WstmException On invalid identifier.
	 */
	public static function quote_identifier( string $name ): string {
		if ( ! preg_match( '/^[A-Za-z0-9_$\-]{1,64}$/', $name ) ) {
			throw new WstmException( 'bad_identifier', 'Invalid SQL identifier.', array( 'why' => 'Identifier contains disallowed characters' ) );
		}
		return '`' . $name . '`';
	}

	/** Server version string. */
	public function server_version(): string {
		return (string) $this->wpdb->get_var( 'SELECT VERSION()' ); // phpcs:ignore WordPress.DB
	}

	/** Whether server is MariaDB. */
	public function is_mariadb(): bool {
		return str_contains( strtolower( $this->server_version() ), 'mariadb' );
	}

	/**
	 * List all tables in the current database (optionally by prefix).
	 *
	 * @param string|null $prefix Prefix filter.
	 */
	public function list_tables( ?string $prefix = null ): array {
		$sql = null === $prefix
			? 'SHOW TABLES'
			: $this->wpdb->prepare( 'SHOW TABLES LIKE %s', $this->wpdb->esc_like( $prefix ) . '%' );
		return $this->wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Table status rows: name, rows, data/index size, engine, collation.
	 */
	public function table_status(): array {
		return $this->get_results( 'SHOW TABLE STATUS' );
	}

	/** Total DB size in bytes. */
	public function size_bytes(): int {
		$total = 0;
		foreach ( $this->table_status() as $t ) {
			$total += (int) $t['Data_length'] + (int) $t['Index_length'];
		}
		return $total;
	}

	/** max_allowed_packet in bytes. */
	public function max_allowed_packet(): int {
		$row = $this->get_row( "SHOW VARIABLES LIKE 'max_allowed_packet'" );
		return (int) ( $row['Value'] ?? 0 );
	}

	/**
	 * Execute a statement directly on the connection, bypassing wpdb's query
	 * rewriting (wpdb::strip_invalid_text_from_query can reject or slow down
	 * large INSERTs). Used by the import engine only.
	 *
	 * @param string $sql SQL.
	 * @throws WstmException On error (message includes server error + errno).
	 */
	public function raw_query( string $sql ): void {
		$dbh = $this->wpdb->dbh ?? null;
		if ( $dbh instanceof \mysqli ) {
			$res = mysqli_query( $dbh, $sql ); // phpcs:ignore WordPress.DB.RestrictedFunctions
			if ( false === $res ) {
				throw new WstmException(
					'db_error',
					'Database statement failed.',
					array(
						'why'   => mysqli_error( $dbh ), // phpcs:ignore WordPress.DB.RestrictedFunctions
						'errno' => mysqli_errno( $dbh ), // phpcs:ignore WordPress.DB.RestrictedFunctions
					)
				);
			}
			if ( $res instanceof \mysqli_result ) {
				mysqli_free_result( $res ); // phpcs:ignore WordPress.DB.RestrictedFunctions
			}
			return;
		}
		// Non-mysqli drivers (e.g. SQLite drop-in): use wpdb.
		$this->wpdb->last_error = '';
		$res                    = $this->wpdb->query( $sql ); // phpcs:ignore WordPress.DB
		if ( false === $res || '' !== $this->wpdb->last_error ) {
			$err                    = $this->wpdb->last_error;
			$this->wpdb->last_error = '';
			throw new WstmException( 'db_error', 'Database statement failed.', array( 'why' => $err ?: 'Unknown error', 'errno' => 0 ) );
		}
	}

	/**
	 * Numeric-indexed result rows (for streaming exports).
	 *
	 * @param string $sql SQL (already safe).
	 */
	public function get_rows_num( string $sql ): array {
		$r = $this->wpdb->get_results( $sql, ARRAY_N ); // phpcs:ignore WordPress.DB
		$this->check( 'select' );
		$this->wpdb->flush();
		return $r ?: array();
	}

	/**
	 * Whether a table exists.
	 *
	 * @param string $table Full table name.
	 */
	public function table_exists( string $table ): bool {
		return in_array( $table, $this->list_tables( $table ), true );
	}

	/** Connection charset used by wpdb. */
	public function charset(): string {
		return (string) ( $this->wpdb->charset ?: 'utf8mb4' );
	}

	/** Base table prefix. */
	public function base_prefix(): string {
		return (string) $this->wpdb->base_prefix;
	}

	/** Whether the connection is alive. */
	public function ping(): bool {
		return '1' === (string) $this->wpdb->get_var( 'SELECT 1' ); // phpcs:ignore WordPress.DB
	}
}
