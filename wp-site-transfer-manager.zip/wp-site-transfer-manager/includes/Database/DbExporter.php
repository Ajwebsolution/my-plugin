<?php
/**
 * Chunked, resumable database exporter.
 *
 * Stateless service: all progress lives in the $state array returned from
 * slice(), which the job manager persists as the job checkpoint. Rows are
 * read in batches (keyset pagination on integer primary keys, LIMIT/OFFSET
 * otherwise) and written as multi-row INSERTs capped by size, so memory use is
 * bounded by one batch regardless of table size.
 *
 * Dump layout:
 *   header (SET ...)
 *   per table: "-- WSTM:TABLE `t`", [DROP TABLE], CREATE TABLE, INSERTs, "-- WSTM:TABLE_END `t` rows=N"
 *   footer, "-- WSTM:END"  (completeness marker checked by the importer)
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Exporter.
 */
class DbExporter {

	/** Max bytes per INSERT statement (also capped by max_allowed_packet / 2). */
	public const MAX_STATEMENT_BYTES = 1048576;

	/** If a batch exceeds this many bytes the batch size is halved. */
	private const BATCH_BYTE_TARGET = 8388608;

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var TableScanner
	 */
	private TableScanner $scanner;

	/**
	 * Constructor.
	 *
	 * @param Database     $db      Database.
	 * @param TableScanner $scanner Scanner.
	 */
	public function __construct( Database $db, TableScanner $scanner ) {
		$this->db = $db;
		$this->scanner = $scanner;
	}

	/**
	 * Build initial state.
	 *
	 * @param array $opts file, tables[], gzip, drop_table, batch_rows.
	 */
	public static function init_state( array $opts ): array {
		return array(
			'stage'      => 'prepare',
			'file'       => (string) $opts['file'],
			'gzip'       => ! empty( $opts['gzip'] ),
			'drop'       => ! array_key_exists( 'drop_table', $opts ) || ! empty( $opts['drop_table'] ),
			'batch'      => max( 10, (int) ( $opts['batch_rows'] ?? 1000 ) ),
			'requested'  => array_values( array_unique( array_map( 'strval', (array) ( $opts['tables'] ?? array() ) ) ) ),
			'filters'    => (array) ( $opts['filters'] ?? array() ), // table => SQL condition (trusted, built internally).
			'tables'     => array(),
			't'          => 0,
			'cursor'     => null,
			'committed'  => 0,
			'raw_bytes'  => 0,
			'rows_done'  => 0,
			'rows_est'   => 0,
			'stmt_limit' => self::MAX_STATEMENT_BYTES,
			'warnings'   => array(),
			'hash'       => BlockHasher::init(),
			'started'    => time(),
		);
	}

	/**
	 * Perform one slice of work.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Unix deadline.
	 * @throws WstmException On failure (state not advanced).
	 */
	public function slice( array $s, int $deadline ): array {
		if ( 'prepare' === $s['stage'] ) {
			return $this->prepare( $s );
		}
		if ( 'hash' === $s['stage'] ) {
			$s['hash'] = BlockHasher::step( $s['file'], $s['hash'], $deadline );
			if ( $s['hash']['done'] ) {
				$s['stage'] = 'done';
			}
			return $s;
		}
		if ( 'done' === $s['stage'] ) {
			return $s;
		}

		$w = new DumpWriter( $s['file'], $s['gzip'], (int) $s['committed'] );
		try {
			// At least one unit of work per slice.
			do {
				$s = $this->advance( $s, $w );
			} while ( time() < $deadline && ! in_array( $s['stage'], array( 'hash', 'done' ), true ) );
		} catch ( \Throwable $e ) {
			$w->abort();
			throw $e;
		}
		$s['committed'] = $w->close();
		$s['raw_bytes'] += $w->written();
		return $s;
	}

	/**
	 * Validate requested tables and collect metadata.
	 *
	 * @param array $s State.
	 * @throws WstmException If nothing to export.
	 */
	private function prepare( array $s ): array {
		$all = array();
		foreach ( $this->scanner->tables() as $t ) {
			$all[ $t['name'] ] = $t;
		}
		$requested = $s['requested'] ?: $this->scanner->default_tables();
		foreach ( $requested as $name ) {
			if ( ! isset( $all[ $name ] ) ) {
				$s['warnings'][] = sprintf( 'Table %s does not exist and was skipped.', $name );
				continue;
			}
			$info = $all[ $name ];
			if ( in_array( $info['group'], array( 'plugin_internal', 'reserved' ), true ) ) {
				$s['warnings'][] = sprintf( 'Table %s belongs to the migration engine and is never exported.', $name );
				continue;
			}
			if ( $info['is_view'] ) {
				$s['warnings'][] = sprintf( 'View %s was skipped (views are not exported).', $name );
				continue;
			}
			$cols   = $this->scanner->columns( $name );
			$pk     = $this->scanner->primary_key( $name );
			$keyset = null;
			if ( 1 === count( $pk ) && preg_match( '/^(tinyint|smallint|mediumint|int|integer|bigint)\b/i', $cols[ $pk[0] ] ?? '' ) ) {
				$keyset = $pk[0];
			}
			$kinds  = array();
			$select = array();
			foreach ( $cols as $c => $type ) {
				$kind     = SqlEscaper::kind( $type );
				$kinds[]  = $kind;
				$select[] = 'bit' === $kind ? SqlEscaper::identifier( $c ) . '+0' : SqlEscaper::identifier( $c );
			}
			$s['tables'][]  = array(
				'name'   => $name,
				'cols'   => array_keys( $cols ),
				'kinds'  => $kinds,
				'select' => implode( ',', $select ),
				'pk'     => $pk,
				'keyset' => $keyset,
				'est'    => $info['rows'],
				'rows'   => 0,
			);
			$s['rows_est'] += max( 0, $info['rows'] );
		}
		if ( ! $s['tables'] ) {
			throw new WstmException( 'nothing_to_export', 'No exportable tables were selected.', array( 'what' => 'Database export', 'action' => 'Select at least one table.' ) );
		}
		$packet = $this->db->max_allowed_packet();
		if ( $packet > 0 ) {
			$s['stmt_limit'] = max( 65536, min( self::MAX_STATEMENT_BYTES, (int) ( $packet / 2 ) ) );
		}
		$s['charset'] = $this->db->charset();
		$s['stage']   = 'header';
		return $s;
	}

	/**
	 * Advance one unit of work.
	 *
	 * @param array      $s State.
	 * @param DumpWriter $w Writer.
	 */
	private function advance( array $s, DumpWriter $w ): array {
		switch ( $s['stage'] ) {
			case 'header':
				$w->write(
					"-- WP Site Transfer Manager database export\n" .
					'-- Generated: ' . gmdate( 'Y-m-d H:i:s' ) . " UTC\n" .
					'-- Server: ' . $this->db->server_version() . "\n\n" .
					'SET NAMES ' . preg_replace( '/[^a-z0-9_]/i', '', $s['charset'] ) . ";\n" .
					"SET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET TIME_ZONE='+00:00';\n"
				);
				$s['stage'] = 'structure';
				return $s;

			case 'structure':
				$t      = $s['tables'][ $s['t'] ];
				$create = $this->scanner->create_statement( $t['name'] );
				if ( null === $create ) {
					throw new WstmException( 'create_failed', 'Could not read table structure.', array( 'what' => 'Export table ' . $t['name'], 'why' => 'SHOW CREATE TABLE returned nothing', 'resumable' => true ) );
				}
				$q = SqlEscaper::identifier( $t['name'] );
				$w->write( "\n-- WSTM:TABLE {$q}\n" . ( $s['drop'] ? "DROP TABLE IF EXISTS {$q};\n" : '' ) . rtrim( $create, "; \n" ) . ";\n" );
				$s['stage']  = 'data';
				$s['cursor'] = null;
				$s['bsize']  = $s['batch'];
				return $s;

			case 'data':
				return $this->export_batch( $s, $w );

			case 'footer':
				$w->write( "\nSET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n-- WSTM:END\n" );
				$s['stage'] = 'hash';
				return $s;
		}
		return $s;
	}

	/**
	 * Export one batch of rows of the current table.
	 *
	 * @param array      $s State.
	 * @param DumpWriter $w Writer.
	 * @throws WstmException On query error.
	 */
	private function export_batch( array $s, DumpWriter $w ): array {
		$i     = $s['t'];
		$t     = $s['tables'][ $i ];
		$q     = SqlEscaper::identifier( $t['name'] );
		$limit = max( 10, (int) $s['bsize'] );

		if ( $t['keyset'] ) {
			$k   = SqlEscaper::identifier( $t['keyset'] );
			$conds = array();
			if ( ! empty( $s['filters'][ $t['name'] ] ) ) {
				$conds[] = '(' . $s['filters'][ $t['name'] ] . ')';
			}
			if ( null !== $s['cursor'] ) {
				$conds[] = "{$k} > " . $s['cursor'];
			}
			$sql = "SELECT {$t['select']} FROM {$q}" . ( $conds ? ' WHERE ' . implode( ' AND ', $conds ) : '' ) . " ORDER BY {$k} ASC LIMIT {$limit}";
		} else {
			$order = $t['pk'] ? ' ORDER BY ' . implode( ',', array_map( array( SqlEscaper::class, 'identifier' ), $t['pk'] ) ) : '';
			$where = ! empty( $s['filters'][ $t['name'] ] ) ? ' WHERE (' . $s['filters'][ $t['name'] ] . ')' : '';
			$sql   = "SELECT {$t['select']} FROM {$q}{$where}{$order} LIMIT {$limit} OFFSET " . (int) $s['cursor'];
		}

		try {
			$rows = $this->db->get_rows_num( $sql );
		} catch ( WstmException $e ) {
			throw new WstmException(
				'export_query_failed',
				'Reading table data failed.',
				array(
					'what'      => 'Export table ' . $t['name'],
					'why'       => $e->get_context()['why'] ?? $e->getMessage(),
					'completed' => sprintf( '%d rows of this table, %d rows total', $t['rows'], $s['rows_done'] ),
					'resumable' => true,
					'action'    => 'Resume; if it keeps failing, lower "Database rows per batch" in Settings.',
				),
				$e
			);
		}

		if ( ! $rows ) {
			$w->write( '-- WSTM:TABLE_END ' . $q . ' rows=' . $t['rows'] . "\n" );
			++$s['t'];
			$s['stage'] = $s['t'] < count( $s['tables'] ) ? 'structure' : 'footer';
			return $s;
		}

		$cols   = '(' . implode( ',', array_map( array( SqlEscaper::class, 'identifier' ), $t['cols'] ) ) . ')';
		$head   = "INSERT INTO {$q} {$cols} VALUES\n";
		$buf    = '';
		$bytes  = 0;
		$keypos = $t['keyset'] ? array_search( $t['keyset'], $t['cols'], true ) : false;
		$last   = null;

		foreach ( $rows as $row ) {
			$vals = array();
			foreach ( $row as $ci => $v ) {
				$vals[] = SqlEscaper::typed( $v, $t['kinds'][ $ci ] ?? 'str' );
			}
			$tuple = '(' . implode( ',', $vals ) . ')';
			if ( '' !== $buf && strlen( $buf ) + strlen( $tuple ) > $s['stmt_limit'] ) {
				$w->write( $head . $buf . ";\n" );
				$bytes += strlen( $buf );
				$buf    = '';
			}
			$buf .= ( '' === $buf ? '' : ",\n" ) . $tuple;
			if ( false !== $keypos ) {
				$last = $row[ $keypos ];
			}
		}
		if ( '' !== $buf ) {
			$w->write( $head . $buf . ";\n" );
			$bytes += strlen( $buf );
		}

		$n                          = count( $rows );
		$s['tables'][ $i ]['rows'] += $n;
		$s['rows_done']            += $n;

		if ( false !== $keypos ) {
			if ( null === $last || ! preg_match( '/^-?\d+$/', (string) $last ) ) {
				throw new WstmException( 'bad_key', 'Unexpected primary key value during export.', array( 'what' => 'Export table ' . $t['name'], 'why' => 'Non-integer key in integer column', 'resumable' => false ) );
			}
			$s['cursor'] = (string) $last;
		} else {
			$s['cursor'] = (int) $s['cursor'] + $n;
		}

		// Adapt batch size to row width to protect memory on low-RAM hosts.
		if ( $bytes > self::BATCH_BYTE_TARGET ) {
			$s['bsize'] = max( 10, (int) ( $limit / 2 ) );
		} elseif ( $bytes < self::BATCH_BYTE_TARGET / 4 && $limit < $s['batch'] ) {
			$s['bsize'] = min( $s['batch'], $limit * 2 );
		}
		if ( $n < $limit ) {
			// Short batch: the table is finished.
			$w->write( '-- WSTM:TABLE_END ' . $q . ' rows=' . $s['tables'][ $i ]['rows'] . "\n" );
			++$s['t'];
			$s['stage'] = $s['t'] < count( $s['tables'] ) ? 'structure' : 'footer';
		}
		return $s;
	}

	/**
	 * Progress 0–100 (row-based estimate during data, exact during hashing).
	 *
	 * @param array $s State.
	 */
	public static function progress( array $s ): float {
		switch ( $s['stage'] ) {
			case 'prepare':
			case 'header':
				return 0.0;
			case 'hash':
				$size = max( 1, (int) $s['committed'] );
				return 95.0 + 5.0 * min( 1, $s['hash']['offset'] / $size );
			case 'done':
				return 100.0;
		}
		$tables = max( 1, count( $s['tables'] ) );
		$by_tab = $s['t'] / $tables;
		$by_row = $s['rows_est'] > 0 ? min( 1, $s['rows_done'] / $s['rows_est'] ) : $by_tab;
		return round( min( 94.9, 95.0 * max( $by_tab, $by_row ) ), 2 );
	}

	/**
	 * Manifest data for a completed export.
	 *
	 * @param array $s State (stage done).
	 */
	public function manifest( array $s ): array {
		global $wp_version;
		return array(
			'created_at'   => gmdate( 'c' ),
			'generator'    => 'WP Site Transfer Manager ' . WSTM_VERSION,
			'file'         => basename( $s['file'] ),
			'gzip'         => $s['gzip'],
			'size'         => (int) $s['committed'],
			'raw_size'     => (int) $s['raw_bytes'],
			'checksum'     => array(
				'algo'       => BlockHasher::ALGO,
				'block_size' => BlockHasher::BLOCK_SIZE,
				'blocks'     => $s['hash']['blocks'],
				'hash'       => $s['hash']['hash'],
			),
			'site_url'     => site_url(),
			'home_url'     => home_url(),
			'table_prefix' => $this->db->base_prefix(),
			'multisite'    => is_multisite(),
			'wp_version'   => $wp_version,
			'db_server'    => $this->db->server_version(),
			'charset'      => $s['charset'] ?? $this->db->charset(),
			'tables'       => array_map( static fn( $t ) => array( 'name' => $t['name'], 'rows' => $t['rows'] ), $s['tables'] ),
			'rows'         => (int) $s['rows_done'],
			'warnings'     => $s['warnings'],
		);
	}
}
