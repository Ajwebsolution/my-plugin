<?php
/**
 * SQL value/identifier escaping for dump generation.
 *
 * Output is valid for MySQL/MariaDB sessions WITHOUT the NO_BACKSLASH_ESCAPES
 * sql_mode (the importer always sets an explicit sql_mode).
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Escaper.
 */
final class SqlEscaper {

	/**
	 * Column types exported as hex literals (binary-safe, charset-independent).
	 */
	private const BINARY_TYPE_RE = '/^(tinyblob|blob|mediumblob|longblob|binary|varbinary|bit|geometry|point|linestring|polygon|multipoint|multilinestring|multipolygon|geometrycollection)\b/i';

	/**
	 * Whether a column type should be hex-encoded.
	 *
	 * @param string $type Column type from SHOW COLUMNS (e.g. "varbinary(255)").
	 */
	public static function is_binary_type( string $type ): bool {
		return 1 === preg_match( self::BINARY_TYPE_RE, trim( $type ) );
	}

	/**
	 * Export kind for a column type: "bit" (numeric), "bin" (hex) or "str" (quoted).
	 *
	 * @param string $type Column type.
	 */
	public static function kind( string $type ): string {
		if ( preg_match( '/^bit\b/i', trim( $type ) ) ) {
			return 'bit';
		}
		return self::is_binary_type( $type ) ? 'bin' : 'str';
	}

	/**
	 * Escape a value according to its column kind.
	 *
	 * @param string|int|float|null $value Value.
	 * @param string                $kind  bit|bin|str.
	 * @throws WstmException On a non-numeric BIT value (selected as `col`+0).
	 */
	public static function typed( $value, string $kind ): string {
		if ( 'bit' === $kind && null !== $value ) {
			$value = (string) $value;
			if ( ! ctype_digit( $value ) ) {
				throw new WstmException( 'bad_bit', 'Unexpected BIT value during export.', array( 'why' => 'Expected an integer' ) );
			}
			return $value;
		}
		return self::value( $value, 'bin' === $kind );
	}

	/**
	 * Escape one value as a SQL literal.
	 *
	 * @param string|int|float|null $value  Value from the result set.
	 * @param bool                  $binary Hex-encode.
	 */
	public static function value( $value, bool $binary ): string {
		if ( null === $value ) {
			return 'NULL';
		}
		$value = (string) $value;
		if ( $binary ) {
			return '' === $value ? "''" : '0x' . bin2hex( $value );
		}
		return "'" . strtr(
			$value,
			array(
				'\\'   => '\\\\',
				"\0"   => '\\0',
				"\n"   => '\\n',
				"\r"   => '\\r',
				"'"    => "\\'",
				'"'    => '\\"',
				"\x1a" => '\\Z',
			)
		) . "'";
	}

	/**
	 * Quote an identifier with backticks (doubling embedded backticks).
	 *
	 * @param string $name Identifier.
	 * @throws WstmException On empty/oversized/null-byte identifiers.
	 */
	public static function identifier( string $name ): string {
		if ( '' === $name || strlen( $name ) > 64 || str_contains( $name, "\0" ) ) {
			throw new WstmException( 'bad_identifier', 'Invalid SQL identifier.', array( 'why' => 'Identifier is empty, too long or contains a null byte' ) );
		}
		return '`' . str_replace( '`', '``', $name ) . '`';
	}
}
