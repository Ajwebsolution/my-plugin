<?php
/**
 * Resumable gzip decompression.
 *
 * Gzip files may consist of several concatenated members. Our exporter writes
 * one member per request, so member boundaries are frequent; decompression
 * checkpoints at each boundary (compressed offset + output size) and can
 * resume there in a later request. Foreign single-member files are still
 * supported but can only checkpoint at the end of the member.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Inflater.
 */
final class GzipInflater {

	private const READ = 1048576;

	/** Fresh state. */
	public static function init(): array {
		return array(
			'in'   => 0,
			'out'  => 0,
			'done' => false,
		);
	}

	/**
	 * Decompress until done or deadline (checked at member boundaries).
	 *
	 * @param string $src      Source .gz.
	 * @param string $dst      Destination file.
	 * @param array  $st       State.
	 * @param int    $deadline Deadline.
	 * @throws WstmException On corrupt input or I/O failure.
	 */
	public static function step( string $src, string $dst, array $st, int $deadline ): array {
		if ( ! function_exists( 'inflate_init' ) ) {
			throw new WstmException( 'zlib_missing', 'This server cannot decompress .gz files.', array( 'action' => 'Upload an uncompressed .sql dump instead.' ) );
		}
		clearstatcache();
		$in_size = (int) filesize( $src );
		$in      = fopen( $src, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$out     = fopen( $dst, 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $in || ! $out ) {
			throw new WstmException( 'io_error', 'Could not open files for decompression.', array( 'resumable' => true ) );
		}
		try {
			// Discard output beyond the last committed member boundary.
			ftruncate( $out, $st['out'] );
			fseek( $out, $st['out'] );

			while ( $st['in'] < $in_size ) {
				// Skip zero padding some tools append after the last member.
				fseek( $in, $st['in'] );
				$peek = fread( $in, 2 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( "\x1f\x8b" !== $peek ) {
					$rest = stream_get_contents( $in, 4096, $st['in'] );
					if ( '' === trim( (string) $rest, "\0" ) ) {
						$st['in'] = $in_size;
						break;
					}
					throw self::corrupt( $st['in'] );
				}
				fseek( $in, $st['in'] );

				$ctx      = inflate_init( ZLIB_ENCODING_GZIP );
				$member   = $st['in'];
				$finished = false;
				while ( ! feof( $in ) ) {
					$data = fread( $in, self::READ ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( false === $data ) {
						throw new WstmException( 'io_error', 'Read error during decompression.', array( 'resumable' => true ) );
					}
					$chunk = @inflate_add( $ctx, $data, ZLIB_SYNC_FLUSH ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
					if ( false === $chunk ) {
						throw self::corrupt( $member );
					}
					if ( '' !== $chunk && fwrite( $out, $chunk ) !== strlen( $chunk ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
						throw new WstmException( 'write_failed', 'Writing decompressed data failed.', array( 'why' => 'Disk full?', 'resumable' => true, 'action' => 'Free disk space and resume.' ) );
					}
					if ( ZLIB_STREAM_END === inflate_get_status( $ctx ) ) {
						$finished = true;
						break;
					}
				}
				if ( ! $finished ) {
					throw new WstmException( 'gzip_truncated', 'The compressed file is truncated.', array( 'what' => 'Decompression', 'why' => 'Gzip stream ended unexpectedly at byte ' . $member, 'action' => 'Re-create or re-upload the dump.' ) );
				}
				fflush( $out );
				$st['in']  = $member + inflate_get_read_len( $ctx );
				$st['out'] = ftell( $out );
				if ( time() >= $deadline ) {
					break;
				}
			}
		} finally {
			fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$st['done'] = $st['in'] >= $in_size;
		return $st;
	}

	/**
	 * Corruption error.
	 *
	 * @param int $at Offset.
	 */
	private static function corrupt( int $at ): WstmException {
		return new WstmException( 'gzip_corrupt', 'The compressed file is corrupted.', array( 'what' => 'Decompression', 'why' => 'Invalid gzip data at byte ' . $at, 'action' => 'Re-create or re-upload the dump.' ) );
	}
}
