<?php
/**
 * Plugin table schema (installed via dbDelta).
 *
 * All six tables are defined now so later phases do not need structural
 * migrations; Phase 1 only reads/writes jobs and logs.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Schema installer.
 */
final class Schema {

	public const VERSION_OPTION = 'wstm_db_version';

	/**
	 * CREATE TABLE statements.
	 */
	public static function sql(): array {
		global $wpdb;
		$p       = $wpdb->base_prefix . 'wstm_';
		$charset = $wpdb->get_charset_collate();

		return array(
			"CREATE TABLE {$p}jobs (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				uuid char(36) NOT NULL,
				type varchar(40) NOT NULL,
				status varchar(20) NOT NULL DEFAULT 'pending',
				current_step varchar(64) NOT NULL DEFAULT '',
				progress decimal(5,2) NOT NULL DEFAULT 0.00,
				checkpoint longtext NULL,
				metadata longtext NULL,
				error longtext NULL,
				parent_id bigint(20) unsigned NULL,
				lock_token char(32) NULL,
				locked_until datetime NULL,
				attempts int(10) unsigned NOT NULL DEFAULT 0,
				created_by bigint(20) unsigned NULL,
				started_at datetime NULL,
				updated_at datetime NOT NULL,
				finished_at datetime NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY uuid (uuid),
				KEY status_type (status,type),
				KEY parent_id (parent_id),
				KEY updated_at (updated_at)
			) {$charset};",

			"CREATE TABLE {$p}logs (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				level varchar(10) NOT NULL,
				channel varchar(32) NOT NULL DEFAULT 'general',
				job_id bigint(20) unsigned NULL,
				message text NOT NULL,
				context longtext NULL,
				user_id bigint(20) unsigned NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY level (level),
				KEY job_id (job_id),
				KEY created_at (created_at)
			) {$charset};",

			"CREATE TABLE {$p}transfers (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				transfer_id char(32) NOT NULL,
				direction varchar(10) NOT NULL,
				secret_hash char(64) NOT NULL,
				secret_enc text NULL,
				meta longtext NULL,
				remote_url varchar(255) NOT NULL DEFAULT '',
				status varchar(20) NOT NULL DEFAULT 'active',
				job_id bigint(20) unsigned NULL,
				expires_at datetime NOT NULL,
				used_at datetime NULL,
				revoked_at datetime NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY transfer_id (transfer_id),
				KEY status_expires (status,expires_at)
			) {$charset};",

			"CREATE TABLE {$p}backups (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				uuid char(36) NOT NULL,
				type varchar(20) NOT NULL,
				label varchar(191) NOT NULL DEFAULT '',
				file_path text NOT NULL,
				size_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
				checksum char(64) NULL,
				verified tinyint(1) NOT NULL DEFAULT 0,
				is_safety tinyint(1) NOT NULL DEFAULT 0,
				parent_backup_id bigint(20) unsigned NULL,
				job_id bigint(20) unsigned NULL,
				manifest longtext NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY uuid (uuid),
				KEY type_created (type,created_at)
			) {$charset};",

			"CREATE TABLE {$p}chunks (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				job_id bigint(20) unsigned NOT NULL,
				chunk_index int(10) unsigned NOT NULL,
				object_key varchar(191) NOT NULL DEFAULT '',
				byte_offset bigint(20) unsigned NOT NULL DEFAULT 0,
				size_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
				checksum char(64) NULL,
				status varchar(20) NOT NULL DEFAULT 'pending',
				attempts int(10) unsigned NOT NULL DEFAULT 0,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY job_chunk (job_id,object_key,chunk_index),
				KEY job_status (job_id,status)
			) {$charset};",

			"CREATE TABLE {$p}packages (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				uuid char(36) NOT NULL,
				file_path text NOT NULL,
				size_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
				checksum char(64) NULL,
				source_url varchar(255) NOT NULL DEFAULT '',
				status varchar(20) NOT NULL DEFAULT 'building',
				manifest longtext NULL,
				job_id bigint(20) unsigned NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY uuid (uuid),
				KEY status (status)
			) {$charset};",
		);
	}

	/**
	 * Install / upgrade.
	 */
	public static function install(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( self::sql() as $statement ) {
			dbDelta( $statement );
		}
		update_site_option( self::VERSION_OPTION, WSTM_DB_VERSION );
	}

	/**
	 * Drop all plugin tables (uninstall only, opt-in).
	 */
	public static function drop(): void {
		global $wpdb;
		foreach ( Database::TABLES as $t ) {
			$wpdb->query( 'DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'wstm_' . $t . '`' ); // phpcs:ignore WordPress.DB
		}
		delete_site_option( self::VERSION_OPTION );
	}
}
