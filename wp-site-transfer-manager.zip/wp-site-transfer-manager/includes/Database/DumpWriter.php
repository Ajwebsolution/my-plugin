<?php
/**
 * Append-only dump writer with crash-safe resume.
 *
 * Each open/close cycle appends a complete gzip member (when compressing),
 * so the committed file size always lands on a valid boundary. On resume the
 * file is truncated back to the last committed size, discarding any partial
 * output from a request that was killed mid-write.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Dump writer.
 */
final class DumpWriter {

	/**
	 * Handle.
	 *
	 * @var resource|null
	 */
	private $fh = null;

	/** Uncompressed bytes written in this session. */
	private int $written = 0;

	/**
	 * @var string
	 */
	private string $path;

	/**
	 * @var bool
	 */
	private bool $gzip;

	/**
	 * Constructor.
	 *
	 * @param string $path      File path.
	 * @param bool   $gzip      Compress.
	 * @param int    $committed Last committed size.
	 * @throws WstmException On I/O failure.
	 */
	public function __construct( string $path, bool $gzip, int $committed ) {
		$this->path = $path;
		$this->gzip = $gzip;
		clearstatcache( true, $path );
		$exists = file_exists( $path );
		if ( $committed > 0 && ! $exists ) {
			throw new WstmException(
				'dump_missing',
				'The partially written export file is missing.',
				array(
					'what'   => 'Resume export',
					'why'    => 'File was deleted: ' . basename( $path ),
					'action' => 'Cancel this job and start a new export.',
				)
			);
		}
		if ( $exists && filesize( $path ) !== $committed ) {
			$h = fopen( $path, 'r+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( ! $h || ! ftruncate( $h, $committed ) ) {
				throw new WstmException( 'io_error', 'Could not truncate the export file to its last checkpoint.', array( 'why' => basename( $path ), 'resumable' => true ) );
			}
			fclose( $h ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$this->fh = $gzip ? gzopen( $path, 'ab6' ) : fopen( $path, 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $this->fh ) {
			throw new WstmException( 'io_error', 'Could not open the export file for writing.', array( 'why' => basename( $path ), 'resumable' => true, 'action' => 'Check that the storage folder is writable.' ) );
		}
	}

	/**
	 * Write data.
	 *
	 * @param string $data Data.
	 * @throws WstmException On short write (usually disk full).
	 */
	public function write( string $data ): void {
		if ( '' === $data ) {
			return;
		}
		$len = strlen( $data );
		$n   = $this->gzip ? gzwrite( $this->fh, $data ) : fwrite( $this->fh, $data ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $n || $n < $len ) {
			throw new WstmException(
				'write_failed',
				'Writing the export file failed.',
				array(
					'what'      => 'Database export',
					'why'       => 'Short write — the disk is probably full or quota exceeded.',
					'resumable' => true,
					'action'    => 'Free disk space, then resume. Output after the last checkpoint is discarded automatically.',
				)
			);
		}
		$this->written += $len;
	}

	/** Uncompressed bytes written this session. */
	public function written(): int {
		return $this->written;
	}

	/**
	 * Close and return the new committed file size.
	 *
	 * @throws WstmException If close fails.
	 */
	public function close(): int {
		if ( $this->fh ) {
			$ok       = $this->gzip ? gzclose( $this->fh ) : fclose( $this->fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$this->fh = null;
			if ( ! $ok ) {
				throw new WstmException( 'write_failed', 'Could not finalise the export file.', array( 'why' => 'close() failed (disk full?)', 'resumable' => true ) );
			}
		}
		clearstatcache( true, $this->path );
		return (int) filesize( $this->path );
	}

	/** Abort without committing. */
	public function abort(): void {
		if ( $this->fh ) {
			$this->gzip ? gzclose( $this->fh ) : fclose( $this->fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$this->fh = null;
		}
	}
}
