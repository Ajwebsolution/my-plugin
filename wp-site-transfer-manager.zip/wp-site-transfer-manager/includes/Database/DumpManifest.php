<?php
/**
 * Database dump manifest (sidecar JSON next to every export).
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Manifest helper.
 */
final class DumpManifest {

	public const FORMAT  = 'wstm-db-dump';
	public const VERSION = 1;

	/**
	 * Manifest path for a dump file.
	 *
	 * @param string $dump Dump path (.sql or .sql.gz).
	 */
	public static function path_for( string $dump ): string {
		return preg_replace( '/\.sql(\.gz)?$/', '', $dump ) . '.manifest.json';
	}

	/**
	 * Write atomically (temp file + rename).
	 *
	 * @param string $path Path.
	 * @param array  $data Data.
	 * @throws WstmException On failure.
	 */
	public static function write( string $path, array $data ): void {
		$data = array_merge( array( 'format' => self::FORMAT, 'version' => self::VERSION ), $data );
		$tmp  = $path . '.tmp';
		$json = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		if ( false === $json || false === file_put_contents( $tmp, $json ) || ! rename( $tmp, $path ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			throw new WstmException( 'write_failed', 'Could not write the export manifest.', array( 'why' => basename( $path ), 'resumable' => true ) );
		}
	}

	/**
	 * Read and validate.
	 *
	 * @param string $path Path.
	 * @throws WstmException When invalid.
	 */
	public static function read( string $path ): array {
		$raw  = is_readable( $path ) ? file_get_contents( $path, false, null, 0, 8 * MB_IN_BYTES ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = false === $raw ? null : json_decode( $raw, true );
		if ( ! is_array( $data ) || ( $data['format'] ?? '' ) !== self::FORMAT || ! isset( $data['tables'], $data['checksum']['hash'], $data['size'] ) || ! is_array( $data['tables'] ) ) {
			throw new WstmException(
				'bad_manifest',
				'The dump manifest is missing or invalid.',
				array(
					'what'   => 'Manifest validation',
					'why'    => basename( $path ),
					'action' => 'Use a dump created by WP Site Transfer Manager, or import the .sql file without its manifest.',
				)
			);
		}
		if ( (int) $data['version'] > self::VERSION ) {
			throw new WstmException( 'manifest_version', 'This dump was created by a newer plugin version.', array( 'action' => 'Update the plugin on this site first.' ) );
		}
		return $data;
	}
}
