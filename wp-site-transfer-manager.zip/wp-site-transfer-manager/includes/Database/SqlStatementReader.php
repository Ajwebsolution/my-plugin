<?php
/**
 * Streaming SQL statement reader.
 *
 * Reads a .sql file from an arbitrary byte offset and yields complete
 * statements one at a time, correctly handling quoted strings ('', "", ``),
 * backslash escapes, doubled quotes and comments (--, #, block). Memory use is
 * bounded by the largest single statement.
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Statement reader.
 */
final class SqlStatementReader {

	public const READ_SIZE     = 1048576;
	public const MAX_STATEMENT = 134217728; // 128 MB safety cap.

	/**
	 * Handle.
	 *
	 * @var resource
	 */
	private $fh;

	/** Buffered unread data. */
	private string $buf = '';

	/** Absolute file offset of $buf[0]. */
	private int $buf_offset;

	/** Scan position inside $buf. */
	private int $pos = 0;

	/** Current quote char or ''. */
	private string $quote = '';

	/** Whether EOF has been reached. */
	private bool $eof = false;

	/** Whether the post-EOF rescan has happened. */
	private bool $final_pass = false;

	/**
	 * Constructor.
	 *
	 * @param string $path   File.
	 * @param int    $offset Byte offset (must be a statement boundary).
	 * @throws WstmException If unreadable.
	 */
	public function __construct( string $path, int $offset = 0 ) {
		$fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh || ( $offset > 0 && 0 !== fseek( $fh, $offset ) ) ) {
			throw new WstmException( 'io_error', 'Could not open the SQL file.', array( 'why' => basename( $path ), 'resumable' => true ) );
		}
		$this->fh         = $fh;
		$this->buf_offset = $offset;
	}

	/** Close. */
	public function __destruct() {
		if ( is_resource( $this->fh ) ) {
			fclose( $this->fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}

	/**
	 * Read more data into the buffer.
	 */
	private function fill(): bool {
		if ( $this->eof ) {
			return false;
		}
		$chunk = fread( $this->fh, self::READ_SIZE ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( false === $chunk || '' === $chunk ) {
			$this->eof = true;
			return false;
		}
		$this->buf .= $chunk;
		if ( strlen( $this->buf ) > self::MAX_STATEMENT ) {
			throw new WstmException(
				'statement_too_large',
				'A SQL statement is larger than 128 MB or the file is malformed.',
				array(
					'what'   => 'SQL parsing',
					'why'    => 'No statement terminator found near byte ' . $this->buf_offset,
					'action' => 'Check that the dump is complete and not corrupted.',
				)
			);
		}
		return true;
	}

	/**
	 * Next statement, or null at end of file.
	 *
	 * @return array{sql:string,end:int}|null  end = absolute offset just after the statement.
	 * @throws WstmException On truncated input.
	 */
	public function next(): ?array {
		while ( true ) {
			$len = strlen( $this->buf );
			$i   = $this->pos;

			while ( $i < $len ) {
				if ( '' === $this->quote ) {
					$i += strcspn( $this->buf, "'\"`;-#/", $i );
					if ( $i >= $len ) {
						break;
					}
					$c = $this->buf[ $i ];
					if ( ';' === $c ) {
						$sql              = substr( $this->buf, 0, $i + 1 );
						$end              = $this->buf_offset + $i + 1;
						$this->buf        = (string) substr( $this->buf, $i + 1 );
						$this->buf_offset = $end;
						$this->pos        = 0;
						return array(
							'sql' => $sql,
							'end' => $end,
						);
					}
					if ( "'" === $c || '"' === $c || '`' === $c ) {
						$this->quote = $c;
						++$i;
						continue;
					}
					// Comments need lookahead; if lookahead is not buffered yet, read more.
					if ( '-' === $c || '/' === $c ) {
						if ( $i + 2 >= $len && ! $this->eof ) {
							break;
						}
						$n1 = $this->buf[ $i + 1 ] ?? '';
						$n2 = $this->buf[ $i + 2 ] ?? '';
						if ( '-' === $c && '-' === $n1 && ( '' === $n2 || ctype_space( $n2 ) ) ) {
							$nl = strpos( $this->buf, "\n", $i );
							if ( false === $nl ) {
								if ( ! $this->eof ) {
									break;
								}
								$i = $len;
								continue;
							}
							$i = $nl + 1;
							continue;
						}
						if ( '/' === $c && '*' === $n1 ) {
							$close = strpos( $this->buf, '*/', $i + 2 );
							if ( false === $close ) {
								if ( ! $this->eof ) {
									break;
								}
								throw $this->truncated();
							}
							$i = $close + 2;
							continue;
						}
						++$i;
						continue;
					}
					if ( '#' === $c ) {
						$nl = strpos( $this->buf, "\n", $i );
						if ( false === $nl ) {
							if ( ! $this->eof ) {
								break;
							}
							$i = $len;
							continue;
						}
						$i = $nl + 1;
						continue;
					}
					++$i;
					continue;
				}

				// Inside a quoted string/identifier.
				$q     = $this->quote;
				$stops = '`' === $q ? '`' : $q . '\\';
				$i    += strcspn( $this->buf, $stops, $i );
				if ( $i >= $len ) {
					break;
				}
				if ( '\\' === $this->buf[ $i ] ) {
					if ( $i + 1 >= $len && ! $this->eof ) {
						break;
					}
					$i += 2;
					continue;
				}
				// Closing quote or doubled quote.
				if ( $i + 1 >= $len && ! $this->eof ) {
					break;
				}
				if ( ( $this->buf[ $i + 1 ] ?? '' ) === $q ) {
					$i += 2;
					continue;
				}
				$this->quote = '';
				++$i;
			}

			$this->pos = min( $i, strlen( $this->buf ) );
			if ( $this->fill() ) {
				continue;
			}
			if ( ! $this->final_pass ) {
				// Rescan once with EOF known, so lookahead-dependent tokens resolve.
				$this->final_pass = true;
				continue;
			}

			// EOF: anything left must be whitespace/comments only.
			if ( '' !== $this->quote || '' !== self::strip_leading( $this->buf ) ) {
				throw $this->truncated();
			}
			return null;
		}
	}

	/**
	 * Error for an incomplete trailing statement.
	 */
	private function truncated(): WstmException {
		return new WstmException(
			'sql_truncated',
			'The SQL file ends in the middle of a statement.',
			array(
				'what'   => 'SQL parsing',
				'why'    => 'Incomplete statement starting at byte ' . $this->buf_offset . ' — the file is truncated or corrupted.',
				'action' => 'Re-create or re-upload the dump.',
			)
		);
	}

	/**
	 * Remove leading whitespace and comments (but not MySQL /*! executable comments
	 * which are treated as comments too — they only carry optional session settings).
	 *
	 * @param string $sql SQL.
	 */
	public static function strip_leading( string $sql ): string {
		while ( true ) {
			$sql = ltrim( $sql );
			if ( str_starts_with( $sql, '#' ) || preg_match( '/^--(\s|$)/', $sql ) ) {
				$nl  = strpos( $sql, "\n" );
				$sql = false === $nl ? '' : substr( $sql, $nl + 1 );
				continue;
			}
			if ( str_starts_with( $sql, '/*' ) ) {
				$end = strpos( $sql, '*/' );
				$sql = false === $end ? '' : substr( $sql, $end + 2 );
				continue;
			}
			return $sql;
		}
	}
}
