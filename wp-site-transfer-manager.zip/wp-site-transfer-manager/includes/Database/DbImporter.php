<?php
/**
 * Safe, resumable database importer.
 *
 * Safety model:
 *   1. The live database is NEVER written while the dump is being imported.
 *      Every table is created and filled under a temporary name
 *      ("wstmi_" + original name).
 *   2. After all statements run, row counts of the temporary tables are
 *      verified against the dump manifest.
 *   3. Only then are tables swapped with ONE atomic RENAME TABLE statement.
 *      Replaced live tables are kept as "wstmo_" + name (rollback copies).
 *   4. Each executed statement and its checkpoint are committed in the same
 *      transaction, so a killed request never re-executes an INSERT on resume
 *      (InnoDB tables; DDL statements are idempotent by design).
 *
 * Stages: precheck → verify → safety → decompress → import → verify_rows → swap → cleanup → done
 *
 * @package WSTM\Database
 */

namespace WSTM\Database;

use WSTM\Core\Logger;
use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Importer.
 */
class DbImporter {

	public const TMP_PREFIX = 'wstmi_';

	/** Tables to keep from the destination (set per slice from state). @var string[] */
	private array $skip_tables = array();
	public const OLD_PREFIX = 'wstmo_';

	/** Options that belong to the destination plugin installation and survive an import. */
	public const PRESERVED_OPTIONS = array( 'wstm_settings', 'wstm_storage_dirname', 'wstm_db_version' );

	/** Max warnings kept in state. */
	private const MAX_WARNINGS = 100;

	/**
	 * @var Database
	 */
	private Database $db;

	/**
	 * @var TableScanner
	 */
	private TableScanner $scanner;

	/**
	 * @var Logger
	 */
	private Logger $logger;

	/**
	 * @var int
	 */
	private int $job_id;

	/**
	 * Constructor.
	 *
	 * @param Database     $db       Database.
	 * @param TableScanner $scanner  Scanner.
	 * @param Logger       $logger   Logger.
	 * @param int          $job_id   Job id (for log context).
	 */
	public function __construct( Database $db, TableScanner $scanner, Logger $logger, int $job_id = 0 ) {
		$this->db = $db;
		$this->scanner = $scanner;
		$this->logger = $logger;
		$this->job_id = $job_id;
	}

	/**
	 * Initial state.
	 *
	 * @param array $opts source, manifest (path|null), work_dir, safety_file (path|null), batch_rows.
	 */
	public static function init_state( array $opts ): array {
		$source = (string) $opts['source'];
		return array(
			'stage'       => 'precheck',
			'source'      => $source,
			'manifest'    => $opts['manifest'] ?? null,
			'gzip'        => str_ends_with( strtolower( $source ), '.gz' ),
			'work_dir'    => (string) $opts['work_dir'],
			'sql'         => null,
			'safety_file' => $opts['safety_file'] ?? null,
			'safety'      => null,
			'batch_rows'  => (int) ( $opts['batch_rows'] ?? 1000 ),
			'hash'        => BlockHasher::init(),
			'gz'          => GzipInflater::init(),
			'offset'      => 0,
			'sql_size'    => 0,
			'statements'  => 0,
			'current'     => '',
			'tables'      => array(),
			'skipped'     => array(),
			'expected'    => array(),
			'vi'          => 0,
			'counts'      => array(),
			'warnings'    => array(),
			'previous'    => array(),
			'allow_prefix' => ! empty( $opts['allow_prefix_change'] ),
			'prefix_from' => null,
			'defer_swap'  => ! empty( $opts['defer_swap'] ),
			'skip_tables' => array_values( (array) ( $opts['skip_tables'] ?? array() ) ),
			'collations'  => array(),
		);
	}

	/**
	 * Run one slice.
	 *
	 * @param array    $s        State.
	 * @param int      $deadline Deadline.
	 * @param callable $commit   fn(array $state): void — persists checkpoint (called inside the statement transaction).
	 * @param callable $safety   fn(array $safety_state, int $deadline): array — runs one slice of the safety export.
	 * @throws WstmException On failure.
	 */
	public function slice( array $s, int $deadline, callable $commit, callable $safety ): array {
		switch ( $s['stage'] ) {
			case 'precheck':
				return $this->precheck( $s );

			case 'verify':
				$s['hash'] = BlockHasher::step( $s['source'], $s['hash'], $deadline );
				if ( $s['hash']['done'] ) {
					$m = DumpManifest::read( $s['manifest'] );
					if ( ! hash_equals( (string) $m['checksum']['hash'], (string) $s['hash']['hash'] ) ) {
						throw new WstmException(
							'checksum_mismatch',
							'The dump file failed checksum verification.',
							array(
								'what'   => 'Integrity check',
								'why'    => 'SHA-256 does not match the manifest — the file is corrupted or was modified.',
								'action' => 'Re-create or re-upload the dump. Nothing on this site was changed.',
							)
						);
					}
					$s['stage'] = $s['safety_file'] ? 'safety' : ( $s['gzip'] ? 'decompress' : 'import' );
				}
				return $s;

			case 'safety':
				$s['safety'] = $safety( $s['safety'], $deadline );
				if ( 'done' === ( $s['safety']['stage'] ?? '' ) ) {
					$s['stage'] = $s['gzip'] ? 'decompress' : 'import';
				}
				return $s;

			case 'decompress':
				$s['gz'] = GzipInflater::step( $s['source'], $s['sql'], $s['gz'], $deadline );
				if ( $s['gz']['done'] ) {
					$s['stage'] = 'import';
				}
				return $s;

			case 'import':
				return $this->import( $s, $deadline, $commit );

			case 'verify_rows':
				return $this->verify_rows( $s, $deadline );

			case 'prefix_fix':
				return $this->prefix_fix( $s );

			case 'ready':
				return $s; // Waiting for the caller to request the swap (stage = 'swap').

			case 'swap':
				return $this->swap( $s );

			case 'cleanup':
				if ( $s['gzip'] && $s['sql'] && is_file( $s['sql'] ) ) {
					wp_delete_file( $s['sql'] );
				}
				$s['stage'] = 'done';
				return $s;
		}
		return $s;
	}

	/**
	 * Validate inputs before anything is modified.
	 *
	 * @param array $s State.
	 * @throws WstmException When the import is unsafe.
	 */
	private function precheck( array $s ): array {
		if ( ! is_file( $s['source'] ) || ! is_readable( $s['source'] ) ) {
			throw new WstmException( 'source_missing', 'The dump file cannot be read.', array( 'what' => 'Import precheck', 'why' => basename( $s['source'] ), 'action' => 'Choose an existing dump.' ) );
		}
		$base = $this->db->base_prefix();

		if ( $s['manifest'] ) {
			$m = DumpManifest::read( $s['manifest'] );
			clearstatcache( true, $s['source'] );
			if ( (int) filesize( $s['source'] ) !== (int) $m['size'] ) {
				throw new WstmException( 'size_mismatch', 'The dump file size does not match its manifest.', array( 'what' => 'Import precheck', 'why' => 'File is incomplete or modified.', 'action' => 'Re-upload the dump. Nothing was changed.' ) );
			}
			if ( (string) $m['table_prefix'] !== $base && $s['allow_prefix'] && ! is_multisite() && empty( $m['multisite'] ) ) {
				$s['prefix_from'] = (string) $m['table_prefix'];
				$s['warnings'][]  = sprintf( 'Table prefix converted from "%s" to "%s".', $m['table_prefix'], $base );
			} elseif ( (string) $m['table_prefix'] !== $base ) {
				throw new WstmException(
					'prefix_mismatch',
					'The dump uses a different table prefix.',
					array(
						'what'   => 'Import precheck',
						'why'    => sprintf( 'Dump prefix "%s", this site uses "%s".', $m['table_prefix'], $base ),
						'action' => 'Use the one-click Import screen, which converts table prefixes automatically (single sites). Nothing was changed.',
					)
				);
			}
			if ( 'utf8mb4' === ( $m['charset'] ?? '' ) && 'utf8mb4' !== $this->db->charset() ) {
				throw new WstmException( 'charset_mismatch', 'This database connection cannot store all characters in the dump.', array( 'why' => 'Dump is utf8mb4, connection is ' . $this->db->charset(), 'action' => 'Set DB_CHARSET to utf8mb4 in wp-config.php.' ) );
			}
			foreach ( $m['tables'] as $t ) {
				$name = $this->map_table( $s, (string) $t['name'] );
				if ( strlen( self::OLD_PREFIX . $name ) > 64 ) {
					throw new WstmException( 'name_too_long', 'A table name is too long to import safely.', array( 'why' => $name . ' (max 58 characters)' ) );
				}
				$s['expected'][ $this->map_table( $s, $name ) ] = (int) $t['rows'];
			}
		} else {
			$s['warnings'][] = 'No manifest: file checksum and row counts cannot be verified.';
		}

		if ( ! is_dir( $s['work_dir'] ) && ! wp_mkdir_p( $s['work_dir'] ) ) {
			throw new WstmException( 'storage_unwritable', 'Could not create the import work directory.', array( 'resumable' => true ) );
		}
		$s['sql'] = $s['gzip'] ? $s['work_dir'] . '/import.sql' : $s['source'];

		// Remove leftovers of an earlier, abandoned import so verification is exact.
		foreach ( $this->db->list_tables( self::TMP_PREFIX ) as $leftover ) {
			$this->db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( $leftover ) );
		}

		$s['stage'] = $s['manifest'] ? 'verify' : ( $s['safety_file'] ? 'safety' : ( $s['gzip'] ? 'decompress' : 'import' ) );
		$this->logger->info( 'Import precheck passed', array( 'file' => basename( $s['source'] ), 'tables' => count( $s['expected'] ) ), 'database', $this->job_id ?: null );
		return $s;
	}

	/**
	 * Session settings applied at the start of each import slice.
	 */
	private function prepare_session(): void {
		foreach ( array( 'SET SESSION FOREIGN_KEY_CHECKS=0', 'SET SESSION UNIQUE_CHECKS=0', "SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO'", "SET SESSION time_zone='+00:00'" ) as $q ) {
			try {
				$this->db->raw_query( $q );
			} catch ( WstmException $e ) {
				$this->logger->debug( 'Session setting not supported: ' . $q, array(), 'database', $this->job_id ?: null );
			}
		}
	}

	/**
	 * Execute statements.
	 *
	 * @param array    $s        State.
	 * @param int      $deadline Deadline.
	 * @param callable $commit   Checkpoint commit.
	 * @throws WstmException On statement failure.
	 */
	private function import( array $s, int $deadline, callable $commit ): array {
		clearstatcache( true, $s['sql'] );
		$s['sql_size'] = (int) filesize( $s['sql'] );
		if ( 0 === $s['offset'] && $s['manifest'] ) {
			$this->assert_complete( $s['sql'] );
		}
		$this->prepare_session();

		$reader = new SqlStatementReader( $s['sql'], (int) $s['offset'] );
		$base   = $this->db->base_prefix();

		$first = true;
		while ( $first || time() < $deadline ) {
			$first = false;
			$stmt  = $reader->next();
			if ( null === $stmt ) {
				if ( ! $s['tables'] ) {
					throw new WstmException( 'nothing_imported', 'The dump contains no importable tables.', array( 'what' => 'Database import', 'why' => 'No CREATE TABLE statements for tables with prefix "' . $base . '".', 'action' => 'Check the dump. Nothing on this site was changed.' ) );
				}
				$s['stage'] = 'verify_rows';
				$s['vi']    = 0;
				return $s;
			}

			$r     = self::rewrite( $stmt['sql'], self::TMP_PREFIX, fn( string $t ) => $this->map_table( $s, $t ) );
			if ( 'create' === $r['type'] && null !== $r['sql'] ) {
				$r['sql'] = $this->fix_collations( $r['sql'], $s );
			}
			$table = $r['table'];
			$next  = $s;
			$next['offset'] = $stmt['end'];

			$run = null;
			switch ( $r['type'] ) {
				case 'empty':
				case 'set':
				case 'lock':
					break;
				case 'unsupported':
					$next = $this->warn( $next, 'Skipped unsupported statement: ' . mb_substr( preg_replace( '/\s+/', ' ', SqlStatementReader::strip_leading( $stmt['sql'] ) ), 0, 80 ) );
					break;
				default:
					$this->skip_tables = (array) ( $s['skip_tables'] ?? array() );
					$reason = $this->table_skip_reason( $table, $base );
					if ( null !== $reason ) {
						if ( ! isset( $next['skipped'][ $table ] ) ) {
							$next['skipped'][ $table ] = true;
							$next                      = $this->warn( $next, sprintf( 'Table %s skipped: %s', $table, $reason ) );
						}
						break;
					}
					if ( 'create' === $r['type'] ) {
						// Idempotent re-run after an interrupted request.
						$this->db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( self::TMP_PREFIX . $table ) );
						$next['tables'][ $table ] = array( 'statements' => 0 );
						$next['current']          = $table;
					} elseif ( ! isset( $next['tables'][ $table ] ) && 'drop' !== $r['type'] ) {
						throw new WstmException( 'insert_before_create', 'The dump inserts into a table it never created.', array( 'what' => 'Database import', 'why' => 'Table ' . $table . ' has no CREATE TABLE statement before its data.', 'action' => 'Use a dump that includes table structure.' ) );
					}
					if ( isset( $next['tables'][ $table ] ) ) {
						++$next['tables'][ $table ]['statements'];
					}
					$run = $r['sql'];
			}
			++$next['statements'];

			if ( null === $run ) {
				$s = $next;
				continue;
			}

			try {
				$this->db->raw_query( 'START TRANSACTION' );
				$this->db->raw_query( $run );
				$commit( $next );
				$this->db->raw_query( 'COMMIT' );
			} catch ( WstmException $e ) {
				try {
					$this->db->raw_query( 'ROLLBACK' );
				} catch ( \Throwable $ignored ) {
					unset( $ignored );
				}
				throw $this->statement_error( $e, $s, $table, $stmt['sql'] );
			}
			$s = $next;
		}
		return $s;
	}

	/**
	 * Reason a table must not be imported, or null.
	 *
	 * @param string $table Table.
	 * @param string $base  Base prefix.
	 */
	private function table_skip_reason( string $table, string $base ): ?string {
		if ( ! str_starts_with( $table, $base ) ) {
			return 'does not use this site\'s table prefix';
		}
		if ( in_array( $table, $this->skip_tables, true ) ) {
			return 'kept from this site (option)';
		}
		if ( str_starts_with( $table, $base . 'wstm_' ) ) {
			return 'internal migration-engine table (never overwritten)';
		}
		if ( strlen( self::OLD_PREFIX . $table ) > 64 ) {
			return 'name too long to swap safely';
		}
		return null;
	}

	/**
	 * Make sure our own dumps end with the completeness marker.
	 *
	 * @param string $sql SQL path.
	 * @throws WstmException If incomplete.
	 */
	private function assert_complete( string $sql ): void {
		$fh   = fopen( $sql, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$size = (int) filesize( $sql );
		fseek( $fh, max( 0, $size - 256 ) );
		$tail = (string) fread( $fh, 256 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! str_contains( $tail, '-- WSTM:END' ) ) {
			throw new WstmException( 'dump_incomplete', 'The dump is incomplete.', array( 'what' => 'Import precheck', 'why' => 'End-of-dump marker missing.', 'action' => 'Re-create the export. Nothing was changed.' ) );
		}
	}

	/**
	 * Build a structured statement error.
	 *
	 * @param WstmException $e     DB error.
	 * @param array         $s     State before the statement.
	 * @param string|null   $table Table.
	 * @param string        $sql   Statement.
	 */
	private function statement_error( WstmException $e, array $s, ?string $table, string $sql ): WstmException {
		$why    = (string) ( $e->get_context()['why'] ?? $e->getMessage() );
		$errno  = (int) ( $e->get_context()['errno'] ?? 0 );
		$action = 'Review the error, then resume. The live database has not been modified.';
		if ( 2006 === $errno || 1153 === $errno || false !== stripos( $why, 'max_allowed_packet' ) || false !== stripos( $why, 'gone away' ) ) {
			$action = 'Statement exceeds max_allowed_packet (' . size_format( strlen( $sql ) ) . '). Ask your host to raise max_allowed_packet, or re-export with a smaller statement size, then resume.';
		} elseif ( false !== stripos( $why, 'Unknown collation' ) || false !== stripos( $why, 'Unknown character set' ) ) {
			$action = 'The source uses a collation this server lacks (e.g. MySQL 8 utf8mb4_0900_ai_ci on MariaDB). Collation conversion is planned for Phase 6.';
		}
		return new WstmException(
			'db_import_failed',
			'Database import failed.',
			array(
				'what'      => 'Database import' . ( $table ? ', table ' . $table : '' ),
				'why'       => $why,
				'completed' => sprintf( '%s of %s, %d statements, %d tables', size_format( (int) $s['offset'] ), size_format( (int) $s['sql_size'] ), (int) $s['statements'], count( $s['tables'] ) ),
				'resumable' => true,
				'action'    => $action,
				'data'      => array(
					'table'     => $table,
					'offset'    => (int) $s['offset'],
					'statement' => mb_substr( SqlStatementReader::strip_leading( $sql ), 0, 160 ),
				),
			),
			$e
		);
	}

	/**
	 * Rewrite a statement to target the temporary table.
	 *
	 * @param string $sql        Raw statement.
	 * @param string $tmp_prefix Temporary prefix.
	 * @return array{type:string,sql:?string,table:?string}
	 */
	public static function rewrite( string $sql, string $tmp_prefix, ?callable $map = null ): array {
		$body = rtrim( SqlStatementReader::strip_leading( $sql ), "; \t\r\n" );
		if ( '' === $body ) {
			return array( 'type' => 'empty', 'sql' => null, 'table' => null );
		}
		if ( preg_match( '/^SET\s/i', $body ) ) {
			return array( 'type' => 'set', 'sql' => null, 'table' => null );
		}
		if ( preg_match( '/^(?:UNLOCK\s+TABLES|LOCK\s+TABLES\s|ALTER\s+TABLE\s+\S+\s+(?:DISABLE|ENABLE)\s+KEYS)/i', $body ) ) {
			return array( 'type' => 'lock', 'sql' => null, 'table' => null );
		}
		$name = '(?:`((?:[^`]|``)+)`|([A-Za-z0-9_$]+))';
		$patterns = array(
			'drop'   => '/^DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?' . $name . '$/i',
			'create' => '/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?' . $name . '/i',
			'insert' => '/^(?:INSERT|REPLACE)\s+(?:(?:LOW_PRIORITY|DELAYED|HIGH_PRIORITY|IGNORE)\s+)*INTO\s+' . $name . '/i',
		);
		foreach ( $patterns as $type => $re ) {
			if ( ! preg_match( $re, $body, $m, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}
			$quoted = isset( $m[1] ) && -1 !== $m[1][1] && '' !== $m[1][0];
			$table  = $quoted ? str_replace( '``', '`', $m[1][0] ) : $m[2][0];
			if ( $map ) {
				$table = $map( $table );
			}
			$start  = $quoted ? $m[1][1] - 1 : $m[2][1];
			$len    = $quoted ? strlen( $m[1][0] ) + 2 : strlen( $m[2][0] );
			if ( 'drop' === $type ) {
				return array( 'type' => 'drop', 'sql' => 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( $tmp_prefix . $table ), 'table' => $table );
			}
			$rewritten = substr_replace( $body, SqlEscaper::identifier( $tmp_prefix . $table ), $start, $len );
			return array( 'type' => $type, 'sql' => $rewritten, 'table' => $table );
		}
		return array( 'type' => 'unsupported', 'sql' => null, 'table' => null );
	}

	/**
	 * Verify row counts of the temporary tables.
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 * @throws WstmException On mismatch.
	 */
	private function verify_rows( array $s, int $deadline ): array {
		$names = array_keys( $s['tables'] );
		while ( $s['vi'] < count( $names ) ) {
			$t                 = $names[ $s['vi'] ];
			$s['counts'][ $t ] = $this->scanner->exact_count( self::TMP_PREFIX . $t );
			++$s['vi'];
			if ( time() >= $deadline ) {
				break;
			}
		}
		if ( $s['vi'] < count( $names ) ) {
			return $s;
		}
		if ( $s['expected'] ) {
			$problems = array();
			foreach ( $s['expected'] as $t => $rows ) {
				if ( isset( $s['skipped'][ $t ] ) ) {
					continue;
				}
				if ( ! isset( $s['counts'][ $t ] ) ) {
					$problems[] = $t . ': missing';
				} elseif ( $s['counts'][ $t ] !== $rows ) {
					$problems[] = sprintf( '%s: expected %d rows, imported %d', $t, $rows, $s['counts'][ $t ] );
				}
			}
			if ( $problems ) {
				throw new WstmException(
					'row_count_mismatch',
					'Imported data does not match the dump.',
					array(
						'what'   => 'Row-count verification',
						'why'    => implode( '; ', array_slice( $problems, 0, 10 ) ),
						'action' => 'Cancel and run the import again. The live database has not been modified.',
					)
				);
			}
		}
		$s['stage'] = $s['prefix_from'] ? 'prefix_fix' : ( $s['defer_swap'] ? 'ready' : 'swap' );
		return $s;
	}

	/**
	 * Map a source table name to this site's prefix.
	 *
	 * @param array  $s     State.
	 * @param string $table Source table name.
	 */
	private function map_table( array $s, string $table ): string {
		$from = $s['prefix_from'] ?? null;
		if ( $from && str_starts_with( $table, $from ) ) {
			return $this->db->base_prefix() . substr( $table, strlen( $from ) );
		}
		return $table;
	}

	/**
	 * Replace collations this server does not support (e.g. MySQL 8 utf8mb4_0900_* on MariaDB).
	 *
	 * @param string $sql CREATE TABLE statement.
	 * @param array  $s   State (collation cache, by reference).
	 */
	private function fix_collations( string $sql, array &$s ): string {
		if ( ! preg_match_all( '/\butf8mb4_0900_[a-z_]+|\butf8mb4_[a-z0-9]+_(?:0900|as)_[a-z_]+/i', $sql, $m ) ) {
			return $sql;
		}
		foreach ( array_unique( $m[0] ) as $coll ) {
			if ( ! isset( $s['collations'][ $coll ] ) ) {
				$have = (bool) $this->db->get_var( 'SHOW COLLATION LIKE %s', array( $coll ) );
				$alt  = $this->db->get_var( 'SHOW COLLATION LIKE %s', array( 'utf8mb4_unicode_520_ci' ) ) ? 'utf8mb4_unicode_520_ci' : 'utf8mb4_unicode_ci';
				$s['collations'][ $coll ] = $have ? $coll : $alt;
				if ( ! $have ) {
					$s = $this->warn( $s, sprintf( 'Collation %s is not supported here; converted to %s.', $coll, $alt ) );
				}
			}
			$sql = str_replace( $coll, $s['collations'][ $coll ], $sql );
		}
		return $sql;
	}

	/**
	 * Fix prefix-dependent rows in the temporary tables (user roles, user capabilities).
	 *
	 * @param array $s State.
	 */
	private function prefix_fix( array $s ): array {
		$from = (string) $s['prefix_from'];
		$to   = $this->db->base_prefix();
		$wpdb = $this->db->wpdb();
		$opt  = self::TMP_PREFIX . $to . 'options';
		$um   = self::TMP_PREFIX . $to . 'usermeta';
		if ( isset( $s['tables'][ $to . 'options' ] ) ) {
			$this->db->query( 'UPDATE ' . SqlEscaper::identifier( $opt ) . ' SET option_name = %s WHERE option_name = %s', array( $to . 'user_roles', $from . 'user_roles' ) );
		}
		if ( isset( $s['tables'][ $to . 'usermeta' ] ) ) {
			$this->db->query(
				'UPDATE ' . SqlEscaper::identifier( $um ) . ' SET meta_key = CONCAT(%s, SUBSTRING(meta_key, %d)) WHERE meta_key LIKE %s',
				array( $to, strlen( $from ) + 1, $wpdb->esc_like( $from ) . '%' )
			);
		}
		$s['stage'] = $s['defer_swap'] ? 'ready' : 'swap';
		return $s;
	}

	/**
	 * Atomically swap temporary tables into place.
	 *
	 * @param array $s State.
	 * @throws WstmException If the rename fails (nothing is changed in that case).
	 */
	private function swap( array $s ): array {
		$preserved = array();
		foreach ( self::PRESERVED_OPTIONS as $opt ) {
			$preserved[ $opt ] = get_site_option( $opt, null );
		}

		$existing = array_flip( $this->db->list_tables() );
		$pairs    = array();
		$previous = array();
		foreach ( array_keys( $s['tables'] ) as $t ) {
			if ( ! isset( $existing[ self::TMP_PREFIX . $t ] ) ) {
				throw new WstmException( 'tmp_missing', 'A temporary import table disappeared.', array( 'why' => self::TMP_PREFIX . $t, 'action' => 'Cancel and run the import again. Nothing was changed.' ) );
			}
			if ( isset( $existing[ $t ] ) ) {
				$this->db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( self::OLD_PREFIX . $t ) );
				$pairs[]    = SqlEscaper::identifier( $t ) . ' TO ' . SqlEscaper::identifier( self::OLD_PREFIX . $t );
				$previous[] = $t;
			}
			$pairs[] = SqlEscaper::identifier( self::TMP_PREFIX . $t ) . ' TO ' . SqlEscaper::identifier( $t );
		}

		try {
			$this->db->raw_query( 'RENAME TABLE ' . implode( ', ', $pairs ) );
		} catch ( WstmException $e ) {
			throw new WstmException(
				'swap_failed',
				'Switching to the imported tables failed.',
				array(
					'what'      => 'Table swap',
					'why'       => (string) ( $e->get_context()['why'] ?? $e->getMessage() ),
					'completed' => 'All data imported and verified in temporary tables.',
					'resumable' => true,
					'action'    => 'Resume to retry the swap. The live database is unchanged (RENAME TABLE is atomic).',
				),
				$e
			);
		}

		$s['previous'] = $previous;
		$this->logger->info( sprintf( 'Imported %d tables; %d previous tables kept as rollback copies', count( $pairs ) - count( $previous ), count( $previous ) ), array(), 'database', $this->job_id ?: null );

		// Restore this installation's own plugin state and keep the plugin active.
		wp_cache_flush();
		foreach ( $preserved as $opt => $val ) {
			if ( null === $val ) {
				delete_site_option( $opt );
			} else {
				update_site_option( $opt, $val );
			}
		}
		if ( defined( 'WSTM_BASENAME' ) ) {
			if ( is_multisite() ) {
				$net = (array) get_site_option( 'active_sitewide_plugins', array() );
				if ( ! isset( $net[ WSTM_BASENAME ] ) ) {
					$net[ WSTM_BASENAME ] = time();
					update_site_option( 'active_sitewide_plugins', $net );
				}
			} else {
				$active = (array) get_option( 'active_plugins', array() );
				if ( ! in_array( WSTM_BASENAME, $active, true ) ) {
					$active[] = WSTM_BASENAME;
					update_option( 'active_plugins', array_values( $active ) );
				}
			}
		}
		wp_cache_flush();

		$s['stage'] = 'cleanup';
		return $s;
	}

	/**
	 * Drop temporary tables (cancel/cleanup).
	 */
	public function drop_temp_tables(): int {
		$n = 0;
		foreach ( $this->db->list_tables( self::TMP_PREFIX ) as $t ) {
			$this->db->raw_query( 'DROP TABLE IF EXISTS ' . SqlEscaper::identifier( $t ) );
			++$n;
		}
		return $n;
	}

	/**
	 * Add a warning (bounded).
	 *
	 * @param array  $s   State.
	 * @param string $msg Message.
	 */
	private function warn( array $s, string $msg ): array {
		if ( count( $s['warnings'] ) < self::MAX_WARNINGS ) {
			$s['warnings'][] = $msg;
		}
		$this->logger->warning( $msg, array(), 'database', $this->job_id ?: null );
		return $s;
	}

	/**
	 * Progress 0–100.
	 *
	 * @param array $s State.
	 */
	public static function progress( array $s ): float {
		$weights = array(
			'precheck'    => array( 0, 1 ),
			'verify'      => array( 1, 5 ),
			'safety'      => array( 6, 24 ),
			'decompress'  => array( 30, 10 ),
			'import'      => array( 40, 50 ),
			'verify_rows' => array( 90, 5 ),
			'prefix_fix'  => array( 95, 0 ),
			'ready'       => array( 95, 0 ),
			'swap'        => array( 95, 4 ),
			'cleanup'     => array( 99, 1 ),
			'done'        => array( 100, 0 ),
		);
		[ $start, $span ] = $weights[ $s['stage'] ] ?? array( 0, 0 );
		$frac = 0.0;
		switch ( $s['stage'] ) {
			case 'verify':
				$frac = ( (int) ( $s['hash']['offset'] ?? 0 ) ) / max( 1, (int) @filesize( $s['source'] ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				break;
			case 'safety':
				$frac = $s['safety'] ? DbExporter::progress( $s['safety'] ) / 100 : 0;
				break;
			case 'decompress':
				$frac = $s['gz']['in'] / max( 1, (int) @filesize( $s['source'] ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				break;
			case 'import':
				$frac = $s['offset'] / max( 1, (int) $s['sql_size'] );
				break;
			case 'verify_rows':
				$frac = $s['vi'] / max( 1, count( $s['tables'] ) );
				break;
		}
		return round( $start + $span * min( 1, $frac ), 2 );
	}
}
