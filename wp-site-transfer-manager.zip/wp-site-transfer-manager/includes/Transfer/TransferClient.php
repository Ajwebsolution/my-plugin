<?php
/**
 * Client side of direct transfers: signed requests to the other site.
 *
 * @package WSTM\Transfer
 */

namespace WSTM\Transfer;

use WSTM\Core\WstmException;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Transfer client.
 */
class TransferClient {

	/**
	 * @var array
	 */
	private array $key;

	/**
	 * Constructor.
	 *
	 * @param array $key Parsed key (TransferKeys::parse()).
	 */
	public function __construct( array $key ) {
		$this->key = $key;
	}

	/** Remote site host (for display). */
	public function host(): string {
		return (string) ( $this->key['n'] ?? wp_parse_url( (string) $this->key['u'], PHP_URL_HOST ) );
	}

	/**
	 * Build the URL for a transfer path.
	 *
	 * @param string $path  Path under /transfer/.
	 * @param array  $query Query params.
	 */
	private function url( string $path, array $query ): string {
		$base = (string) $this->key['u'];
		$url  = $base . $path;
		if ( $query ) {
			$url .= ( str_contains( $base, '?' ) ? '&' : '?' ) . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );
		}
		return $url;
	}

	/**
	 * Signed request.
	 *
	 * @param string $method  GET|POST.
	 * @param string $path    Path under /transfer/ (e.g. "handshake").
	 * @param array  $body    JSON body (POST).
	 * @param array  $query   Query params.
	 * @param int    $timeout Seconds.
	 * @throws WstmException On network or remote errors.
	 */
	public function request( string $method, string $path, array $body = array(), array $query = array(), int $timeout = 60 ): array {
		$raw   = 'POST' === $method ? (string) wp_json_encode( (object) $body ) : '';
		$time  = (string) time();
		$nonce = Security::random_token( 16 );
		$route = '/' . TransferServer::NS_ROOT . $path;
		$sig   = TransferKeys::sign( (string) $this->key['s'], TransferKeys::canonical( $method, $route, $query, $time, $nonce, $raw ) );
		$res   = wp_remote_request(
			$this->url( $path, $query ),
			array(
				'method'    => $method,
				'timeout'   => $timeout,
				'sslverify' => (bool) apply_filters( 'wstm_transfer_sslverify', true ),
				'headers'   => array(
					'Content-Type' => 'application/json',
					'X-WSTM-Id'    => (string) $this->key['i'],
					'X-WSTM-Time'  => $time,
					'X-WSTM-Nonce' => $nonce,
					'X-WSTM-Sig'   => $sig,
				),
				'body'      => 'POST' === $method ? $raw : null,
			)
		);
		if ( is_wp_error( $res ) ) {
			throw new WstmException(
				'network',
				'Could not reach the other site.',
				array(
					'what'      => 'Connection to ' . $this->host(),
					'why'       => $res->get_error_message(),
					'resumable' => true,
					'action'    => 'Check that the other site is online and reachable from this server, then resume.',
				)
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			$msg = is_array( $data ) ? (string) ( $data['message'] ?? '' ) : '';
			throw new WstmException(
				'remote_error',
				'The other site rejected the request.',
				array(
					'what'      => $this->host() . ' (' . $path . ')',
					'why'       => $msg ?: 'HTTP ' . $code . ( is_array( $data ) ? '' : ' — the response was not from WP Site Transfer Manager (security plugin or firewall?)' ),
					'resumable' => $code >= 500 || 429 === $code || 0 === $code,
					'action'    => 403 === $code ? 'The key may have expired or been revoked — generate a new one.' : 'Check the other site\'s Logs page.',
					'data'      => is_array( $data ) ? ( $data['data'] ?? null ) : null,
				)
			);
		}
		return $data;
	}
}
