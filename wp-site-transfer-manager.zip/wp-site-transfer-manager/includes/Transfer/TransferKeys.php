<?php
/**
 * Transfer keys: issue, parse, verify, revoke.
 *
 * A key is "wstm1." + base64url(JSON {u: REST root of the issuing site,
 * i: transfer id, s: 256-bit secret, m: mode, e: expiry}). The issuing site
 * stores only an encrypted copy of the secret (and its hash); every request
 * is authenticated with HMAC-SHA256 over method, route, query, timestamp,
 * nonce and body hash. Keys expire automatically and can be revoked.
 *
 * Modes:
 *   pull — the issuing site lets the key holder download a package of it.
 *   push — the issuing site lets the key holder upload a package AND restore it here.
 *
 * @package WSTM\Transfer
 */

namespace WSTM\Transfer;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Security\Crypto;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Transfer keys.
 */
class TransferKeys {

	public const PREFIX     = 'wstm1.';
	public const MODES      = array( 'pull', 'push' );
	public const CLOCK_SKEW = 300;

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Issue a key.
	 *
	 * @param string $mode    pull|push.
	 * @param int    $minutes Lifetime (15, 30 or 60).
	 * @return array{key:string,transfer_id:string,expires_at:string}
	 * @throws WstmException On invalid input.
	 */
	public function issue( string $mode, int $minutes ): array {
		if ( ! in_array( $mode, self::MODES, true ) ) {
			throw new WstmException( 'bad_mode', 'Invalid transfer mode.' );
		}
		$minutes = in_array( $minutes, array( 15, 30, 60 ), true ) ? $minutes : 30;
		$id      = Security::random_token( 16 );
		$secret  = Security::random_token( 32 );
		$expires = time() + $minutes * MINUTE_IN_SECONDS;
		$this->plugin->db()->insert(
			'transfers',
			array(
				'transfer_id' => $id,
				'direction'   => $mode,
				'secret_hash' => hash( 'sha256', $secret ),
				'secret_enc'  => Crypto::encrypt( $secret ),
				'meta'        => wp_json_encode( array( 'created_by' => get_current_user_id() ) ),
				'status'      => 'active',
				'expires_at'  => gmdate( 'Y-m-d H:i:s', $expires ),
				'created_at'  => gmdate( 'Y-m-d H:i:s' ),
			)
		);
		$this->plugin->logger()->info( sprintf( 'Transfer key issued (%s, %d min)', $mode, $minutes ), array( 'transfer' => substr( $id, 0, 8 ) ), 'transfer' );
		$payload = array(
			'u' => rest_url( TransferServer::NS_ROOT ),
			'i' => $id,
			's' => $secret,
			'm' => $mode,
			'e' => $expires,
			'n' => wp_parse_url( home_url(), PHP_URL_HOST ),
		);
		return array(
			'key'         => self::PREFIX . rtrim( strtr( base64_encode( wp_json_encode( $payload, JSON_UNESCAPED_SLASHES ) ), '+/', '-_' ), '=' ),
			'transfer_id' => $id,
			'expires_at'  => gmdate( 'c', $expires ),
		);
	}

	/**
	 * Parse a key string.
	 *
	 * @param string $key Key.
	 * @throws WstmException If malformed or expired.
	 */
	public static function parse( string $key ): array {
		$key = trim( preg_replace( '/\s+/', '', $key ) );
		if ( ! str_starts_with( $key, self::PREFIX ) ) {
			throw new WstmException( 'bad_key', 'This is not a WP Site Transfer key.', array( 'action' => 'Copy the whole key from the other site, including "wstm1.".' ) );
		}
		$json = base64_decode( strtr( substr( $key, strlen( self::PREFIX ) ), '-_', '+/' ), true );
		$d    = $json ? json_decode( $json, true ) : null;
		if ( ! is_array( $d ) || empty( $d['u'] ) || ! preg_match( '/^[a-f0-9]{32}$/', (string) ( $d['i'] ?? '' ) ) || ! preg_match( '/^[a-f0-9]{64}$/', (string) ( $d['s'] ?? '' ) ) || ! in_array( $d['m'] ?? '', self::MODES, true ) ) {
			throw new WstmException( 'bad_key', 'The transfer key is damaged.', array( 'action' => 'Copy the key again from the other site.' ) );
		}
		if ( ! wp_http_validate_url( (string) $d['u'] ) && ! preg_match( '#^https?://#', (string) $d['u'] ) ) {
			throw new WstmException( 'bad_key', 'The transfer key contains an invalid address.' );
		}
		if ( (int) $d['e'] < time() ) {
			throw new WstmException( 'key_expired', 'This transfer key has expired.', array( 'action' => 'Generate a new key on the other site.' ) );
		}
		return $d;
	}

	/**
	 * Load an active transfer row with its decrypted secret.
	 *
	 * @param string $id Transfer id.
	 */
	public function active( string $id ): ?array {
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $id ) ) {
			return null;
		}
		$row = $this->plugin->db()->get_row( 'SELECT * FROM ' . $this->plugin->db()->table( 'transfers' ) . ' WHERE transfer_id = %s', array( $id ) );
		if ( ! $row || 'active' !== $row['status'] || strtotime( $row['expires_at'] . ' UTC' ) < time() || ! empty( $row['revoked_at'] ) ) {
			return null;
		}
		$secret = Crypto::decrypt( (string) $row['secret_enc'] );
		if ( null === $secret || ! hash_equals( (string) $row['secret_hash'], hash( 'sha256', $secret ) ) ) {
			return null;
		}
		$row['secret'] = $secret;
		$row['meta']   = json_decode( (string) $row['meta'], true ) ?: array();
		return $row;
	}

	/**
	 * Update stored metadata for a transfer.
	 *
	 * @param string $id   Transfer id.
	 * @param array  $meta Merged metadata.
	 */
	public function set_meta( string $id, array $meta ): void {
		$this->plugin->db()->update( 'transfers', array( 'meta' => wp_json_encode( $meta ) ), array( 'transfer_id' => $id ) );
	}

	/**
	 * Revoke.
	 *
	 * @param string $id Transfer id.
	 */
	public function revoke( string $id ): void {
		$this->plugin->db()->update( 'transfers', array( 'status' => 'revoked', 'revoked_at' => gmdate( 'Y-m-d H:i:s' ), 'secret_enc' => null ), array( 'transfer_id' => $id ) );
		$this->plugin->logger()->info( 'Transfer key revoked', array( 'transfer' => substr( $id, 0, 8 ) ), 'transfer' );
	}

	/**
	 * Mark finished (key can no longer be used).
	 *
	 * @param string $id Transfer id.
	 */
	public function finish( string $id ): void {
		$this->plugin->db()->update( 'transfers', array( 'status' => 'used', 'used_at' => gmdate( 'Y-m-d H:i:s' ), 'secret_enc' => null ), array( 'transfer_id' => $id ) );
	}

	/** Keys for the admin list (never includes secrets). */
	public function list(): array {
		$rows = $this->plugin->db()->get_results( 'SELECT transfer_id, direction, status, expires_at, used_at, revoked_at, created_at FROM ' . $this->plugin->db()->table( 'transfers' ) . ' ORDER BY id DESC LIMIT 50' );
		foreach ( $rows as &$r ) {
			if ( 'active' === $r['status'] && strtotime( $r['expires_at'] . ' UTC' ) < time() ) {
				$r['status'] = 'expired';
			}
			$r['short'] = substr( $r['transfer_id'], 0, 8 );
		}
		return $rows;
	}

	/**
	 * Canonical string that is signed.
	 *
	 * @param string $method HTTP method.
	 * @param string $route  REST route (e.g. /wstm/v1/transfer/handshake).
	 * @param array  $query  Query params (excluding rest_route).
	 * @param string $time   Unix timestamp.
	 * @param string $nonce  Nonce.
	 * @param string $body   Raw body.
	 */
	public static function canonical( string $method, string $route, array $query, string $time, string $nonce, string $body ): string {
		unset( $query['rest_route'] );
		ksort( $query );
		return strtoupper( $method ) . "\n" . $route . "\n" . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 ) . "\n" . $time . "\n" . $nonce . "\n" . hash( 'sha256', $body );
	}

	/**
	 * Sign.
	 *
	 * @param string $secret    Secret.
	 * @param string $canonical Canonical string.
	 */
	public static function sign( string $secret, string $canonical ): string {
		return hash_hmac( 'sha256', $canonical, $secret );
	}
}
