<?php
/**
 * Server side of direct transfers (wstm/v1/transfer/*).
 *
 * Every endpoint is authenticated by an HMAC-SHA256 signature made with the
 * transfer key's secret (never by cookies). Requests must carry a fresh
 * timestamp (±5 min) and a single-use nonce; failures are rate-limited.
 *
 * @package WSTM\Transfer
 */

namespace WSTM\Transfer;

use WSTM\Core\Plugin;
use WSTM\Core\WstmException;
use WSTM\Files\UploadManager;
use WSTM\Jobs\Handlers\PackageExportHandler;
use WSTM\Jobs\Handlers\PackageImportHandler;
use WSTM\Jobs\Handlers\SiteRestoreHandler;
use WSTM\Jobs\JobStatus;
use WSTM\Rest\MigrationController;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Transfer server.
 */
class TransferServer {

	public const NS_ROOT    = 'wstm/v1/transfer/';
	public const MAX_CHUNK  = 8388608;

	/** Transfer row of the current authenticated request. */
	private ?array $transfer = null;

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Largest raw chunk this server can accept in one JSON request (base64 adds ~37%).
	 */
	public static function safe_chunk(): int {
		$limits = array_filter( array( wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ), wp_convert_hr_to_bytes( (string) ini_get( 'upload_max_filesize' ) ) ), static fn( $v ) => $v > 0 );
		$post   = $limits ? min( $limits ) : self::MAX_CHUNK;
		return (int) max( 262144, min( self::MAX_CHUNK, (int) ( ( $post - 262144 ) * 0.7 ) ) );
	}

	/** Register routes. */
	public function register_routes(): void {
		$routes = array(
			'handshake'      => array( 'POST', array( 'pull', 'push' ), 'handshake' ),
			'export/start'   => array( 'POST', array( 'pull' ), 'export_start' ),
			'export/run'     => array( 'POST', array( 'pull' ), 'export_run' ),
			'package'        => array( 'GET', array( 'pull' ), 'package_chunk' ),
			'upload/start'   => array( 'POST', array( 'push' ), 'upload_start' ),
			'upload/chunk'   => array( 'POST', array( 'push' ), 'upload_chunk' ),
			'upload/finish'  => array( 'POST', array( 'push' ), 'upload_finish' ),
			'restore/start'  => array( 'POST', array( 'push' ), 'restore_start' ),
			'restore/run'    => array( 'POST', array( 'push' ), 'restore_run' ),
			'finish'         => array( 'POST', array( 'pull', 'push' ), 'finish' ),
		);
		foreach ( $routes as $path => [ $method, $modes, $cb ] ) {
			register_rest_route(
				'wstm/v1',
				'/transfer/' . $path,
				array(
					'methods'             => $method,
					'permission_callback' => fn( \WP_REST_Request $r ) => $this->authenticate( $r, $modes ),
					'callback'            => fn( \WP_REST_Request $r ) => $this->wrap( fn() => $this->{$cb}( $r ) ),
				)
			);
		}
	}

	/**
	 * Verify signature, freshness, nonce and key state.
	 *
	 * @param \WP_REST_Request $r     Request.
	 * @param string[]         $modes Allowed key modes.
	 */
	public function authenticate( \WP_REST_Request $r, array $modes ) {
		// WordPress calls permission callbacks more than once per request (e.g. rest_send_allow_header);
		// the nonce is single-use, so reuse the verdict for the same request object.
		$rid = spl_object_id( $r );
		if ( isset( $this->verdicts[ $rid ] ) ) {
			return $this->verdicts[ $rid ];
		}
		return $this->verdicts[ $rid ] = $this->verify( $r, $modes );
	}

	/** Per-request authentication results. @var array<int,bool|\WP_Error> */
	private array $verdicts = array();

	/**
	 * Verify a signed request.
	 *
	 * @param \WP_REST_Request $r     Request.
	 * @param string[]         $modes Allowed key modes.
	 */
	private function verify( \WP_REST_Request $r, array $modes ) {
		$fp = Security::client_fingerprint();
		if ( (int) get_site_transient( 'wstm_tf_' . md5( $fp ) ) >= 30 ) {
			return new \WP_Error( 'wstm_rate_limited', 'Too many failed transfer attempts. Try again later.', array( 'status' => 429 ) );
		}
		$deny = function ( string $why ) use ( $fp ) {
			$k = 'wstm_tf_' . md5( $fp );
			set_site_transient( $k, (int) get_site_transient( $k ) + 1, 10 * MINUTE_IN_SECONDS );
			$this->plugin->logger()->warning( 'Rejected transfer request: ' . $why, array(), 'transfer' );
			return new \WP_Error( 'wstm_transfer_denied', 'Transfer request rejected: ' . $why, array( 'status' => 403 ) );
		};
		$id    = (string) $r->get_header( 'x_wstm_id' );
		$time  = (string) $r->get_header( 'x_wstm_time' );
		$nonce = (string) $r->get_header( 'x_wstm_nonce' );
		$sig   = (string) $r->get_header( 'x_wstm_sig' );
		if ( ! $id || ! ctype_digit( $time ) || ! preg_match( '/^[a-f0-9]{32}$/', $nonce ) || ! preg_match( '/^[a-f0-9]{64}$/', $sig ) ) {
			return $deny( 'missing or malformed authentication headers' );
		}
		if ( abs( time() - (int) $time ) > TransferKeys::CLOCK_SKEW ) {
			return $deny( 'timestamp outside the allowed window (check server clocks)' );
		}
		$t = ( new TransferKeys( $this->plugin ) )->active( $id );
		if ( ! $t ) {
			return $deny( 'unknown, expired or revoked transfer key' );
		}
		if ( ! in_array( $t['direction'], $modes, true ) ) {
			return $deny( 'this key does not allow this operation' );
		}
		$expected = TransferKeys::sign( $t['secret'], TransferKeys::canonical( $r->get_method(), $r->get_route(), $r->get_query_params(), $time, $nonce, (string) $r->get_body() ) );
		if ( ! hash_equals( $expected, $sig ) ) {
			return $deny( 'invalid signature' );
		}
		$nk = 'wstm_tn_' . md5( $id . $nonce );
		if ( get_site_transient( $nk ) ) {
			return $deny( 'replayed request' );
		}
		set_site_transient( $nk, 1, 2 * TransferKeys::CLOCK_SKEW );
		$this->transfer = $t;
		return true;
	}

	/**
	 * Request JSON body.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function body( \WP_REST_Request $r ): array {
		$b = json_decode( (string) $r->get_body(), true );
		return is_array( $b ) ? $b : array();
	}

	/** Save transfer metadata. */
	private function meta( array $changes ): array {
		$this->transfer['meta'] = array_merge( $this->transfer['meta'], $changes );
		( new TransferKeys( $this->plugin ) )->set_meta( $this->transfer['transfer_id'], $this->transfer['meta'] );
		return $this->transfer['meta'];
	}

	/** Site info. */
	private function handshake(): array {
		global $wp_version;
		return array(
			'site'           => get_bloginfo( 'name' ),
			'home_url'       => home_url(),
			'wp_version'     => $wp_version,
			'php_version'    => PHP_VERSION,
			'plugin_version' => WSTM_VERSION,
			'mode'           => $this->transfer['direction'],
			'multisite'      => is_multisite(),
			'max_chunk'      => self::safe_chunk(),
		);
	}

	/**
	 * Start (or reuse) the export of this site.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function export_start( \WP_REST_Request $r ): array {
		$m = $this->transfer['meta'];
		if ( ! empty( $m['export_job'] ) ) {
			try {
				$job = $this->plugin->jobs()->get( (int) $m['export_job'] );
				if ( ! in_array( $job->status, array( JobStatus::CANCELLED ), true ) ) {
					return array( 'job' => $job->id );
				}
			} catch ( WstmException $e ) {
				unset( $e );
			}
		}
		( new \WSTM\Rest\PackageController( $this->plugin ) )->assert_idle();
		$b   = $this->body( $r );
		$job = $this->plugin->jobs()->create( PackageExportHandler::TYPE, MigrationController::export_meta( $this->plugin, (array) ( $b['skip'] ?? array() ) ) );
		$this->meta( array( 'export_job' => $job->id ) );
		return array( 'job' => $job->id );
	}

	/** Run the export for one request budget. */
	private function export_run(): array {
		$id = (int) ( $this->transfer['meta']['export_job'] ?? 0 );
		if ( ! $id ) {
			throw new WstmException( 'no_export', 'Export has not been started.' );
		}
		$job = $this->plugin->jobs()->get( $id );
		if ( JobStatus::FAILED === $job->status && ! empty( $job->error['resumable'] ) ) {
			$job = $this->plugin->jobs()->resume( $id );
		}
		$job = $this->plugin->jobs()->run( $id, (int) $this->plugin->settings()->get( 'time_budget' ) );
		$out = array( 'status' => $job->status, 'progress' => $job->progress, 'step' => $job->current_step, 'error' => $job->error );
		if ( JobStatus::COMPLETED === $job->status ) {
			$file = (string) $job->metadata['file'];
			$path = PackageImportHandler::resolve( $this->plugin, $file );
			$this->meta( array( 'file' => $file ) );
			$out['file']   = $file;
			$out['size']   = (int) filesize( $path );
			$out['sha256'] = (string) ( $job->metadata['seal'] ?? '' );
		}
		return $out;
	}

	/**
	 * Serve one chunk of the exported package.
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException On invalid range.
	 */
	private function package_chunk( \WP_REST_Request $r ): array {
		$file = (string) ( $this->transfer['meta']['file'] ?? '' );
		if ( '' === $file ) {
			throw new WstmException( 'no_package', 'The package is not ready yet.' );
		}
		$path   = PackageImportHandler::resolve( $this->plugin, $file );
		$size   = (int) filesize( $path );
		$offset = max( 0, (int) $r->get_param( 'offset' ) );
		$length = min( self::MAX_CHUNK, max( 1, (int) $r->get_param( 'length' ) ) );
		if ( $offset >= $size ) {
			throw new WstmException( 'bad_range', 'Offset beyond end of package.' );
		}
		$fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fseek( $fh, $offset );
		$data = (string) fread( $fh, min( $length, $size - $offset ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return array(
			'offset' => $offset,
			'size'   => $size,
			'sha256' => hash( 'sha256', $data ),
			'data'   => base64_encode( $data ),
		);
	}

	/** Uploads for push mode. */
	private function uploads(): UploadManager {
		return new UploadManager( $this->plugin->storage() );
	}

	/**
	 * Begin receiving a package.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function upload_start( \WP_REST_Request $r ): array {
		$b = $this->body( $r );
		( new \WSTM\Rest\PackageController( $this->plugin ) )->assert_idle();
		$up = $this->uploads()->start( 'transfer-' . substr( $this->transfer['transfer_id'], 0, 8 ) . '.wpmig', (int) ( $b['size'] ?? 0 ), 'transfer:' . $this->transfer['transfer_id'] );
		$this->meta( array( 'upload' => $up['id'] ) );
		return array( 'id' => $up['id'], 'received' => $up['received'] );
	}

	/**
	 * Receive a chunk.
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException On bad data.
	 */
	private function upload_chunk( \WP_REST_Request $r ): array {
		$b    = $this->body( $r );
		$data = base64_decode( (string) ( $b['data'] ?? '' ), true );
		if ( false === $data || strlen( $data ) > self::MAX_CHUNK ) {
			throw new WstmException( 'bad_chunk', 'Invalid chunk data.' );
		}
		$up = $this->uploads()->chunk( (string) ( $this->transfer['meta']['upload'] ?? '' ), (int) ( $b['offset'] ?? 0 ), $data, (string) ( $b['sha256'] ?? '' ) ?: null );
		return array( 'received' => $up['received'] );
	}

	/** Finish receiving. */
	private function upload_finish(): array {
		$done = $this->uploads()->finish( (string) ( $this->transfer['meta']['upload'] ?? '' ) );
		$this->meta( array( 'file' => $done['file'] ) );
		return $done;
	}

	/**
	 * Start the restore of the received package.
	 *
	 * @param \WP_REST_Request $r Request.
	 * @throws WstmException If nothing was received.
	 */
	private function restore_start( \WP_REST_Request $r ): array {
		$m = $this->transfer['meta'];
		if ( ! empty( $m['restore_job'] ) ) {
			return array( 'job' => (int) $m['restore_job'] );
		}
		if ( empty( $m['file'] ) ) {
			throw new WstmException( 'no_package', 'No package has been received.' );
		}
		( new \WSTM\Rest\PackageController( $this->plugin ) )->assert_idle();
		$b   = $this->body( $r );
		$job = $this->plugin->jobs()->create(
			SiteRestoreHandler::TYPE,
			array(
				'file'          => (string) $m['file'],
				'confirmed'     => true, // The administrator of this site allowed it by issuing a push key.
				'safety_backup' => true,
				'keep_users'    => ! empty( $b['keep_users'] ),
				'label'         => 'Pushed from ' . sanitize_text_field( (string) ( $b['source'] ?? 'another site' ) ),
			)
		);
		$this->meta( array( 'restore_job' => $job->id ) );
		return array( 'job' => $job->id );
	}

	/** Run the restore for one request budget. */
	private function restore_run(): array {
		$id = (int) ( $this->transfer['meta']['restore_job'] ?? 0 );
		if ( ! $id ) {
			throw new WstmException( 'no_restore', 'Restore has not been started.' );
		}
		$job = $this->plugin->jobs()->get( $id );
		if ( JobStatus::FAILED === $job->status && ! empty( $job->error['resumable'] ) ) {
			$job = $this->plugin->jobs()->resume( $id );
		}
		$job = $this->plugin->jobs()->run( $id, (int) $this->plugin->settings()->get( 'time_budget' ) );
		return array( 'status' => $job->status, 'progress' => $job->progress, 'step' => $job->current_step, 'error' => $job->error, 'result' => JobStatus::COMPLETED === $job->status ? $job->metadata : null );
	}

	/**
	 * Close the transfer: invalidate the key; for pulls, delete the served package.
	 *
	 * @param \WP_REST_Request $r Request.
	 */
	private function finish( \WP_REST_Request $r ): array {
		$b = $this->body( $r );
		if ( 'pull' === $this->transfer['direction'] && ! empty( $this->transfer['meta']['file'] ) && ( $b['delete_package'] ?? true ) ) {
			try {
				$path = PackageImportHandler::resolve( $this->plugin, (string) $this->transfer['meta']['file'] );
				wp_delete_file( $path );
				\WSTM\Package\PackageInfo::delete( $path );
			} catch ( WstmException $e ) {
				unset( $e );
			}
		}
		( new TransferKeys( $this->plugin ) )->finish( $this->transfer['transfer_id'] );
		$this->plugin->logger()->info( 'Transfer finished', array( 'transfer' => substr( $this->transfer['transfer_id'], 0, 8 ) ), 'transfer' );
		return array( 'finished' => true );
	}

	/**
	 * Error wrapper.
	 *
	 * @param callable $fn Callback.
	 */
	private function wrap( callable $fn ) {
		try {
			return rest_ensure_response( $fn() );
		} catch ( WstmException $e ) {
			return new \WP_Error( $e->get_error_code(), $e->getMessage(), array_merge( $e->to_array(), array( 'status' => 400 ) ) );
		} catch ( \Throwable $e ) {
			$this->plugin->logger()->error( 'Transfer endpoint error: ' . $e->getMessage(), array(), 'transfer' );
			return new \WP_Error( 'wstm_internal', 'Internal error on the remote site. See its logs.', array( 'status' => 500 ) );
		}
	}
}
