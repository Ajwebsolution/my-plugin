<?php
/**
 * Resumable recursive filesystem scanner.
 *
 * Walks one or more roots using an explicit directory stack stored in the
 * checkpoint, and streams results to an index file (one JSON line per entry),
 * so millions of files never live in memory or in the database. Symlinks are
 * never followed (recorded as warnings); unreadable paths are recorded too.
 *
 * Index line: {"r":"root","p":"rel/path","t":"f|d","s":size,"m":mtime}
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Scanner.
 */
final class FileScanner {

	private const MAX_WARNINGS = 200;

	/**
	 * Initial state.
	 *
	 * @param array<string,string> $roots   root key => absolute dir.
	 * @param string[]             $rules   Exclusion rules (relative to each root, prefixed "key:" to target one root).
	 * @param string               $index   Index file path.
	 * @param array<string,string[]> $skip  root key => relative dirs to skip (nested roots).
	 */
	public static function init_state( array $roots, array $rules, string $index, array $skip = array() ): array {
		$stack = array();
		foreach ( array_reverse( $roots, true ) as $key => $dir ) {
			$stack[] = array( $key, '' );
		}
		return array(
			'roots'     => array_map( static fn( $d ) => rtrim( wp_normalize_path( $d ), '/' ), $roots ),
			'rules'     => array_values( $rules ),
			'skip'      => $skip,
			'stack'     => $stack,
			'index'     => $index,
			'committed' => 0,
			'files'     => 0,
			'dirs'      => 0,
			'bytes'     => 0,
			'warnings'  => array(),
			'skipped'   => 0,
			'done'      => false,
		);
	}

	/**
	 * Rules applicable to a root ("key:rule" targets a root; plain rules apply everywhere).
	 *
	 * @param array  $rules Rules.
	 * @param string $key   Root key.
	 */
	private static function rules_for( array $rules, string $key ): ExclusionRules {
		$out = array();
		foreach ( $rules as $r ) {
			if ( preg_match( '/^([a-z_]+):(.*)$/', $r, $m ) ) {
				if ( $m[1] === $key ) {
					$out[] = $m[2];
				}
			} else {
				$out[] = $r;
			}
		}
		return new ExclusionRules( $out );
	}

	/**
	 * Scan until done or deadline (checked between directories).
	 *
	 * @param array $s        State.
	 * @param int   $deadline Deadline.
	 * @param string|null $storage_root Absolute storage root to always exclude.
	 * @throws WstmException On index write failure.
	 */
	public static function step( array $s, int $deadline, ?string $storage_root = null ): array {
		clearstatcache();
		$fh = fopen( $s['index'], 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			throw new WstmException( 'io_error', 'Could not write the file index.', array( 'resumable' => true ) );
		}
		ftruncate( $fh, $s['committed'] );
		fseek( $fh, $s['committed'] );
		$rules   = array();
		$storage = $storage_root ? rtrim( wp_normalize_path( $storage_root ), '/' ) : null;

		try {
			do {
				$item = array_pop( $s['stack'] );
				if ( null === $item ) {
					$s['done'] = true;
					break;
				}
				[ $key, $rel ] = $item;
				$rules[ $key ] ??= self::rules_for( $s['rules'], $key );
				$root           = $s['roots'][ $key ];
				$abs            = '' === $rel ? $root : $root . '/' . $rel;

				$dh = @opendir( $abs ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				if ( ! $dh ) {
					$s = self::warn( $s, 'Unreadable directory skipped: ' . $key . '/' . $rel );
					continue;
				}
				$subdirs = array();
				$lines   = '';
				while ( false !== ( $name = readdir( $dh ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
					if ( '.' === $name || '..' === $name ) {
						continue;
					}
					$child_rel = '' === $rel ? $name : $rel . '/' . $name;
					$child_abs = $abs . '/' . $name;
					if ( str_contains( $name, "\n" ) || str_contains( $name, "\0" ) ) {
						$s = self::warn( $s, 'Invalid file name skipped in ' . $key . '/' . $rel );
						continue;
					}
					if ( is_link( $child_abs ) ) {
						$s = self::warn( $s, 'Symlink not followed: ' . $key . '/' . $child_rel );
						continue;
					}
					$is_dir = is_dir( $child_abs );
					if ( $is_dir && ( ( $storage && $child_abs === $storage ) || in_array( $child_rel, $s['skip'][ $key ] ?? array(), true ) ) ) {
						continue; // Our own storage, or a nested root scanned separately.
					}
					if ( $rules[ $key ]->excluded( $child_rel, $is_dir ) ) {
						++$s['skipped'];
						continue;
					}
					if ( $is_dir ) {
						$subdirs[] = $child_rel;
						$lines    .= wp_json_encode( array( 'r' => $key, 'p' => $child_rel, 't' => 'd' ) ) . "\n";
						++$s['dirs'];
						continue;
					}
					if ( ! is_readable( $child_abs ) ) {
						$s = self::warn( $s, 'Unreadable file skipped: ' . $key . '/' . $child_rel );
						continue;
					}
					$size = (int) @filesize( $child_abs ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
					$lines .= wp_json_encode( array( 'r' => $key, 'p' => $child_rel, 't' => 'f', 's' => $size, 'm' => (int) @filemtime( $child_abs ) ) ) . "\n"; // phpcs:ignore WordPress.PHP.NoSilencedErrors
					++$s['files'];
					$s['bytes'] += $size;
					if ( strlen( $lines ) > 262144 ) {
						self::write( $fh, $lines );
						$lines = '';
					}
				}
				closedir( $dh );
				self::write( $fh, $lines );
				// Depth-first, alphabetical for deterministic packages.
				rsort( $subdirs, SORT_STRING );
				foreach ( $subdirs as $d ) {
					$s['stack'][] = array( $key, $d );
				}
			} while ( time() < $deadline );
			fflush( $fh );
			$s['committed'] = ftell( $fh );
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( ! $s['stack'] ) {
			$s['done'] = true;
		}
		return $s;
	}

	/**
	 * Write to index.
	 *
	 * @param resource $fh    Handle.
	 * @param string   $lines Data.
	 * @throws WstmException On short write.
	 */
	private static function write( $fh, string $lines ): void {
		if ( '' !== $lines && fwrite( $fh, $lines ) !== strlen( $lines ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			throw new WstmException( 'write_failed', 'Writing the file index failed (disk full?).', array( 'resumable' => true ) );
		}
	}

	/**
	 * Bounded warning list.
	 *
	 * @param array  $s   State.
	 * @param string $msg Message.
	 */
	private static function warn( array $s, string $msg ): array {
		if ( count( $s['warnings'] ) < self::MAX_WARNINGS ) {
			$s['warnings'][] = $msg;
		}
		return $s;
	}

	/**
	 * Iterate an index file from a byte offset.
	 *
	 * @param string $index  Index path.
	 * @param int    $offset Offset.
	 * @return \Generator<int,array> offset_after => entry
	 */
	public static function read_index( string $index, int $offset = 0 ): \Generator {
		$fh = fopen( $index, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			return;
		}
		fseek( $fh, $offset );
		try {
			while ( false !== ( $line = fgets( $fh ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
				$entry = json_decode( $line, true );
				if ( is_array( $entry ) ) {
					yield ftell( $fh ) => $entry;
				}
			}
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}
}
