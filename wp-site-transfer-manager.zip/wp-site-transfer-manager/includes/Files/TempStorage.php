<?php
/**
 * Safe storage system for temporary data, packages and backups.
 *
 * Layout (root = custom path or wp-content/wstm-storage-<random>):
 *   root/tmp/<job-uuid>/...
 *   root/packages/
 *   root/backups/
 * Every directory is protected with index.php, .htaccess and web.config.
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

use WSTM\Core\Settings;
use WSTM\Core\WstmException;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * Temp storage.
 */
class TempStorage {

	public const DIR_OPTION = 'wstm_storage_dirname';
	public const AREAS      = array( 'tmp', 'packages', 'backups' );

	/**
	 * @var Settings
	 */
	private Settings $settings;

	/**
	 * Constructor.
	 *
	 * @param Settings $settings Settings.
	 */
	public function __construct( Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Root directory (absolute, normalized, no trailing slash).
	 */
	public function root(): string {
		$custom = (string) $this->settings->get( 'storage_path' );
		if ( '' !== $custom ) {
			return untrailingslashit( wp_normalize_path( $custom ) ) . '/wstm-storage';
		}
		$name = get_site_option( self::DIR_OPTION );
		if ( ! is_string( $name ) || ! preg_match( '/^wstm-storage-[a-f0-9]{16}$/', $name ) ) {
			$name = 'wstm-storage-' . bin2hex( random_bytes( 8 ) );
			update_site_option( self::DIR_OPTION, $name );
		}
		return untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . '/' . $name;
	}

	/**
	 * Whether the root is reachable via the public web (inside ABSPATH/WP_CONTENT).
	 */
	public function is_publicly_located(): bool {
		$root = $this->root();
		return PathGuard::is_within( untrailingslashit( wp_normalize_path( ABSPATH ) ), $root )
			|| PathGuard::is_within( untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ), $root );
	}

	/**
	 * Create root and areas with protection files.
	 *
	 * @throws WstmException If not creatable.
	 */
	public function ensure_root(): string {
		$root = $this->root();
		foreach ( array_merge( array( '' ), self::AREAS ) as $area ) {
			$dir = $root . ( $area ? '/' . $area : '' );
			if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
				throw new WstmException(
					'storage_unwritable',
					'Could not create storage directory.',
					array(
						'what'   => 'Storage initialisation',
						'why'    => 'Directory is not writable: ' . $dir,
						'action' => 'Make wp-content writable or set a custom storage directory in Settings.',
					)
				);
			}
			$this->protect( $dir );
		}
		return $root;
	}

	/**
	 * Write protection files into a directory (idempotent).
	 *
	 * @param string $dir Directory.
	 */
	public function protect( string $dir ): void {
		$files = array(
			'index.php'  => "<?php\n// Silence is golden.\n",
			'.htaccess'  => "# WP Site Transfer Manager - deny all\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder allow,deny\n\tDeny from all\n</IfModule>\nOptions -Indexes\n",
			'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization><directoryBrowse enabled=\"false\" /></system.webServer></configuration>\n",
		);
		foreach ( $files as $name => $content ) {
			$path = $dir . '/' . $name;
			if ( ! file_exists( $path ) ) {
				file_put_contents( $path, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
	}

	/**
	 * Absolute path to an area directory.
	 *
	 * @param string $area Area.
	 * @throws WstmException On unknown area.
	 */
	public function area( string $area ): string {
		if ( ! in_array( $area, self::AREAS, true ) ) {
			throw new WstmException( 'bad_area', 'Unknown storage area.' );
		}
		$this->ensure_root();
		return $this->root() . '/' . $area;
	}

	/**
	 * Create (or return) a private working directory for a job.
	 *
	 * @param string $job_uuid Job UUID.
	 * @throws WstmException On failure.
	 */
	public function job_dir( string $job_uuid ): string {
		if ( ! wp_is_uuid( $job_uuid ) ) {
			throw new WstmException( 'bad_uuid', 'Invalid job identifier.' );
		}
		$dir = $this->area( 'tmp' ) . '/' . $job_uuid;
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			throw new WstmException( 'storage_unwritable', 'Could not create job directory.', array( 'why' => $dir ) );
		}
		$this->protect( $dir );
		return $dir;
	}

	/**
	 * Resolve a safe path inside an area (traversal + symlink checked).
	 *
	 * @param string $area     Area.
	 * @param string $relative Relative path.
	 */
	public function path( string $area, string $relative ): string {
		return PathGuard::resolve_within( $this->area( $area ), $relative );
	}

	/**
	 * Unpredictable filename with a given extension.
	 *
	 * @param string $prefix Prefix (slug).
	 * @param string $ext    Extension.
	 */
	public function random_filename( string $prefix, string $ext ): string {
		return sanitize_file_name( $prefix ) . '-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 8 ) ) . '.' . preg_replace( '/[^a-z0-9.]/', '', strtolower( $ext ) );
	}

	/**
	 * Recursively delete a directory INSIDE the storage root only. Never follows symlinks.
	 *
	 * @param string $dir Absolute dir.
	 * @throws WstmException If outside root.
	 */
	public function delete_dir( string $dir ): void {
		$dir  = untrailingslashit( wp_normalize_path( $dir ) );
		$root = $this->root();
		if ( $dir === $root || ! PathGuard::is_within( $root, $dir ) ) {
			throw new WstmException( 'unsafe_delete', 'Refusing to delete outside temporary storage.', array( 'why' => 'Path not inside storage root' ) );
		}
		if ( ! is_dir( $dir ) || is_link( $dir ) ) {
			return;
		}
		$it = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CHILD_FIRST
		);
		foreach ( $it as $item ) {
			/** @var \SplFileInfo $item */
			if ( $item->isLink() || $item->isFile() ) {
				wp_delete_file( $item->getPathname() );
				if ( file_exists( $item->getPathname() ) || is_link( $item->getPathname() ) ) {
					unlink( $item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				}
			} elseif ( $item->isDir() ) {
				rmdir( $item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
		rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Delete tmp job directories older than $age seconds. Never touches backups/packages.
	 *
	 * @param int $age Seconds.
	 */
	public function purge_stale( int $age ): int {
		$tmp = $this->root() . '/tmp';
		if ( ! is_dir( $tmp ) ) {
			return 0;
		}
		$count = 0;
		foreach ( new \DirectoryIterator( $tmp ) as $entry ) {
			if ( $entry->isDot() || ! $entry->isDir() || $entry->isLink() || ! wp_is_uuid( $entry->getFilename() ) ) {
				continue;
			}
			if ( $entry->getMTime() < time() - $age ) {
				$this->delete_dir( $entry->getPathname() );
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Free disk space at the storage root (bytes) or null if unknown.
	 */
	public function free_space(): ?float {
		if ( ! function_exists( 'disk_free_space' ) ) {
			return null;
		}
		$dir  = is_dir( $this->root() ) ? $this->root() : WP_CONTENT_DIR;
		$free = @disk_free_space( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- often disabled on shared hosts.
		return false === $free ? null : (float) $free;
	}

	/**
	 * Size of a directory, streamed (no big arrays). Stops after $limit seconds.
	 *
	 * @param string $dir   Directory.
	 * @param int    $limit Seconds.
	 * @return array{bytes:int,files:int,complete:bool}
	 */
	public static function dir_size( string $dir, int $limit = 5 ): array {
		$bytes = 0;
		$files = 0;
		$end   = microtime( true ) + $limit;
		if ( ! is_dir( $dir ) ) {
			return compact( 'bytes', 'files' ) + array( 'complete' => true );
		}
		try {
			$it = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
				\RecursiveIteratorIterator::LEAVES_ONLY,
				\RecursiveIteratorIterator::CATCH_GET_CHILD
			);
			foreach ( $it as $f ) {
				if ( $f->isFile() && ! $f->isLink() ) {
					$bytes += (int) $f->getSize();
					++$files;
				}
				if ( 0 === $files % 500 && microtime( true ) > $end ) {
					return compact( 'bytes', 'files' ) + array( 'complete' => false );
				}
			}
		} catch ( \Throwable $e ) {
			return compact( 'bytes', 'files' ) + array( 'complete' => false );
		}
		return compact( 'bytes', 'files' ) + array( 'complete' => true );
	}
}
