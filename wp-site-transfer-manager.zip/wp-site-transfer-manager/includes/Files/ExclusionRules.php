<?php
/**
 * Exclusion engine for file scanning.
 *
 * Rules are relative paths (forward slashes):
 *   "wp-content/cache/"  → directory prefix
 *   "*.log"              → glob against the basename
 *   "wp-content/*.tmp"   → glob against the full relative path
 *   "error_log"          → exact relative path or basename
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

defined( 'ABSPATH' ) || exit;

/**
 * Exclusion rules.
 */
final class ExclusionRules {

	/** Directory prefixes. @var string[] */
	private array $prefixes = array();

	/** Glob patterns. @var string[] */
	private array $globs = array();

	/** Exact names. @var array<string,bool> */
	private array $exact = array();

	/**
	 * Constructor.
	 *
	 * @param string[] $rules Rules.
	 */
	public function __construct( array $rules ) {
		foreach ( $rules as $r ) {
			$r = trim( str_replace( '\\', '/', (string) $r ) );
			$r = ltrim( $r, '/' );
			if ( '' === $r || str_contains( $r, '..' ) ) {
				continue;
			}
			if ( str_ends_with( $r, '/' ) ) {
				$this->prefixes[] = $r;
			} elseif ( strpbrk( $r, '*?[' ) ) {
				$this->globs[] = $r;
			} else {
				$this->exact[ $r ] = true;
			}
		}
	}

	/**
	 * Whether a relative path is excluded.
	 *
	 * @param string $rel   Relative path (no leading slash).
	 * @param bool   $is_dir Whether it is a directory.
	 */
	public function excluded( string $rel, bool $is_dir = false ): bool {
		$check = $is_dir ? rtrim( $rel, '/' ) . '/' : $rel;
		foreach ( $this->prefixes as $p ) {
			// Single-segment rules ("node_modules/") match at any depth; multi-segment rules are anchored.
			if ( 1 === substr_count( $p, '/' ) ? str_contains( '/' . $check, '/' . $p ) : str_starts_with( $check, $p ) ) {
				return true;
			}
		}
		$base = basename( $rel );
		if ( isset( $this->exact[ $rel ] ) || isset( $this->exact[ $base ] ) ) {
			return true;
		}
		foreach ( $this->globs as $g ) {
			$target = str_contains( $g, '/' ) ? $rel : $base;
			if ( fnmatch( $g, $target, FNM_PATHNAME | FNM_PERIOD ) ) {
				return true;
			}
		}
		return false;
	}

	/** Rules as array (for manifests). */
	public function to_array(): array {
		return array_merge( $this->prefixes, $this->globs, array_keys( $this->exact ) );
	}
}
