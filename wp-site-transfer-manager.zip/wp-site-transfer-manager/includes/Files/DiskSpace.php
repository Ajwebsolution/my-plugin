<?php
/**
 * Disk-space requirement checks (run before anything is modified).
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Disk space guard.
 */
final class DiskSpace {

	/** Safety margin added to every estimate. */
	public const MARGIN = 104857600; // 100 MB.

	/**
	 * Build a requirement report.
	 *
	 * @param TempStorage          $storage Storage.
	 * @param array<string,int>    $parts   Label => bytes.
	 * @return array{parts:array,required:int,available:?float,safe:?bool}
	 */
	public static function report( TempStorage $storage, array $parts ): array {
		$required  = (int) array_sum( $parts ) + self::MARGIN;
		$available = $storage->free_space();
		return array(
			'parts'     => $parts,
			'required'  => $required,
			'available' => $available,
			'safe'      => null === $available ? null : $available >= $required,
		);
	}

	/**
	 * Throw unless enough space is known to be available.
	 *
	 * @param TempStorage       $storage       Storage.
	 * @param array<string,int> $parts         Label => bytes.
	 * @param bool              $allow_unknown Proceed when free space cannot be determined.
	 * @throws WstmException When insufficient or unknown (and not allowed).
	 */
	public static function require( TempStorage $storage, array $parts, bool $allow_unknown = false ): array {
		$r      = self::report( $storage, $parts );
		$detail = implode( ', ', array_map( static fn( $k, $v ) => $k . ' ' . size_format( $v ), array_keys( $parts ), $parts ) );
		if ( false === $r['safe'] ) {
			throw new WstmException(
				'insufficient_disk',
				'Not enough free disk space.',
				array(
					'what'   => 'Disk space check',
					'why'    => sprintf( 'Required %s (%s + margin), available %s.', size_format( $r['required'] ), $detail, size_format( $r['available'] ) ),
					'action' => 'Free disk space or choose another storage directory. Nothing was changed.',
					'data'   => $r,
				)
			);
		}
		if ( null === $r['safe'] && ! $allow_unknown ) {
			throw new WstmException(
				'disk_unknown',
				'Free disk space cannot be determined on this server.',
				array(
					'what'   => 'Disk space check',
					'why'    => 'disk_free_space() is disabled. Estimated requirement: ' . size_format( $r['required'] ) . '.',
					'action' => 'Confirm you have enough space and start again with "proceed without disk check" ticked.',
					'data'   => $r,
				)
			);
		}
		return $r;
	}
}
