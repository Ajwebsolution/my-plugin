<?php
/**
 * Applies staged package files to the live site (resumable, with rollback copies).
 *
 * For every staged file: the live file (if any) is moved into the rollback
 * folder, then the staged file is moved into place. Every step is idempotent,
 * so a request killed at any point resumes safely. Files that are not in the
 * package are never deleted. The running copy of this plugin, wp-config.php
 * and plugin storage are never overwritten.
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

use WSTM\Core\WstmException;
use WSTM\Security\PathGuard;

defined( 'ABSPATH' ) || exit;

/**
 * File applier.
 */
final class FileApplier {

	/** Apply order: content first, core last. */
	public const ORDER = array( 'content', 'uploads', 'themes', 'plugins', 'abspath', 'core_includes', 'core_admin' );

	/**
	 * Initial state.
	 *
	 * @param string $staging  Staging dir (contains <root>/...).
	 * @param string $rollback Rollback dir.
	 * @param string $index    Index file path.
	 */
	public static function init_state( string $staging, string $rollback, string $index ): array {
		$roots = array();
		foreach ( self::ORDER as $k ) {
			if ( is_dir( $staging . '/' . $k ) ) {
				$roots[ $k ] = $staging . '/' . $k;
			}
		}
		return array(
			'staging'  => $staging,
			'rollback' => $rollback,
			'scan'     => FileScanner::init_state( $roots, array(), $index ),
			'offset'   => 0,
			'checked'  => false,
			'applied'  => 0,
			'replaced' => 0,
			'skipped'  => 0,
			'total'    => 0,
			'warnings' => array(),
			'done'     => false,
		);
	}

	/**
	 * Paths that must never be overwritten on this site: root => [relative paths].
	 */
	public static function protected_paths(): array {
		$plugin_dir = defined( 'WSTM_BASENAME' ) ? dirname( WSTM_BASENAME ) : 'wp-site-transfer-manager';
		return array(
			'plugins' => array( $plugin_dir ),
			'abspath' => array( 'wp-config.php' ),
		);
	}

	/**
	 * One slice.
	 *
	 * @param array  $s            State.
	 * @param int    $deadline     Deadline.
	 * @param string $storage_root Plugin storage root (never written).
	 * @throws WstmException On failure.
	 */
	public static function step( array $s, int $deadline, string $storage_root ): array {
		if ( ! $s['scan']['done'] ) {
			$s['scan'] = FileScanner::step( $s['scan'], $deadline );
			if ( $s['scan']['done'] ) {
				$s['total'] = (int) $s['scan']['files'];
			}
			return $s;
		}
		$live = SiteRoots::dirs();
		if ( ! $s['checked'] ) {
			$problems = array();
			foreach ( array_keys( $s['scan']['roots'] ) as $k ) {
				if ( ! is_dir( $live[ $k ] ) && ! wp_mkdir_p( $live[ $k ] ) ) {
					$problems[] = $live[ $k ];
				} elseif ( ! wp_is_writable( $live[ $k ] ) ) {
					$problems[] = $live[ $k ];
				}
			}
			if ( $problems ) {
				throw new WstmException( 'not_writable', 'Some site folders are not writable.', array( 'what' => 'Applying files', 'why' => implode( ', ', $problems ), 'resumable' => true, 'action' => 'Fix folder permissions (usually 755, owned by the web server user), then resume. The database has not been switched yet.' ) );
			}
			$s['checked'] = true;
		}

		$protected = self::protected_paths();
		$storage   = rtrim( wp_normalize_path( $storage_root ), '/' );
		$gen       = FileScanner::read_index( $s['scan']['index'], (int) $s['offset'] );
		$first     = true;
		while ( $gen->valid() && ( $first || time() < $deadline ) ) {
			$first = false;
			$e     = $gen->current();
			$after = $gen->key();
			$gen->next();
			$s['offset'] = $after;

			$root = $e['r'];
			$rel  = $e['p'];
			foreach ( $protected[ $root ] ?? array() as $p ) {
				if ( $rel === $p || str_starts_with( $rel, $p . '/' ) ) {
					++$s['skipped'];
					continue 2;
				}
			}
			$dest_root = $live[ $root ];
			$dest      = PathGuard::resolve_within( $dest_root, $rel );
			if ( PathGuard::is_within( $storage, wp_normalize_path( $dest ) ) ) {
				++$s['skipped'];
				continue;
			}
			if ( 'd' === $e['t'] ) {
				if ( ! is_dir( $dest ) ) {
					if ( file_exists( $dest ) ) {
						self::to_rollback( $s, $root, $rel, $dest );
					}
					if ( ! wp_mkdir_p( $dest ) ) {
						throw self::fail( 'Could not create folder ' . $root . '/' . $rel );
					}
				}
				continue;
			}
			$src = $s['staging'] . '/' . $root . '/' . $rel;
			if ( ! is_file( $src ) ) {
				continue; // Already applied in an earlier (interrupted) request.
			}
			if ( is_dir( $dest ) ) {
				throw self::fail( 'A folder exists where the package has a file: ' . $root . '/' . $rel );
			}
			if ( file_exists( $dest ) ) {
				self::to_rollback( $s, $root, $rel, $dest );
				++$s['replaced'];
			} else {
				// Remember files that did not exist before, so an undo can remove them.
				file_put_contents( $s['rollback'] . '/created.lst', $root . '/' . $rel . "\n", FILE_APPEND ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
			if ( ! is_dir( dirname( $dest ) ) && ! wp_mkdir_p( dirname( $dest ) ) ) {
				throw self::fail( 'Could not create folder for ' . $root . '/' . $rel );
			}
			if ( ! self::move( $src, $dest ) ) {
				throw self::fail( 'Could not write ' . $root . '/' . $rel );
			}
			++$s['applied'];
		}
		if ( ! $gen->valid() ) {
			$s['done'] = true;
		}
		return $s;
	}

	/**
	 * Move a live file into the rollback folder.
	 *
	 * @param array  $s    State.
	 * @param string $root Root.
	 * @param string $rel  Relative path.
	 * @param string $dest Live path.
	 * @throws WstmException On failure.
	 */
	private static function to_rollback( array $s, string $root, string $rel, string $dest ): void {
		$rb = $s['rollback'] . '/' . $root . '/' . $rel;
		if ( file_exists( $rb ) ) {
			$rb .= '.wstmprev-' . time(); // Intermediate version (chain restores); the original keeps the plain name.
		}
		if ( ! is_dir( dirname( $rb ) ) && ! wp_mkdir_p( dirname( $rb ) ) ) {
			throw self::fail( 'Could not create rollback folder for ' . $root . '/' . $rel );
		}
		if ( ! self::move( $dest, $rb ) ) {
			throw self::fail( 'Could not back up existing file ' . $root . '/' . $rel );
		}
	}

	/**
	 * Rename with copy+unlink fallback (cross-device).
	 *
	 * @param string $from From.
	 * @param string $to   To.
	 */
	private static function move( string $from, string $to ): bool {
		if ( @rename( $from, $to ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return true;
		}
		if ( @copy( $from, $to ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			@unlink( $from ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			return true;
		}
		return false;
	}

	/**
	 * Structured failure.
	 *
	 * @param string $why Why.
	 */
	private static function fail( string $why ): WstmException {
		return new WstmException( 'apply_failed', 'Applying files failed.', array( 'what' => 'Applying files', 'why' => $why, 'resumable' => true, 'action' => 'Check folder permissions and free space, then resume. Replaced files are kept in the rollback folder.' ) );
	}
}
