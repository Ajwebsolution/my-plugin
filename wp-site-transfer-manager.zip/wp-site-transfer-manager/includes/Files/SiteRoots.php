<?php
/**
 * Logical filesystem roots of a WordPress install and component mapping.
 *
 * Packages store files as "files/<root>/<relative path>" so they restore
 * correctly even when wp-content, plugins or uploads live in custom places.
 *
 * Roots: abspath, core_admin, core_includes, content, plugins, themes, uploads.
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

defined( 'ABSPATH' ) || exit;

/**
 * Site roots.
 */
final class SiteRoots {

	public const KEYS = array( 'abspath', 'core_admin', 'core_includes', 'content', 'plugins', 'themes', 'uploads' );

	/** Components selectable in the UI. */
	public const COMPONENTS = array( 'database', 'core', 'plugins', 'themes', 'uploads', 'content', 'root' );

	/** Files in the WordPress root that belong to core. */
	private const CORE_ROOT_RE = '/^(index\.php|wp-(?!config\.php$)[a-z0-9-]+\.php|xmlrpc\.php|license\.txt|readme\.html)$/i';

	/**
	 * Absolute directories for each root on this site.
	 *
	 * @return array<string,string>
	 */
	public static function dirs(): array {
		$n       = static fn( $p ) => rtrim( wp_normalize_path( (string) $p ), '/' );
		$uploads = wp_upload_dir( null, false );
		return array(
			'abspath'       => $n( ABSPATH ),
			'core_admin'    => $n( ABSPATH . 'wp-admin' ),
			'core_includes' => $n( ABSPATH . WPINC ),
			'content'       => $n( WP_CONTENT_DIR ),
			'plugins'       => $n( WP_PLUGIN_DIR ),
			'themes'        => $n( get_theme_root() ),
			'uploads'       => $n( $uploads['basedir'] ),
		);
	}

	/**
	 * Roots to scan for the selected components, plus nested dirs to skip.
	 *
	 * @param array<string,bool> $components Component flags.
	 * @return array{roots:array<string,string>,skip:array<string,string[]>}
	 */
	public static function scan_plan( array $components ): array {
		$dirs  = self::dirs();
		$roots = array();
		if ( ! empty( $components['core'] ) ) {
			$roots['core_admin']    = $dirs['core_admin'];
			$roots['core_includes'] = $dirs['core_includes'];
		}
		if ( ! empty( $components['core'] ) || ! empty( $components['root'] ) ) {
			$roots['abspath'] = $dirs['abspath'];
		}
		foreach ( array( 'content', 'plugins', 'themes', 'uploads' ) as $k ) {
			if ( ! empty( $components[ $k ] ) ) {
				$roots[ $k ] = $dirs[ $k ];
			}
		}

		// Never descend into a directory that is (or contains) another root; each root is scanned on its own.
		$skip = array();
		foreach ( $roots as $key => $dir ) {
			foreach ( $dirs as $other => $odir ) {
				if ( $other === $key || 'abspath' === $other ) {
					continue;
				}
				if ( str_starts_with( $odir . '/', $dir . '/' ) && $odir !== $dir ) {
					$skip[ $key ][] = substr( $odir, strlen( $dir ) + 1 );
				}
			}
		}
		return array(
			'roots' => $roots,
			'skip'  => $skip,
		);
	}

	/**
	 * Whether an indexed entry belongs to the selected components.
	 *
	 * @param string             $root       Root key.
	 * @param string             $rel        Relative path.
	 * @param array<string,bool> $components Components.
	 */
	public static function wanted( string $root, string $rel, array $components ): bool {
		if ( 'abspath' !== $root ) {
			return true;
		}
		if ( 'wp-config.php' === $rel ) {
			return false; // Credentials never travel in packages (see metadata.json config summary).
		}
		$core = ! str_contains( $rel, '/' ) && preg_match( self::CORE_ROOT_RE, $rel );
		return $core ? ! empty( $components['core'] ) : ! empty( $components['root'] );
	}

	/**
	 * Translate user exclusions (relative to the WordPress root) into per-root rules.
	 *
	 * @param string[] $rules Rules like "wp-content/cache/", ".git/", "*.log".
	 */
	public static function translate_rules( array $rules ): array {
		$dirs = self::dirs();
		$abs  = $dirs['abspath'];
		$out  = array();
		foreach ( $rules as $rule ) {
			$rule = ltrim( str_replace( '\\', '/', trim( (string) $rule ) ), '/' );
			if ( '' === $rule ) {
				continue;
			}
			if ( preg_match( '/^(' . implode( '|', self::KEYS ) . '):/', $rule ) ) {
				$out[] = $rule; // Already root-scoped.
				continue;
			}
			$matched = false;
			// Most specific root first.
			$candidates = $dirs;
			unset( $candidates['abspath'] );
			uasort( $candidates, static fn( $a, $b ) => strlen( $b ) <=> strlen( $a ) );
			foreach ( $candidates as $key => $dir ) {
				if ( ! str_starts_with( $dir . '/', $abs . '/' ) ) {
					continue;
				}
				$prefix = substr( $dir, strlen( $abs ) + 1 ) . '/';
				if ( str_starts_with( $rule, $prefix ) ) {
					$out[]   = $key . ':' . substr( $rule, strlen( $prefix ) );
					$matched = true;
					break;
				}
			}
			if ( ! $matched ) {
				// Single-segment/glob rules apply everywhere; rooted paths apply to abspath.
				$single = 1 === substr_count( rtrim( $rule, '/' ) . '/', '/' ) && ! str_contains( rtrim( $rule, '/' ), '/' );
				$out[]  = $single ? $rule : 'abspath:' . $rule;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Built-in exclusions that always apply.
	 */
	public static function builtin_rules(): array {
		return array( 'content:cache/', 'content:upgrade/', 'content:upgrade-temp-backup/', 'content:wflogs/', 'content:wstm-storage-*', '*.wstmpart', 'content:debug.log' );
	}
}
