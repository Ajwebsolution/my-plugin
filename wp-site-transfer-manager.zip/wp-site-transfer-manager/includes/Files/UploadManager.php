<?php
/**
 * Resumable chunked uploads (packages and SQL dumps) into plugin storage.
 *
 * Each upload lives in tmp/uploads/<id>.part with a JSON state file. Chunks
 * must arrive at the current offset; a repeated chunk (retry after a network
 * error) is accepted idempotently. Optional per-chunk SHA-256 is verified.
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

use WSTM\Core\WstmException;

defined( 'ABSPATH' ) || exit;

/**
 * Upload manager.
 */
final class UploadManager {

	public const EXT_RE = '/\.(wpmig|sql|sql\.gz)$/i';

	/**
	 * @var TempStorage
	 */
	private TempStorage $storage;

	/**
	 * Constructor.
	 *
	 * @param TempStorage $storage Storage.
	 */
	public function __construct( TempStorage $storage ) {
		$this->storage = $storage;
	}

	/** Upload directory. */
	private function dir(): string {
		$d = $this->storage->area( 'tmp' ) . '/uploads';
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
		}
		$this->storage->protect( $d );
		return $d;
	}

	/**
	 * Validate id.
	 *
	 * @param string $id Upload id.
	 * @throws WstmException If invalid/unknown.
	 */
	private function state_path( string $id ): string {
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $id ) ) {
			throw new WstmException( 'bad_upload', 'Invalid upload id.' );
		}
		return $this->dir() . '/' . $id . '.json';
	}

	/**
	 * Load state.
	 *
	 * @param string $id Upload id.
	 * @throws WstmException If missing.
	 */
	public function get( string $id ): array {
		$p = $this->state_path( $id );
		$s = is_file( $p ) ? json_decode( (string) file_get_contents( $p ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $s ) ) {
			throw new WstmException( 'upload_missing', 'Upload not found or expired.', array( 'action' => 'Start the upload again.' ) );
		}
		clearstatcache( true, $s['part'] );
		$s['received'] = is_file( $s['part'] ) ? (int) filesize( $s['part'] ) : 0;
		return $s;
	}

	/**
	 * Start (or resume) an upload.
	 *
	 * @param string $name          Original file name.
	 * @param int    $size          Total bytes.
	 * @param string $fingerprint   Client fingerprint (name+size+mtime) used to resume.
	 * @param bool   $allow_unknown Proceed if free disk space is unknown.
	 * @throws WstmException On invalid input.
	 */
	public function start( string $name, int $size, string $fingerprint, bool $allow_unknown = false ): array {
		$name = sanitize_file_name( $name );
		if ( ! preg_match( self::EXT_RE, $name ) ) {
			throw new WstmException( 'bad_type', 'Only .wpmig, .sql and .sql.gz files can be uploaded.' );
		}
		if ( $size < 1 ) {
			throw new WstmException( 'bad_size', 'The file is empty.' );
		}
		$fp = hash( 'sha256', $fingerprint . '|' . $name . '|' . $size );
		foreach ( glob( $this->dir() . '/*.json' ) ?: array() as $f ) {
			$s = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( is_array( $s ) && ( $s['fp'] ?? '' ) === $fp ) {
				return $this->get( $s['id'] );
			}
		}
		DiskSpace::require( $this->storage, array( 'Upload' => $size ), $allow_unknown );
		$id = bin2hex( random_bytes( 16 ) );
		$s  = array(
			'id'      => $id,
			'name'    => $name,
			'size'    => $size,
			'fp'      => $fp,
			'part'    => $this->dir() . '/' . $id . '.part',
			'created' => time(),
		);
		touch( $s['part'] );
		file_put_contents( $this->state_path( $id ), wp_json_encode( $s ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $this->get( $id );
	}

	/**
	 * Append a chunk.
	 *
	 * @param string      $id     Upload id.
	 * @param int         $offset Byte offset of this chunk.
	 * @param string      $data   Chunk bytes.
	 * @param string|null $sha256 Expected chunk SHA-256.
	 * @throws WstmException On offset/checksum problems.
	 */
	public function chunk( string $id, int $offset, string $data, ?string $sha256 ): array {
		$s = $this->get( $id );
		if ( $sha256 && ! hash_equals( strtolower( $sha256 ), hash( 'sha256', $data ) ) ) {
			throw new WstmException( 'chunk_checksum', 'Chunk checksum mismatch (corrupted in transit).', array( 'resumable' => true, 'action' => 'The chunk will be retried.' ) );
		}
		if ( $offset + strlen( $data ) > $s['size'] ) {
			throw new WstmException( 'chunk_overflow', 'Chunk exceeds the declared file size.' );
		}
		if ( $offset > $s['received'] ) {
			throw new WstmException( 'chunk_gap', 'Chunk offset is ahead of received data.', array( 'data' => array( 'received' => $s['received'] ), 'resumable' => true ) );
		}
		if ( $offset + strlen( $data ) <= $s['received'] ) {
			return $s; // Duplicate (retry) — already stored.
		}
		$fh = fopen( $s['part'], 'c+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh || ! ftruncate( $fh, $offset ) || 0 !== fseek( $fh, $offset ) || fwrite( $fh, $data ) !== strlen( $data ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $fh ) {
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
			throw new WstmException( 'write_failed', 'Could not store the uploaded chunk (disk full?).', array( 'resumable' => true ) );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $this->get( $id );
	}

	/**
	 * Complete: move into the packages area under a unique name.
	 *
	 * @param string $id Upload id.
	 * @throws WstmException If incomplete.
	 */
	public function finish( string $id ): array {
		$s = $this->get( $id );
		if ( $s['received'] !== (int) $s['size'] ) {
			throw new WstmException( 'upload_incomplete', 'The upload is incomplete.', array( 'why' => sprintf( '%d of %d bytes received', $s['received'], $s['size'] ), 'resumable' => true ) );
		}
		$dir  = $this->storage->area( 'packages' );
		$name = $s['name'];
		$base = preg_replace( self::EXT_RE, '', $name );
		$ext  = substr( $name, strlen( $base ) );
		$i    = 1;
		while ( file_exists( $dir . '/' . $name ) ) {
			$name = $base . '-' . ( $i++ ) . $ext;
		}
		if ( ! rename( $s['part'], $dir . '/' . $name ) ) {
			throw new WstmException( 'io_error', 'Could not move the uploaded file into storage.', array( 'resumable' => true ) );
		}
		wp_delete_file( $this->state_path( $id ) );
		return array( 'file' => $name, 'size' => (int) $s['size'] );
	}

	/**
	 * Abort and delete.
	 *
	 * @param string $id Upload id.
	 */
	public function abort( string $id ): void {
		$s = $this->get( $id );
		wp_delete_file( $s['part'] );
		wp_delete_file( $this->state_path( $id ) );
	}

	/**
	 * Remove uploads idle longer than $age seconds.
	 *
	 * @param int $age Seconds.
	 */
	public function purge( int $age ): int {
		$n = 0;
		foreach ( glob( $this->dir() . '/*.json' ) ?: array() as $f ) {
			$s = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$t = is_array( $s ) && is_file( $s['part'] ?? '' ) ? filemtime( $s['part'] ) : filemtime( $f );
			if ( $t < time() - $age ) {
				if ( is_array( $s ) && ! empty( $s['part'] ) && is_file( $s['part'] ) ) {
					wp_delete_file( $s['part'] );
				}
				wp_delete_file( $f );
				++$n;
			}
		}
		return $n;
	}
}
