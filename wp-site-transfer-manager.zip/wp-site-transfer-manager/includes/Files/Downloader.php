<?php
/**
 * Streaming file download with HTTP Range support (never loads the file into memory).
 *
 * @package WSTM\Files
 */

namespace WSTM\Files;

defined( 'ABSPATH' ) || exit;

/**
 * Downloader.
 */
final class Downloader {

	private const CHUNK = 1048576;

	/**
	 * Stream a file to the client. Caller must have authorised the request.
	 *
	 * @param string $path Absolute path (already validated).
	 * @param string $name Download filename.
	 */
	public static function stream( string $path, string $name ): void {
		clearstatcache( true, $path );
		$size = (int) filesize( $path );
		$fh   = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $fh ) {
			status_header( 404 );
			return;
		}
		$start = 0;
		$end   = $size - 1;

		$range = isset( $_SERVER['HTTP_RANGE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_RANGE'] ) ) : '';
		if ( $range && preg_match( '/^bytes=(\d*)-(\d*)$/', $range, $m ) && ( '' !== $m[1] || '' !== $m[2] ) ) {
			if ( '' === $m[1] ) {
				$start = max( 0, $size - (int) $m[2] );
			} else {
				$start = (int) $m[1];
				$end   = '' === $m[2] ? $end : min( $end, (int) $m[2] );
			}
			if ( $start > $end || $start >= $size ) {
				status_header( 416 );
				header( 'Content-Range: bytes */' . $size );
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				return;
			}
			status_header( 206 );
			header( sprintf( 'Content-Range: bytes %d-%d/%d', $start, $end, $size ) );
		} else {
			status_header( 200 );
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $name ) . '"' );
		header( 'Content-Length: ' . ( $end - $start + 1 ) );
		header( 'Accept-Ranges: bytes' );
		header( 'X-Content-Type-Options: nosniff' );

		fseek( $fh, $start );
		$left = $end - $start + 1;
		while ( $left > 0 && ! feof( $fh ) && ! connection_aborted() ) {
			$buf = fread( $fh, (int) min( self::CHUNK, $left ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( false === $buf ) {
				break;
			}
			echo $buf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary file stream.
			$left -= strlen( $buf );
			flush();
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
}
