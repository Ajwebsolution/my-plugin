<?php
/**
 * Uninstall routine.
 *
 * - Always: remove options, transients, scheduled events, capability, temp files.
 * - Only if "Remove plugin database tables on uninstall" is enabled: drop tables.
 * - Never: delete website files, backups or packages.
 *
 * @package WSTM
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

define( 'WSTM_PATH', plugin_dir_path( __FILE__ ) );
if ( ! defined( 'WSTM_DB_VERSION' ) ) {
	define( 'WSTM_DB_VERSION', '2' );
}

require_once WSTM_PATH . 'includes/compat.php';
require_once WSTM_PATH . 'includes/Core/Autoloader.php';
\WSTM\Core\Autoloader::register( 'WSTM\\', WSTM_PATH . 'includes/' );

$wstm_settings = get_site_option( 'wstm_settings', array() );
$wstm_drop     = is_array( $wstm_settings ) && ! empty( $wstm_settings['uninstall_cleanup'] );

// Scheduled jobs.
wp_clear_scheduled_hook( 'wstm_cleanup_cron' );

// Temporary files only (tmp area). Backups/packages are preserved.
try {
	$wstm_storage = new \WSTM\Files\TempStorage( new \WSTM\Core\Settings() );
	$wstm_tmp     = $wstm_storage->root() . '/tmp';
	if ( is_dir( $wstm_tmp ) ) {
		$wstm_storage->delete_dir( $wstm_tmp );
	}
} catch ( \Throwable $e ) {
	// Never fail uninstall because of temp cleanup.
	unset( $e );
}

// Capability.
\WSTM\Core\Capabilities::revoke_all();

// Tables (opt-in).
if ( $wstm_drop ) {
	\WSTM\Database\Schema::drop();
}

// Options & transients. Storage dirname is kept so remaining backups stay findable after reinstall.
delete_site_option( 'wstm_settings' );
delete_site_transient( 'wstm_diagnostics' );
delete_option( 'wstm_cloud' ); // Encrypted cloud credentials. Remote backups themselves are never touched.
wp_clear_scheduled_hook( 'wstm_scheduled_backup' );
if ( $wstm_drop ) {
	delete_site_option( 'wstm_db_version' );
}
