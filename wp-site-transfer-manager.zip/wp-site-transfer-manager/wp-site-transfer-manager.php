<?php
/**
 * Plugin Name:       WP Site Transfer Manager
 * Description:       Professional, dependency-free WordPress migration, backup, restore and site-transfer system.
 * Version:           1.0.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            WP Site Transfer Manager
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-site-transfer-manager
 * Domain Path:       /languages
 * Network:           true
 *
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;

define( 'WSTM_VERSION', '1.0.1' );
define( 'WSTM_DB_VERSION', '2' );
define( 'WSTM_FILE', __FILE__ );
define( 'WSTM_PATH', plugin_dir_path( __FILE__ ) );
define( 'WSTM_URL', plugin_dir_url( __FILE__ ) );
define( 'WSTM_BASENAME', plugin_basename( __FILE__ ) );
define( 'WSTM_MIN_PHP', '7.4' );
define( 'WSTM_MIN_WP', '6.0' );

if ( version_compare( PHP_VERSION, WSTM_MIN_PHP, '<' ) ) {
	add_action(
		'admin_notices',
		static function () {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: required PHP version, 2: current PHP version. */
						__( 'WP Site Transfer Manager requires PHP %1$s or newer. You are running %2$s.', 'wp-site-transfer-manager' ),
						WSTM_MIN_PHP,
						PHP_VERSION
					)
				)
			);
		}
	);
	return;
}

require_once WSTM_PATH . 'includes/compat.php';
require_once WSTM_PATH . 'includes/Core/Autoloader.php';
\WSTM\Core\Autoloader::register( 'WSTM\\', WSTM_PATH . 'includes/' );

register_activation_hook( __FILE__, array( \WSTM\Core\Activator::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( \WSTM\Core\Deactivator::class, 'deactivate' ) );

add_action( 'plugins_loaded', array( \WSTM\Core\Plugin::class, 'instance' ) );
