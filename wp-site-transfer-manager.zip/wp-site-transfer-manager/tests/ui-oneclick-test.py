import re, json
from playwright.sync_api import sync_playwright, expect
SRC, DST = "http://127.0.0.1:8099", "http://127.0.0.1:8098"
ok = bad = 0
def check(n, c, x=""):
    global ok, bad
    if c: ok += 1; print("  ✓", n)
    else: bad += 1; print("  ✕", n, x)
errs = []
def login(pg, base, pw):
    pg.goto(base + "/wp-login.php"); pg.fill("#user_login", "admin"); pg.fill("#user_pass", pw); pg.click("#wp-submit"); pg.wait_for_url(re.compile("wp-admin"))
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(accept_downloads=True, viewport={"width": 1300, "height": 950})
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errs.append(str(e)))
    print("Source site: one-click export")
    login(pg, SRC, "pw")
    pg.evaluate("""() => fetch(WSTM.restRoot.replace('wstm/v1/','wp/v2/posts'), {method:'POST', credentials:'same-origin', headers:{'X-WP-Nonce':WSTM.nonce,'Content-Type':'application/json'}, body: JSON.stringify({title:'Moved post', status:'publish', content:'<a href="http://127.0.0.1:8099/hello">link</a>'})})""") if False else None
    pg.goto(SRC + "/wp-admin/admin.php?page=wstm-export")
    pg.evaluate("""() => fetch(WSTM.restUrl ? '' : '', {})""") if False else None
    pg.evaluate("""async () => { const u = WSTMAdmin.restUrl('').replace('wstm/v1/','wp/v2/posts'); await fetch(u, {method:'POST', credentials:'same-origin', headers:{'X-WP-Nonce':WSTM.nonce,'Content-Type':'application/json'}, body: JSON.stringify({title:'Moved post', status:'publish', content:'<a href="http://127.0.0.1:8099/hello">link</a>'})}); }""")
    pg.screenshot(path="/tmp/claude-0/ui/simple-export-before.png", full_page=True)
    with pg.expect_download(timeout=300000) as dl:
        pg.click("#wstm-mig-export")
    d = dl.value
    path = "/tmp/claude-0/ui/" + d.suggested_filename
    d.save_as(path)
    check("export finished and file auto-downloaded", path.endswith(".wpmig"), path)
    pg.wait_for_selector(".wstm-run.is-done")
    pg.screenshot(path="/tmp/claude-0/ui/simple-export-done.png", full_page=True)
    check("download button shown", pg.locator(".wstm-run__actions a.button-hero").count() == 1)

    print("Destination site: drag & drop import")
    pg2 = ctx.new_page(); pg2.on("pageerror", lambda e: errs.append(str(e)))
    login(pg2, DST, "destpw")
    pg2.goto(DST + "/wp-admin/admin.php?page=wstm-import")
    pg2.screenshot(path="/tmp/claude-0/ui/simple-import-before.png", full_page=True)
    pg2.set_input_files("#wstm-drop-input", path)
    pg2.on("console", lambda m: print("   CONSOLE", m.text[:200]) if "JQMIGRATE" not in m.text else None)
    try:
        expect(pg2.locator("#wstm-confirm-modal")).to_be_visible(timeout=120000)
    except Exception:
        print("   STATE:", pg2.locator(".wstm-run").inner_text()[:600].replace("\n"," | "))
        pg2.screenshot(path="/tmp/claude-0/ui/fail80.png", full_page=True)
        raise
    check("confirm shown after upload", True)
    pg2.check("#wstm-modal-ack"); pg2.click("[data-wstm-modal=continue]")
    pg2.wait_for_selector(".wstm-run.is-done, .wstm-run.is-failed", timeout=600000)
    pg2.screenshot(path="/tmp/claude-0/ui/simple-import-done.png", full_page=True)
    check("import completed (survives user-table switch)", pg2.locator(".wstm-run.is-done").count() == 1, pg2.inner_text(".wstm-run"))
    check("log-in button points to destination", pg2.locator(".wstm-run__actions a").get_attribute("href").startswith(DST))
    pg2.goto(DST + "/wp-login.php", wait_until="domcontentloaded")
    pg2.fill("#user_login", "admin"); pg2.fill("#user_pass", "pw"); pg2.click("#wp-submit")
    pg2.wait_for_url(re.compile("wp-admin"), timeout=60000, wait_until="domcontentloaded")
    check("log in on destination with SOURCE credentials", "wp-admin" in pg2.url)
    pg2.goto(DST + "/?s=Moved+post", wait_until="domcontentloaded")
    html = pg2.content()
    check("source post visible on destination with destination URLs", "Moved post" in html)
    pg2.goto(DST + "/wp-admin/admin.php?page=wstm", wait_until="domcontentloaded")
    check("plugin still works on destination after import", pg2.locator(".wstm-wrap").count() == 1)
    body = pg2.evaluate("""async () => { const r = await fetch(WSTMAdmin.restUrl('').replace('wstm/v1/','wp/v2/posts') + '&search=Moved%20post&context=edit', {credentials:'same-origin', headers:{'X-WP-Nonce':WSTM.nonce}}); const j = await r.json(); return j[0] ? j[0].content.raw : JSON.stringify(j); }""")
    check("links rewritten 8099 → 8098", "127.0.0.1:8098/hello" in body and "8099" not in body, body)
    check("no JavaScript page errors", not errs, json.dumps(errs[:3]))
    b.close()
print(f"\n{ok} passed, {bad} failed")
