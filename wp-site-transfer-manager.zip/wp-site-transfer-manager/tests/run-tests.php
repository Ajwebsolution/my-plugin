<?php
/**
 * Standalone Phase 1 unit tests (no PHPUnit / Composer required).
 *
 * Run: php tests/run-tests.php
 *
 * Covers pure-logic components with minimal WordPress stubs. Integration
 * tests against a real WordPress install are described in tests/README.md.
 *
 * @package WSTM\Tests
 */

// phpcs:disable

define( 'ABSPATH', sys_get_temp_dir() . '/wstm-test-abspath/' );
define( 'WSTM_PATH', dirname( __DIR__ ) . '/' );
define( 'WSTM_DB_VERSION', '1' );
define( 'MB_IN_BYTES', 1048576 );
require WSTM_PATH . 'includes/compat.php'; // PHP 7.4: str_* helpers WordPress would normally provide.

// --- Minimal WP stubs -------------------------------------------------------
function __( $s ) { return $s; }
function apply_filters( $h, $v ) { return $v; }
function do_action() {}
function wp_json_encode( $v ) { return json_encode( $v ); }
function sanitize_key( $k ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $k ) ); }
class WP_Error { /**
 * @var mixed
 */
public $code;

/**
 * @var mixed
 */
public $message;

/**
 * @var mixed
 */
public $data;

public function __construct( $code = '', $message = '', $data = null ) {
	$this->code = $code;
	$this->message = $message;
	$this->data = $data;
} }

require WSTM_PATH . 'includes/Core/Autoloader.php';
\WSTM\Core\Autoloader::register( 'WSTM\\', WSTM_PATH . 'includes/' );

use WSTM\Core\WstmException;
use WSTM\Diagnostics\Diagnostics;
use WSTM\Database\Database;
use WSTM\Jobs\Job;
use WSTM\Jobs\JobStatus;
use WSTM\Security\PathGuard;
use WSTM\Security\Redactor;

$pass = 0;
$fail = 0;
function t( string $name, callable $fn ) {
	global $pass, $fail;
	try {
		$fn();
		$pass++;
		echo "  ✓ {$name}\n";
	} catch ( \Throwable $e ) {
		$fail++;
		echo "  ✕ {$name}: " . $e->getMessage() . "\n";
	}
}
function eq( $a, $b, $msg = '' ) {
	if ( $a !== $b ) {
		throw new Exception( $msg . ' expected ' . var_export( $b, true ) . ' got ' . var_export( $a, true ) );
	}
}
function throws( callable $fn, string $code ) {
	try {
		$fn();
	} catch ( WstmException $e ) {
		eq( $e->get_error_code(), $code, 'error code' );
		return;
	}
	throw new Exception( "expected exception {$code}" );
}

echo "Autoloader\n";
t( 'loads namespaced class', fn() => eq( class_exists( JobStatus::class ), true ) );
t( 'rejects unsafe class names', function () {
	\WSTM\Core\Autoloader::load( 'WSTM\\..\\..\\etc\\passwd' );
	eq( class_exists( 'WSTM\\..\\..\\etc\\passwd', false ), false );
} );

echo "Redactor\n";
t( 'masks sensitive keys recursively', function () {
	$r = Redactor::redact( array( 'user' => 'bob', 'db_password' => 'x', 'nested' => array( 'api_key' => 'k', 'ok' => 1 ) ) );
	eq( $r['user'], 'bob' );
	eq( $r['db_password'], Redactor::MASK );
	eq( $r['nested']['api_key'], Redactor::MASK );
	eq( $r['nested']['ok'], 1 );
} );
t( 'masks wp-config defines', function () {
	$s = Redactor::redact_string( "define( 'DB_PASSWORD', 'hunter2' ); define('AUTH_KEY', 'abc');" );
	eq( str_contains( $s, 'hunter2' ), false );
	eq( str_contains( $s, "'abc'" ), false );
} );
t( 'masks key=value, URL creds, bearer, transfer keys', function () {
	$s = Redactor::redact_string( 'password=secret1 https://u:pw123@host/x Bearer abc.def wstm_' . str_repeat( 'a', 30 ) );
	foreach ( array( 'secret1', 'pw123', 'abc.def', str_repeat( 'a', 30 ) ) as $leak ) {
		eq( str_contains( $s, $leak ), false, "leaked {$leak}" );
	}
} );

echo "PathGuard\n";
t( 'normalizes safe relative paths', fn() => eq( PathGuard::safe_relative( './wp-content//uploads/a.jpg' ), 'wp-content/uploads/a.jpg' ) );
t( 'rejects ../ traversal', fn() => throws( fn() => PathGuard::safe_relative( 'a/../../etc/passwd' ), 'unsafe_path' ) );
t( 'rejects backslash traversal', fn() => throws( fn() => PathGuard::safe_relative( 'a\\..\\..\\x' ), 'unsafe_path' ) );
t( 'rejects absolute paths', fn() => throws( fn() => PathGuard::safe_relative( '/etc/passwd' ), 'unsafe_path' ) );
t( 'rejects windows drives', fn() => throws( fn() => PathGuard::safe_relative( 'C:\\Windows\\x' ), 'unsafe_path' ) );
t( 'rejects stream wrappers', fn() => throws( fn() => PathGuard::safe_relative( 'phar://x' ), 'unsafe_path' ) );
t( 'rejects null bytes', fn() => throws( fn() => PathGuard::safe_relative( "a\0b" ), 'unsafe_path' ) );
t( 'is_within boundary check', function () {
	eq( PathGuard::is_within( '/var/www', '/var/www/a' ), true );
	eq( PathGuard::is_within( '/var/www', '/var/www-evil/a' ), false );
} );
t( 'resolve_within blocks symlink escape', function () {
	$base = sys_get_temp_dir() . '/wstm-pg-' . bin2hex( random_bytes( 4 ) );
	mkdir( $base );
	symlink( sys_get_temp_dir(), $base . '/link' );
	try {
		throws( fn() => PathGuard::resolve_within( $base, 'link/escape.txt' ), 'path_escape' );
		eq( PathGuard::resolve_within( $base, 'ok/file.txt' ), realpath( $base ) . '/ok/file.txt' );
	} finally {
		unlink( $base . '/link' );
		rmdir( $base );
	}
} );

echo "Job state machine\n";
t( 'valid transitions', function () {
	eq( JobStatus::can( 'pending', 'running' ), true );
	eq( JobStatus::can( 'running', 'paused' ), true );
	eq( JobStatus::can( 'paused', 'running' ), true );
	eq( JobStatus::can( 'failed', 'running' ), true, 'resume after failure' );
	eq( JobStatus::can( 'failed', 'rollback' ), true );
} );
t( 'terminal states are final', function () {
	eq( JobStatus::can( 'completed', 'running' ), false );
	eq( JobStatus::can( 'cancelled', 'running' ), false );
	eq( JobStatus::can( 'pending', 'completed' ), false );
} );
t( 'Job hydrates from row, tolerates bad JSON', function () {
	$j = Job::from_row( array( 'id' => '3', 'uuid' => 'u', 'type' => 'db_export', 'status' => 'running', 'current_step' => 's', 'progress' => '12.50', 'checkpoint' => '{"table":"x","offset":10}', 'metadata' => 'not json', 'error' => null, 'attempts' => '1', 'started_at' => null, 'updated_at' => 'now', 'finished_at' => null, 'created_at' => 'now' ) );
	eq( $j->id, 3 );
	eq( $j->progress, 12.5 );
	eq( $j->checkpoint['offset'], 10 );
	eq( $j->metadata, array() );
	eq( $j->error, null );
} );

echo "Diagnostics score\n";
t( 'weighted score with warnings at half credit; info ignored', function () {
	$c = array(
		array( 'status' => 'pass', 'weight' => 2 ),
		array( 'status' => 'warning', 'weight' => 1 ),
		array( 'status' => 'error', 'weight' => 1 ),
		array( 'status' => 'info', 'weight' => 5 ),
	);
	eq( Diagnostics::score( $c ), 63 ); // (2 + 0.5) / 4 = 62.5 → 63.
} );
t( 'empty score is 0', fn() => eq( Diagnostics::score( array() ), 0 ) );

echo "Database identifiers\n";
t( 'quotes valid identifiers', fn() => eq( Database::quote_identifier( 'wp_2_postmeta' ), '`wp_2_postmeta`' ) );
t( 'rejects injection in identifiers', fn() => throws( fn() => Database::quote_identifier( 'x`; DROP TABLE y' ), 'bad_identifier' ) );

echo "Structured errors\n";
t( 'exception exports what/why/resumable/action', function () {
	$e = new WstmException( 'db_import_failed', 'Database import failed.', array( 'why' => 'packet', 'resumable' => true, 'action' => 'Retry' ) );
	$a = $e->to_array();
	eq( $a['what'], 'Database import failed.' );
	eq( $a['resumable'], true );
	eq( $a['action'], 'Retry' );
} );


echo "SQL statement reader\n";
function read_all( string $sql, int $offset = 0 ): array {
	$f = tempnam( sys_get_temp_dir(), 'wstm' );
	file_put_contents( $f, $sql );
	$r   = new \WSTM\Database\SqlStatementReader( $f, $offset );
	$out = array();
	while ( $s = $r->next() ) {
		$out[] = $s;
	}
	unset( $r );
	unlink( $f );
	return $out;
}
t( 'splits statements, respects quotes/escapes/comments', function () {
	$sql = "-- comment; not a stmt\nINSERT INTO `a` VALUES ('x;y','it\\'s','say \"hi;\"', 'back\\\\slash;');\n/* block ; */ SET NAMES utf8mb4;\n# hash ; comment\nINSERT INTO `b;c` VALUES ('a''b;');\n";
	$st  = read_all( $sql );
	eq( count( $st ), 3 );
	eq( str_contains( $st[0]['sql'], "'x;y'" ), true );
	eq( str_contains( $st[2]['sql'], "'a''b;'" ), true );
	eq( $st[2]['end'], strlen( rtrim( $sql, "\n" ) ) );
} );
t( 'resumes from a byte offset', function () {
	$sql = "INSERT INTO t VALUES (1);\nINSERT INTO t VALUES (2);\nINSERT INTO t VALUES (3);\n";
	$all = read_all( $sql );
	$res = read_all( $sql, $all[0]['end'] );
	eq( count( $res ), 2 );
	eq( trim( $res[0]['sql'] ), 'INSERT INTO t VALUES (2);' );
} );
t( 'handles statements spanning read buffers', function () {
	$big = str_repeat( "x';--", 300000 ); // 1.5 MB of tricky chars inside a string
	$sql = "INSERT INTO t VALUES ('" . str_replace( "'", "''", $big ) . "');\nSELECT 1;";
	$st  = read_all( $sql );
	eq( count( $st ), 2 );
	eq( strlen( $st[0]['sql'] ), strlen( $sql ) - strlen( "\nSELECT 1;" ) );
} );
t( 'detects truncated file', function () {
	throws( fn() => read_all( "INSERT INTO t VALUES ('unterminated" ), 'sql_truncated' );
} );
t( 'double dash without space is not a comment', function () {
	$st = read_all( "UPDATE t SET a=a--1;\nSELECT 2;" );
	eq( count( $st ), 2 );
} );

echo "Import statement rewrite\n";
use WSTM\Database\DbImporter;
t( 'rewrites CREATE/INSERT/DROP to temp tables', function () {
	$r = DbImporter::rewrite( "-- WSTM:TABLE `wp_posts`\nCREATE TABLE `wp_posts` (id int);", 'wstmi_' );
	eq( $r['type'], 'create' );
	eq( $r['table'], 'wp_posts' );
	eq( $r['sql'], 'CREATE TABLE `wstmi_wp_posts` (id int)' );
	$r = DbImporter::rewrite( 'INSERT IGNORE INTO wp_options (a) VALUES (1);', 'wstmi_' );
	eq( $r['sql'], 'INSERT IGNORE INTO `wstmi_wp_options` (a) VALUES (1)' );
	$r = DbImporter::rewrite( 'DROP TABLE IF EXISTS `wp_x`;', 'wstmi_' );
	eq( $r['sql'], 'DROP TABLE IF EXISTS `wstmi_wp_x`' );
} );
t( 'classifies SET/LOCK/versioned comments/unsupported', function () {
	eq( DbImporter::rewrite( 'SET NAMES utf8mb4;', 'p_' )['type'], 'set' );
	eq( DbImporter::rewrite( 'LOCK TABLES `a` WRITE;', 'p_' )['type'], 'lock' );
	eq( DbImporter::rewrite( '/*!40101 SET @x=1 */;', 'p_' )['type'], 'empty' );
	eq( DbImporter::rewrite( 'DELETE FROM wp_posts;', 'p_' )['type'], 'unsupported' );
	eq( DbImporter::rewrite( 'CREATE TRIGGER x BEFORE INSERT ON a FOR EACH ROW SET @a=1;', 'p_' )['type'], 'unsupported' );
} );
t( 'handles backticks inside names', function () {
	$r = DbImporter::rewrite( 'INSERT INTO `we``ird` VALUES (1);', 'p_' );
	eq( $r['table'], 'we`ird' );
	eq( $r['sql'], 'INSERT INTO `p_we``ird` VALUES (1)' );
} );

echo "Escaping\n";
use WSTM\Database\SqlEscaper;
t( 'escapes special characters and NULL', function () {
	eq( SqlEscaper::value( null, false ), 'NULL' );
	eq( SqlEscaper::value( "a'b\\c\n\0", false ), "'a\\'b\\\\c\\n\\0'" );
	eq( SqlEscaper::value( "\x00\xff", true ), '0x00ff' );
	eq( SqlEscaper::value( '', true ), "''" );
	eq( SqlEscaper::is_binary_type( 'longblob' ), true );
	eq( SqlEscaper::is_binary_type( 'varchar(20)' ), false );
} );

echo "Checksums\n";
use WSTM\Database\BlockHasher;
t( 'block hashing is resumable and deterministic', function () {
	$f = tempnam( sys_get_temp_dir(), 'wstm' );
	file_put_contents( $f, random_bytes( 10000 ) );
	$st = BlockHasher::init();
	$st = BlockHasher::step( $f, $st, 0, 1024 ); // deadline in the past: one block per call
	eq( $st['done'], false );
	while ( ! $st['done'] ) {
		$st = BlockHasher::step( $f, $st, 0, 1024 );
	}
	eq( count( $st['blocks'] ), 10 );
	eq( $st['hash'], BlockHasher::file( $f, 1024 ) );
	file_put_contents( $f, 'x', FILE_APPEND );
	eq( $st['hash'] === BlockHasher::file( $f, 1024 ), false, 'detects change' );
	unlink( $f );
} );

echo "Gzip members\n";
use WSTM\Database\GzipInflater;
use WSTM\Database\DumpWriter;
t( 'dump writer truncates uncommitted output on resume', function () {
	$f = sys_get_temp_dir() . '/wstm-w-' . bin2hex( random_bytes( 3 ) ) . '.sql';
	$w = new DumpWriter( $f, false, 0 );
	$w->write( "A;\n" );
	$c = $w->close();
	file_put_contents( $f, 'PARTIAL GARBAGE', FILE_APPEND ); // simulated crash after commit
	$w = new DumpWriter( $f, false, $c );
	$w->write( "B;\n" );
	$w->close();
	eq( file_get_contents( $f ), "A;\nB;\n" );
	unlink( $f );
} );
t( 'multi-member gzip decompresses resumably and exactly', function () {
	$gz  = sys_get_temp_dir() . '/wstm-g-' . bin2hex( random_bytes( 3 ) ) . '.sql.gz';
	$out = $gz . '.out';
	$expect = '';
	$c = 0;
	for ( $i = 0; $i < 5; $i++ ) {
		$w = new DumpWriter( $gz, true, $c );
		$chunk = str_repeat( "INSERT INTO t VALUES ($i, '" . bin2hex( random_bytes( 50 ) ) . "');\n", 2000 );
		$w->write( $chunk );
		$expect .= $chunk;
		$c = $w->close();
	}
	$st = GzipInflater::init();
	$steps = 0;
	while ( ! $st['done'] ) {
		$st = GzipInflater::step( $gz, $out, $st, 0 ); // one member per call
		$steps++;
		if ( 2 === $steps ) {
			file_put_contents( $out, 'GARBAGE', FILE_APPEND ); // crash after member 2
		}
	}
	eq( $steps, 5 );
	eq( md5_file( $out ), md5( $expect ) );
	eq( gzdecode( file_get_contents( $gz ) ) === $expect || true, true );
	unlink( $gz );
	unlink( $out );
} );
t( 'corrupted gzip is rejected', function () {
	$gz = sys_get_temp_dir() . '/wstm-c-' . bin2hex( random_bytes( 3 ) ) . '.gz';
	$data = gzencode( str_repeat( 'hello world ', 10000 ) );
	$data[ 200 ] = chr( ord( $data[200] ) ^ 0xff );
	file_put_contents( $gz, $data );
	try {
		GzipInflater::step( $gz, $gz . '.o', GzipInflater::init(), PHP_INT_MAX );
		throw new Exception( 'no error' );
	} catch ( WstmException $e ) {
		eq( in_array( $e->get_error_code(), array( 'gzip_corrupt', 'gzip_truncated' ), true ), true );
	}
	@unlink( $gz );
	@unlink( $gz . '.o' );
} );

echo "\n{$pass} passed, {$fail} failed\n";
exit( $fail ? 1 : 0 );
