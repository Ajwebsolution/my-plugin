import re, sys, time, glob, json
from playwright.sync_api import sync_playwright, expect
BASE = "http://127.0.0.1:8099"
ok = bad = 0
def check(name, cond, extra=""):
    global ok, bad
    if cond: ok += 1; print("  ✓", name)
    else: bad += 1; print("  ✕", name, extra)
errors = []
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1400, "height": 1000})
    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.goto(BASE + "/wp-login.php")
    pg.fill("#user_login", "admin"); pg.fill("#user_pass", "pw"); pg.click("#wp-submit")
    pg.wait_for_url(re.compile("wp-admin"))
    adm = BASE + "/wp-admin/admin.php?page="

    print("Dashboard / diagnostics / logs / settings")
    for slug in ["wstm", "wstm-diagnostics", "wstm-logs", "wstm-settings"]:
        pg.goto(adm + slug); check(f"{slug} renders", pg.locator(".wstm-wrap").count() == 1)
    pg.goto(adm + "wstm"); check('dashboard rendered once', pg.locator('.wstm-wrap').count() == 1); pg.screenshot(path="/tmp/claude-0/ui/dashboard.png", full_page=True)

    print("Export page: package")
    pg.goto(adm + "wstm-export")
    pg.wait_for_selector("#wstm-table-picker .wstm-tbl")
    for comp in ["themes", "core", "root"]:
        pg.locator(f"#wstm-components input[value={comp}]").uncheck()
    pg.click("#wstm-start-package")
    pg.wait_for_selector("#wstm-monitor:not([hidden])")
    pg.wait_for_function("document.querySelector('#wstm-monitor').innerText.includes('completed')", timeout=180000)
    check("package created via UI", "Package created and sealed" in pg.inner_text("#wstm-monitor"))
    pg.screenshot(path="/tmp/claude-0/ui/export.png", full_page=True)
    pg.wait_for_selector("#wstm-packages table")
    pkgname = pg.locator("#wstm-packages tbody tr code").first.inner_text()
    check("package listed with verified tick", pg.locator("#wstm-packages tbody tr .wstm-badge--success").count() >= 1)
    pg.locator("#wstm-packages [data-validate]").first.click()
    pg.wait_for_function("document.querySelector('#wstm-monitor').innerText.includes('Package is valid')", timeout=120000)
    check("validate via UI", True)

    print("Export page: database dump")
    pg.click("#wstm-start-export")
    pg.wait_for_function("document.querySelector('#wstm-monitor').innerText.includes('Export complete')", timeout=120000)
    check("DB export via UI", True)

    print("Import page: chunked upload of the package")
    pkgpath = glob.glob("/tmp/claude-0/wpt/wpm/wp-content/wstm-storage-*/packages/" + pkgname)
    # The UI site shares the filesystem with other test sites; find this site's copy.
    src = [f for f in glob.glob("/tmp/claude-0/wpt/wpm/wp-content/wstm-storage-*/packages/" + pkgname)][0]
    import shutil; shutil.copy(src, "/tmp/claude-0/ui/upload-test.wpmig")
    pg.goto(adm + "wstm-import")
    pg.set_input_files("#wstm-upload-file", "/tmp/claude-0/ui/upload-test.wpmig")
    pg.click("#wstm-upload-start")
    pg.wait_for_function("document.querySelector('#wstm-upload-progress p').innerText.includes('Uploaded as')", timeout=180000)
    check("upload completed via UI", True)
    pg.wait_for_selector("#wstm-packages code:text('upload-test.wpmig')")
    row = pg.locator("#wstm-packages tbody tr", has_text="upload-test.wpmig")
    row.locator("[data-import]").click()
    expect(pg.locator("#wstm-confirm-modal")).to_be_visible()
    check("confirm modal: Continue disabled until acknowledged", pg.locator("[data-wstm-modal=continue]").is_disabled())
    pg.check("#wstm-modal-ack"); pg.click("[data-wstm-modal=continue]")
    pg.wait_for_function("document.querySelector('#wstm-monitor').innerText.includes('Package verified and imported')", timeout=240000)
    check("package import (DB + staging) via UI", True)
    pg.screenshot(path="/tmp/claude-0/ui/import.png", full_page=True)
    # Session may be replaced by the imported users table (same site here, so still valid).

    print("URL replace page")
    pg.goto(adm + "wstm-url-replace")
    pg.wait_for_selector("#wstm-pairs .wstm-old")
    pg.evaluate("""() => fetch(WSTM.restRoot.replace('wstm/v1/','wp/v2/posts'), {method:'POST', credentials:'same-origin', headers:{'X-WP-Nonce':WSTM.nonce,'Content-Type':'application/json'}, body: JSON.stringify({title:'UI URL', status:'publish', content:'<a href="https://dev.ui-test.com/page">x</a> https://dev.ui-test.com.au'})}).then(r=>r.status)""")
    pg.fill("#wstm-pairs .wstm-old", "https://dev.ui-test.com")
    pg.fill("#wstm-pairs .wstm-new", "https://ui-live.org")
    check("replace disabled before dry run", pg.locator("#wstm-url-replace").is_disabled())
    pg.click("#wstm-url-scan")
    pg.wait_for_selector("#wstm-url-report:not([hidden])", timeout=60000)
    check("scan report shown", "Scan results" in pg.inner_text("#wstm-url-report"))
    pg.click("#wstm-url-dry")
    pg.wait_for_function("document.querySelector('#wstm-url-report').innerText.includes('Dry run')", timeout=60000)
    check("dry run shows sample diff", pg.locator(".wstm-samples ins").count() >= 1)
    check("replace enabled after dry run", pg.locator("#wstm-url-replace").is_enabled())
    pg.click("#wstm-url-replace"); pg.check("#wstm-modal-ack"); pg.click("[data-wstm-modal=continue]")
    pg.wait_for_function("document.querySelector('#wstm-url-report').innerText.includes('Replacement complete')", timeout=120000)
    check("replace via UI", True)
    pg.screenshot(path="/tmp/claude-0/ui/url.png", full_page=True)
    content = pg.evaluate("""() => fetch(WSTM.restRoot.replace('wstm/v1/','wp/v2/posts&search=UI%20URL&context=edit'), {credentials:'same-origin', headers:{'X-WP-Nonce':WSTM.nonce}}).then(r=>r.json()).then(j=>j[0].content.raw)""")
    check("content rewritten, .au untouched", "https://ui-live.org/page" in content and "https://dev.ui-test.com.au" in content, content)

    pg.goto(adm + "wstm-logs"); check("logs page shows entries", pg.locator(".wstm-log-table tbody tr").count() > 3)
    real = [e for e in errors if "favicon" not in e]
    check("no JavaScript errors", not real, json.dumps(real[:5]))
    b.close()
print(f"\n{ok} passed, {bad} failed")
