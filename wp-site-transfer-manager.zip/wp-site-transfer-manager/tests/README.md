# Tests

**Unit (no WordPress needed):** `php tests/run-tests.php`

**Integration (real WordPress, disposable install only):**
`WP_PATH=/path/to/test-wordpress php tests/integration-test.php`
The plugin must be in that install's `wp-content/plugins/`. Covers activation, tables, capabilities,
storage protection, logging/redaction, settings validation, job lifecycle (slicing, failure, resume
from checkpoint, cancel, locking), diagnostics, REST permissions and admin page rendering.
Never run against a production site.

**Phase 2 database engine (MySQL/MariaDB, disposable install only — it drops and rewrites tables):**
`WP_PATH=/path/to/test-wordpress WSTM_DB=dbname php tests/phase2/p2test.php`
Each job slice runs in a separate PHP process to simulate separate HTTP requests. Covers exports with
simulated crashes, low-memory export (64 MB), byte-identical round-trip (CHECKSUM TABLE), BIT/BLOB/JSON/
zero-date/max-BIGINT values, no-PK and composite-PK tables, failed import (max_allowed_packet) with resume,
corrupted/truncated/wrong-prefix/unconfirmed/cancelled imports leaving live data untouched, REST and pages.

## Phases 7–10
- `tests/phase2/p7test.php` – backups (full/incremental/differential), verify, retention, chain restore, undo.
- `tests/phase2/p8test.php` – direct transfer: signed requests, replay/skew/rate limits, pull and push between two live sites.
- `tests/phase2/p9test.php` – health check, cache/permalink/Elementor tools, link audit, migration history, WooCommerce skip filters.
- `tests/phase2/p10test.php` – S3-compatible cloud: SigV4 (AWS test vector), encrypted credentials, multipart upload, ranged download, list/delete. Needs an S3 endpoint at http://127.0.0.1:5055 with bucket `wstm-bkt` (e.g. `moto_server -p 5055`).
- `tests/ui-cloud-tools-test.py` – Playwright: dashboard tools + cloud destination UI.

## PHP versions
Version 1.0.1 supports PHP 7.4 and newer. All suites above (unit, Phase 1 integration, Phases 2–10 and both
browser tests) were run on PHP 7.4.33, 8.0.30 and 8.3.6.
