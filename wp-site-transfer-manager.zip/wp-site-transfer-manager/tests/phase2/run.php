<?php
// One "HTTP request": run a job, print status JSON. argv[2] = budget seconds, 0 = exactly one slice.
require __DIR__ . '/boot.php';
if ( '0' === ( $argv[2] ?? '' ) ) {
	add_filter( 'wstm_job_deadline', static fn() => time() );
}
$job = $P->jobs()->run( (int) $argv[1], (int) ( $argv[2] ?? 2 ) );
echo json_encode( array( 'status' => $job->status, 'progress' => $job->progress, 'step' => $job->current_step, 'error' => $job->error, 'mem' => memory_get_peak_usage( true ) ) ), "\n";
