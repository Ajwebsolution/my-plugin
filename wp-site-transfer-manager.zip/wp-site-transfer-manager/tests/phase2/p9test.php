<?php
// Phase 9 / extras: health check, tools, link audit, history, WooCommerce skip filters.
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function php_run( $code ) { return (string) shell_exec( 'php -r ' . escapeshellarg( 'require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function rest( $method, $route, $params = array(), $user = 1 ) {
	$out = php_run( 'wp_set_current_user(' . $user . '); do_action("rest_api_init"); $r=new WP_REST_Request("' . $method . '","/wstm/v1' . $route . '"); $r->set_body_params(' . var_export( $params, true ) . '); $res=rest_get_server()->dispatch($r); echo "\n@@" . json_encode(array($res->get_status(), $res->get_data()));' );
	return json_decode( substr( $out, strrpos( $out, '@@' ) + 2 ), true );
}
function run_job( $id ) {
	for ( $i = 0; $i < 500; $i++ ) {
		$out = (string) shell_exec( 'php ' . __DIR__ . '/run.php ' . $id . ' 3 2>&1' );
		$st  = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN: $out\n"; return 'crash'; }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st['status']; }
	}
	return 'timeout';
}
$P = \WSTM\Core\Plugin::instance();

echo "Health check\n";
$h = rest( 'GET', '/tools/health' );
check( 'health endpoint 200', 200 === $h[0], json_encode( $h ) );
$checks = $h[1]['checks'] ?? array();
check( 'health has status + checks', in_array( $h[1]['status'] ?? '', array( 'pass', 'warning', 'error' ), true ) && count( $checks ) >= 6 );
$ids = array_column( $checks, 'id' );
check( 'database check passes', 'pass' === ( $checks[ array_search( 'database', $ids, true ) ]['status'] ?? '' ), json_encode( $ids ) );
check( 'subscriber denied', 403 === rest( 'GET', '/tools/health', array(), 0 )[0] || 401 === rest( 'GET', '/tools/health', array(), 0 )[0] );

echo "Tools\n";
set_transient( 'p9_tmp', 'x', 3600 ); set_transient( 'wstm_keep', 'y', 3600 );
$c = rest( 'POST', '/tools/clear-cache' );
check( 'clear-cache ok', 200 === $c[0] && is_string( $c[1]['message'] ) );
wp_cache_flush();
check( 'foreign transient removed, wstm kept', false === get_transient( 'p9_tmp' ) && 'y' === get_transient( 'wstm_keep' ) );
check( 'permalinks ok', 200 === rest( 'POST', '/tools/permalinks' )[0] );
check( 'elementor ok (absent plugin handled)', 200 === rest( 'POST', '/tools/elementor' )[0] );

echo "Link audit\n";
$wpdb->query( "DELETE FROM wp_posts WHERE post_title LIKE 'P9 %'" );
wp_insert_post( array( 'post_title' => 'P9 links', 'post_status' => 'publish', 'post_content' => '<a href="https://old-site.example/page">x</a> <img src="' . content_url( 'uploads/nope-p9.jpg' ) . '">' ) );
$j = rest( 'POST', '/tools/link-audit', array( 'old_hosts' => array( 'https://old-site.example' ) ) );
check( 'link audit job created', 200 === $j[0] && 'link_audit' === $j[1]['type'], json_encode( $j ) );
check( 'link audit completed', 'completed' === run_job( $j[1]['id'] ) );
$m = $P->jobs()->get( $j[1]['id'] )->metadata;
check( 'old-domain link found', $m['old'] >= 1 && str_contains( json_encode( $m['old_samples'] ), 'old-site.example' ), json_encode( $m ) );
check( 'missing upload found', $m['missing'] >= 1 && str_contains( json_encode( $m['missing_samples'] ), 'nope-p9.jpg' ) );

echo "History\n";
$hi = rest( 'GET', '/tools/history' );
check( 'history 200 + list', 200 === $hi[0] && is_array( $hi[1] ), json_encode( $hi ) );

echo "WooCommerce filters\n";
$wpdb->query( 'CREATE TABLE IF NOT EXISTS wp_wc_orders (id BIGINT PRIMARY KEY, total DECIMAL(10,2))' );
$wpdb->query( 'REPLACE INTO wp_wc_orders VALUES (1, 9.99)' );
$order = wp_insert_post( array( 'post_title' => 'P9 order', 'post_type' => 'shop_order', 'post_status' => 'publish' ) );
add_post_meta( $order, '_p9', 'secret-order' );
$cust = wp_insert_user( array( 'user_login' => 'p9cust' . wp_rand(), 'user_pass' => 'x', 'role' => 'subscriber' ) );
( new WP_User( $cust ) )->set_role( 'customer' );
$f = \WSTM\Package\PackageBuilder::db_filters( array( 'woo_orders' => true, 'woo_customers' => true, 'revisions' => true ) );
$cnt = fn( $t ) => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$t` WHERE " . $f[ $t ] );
check( 'all filter SQL valid', null !== $wpdb->get_var( "SELECT COUNT(*) FROM wp_users WHERE {$f['wp_users']}" ) && '' === $wpdb->last_error );
check( 'orders table emptied', 0 === $cnt( 'wp_wc_orders' ) );
check( 'shop_order post excluded, normal posts kept', 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_posts WHERE ID=$order AND {$f['wp_posts']}" ) && $cnt( 'wp_posts' ) > 0 );
check( 'order meta excluded', 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_postmeta WHERE post_id=$order AND {$f['wp_postmeta']}" ) );
check( 'customer excluded, admin kept', 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_users WHERE ID=$cust AND {$f['wp_users']}" ) && 1 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_users WHERE ID=1 AND {$f['wp_users']}" ) );
check( 'customer meta excluded', 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_usermeta WHERE user_id=$cust AND {$f['wp_usermeta']}" ) );
wp_delete_post( $order, true ); wp_delete_user( $cust ); $wpdb->query( 'DROP TABLE wp_wc_orders' );
$wpdb->query( "DELETE FROM wp_posts WHERE post_title LIKE 'P9 %'" );

echo "\n$ok passed, $bad failed\n";
exit( $bad ? 1 : 0 );
