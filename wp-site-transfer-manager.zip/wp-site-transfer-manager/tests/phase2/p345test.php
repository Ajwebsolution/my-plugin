<?php
// Phases 3–5 integration tests (MariaDB). Source DB = wpsrc, destination DB = wpdst (same code, separate site).
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function q( $sql ) { global $wpdb; $wpdb->query( $sql ); if ( $wpdb->last_error ) { echo "SQL ERR: {$wpdb->last_error}\n"; } }
function php_run( string $db, string $code ): string { return (string) shell_exec( 'WSTM_DB=' . $db . ' php -r ' . escapeshellarg( 'require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function run_job( string $db, int $id, int $budget = 0, ?callable $each = null, int $max = 3000 ): array {
	$runs = 0;
	while ( $runs++ < $max ) {
		$b   = $budget < 0 ? 0 : $budget; // -1: single-slice requests.
		$out = (string) shell_exec( 'WSTM_DB=' . $db . ' php ' . __DIR__ . '/run.php ' . $id . ' ' . $b . ' 2>&1' );
		$st  = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN OUTPUT: $out\n"; return array( 'status' => 'crash' ); }
		if ( $each ) { $each( $runs, $st ); }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st + array( 'runs' => $runs ); }
	}
	return array( 'status' => 'timeout' );
}
function job( string $db, int $id ): array { return json_decode( php_run( $db, '$j = $P->jobs()->get(' . $id . '); echo json_encode($j->to_array());' ), true ) ?: array(); }
function create( string $db, string $type, array $meta ): int { return (int) trim( php_run( $db, 'echo $P->jobs()->create(' . var_export( $type, true ) . ', ' . var_export( $meta, true ) . ')->id;' ) ); }

$P = \WSTM\Core\Plugin::instance();
q( 'TRUNCATE wp_wstm_jobs' );
foreach ( $wpdb->get_col( "SHOW TABLES LIKE 'wstm%'" ) as $t ) { q( "DROP TABLE `$t`" ); }

echo "Setup source site files & content\n";
$up = wp_upload_dir()['basedir'];
exec( 'rm -rf ' . escapeshellarg( $up ) . ' ' . escapeshellarg( WP_PLUGIN_DIR . '/demo-plugin' ) );
wp_mkdir_p( "$up/2026/10" ); wp_mkdir_p( WP_PLUGIN_DIR . '/demo-plugin/node_modules/x' ); wp_mkdir_p( WP_CONTENT_DIR . '/cache/page' );
file_put_contents( "$up/2026/10/photo.jpg", random_bytes( 300000 ) );
file_put_contents( "$up/2026/10/big.bin", random_bytes( 12 * 1048576 + 7 ) );
file_put_contents( "$up/2026/10/ünï 😀.txt", 'unicode name' );
file_put_contents( "$up/evil.php", '<?php echo 1;' );
file_put_contents( WP_PLUGIN_DIR . '/demo-plugin/demo.php', "<?php\n/* Plugin Name: Demo */" );
file_put_contents( WP_PLUGIN_DIR . '/demo-plugin/node_modules/x/a.js', 'x' );
file_put_contents( WP_CONTENT_DIR . '/cache/page/c.html', 'cached' );
@symlink( '/etc', "$up/link-to-etc" );
wp_mkdir_p( "$up/emptydir" );

// URL test content.
$old = 'https://dev.example.com';
q( "DELETE FROM wp_posts WHERE post_title LIKE 'URL test%'" );
$pid = wp_insert_post( array( 'post_title' => 'URL test', 'post_status' => 'publish', 'post_content' => "<a href=\"$old/about\">About</a> <img src=\"$old/wp-content/uploads/2026/10/photo.jpg\"> keep $old.au and $old-staging.net" ) );
q( $wpdb->prepare( 'UPDATE wp_posts SET guid=%s WHERE ID=%d', "$old/?p=$pid", $pid ) );
update_post_meta( $pid, '_elementor_data', wp_slash( wp_json_encode( array( array( 'settings' => array( 'url' => "$old/x", 'image' => array( 'url' => "$old/wp-content/uploads/a.jpg" ) ) ) ) ) ) );
update_post_meta( $pid, 'acf_link', array( 'title' => 'Link', 'url' => "$old/acf", 'nested' => array( 'deep' => serialize( array( 'u' => "$old/deep" ) ) ) ) );
update_option( 'wstm_url_test', array( 'home' => $old, 'list' => array( "$old/a", "$old/b" ), 'obj' => (object) array( 'u' => "$old/o" ) ) );
q( $wpdb->prepare( "INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('wstm_corrupt', %s, 'no') ON DUPLICATE KEY UPDATE option_value=VALUES(option_value)", 'a:1:{s:1:"u";s:99:"' . $old . '";}' ) );
q( 'DROP TABLE IF EXISTS wp_t_big' );

echo "Phase 4: build package (one slice per request, with a simulated crash)\n";
$small = create( 'wpsrc', 'package_export', array( 'components' => array( 'database' => true, 'uploads' => true, 'plugins' => true ), 'exclusions' => array( 'node_modules/' ) ) );
$id    = $small;
$snap  = null; $crashed = false;
$res   = run_job( 'wpsrc', $id, -1, function ( $n, $st ) use ( $id, &$snap, &$crashed ) {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT checkpoint FROM wpsrc.wp_wstm_jobs WHERE id=%d', $id ), ARRAY_A );
	$cp  = json_decode( (string) $row['checkpoint'], true );
	if ( ! $crashed && 'files' === ( $cp['stage'] ?? '' ) ) {
		if ( null === $snap ) { $snap = $row['checkpoint']; return; }
		file_put_contents( $cp['part'], random_bytes( 3000 ), FILE_APPEND );
		$wpdb->update( 'wp_wstm_jobs', array( 'checkpoint' => $snap ), array( 'id' => $id ) );
		$crashed = true;
	}
} );
$j = job( 'wpsrc', $id );
check( 'package built across many single-slice requests', 'completed' === $j['status'] && $res['runs'] > 20, json_encode( $res ) . json_encode( $j['error'] ) );
check( 'crash mid-archive recovered', $crashed );
$smallpkg = $P->storage()->area( 'packages' ) . '/' . $j['metadata']['file'];
$v = create( 'wpsrc', 'package_validate', array( 'file' => basename( $smallpkg ) ) ); run_job( 'wpsrc', $v, 3 );
check( 'package built through a crash is valid', 'completed' === job( 'wpsrc', $v )['status'], json_encode( job( 'wpsrc', $v )['error'] ) );
@unlink( $smallpkg ); @unlink( $smallpkg . '.json' );
echo "Phase 4: full-site package (all components)\n";
$id = create( 'wpsrc', 'package_export', array( 'components' => array_fill_keys( \WSTM\Files\SiteRoots::COMPONENTS, true ), 'exclusions' => array( 'node_modules/', 'wp-content/cache/', '.git/' ) ) );
run_job( 'wpsrc', $id, 5 );
$j = job( 'wpsrc', $id );
check( 'full package built', 'completed' === $j['status'], json_encode( $j['error'] ) );
$pkg = $P->storage()->area( 'packages' ) . '/' . $j['metadata']['file'];
check( 'package is .wpmig in protected storage', str_ends_with( $pkg, '.wpmig' ) && is_file( $pkg ) && ! is_file( $pkg . '.part' ) );
$names = array();
foreach ( \WSTM\Archive\ArchiveIndex::entries( $pkg ) as $e ) { $names[ $e['path'] ] = $e; }
check( 'layout: metadata, migration, db, checksums, manifest', isset( $names['metadata.json'], $names['migration.json'], $names['database.sql.gz'], $names['database.manifest.json'], $names['checksums.json'], $names['manifest.json'] ) );
check( 'uploads/plugins/themes/core included', isset( $names['files/uploads/2026/10/big.bin'], $names['files/plugins/demo-plugin/demo.php'], $names['files/core_includes/version.php'], $names['files/abspath/index.php'] ) && count( preg_grep( '#^files/themes/#', array_keys( $names ) ) ) > 0 );
check( 'unicode file name archived', isset( $names['files/uploads/2026/10/ünï 😀.txt'] ) );
check( 'exclusions honoured (node_modules, cache)', ! preg_grep( '#node_modules|/cache/page#', array_keys( $names ) ) );
check( 'wp-config.php never packaged', ! isset( $names['files/abspath/wp-config.php'] ) );
check( 'plugin storage never packaged', ! preg_grep( '#wstm-storage-#', array_keys( $names ) ) );
check( 'symlinks not followed', ! preg_grep( '#link-to-etc#', array_keys( $names ) ) );
$ck = json_decode( \WSTM\Archive\ArchiveExtractor::read_entry( $pkg, 'checksums.json', 64 * 1048576 ), true );
check( 'checksums.json valid JSON with per-file SHA-256', is_array( $ck ) && isset( $ck['files/uploads/2026/10/photo.jpg'] ) && $ck['files/uploads/2026/10/photo.jpg'] === $names['files/uploads/2026/10/photo.jpg']['sha256'] );
$meta = json_decode( \WSTM\Archive\ArchiveExtractor::read_entry( $pkg, 'metadata.json' ), true );
check( 'metadata has no DB credentials/salts', ! str_contains( json_encode( $meta ), 'DB_PASSWORD' ) && ! str_contains( json_encode( $meta ), '"wp"' ) || ! isset( $meta['config']['DB_PASSWORD'] ) );

echo "Phase 4: validation\n";
$v = create( 'wpsrc', 'package_validate', array( 'file' => basename( $pkg ) ) );
run_job( 'wpsrc', $v, 3 );
$vj = job( 'wpsrc', $v );
check( 'valid package passes seal + structure + manifest', 'completed' === $vj['status'], json_encode( $vj['error'] ) );
check( 'suspicious uploads executable reported', str_contains( json_encode( $vj['metadata']['warnings'] ?? array() ), 'executable' ) );
$bad1 = dirname( $pkg ) . '/tampered.wpmig'; copy( $pkg, $bad1 );
$h = fopen( $bad1, 'r+b' ); fseek( $h, (int) ( filesize( $bad1 ) / 2 ) ); $c = fread( $h, 1 ); fseek( $h, (int) ( filesize( $bad1 ) / 2 ) ); fwrite( $h, chr( ord( $c ) ^ 1 ) ); fclose( $h );
$v = create( 'wpsrc', 'package_validate', array( 'file' => 'tampered.wpmig' ) ); run_job( 'wpsrc', $v, 3 );
check( 'single flipped bit detected (seal)', 'seal_mismatch' === ( job( 'wpsrc', $v )['error']['code'] ?? '' ) );
$bad2 = dirname( $pkg ) . '/truncated.wpmig'; file_put_contents( $bad2, file_get_contents( $pkg, false, null, 0, (int) ( filesize( $pkg ) * 0.6 ) ) );
$v = create( 'wpsrc', 'package_validate', array( 'file' => 'truncated.wpmig' ) ); run_job( 'wpsrc', $v, 3 );
check( 'truncated package rejected', 'failed' === job( 'wpsrc', $v )['status'] );
// Malicious package: traversal entry with a valid seal.
$evil = dirname( $pkg ) . '/evil.wpmig';
$w = new \WSTM\Archive\ArchiveWriter( \WSTM\Archive\ArchiveWriter::init_state( $evil ) );
$w->add_string( 'metadata.json', '{}' ); $w->add_string( 'files/uploads/../../../../tmp/pwned.php', '<?php' ); $st = $w->close();
$w = new \WSTM\Archive\ArchiveWriter( $st ); $w->seal( \WSTM\Database\BlockHasher::file( $evil ) ); $w->close();
$v = create( 'wpsrc', 'package_validate', array( 'file' => 'evil.wpmig' ) ); run_job( 'wpsrc', $v, 3 );
check( 'path-traversal entry rejected even with valid seal', 'unsafe_path' === ( job( 'wpsrc', $v )['error']['code'] ?? '' ) && ! file_exists( '/tmp/pwned.php' ) );
foreach ( array( $bad1, $bad2, $evil ) as $f ) { @unlink( $f ); }

echo "Phase 4: chunked upload to the destination site\n";
php_run( 'wpdst', '' ); // ensure destination installed
$dst_storage = trim( php_run( 'wpdst', 'echo $P->storage()->area("packages");' ) );
check( 'destination has its own storage', $dst_storage !== dirname( $pkg ) && is_dir( $dst_storage ) );
$size  = filesize( $pkg );
$start = json_decode( php_run( 'wpdst', 'echo json_encode((new \WSTM\Files\UploadManager($P->storage()))->start("site.wpmig",' . $size . ',"fp1"));' ), true );
check( 'upload started', ! empty( $start['id'] ) );
$chunk = 4 * 1048576; $off = 0; $n = 0; $dupe_ok = false; $gap_rejected = false;
$fh = fopen( $pkg, 'rb' );
while ( $off < $size ) {
	fseek( $fh, $off ); $data = fread( $fh, $chunk );
	$tmp = tempnam( sys_get_temp_dir(), 'ch' ); file_put_contents( $tmp, $data );
	$code = '$d=file_get_contents("' . $tmp . '"); echo json_encode((new \WSTM\Files\UploadManager($P->storage()))->chunk("' . $start['id'] . '",' . $off . ',$d,hash("sha256",$d)));';
	$r = json_decode( php_run( 'wpdst', $code ), true );
	if ( 1 === ++$n ) { // retry the same chunk (network retry) — must be idempotent
		$r2 = json_decode( php_run( 'wpdst', $code ), true ); $dupe_ok = $r2['received'] === $r['received'];
		$gap = php_run( 'wpdst', 'try{(new \WSTM\Files\UploadManager($P->storage()))->chunk("' . $start['id'] . '",' . ( $off + 2 * $chunk ) . ',"x",null);}catch(\Throwable $e){echo $e->getMessage();}' );
		$gap_rejected = str_contains( $gap, 'ahead' );
		$resume = json_decode( php_run( 'wpdst', 'echo json_encode((new \WSTM\Files\UploadManager($P->storage()))->start("site.wpmig",' . $size . ',"fp1"));' ), true );
		check( 'interrupted upload resumes at received offset', $resume['id'] === $start['id'] && $resume['received'] === strlen( $data ) );
	}
	unlink( $tmp );
	$off += strlen( $data );
}
fclose( $fh );
check( 'duplicate chunk accepted idempotently', $dupe_ok );
check( 'out-of-order chunk rejected', $gap_rejected );
$bad_hash = php_run( 'wpdst', 'try{(new \WSTM\Files\UploadManager($P->storage()))->chunk("' . $start['id'] . '",0,"zzz",str_repeat("0",64));}catch(\Throwable $e){echo $e->getMessage();}' );
check( 'chunk checksum mismatch rejected', str_contains( $bad_hash, 'checksum' ) );
$fin = json_decode( php_run( 'wpdst', 'echo json_encode((new \WSTM\Files\UploadManager($P->storage()))->finish("' . $start['id'] . '"));' ), true );
check( 'upload finished, byte-identical', ! empty( $fin['file'] ) && hash_file( 'sha256', $dst_storage . '/' . $fin['file'] ) === hash_file( 'sha256', $pkg ) );
$bad_ext = php_run( 'wpdst', 'try{(new \WSTM\Files\UploadManager($P->storage()))->start("shell.php",10,"x");}catch(\Throwable $e){echo $e->getMessage();}' );
check( 'non-package upload types refused', str_contains( $bad_ext, 'Only' ) );

echo "Phase 4: import package into destination (database + staged files)\n";
$dst_before_posts = (int) trim( php_run( 'wpdst', 'global $wpdb; echo $wpdb->get_var("SELECT COUNT(*) FROM wp_posts WHERE post_title=\'URL test\'");' ) );
$imp = create( 'wpdst', 'package_import', array( 'file' => $fin['file'], 'confirmed' => true, 'import_database' => true, 'safety_backup' => true ) );
$r   = run_job( 'wpdst', $imp, 2 );
$ij  = job( 'wpdst', $imp );
check( 'package import completed', 'completed' === $ij['status'], json_encode( $ij['error'] ) );
$after_posts = (int) trim( php_run( 'wpdst', 'global $wpdb; echo $wpdb->get_var("SELECT COUNT(*) FROM wp_posts WHERE post_title=\'URL test\'");' ) );
check( 'source database now on destination', 0 === $dst_before_posts && 1 === $after_posts );
$staging = $ij['metadata']['staging'] ?? '';
$diff = shell_exec( 'diff -r --exclude=link-to-etc --exclude=evil.php ' . escapeshellarg( $up ) . ' ' . escapeshellarg( $staging . '/uploads' ) . ' 2>&1 && echo SAME' );
check( 'staged uploads byte-identical to source', str_contains( (string) $diff, 'SAME' ), substr( (string) $diff, 0, 300 ) );
check( 'executable in uploads not extracted', ! file_exists( $staging . '/uploads/evil.php' ) );
check( 'empty directory recreated', is_dir( $staging . '/uploads/emptydir' ) );
check( 'plugins & core staged', is_file( $staging . '/plugins/demo-plugin/demo.php' ) && is_file( $staging . '/core_includes/version.php' ) );
check( 'destination storage settings survived import', trim( php_run( 'wpdst', 'echo $P->storage()->area("packages");' ) ) === $dst_storage );
check( 'safety backup of destination created', ! empty( $ij['metadata']['safety_backup'] ) );

echo "Phase 5: URL scan / dry run / replace on destination\n";
$new   = 'https://live.example.org';
$pairs = array( array( $old, $new ) );
$sc = create( 'wpdst', 'url_scan', array( 'mode' => 'scan', 'pairs' => $pairs ) ); run_job( 'wpdst', $sc, 3 ); $sj = job( 'wpdst', $sc );
check( 'scan completed', 'completed' === $sj['status'], json_encode( $sj['error'] ) );
$tot = $sj['metadata']['totals'];
check( 'scan finds posts/postmeta/options', isset( $sj['metadata']['report']['wp_posts'], $sj['metadata']['report']['wp_postmeta'], $sj['metadata']['report']['wp_options'] ), json_encode( array_keys( $sj['metadata']['report'] ) ) );
check( 'scan classifies serialized + json + plain', $tot['serialized'] >= 2 && $tot['json'] >= 1 && $tot['plain'] >= 1, json_encode( $tot ) );
check( 'corrupt serialized value reported, not counted', 1 === $tot['unparseable'] );
$snap_db = trim( php_run( 'wpdst', 'global $wpdb; echo md5(json_encode($wpdb->get_results("CHECKSUM TABLE wp_posts, wp_postmeta, wp_options")));' ) );
$dr = create( 'wpdst', 'url_scan', array( 'mode' => 'dry_run', 'pairs' => $pairs ) ); run_job( 'wpdst', $dr, 3 ); $dj = job( 'wpdst', $dr );
check( 'dry run completed with samples', 'completed' === $dj['status'] && count( $dj['metadata']['samples'] ) > 0 );
check( 'dry run did not modify data', $snap_db === trim( php_run( 'wpdst', 'global $wpdb; echo md5(json_encode($wpdb->get_results("CHECKSUM TABLE wp_posts, wp_postmeta, wp_options")));' ) ) );
$rp = create( 'wpdst', 'url_replace', array( 'pairs' => $pairs ) ); run_job( 'wpdst', $rp, 3 );
check( 'replace refused without confirmation', 'not_confirmed' === ( job( 'wpdst', $rp )['error']['code'] ?? '' ) );
php_run( 'wpdst', '$P->jobs()->cancel(' . $rp . ');' );
$rp = create( 'wpdst', 'url_replace', array( 'pairs' => $pairs, 'confirmed' => true, 'safety_backup' => true ) );
run_job( 'wpdst', $rp, -1 ); $rj = job( 'wpdst', $rp );
check( 'replace completed (single-slice requests)', 'completed' === $rj['status'], json_encode( $rj['error'] ) );
check( 'replace count equals dry run', $rj['metadata']['totals']['replacements'] === $dj['metadata']['totals']['replacements'], $rj['metadata']['totals']['replacements'] . ' vs ' . $dj['metadata']['totals']['replacements'] );
$check = php_run( 'wpdst', '
	global $wpdb; wp_cache_flush();
	$p = $wpdb->get_row("SELECT ID, post_content, guid FROM wp_posts WHERE post_title=\'URL test\'");
	$o = get_option("wstm_url_test");
	$a = get_post_meta($p->ID, "acf_link", true);
	$e = json_decode(get_post_meta($p->ID, "_elementor_data", true), true);
	echo json_encode(array(
		"content" => $p->post_content, "guid" => $p->guid,
		"opt_ok" => is_array($o) && $o["home"] === "https://live.example.org" && $o["list"][1] === "https://live.example.org/b" && $o["obj"]->u === "https://live.example.org/o",
		"acf_ok" => is_array($a) && $a["url"] === "https://live.example.org/acf" && unserialize($a["nested"]["deep"])["u"] === "https://live.example.org/deep",
		"el_ok" => $e[0]["settings"]["image"]["url"] === "https://live.example.org/wp-content/uploads/a.jpg",
		"corrupt" => $wpdb->get_var("SELECT option_value FROM wp_options WHERE option_name=\'wstm_corrupt\'"),
	));' );
$c = json_decode( $check, true ) ?: array();
check( 'post content rewritten', str_contains( $c['content'] ?? '', "$new/about" ) && ! str_contains( $c['content'] ?? '', "$old/about" ), $check );
check( 'longer domains untouched (.au, -staging)', str_contains( $c['content'] ?? '', "$old.au" ) && str_contains( $c['content'] ?? '', "$old-staging.net" ) );
check( 'GUID untouched by default', str_starts_with( $c['guid'] ?? '', $old ) );
check( 'serialized option (array + object) intact & replaced', ! empty( $c['opt_ok'] ) );
check( 'ACF-style nested serialized-in-serialized replaced', ! empty( $c['acf_ok'] ) );
check( 'Elementor JSON (escaped slashes) replaced', ! empty( $c['el_ok'] ) );
check( 'corrupt serialized value left byte-identical', ( $c['corrupt'] ?? '' ) === 'a:1:{s:1:"u";s:99:"' . $old . '";}' );
check( 'verification reports remaining legit references only', array_sum( $rj['metadata']['remaining'] ) >= 1 && ! isset( $rj['metadata']['remaining']['wp_postmeta'] ), json_encode( $rj['metadata']['remaining'] ) );
check( 'safety backup before replace', ! empty( $rj['metadata']['safety_backup'] ) );
$rr = create( 'wpdst', 'url_scan', array( 'mode' => 'scan', 'pairs' => $pairs ) ); run_job( 'wpdst', $rr, 3 );
check( 'rescan: nothing left to replace', 0 === job( 'wpdst', $rr )['metadata']['totals']['replacements'] );

echo "REST & pages\n";
$rest = php_run( 'wpdst', '
	do_action("rest_api_init"); $s = rest_get_server(); $o = array();
	$o[] = $s->dispatch(new WP_REST_Request("GET","/wstm/v1/packages"))->get_status();
	$o[] = $s->dispatch(new WP_REST_Request("GET","/wstm/v1/url/defaults"))->get_status();
	$r = new WP_REST_Request("POST","/wstm/v1/url/replace"); $r->set_body_params(array("pairs"=>array(array("old"=>"https://a.com","new"=>"https://b.com")))); $o[] = $s->dispatch($r)->get_status();
	$r = new WP_REST_Request("POST","/wstm/v1/url/scan"); $r->set_body_params(array("pairs"=>array(array("old"=>"ab","new"=>"cd")))); $o[] = $s->dispatch($r)->get_status();
	$r = new WP_REST_Request("POST","/wstm/v1/packages/import"); $r->set_body_params(array("file"=>"../x.wpmig","confirm"=>true)); $o[] = $s->dispatch($r)->get_status();
	wp_set_current_user(0); $o[] = $s->dispatch(new WP_REST_Request("GET","/wstm/v1/packages"))->get_status();
	echo json_encode($o);' );
check( 'REST: list 200, defaults 200, unconfirmed replace 400, too-short pattern 400, traversal 400, anon denied', '[200,200,400,400,400,401]' === trim( $rest ), $rest );
$pages = php_run( 'wpdst', 'require_once WSTM_PATH."admin/class-admin.php"; set_current_screen("dashboard"); $a=new \WSTM\Admin\Admin($P); $bad=0; foreach(array("export","import","url-replace","") as $p){ ob_start(); $a->render($p); $h=ob_get_clean(); if(!str_contains($h,"wstm-wrap")||preg_match("/(Warning|Notice|Fatal error|Deprecated):/",$h)) $bad++; } echo $bad;' );
check( 'admin pages render cleanly', '0' === trim( $pages ), $pages );

exec( 'rm -rf ' . escapeshellarg( WP_PLUGIN_DIR . '/demo-plugin' ) . ' ' . escapeshellarg( WP_CONTENT_DIR . '/cache' ) );
echo "\n$ok passed, $bad failed\n";
