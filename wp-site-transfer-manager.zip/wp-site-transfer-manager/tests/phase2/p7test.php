<?php
// Phase 7: backups (full/incremental), verification, retention, chain restore, undo.
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function php_run( $code ) { return (string) shell_exec( 'php -r ' . escapeshellarg( 'require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function rest( $method, $route, $params = array(), $user = 1 ) {
	$out = php_run( 'wp_set_current_user(' . $user . '); do_action("rest_api_init"); $r=new WP_REST_Request("' . $method . '","/wstm/v1' . $route . '"); $r->set_body_params(' . var_export( $params, true ) . '); $res=rest_get_server()->dispatch($r); echo "\n@@" . json_encode(array($res->get_status(), $res->get_data()));' );
	return json_decode( substr( $out, strrpos( $out, '@@' ) + 2 ), true );
}
function run_job( $id, $budget = 3 ) {
	for ( $i = 0; $i < 3000; $i++ ) {
		$out = (string) shell_exec( 'php ' . __DIR__ . '/run.php ' . $id . ' ' . $budget . ' 2>&1' );
		$st  = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN: $out\n"; return 'crash'; }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st['status']; }
	}
	return 'timeout';
}
function run_token( $id, $token ) {
	for ( $i = 0; $i < 3000; $i++ ) {
		$d = rest( 'POST', '/migration/run/' . $id, array( 'token' => $token ), 0 );
		if ( ! $d || 200 !== $d[0] ) { echo 'TOKEN RUN: ' . json_encode( $d ) . "\n"; return 'error'; }
		if ( ! in_array( $d[1]['status'], array( 'running', 'pending' ), true ) ) { return $d[1]['status'] . ( $d[1]['error'] ? ' ' . json_encode( $d[1]['error'] ) : '' ); }
	}
	return 'timeout';
}
function job( $id ) { return json_decode( php_run( 'echo json_encode($P->jobs()->get(' . $id . ')->to_array());' ), true ); }
function post_count() { global $wpdb; return (int) $wpdb->get_var( "SELECT COUNT(*) FROM wp_posts WHERE post_title LIKE 'P7 %'" ); }

$P  = \WSTM\Core\Plugin::instance();
$up = wp_upload_dir()['basedir'];
$wpdb->query( 'TRUNCATE wp_wstm_jobs' ); $wpdb->query( 'TRUNCATE wp_wstm_backups' );
foreach ( glob( $P->storage()->area( 'backups' ) . '/*' ) as $f ) { is_dir( $f ) ? exec( 'rm -rf ' . escapeshellarg( $f ) ) : ( str_ends_with( $f, '.php' ) || str_ends_with( $f, 'htaccess' ) || str_ends_with( $f, 'config' ) ? null : unlink( $f ) ); }
$wpdb->query( "DELETE FROM wp_posts WHERE post_title LIKE 'P7 %'" );
file_put_contents( "$up/p7-a.txt", 'A1' );
@unlink( "$up/p7-b.txt" );
wp_insert_post( array( 'post_title' => 'P7 one', 'post_status' => 'publish' ) );

echo "Full backup\n";
$j = rest( 'POST', '/backups/create', array( 'type' => 'full', 'mode' => 'full', 'label' => 'Base' ) )[1];
check( 'full backup completed', 'completed' === run_job( $j['id'] ) );
$list = rest( 'GET', '/backups' )[1]['backups'];
$full = $list[0];
check( 'recorded as verified full backup with snapshot', 'full' === $full['type'] && $full['verified'] && 'full' === $full['meta']['mode'] && is_file( $P->storage()->area( 'backups' ) . '/' . $full['file'] . '.idx' ) );
$full_files = $full['meta']['files'];

echo "Incremental backup\n";
sleep( 1 );
file_put_contents( "$up/p7-a.txt", 'A2-changed' );
file_put_contents( "$up/p7-b.txt", 'B new' );
wp_insert_post( array( 'post_title' => 'P7 two', 'post_status' => 'publish' ) );
$j = rest( 'POST', '/backups/create', array( 'type' => 'full', 'mode' => 'incremental' ) )[1];
check( 'incremental backup completed', 'completed' === run_job( $j['id'] ) );
$inc = rest( 'GET', '/backups' )[1]['backups'][0];
check( 'incremental stores only changed files', 'incremental' === $inc['meta']['mode'] && $inc['meta']['files'] <= 3 && $inc['meta']['unchanged'] > 10 && $inc['parent_backup_id'] === $full['id'], json_encode( $inc['meta'] ) . ' full=' . $full_files );
check( 'incremental much smaller than full', $inc['size_bytes'] < $full['size_bytes'] );
$expected_posts = post_count();

echo "Damage the site, then restore the incremental chain\n";
file_put_contents( "$up/p7-a.txt", 'DAMAGED' );
@unlink( "$up/p7-b.txt" );
file_put_contents( "$up/p7-c.txt", 'created after backup' );
$wpdb->query( "DELETE FROM wp_posts WHERE post_title LIKE 'P7 %'" );
$r = rest( 'POST', '/backups/' . $inc['id'] . '/restore', array( 'confirm' => true ) )[1];
check( 'restore job with token', ! empty( $r['token'] ) );
$st = run_token( $r['id'], $r['token'] );
check( 'chain restore completed', 'completed' === $st, $st );
wp_cache_flush();
check( 'files back to incremental state', 'A2-changed' === @file_get_contents( "$up/p7-a.txt" ) && 'B new' === @file_get_contents( "$up/p7-b.txt" ) );
check( 'database back to incremental state', $expected_posts === post_count(), post_count() . ' vs ' . $expected_posts );
check( 'files not in any backup are left alone (no deletions)', is_file( "$up/p7-c.txt" ) );
$rj = job( $r['id'] );
check( 'restore applied 2 packages', 2 === $rj['metadata']['chain'] );

echo "Undo the restore\n";
$points = rest( 'GET', '/backups' )[1]['rollbacks'];
check( 'undo point listed', ! empty( $points ) && $points[0]['dir'] === $rj['metadata']['rollback_id'] );
$u = rest( 'POST', '/rollback/' . $points[0]['dir'], array( 'confirm' => true ) )[1];
$st = run_token( $u['id'], $u['token'] );
check( 'undo completed', 'completed' === $st, $st );
wp_cache_flush();
check( 'files back to pre-restore (damaged) state', 'DAMAGED' === @file_get_contents( "$up/p7-a.txt" ) && ! is_file( "$up/p7-b.txt" ) && is_file( "$up/p7-c.txt" ) );
check( 'database back to pre-restore state', 0 === post_count() );
$again = rest( 'POST', '/rollback/' . $points[0]['dir'], array( 'confirm' => true ) );
check( 'undo cannot run twice', 400 === $again[0] );

echo "Verification & retention\n";
$bpath = $P->storage()->area( 'backups' ) . '/' . $full['file'];
copy( $bpath, $bpath . '.orig' );
$h = fopen( $bpath, 'r+b' ); fseek( $h, 5000 ); fwrite( $h, 'XX' ); fclose( $h );
$v = rest( 'POST', '/backups/' . $full['id'] . '/verify' )[1];
run_job( $v['id'] );
$after = array_values( array_filter( rest( 'GET', '/backups' )[1]['backups'], fn( $b ) => $b['id'] === $full['id'] ) )[0];
check( 'tampered backup marked unverified', false === $after['verified'] );
rename( $bpath . '.orig', $bpath );
$v = rest( 'POST', '/backups/' . $full['id'] . '/verify' )[1]; run_job( $v['id'] );
check( 're-verify after repair', true === array_values( array_filter( rest( 'GET', '/backups' )[1]['backups'], fn( $b ) => $b['id'] === $full['id'] ) )[0]['verified'] );
$del = rest( 'POST', '/backups/' . $full['id'] . '/delete', array( 'confirm' => true ) );
check( 'base with dependents cannot be deleted', 400 === $del[0] );
php_run( '$s=get_site_option("wstm_settings"); $s["backup_retention"]=1; update_site_option("wstm_settings",$s);' );
$j = rest( 'POST', '/backups/create', array( 'type' => 'database' ) )[1];
run_job( $j['id'] );
$after = rest( 'GET', '/backups' )[1]['backups'];
$non_safety = array_values( array_filter( $after, fn( $b ) => ! $b['is_safety'] ) );
check( 'retention kept only newest restore point', 1 === count( $non_safety ) && 'database' === $non_safety[0]['type'], json_encode( array_map( fn( $b ) => $b['type'] . '#' . $b['id'], $non_safety ) ) );
check( 'old backup files removed from disk', ! is_file( $bpath ) );
php_run( '$s=get_site_option("wstm_settings"); $s["backup_retention"]=5; $s["backup_schedule"]="daily"; update_site_option("wstm_settings",$s);' );
check( 'daily schedule registered', (bool) trim( php_run( 'do_action("init"); echo wp_next_scheduled("wstm_scheduled_backup") ? "1" : "";' ) ) );
php_run( '$s=get_site_option("wstm_settings"); $s["backup_schedule"]="off"; update_site_option("wstm_settings",$s); do_action("init");' );

@unlink( "$up/p7-a.txt" ); @unlink( "$up/p7-b.txt" ); @unlink( "$up/p7-c.txt" );
echo "\n$ok passed, $bad failed\n";
