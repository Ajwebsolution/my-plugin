<?php
// Phase 2 integration tests on MariaDB. Each job slice runs in a separate PHP process (= a separate HTTP request).
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function q( $sql ) { global $wpdb; $wpdb->query( $sql ); if ( $wpdb->last_error ) { echo "SQL ERR: {$wpdb->last_error}\n"; } }
function run_job( int $id, int $budget = 2, int $max = 2000, ?callable $each = null, string $php = 'php' ): array {
	$runs = 0; $peak = 0;
	while ( $runs < $max ) {
		$out = shell_exec( $php . ' ' . __DIR__ . '/run.php ' . $id . ' ' . $budget . ' 2>&1' );
		$runs++;
		$st = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN OUTPUT: $out\n"; return array( 'status' => 'crash', 'runs' => $runs ); }
		$peak = max( $peak, $st['mem'] );
		if ( $each ) { $each( $runs, $st ); }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st + array( 'runs' => $runs, 'peak' => $peak ); }
	}
	return array( 'status' => 'timeout', 'runs' => $runs );
}
function checksums( array $tables ): array {
	global $wpdb; $out = array();
	foreach ( $tables as $t ) { $r = $wpdb->get_row( "CHECKSUM TABLE `$t` EXTENDED", ARRAY_A ); $out[ $t ] = $r['Checksum']; }
	return $out;
}
function gunzip( $f ) { return (string) shell_exec( 'zcat ' . escapeshellarg( $f ) ); }
function fresh() { wp_cache_flush(); return \WSTM\Core\Plugin::instance(); }

echo "Setup test data\n";
q( 'DROP TABLE IF EXISTS wp_t_types, wp_t_nopk, wp_t_cpk, wp_t_new, other_table' );
foreach ( $wpdb->get_col( "SHOW TABLES LIKE 'wstm%'" ) as $t ) { q( "DROP TABLE `$t`" ); }
q( 'TRUNCATE wp_wstm_jobs' ); q( 'TRUNCATE wp_wstm_backups' );
q( "SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO'" );
q( 'CREATE TABLE wp_t_types ( id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, txt LONGTEXT, bin LONGBLOB, n DECIMAL(20,6), d DATETIME, j JSON, nul VARCHAR(10) NULL, bits BIT(8) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5' );
$tricky = array( "O'Reilly; DROP TABLE x; -- \\ /* */ # \"q\"", "emoji 😀🚀 ünïcødé 中文", serialize( array( 'url' => 'https://dev.example.com', 'n' => array( 1, 'a;b' ) ) ), "line1\nline2\r\n\ttab\0null", '', '\\\\', "a''b", '0x41', 'NULL' );
for ( $i = 0; $i < 3000; $i++ ) {
	$wpdb->insert( 'wp_t_types', array( 'txt' => $tricky[ $i % count( $tricky ) ] . $i, 'bin' => random_bytes( 64 ), 'n' => $i * 1.25, 'd' => '2026-01-01 00:00:00', 'j' => wp_json_encode( array( 'i' => $i, 's' => "x\"y" ) ) ) );
}
$wpdb->insert( 'wp_t_types', array( 'txt' => str_repeat( "big;'row\n", 250000 ), 'bin' => random_bytes( 2 * 1024 * 1024 ), 'n' => 0 ) ); // ~2.2 MB text + 2 MB blob
q( "INSERT INTO wp_t_types (id, txt, d, bits) VALUES (18446744073709551000, 'max bigint', '0000-00-00 00:00:00', b'10101010')" );
q( "INSERT INTO wp_t_types (id, txt) VALUES (0, 'zero id')" );
q( 'CREATE TABLE wp_t_nopk ( a INT, b VARCHAR(50) ) ENGINE=InnoDB' );
for ( $i = 0; $i < 2500; $i++ ) { $wpdb->insert( 'wp_t_nopk', array( 'a' => $i % 7, 'b' => 'dup' ) ); }
q( 'CREATE TABLE wp_t_cpk ( a INT, b VARCHAR(20), v TEXT, PRIMARY KEY (a,b) ) ENGINE=MyISAM' );
for ( $i = 0; $i < 1200; $i++ ) { $wpdb->insert( 'wp_t_cpk', array( 'a' => $i % 30, 'b' => 'k' . $i, 'v' => "v;$i" ) ); }
q( 'CREATE TABLE other_table ( id INT PRIMARY KEY )' );
for ( $i = 1; $i <= 50; $i++ ) { wp_insert_post( array( 'post_title' => "Post $i 😀", 'post_content' => "Content <a href='https://dev.example.com/x'>link</a>; it's $i", 'post_status' => 'publish' ) ); }
update_option( 'blogname', 'Src' );
update_option( 'wstm_test_opt', array( 'nested' => array( 'a' => 'b' ) ) );

$P = fresh();
$scanner = new \WSTM\Database\TableScanner( $P->db() );
$default = $scanner->default_tables();
check( 'scanner: site tables selected by default', in_array( 'wp_posts', $default, true ) && in_array( 'wp_t_types', $default, true ) );
check( 'scanner: other-prefix & internal tables excluded', ! in_array( 'other_table', $default, true ) && ! in_array( 'wp_wstm_jobs', $default, true ) );
$before = checksums( $default );

echo "Export (gzip) with simulated crashes\n";
$job = $P->jobs()->create( 'db_export', array( 'tables' => array(), 'gzip' => true ) );
$snap = null; $crashed = 0;
$res = run_job( $job->id, 0, 2000, function ( $n, $st ) use ( $job, &$snap, &$crashed ) {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT checkpoint FROM wp_wstm_jobs WHERE id=%d", $job->id ), ARRAY_A );
	$cp  = json_decode( $row['checkpoint'], true );
	if ( 3 === $n || 6 === $n ) { $snap = $row['checkpoint']; }
	if ( ( 4 === $n || 8 === $n ) && $snap && ! empty( $cp['file'] ) && 'running' === $st['status'] ) {
		// Simulate a request killed after writing but before its checkpoint was saved.
		file_put_contents( $cp['file'], random_bytes( 5000 ), FILE_APPEND );
		$wpdb->update( 'wp_wstm_jobs', array( 'checkpoint' => $snap ), array( 'id' => $job->id ) );
		$crashed++;
	}
} );
$job = fresh()->jobs()->get( $job->id );
check( 'export completed across many requests', 'completed' === $job->status && $res['runs'] > 3, json_encode( $res ) );
check( 'two crashes simulated and recovered', 2 === $crashed );
$dump     = $P->storage()->area( 'packages' ) . '/' . $job->metadata['file'];
$manifest = \WSTM\Database\DumpManifest::read( \WSTM\Database\DumpManifest::path_for( $dump ) );
check( 'manifest checksum matches file', $manifest['checksum']['hash'] === \WSTM\Database\BlockHasher::file( $dump ) );
check( 'gzip file valid and complete', str_ends_with( rtrim( gunzip( $dump ) ), '-- WSTM:END' ) );
$counts = array_column( $manifest['tables'], 'rows', 'name' );
check( 'row counts exact (types/nopk/cpk)', 3003 === $counts['wp_t_types'] && 2500 === $counts['wp_t_nopk'] && 1200 === $counts['wp_t_cpk'], json_encode( array_intersect_key( $counts, array_flip( array( 'wp_t_types', 'wp_t_nopk', 'wp_t_cpk' ) ) ) ) );
check( 'dump file protected inside storage', str_contains( $dump, 'wstm-storage-' ) );
$sql = gunzip( $dump );
preg_match( "/CREATE TABLE `wp_t_types`[^;]*;/", $sql, $cm ); check( "AUTO_INCREMENT & charset/collation preserved in CREATE", (bool) preg_match( "/AUTO_INCREMENT=\\d+ .*COLLATE=utf8mb4_unicode_ci/", $cm[0] ?? "" ) );

echo "Export (plain SQL)\n";
$job2 = fresh()->jobs()->create( 'db_export', array( 'tables' => array( 'wp_t_types', 'wp_options' ), 'gzip' => false ) );
$res2 = run_job( $job2->id, 3 );
check( 'plain export completed', 'completed' === $res2['status'] );
$plain = $P->storage()->area( 'packages' ) . '/' . fresh()->jobs()->get( $job2->id )->metadata['file'];
check( 'plain dump is .sql', str_ends_with( $plain, '.sql' ) );

echo "Low-memory export (memory_limit=64M, 120k rows)\n";
q( 'DROP TABLE IF EXISTS wp_t_big' );
q( 'CREATE TABLE wp_t_big ( id INT AUTO_INCREMENT PRIMARY KEY, payload VARCHAR(600) ) ENGINE=InnoDB' );
q( "INSERT INTO wp_t_big (payload) SELECT REPEAT(MD5(RAND()), 18) FROM information_schema.columns a, information_schema.columns b LIMIT 120000" );
$big = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM wp_t_big' );
$job3 = fresh()->jobs()->create( 'db_export', array( 'tables' => array( 'wp_t_big' ), 'gzip' => true ) );
$res3 = run_job( $job3->id, 5, 2000, null, 'php -d memory_limit=64M' );
$m3 = \WSTM\Database\DumpManifest::read( \WSTM\Database\DumpManifest::path_for( $P->storage()->area( 'packages' ) . '/' . fresh()->jobs()->get( $job3->id )->metadata['file'] ) );
check( "low-memory export completed ($big rows, peak " . round( $res3['peak'] / 1048576, 1 ) . ' MB)', 'completed' === $res3['status'] && $m3['tables'][0]['rows'] === $big, json_encode( $res3 ) );
q( 'DROP TABLE wp_t_big' );
foreach ( array( $P->storage()->area( 'packages' ) . '/' . fresh()->jobs()->get( $job3->id )->metadata['file'] ) as $f ) { @unlink( $f ); @unlink( \WSTM\Database\DumpManifest::path_for( $f ) ); }

echo "Modify the site, then import the gzip dump\n";
q( "DELETE FROM wp_posts WHERE post_title LIKE 'Post 1%'" );
q( 'TRUNCATE wp_t_types' );
q( 'DROP TABLE wp_t_nopk' );
update_option( 'blogname', 'CHANGED' );
q( 'CREATE TABLE wp_t_new ( id INT PRIMARY KEY )' );
q( 'INSERT INTO wp_t_new VALUES (1),(2)' );
$settings_before = get_site_option( 'wstm_settings' );
$changed = checksums( array( 'wp_options', 'wp_posts' ) );

// Make the 4 MB row fail first: lower max_allowed_packet so the import errors, then fix and resume.
q( 'SET GLOBAL max_allowed_packet=1048576' );
$imp = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => basename( $dump ), 'confirmed' => true, 'safety_backup' => true ) );
$r = run_job( $imp->id, 2 );
$imp = fresh()->jobs()->get( $imp->id );
check( 'import fails cleanly on oversized statement', 'failed' === $imp->status && ! empty( $imp->error['resumable'] ), json_encode( $imp->error ) );
check( 'error explains packet size + action', str_contains( (string) ( $imp->error['action'] ?? '' ), 'max_allowed_packet' ), (string) ( $imp->error['action'] ?? '' ) );
check( 'live tables untouched after failed import', $changed['wp_posts'] === checksums( array( 'wp_posts' ) )['wp_posts'] && 'CHANGED' === $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name='blogname'" ) );
check( 'temp tables exist mid-import', (bool) $wpdb->get_var( "SHOW TABLES LIKE 'wstmi\\_%'" ) );
$offset_at_fail = (int) $imp->checkpoint['offset'];
q( 'SET GLOBAL max_allowed_packet=67108864' );
fresh()->jobs()->resume( $imp->id );
$r = run_job( $imp->id, 2 );
$imp = fresh()->jobs()->get( $imp->id );
check( 'import resumed from checkpoint and completed', 'completed' === $imp->status, json_encode( $imp->error ) );
check( 'resume did not restart from zero', $offset_at_fail > 0 );
$after = checksums( $default );
$diff = array_keys( array_diff_assoc( $before, $after ) );
// wp_options legitimately differs only if WP wrote cron/transients after the export; compare all except options first.
$strict = array_diff( $diff, array( 'wp_options' ) );
check( 'all tables byte-identical to source (CHECKSUM TABLE)', ! $strict, 'diff: ' . implode( ',', $diff ) );
check( 'restored blogname from dump', 'Src' === $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name='blogname'" ) );
check( 'BIT value preserved', 'AA' === $wpdb->get_var( 'SELECT HEX(bits) FROM wp_t_types WHERE id=18446744073709551000' ) );
check( 'tricky values round-trip', $tricky[0] . '0' === $wpdb->get_var( 'SELECT txt FROM wp_t_types WHERE id=5' ) && "emoji 😀🚀 ünïcødé 中文1" === $wpdb->get_var( 'SELECT txt FROM wp_t_types WHERE id=6' ) );
check( 'zero id & max bigint & zero date preserved', '1' === $wpdb->get_var( "SELECT COUNT(*) FROM wp_t_types WHERE id=0" ) && '0000-00-00 00:00:00' === $wpdb->get_var( 'SELECT d FROM wp_t_types WHERE id=18446744073709551000' ) );
check( 'dropped table restored (no-PK, duplicates kept)', 2500 === (int) $wpdb->get_var( 'SELECT COUNT(*) FROM wp_t_nopk' ) );
check( 'table not in dump left untouched', 2 === (int) $wpdb->get_var( 'SELECT COUNT(*) FROM wp_t_new' ) );
check( 'rollback copies kept (wstmo_)', (bool) $wpdb->get_var( "SHOW TABLES LIKE 'wstmo\\_wp\\_posts'" ) && ! $wpdb->get_var( "SHOW TABLES LIKE 'wstmi\\_%'" ) );
wp_cache_flush();
check( 'plugin settings preserved & still active', get_site_option( 'wstm_settings' ) == $settings_before && in_array( 'wp-site-transfer-manager/wp-site-transfer-manager.php', (array) get_option( 'active_plugins' ), true ) );
$safety = $imp->metadata['safety_backup'] ?? '';
check( 'safety backup created + recorded', $safety && is_file( $P->storage()->area( 'backups' ) . '/' . $safety ) && (int) $wpdb->get_var( 'SELECT COUNT(*) FROM wp_wstm_backups WHERE is_safety=1' ) >= 1 );
check( 'safety backup contains pre-import state', str_contains( gunzip( $P->storage()->area( 'backups' ) . '/' . $safety ), 'CHANGED' ) );
check( 'work files cleaned up', ! is_dir( $imp->checkpoint['work_dir'] ?? '/nonexistent' ) || ! file_exists( $imp->checkpoint['work_dir'] . '/import.sql' ) );

echo "Safety: corrupted, truncated, wrong-prefix, cancelled imports never touch live data\n";
$live = checksums( array( 'wp_posts', 'wp_t_types', 'wp_t_nopk' ) ); $live_name = get_option( 'blogname' );
$pk   = $P->storage()->area( 'packages' );
// Corrupted (manifest kept).
$bad1 = $pk . '/corrupt-test.sql.gz';
copy( $dump, $bad1 );
$h = fopen( $bad1, 'r+b' ); fseek( $h, (int) ( filesize( $bad1 ) / 2 ) ); $c = fread( $h, 1 ); fseek( $h, (int) ( filesize( $bad1 ) / 2 ) ); fwrite( $h, chr( ord( $c ) ^ 0x55 ) ); fclose( $h );
copy( \WSTM\Database\DumpManifest::path_for( $dump ), \WSTM\Database\DumpManifest::path_for( $bad1 ) );
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => 'corrupt-test.sql.gz', 'confirmed' => true, 'safety_backup' => false ) );
run_job( $j->id, 3 );
$j = fresh()->jobs()->get( $j->id );
check( 'corrupted dump rejected by checksum', 'failed' === $j->status && str_contains( (string) $j->error['why'], 'SHA-256' ), json_encode( $j->error ) );
fresh()->jobs()->cancel( $j->id );
// Truncated, no manifest.
$bad2 = $pk . '/truncated-test.sql';
file_put_contents( $bad2, substr( file_get_contents( $plain ), 0, (int) ( filesize( $plain ) * 0.7 ) ) );
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => 'truncated-test.sql', 'confirmed' => true, 'safety_backup' => false ) );
run_job( $j->id, 3 );
$j = fresh()->jobs()->get( $j->id );
check( 'truncated dump detected', 'failed' === $j->status && 'sql_truncated' === ( $j->error['code'] ?? '' ) || ( 'failed' === $j->status && str_contains( json_encode( $j->error ), 'truncated' ) ), json_encode( $j->error ) );
fresh()->jobs()->cancel( $j->id );
check( 'cancel drops temp tables', ! $wpdb->get_var( "SHOW TABLES LIKE 'wstmi\\_%'" ) );
// Wrong prefix.
$m = json_decode( file_get_contents( \WSTM\Database\DumpManifest::path_for( $bad1 ) ), true );
copy( $dump, $bad1 );
$m['table_prefix'] = 'xyz_';
file_put_contents( \WSTM\Database\DumpManifest::path_for( $bad1 ), json_encode( $m ) );
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => 'corrupt-test.sql.gz', 'confirmed' => true ) );
run_job( $j->id, 3 );
check( 'prefix mismatch refused', 'prefix_mismatch' === ( fresh()->jobs()->get( $j->id )->error['code'] ?? '' ) );
fresh()->jobs()->cancel( $j->id );
// Not confirmed.
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => basename( $dump ) ) );
run_job( $j->id, 3 );
check( 'unconfirmed import refused', 'not_confirmed' === ( fresh()->jobs()->get( $j->id )->error['code'] ?? '' ) );
fresh()->jobs()->cancel( $j->id );
// Cancel mid-import.
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => basename( $plain ), 'confirmed' => true, 'safety_backup' => false ) );
$n = 0;
run_job( $j->id, 0, 2000, function ( $runs, $st ) use ( $j, &$n ) { if ( 3 === $runs ) { fresh()->jobs()->cancel( $j->id ); } } );
check( 'cancelled mid-import', 'cancelled' === fresh()->jobs()->get( $j->id )->status && ! $wpdb->get_var( "SHOW TABLES LIKE 'wstmi\\_%'" ) );
wp_cache_flush(); check( 'live data unchanged by all failed/cancelled imports', $live === checksums( array( 'wp_posts', 'wp_t_types', 'wp_t_nopk' ) ) && $live_name === $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name='blogname'" ) );
// Path traversal via job metadata.
$j = fresh()->jobs()->create( 'db_import', array( 'area' => 'packages', 'file' => '../../wp-config.sql', 'confirmed' => true ) );
run_job( $j->id, 3 );
check( 'path traversal in import source refused', 'failed' === fresh()->jobs()->get( $j->id )->status );
fresh()->jobs()->cancel( $j->id );
$j = fresh()->jobs()->create( 'db_import', array( 'area' => '../etc', 'file' => 'x.sql', 'confirmed' => true ) );
run_job( $j->id, 3 );
check( 'invalid storage area refused', 'bad_source' === ( fresh()->jobs()->get( $j->id )->error['code'] ?? '' ) );
fresh()->jobs()->cancel( $j->id );
@unlink( $bad1 ); @unlink( \WSTM\Database\DumpManifest::path_for( $bad1 ) ); @unlink( $bad2 );

echo "REST\n";
do_action( 'rest_api_init' );
$srv = rest_get_server();
$res = $srv->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/database/tables' ) );
check( 'GET database/tables', 200 === $res->get_status() && ! empty( $res->get_data()['tables'] ) );
$res = $srv->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/database/dumps' ) );
check( 'GET database/dumps lists exports + safety backups', 200 === $res->get_status() && count( array_unique( array_column( $res->get_data(), 'area' ) ) ) === 2 );
$req = new WP_REST_Request( 'POST', '/wstm/v1/database/import' ); $req->set_body_params( array( 'area' => 'packages', 'file' => basename( $dump ) ) );
$res = $srv->dispatch( $req );
check( 'REST import without confirm rejected', 400 === $res->get_status() );
$req = new WP_REST_Request( 'POST', '/wstm/v1/database/import' ); $req->set_body_params( array( 'area' => 'packages', 'file' => '../x.sql', 'confirm' => true ) );
check( 'REST import rejects traversal filename', 400 === $srv->dispatch( $req )->get_status() );
$res = $srv->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/database/previous' ) );
check( 'GET database/previous', 200 === $res->get_status() && count( $res->get_data() ) > 0 );
wp_set_current_user( 0 );
check( 'anonymous denied', in_array( $srv->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/database/dumps' ) )->get_status(), array( 401, 403 ), true ) );
wp_set_current_user( 1 );
$req = new WP_REST_Request( 'POST', '/wstm/v1/database/previous/delete' ); $req->set_body_params( array( 'confirm' => true ) );
$res = $srv->dispatch( $req );
if ( 200 !== $res->get_status() ) { print_r( $res->get_data() ); }
check( 'rollback copies deleted on request', 200 === $res->get_status() && ! $wpdb->get_var( "SHOW TABLES LIKE 'wstmo\\_%'" ) );

echo "Admin pages\n";
require_once WSTM_PATH . 'admin/class-admin.php';
set_current_screen( 'dashboard' );
$admin = new \WSTM\Admin\Admin( fresh() );
foreach ( array( 'export', 'import', '' ) as $sub ) {
	ob_start(); $admin->render( $sub ); $html = ob_get_clean();
	check( "render $sub", str_contains( $html, 'wstm-wrap' ) && ! preg_match( '/(Warning|Notice|Fatal error|Deprecated):/', $html ) );
}

echo "\n$ok passed, $bad failed\n";
