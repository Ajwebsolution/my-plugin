<?php
// One-click export → restore into a DIFFERENT site (other DB, other table prefix, other URL).
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function env( $db, $pfx ) { return 'WSTM_DB=' . $db . ' WSTM_PREFIX=' . $pfx . ' '; }
function php_run( $db, $pfx, $code ) { return (string) shell_exec( env( $db, $pfx ) . 'php -r ' . escapeshellarg( 'require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function run_job( $db, $pfx, $id, $budget = 3, $max = 4000 ) {
	for ( $i = 0; $i < $max; $i++ ) {
		$out = (string) shell_exec( env( $db, $pfx ) . 'php ' . __DIR__ . '/run.php ' . $id . ' ' . $budget . ' 2>&1' );
		$st  = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN OUTPUT: $out\n"; return array( 'status' => 'crash' ); }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st + array( 'runs' => $i + 1 ); }
	}
	return array( 'status' => 'timeout' );
}
function jget( $db, $pfx, $id ) { return json_decode( php_run( $db, $pfx, 'echo json_encode($P->jobs()->get(' . $id . ')->to_array());' ), true ); }

echo "Source: one-click export (skip revisions + spam, inactive plugins)\n";
$P = \WSTM\Core\Plugin::instance();
$old = home_url();
q: {
	$wpdb->query( "DELETE FROM wp_posts WHERE post_title IN ('P6 test','P6 rev')" );
	$pid = wp_insert_post( array( 'post_title' => 'P6 test', 'post_status' => 'publish', 'post_content' => "<a href='$old/p6'>x</a> <img src='$old/wp-content/uploads/p6.jpg'>" ) );
	wp_insert_post( array( 'post_title' => 'P6 rev', 'post_type' => 'revision', 'post_status' => 'inherit', 'post_parent' => $pid ) );
	update_option( 'p6_opt', array( 'logo' => "$old/wp-content/uploads/logo.png", 'path' => ABSPATH . 'wp-content/uploads' ) );
	wp_mkdir_p( WP_PLUGIN_DIR . '/p6-inactive' ); file_put_contents( WP_PLUGIN_DIR . '/p6-inactive/p6.php', "<?php\n/* Plugin Name: P6 Inactive */" );
	file_put_contents( wp_upload_dir()['basedir'] . '/p6.txt', 'original' ); file_put_contents( wp_upload_dir()['basedir'] . '/p6b.txt', 'b' );
}
$jid = (int) trim( php_run( 'wpsrc', 'wp_', 'do_action("rest_api_init"); $r=new WP_REST_Request("POST","/wstm/v1/migration/export"); $r->set_body_params(array("skip"=>array("revisions"=>true,"spam_comments"=>true,"inactive_plugins"=>true,"inactive_themes"=>true))); $res=rest_get_server()->dispatch($r); echo $res->get_data()["id"] ?? json_encode($res->get_data());' ) );
check( 'export job created via REST', $jid > 0, (string) $jid );
$r = run_job( 'wpsrc', 'wp_', $jid, 5 );
$j = jget( 'wpsrc', 'wp_', $jid );
check( 'export completed', 'completed' === $j['status'], json_encode( $j['error'] ) );
$pkg = $P->storage()->area( 'packages' ) . '/' . $j['metadata']['file'];
$names = array();
foreach ( \WSTM\Archive\ArchiveIndex::entries( $pkg ) as $e ) { $names[ $e['path'] ] = 1; }
check( 'inactive plugin skipped, active theme kept', ! isset( $names['files/plugins/p6-inactive/p6.php'] ) && count( preg_grep( '#^files/themes/' . preg_quote( get_stylesheet(), '#' ) . '/#', array_keys( $names ) ) ) > 0 );
$sql = shell_exec( 'mkdir -p /tmp/claude-0/p6x && cd /tmp/claude-0/p6x && php -r ' . escapeshellarg( 'define("ABSPATH","/");require "/home/claude/wp-site-transfer-manager/includes/compat.php";require "/home/claude/wp-site-transfer-manager/includes/Core/Autoloader.php";\WSTM\Core\Autoloader::register("WSTM\\\\","/home/claude/wp-site-transfer-manager/includes/");function wp_mkdir_p($d){return is_dir($d)||mkdir($d,0777,true);}function wp_delete_file($f){@unlink($f);}function wp_normalize_path($p){return $p;}$s=\WSTM\Archive\ArchiveExtractor::init_state("' . $pkg . '");while(!$s["done"])$s=\WSTM\Archive\ArchiveExtractor::step($s,fn($h)=>str_starts_with($h["path"],"database")?["/tmp/claude-0/p6x",$h["path"]]:null,PHP_INT_MAX);' ) . ' && zcat /tmp/claude-0/p6x/database.sql.gz' );
check( 'revisions filtered from DB dump', str_contains( (string) $sql, 'P6 test' ) && ! str_contains( (string) $sql, 'P6 rev' ) );

echo "Destination: separate site (DB wpp6, prefix abc_, URL http://dest.test/sub)\n";
shell_exec( 'mysql -uwp -pwp -e "DROP DATABASE IF EXISTS wpp6; CREATE DATABASE wpp6"' );
php_run( 'wpp6', 'abc_', 'update_option("home","http://dest.test/sub"); update_option("siteurl","http://dest.test/sub"); wp_insert_user(array("user_login"=>"destadmin","user_pass"=>"x","role"=>"administrator"));' );
$dst_pkgdir = trim( php_run( 'wpp6', 'abc_', 'echo $P->storage()->area("packages");' ) );
copy( $pkg, $dst_pkgdir . '/moved.wpmig' );
// Simulate destination differences the restore must fix.
file_put_contents( wp_upload_dir()['basedir'] . '/p6.txt', 'destination version' );
@unlink( wp_upload_dir()['basedir'] . '/p6b.txt' );

$start = json_decode( php_run( 'wpp6', 'abc_', 'do_action("rest_api_init"); $r=new WP_REST_Request("POST","/wstm/v1/migration/import"); $r->set_body_params(array("file"=>"moved.wpmig","confirm"=>true)); echo json_encode(rest_get_server()->dispatch($r)->get_data());' ), true );
check( 'restore job created with driver token', ! empty( $start['id'] ) && 64 === strlen( $start['token'] ?? '' ), json_encode( $start ) );
// Drive the job ONLY via the token endpoint (no login), as the browser does after the user table changes.
$id = (int) $start['id']; $tok = $start['token']; $status = ''; $calls = 0;
$bad_tok = php_run( 'wpp6', 'abc_', 'wp_set_current_user(0); do_action("rest_api_init"); $r=new WP_REST_Request("POST","/wstm/v1/migration/run/' . $id . '"); $r->set_param("token", str_repeat("0",64)); echo rest_get_server()->dispatch($r)->get_status();' );
check( 'wrong token rejected', '403' === trim( $bad_tok ), $bad_tok );
do {
	$out = php_run( 'wpp6', 'abc_', 'wp_set_current_user(0); do_action("rest_api_init"); $r=new WP_REST_Request("POST","/wstm/v1/migration/run/' . $id . '"); $r->set_param("token","' . $tok . '"); $res=rest_get_server()->dispatch($r); echo json_encode(array($res->get_status(), $res->get_data()["status"] ?? null, $res->get_data()["error"] ?? null, $res->get_data()["current_step"] ?? null));' );
	$d = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
	if ( ! $d ) { echo "OUT: $out\n"; break; }
	$status = $d[1]; $calls++;
} while ( in_array( $status, array( 'running', 'pending' ), true ) && $calls < 500 );
check( 'restore completed via token-driven requests', 'completed' === $status, json_encode( $d ) );

$res = json_decode( php_run( 'wpp6', 'abc_', 'global $wpdb; wp_cache_flush(); $p=$wpdb->get_row("SELECT post_content FROM abc_posts WHERE post_title=\'P6 test\'"); $u=wp_authenticate("admin","pw"); echo json_encode(array(
	"home"=>get_option("home"), "content"=>$p?$p->post_content:null, "opt"=>get_option("p6_opt"),
	"roles"=>(bool)get_option("abc_user_roles"), "admin_ok"=>!is_wp_error($u) && user_can($u,"manage_options"),
	"destadmin"=>(bool)get_user_by("login","destadmin"), "wp_tables"=>$wpdb->get_var("SHOW TABLES LIKE \'wp\\\\_posts\'") && false,
	"plugin_active"=>is_plugin_active("wp-site-transfer-manager/wp-site-transfer-manager.php"), "storage"=>$P->storage()->area("packages"),
	"leftover_tmp"=>(int)$wpdb->get_var("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=\'wpp6\' AND table_name LIKE \'wstmi\\\\_%\'"),
));' ), true );
check( 'site URL kept as destination', 'http://dest.test/sub' === ( $res['home'] ?? '' ), json_encode( $res ) );
check( 'content URLs rewritten to destination', str_contains( (string) $res['content'], 'http://dest.test/sub/p6' ) && ! str_contains( (string) $res['content'], $old ) );
check( 'serialized option URL + server path rewritten', ( $res['opt']['logo'] ?? '' ) === 'http://dest.test/sub/wp-content/uploads/logo.png' );
check( 'prefix converted: abc_user_roles + capabilities', ! empty( $res['roles'] ) && ! empty( $res['admin_ok'] ) );
check( 'source users now active (dest-only user gone)', empty( $res['destadmin'] ) );
check( 'plugin still active, storage kept', ! empty( $res['plugin_active'] ) && $res['storage'] === $dst_pkgdir );
check( 'no temporary tables left', 0 === ( $res['leftover_tmp'] ?? -1 ) );
check( 'files restored (changed file overwritten, deleted file back)', 'original' === file_get_contents( wp_upload_dir()['basedir'] . '/p6.txt' ) && 'b' === @file_get_contents( wp_upload_dir()['basedir'] . '/p6b.txt' ) );
$jj = jget( 'wpp6', 'abc_', $id );
check( 'replaced files kept in rollback folder', is_file( $jj['metadata']['rollback_folder'] . '/uploads/p6.txt' ) && 'destination version' === file_get_contents( $jj['metadata']['rollback_folder'] . '/uploads/p6.txt' ) );
check( 'safety backup of destination DB created', ! empty( $jj['metadata']['safety_backup'] ) );
check( 'staging cleaned up', ! is_dir( dirname( $jj['metadata']['rollback_folder'] ) . '/../tmp/' ) || ! glob( dirname( $jj['metadata']['rollback_folder'] ) . '/../tmp/*/staging' ) );

exec( 'rm -rf ' . escapeshellarg( WP_PLUGIN_DIR . '/p6-inactive' ) );
echo "\n$ok passed, $bad failed\n";
