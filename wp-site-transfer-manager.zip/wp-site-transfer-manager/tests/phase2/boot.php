<?php
$_SERVER['HTTP_HOST'] = 'example.test'; $_SERVER['REQUEST_URI'] = '/'; $_SERVER['SERVER_NAME'] = 'example.test';
if ( ! defined( 'WP_INSTALLING' ) && ! (int) shell_exec( "mysql -u" . ( getenv( 'WSTM_DB_USER' ) ?: 'wp' ) . " -p" . ( getenv( 'WSTM_DB_PASS' ) ?: 'wp' ) . " -N -e \"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='" . ( getenv( 'WSTM_DB' ) ?: 'wpsrc' ) . "' AND table_name='" . ( getenv( 'WSTM_PREFIX' ) ?: 'wp_' ) . "options'\" 2>/dev/null" ) ) { define( 'WP_INSTALLING', true ); }
require ( getenv( 'WP_PATH' ) ?: dirname( __DIR__ ) . '/wpm' ) . '/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
if ( ! is_blog_installed() ) { wp_install( 'Src', 'admin', 'a@example.test', true, '', 'pw' ); }
wp_set_current_user( 1 );
if ( ! class_exists( '\WSTM\Core\Plugin' ) ) {
	activate_plugin( 'wp-site-transfer-manager/wp-site-transfer-manager.php' );
}
$P = \WSTM\Core\Plugin::instance();
wp_set_current_user( 0 ); wp_set_current_user( 1 );
