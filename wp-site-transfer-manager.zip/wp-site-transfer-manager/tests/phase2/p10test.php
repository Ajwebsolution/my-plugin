<?php
// Phase 10: S3-compatible cloud storage (SigV4, multipart, ranged download, list, delete) against moto.
require __DIR__ . '/boot.php';
global $wpdb;
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
function php_run( $code ) { return (string) shell_exec( 'php -r ' . escapeshellarg( 'require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function rest( $method, $route, $params = array(), $user = 1 ) {
	$out = php_run( 'wp_set_current_user(' . $user . '); do_action("rest_api_init"); $r=new WP_REST_Request("' . $method . '","/wstm/v1' . $route . '"); $r->set_body_params(' . var_export( $params, true ) . '); $res=rest_get_server()->dispatch($r); echo "\n@@" . json_encode(array($res->get_status(), $res->get_data()));' );
	return json_decode( substr( $out, strrpos( $out, '@@' ) + 2 ), true );
}
function run_job( $id ) {
	for ( $i = 0; $i < 3000; $i++ ) {
		$out = (string) shell_exec( 'php ' . __DIR__ . '/run.php ' . $id . ' 3 2>&1' );
		$st  = json_decode( trim( substr( $out, strrpos( rtrim( $out ), "\n" ) ?: 0 ) ), true );
		if ( ! $st ) { echo "RUN: $out\n"; return 'crash'; }
		if ( ! in_array( $st['status'], array( 'running', 'pending' ), true ) ) { return $st['status'] . ( $st['error'] ? ' ' . json_encode( $st['error'] ) : '' ); }
	}
	return 'timeout';
}
$P = \WSTM\Core\Plugin::instance();
$wpdb->query( "DELETE FROM wp_options WHERE option_name='wstm_cloud'" );
$wpdb->query( 'TRUNCATE wp_wstm_jobs' );

echo "SigV4 (AWS documented test vector: GET Object with Range)\n";
$c = new \WSTM\Cloud\S3Client( 'https://s3.amazonaws.com', 'us-east-1', 'examplebucket', 'AKIAIOSFODNN7EXAMPLE', 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', false );
$h = $c->sign( 'GET', 'examplebucket.s3.amazonaws.com', '/test.txt', array(), array( 'range' => 'bytes=0-9' ), hash( 'sha256', '' ), gmmktime( 0, 0, 0, 5, 24, 2013 ) );
check( 'signature matches AWS example', str_ends_with( $h['authorization'], 'Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41' ), $h['authorization'] );
check( 'secret hidden from var_dump', ! str_contains( print_r( $c, true ), 'wJalr' ) );
check( 'canonical query sorted/encoded', 'a=1&b=x%2Fy&uploads=' === \WSTM\Cloud\S3Client::canonical_query( array( 'uploads' => '', 'b' => 'x/y', 'a' => '1' ) ) );

echo "Destination settings\n";
$bad_http = rest( 'POST', '/cloud', array( 'endpoint' => 'http://s3.example.com', 'bucket' => 'b1', 'access_key' => 'AK', 'secret_key' => 'SK' ) );
check( 'plain-http remote endpoint rejected', 400 === $bad_http[0] && 'cloud_insecure' === $bad_http[1]['code'] );
check( 'missing keys rejected', 400 === rest( 'POST', '/cloud', array( 'endpoint' => 'http://127.0.0.1:5055', 'bucket' => 'wstm-bkt' ) )[0] );
check( 'subscriber denied', in_array( rest( 'GET', '/cloud', array(), 0 )[0], array( 401, 403 ), true ) );
$secret = 'TOP-SECRET-' . wp_generate_password( 12, false );
$s = rest( 'POST', '/cloud', array( 'label' => 'Moto', 'endpoint' => 'http://127.0.0.1:5055', 'region' => 'us-east-1', 'bucket' => 'wstm-bkt', 'prefix' => 'site-a/', 'path_style' => true, 'access_key' => 'AKIAMOTOTESTKEY01', 'secret_key' => $secret ) );
check( 'destination saved', 200 === $s[0] && 'Moto' === $s[1]['label'], json_encode( $s ) );
$id = $s[1]['id'];
$list = rest( 'GET', '/cloud' );
$json = json_encode( $list );
check( 'REST never returns secret; access key masked', ! str_contains( $json, $secret ) && ! str_contains( $json, 'AKIAMOTOTESTKEY01' ) && $list[1]['destinations'][0]['has_secret'] );
$raw = (string) $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name='wstm_cloud'" );
check( 'secret encrypted at rest', ! str_contains( $raw, $secret ) && ( str_contains( $raw, 's1:' ) || str_contains( $raw, 'o1:' ) ) );
$u = rest( 'POST', '/cloud', array( 'id' => $id, 'label' => 'Moto 2', 'endpoint' => 'http://127.0.0.1:5055', 'bucket' => 'wstm-bkt', 'prefix' => 'site-a', 'path_style' => true, 'access_key' => $list[1]['destinations'][0]['access_key'] ) );
$opt = fn() => maybe_unserialize( $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name='wstm_cloud'" ) );
check( 'edit without secret keeps secret + key', 200 === $u[0] && $secret === \WSTM\Security\Crypto::decrypt( $opt()[ $id ]['secret_enc'] ) && 'AKIAMOTOTESTKEY01' === $opt()[ $id ]['access_key'] );
$t = rest( 'POST', "/cloud/$id/test" );
check( 'test connection ok', 200 === $t[0] && $t[1]['ok'], json_encode( $t ) );
check( 'destination offered for backups', in_array( $id, array_column( rest( 'GET', '/backups' )[1]['clouds'], 'id' ), true ) );

echo "Backup → cloud (multipart)\n";
$up = wp_upload_dir()['basedir'];
@mkdir( "$up/p10" );
file_put_contents( "$up/p10/big.bin", random_bytes( 19 * 1024 * 1024 ) ); // incompressible → multipart (3 parts)
$j = rest( 'POST', '/backups/create', array( 'type' => 'full', 'mode' => 'full', 'label' => 'Cloud', 'cloud' => $id ) );
$st = run_job( $j[1]['id'] );
check( 'backup with cloud upload completed', 'completed' === $st, $st );
$job = $P->jobs()->get( $j[1]['id'] );
$bk  = rest( 'GET', '/backups' )[1]['backups'][0];
check( 'backup records cloud location', ( $bk['meta']['cloud']['destination'] ?? '' ) === $id && str_starts_with( $bk['meta']['cloud']['key'], 'site-a/' ), json_encode( $bk['meta']['cloud'] ?? null ) );
$local = $P->storage()->area( 'backups' ) . '/' . $bk['file'];
check( 'backup large enough for multipart', filesize( $local ) > \WSTM\Cloud\S3Destination::PART_SIZE * 2 );
$f = rest( 'GET', "/cloud/$id/files" );
$remote = array_values( array_filter( $f[1]['files'] ?? array(), fn( $x ) => $x['name'] === $bk['file'] ) );
check( 'listed in cloud with same size', $remote && $remote[0]['size'] === filesize( $local ), json_encode( $f ) );

echo "Cloud → this site (ranged download)\n";
check( 'non-package key rejected', 400 === rest( 'POST', "/cloud/$id/fetch", array( 'key' => 'site-a/../../evil.php' ) )[0] );
@unlink( $P->storage()->path( 'packages', $bk['file'] ) );
$fj = rest( 'POST', "/cloud/$id/fetch", array( 'key' => $remote[0]['key'] ) );
$st = run_job( $fj[1]['id'] );
check( 'fetch completed', 'completed' === $st, $st . json_encode( $fj ) );
$got = $P->storage()->path( 'packages', $bk['file'] );
check( 'downloaded file identical', is_file( $got ) && hash_file( 'sha256', $got ) === hash_file( 'sha256', $local ) );
$vj = rest( 'POST', '/packages/validate', array( 'file' => $bk['file'] ) );
if ( 200 === $vj[0] ) { check( 'downloaded package validates', 'completed' === run_job( $vj[1]['id'] ) ); }
check( 'second fetch refuses to overwrite', 400 === rest( 'POST', "/cloud/$id/fetch", array( 'key' => $remote[0]['key'] ) )[0] || str_contains( run_job( rest( 'POST', "/cloud/$id/fetch", array( 'key' => $remote[0]['key'] ) )[1]['id'] ), 'cloud_exists' ) );

echo "Delete\n";
check( 'delete requires confirm', 400 === rest( 'POST', "/cloud/$id/files/delete", array( 'key' => $remote[0]['key'] ) )[0] );
check( 'delete outside folder refused', 400 === rest( 'POST', "/cloud/$id/files/delete", array( 'key' => 'other/x.wpmig', 'confirm' => true ) )[0] );
check( 'delete ok', 200 === rest( 'POST', "/cloud/$id/files/delete", array( 'key' => $remote[0]['key'], 'confirm' => true ) )[0] );
check( 'gone from listing', ! array_filter( rest( 'GET', "/cloud/$id/files" )[1]['files'], fn( $x ) => $x['key'] === $remote[0]['key'] ) );

echo "Errors\n";
$o = $opt(); $o[ $id ]['bucket'] = 'no-such-bucket-p10'; $wpdb->update( 'wp_options', array( 'option_value' => serialize( $o ) ), array( 'option_name' => 'wstm_cloud' ) );
$t = rest( 'POST', "/cloud/$id/test" );
check( 'missing bucket reported clearly', 200 === $t[0] && ! $t[1]['ok'] && str_contains( $t[1]['message'], 'NoSuchBucket' ), json_encode( $t ) );
$logs = (string) $wpdb->get_var( "SELECT GROUP_CONCAT(message, context) FROM wp_wstm_logs" );
check( 'secret never logged', ! str_contains( $logs, $secret ) );
check( 'remove destination', 200 === rest( 'POST', "/cloud/$id/delete" )[0] && ! rest( 'GET', '/cloud' )[1]['destinations'] );

exec( 'rm -rf ' . escapeshellarg( "$up/p10" ) . ' ' . escapeshellarg( $got ) );
echo "\n$ok passed, $bad failed\n";
exit( $bad ? 1 : 0 );
