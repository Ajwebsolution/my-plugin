<?php
if ( ! function_exists( 'str_starts_with' ) ) { function str_starts_with( $h, $n ) { return 0 === strncmp( (string) $h, (string) $n, strlen( (string) $n ) ); } } // PHP 7.4 (no WordPress loaded here)
if ( ! function_exists( 'str_contains' ) ) { function str_contains( $h, $n ) { return '' === $n || false !== strpos( (string) $h, (string) $n ); } }
// Phase 8: direct transfer between two live sites over HTTP (pull, then push), plus security checks.
$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }
$SITES = array( 'A' => array( 'wpui', 'wp_', 'http://127.0.0.1:8099' ), 'B' => array( 'wpui2', 'xy_', 'http://127.0.0.1:8098' ) );
function cli( $site, $code ) { global $SITES; [ $db, $pfx ] = $SITES[ $site ]; return (string) shell_exec( 'WSTM_DB=' . $db . ' WSTM_PREFIX=' . $pfx . ' php -r ' . escapeshellarg( '$_SERVER["HTTP_HOST"]="' . substr( $SITES[ $site ][2], 7 ) . '"; require "' . __DIR__ . '/boot.php"; ' . $code ) . ' 2>&1' ); }
function rest( $site, $method, $route, $params = array() ) {
	$out = cli( $site, 'wp_set_current_user(1); do_action("rest_api_init"); $r=new WP_REST_Request(' . var_export( $method, true ) . ',' . var_export( '/wstm/v1' . $route, true ) . '); $r->set_body_params(' . var_export( $params, true ) . '); $res=rest_get_server()->dispatch($r); echo "\n@@", json_encode(array($res->get_status(),$res->get_data()));' );
	return json_decode( substr( $out, strrpos( $out, '@@' ) + 2 ), true ) ?: array( 0, $out );
}
function http_post( $url, $body = '', $headers = array() ) {
	$ch = curl_init( $url );
	curl_setopt_array( $ch, array( CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 300, CURLOPT_PROXY => '' ) );
	$res = curl_exec( $ch ); $code = curl_getinfo( $ch, CURLINFO_HTTP_CODE ); curl_close( $ch );
	return array( $code, json_decode( (string) $res, true ), $res );
}
function drive( $base, $id, $token ) {
	for ( $i = 0; $i < 3000; $i++ ) {
		[ $code, $j, $raw ] = http_post( $base . '/index.php?rest_route=/wstm/v1/migration/run/' . $id . '&token=' . $token );
		if ( 200 !== $code ) { return array( 'status' => 'http_' . $code, 'raw' => substr( (string) $raw, 0, 400 ) ); }
		if ( ! in_array( $j['status'], array( 'running', 'pending' ), true ) ) { return $j; }
	}
	return array( 'status' => 'timeout' );
}
foreach ( array( 'A', 'B' ) as $s ) { cli( $s, 'global $wpdb; $wpdb->query("TRUNCATE ".$wpdb->base_prefix."wstm_jobs");' ); }
cli( 'A', 'wp_insert_post(array("post_title"=>"From A ".time(),"post_status"=>"publish","post_content"=>"<a href=\"http://127.0.0.1:8099/x\">x</a>")); update_option("blogname","Site A");' );
cli( 'B', 'update_option("blogname","Site B");' );

echo "Keys & security\n";
[ $st, $k ] = rest( 'A', 'POST', '/transfers/key', array( 'mode' => 'pull', 'minutes' => 15 ) );
check( 'source issues a pull key', 200 === $st && str_starts_with( $k['key'] ?? '', 'wstm1.' ), json_encode( $k ) );
$key = $k['key'];
$tid = $k['transfer_id'];
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', array( 'Content-Type: application/json' ) );
check( 'unsigned request rejected', 403 === $code );
$bad_sig = array( 'X-WSTM-Id: ' . $tid, 'X-WSTM-Time: ' . time(), 'X-WSTM-Nonce: ' . bin2hex( random_bytes( 16 ) ), 'X-WSTM-Sig: ' . str_repeat( 'a', 64 ), 'Content-Type: application/json' );
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', $bad_sig );
check( 'forged signature rejected', 403 === $code );
$secret = json_decode( base64_decode( strtr( substr( $key, 6 ), '-_', '+/' ) ), true )['s'];
$t = (string) time(); $n = bin2hex( random_bytes( 16 ) );
$canon = "POST\n/wstm/v1/transfer/handshake\n\n$t\n$n\n" . hash( 'sha256', '{}' );
$good = array( 'X-WSTM-Id: ' . $tid, 'X-WSTM-Time: ' . $t, 'X-WSTM-Nonce: ' . $n, 'X-WSTM-Sig: ' . hash_hmac( 'sha256', $canon, $secret ), 'Content-Type: application/json' );
[ $code, $hs ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', $good );
check( 'correctly signed handshake accepted', 200 === $code && 'pull' === ( $hs['mode'] ?? '' ), (string) $code );
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', $good );
check( 'replayed request rejected', 403 === $code );
$t2 = (string) ( time() - 900 ); $n2 = bin2hex( random_bytes( 16 ) );
$old = array( 'X-WSTM-Id: ' . $tid, 'X-WSTM-Time: ' . $t2, 'X-WSTM-Nonce: ' . $n2, 'X-WSTM-Sig: ' . hash_hmac( 'sha256', "POST\n/wstm/v1/transfer/handshake\n\n$t2\n$n2\n" . hash( 'sha256', '{}' ), $secret ), 'Content-Type: application/json' );
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', $old );
check( 'stale timestamp rejected', 403 === $code );
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/upload/start', '{}', $good );
check( 'pull key cannot be used for push endpoints', 403 === $code );
$log = cli( 'A', 'global $wpdb; echo $wpdb->get_var("SELECT GROUP_CONCAT(message SEPARATOR \" | \") FROM wp_wstm_logs WHERE channel=\'transfer\'");' );
check( 'secret never written to logs', ! str_contains( $log, $secret ) && str_contains( $log, 'Rejected' ) );
[ $st, $e ] = rest( 'B', 'POST', '/transfers/push', array( 'key' => $key, 'confirm' => true ) );
check( 'pull key refused for push on the other site', 400 === $st && 'wrong_key' === ( $e['code'] ?? '' ) );
[ $st, $e ] = rest( 'B', 'POST', '/transfers/pull', array( 'key' => $key ) );
check( 'unconfirmed pull refused', 400 === $st );

echo "Pull A into B\n";
[ $st, $job ] = rest( 'B', 'POST', '/transfers/pull', array( 'key' => $key, 'confirm' => true, 'skip' => array( 'revisions' => true ) ) );
check( 'pull job started on B', 200 === $st && ! empty( $job['token'] ), json_encode( $job ) );
$r = drive( 'http://127.0.0.1:8098', $job['id'], $job['token'] );
check( 'B pulled and downloaded A', 'completed' === $r['status'] && ! empty( $r['metadata']['child_job'] ), json_encode( $r['error'] ?? $r ) );
$r2 = drive( 'http://127.0.0.1:8098', $r['metadata']['child_job'], $job['token'] );
check( 'B imported A (via token after user switch)', 'completed' === $r2['status'], json_encode( $r2['error'] ?? $r2 ) );
$b = json_decode( cli( 'B', 'wp_cache_flush(); global $wpdb; echo json_encode(array("name"=>get_option("blogname"),"home"=>get_option("home"),"c"=>$wpdb->get_var("SELECT post_content FROM xy_posts WHERE post_title LIKE \'From A %\' ORDER BY ID DESC LIMIT 1")));' ), true );
check( 'B now has A\'s content with B\'s URLs', 'Site A' === ( $b['name'] ?? '' ) && 'http://127.0.0.1:8098' === $b['home'] && str_contains( (string) $b['c'], '127.0.0.1:8098/x' ), json_encode( $b ) );
$ks = cli( 'A', 'global $wpdb; echo $wpdb->get_var("SELECT status FROM wp_wstm_transfers WHERE transfer_id=\'' . $tid . '\'");' );
check( 'key marked used on A after the transfer', str_contains( $ks, 'used' ), $ks );
[ $code ] = http_post( 'http://127.0.0.1:8099/index.php?rest_route=/wstm/v1/transfer/handshake', '{}', $good );
check( 'used key no longer accepted', 403 === $code );

echo "Push A into B\n";
cli( 'A', 'wp_insert_post(array("post_title"=>"Pushed post","post_status"=>"publish"));' );
[ $st, $k2 ] = rest( 'B', 'POST', '/transfers/key', array( 'mode' => 'push', 'minutes' => 15 ) );
check( 'destination issues a push key', 200 === $st, json_encode( $k2 ) );
[ $st, $pj ] = rest( 'A', 'POST', '/transfers/push', array( 'key' => $k2['key'], 'confirm' => true ) );
check( 'push job started on A', 200 === $st, json_encode( $pj ) );
$r3 = drive( 'http://127.0.0.1:8099', $pj['id'], $pj['token'] );
check( 'A pushed itself into B', 'completed' === $r3['status'], json_encode( $r3['error'] ?? $r3 ) );
$c = cli( 'B', 'wp_cache_flush(); global $wpdb; echo $wpdb->get_var("SELECT COUNT(*) FROM xy_posts WHERE post_title=\'Pushed post\'");' );
$a = cli( 'A', 'global $wpdb; echo $wpdb->get_var("SELECT COUNT(*) FROM wp_posts WHERE post_title=\'Pushed post\'");' );
check( 'pushed content present on B (same as A)', (int) trim( $c ) >= 1 && trim( $c ) === trim( $a ), "B=$c A=$a" );
[ $st, $k3 ] = rest( 'A', 'POST', '/transfers/key', array( 'mode' => 'pull' ) );
rest( 'A', 'POST', '/transfers/' . $k3['transfer_id'] . '/revoke' );
[ $st, $e ] = rest( 'B', 'POST', '/transfers/pull', array( 'key' => $k3['key'], 'confirm' => true ) );
$rv = drive( 'http://127.0.0.1:8098', $e['id'], $e['token'] );
check( 'revoked key fails cleanly on the other side', 'failed' === $rv['status'] && str_contains( json_encode( $rv['error'] ), 'rejected' ), json_encode( $rv['error'] ?? $rv ) );
echo "\n$ok passed, $bad failed\n";
