<?php
define('ABSPATH','/tmp/');
require dirname(__DIR__) . '/includes/compat.php';
require dirname(__DIR__) . '/includes/Core/Autoloader.php';
\WSTM\Core\Autoloader::register('WSTM\\',dirname(__DIR__) . '/includes/');
function is_serialized($d){ $d=trim($d); return (bool)preg_match('/^(a|O|s|i|d|b|C|E):/',$d) || $d==='N;'; }
use WSTM\URL\ValueReplacer;
$r=new ValueReplacer([['https://dev.example.com','https://example.org/new']]);
$t=function($name,$in,$exp=null) use($r){ $o=$r->replace($in); $ok = $exp===null ? true : $o===$exp; echo ($ok?'✓':'✕')." $name kind={$r->last['kind']} n={$r->last['count']} err=".json_encode($r->last['error'])."\n"; if(!$ok) echo "   got: $o\n"; return $o; };
$o=$t('serialized nested', serialize(['url'=>'https://dev.example.com/x','n'=>['a'=>'see https://dev.example.com.au and https://dev.example.com'],'obj'=>(object)['u'=>'https://dev.example.com']]));
var_dump(unserialize($o)['n']['a'], unserialize($o)['obj']->u);
$t('serialized in serialized', serialize(['inner'=>serialize(['u'=>'https://dev.example.com/p'])]));
echo "   inner: ".unserialize(unserialize($r->replace(serialize(['inner'=>serialize(['u'=>'https://dev.example.com/p'])])))['inner'])['u']."\n";
$t('json escaped', '{"url":"https:\/\/dev.example.com\/wp-content\/a.jpg","x":1}', '{"url":"https:\/\/example.org\/new\/wp-content\/a.jpg","x":1}');
$t('boundary: .au untouched', 'go https://dev.example.com.au now', 'go https://dev.example.com.au now');
$t('boundary: -staging untouched', 'https://dev.example.com-staging.net', 'https://dev.example.com-staging.net');
$t('end of sentence', 'Visit https://dev.example.com.', 'Visit https://example.org/new.');
$t('html', '<a href="https://dev.example.com/page">x</a>', '<a href="https://example.org/new/page">x</a>');
$t('corrupt serialized left alone', 'a:1:{s:3:"url";s:99:"https://dev.example.com";}', 'a:1:{s:3:"url";s:99:"https://dev.example.com";}');
class Foo implements Serializable{ public $u='https://dev.example.com'; function serialize(){return $this->u;} function unserialize($d){$this->u=$d;} function __serialize(): array {return [];} function __unserialize(array $d): void {} }
$t('C: opaque reported', 'a:1:{i:0;C:3:"Foo":23:{https://dev.example.com}}');
$t('utf8 lengths', serialize(['t'=>'ünï 😀 https://dev.example.com/ü']));
echo unserialize($r->replace(serialize(['t'=>'ünï 😀 https://dev.example.com/ü'])))['t']."\n";
$t('no match fast path', serialize(['x'=>'nothing']));
$t('unknown class preserved', 'O:9:"Missing\X":1:{s:1:"u";s:23:"https://dev.example.com";}', 'O:9:"Missing\X":1:{s:1:"u";s:23:"https://example.org/new";}');
