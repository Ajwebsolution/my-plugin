<?php
// Integration test against a real WordPress (SQLite-backed) install.
$_SERVER['HTTP_HOST'] = 'example.test';
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['SERVER_NAME'] = 'example.test';
define( 'WP_INSTALLING', ! file_exists( ( getenv( 'WP_PATH' ) ?: __DIR__ . '/wp' ) . '/wp-content/database/.ht.sqlite' ) );
require ( getenv( 'WP_PATH' ) ?: __DIR__ . '/wp' ) . '/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';

$ok = 0; $bad = 0;
function check( $name, $cond, $extra = '' ) { global $ok, $bad; if ( $cond ) { $ok++; echo "  ✓ $name\n"; } else { $bad++; echo "  ✕ $name $extra\n"; } }

if ( ! is_blog_installed() ) {
	wp_install( 'Test', 'admin', 'a@example.test', true, '', 'pw' );
}
wp_set_current_user( 1 );

$r = activate_plugin( 'wp-site-transfer-manager/wp-site-transfer-manager.php' );
check( 'activation', ! is_wp_error( $r ), is_wp_error( $r ) ? $r->get_error_message() : '' );
if ( ! class_exists( '\WSTM\Core\Plugin' ) ) { require WP_PLUGIN_DIR . '/wp-site-transfer-manager/wp-site-transfer-manager.php'; }
$p = \WSTM\Core\Plugin::instance(); wp_set_current_user( 0 ); wp_set_current_user( 1 );

global $wpdb;
foreach ( \WSTM\Database\Database::TABLES as $t ) {
	$tables = $p->db()->list_tables( 'tst_wstm_' . $t );
	check( "table tst_wstm_$t exists (prefix respected)", in_array( 'tst_wstm_' . $t, $tables, true ) );
}
check( 'admin has manage_site_migration', current_user_can( 'manage_site_migration' ) );
check( 'cron scheduled', (bool) wp_next_scheduled( 'wstm_cleanup_cron' ) );

// Storage.
$root = $p->storage()->ensure_root();
check( 'storage root randomised', (bool) preg_match( '/wstm-storage-[a-f0-9]{16}$/', $root ) );
foreach ( array( 'index.php', '.htaccess', 'web.config' ) as $f ) check( "protection $f", file_exists( $root . '/backups/' . $f ) );
$jd = $p->storage()->job_dir( wp_generate_uuid4() );
check( 'job dir created', is_dir( $jd ) );
try { $p->storage()->delete_dir( WP_CONTENT_DIR ); check( 'refuses delete outside root', false ); } catch ( \WSTM\Core\WstmException $e ) { check( 'refuses delete outside root', true ); }
touch( $jd, time() - 10 * DAY_IN_SECONDS );
check( 'purge_stale removes old tmp', 1 === $p->storage()->purge_stale( HOUR_IN_SECONDS ) && ! is_dir( $jd ) );

// Logger + redaction.
$p->logger()->info( 'Connecting with password=hunter2', array( 'db_password' => 'x', 'table' => 'posts' ), 'test' );
$p->logger()->debug( 'should be filtered (min level info)' );
$rows = $p->logger()->query( array( 'per_page' => 5 ) )['rows'];
check( 'log written', ! empty( $rows ) );
$dump = wp_json_encode( $rows );
check( 'secrets redacted in logs', ! str_contains( $dump, 'hunter2' ) && str_contains( $dump, 'REDACTED' ) );
check( 'debug filtered by level', ! str_contains( $dump, 'should be filtered' ) );

// Settings.
$errs = $p->settings()->save( array( 'db_batch_rows' => 10, 'chunk_size' => 'auto', 'log_level' => 'info', 'time_budget' => 20, 'backup_retention' => 5, 'log_retention_days' => 30, 'temp_retention_hours' => 48, 'transfer_key_ttl' => '30' ) );
check( 'settings validation rejects out-of-range', isset( $errs['db_batch_rows'] ) );
$errs = $p->settings()->save( array( 'db_batch_rows' => 500, 'chunk_size' => '5', 'log_level' => 'info', 'time_budget' => 20, 'backup_retention' => 5, 'log_retention_days' => 30, 'temp_retention_hours' => 48, 'transfer_key_ttl' => '15', 'default_exclusions' => "wp-content/cache/\n../evil" ) );
check( 'settings rejects .. exclusions', isset( $errs['default_exclusions'] ) );
$errs = $p->settings()->save( array( 'db_batch_rows' => 500, 'chunk_size' => '5', 'log_level' => 'info', 'time_budget' => 20, 'backup_retention' => 5, 'log_retention_days' => 30, 'temp_retention_hours' => 48, 'transfer_key_ttl' => '15', 'default_exclusions' => "wp-content/cache/\n/node_modules/" ) );
check( 'settings saved', empty( $errs ) && 500 === $p->settings()->get( 'db_batch_rows' ) && '5' === $p->settings()->get( 'chunk_size' ) );
$p->settings()->save( array_merge( \WSTM\Core\Settings::defaults(), array( 'default_exclusions' => 'wp-content/cache/', 'transfer_key_ttl' => '30', 'chunk_size' => 'auto', 'log_level' => 'info' ) ) );

// Job manager with a test handler that needs several resumable slices.
class Counter_Handler implements \WSTM\Jobs\JobHandlerInterface {
	public int $calls = 0;
	public function type(): string { return 'test_counter'; }
	public function step( \WSTM\Jobs\Job $job, int $deadline ): \WSTM\Jobs\StepResult {
		$this->calls++;
		$n = (int) ( $job->checkpoint['n'] ?? 0 ) + 1;
		if ( ! empty( $job->metadata['explode_at'] ) && $n === $job->metadata['explode_at'] && empty( $job->checkpoint['exploded'] ) ) {
			throw new \WSTM\Core\WstmException( 'boom', 'Simulated failure', array( 'what' => 'step', 'why' => 'test', 'resumable' => true ) );
		}
		return $n >= 5 ? \WSTM\Jobs\StepResult::complete( array( 'final' => $n ) ) : \WSTM\Jobs\StepResult::continue( array( 'n' => $n ), $n * 20, "count $n" );
	}
	public function on_cancel( \WSTM\Jobs\Job $job ): void {}
}
$h = new Counter_Handler();
$p->jobs()->register_handler( $h );
$job = $p->jobs()->create( 'test_counter' );
check( 'job created pending', 'pending' === $job->status );
$job = $p->jobs()->run( $job->id, 5 );
check( 'job completes through slices', 'completed' === $job->status && 100.0 === $job->progress, $job->status );
check( 'metadata merged', 5 === ( $job->metadata['final'] ?? null ) );

$job = $p->jobs()->create( 'test_counter', array( 'explode_at' => 3 ) );
$job = $p->jobs()->run( $job->id, 5 );
check( 'failure recorded structured', 'failed' === $job->status && 'Simulated failure' === ( $job->error['what'] ?? $job->error['code'] ?? '' ) || ( 'failed' === $job->status && ! empty( $job->error['resumable'] ) ), wp_json_encode( $job->error ) );
check( 'checkpoint preserved at failure', 2 === ( $job->checkpoint['n'] ?? null ) );
// Resume from checkpoint: patch checkpoint to skip explosion, then resume.
$wpdb->update( $p->db()->table( 'jobs' ), array( 'checkpoint' => wp_json_encode( array( 'n' => 2, 'exploded' => true ) ) ), array( 'id' => $job->id ) );
$p->jobs()->resume( $job->id );
$h->calls = 0;
$job = $p->jobs()->run( $job->id, 5 );
check( 'resume continues from checkpoint (not from zero)', 'completed' === $job->status && 3 === $h->calls, "calls={$h->calls}" );

$job = $p->jobs()->create( 'test_counter' );
$p->jobs()->cancel( $job->id );
try { $p->jobs()->resume( $job->id ); check( 'cancelled cannot resume', false ); } catch ( \WSTM\Core\WstmException $e ) { check( 'cancelled cannot resume', 'invalid_transition' === $e->get_error_code() ); }

$job = $p->jobs()->create( 'unknown_type' );
$job = $p->jobs()->run( $job->id, 5 );
check( 'missing handler fails resumably', 'failed' === $job->status && ! empty( $job->error['resumable'] ) );

$job = $p->jobs()->create( 'test_counter' );
$t1 = $p->jobs()->acquire_lock( $job->id );
$t2 = $p->jobs()->acquire_lock( $job->id );
check( 'job lock is exclusive', null !== $t1 && null === $t2 );
$p->jobs()->release_lock( $job->id, $t1 );

// Diagnostics.
$rep = $p->diagnostics()->run( true );
check( 'diagnostics score computed', $rep['score'] > 0 && $rep['score'] <= 100, (string) $rep['score'] );
check( 'diagnostics cached', get_site_transient( 'wstm_diagnostics' )['generated_at'] === $rep['generated_at'] );
$ids = array_column( $rep['checks'], 'id' );
foreach ( array( 'php_version', 'memory_limit', 'db_connection', 'disk_free', 'temp_writable', 'ziparchive', 'gzip', 'rest_api', 'elementor', 'woocommerce', 'acf' ) as $id ) check( "check $id present", in_array( $id, $ids, true ) );

// REST.
do_action( 'rest_api_init' );
$server = rest_get_server();
$res = $server->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/diagnostics' ) );
check( 'REST diagnostics 200 for admin', 200 === $res->get_status() );
$res = $server->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/jobs/999999' ) );
check( 'REST unknown job 404', 404 === $res->get_status(), (string) $res->get_status() );
$res = $server->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/logs' ) );
check( 'REST logs 200', 200 === $res->get_status() );
wp_set_current_user( 0 );
$res = $server->dispatch( new WP_REST_Request( 'GET', '/wstm/v1/jobs' ) );
check( 'REST denies anonymous', in_array( $res->get_status(), array( 401, 403 ), true ) );
$sub = wp_insert_user( array( 'user_login' => 'ed' . wp_rand(), 'user_pass' => 'x', 'role' => 'editor' ) );
wp_set_current_user( $sub );
$res = $server->dispatch( new WP_REST_Request( 'POST', '/wstm/v1/jobs/1/cancel' ) );
check( 'REST denies editors', 403 === $res->get_status() );
wp_set_current_user( 1 );

// Admin page rendering.
set_current_screen( 'dashboard' );
require_once WSTM_PATH . 'admin/class-admin.php';
$admin = new \WSTM\Admin\Admin( $p );
foreach ( array_keys( \WSTM\Admin\Admin::pages() ) as $sub ) {
	ob_start();
	try { $admin->render( $sub ); $html = ob_get_clean(); check( "render page '" . ( $sub ?: 'dashboard' ) . "'", str_contains( $html, 'wstm-wrap' ) && ! preg_match( '/(Warning|Notice|Fatal error|Deprecated):/', $html ), substr( strip_tags( $html ), 0, 300 ) ); }
	catch ( \Throwable $e ) { ob_end_clean(); check( "render page $sub", false, $e->getMessage() ); }
}

// Cleanup cron.
$p->run_cleanup();
check( 'cleanup cron runs', true );

echo "\n$ok passed, $bad failed\n";
