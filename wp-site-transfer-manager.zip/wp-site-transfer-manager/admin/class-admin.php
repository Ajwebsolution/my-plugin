<?php
/**
 * Admin UI: menus, asset loading, form handlers.
 *
 * @package WSTM\Admin
 */

namespace WSTM\Admin;

use WSTM\Core\Capabilities;
use WSTM\Core\Plugin;
use WSTM\Core\Settings;
use WSTM\Jobs\JobStatus;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Admin controller.
 */
class Admin {

	public const SLUG = 'wstm';

	/**
	 * Page hook suffixes registered by this plugin.
	 *
	 * @var string[]
	 */
	private array $hooks = array();

	/**
	 * @var Plugin
	 */
	private Plugin $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Register hooks.
	 */
	public function hooks(): void {
		add_action( is_multisite() ? 'network_admin_menu' : 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_wstm_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_wstm_logs', array( $this, 'handle_logs' ) );
		add_action( 'admin_post_wstm_refresh_diagnostics', array( $this, 'handle_refresh_diagnostics' ) );
		add_action( 'admin_post_wstm_download', array( $this, 'handle_download' ) );
		add_filter( 'plugin_action_links_' . WSTM_BASENAME, array( $this, 'action_links' ) );
		add_filter( 'network_admin_plugin_action_links_' . WSTM_BASENAME, array( $this, 'action_links' ) );
	}

	/**
	 * Page definitions: slug suffix => [title, view, phase].
	 */
	public static function pages(): array {
		return array(
			''                => array( __( 'Dashboard', 'wp-site-transfer-manager' ), 'dashboard', 1 ),
			'export'          => array( __( 'Export', 'wp-site-transfer-manager' ), 'simple-export', 6 ),
			'import'          => array( __( 'Import', 'wp-site-transfer-manager' ), 'simple-import', 6 ),
			'backups'         => array( __( 'Backups', 'wp-site-transfer-manager' ), 'backups', 7 ),
			'transfer'        => array( __( 'Transfer', 'wp-site-transfer-manager' ), 'transfer', 8 ),
			'advanced-export' => array( __( 'Advanced Export', 'wp-site-transfer-manager' ), 'export', 4 ),
			'advanced-import' => array( __( 'Advanced Import', 'wp-site-transfer-manager' ), 'import', 4 ),
			'url-replace'     => array( __( 'URL Replace', 'wp-site-transfer-manager' ), 'url-replace', 5 ),
			'diagnostics'     => array( __( 'Diagnostics', 'wp-site-transfer-manager' ), 'diagnostics', 1 ),
			'logs'            => array( __( 'Logs', 'wp-site-transfer-manager' ), 'logs', 1 ),
			'settings'        => array( __( 'Settings', 'wp-site-transfer-manager' ), 'settings', 1 ),
		);
	}

	/**
	 * Admin URL for a page.
	 *
	 * @param string $sub  Sub page key.
	 * @param array  $args Query args.
	 */
	public static function url( string $sub = '', array $args = array() ): string {
		$slug = '' === $sub ? self::SLUG : self::SLUG . '-' . $sub;
		$base = is_multisite() ? network_admin_url( 'admin.php' ) : admin_url( 'admin.php' );
		return add_query_arg( array_merge( array( 'page' => $slug ), $args ), $base );
	}

	/**
	 * Register menu.
	 */
	public function menu(): void {
		$cap = Capabilities::menu_cap();
		$this->hooks[] = add_menu_page(
			__( 'WP Site Transfer', 'wp-site-transfer-manager' ),
			__( 'WP Site Transfer', 'wp-site-transfer-manager' ),
			$cap,
			self::SLUG,
			fn() => $this->render( '' ),
			'dashicons-migrate',
			80
		);
		foreach ( self::pages() as $sub => $def ) {
			$this->hooks[] = add_submenu_page(
				self::SLUG,
				$def[0],
				$def[0],
				$cap,
				'' === $sub ? self::SLUG : self::SLUG . '-' . $sub,
				'' === $sub ? '' : fn() => $this->render( $sub ) // Dashboard is already rendered by the top-level page.
			);
		}
	}

	/**
	 * Render a page.
	 *
	 * @param string $sub Sub page key.
	 */
	public function render( string $sub ): void {
		if ( ! Capabilities::current_user_can_manage() ) {
			wp_die( esc_html__( 'You are not allowed to access this page.', 'wp-site-transfer-manager' ), 403 );
		}
		$pages = self::pages();
		if ( ! isset( $pages[ $sub ] ) ) {
			return;
		}
		[ $title, $view, $phase ] = $pages[ $sub ];
		$plugin = $this->plugin;
		$current = $sub;
		include WSTM_PATH . 'admin/views/header.php';
		include WSTM_PATH . 'admin/views/' . $view . '.php';
		include WSTM_PATH . 'admin/views/footer.php';
	}

	/**
	 * Enqueue assets on plugin pages only.
	 *
	 * @param string $hook Hook suffix.
	 */
	public function assets( string $hook ): void {
		$is_ours = in_array( $hook, $this->hooks, true ) || str_contains( $hook, self::SLUG );
		if ( ! $is_ours ) {
			return;
		}
		wp_enqueue_style( 'wstm-admin', WSTM_URL . 'admin/assets/css/admin.css', array(), WSTM_VERSION );
		wp_enqueue_script( 'wstm-admin', WSTM_URL . 'admin/assets/js/admin.js', array(), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-database', WSTM_URL . 'admin/assets/js/database.js', array( 'wstm-admin' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-packages', WSTM_URL . 'admin/assets/js/packages.js', array( 'wstm-database' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-url', WSTM_URL . 'admin/assets/js/url.js', array( 'wstm-database' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-migrate', WSTM_URL . 'admin/assets/js/migrate.js', array( 'wstm-packages' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-backups', WSTM_URL . 'admin/assets/js/backups.js', array( 'wstm-migrate' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-transfer', WSTM_URL . 'admin/assets/js/transfer.js', array( 'wstm-migrate' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-cloud', WSTM_URL . 'admin/assets/js/cloud.js', array( 'wstm-migrate' ), WSTM_VERSION, true );
		wp_enqueue_script( 'wstm-tools', WSTM_URL . 'admin/assets/js/tools.js', array( 'wstm-migrate' ), WSTM_VERSION, true );
		wp_localize_script(
			'wstm-admin',
			'WSTM',
			array(
				'restRoot' => esc_url_raw( rest_url( 'wstm/v1/' ) ),
				'uploadChunk' => self::upload_chunk_bytes(),
				'adminBase'   => admin_url( 'admin.php' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'i18n'     => array(
					'error'        => __( 'Request failed', 'wp-site-transfer-manager' ),
					'confirm'      => __( 'I understand that existing data may be overwritten.', 'wp-site-transfer-manager' ),
					'cancel'       => __( 'Cancel', 'wp-site-transfer-manager' ),
					'continue'     => __( 'Continue', 'wp-site-transfer-manager' ),
					'refreshing'   => __( 'Running checks…', 'wp-site-transfer-manager' ),
					'noJobs'       => __( 'No active jobs.', 'wp-site-transfer-manager' ),
					'pause'        => __( 'Pause', 'wp-site-transfer-manager' ),
					'resume'       => __( 'Resume', 'wp-site-transfer-manager' ),
					'retry'        => __( 'Retry from checkpoint', 'wp-site-transfer-manager' ),
					'eta'          => __( 'ETA', 'wp-site-transfer-manager' ),
					'speed'        => __( 'Speed', 'wp-site-transfer-manager' ),
					'completed'    => __( 'Completed', 'wp-site-transfer-manager' ),
					'failed'       => __( 'Failed', 'wp-site-transfer-manager' ),
				),
			)
		);
	}

	/**
	 * Largest safe upload chunk for this server (below post_max_size/upload_max_filesize).
	 */
	public static function upload_chunk_bytes(): int {
		$limits = array_filter( array( wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ), wp_convert_hr_to_bytes( (string) ini_get( 'upload_max_filesize' ) ) ), static fn( $v ) => $v > 0 );
		$max    = $limits ? min( $limits ) : 8 * MB_IN_BYTES;
		return (int) max( 256 * KB_IN_BYTES, min( 8 * MB_IN_BYTES, $max - 128 * KB_IN_BYTES ) );
	}

	/**
	 * Plugins-list link.
	 *
	 * @param array $links Links.
	 */
	public function action_links( array $links ): array {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Dashboard', 'wp-site-transfer-manager' ) . '</a>' );
		return $links;
	}

	/**
	 * Abort a form handler with a safe error.
	 *
	 * @param \WP_Error $e Error.
	 */
	private function deny( \WP_Error $e ): void {
		wp_die( esc_html( $e->get_error_message() ), esc_html__( 'Error', 'wp-site-transfer-manager' ), array( 'response' => 403, 'back_link' => true ) );
	}

	/**
	 * Save settings.
	 */
	public function handle_save_settings(): void {
		$ok = Security::verify_request( 'save_settings' );
		if ( is_wp_error( $ok ) ) {
			$this->deny( $ok );
			return;
		}
		$raw    = isset( $_POST['wstm'] ) && is_array( $_POST['wstm'] ) ? wp_unslash( $_POST['wstm'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-field in Settings::save().
		$errors = $this->plugin->settings()->save( $raw );
		if ( $errors ) {
			set_site_transient( 'wstm_settings_errors_' . get_current_user_id(), $errors, 60 );
			$this->plugin->logger()->warning( 'Settings validation failed', array( 'fields' => array_keys( $errors ) ), 'settings' );
		} else {
			$this->plugin->logger()->info( 'Settings updated', array(), 'settings' );
			$this->plugin->diagnostics()->flush();
		}
		wp_safe_redirect( self::url( 'settings', array( 'updated' => $errors ? 0 : 1 ) ) );
		exit; // Redirect termination (not a migration failure).
	}

	/**
	 * Log actions: download / clear / prune.
	 */
	public function handle_logs(): void {
		$ok = Security::verify_request( 'logs' );
		if ( is_wp_error( $ok ) ) {
			$this->deny( $ok );
			return;
		}
		$action = isset( $_REQUEST['do'] ) ? sanitize_key( wp_unslash( $_REQUEST['do'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- verified above.
		$logger = $this->plugin->logger();
		switch ( $action ) {
			case 'download':
				$logger->stream_download();
				exit; // End of streamed download.
			case 'clear':
				$logger->clear();
				$logger->info( 'Logs cleared by user', array(), 'logs' );
				break;
			case 'prune':
				$logger->delete_older_than( (int) $this->plugin->settings()->get( 'log_retention_days' ) );
				break;
		}
		wp_safe_redirect( self::url( 'logs', array( 'done' => $action ) ) );
		exit;
	}

	/**
	 * Refresh diagnostics (non-JS fallback).
	 */
	public function handle_refresh_diagnostics(): void {
		$ok = Security::verify_request( 'diagnostics' );
		if ( is_wp_error( $ok ) ) {
			$this->deny( $ok );
			return;
		}
		$this->plugin->diagnostics()->run( true );
		wp_safe_redirect( self::url( 'diagnostics' ) );
		exit;
	}

	/**
	 * Stream a dump/backup download (capability + nonce + path validation).
	 */
	public function handle_download(): void {
		$ok = Security::verify_request( 'download' );
		if ( is_wp_error( $ok ) ) {
			$this->deny( $ok );
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- verified above.
		$area = isset( $_GET['area'] ) ? sanitize_key( wp_unslash( $_GET['area'] ) ) : '';
		$file = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		// phpcs:enable
		try {
			if ( str_ends_with( $file, '.wpmig' ) ) {
				$path = \WSTM\Jobs\Handlers\SiteRestoreHandler::resolve_in( $this->plugin, $area, $file );
			} else {
				$path = \WSTM\Jobs\Handlers\DbImportHandler::resolve( $this->plugin, $area, $file )['source'];
			}
		} catch ( \WSTM\Core\WstmException $e ) {
			wp_die( esc_html( $e->getMessage() ), esc_html__( 'Download failed', 'wp-site-transfer-manager' ), array( 'response' => 404, 'back_link' => true ) );
			return;
		}
		$this->plugin->logger()->info( 'Download: ' . basename( $path ), array(), 'download' );
		\WSTM\Files\Downloader::stream( $path, basename( $path ) );
		exit; // End of streamed download.
	}

	/**
	 * Status badge HTML.
	 *
	 * @param string $status pass|warning|error|info|running|job statuses.
	 * @param string $label  Optional label.
	 */
	public static function badge( string $status, string $label = '' ): string {
		$map = array(
			'pass'                => array( '✓', 'success' ),
			'warning'             => array( '⚠', 'warning' ),
			'error'               => array( '✕', 'error' ),
			'info'                => array( 'ℹ', 'info' ),
			JobStatus::RUNNING    => array( '●', 'running' ),
			JobStatus::PENDING    => array( '○', 'info' ),
			JobStatus::PAUSED     => array( '❚❚', 'warning' ),
			JobStatus::COMPLETED  => array( '✓', 'success' ),
			JobStatus::FAILED     => array( '✕', 'error' ),
			JobStatus::CANCELLED  => array( '–', 'info' ),
			JobStatus::ROLLBACK   => array( '↺', 'warning' ),
		);
		[ $icon, $cls ] = $map[ $status ] ?? array( '•', 'info' );
		return sprintf( '<span class="wstm-badge wstm-badge--%s" aria-hidden="true">%s</span>%s', esc_attr( $cls ), esc_html( $icon ), $label ? ' ' . esc_html( $label ) : '' );
	}

	/**
	 * Settings schema grouped by section.
	 */
	public static function settings_sections(): array {
		$out = array();
		foreach ( Settings::schema() as $key => $field ) {
			$out[ $field['section'] ][ $key ] = $field;
		}
		return $out;
	}
}
