/**
 * WP Site Transfer Manager — database export/import UI and reusable job monitor.
 * Vanilla JS; depends on window.WSTMAdmin (admin.js).
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const i18n = ( window.WSTM && window.WSTM.i18n ) || {};
	if ( ! A ) {
		return;
	}
	const { api, confirmDestructive, esc } = A;

	const fmtBytes = ( n ) => {
		n = Number( n ) || 0;
		const u = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
		let i = 0;
		while ( n >= 1024 && i < u.length - 1 ) { n /= 1024; i++; }
		return ( i ? n.toFixed( 1 ) : n ) + ' ' + u[ i ];
	};
	const fmtTime = ( s ) => {
		if ( ! isFinite( s ) || s < 0 ) { return '—'; }
		s = Math.round( s );
		const h = Math.floor( s / 3600 ), m = Math.floor( ( s % 3600 ) / 60 ), r = s % 60;
		return ( h ? h + 'h ' : '' ) + ( h || m ? m + 'm ' : '' ) + r + 's';
	};
	const errorText = ( err ) => {
		const d = err && err.data;
		if ( ! d ) { return esc( err.message || i18n.error ); }
		return '<strong>' + esc( d.what || err.message ) + '</strong>' +
			( d.why ? '<br>' + esc( d.why ) : '' ) +
			( d.action ? '<br><em>' + esc( d.action ) + '</em>' : '' );
	};
	const notice = ( el, html, type ) => {
		const n = document.createElement( 'div' );
		n.className = 'notice notice-' + ( type || 'error' ) + ' inline';
		n.innerHTML = '<p>' + html + '</p>';
		el.prepend( n );
		setTimeout( () => n.remove(), 15000 );
	};

	/**
	 * Drives a job via the REST "run" endpoint and renders real progress.
	 */
	class JobMonitor {
		constructor( el, jobId, onDone ) {
			this.el = el;
			this.id = jobId;
			this.onDone = onDone || ( () => {} );
			this.samples = [];
			this.stopped = false;
			this.el.hidden = false;
			this.el.innerHTML = '';
			this.loop();
		}

		async loop() {
			if ( this.stopped ) { return; }
			let job;
			try {
				job = await api( 'jobs/' + this.id + '/run', { method: 'POST' } );
				this.netErrors = 0;
			} catch ( err ) {
				this.netErrors = ( this.netErrors || 0 ) + 1;
				this.renderNetError( err );
				setTimeout( () => this.loop(), Math.min( 30000, 3000 * this.netErrors ) );
				return;
			}
			this.render( job );
			if ( 'running' === job.status || 'pending' === job.status ) {
				setTimeout( () => this.loop(), 250 );
			} else if ( 'completed' === job.status ) {
				this.onDone( job );
			}
		}

		sample( job ) {
			const now = Date.now() / 1000;
			const bytes = Number( job.metadata.bytes ) || 0;
			this.samples.push( { t: now, b: bytes, p: Number( job.progress ) } );
			this.samples = this.samples.filter( ( s ) => now - s.t < 30 );
			const first = this.samples[ 0 ];
			const dt = now - first.t;
			if ( dt < 2 ) { return { speed: null, eta: null }; }
			const speed = ( bytes - first.b ) / dt;
			const pRate = ( job.progress - first.p ) / dt;
			const eta = pRate > 0 ? ( 100 - job.progress ) / pRate : null;
			return { speed, eta };
		}

		render( job ) {
			const m = job.metadata || {};
			const pct = Math.max( 0, Math.min( 100, Number( job.progress ) || 0 ) );
			const { speed, eta } = this.sample( job );
			const badge = { running: '●', pending: '○', paused: '❚❚', failed: '✕', completed: '✓', cancelled: '–' }[ job.status ] || '•';
			const cls = { running: 'running', paused: 'warning', failed: 'error', completed: 'success' }[ job.status ] || 'info';
			const rows = [];
			if ( m.current_table ) { rows.push( [ 'Current table', '<code>' + esc( m.current_table ) + '</code>' ] ); }
			if ( m.current_file ) { rows.push( [ 'Current file', '<code>' + esc( m.current_file ) + '</code>' ] ); }
			if ( m.files_total ) { rows.push( [ 'Files', esc( Number( m.files_done || 0 ).toLocaleString() + ' / ' + Number( m.files_total ).toLocaleString() ) ] ); }
			if ( m.totals ) { rows.push( [ 'Matches', esc( m.totals.rows + ' rows, ' + m.totals.values + ' values, ' + m.totals.replacements + ' replacements' ) ] ); }
			if ( m.tables_total ) { rows.push( [ 'Tables', esc( m.tables_done + ' / ' + m.tables_total ) ] ); }
			else if ( m.tables_done ) { rows.push( [ 'Tables', esc( m.tables_done ) ] ); }
			if ( m.rows_done !== undefined ) { rows.push( [ 'Rows', esc( Number( m.rows_done ).toLocaleString() + ( m.rows_total ? ' / ~' + Number( m.rows_total ).toLocaleString() : '' ) ) ] ); }
			if ( m.statements ) { rows.push( [ 'Statements', esc( Number( m.statements ).toLocaleString() ) ] ); }
			if ( m.bytes !== undefined ) { rows.push( [ 'Bytes processed', esc( fmtBytes( m.bytes ) + ( m.bytes_total ? ' / ' + fmtBytes( m.bytes_total ) : '' ) ) ] ); }
			if ( 'running' === job.status ) {
				rows.push( [ i18n.speed || 'Speed', speed !== null ? esc( fmtBytes( speed ) + '/s' ) : '—' ] );
				rows.push( [ i18n.eta || 'ETA', eta !== null ? esc( fmtTime( eta ) ) : '—' ] );
			}
			if ( m.safety_backup ) { rows.push( [ 'Safety backup', '<code>' + esc( m.safety_backup ) + '</code>' ] ); }

			const titles = { db_import: 'Database import', db_export: 'Database export', package_export: 'Create package', package_import: 'Import package', package_validate: 'Validate package', url_scan: 'dry_run' === m.mode ? 'URL dry run' : 'URL scan', url_replace: 'URL replace' };
			let html = '<h2>' + esc( titles[ job.type ] || job.type ) + ' #' + esc( job.id ) + '</h2>' +
				'<p><span class="wstm-badge wstm-badge--' + cls + '">' + badge + '</span> <strong>' + esc( job.status ) + '</strong> — ' + esc( job.current_step ) + '</p>' +
				'<div class="wstm-progress wstm-progress--lg" role="progressbar" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"><span style="width:' + pct + '%"></span></div>' +
				'<p class="wstm-muted">' + pct.toFixed( 1 ) + '%</p>' +
				'<table class="wstm-kv">' + rows.map( ( r ) => '<tr><th>' + esc( r[ 0 ] ) + '</th><td>' + r[ 1 ] + '</td></tr>' ).join( '' ) + '</table>';

			if ( job.error ) {
				const e = job.error;
				html += '<div class="notice notice-error inline wstm-error-box"><p><strong>' + esc( e.what || 'Error' ) + '</strong></p>' +
					( e.why ? '<p><b>Reason:</b> ' + esc( e.why ) + '</p>' : '' ) +
					( e.completed ? '<p><b>Completed:</b> ' + esc( e.completed ) + '</p>' : '' ) +
					'<p><b>Resumable:</b> ' + ( e.resumable ? 'yes' : 'no' ) + '</p>' +
					( e.action ? '<p><b>Action:</b> ' + esc( e.action ) + '</p>' : '' ) + '</div>';
			}
			if ( m.warnings && m.warnings.length ) {
				html += '<details class="wstm-warnings"><summary>⚠ ' + esc( m.warnings.length ) + ' warning(s)</summary><ul>' + m.warnings.map( ( w ) => '<li>' + esc( w ) + '</li>' ).join( '' ) + '</ul></details>';
			}
			if ( 'completed' === job.status && 'package_import' === job.type ) {
				html += '<div class="notice notice-success inline"><p>Package verified and imported' + ( m.database_import ? ' (database switched atomically)' : '' ) + '. ' + esc( m.staged_files ) + ' entries staged in protected storage for Phase 6 file migration.</p></div>';
			} else if ( 'completed' === job.status && 'package_validate' === job.type ) {
				html += '<div class="notice notice-success inline"><p>Package is valid: seal, structure and manifest verified.</p></div>';
			} else if ( 'completed' === job.status && 'package_export' === job.type ) {
				html += '<div class="notice notice-success inline"><p>Package created and sealed (' + esc( fmtBytes( m.size ) ) + ', SHA-256 ' + esc( ( m.seal || '' ).slice( 0, 16 ) ) + '…).</p></div>';
			} else if ( 'completed' === job.status && 0 === job.type.indexOf( 'url_' ) ) {
				html += '';
			} else if ( 'completed' === job.status && m.previous_tables ) {
				html += '<div class="notice notice-success inline"><p>Import complete and verified: ' + esc( m.tables_imported ) + ' tables. ' + esc( m.previous_tables.length ) + ' replaced tables kept as rollback copies.</p></div>';
			} else if ( 'completed' === job.status ) {
				html += '<div class="notice notice-success inline"><p>Export complete and checksummed (SHA-256 ' + esc( ( m.checksum || '' ).slice( 0, 16 ) ) + '…).</p></div>';
			}

			const btns = [];
			if ( 'running' === job.status || 'pending' === job.status ) {
				btns.push( '<button type="button" class="button" data-act="pause">' + esc( i18n.pause || 'Pause' ) + '</button>' );
			}
			if ( 'paused' === job.status ) {
				btns.push( '<button type="button" class="button button-primary" data-act="resume">' + esc( i18n.resume || 'Resume' ) + '</button>' );
			}
			if ( 'failed' === job.status && job.error && job.error.resumable ) {
				btns.push( '<button type="button" class="button button-primary" data-act="resume">' + esc( i18n.retry || 'Retry' ) + '</button>' );
			}
			if ( [ 'running', 'pending', 'paused', 'failed' ].includes( job.status ) ) {
				btns.push( '<button type="button" class="button button-link-delete" data-act="cancel">' + esc( i18n.cancel || 'Cancel' ) + '</button>' );
			}
			html += '<p class="wstm-actions">' + btns.join( ' ' ) + '</p>';

			this.el.innerHTML = html;
			this.el.querySelectorAll( '[data-act]' ).forEach( ( b ) => b.addEventListener( 'click', () => this.action( b.dataset.act ) ) );
		}

		renderNetError( err ) {
			let box = this.el.querySelector( '.wstm-net' );
			if ( ! box ) {
				box = document.createElement( 'p' );
				box.className = 'wstm-net wstm-error-line';
				this.el.appendChild( box );
			}
			box.textContent = 'Connection problem (' + ( err.message || 'network' ) + '). Retrying automatically — progress is saved on the server.';
		}

		async action( act ) {
			if ( 'cancel' === act ) {
				const ok = await confirmDestructive( 'Cancel this job?', 'Partial output and temporary tables will be removed. Your live database is not affected.', 'I understand this job cannot be resumed after cancelling.' );
				if ( ! ok ) { return; }
			}
			try {
				const job = await api( 'jobs/' + this.id + '/' + act, { method: 'POST' } );
				this.render( job );
				if ( 'resume' === act ) {
					this.samples = [];
					this.loop();
				}
				if ( 'cancel' === act ) {
					this.onDone( job );
				}
			} catch ( err ) {
				notice( this.el, errorText( err ) );
			}
		}
	}
	A.JobMonitor = JobMonitor;
	A.watch = ( id, done ) => {
		const el = document.getElementById( 'wstm-monitor' );
		el.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		return new JobMonitor( el, id, done );
	};
	A.fmtBytes = fmtBytes;
	A.errorText = errorText;
	A.notice = notice;

	const page = document.querySelector( '[data-wstm-page="export"], [data-wstm-page="import"]' );
	if ( ! page ) {
		return;
	}
	const mode = page.dataset.wstmPage;
	const monitorEl = document.getElementById( 'wstm-monitor' );
	const dumpsEl = document.getElementById( 'wstm-dumps' );
	const unknownDisk = () => !! ( document.getElementById( 'wstm-opt-unknown-disk' ) || {} ).checked;

	/* ----- Dumps list ----- */
	async function loadDumps() {
		try {
			const dumps = await api( 'database/dumps' );
			if ( ! dumps.length ) {
				dumpsEl.innerHTML = '<p class="wstm-muted">No dumps yet.</p>';
				return;
			}
			dumpsEl.innerHTML = '<table class="widefat striped"><thead><tr><th>File</th><th>Location</th><th>Size</th><th>Created</th><th>Contents</th><th></th></tr></thead><tbody>' +
				dumps.map( ( d, i ) => {
					const m = d.manifest;
					let info = '<span class="wstm-muted">No manifest (unverified)</span>';
					if ( m && m.error ) {
						info = '<span class="wstm-error-line">' + esc( m.error ) + '</span>';
					} else if ( m ) {
						info = esc( m.tables + ' tables, ' + Number( m.rows ).toLocaleString() + ' rows' ) + '<br><span class="wstm-muted">' + esc( m.site_url ) + ' · prefix <code>' + esc( m.table_prefix ) + '</code></span>' +
							( m.compatible ? '' : '<br><span class="wstm-error-line">Different table prefix — import requires Phase 6</span>' );
					}
					const canImport = ! m || ( ! m.error && m.compatible );
					return '<tr><td><code>' + esc( d.file ) + '</code></td><td>' + esc( 'backups' === d.area ? 'Safety backup' : 'Export' ) + '</td><td>' + esc( fmtBytes( d.size ) ) + '</td><td>' + esc( new Date( d.modified ).toLocaleString() ) + '</td><td>' + info + '</td><td class="wstm-nowrap">' +
						'<a class="button button-small" href="' + esc( d.download ) + '">Download</a> ' +
						( 'import' === mode ? '<button type="button" class="button button-small button-primary" data-import="' + i + '"' + ( canImport ? '' : ' disabled' ) + '>Import</button> ' : '' ) +
						'<button type="button" class="button button-small button-link-delete" data-delete="' + i + '">Delete</button></td></tr>';
				} ).join( '' ) + '</tbody></table>';
			dumpsEl.querySelectorAll( '[data-delete]' ).forEach( ( b ) => b.addEventListener( 'click', () => deleteDump( dumps[ b.dataset.delete ] ) ) );
			dumpsEl.querySelectorAll( '[data-import]' ).forEach( ( b ) => b.addEventListener( 'click', () => startImport( dumps[ b.dataset.import ] ) ) );
		} catch ( err ) {
			dumpsEl.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
		}
	}

	async function deleteDump( d ) {
		const ok = await confirmDestructive( 'Delete ' + d.file + '?', 'The dump and its manifest are permanently deleted.', 'I understand this file cannot be recovered.' );
		if ( ! ok ) { return; }
		try {
			await api( 'database/dumps/delete', { method: 'POST', body: { area: d.area, file: d.file, confirm: true } } );
			loadDumps();
		} catch ( err ) {
			notice( dumpsEl, errorText( err ) );
		}
	}

	async function startImport( d ) {
		const ok = await confirmDestructive(
			'Replace this site\'s database?',
			'This operation will replace the destination database with "' + d.file + '". Live tables are swapped only after the import is verified, and the replaced tables are kept as rollback copies.',
			i18n.confirm
		);
		if ( ! ok ) { return; }
		try {
			const job = await api( 'database/import', { method: 'POST', body: {
				area: d.area, file: d.file, confirm: true,
				safety_backup: document.getElementById( 'wstm-opt-safety' ).checked,
				allow_unknown_disk: unknownDisk(),
			} } );
			watch( job.id );
		} catch ( err ) {
			notice( dumpsEl, errorText( err ) );
		}
	}

	function watch( id ) {
		monitorEl.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		new JobMonitor( monitorEl, id, () => { loadDumps(); if ( 'import' === mode ) { loadPrevious(); } } );
	}

	/* ----- Export: table picker ----- */
	async function loadTables() {
		const el = document.getElementById( 'wstm-table-picker' );
		try {
			const data = await api( 'database/tables' );
			const gz = document.getElementById( 'wstm-opt-gzip' );
			if ( ! data.gzip ) { gz.checked = false; gz.disabled = true; }
			const groups = { site: 'This site (prefix ' + data.prefix + ')', other: 'Other tables in this database', plugin_internal: 'Migration engine (never exported)', reserved: 'Import temporary / rollback tables (never exported)' };
			let html = '<p><label><input type="checkbox" id="wstm-all"> <strong>Select all site tables</strong></label> <span class="wstm-muted" id="wstm-sel-summary"></span></p>';
			Object.keys( groups ).forEach( ( g ) => {
				const list = data.tables.filter( ( t ) => t.group === g );
				if ( ! list.length ) { return; }
				const locked = 'plugin_internal' === g || 'reserved' === g;
				html += '<h3 class="wstm-subhead">' + esc( groups[ g ] ) + '</h3><div class="wstm-table-grid">' + list.map( ( t ) =>
					'<label class="' + ( t.is_view ? 'wstm-muted' : '' ) + '"><input type="checkbox" class="wstm-tbl" value="' + esc( t.name ) + '" data-bytes="' + ( t.data_bytes + t.index_bytes ) + '"' +
					( t.default ? ' checked' : '' ) + ( locked || t.is_view ? ' disabled' : '' ) + '> <code>' + esc( t.name ) + '</code> <span class="wstm-muted">' +
					( t.is_view ? 'view' : esc( fmtBytes( t.data_bytes + t.index_bytes ) + ' · ~' + Number( t.rows ).toLocaleString() + ' rows' ) ) + '</span></label>'
				).join( '' ) + '</div>';
			} );
			el.innerHTML = html;
			const update = () => {
				const sel = [ ...el.querySelectorAll( '.wstm-tbl:checked' ) ];
				document.getElementById( 'wstm-sel-summary' ).textContent = sel.length + ' selected, ' + fmtBytes( sel.reduce( ( a, c ) => a + Number( c.dataset.bytes ), 0 ) );
			};
			el.querySelector( '#wstm-all' ).addEventListener( 'change', ( e ) => {
				el.querySelectorAll( '.wstm-tbl:not(:disabled)' ).forEach( ( c ) => {
					if ( data.tables.find( ( t ) => t.name === c.value && 'site' === t.group ) ) { c.checked = e.target.checked; }
				} );
				update();
			} );
			el.addEventListener( 'change', update );
			el.querySelector( '#wstm-all' ).checked = true;
			update();
		} catch ( err ) {
			el.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
		}
	}

	async function startExport() {
		const tables = [ ...document.querySelectorAll( '.wstm-tbl:checked' ) ].map( ( c ) => c.value );
		const btn = document.getElementById( 'wstm-start-export' );
		if ( ! tables.length ) {
			notice( btn.parentNode.parentNode, 'Select at least one table.' );
			return;
		}
		btn.disabled = true;
		try {
			const job = await api( 'database/export', { method: 'POST', body: {
				tables,
				gzip: document.getElementById( 'wstm-opt-gzip' ).checked,
				drop_table: document.getElementById( 'wstm-opt-drop' ).checked,
				allow_unknown_disk: unknownDisk(),
			} } );
			watch( job.id );
		} catch ( err ) {
			notice( btn.parentNode.parentNode, errorText( err ) );
		} finally {
			btn.disabled = false;
		}
	}

	/* ----- Import: rollback copies ----- */
	async function loadPrevious() {
		const el = document.getElementById( 'wstm-previous' );
		if ( ! el ) { return; }
		try {
			const list = await api( 'database/previous' );
			if ( ! list.length ) {
				el.innerHTML = '<p class="wstm-muted">None.</p>';
				return;
			}
			el.innerHTML = '<p>' + list.map( ( t ) => '<code>' + esc( t.name ) + '</code>' ).join( ' ' ) + '</p><p><button type="button" class="button button-link-delete" id="wstm-drop-prev">Delete rollback copies</button></p>';
			el.querySelector( '#wstm-drop-prev' ).addEventListener( 'click', async () => {
				const ok = await confirmDestructive( 'Delete rollback copies?', 'You will no longer be able to restore the tables replaced by the last import from these copies.', 'I understand the previous tables will be permanently deleted.' );
				if ( ! ok ) { return; }
				try {
					await api( 'database/previous/delete', { method: 'POST', body: { confirm: true } } );
					loadPrevious();
				} catch ( err ) {
					notice( el, errorText( err ) );
				}
			} );
		} catch ( err ) {
			el.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
		}
	}

	/* ----- Re-attach to an unfinished job after reload ----- */
	async function attachActive() {
		try {
			const jobs = await api( 'jobs?status=running,pending,paused,failed&per_page=20' );
			const types = 'export' === mode ? [ 'db_export', 'package_export' ] : [ 'db_import', 'package_import', 'package_validate' ];
			const job = jobs.find( ( j ) => types.includes( j.type ) );
			if ( job ) {
				new JobMonitor( monitorEl, job.id, () => { loadDumps(); loadPrevious(); } );
			}
		} catch ( e ) { /* non-fatal */ }
	}

	if ( 'export' === mode ) {
		loadTables();
		document.getElementById( 'wstm-start-export' ).addEventListener( 'click', startExport );
	} else {
		loadPrevious();
	}
	loadDumps();
	attachActive();
	document.addEventListener( 'wstm:uploaded', loadDumps );
}() );
