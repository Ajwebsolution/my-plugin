/**
 * WP Site Transfer Manager — Backups page: create, restore, verify, delete, undo imports.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const cfg = window.WSTM || {};
	if ( ! A || ! A.drive ) {
		return;
	}
	const { api, esc, confirmDestructive, fmtBytes, errorText } = A;

	/** Undo an import from any page: go to Backups and run it there. */
	A.undo = ( point ) => {
		window.location.href = window.location.pathname + '?page=wstm-backups&undo=' + encodeURIComponent( point );
	};

	const page = document.querySelector( '[data-wstm-page="backups"]' );
	if ( ! page ) {
		return;
	}
	const run = document.getElementById( 'wstm-mig-run' );
	const ui = {
		title: run.querySelector( '.wstm-run__title' ),
		bar: run.querySelector( '.wstm-progress span' ),
		pct: run.querySelector( '.wstm-run__pct' ),
		step: run.querySelector( '.wstm-run__step' ),
		body: run.querySelector( '.wstm-run__body' ),
		actions: run.querySelector( '.wstm-run__actions' ),
	};
	let busy = false;

	const show = ( title ) => {
		run.hidden = false;
		run.classList.remove( 'is-done', 'is-failed' );
		ui.title.textContent = title;
		ui.body.innerHTML = '';
		ui.actions.innerHTML = '';
		progress( 0, 'Starting…' );
		run.scrollIntoView( { behavior: 'smooth', block: 'start' } );
	};
	const progress = ( p, step ) => {
		p = Math.max( 0, Math.min( 100, Number( p ) || 0 ) );
		ui.bar.style.width = p + '%';
		ui.pct.textContent = p.toFixed( 0 ) + '%';
		ui.step.textContent = step || '';
	};
	const fail = ( e ) => {
		run.classList.add( 'is-failed' );
		const d = ( e && e.data ) || e || {};
		ui.body.innerHTML = '<div class="notice notice-error inline"><p><strong>' + esc( d.what || e.message || 'Failed' ) + '</strong></p>' + ( d.why ? '<p>' + esc( d.why ) + '</p>' : '' ) + ( d.action ? '<p><b>What to do:</b> ' + esc( d.action ) + '</p>' : '' ) + '</div>';
	};

	async function follow( title, runner, onDone ) {
		show( title );
		busy = true;
		try {
			const job = await A.drive( runner, ( j ) => progress( j.progress, j.current_step ), () => { ui.step.textContent = 'Connection problem — retrying…'; } );
			if ( 'completed' === job.status ) {
				run.classList.add( 'is-done' );
				progress( 100, '' );
				onDone( job );
			} else if ( 'cancelled' !== job.status ) {
				fail( job.error || {} );
			}
		} catch ( err ) {
			fail( err );
		} finally {
			busy = false;
			load();
		}
	}

	async function load() {
		const list = document.getElementById( 'wstm-bk-list' );
		const undo = document.getElementById( 'wstm-bk-undo' );
		let data;
		try {
			data = await api( 'backups' );
		} catch ( err ) {
			list.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
			return;
		}
		const s = data.schedule;
		document.getElementById( 'wstm-bk-schedule' ).textContent = 'off' === s.frequency
			? 'Automatic backups are off. Keeping the newest ' + s.retention + ' backup(s).'
			: 'Automatic ' + s.frequency + ' ' + s.mode + ' ' + s.type + ' backups' + ( s.next ? ' · next ' + new Date( s.next ).toLocaleString() : '' ) + ' · keeping ' + s.retention + '.';
		const clouds = data.clouds || [];
		const cloudSel = document.getElementById( 'wstm-bk-cloud' );
		if ( clouds.length && cloudSel.options.length === 1 ) {
			clouds.forEach( ( c ) => cloudSel.add( new Option( c.label, c.id ) ) );
			page.querySelector( '.wstm-bk-cloud' ).hidden = false;
		}

		const byId = {};
		data.backups.forEach( ( b ) => { byId[ b.id ] = b; } );
		list.innerHTML = data.backups.length ? '<table class="widefat striped"><thead><tr><th>Backup</th><th>Created</th><th>Size</th><th>Status</th><th></th></tr></thead><tbody>' + data.backups.map( ( b ) => {
			const mode = b.is_safety ? 'safety' : ( b.meta.mode || 'full' );
			const base = b.parent_backup_id && byId[ b.parent_backup_id ] ? '<br><span class="wstm-muted">based on #' + b.parent_backup_id + ' · ' + esc( b.meta.files ) + ' changed files</span>' : '';
			const status = ! b.exists ? '<span class="wstm-error-line">✕ file missing</span>' : ( b.verified ? '<span class="wstm-badge wstm-badge--success">✓</span> Verified' : ( 'sql' === b.kind ? '<span class="wstm-muted">Checksummed</span>' : '<span class="wstm-badge wstm-badge--warning">⚠</span> Not verified' ) );
			return '<tr><td><strong>' + esc( b.label || b.file ) + '</strong> <span class="wstm-pill wstm-pill--' + esc( mode ) + '">' + esc( 'safety' === mode ? 'before import' : mode ) + '</span> <span class="wstm-pill">' + esc( b.type ) + '</span>' + base + '<br><code class="wstm-muted">#' + b.id + ' ' + esc( b.file ) + '</code></td>' +
				'<td>' + esc( new Date( b.created_at.replace( ' ', 'T' ) + 'Z' ).toLocaleString() ) + '</td><td>' + esc( fmtBytes( b.size_bytes ) ) + '</td><td>' + status + ( b.meta.cloud ? '<br><span class="wstm-muted">☁ ' + esc( b.meta.cloud.label || b.meta.cloud ) + '</span>' : '' ) + '</td>' +
				'<td class="wstm-nowrap">' + ( b.exists ? '<button type="button" class="button button-primary button-small" data-restore="' + b.id + '">Restore</button> <a class="button button-small" href="' + esc( b.download ) + '">Download</a> ' + ( 'package' === b.kind ? '<button type="button" class="button button-small" data-verify="' + b.id + '">Verify</button> ' : '' ) : '' ) +
				'<button type="button" class="button button-small button-link-delete" data-delete="' + b.id + '">Delete</button></td></tr>';
		} ).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No backups yet. Click “Back up now”.</p>';

		list.querySelectorAll( '[data-restore]' ).forEach( ( el ) => el.addEventListener( 'click', () => restore( byId[ el.dataset.restore ] ) ) );
		list.querySelectorAll( '[data-verify]' ).forEach( ( el ) => el.addEventListener( 'click', () => verify( byId[ el.dataset.verify ] ) ) );
		list.querySelectorAll( '[data-delete]' ).forEach( ( el ) => el.addEventListener( 'click', () => remove( byId[ el.dataset.delete ] ) ) );

		const points = data.rollbacks || [];
		undo.innerHTML = points.length ? '<table class="widefat striped"><tbody>' + points.map( ( p ) => '<tr><td><strong>' + esc( p.label || ( 'Import of ' + p.package ) ) + '</strong><br><span class="wstm-muted">' + esc( new Date( p.created_at ).toLocaleString() ) + ( p.source ? ' · from ' + esc( p.source ) : '' ) + '</span></td><td>' +
			( p.undone_at ? '<span class="wstm-muted">Undone ' + esc( new Date( p.undone_at ).toLocaleString() ) + '</span>' : '<button type="button" class="button" data-undo="' + esc( p.dir ) + '">Undo this import</button>' ) + '</td></tr>' ).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No imports to undo.</p>';
		undo.querySelectorAll( '[data-undo]' ).forEach( ( el ) => el.addEventListener( 'click', () => doUndo( el.dataset.undo ) ) );
	}

	async function create() {
		if ( busy ) { return; }
		try {
			const job = await api( 'backups/create', { method: 'POST', body: { type: document.getElementById( 'wstm-bk-type' ).value, mode: document.getElementById( 'wstm-bk-mode' ).value, cloud: document.getElementById( 'wstm-bk-cloud' ).value } } );
			follow( 'Creating backup', () => api( 'jobs/' + job.id + '/run', { method: 'POST' } ), ( j ) => {
				ui.title.textContent = 'Backup created and verified';
				ui.body.innerHTML = '<p><code>' + esc( j.metadata.file ) + '</code> · ' + esc( fmtBytes( j.metadata.size ) ) + ( j.metadata.cloud ? ' · uploaded to ' + esc( j.metadata.cloud ) : '' ) + '</p>';
			} );
		} catch ( err ) {
			show( 'Backup' );
			fail( err );
		}
	}

	async function restore( b ) {
		if ( busy ) { return; }
		const chain = b.parent_backup_id ? ' It will be applied together with the backups it is based on.' : '';
		const ok = await confirmDestructive( 'Restore “' + ( b.label || b.file ) + '”?', 'This operation will replace this site\'s ' + ( 'files' === b.type ? 'files' : ( 'database' === b.type ? 'database' : 'database and files' ) ) + ' with the backup from ' + new Date( b.created_at.replace( ' ', 'T' ) + 'Z' ).toLocaleString() + '.' + chain + ' Current files and database are kept so the restore can be undone.', ( cfg.i18n || {} ).confirm );
		if ( ! ok ) { return; }
		try {
			const job = await api( 'backups/' + b.id + '/restore', { method: 'POST', body: { confirm: true } } );
			const runner = job.token ? A.tokenRunner( job.id, job.token ) : () => api( 'jobs/' + job.id + '/run', { method: 'POST' } );
			follow( 'Restoring backup', runner, ( j ) => {
				ui.title.textContent = 'Restore complete';
				ui.body.innerHTML = '<p>The site was restored. You may need to log in again.</p>';
				ui.actions.innerHTML = '<a class="button button-primary" href="' + esc( ( j.metadata && j.metadata.login_url ) || location.href ) + '">Continue</a>';
			} );
		} catch ( err ) {
			show( 'Restore' );
			fail( err );
		}
	}

	async function verify( b ) {
		if ( busy ) { return; }
		try {
			const job = await api( 'backups/' + b.id + '/verify', { method: 'POST' } );
			follow( 'Verifying backup', () => api( 'jobs/' + job.id + '/run', { method: 'POST' } ), () => {
				ui.title.textContent = 'Backup verified';
				ui.body.innerHTML = '<p>Seal, structure and manifest are intact.</p>';
			} );
		} catch ( err ) {
			show( 'Verify' );
			fail( err );
		}
	}

	async function remove( b ) {
		const ok = await confirmDestructive( 'Delete backup #' + b.id + '?', 'The backup file is permanently deleted.', 'I understand this backup cannot be recovered.' );
		if ( ! ok ) { return; }
		try {
			await api( 'backups/' + b.id + '/delete', { method: 'POST', body: { confirm: true } } );
			load();
		} catch ( err ) {
			show( 'Delete' );
			fail( err );
		}
	}

	async function doUndo( point ) {
		if ( busy ) { return; }
		const ok = await confirmDestructive( 'Undo this import?', 'Files added by the import are removed, replaced files are put back, and the previous database is restored.', ( cfg.i18n || {} ).confirm );
		if ( ! ok ) { return; }
		try {
			const job = await api( 'rollback/' + point, { method: 'POST', body: { confirm: true } } );
			follow( 'Undoing import', A.tokenRunner( job.id, job.token ), ( j ) => {
				ui.title.textContent = 'Import undone';
				ui.body.innerHTML = '<p>Your site is back to how it was before the import. You may need to log in again.</p>';
				ui.actions.innerHTML = '<a class="button button-primary" href="' + esc( j.metadata.login_url || location.href ) + '">Continue</a>';
			} );
		} catch ( err ) {
			show( 'Undo' );
			fail( err );
		}
	}

	document.getElementById( 'wstm-bk-create' ).addEventListener( 'click', create );
	load().then( () => {
		const p = new URLSearchParams( location.search ).get( 'undo' );
		if ( p ) { doUndo( p ); }
	} );
	api( 'jobs?status=running,pending&per_page=10' ).then( ( jobs ) => {
		const j = jobs.find( ( x ) => 'backup_create' === x.type );
		if ( j ) { follow( 'Creating backup', () => api( 'jobs/' + j.id + '/run', { method: 'POST' } ), () => { ui.title.textContent = 'Backup created and verified'; } ); }
	} ).catch( () => null );
}() );
