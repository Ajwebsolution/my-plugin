/**
 * WP Site Transfer Manager — packages (create, list, validate, import) and resumable uploads.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const cfg = window.WSTM || {};
	const page = document.querySelector( '[data-wstm-page]' );
	if ( ! A || ! page ) {
		return;
	}
	const { api, esc, confirmDestructive, fmtBytes, errorText, notice } = A;
	const mode = page.dataset.wstmPage;
	const listEl = document.getElementById( 'wstm-packages' );
	const checked = ( id ) => !! ( document.getElementById( id ) || {} ).checked;

	async function loadPackages() {
		if ( ! listEl ) { return; }
		try {
			const data = await api( 'packages' );
			if ( ! data.packages.length ) {
				listEl.innerHTML = '<p class="wstm-muted">No packages yet.</p>';
				return;
			}
			listEl.innerHTML = '<table class="widefat striped"><thead><tr><th>Package</th><th>Size</th><th>Created</th><th>Contents</th><th></th></tr></thead><tbody>' +
				data.packages.map( ( p, i ) => {
					const info = p.info;
					let contents = '<span class="wstm-muted">Not verified yet — run Validate</span>';
					if ( info ) {
						const comps = Object.keys( info.components || {} ).filter( ( k ) => info.components[ k ] );
						contents = esc( comps.join( ', ' ) ) + '<br><span class="wstm-muted">' + esc( Number( info.files || 0 ).toLocaleString() + ' files · from ' + ( info.source || '?' ) ) + '</span>' +
							( info.database && info.prefix && info.prefix !== data.prefix ? '<br><span class="wstm-error-line">Database prefix "' + esc( info.prefix ) + '" differs — DB import requires Phase 6</span>' : '' ) +
							( info.suspicious ? '<br><span class="wstm-error-line">⚠ ' + esc( info.suspicious ) + ' executable file(s) in uploads</span>' : '' );
					}
					return '<tr><td><code>' + esc( p.file ) + '</code>' + ( p.validated ? ' <span class="wstm-badge wstm-badge--success" title="Verified">✓</span>' : '' ) + '</td><td>' + esc( fmtBytes( p.size ) ) + '</td><td>' + esc( new Date( p.modified ).toLocaleString() ) + '</td><td>' + contents + '</td><td class="wstm-nowrap">' +
						'<a class="button button-small" href="' + esc( p.download ) + '">Download</a> ' +
						'<button type="button" class="button button-small" data-validate="' + i + '">Validate</button> ' +
						( 'import' === mode ? '<button type="button" class="button button-small button-primary" data-import="' + i + '">Import</button> ' : '' ) +
						'<button type="button" class="button button-small button-link-delete" data-delete="' + i + '">Delete</button></td></tr>';
				} ).join( '' ) + '</tbody></table>';
			const pk = data.packages;
			listEl.querySelectorAll( '[data-validate]' ).forEach( ( b ) => b.addEventListener( 'click', () => start( 'packages/validate', { file: pk[ b.dataset.validate ].file } ) ) );
			listEl.querySelectorAll( '[data-import]' ).forEach( ( b ) => b.addEventListener( 'click', () => importPackage( pk[ b.dataset.import ] ) ) );
			listEl.querySelectorAll( '[data-delete]' ).forEach( ( b ) => b.addEventListener( 'click', () => deletePackage( pk[ b.dataset.delete ] ) ) );
		} catch ( err ) {
			listEl.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
		}
	}

	async function start( route, body ) {
		try {
			const job = await api( route, { method: 'POST', body } );
			A.watch( job.id, () => loadPackages() );
		} catch ( err ) {
			notice( listEl || page, errorText( err ) );
		}
	}

	async function importPackage( p ) {
		const db = checked( 'wstm-opt-pkg-db' );
		const ok = await confirmDestructive(
			'Import ' + p.file + '?',
			db ? 'This operation will replace the destination database with the database inside the package (after verification, with a safety backup). Files are extracted to a protected staging area.' : 'Files will be verified and extracted to a protected staging area. The database is not touched.',
			( window.WSTM.i18n || {} ).confirm
		);
		if ( ! ok ) { return; }
		start( 'packages/import', {
			file: p.file, confirm: true, import_database: db,
			safety_backup: checked( 'wstm-opt-safety' ),
			allow_uploads_exec: checked( 'wstm-opt-exec' ),
			allow_unknown_disk: checked( 'wstm-opt-unknown-disk' ),
		} );
	}

	async function deletePackage( p ) {
		const ok = await confirmDestructive( 'Delete ' + p.file + '?', 'The package is permanently deleted from this server.', 'I understand this file cannot be recovered.' );
		if ( ! ok ) { return; }
		try {
			await api( 'packages/delete', { method: 'POST', body: { file: p.file, confirm: true } } );
			loadPackages();
		} catch ( err ) {
			notice( listEl, errorText( err ) );
		}
	}

	/* ----- Create package ----- */
	const startBtn = document.getElementById( 'wstm-start-package' );
	if ( startBtn ) {
		startBtn.addEventListener( 'click', () => {
			const components = {};
			document.querySelectorAll( '#wstm-components input' ).forEach( ( c ) => { components[ c.value ] = c.checked; } );
			if ( ! Object.values( components ).some( Boolean ) ) {
				notice( startBtn.parentNode.parentNode, 'Select at least one component.' );
				return;
			}
			start( 'packages/export', {
				components,
				exclusions: document.getElementById( 'wstm-exclusions' ).value.split( /\r?\n/ ).map( ( s ) => s.trim() ).filter( Boolean ),
				gzip: true,
				allow_unknown_disk: checked( 'wstm-opt-unknown-disk' ),
			} );
		} );
	}

	/* ----- Resumable chunked upload (shared with the one-click Import screen) ----- */
	const sha256 = async ( buf ) => {
		if ( ! window.crypto || ! window.crypto.subtle ) { return null; } // Not available on plain http.
		const h = await window.crypto.subtle.digest( 'SHA-256', buf );
		return [ ...new Uint8Array( h ) ].map( ( b ) => b.toString( 16 ).padStart( 2, '0' ) ).join( '' );
	};

	async function sendChunk( id, offset, blob, onRetry, isStopped ) {
		const buf = await blob.arrayBuffer();
		const hash = await sha256( buf );
		for ( let attempt = 1; ; attempt++ ) {
			try {
				const headers = { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/octet-stream' };
				if ( hash ) { headers[ 'X-WSTM-SHA256' ] = hash; }
				const res = await fetch( A.restUrl( 'uploads/' + id + '/chunk?offset=' + offset ), { method: 'POST', credentials: 'same-origin', headers, body: buf } );
				const json = await res.json().catch( () => null );
				// A 200 without a readable body (proxy/host hiccup) is retried like a network error;
				// the server ignores duplicate chunks, so a retry can never corrupt the file.
				if ( res.ok && json && 'number' === typeof json.received ) { return json; }
				if ( res.ok ) { throw new Error( 'The server sent an empty or unreadable reply.' ); }
				if ( 409 === res.status && json && json.data && json.data.detail ) { return { received: json.data.detail.received }; }
				throw Object.assign( new Error( ( json && json.message ) || ( 'HTTP ' + res.status ) ), { data: json && json.data } );
			} catch ( err ) {
				if ( attempt >= 5 || isStopped() ) { throw err; }
				onRetry( attempt );
				await new Promise( ( r ) => setTimeout( r, 2000 * attempt ) );
			}
		}
	}

	/**
	 * Upload a file in resumable chunks. Resolves to { file, size } or { stopped: true, received }.
	 */
	A.upload = async function ( file, opts = {} ) {
		const onProgress = opts.onProgress || ( () => {} );
		const isStopped = opts.isStopped || ( () => false );
		const up = await api( 'uploads/start', { method: 'POST', body: { name: file.name, size: file.size, fingerprint: file.name + '|' + file.size + '|' + file.lastModified, allow_unknown_disk: !! opts.allowUnknownDisk } } );
		let offset = up.received;
		const startOffset = offset;
		const t0 = Date.now();
		// wp_localize_script() delivers numbers as strings; "offset + '1966080'" would concatenate.
		const size = parseInt( cfg.uploadChunk, 10 ) || 2097152;
		while ( offset < file.size ) {
			if ( isStopped() ) { return { stopped: true, received: offset }; }
			const r = await sendChunk( up.id, offset, file.slice( offset, Math.min( file.size, offset + size ) ), ( n ) => onProgress( offset, file.size, null, 'Network problem, retrying (' + n + '/5)…' ), isStopped );
			offset = r.received;
			onProgress( offset, file.size, ( offset - startOffset ) / Math.max( 1, ( Date.now() - t0 ) / 1000 ) );
		}
		return api( 'uploads/' + up.id + '/finish', { method: 'POST' } );
	};

	const fileInput = document.getElementById( 'wstm-upload-file' );
	if ( fileInput ) {
		const box = document.getElementById( 'wstm-upload-progress' );
		const bar = box.querySelector( '.wstm-progress span' );
		const label = box.querySelector( 'p' );
		const stopBtn = document.getElementById( 'wstm-upload-cancel' );
		let stopped = false;
		document.getElementById( 'wstm-upload-start' ).addEventListener( 'click', async () => {
			const file = fileInput.files[ 0 ];
			if ( ! file ) { return; }
			stopped = false;
			box.hidden = false;
			stopBtn.hidden = false;
			try {
				const done = await A.upload( file, {
					allowUnknownDisk: checked( 'wstm-opt-unknown-disk' ),
					isStopped: () => stopped,
					onProgress: ( off, total, speed, msg ) => {
						const pct = 100 * off / total;
						bar.style.width = pct.toFixed( 1 ) + '%';
						label.textContent = msg || ( fmtBytes( off ) + ' / ' + fmtBytes( total ) + ' (' + pct.toFixed( 1 ) + '%)' + ( speed ? ' · ' + fmtBytes( speed ) + '/s' : '' ) );
					},
				} );
				if ( done.stopped ) {
					label.textContent = 'Stopped at ' + fmtBytes( done.received ) + '. Choose the same file and press Upload to resume.';
					return;
				}
				label.textContent = 'Uploaded as ' + done.file + '. ' + ( /\.wpmig$/.test( done.file ) ? 'Validate or import it below.' : 'It is listed under "Available dumps".' );
				loadPackages();
				document.dispatchEvent( new CustomEvent( 'wstm:uploaded' ) );
			} catch ( err ) {
				label.innerHTML = errorText( err ) + '<br>Choose the same file and press Upload to resume.';
			} finally {
				stopBtn.hidden = true;
			}
		} );
		stopBtn.addEventListener( 'click', () => { stopped = true; } );
	}

	loadPackages();
}() );
