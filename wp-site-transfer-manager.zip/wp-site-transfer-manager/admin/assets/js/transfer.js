/**
 * WP Site Transfer Manager — direct transfer (pull / push) screen.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const page = document.querySelector( '[data-wstm-page="transfer"]' );
	if ( ! A || ! A.drive || ! page ) {
		return;
	}
	const { api, esc, confirmDestructive, errorText } = A;
	const run = document.getElementById( 'wstm-mig-run' );
	const ui = {
		title: run.querySelector( '.wstm-run__title' ),
		bar: run.querySelector( '.wstm-progress span' ),
		pct: run.querySelector( '.wstm-run__pct' ),
		step: run.querySelector( '.wstm-run__step' ),
		body: run.querySelector( '.wstm-run__body' ),
		actions: run.querySelector( '.wstm-run__actions' ),
	};
	const checked = ( id ) => document.getElementById( id ).checked;
	let busy = false;

	const progress = ( p, step ) => {
		p = Math.max( 0, Math.min( 100, Number( p ) || 0 ) );
		ui.bar.style.width = p + '%';
		ui.pct.textContent = p.toFixed( 0 ) + '%';
		ui.step.textContent = step || '';
	};
	const show = ( title ) => {
		run.hidden = false;
		run.classList.remove( 'is-done', 'is-failed' );
		ui.title.textContent = title;
		ui.body.innerHTML = '';
		ui.actions.innerHTML = '';
		progress( 0, 'Starting…' );
		run.scrollIntoView( { behavior: 'smooth', block: 'start' } );
	};
	const fail = ( e, retry ) => {
		run.classList.add( 'is-failed' );
		const d = ( e && e.data ) || e || {};
		ui.body.innerHTML = '<div class="notice notice-error inline"><p><strong>' + esc( d.what || e.message || 'Failed' ) + '</strong></p>' + ( d.why ? '<p>' + esc( d.why ) + '</p>' : '' ) + ( d.action ? '<p><b>What to do:</b> ' + esc( d.action ) + '</p>' : '' ) + '</div>';
		if ( retry ) {
			const b = document.createElement( 'button' );
			b.className = 'button button-primary';
			b.textContent = 'Resume';
			b.onclick = retry;
			ui.actions.appendChild( b );
		}
	};
	const retry = ( e ) => !! ( e && ( e.resumable || ( e.data && e.data.resumable ) ) );

	async function start( mode ) {
		if ( busy ) { return; }
		const key = document.getElementById( 'wstm-tf-' + mode + '-key' ).value.trim();
		if ( ! key ) {
			show( 'Transfer' );
			fail( { what: 'Paste the transfer key from the other site first.' } );
			return;
		}
		const ok = await confirmDestructive(
			'pull' === mode ? 'Replace THIS site?' : 'Replace the OTHER site?',
			'pull' === mode ? 'This operation will replace this site\'s database, media, themes and plugins with the other site. A safety backup and an undo point are created first. You will log in with the other site\'s users afterwards' + ( checked( 'wstm-tf-keep-users' ) ? ' — unless you keep this site\'s users (option ticked).' : '.' ) : 'This operation will replace the other site\'s database, media, themes and plugins with this site. The other site creates a safety backup and an undo point first.',
			( window.WSTM.i18n || {} ).confirm
		);
		if ( ! ok ) { return; }
		busy = true;
		show( 'pull' === mode ? 'Pulling site' : 'Pushing site' );
		try {
			const job = await api( 'transfers/' + mode, { method: 'POST', body: { key, confirm: true, keep_users: checked( 'wstm-tf-keep-users' ), skip: { media: checked( 'wstm-tf-skip-media' ), revisions: true, spam_comments: true, cache: true }, allow_unknown_disk: checked( 'wstm-tf-disk' ) } } );
			await follow( job.id, job.token, mode );
		} catch ( err ) {
			fail( err );
		} finally {
			busy = false;
			loadKeys();
		}
	}

	async function follow( id, token, mode ) {
		const runner = A.tokenRunner( id, token );
		const job = await A.drive( runner, ( j ) => progress( j.progress, j.current_step ), () => { ui.step.textContent = 'Connection problem — retrying…'; } );
		if ( 'completed' !== job.status ) {
			if ( 'cancelled' !== job.status ) {
				fail( job.error || {}, retry( job.error ) ? async () => { await api( 'jobs/' + id + '/resume', { method: 'POST' } ).catch( () => null ); show( 'Resuming' ); follow( id, token, mode ); } : null );
			}
			return;
		}
		if ( 'pull' === mode && job.metadata.child_job ) {
			// Downloaded: now import it here (token survives the user-table switch).
			ui.title.textContent = 'Importing pulled site';
			const child = await A.drive( A.tokenRunner( job.metadata.child_job, token ), ( j ) => progress( j.progress, j.current_step ), () => { ui.step.textContent = 'Connection problem — retrying…'; } );
			if ( 'completed' !== child.status ) {
				fail( child.error || {}, retry( child.error ) ? async () => { await A.tokenRunner( child.id, token )().catch( () => null ); show( 'Resuming import' ); follow( id, token, mode ); } : null );
				return;
			}
			run.classList.add( 'is-done' );
			progress( 100, '' );
			ui.title.textContent = 'Site pulled 🎉';
			ui.body.innerHTML = '<p>' + esc( job.metadata.remote ) + ' is now running here (' + esc( child.metadata.site_url ) + '). ' + ( child.metadata.database ? 'Log in with a user from the other site' + ( checked( 'wstm-tf-keep-users' ) ? ' (or your own — users were kept).' : '.' ) : '' ) + '</p>';
			ui.actions.innerHTML = '<a class="button button-primary button-hero" href="' + esc( child.metadata.login_url ) + '">Log in</a>';
			return;
		}
		run.classList.add( 'is-done' );
		progress( 100, '' );
		ui.title.textContent = 'Site pushed 🎉';
		ui.body.innerHTML = '<p>This site is now running on <a href="' + esc( job.metadata.remote_url ) + '" target="_blank" rel="noopener">' + esc( job.metadata.remote_url ) + '</a>. The other site kept a safety backup and an undo point.</p>';
	}

	async function loadKeys() {
		const el = document.getElementById( 'wstm-tf-keys' );
		try {
			const d = await api( 'transfers' );
			el.innerHTML = d.keys.length ? '<table class="widefat striped"><thead><tr><th>Key</th><th>Allows</th><th>Status</th><th>Expires (UTC)</th><th></th></tr></thead><tbody>' + d.keys.map( ( k ) => '<tr><td><code>' + esc( k.short ) + '…</code></td><td>' + ( 'pull' === k.direction ? 'pulling this site' : 'pushing into this site' ) + '</td><td>' + esc( k.status ) + '</td><td>' + esc( k.expires_at ) + '</td><td>' + ( 'active' === k.status ? '<button type="button" class="button button-small button-link-delete" data-revoke="' + esc( k.transfer_id ) + '">Revoke</button>' : '' ) + '</td></tr>' ).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No keys yet.</p>';
			el.querySelectorAll( '[data-revoke]' ).forEach( ( b ) => b.addEventListener( 'click', async () => { await api( 'transfers/' + b.dataset.revoke + '/revoke', { method: 'POST' } ); loadKeys(); } ) );
		} catch ( err ) {
			el.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
		}
	}

	page.querySelectorAll( '[data-tf-key]' ).forEach( ( b ) => b.addEventListener( 'click', async () => {
		try {
			const k = await api( 'transfers/key', { method: 'POST', body: { mode: b.dataset.tfKey, minutes: Number( document.getElementById( 'wstm-tf-ttl' ).value ) } } );
			const box = document.getElementById( 'wstm-tf-newkey' );
			box.hidden = false;
			box.querySelector( 'textarea' ).value = k.key;
			box.querySelector( '.wstm-muted' ).textContent = 'Valid until ' + new Date( k.expires_at ).toLocaleString() + ( 'pull' === b.dataset.tfKey ? ' · paste it on the destination under “Pull another site”.' : ' · paste it on the source under “Push this site”.' );
			loadKeys();
		} catch ( err ) {
			A.notice( page, errorText( err ) );
		}
	} ) );
	document.getElementById( 'wstm-tf-copy' ).addEventListener( 'click', () => {
		const t = document.querySelector( '#wstm-tf-newkey textarea' );
		t.select();
		( navigator.clipboard ? navigator.clipboard.writeText( t.value ) : Promise.reject() ).catch( () => document.execCommand( 'copy' ) );
	} );
	document.getElementById( 'wstm-tf-pull' ).addEventListener( 'click', () => start( 'pull' ) );
	document.getElementById( 'wstm-tf-push' ).addEventListener( 'click', () => start( 'push' ) );
	loadKeys();
}() );
