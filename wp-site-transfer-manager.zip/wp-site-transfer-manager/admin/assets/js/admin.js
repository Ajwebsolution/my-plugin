/**
 * WP Site Transfer Manager — admin script (vanilla JS, no dependencies).
 *
 * Provides: REST client, confirmation modal for destructive actions,
 * job polling on the dashboard. Later phases extend window.WSTMAdmin.
 */
( function () {
	'use strict';

	const cfg = window.WSTM || {};
	const i18n = cfg.i18n || {};

	/**
	 * REST request helper. Throws an Error with structured `data` on failure.
	 */
	function restUrl( path ) {
		path = path.replace( /^\//, '' );
		// Sites without pretty permalinks use "?rest_route=…", so query strings must be joined with "&".
		const q = path.indexOf( '?' );
		if ( cfg.restRoot.indexOf( '?' ) !== -1 && q !== -1 ) {
			return cfg.restRoot + path.slice( 0, q ) + '&' + path.slice( q + 1 );
		}
		return cfg.restRoot + path;
	}

	async function api( path, options = {} ) {
		const res = await fetch( restUrl( path ), {
			method: options.method || 'GET',
			credentials: 'same-origin',
			headers: Object.assign( { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json' }, options.headers || {} ),
			body: options.body ? JSON.stringify( options.body ) : undefined,
		} );
		let json = null;
		try { json = await res.json(); } catch ( e ) { /* non-JSON */ }
		if ( ! res.ok ) {
			const err = new Error( ( json && json.message ) || i18n.error || 'Request failed' );
			err.data = json && json.data;
			err.status = res.status;
			throw err;
		}
		return json;
	}

	/**
	 * Confirmation modal. Resolves true only when the acknowledgement box is ticked and Continue pressed.
	 */
	function confirmDestructive( title, message, ackText ) {
		const modal = document.getElementById( 'wstm-confirm-modal' );
		if ( ! modal ) {
			return Promise.resolve( window.confirm( message ) );
		}
		const ack = modal.querySelector( '#wstm-modal-ack' );
		const btnContinue = modal.querySelector( '[data-wstm-modal="continue"]' );
		const btnCancel = modal.querySelector( '[data-wstm-modal="cancel"]' );
		modal.querySelector( '#wstm-modal-title' ).textContent = title || '';
		modal.querySelector( '.wstm-modal__message' ).textContent = message || '';
		modal.querySelector( '.wstm-modal__ack span' ).textContent = ackText || i18n.confirm;
		btnContinue.textContent = i18n.continue || 'Continue';
		btnCancel.textContent = i18n.cancel || 'Cancel';
		ack.checked = false;
		btnContinue.disabled = true;
		modal.hidden = false;
		btnCancel.focus();

		return new Promise( ( resolve ) => {
			const onAck = () => { btnContinue.disabled = ! ack.checked; };
			const close = ( result ) => {
				modal.hidden = true;
				ack.removeEventListener( 'change', onAck );
				btnContinue.removeEventListener( 'click', onContinue );
				btnCancel.removeEventListener( 'click', onCancel );
				document.removeEventListener( 'keydown', onKey );
				resolve( result );
			};
			const onContinue = () => close( ack.checked );
			const onCancel = () => close( false );
			const onKey = ( e ) => { if ( 'Escape' === e.key ) { close( false ); } };
			ack.addEventListener( 'change', onAck );
			btnContinue.addEventListener( 'click', onContinue );
			btnCancel.addEventListener( 'click', onCancel );
			document.addEventListener( 'keydown', onKey );
		} );
	}

	/** Intercept links/buttons marked data-wstm-confirm. */
	document.addEventListener( 'click', async ( e ) => {
		const el = e.target.closest( '[data-wstm-confirm]' );
		if ( ! el || el.dataset.wstmConfirmed ) {
			return;
		}
		e.preventDefault();
		const ok = await confirmDestructive( el.dataset.wstmConfirmTitle, el.dataset.wstmConfirm );
		if ( ! ok ) {
			return;
		}
		if ( el.href ) {
			window.location.href = el.href;
		} else {
			el.dataset.wstmConfirmed = '1';
			el.click();
		}
	} );

	/** Progressive enhancement: refresh diagnostics via REST. */
	const diagForm = document.querySelector( '[data-wstm-refresh-diagnostics]' );
	if ( diagForm ) {
		diagForm.addEventListener( 'submit', async ( e ) => {
			e.preventDefault();
			const btn = diagForm.querySelector( 'button' );
			btn.disabled = true;
			btn.textContent = i18n.refreshing || '…';
			try {
				await api( 'diagnostics?refresh=1' );
				window.location.reload();
			} catch ( err ) {
				diagForm.submit(); // Fallback to admin-post.
			}
		} );
	}

	/** Escape text for safe insertion. */
	function esc( s ) {
		const d = document.createElement( 'div' );
		d.textContent = null == s ? '' : String( s );
		return d.innerHTML;
	}

	const BADGES = { running: [ '●', 'running' ], pending: [ '○', 'info' ], paused: [ '❚❚', 'warning' ], failed: [ '✕', 'error' ], completed: [ '✓', 'success' ], cancelled: [ '–', 'info' ], rollback: [ '↺', 'warning' ] };

	/** Poll active jobs on the dashboard (only while something is running). */
	const jobBox = document.querySelector( '[data-wstm-poll="jobs"]' );
	if ( jobBox ) {
		let timer = null;
		const render = ( jobs ) => {
			if ( ! jobs.length ) {
				jobBox.innerHTML = '<p class="wstm-muted">' + esc( i18n.noJobs ) + '</p>';
				return;
			}
			jobBox.innerHTML = jobs.map( ( j ) => {
				const b = BADGES[ j.status ] || [ '•', 'info' ];
				const pct = Math.max( 0, Math.min( 100, Number( j.progress ) || 0 ) );
				const err = j.error ? '<p class="wstm-error-line">' + esc( ( j.error.what || '' ) + ' — ' + ( j.error.why || '' ) ) + '</p>' : '';
				return '<div class="wstm-job"><div class="wstm-job__head"><span class="wstm-badge wstm-badge--' + b[ 1 ] + '">' + b[ 0 ] + '</span> <strong>#' + esc( j.id ) + ' ' + esc( j.type ) + '</strong> <span class="wstm-muted">' + esc( j.current_step ) + '</span></div>' +
					'<div class="wstm-progress" role="progressbar" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"><span style="width:' + pct + '%"></span></div>' + err + '</div>';
			} ).join( '' );
		};
		const poll = async () => {
			try {
				const jobs = await api( 'jobs?status=running,pending,paused,failed&per_page=10' );
				render( jobs );
				const active = jobs.some( ( j ) => 'running' === j.status || 'pending' === j.status );
				timer = setTimeout( poll, active ? 3000 : 30000 );
			} catch ( e ) {
				timer = setTimeout( poll, 30000 );
			}
		};
		timer = setTimeout( poll, 3000 );
		document.addEventListener( 'visibilitychange', () => {
			if ( document.hidden ) { clearTimeout( timer ); } else { clearTimeout( timer ); poll(); }
		} );
	}

	window.WSTMAdmin = { api, confirmDestructive, esc, restUrl };
}() );
