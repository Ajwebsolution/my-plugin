/**
 * WP Site Transfer Manager — one-click Export / Import screens.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const cfg = window.WSTM || {};
	if ( ! A || ! A.upload ) {
		return;
	}

	/** One token-authenticated run request (works even after the login is invalidated by a DB switch). */
	A.tokenRunner = ( id, token ) => async () => {
		const res = await fetch( A.restUrl( 'migration/run/' + id + '?token=' + token ), { method: 'POST', credentials: 'omit' } );
		const json = await res.json().catch( () => null );
		if ( ! res.ok ) { throw Object.assign( new Error( ( json && json.message ) || 'HTTP ' + res.status ), { status: res.status, data: json && json.data } ); }
		return json;
	};

	/** Drive a job until it stops; transient errors are retried. */
	A.drive = async ( runner, onUpdate, onRetry ) => {
		let errors = 0;
		for ( ;; ) {
			let job;
			try {
				job = await runner();
				errors = 0;
			} catch ( err ) {
				if ( err.status && err.status < 500 && 408 !== err.status && 429 !== err.status ) { throw err; }
				if ( ++errors > 20 ) { throw err; }
				if ( onRetry ) { onRetry( errors ); }
				await new Promise( ( r ) => setTimeout( r, Math.min( 15000, 1500 * errors ) ) );
				continue;
			}
			onUpdate( job );
			if ( 'running' !== job.status && 'pending' !== job.status ) { return job; }
			await new Promise( ( r ) => setTimeout( r, 150 ) );
		}
	};

	const page = document.querySelector( '[data-wstm-page="simple-export"], [data-wstm-page="simple-import"]' );
	if ( ! page ) {
		return;
	}
	const { api, esc, confirmDestructive, fmtBytes, errorText } = A;
	const mode = page.dataset.wstmPage;
	const run = document.getElementById( 'wstm-mig-run' );
	const ui = {
		title: run.querySelector( '.wstm-run__title' ),
		bar: run.querySelector( '.wstm-progress span' ),
		pct: run.querySelector( '.wstm-run__pct' ),
		step: run.querySelector( '.wstm-run__step' ),
		body: run.querySelector( '.wstm-run__body' ),
		actions: run.querySelector( '.wstm-run__actions' ),
	};
	const checked = ( id ) => !! ( document.getElementById( id ) || {} ).checked;

	function show( title, pct, step ) {
		run.hidden = false;
		run.classList.remove( 'is-done', 'is-failed' );
		ui.title.textContent = title;
		setProgress( pct, step );
	}
	function setProgress( pct, step ) {
		const p = Math.max( 0, Math.min( 100, Number( pct ) || 0 ) );
		ui.bar.style.width = p + '%';
		ui.pct.textContent = p.toFixed( 0 ) + '%';
		ui.step.textContent = step || '';
	}
	function actions( list ) {
		ui.actions.innerHTML = '';
		list.forEach( ( [ label, fn, primary ] ) => {
			const b = document.createElement( 'button' );
			b.type = 'button';
			b.className = 'button' + ( primary ? ' button-primary' : '' );
			b.textContent = label;
			b.addEventListener( 'click', fn );
			ui.actions.appendChild( b );
		} );
	}
	function fail( err, retry ) {
		run.classList.add( 'is-failed' );
		const d = err.data || err;
		ui.body.innerHTML = '<div class="notice notice-error inline"><p><strong>' + esc( d.what || err.message || 'Failed' ) + '</strong></p>' +
			( d.why ? '<p>' + esc( d.why ) + '</p>' : '' ) +
			( d.completed ? '<p><b>Completed:</b> ' + esc( d.completed ) + '</p>' : '' ) +
			( d.action ? '<p><b>What to do:</b> ' + esc( d.action ) + '</p>' : '' ) + '</div>';
		actions( retry ? [ [ 'Retry from where it stopped', retry, true ] ] : [] );
	}

	const drive = ( runner, onUpdate ) => A.drive( runner, onUpdate, () => { ui.step.textContent = 'Connection problem — retrying (progress is saved on the server)…'; } );

	/* ===================== Export ===================== */
	if ( 'simple-export' === mode ) {
		const btn = document.getElementById( 'wstm-mig-export' );

		async function loadRecent() {
			const el = document.getElementById( 'wstm-mig-recent' );
			try {
				const data = await api( 'packages' );
				const list = data.packages.slice( 0, 5 );
				el.innerHTML = list.length ? '<table class="widefat striped"><tbody>' + list.map( ( p ) => '<tr><td><code>' + esc( p.file ) + '</code></td><td>' + esc( fmtBytes( p.size ) ) + '</td><td>' + esc( new Date( p.modified ).toLocaleString() ) + '</td><td><a class="button button-small" href="' + esc( p.download ) + '">Download</a></td></tr>' ).join( '' ) + '</tbody></table><p class="wstm-muted">Manage, validate or delete packages under Advanced Export.</p>' : '<p class="wstm-muted">No exports yet.</p>';
			} catch ( err ) {
				el.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
			}
		}

		async function exportSite( resumeId ) {
			btn.disabled = true;
			ui.body.innerHTML = '';
			actions( [] );
			show( 'Exporting site', 0, 'Starting…' );
			try {
				let id = resumeId;
				if ( ! id ) {
					const skip = {};
					document.querySelectorAll( '#wstm-mig-skip input' ).forEach( ( c ) => { skip[ c.value ] = c.checked; } );
					const job = await api( 'migration/export', { method: 'POST', body: { skip, exclusions: document.getElementById( 'wstm-mig-excl' ).value.split( /\r?\n/ ).map( ( s ) => s.trim() ).filter( Boolean ) } } );
					id = job.id;
				} else {
					await api( 'jobs/' + id + '/resume', { method: 'POST' } ).catch( () => null );
				}
				actions( [ [ 'Cancel', async () => { await api( 'jobs/' + id + '/cancel', { method: 'POST' } ).catch( () => null ); } ] ] );
				const job = await drive( () => api( 'jobs/' + id + '/run', { method: 'POST' } ), ( j ) => setProgress( j.progress, j.current_step ) );
				if ( 'completed' !== job.status ) {
					if ( 'cancelled' === job.status ) { run.hidden = true; return; }
					fail( job.error || {}, job.error && job.error.resumable ? () => exportSite( id ) : null );
					return;
				}
				run.classList.add( 'is-done' );
				ui.title.textContent = 'Export complete';
				setProgress( 100, '' );
				const data = await api( 'packages' );
				const pkg = data.packages.find( ( p ) => p.file === job.metadata.file );
				ui.body.innerHTML = '<p>Your site is packed into <code>' + esc( job.metadata.file ) + '</code> (' + esc( fmtBytes( job.metadata.size ) ) + '). Download it, then go to <b>WP Site Transfer → Import</b> on the destination site.</p>' +
					( job.metadata.warnings && job.metadata.warnings.length ? '<details class="wstm-warnings"><summary>⚠ ' + job.metadata.warnings.length + ' note(s)</summary><ul>' + job.metadata.warnings.map( ( w ) => '<li>' + esc( w ) + '</li>' ).join( '' ) + '</ul></details>' : '' );
				ui.actions.innerHTML = pkg ? '<a class="button button-primary button-hero" href="' + esc( pkg.download ) + '"><span class="dashicons dashicons-download"></span> Download ' + esc( fmtBytes( pkg.size ) ) + '</a>' : '';
				if ( pkg ) { window.location.href = pkg.download; }
				loadRecent();
			} catch ( err ) {
				fail( err, null );
			} finally {
				btn.disabled = false;
			}
		}

		btn.addEventListener( 'click', () => exportSite() );
		loadRecent();
		api( 'jobs?status=running,pending,paused&per_page=10' ).then( ( jobs ) => {
			const j = jobs.find( ( x ) => 'package_export' === x.type );
			if ( j ) { exportSite( j.id ); }
		} ).catch( () => null );
	}

	/* ===================== Import ===================== */
	if ( 'simple-import' === mode ) {
		const drop = document.getElementById( 'wstm-drop' );
		const input = document.getElementById( 'wstm-drop-input' );
		let busy = false;

		async function restore( file, info ) {
			const comps = info && info.components ? Object.keys( info.components ).filter( ( k ) => info.components[ k ] ) : [];
			const ok = await confirmDestructive(
				'Import ' + file + '?',
				'This operation will replace this site\'s ' + ( comps.length ? comps.join( ', ' ) : 'database and files' ) + ' with the contents of the file' + ( info && info.source ? ' (exported from ' + info.source + ')' : '' ) + '. This site\'s address stays ' + location.origin + '. You will need to log in again with a user from the imported site.',
				( cfg.i18n || {} ).confirm
			);
			if ( ! ok ) { busy = false; return; }
			show( 'Importing', 0, 'Starting…' );
			ui.body.innerHTML = '';
			try {
				const job = await api( 'migration/import', { method: 'POST', body: { file, confirm: true, safety_backup: checked( 'wstm-mig-safety' ), allow_uploads_exec: checked( 'wstm-mig-exec' ), allow_unknown_disk: checked( 'wstm-mig-disk' ) } } );
				await follow( job.id, job.token );
			} catch ( err ) {
				fail( err, null );
			} finally {
				busy = false;
			}
		}

		async function follow( id, token ) {
			// Token-driven requests without cookies keep working after the user table is replaced.
			const runner = A.tokenRunner( id, token );
			try { sessionStorage.setItem( 'wstm_restore', JSON.stringify( { id, token } ) ); } catch ( e ) { /* optional */ }
			const job = await drive( runner, ( j ) => setProgress( j.progress, j.current_step ) );
			if ( 'completed' !== job.status ) {
				const point = job.metadata && job.metadata.rollback_id;
				setTimeout( () => {
					if ( point ) {
						const b = document.createElement( 'button' );
						b.type = 'button';
						b.className = 'button';
						b.textContent = 'Undo changes made so far';
						b.addEventListener( 'click', () => A.undo( point ) );
						ui.actions.appendChild( b );
					}
				}, 0 );
				fail( job.error || {}, job.error && job.error.resumable ? async () => {
					await api( 'jobs/' + id + '/resume', { method: 'POST' } ).catch( () => runner() );
					show( 'Importing', job.progress, 'Resuming…' );
					ui.body.innerHTML = '';
					follow( id, token );
				} : null );
				return;
			}
			try { sessionStorage.removeItem( 'wstm_restore' ); } catch ( e ) { /* optional */ }
			const m = job.metadata;
			run.classList.add( 'is-done' );
			ui.title.textContent = 'Import complete 🎉';
			setProgress( 100, '' );
			ui.body.innerHTML = '<dl class="wstm-summary">' +
				( m.source_url ? '<dt>Imported from</dt><dd>' + esc( m.source_url ) + '</dd>' : '' ) +
				'<dt>This site</dt><dd>' + esc( m.site_url ) + '</dd>' +
				'<dt>Files restored</dt><dd>' + esc( Number( m.files_applied ).toLocaleString() ) + ' (' + esc( Number( m.files_replaced ).toLocaleString() ) + ' replaced — previous versions kept)</dd>' +
				( m.database ? '<dt>Database</dt><dd>Imported and switched · ' + esc( Number( m.replacements ).toLocaleString() ) + ' URL/path references updated</dd>' : '' ) +
				( m.safety_backup ? '<dt>Safety backup</dt><dd><code>' + esc( m.safety_backup ) + '</code></dd>' : '' ) +
				'</dl>' +
				( m.warnings && m.warnings.length ? '<details class="wstm-warnings"><summary>⚠ ' + m.warnings.length + ' note(s)</summary><ul>' + m.warnings.map( ( w ) => '<li>' + esc( w ) + '</li>' ).join( '' ) + '</ul></details>' : '' ) +
				( m.database ? '<p>Log in with a username and password <b>from the imported site</b>. Permalinks are refreshed automatically.</p>' : '' ) +
				( m.health && A.renderHealth ? '<h3>Health check</h3>' + A.renderHealth( m.health ) : '' );
			ui.actions.innerHTML = m.database ? '<a class="button button-primary button-hero" href="' + esc( m.login_url ) + '">Log in</a>' : '<a class="button button-primary" href="' + esc( location.href ) + '">Done</a>';
		}

		async function handleFile( file ) {
			if ( busy || ! file ) { return; }
			if ( ! /\.wpmig$/i.test( file.name ) ) {
				show( 'Wrong file type', 0, '' );
				fail( { what: 'Please choose a .wpmig file created by WP Site Transfer Manager.', why: file.name }, null );
				return;
			}
			busy = true;
			let stopped = false;
			show( 'Uploading ' + file.name, 0, '' );
			ui.body.innerHTML = '';
			actions( [ [ 'Stop', () => { stopped = true; } ] ] );
			try {
				const done = await A.upload( file, {
					allowUnknownDisk: checked( 'wstm-mig-disk' ),
					isStopped: () => stopped,
					onProgress: ( off, total, speed, msg ) => setProgress( 100 * off / total, msg || ( fmtBytes( off ) + ' of ' + fmtBytes( total ) + ( speed ? ' · ' + fmtBytes( speed ) + '/s' : '' ) ) ),
				} );
				actions( [] );
				if ( done.stopped ) {
					ui.step.textContent = 'Paused at ' + fmtBytes( done.received ) + '. Drop the same file again to continue.';
					busy = false;
					return;
				}
				setProgress( 100, 'Upload complete' );
				await restore( done.file, null );
			} catch ( err ) {
				busy = false;
				fail( err, () => handleFile( file ) );
			}
		}

		drop.addEventListener( 'click', ( e ) => { if ( e.target.id !== 'wstm-drop-pick' ) { input.click(); } } );
		document.getElementById( 'wstm-drop-pick' ).addEventListener( 'click', ( e ) => { e.stopPropagation(); input.click(); } );
		drop.addEventListener( 'keydown', ( e ) => { if ( 'Enter' === e.key || ' ' === e.key ) { e.preventDefault(); input.click(); } } );
		input.addEventListener( 'change', () => handleFile( input.files[ 0 ] ) );
		[ 'dragenter', 'dragover' ].forEach( ( ev ) => drop.addEventListener( ev, ( e ) => { e.preventDefault(); drop.classList.add( 'is-over' ); } ) );
		[ 'dragleave', 'drop' ].forEach( ( ev ) => drop.addEventListener( ev, ( e ) => { e.preventDefault(); drop.classList.remove( 'is-over' ); } ) );
		drop.addEventListener( 'drop', ( e ) => handleFile( e.dataTransfer.files[ 0 ] ) );

		// Packages already on the server.
		api( 'packages' ).then( ( data ) => {
			const el = document.getElementById( 'wstm-mig-server' );
			el.innerHTML = data.packages.length ? '<table class="widefat striped"><tbody>' + data.packages.map( ( p, i ) => '<tr><td><code>' + esc( p.file ) + '</code><br><span class="wstm-muted">' + esc( p.info && p.info.source ? 'from ' + p.info.source : 'not verified yet' ) + '</span></td><td>' + esc( fmtBytes( p.size ) ) + '</td><td>' + esc( new Date( p.modified ).toLocaleString() ) + '</td><td><button type="button" class="button button-primary button-small" data-restore="' + i + '">Restore</button></td></tr>' ).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No packages on this server. Drop a file above.</p>';
			el.querySelectorAll( '[data-restore]' ).forEach( ( b ) => b.addEventListener( 'click', () => {
				if ( busy ) { return; }
				busy = true;
				const p = data.packages[ b.dataset.restore ];
				window.scrollTo( { top: 0, behavior: 'smooth' } );
				restore( p.file, p.info );
			} ) );
		} ).catch( ( err ) => { document.getElementById( 'wstm-mig-server' ).innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>'; } );

		// Re-attach to a restore that was running when the page was left.
		try {
			const saved = JSON.parse( sessionStorage.getItem( 'wstm_restore' ) || 'null' );
			if ( saved && saved.id && saved.token ) {
				show( 'Importing', 0, 'Reconnecting…' );
				follow( saved.id, saved.token ).catch( ( err ) => fail( err, null ) );
			}
		} catch ( e ) { /* optional */ }
	}
}() );
