/**
 * WP Site Transfer Manager — URL scan / dry run / replace UI.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const page = document.querySelector( '[data-wstm-page="url"]' );
	if ( ! A || ! A.JobMonitor || ! page ) {
		return;
	}
	const { api, esc, confirmDestructive, errorText, notice } = A;
	const tbody = document.querySelector( '#wstm-pairs tbody' );
	const report = document.getElementById( 'wstm-url-report' );
	const replaceBtn = document.getElementById( 'wstm-url-replace' );
	const checked = ( id ) => document.getElementById( id ).checked;
	let dryKey = null;

	function addPair( oldVal, newVal ) {
		const tr = document.createElement( 'tr' );
		tr.innerHTML = '<td><input type="text" class="code wstm-old" placeholder="https://old-site.com"></td><td>→</td><td><input type="text" class="code wstm-new" placeholder="https://new-site.com"></td><td><button type="button" class="button-link" aria-label="Remove">✕</button></td>';
		tr.querySelector( '.wstm-old' ).value = oldVal || '';
		tr.querySelector( '.wstm-new' ).value = newVal || '';
		tr.querySelector( 'button' ).addEventListener( 'click', () => { tr.remove(); invalidate(); } );
		tbody.appendChild( tr );
	}

	function params() {
		let pairs = [ ...tbody.querySelectorAll( 'tr' ) ].map( ( tr ) => ( { old: tr.querySelector( '.wstm-old' ).value.trim(), new: tr.querySelector( '.wstm-new' ).value.trim() } ) ).filter( ( p ) => p.old );
		if ( checked( 'wstm-opt-protocol' ) ) {
			const extra = [];
			pairs.forEach( ( p ) => {
				const m = p.old.match( /^(https?):\/\/(.*)$/i );
				if ( m ) {
					const other = ( 'http' === m[ 1 ].toLowerCase() ? 'https' : 'http' ) + '://' + m[ 2 ];
					if ( ! pairs.some( ( q ) => q.old === other ) ) { extra.push( { old: other, new: p.new } ); }
				}
			} );
			pairs = pairs.concat( extra );
		}
		return {
			pairs,
			tables: [ ...document.querySelectorAll( '#wstm-url-tables input:checked' ) ].map( ( c ) => c.value ),
			skip_guid: checked( 'wstm-opt-guid' ),
			url_encoded: checked( 'wstm-opt-encoded' ),
		};
	}

	function invalidate() {
		dryKey = null;
		replaceBtn.disabled = true;
	}

	function renderReport( job ) {
		const m = job.metadata || {};
		const t = m.totals || {};
		const rows = Object.keys( m.report || {} ).filter( ( k ) => m.report[ k ].values || m.report[ k ].unparseable ).map( ( k ) => {
			const r = m.report[ k ];
			return '<tr><td><code>' + esc( k ) + '</code></td><td>' + esc( r.rows ) + '</td><td>' + esc( r.serialized ) + '</td><td>' + esc( r.json ) + '</td><td>' + esc( r.plain ) + '</td><td>' + esc( r.replacements ) + '</td><td>' + ( r.unparseable ? '<span class="wstm-error-line">' + esc( r.unparseable ) + '</span>' : '0' ) + '</td></tr>';
		} ).join( '' );
		const label = { scan: 'Scan results', dry_run: 'Dry run — nothing has been changed', replace: 'Replacement complete' }[ m.mode ] || 'Results';
		let html = '<h2>' + esc( label ) + '</h2>' +
			'<p>' + [ [ 'Tables affected', Object.keys( m.report || {} ).filter( ( k ) => m.report[ k ].values ).length ], [ 'Rows affected', t.rows ], [ 'Serialized values', t.serialized ], [ 'JSON values', t.json ], [ 'Plain values', t.plain ], [ 'mode' in m && 'scan' === m.mode ? 'Estimated replacements' : 'Replacements', t.replacements ] ]
				.map( ( s ) => '<span class="wstm-stat"><b>' + esc( Number( s[ 1 ] || 0 ).toLocaleString() ) + '</b>' + esc( s[ 0 ] ) + '</span>' ).join( '' ) + '</p>';
		html += rows ? '<table class="widefat striped"><thead><tr><th>Table</th><th>Rows</th><th>Serialized</th><th>JSON</th><th>Plain</th><th>Replacements</th><th>Corrupt (skipped)</th></tr></thead><tbody>' + rows + '</tbody></table>' : '<p>No matches found.</p>';
		if ( m.samples && m.samples.length ) {
			html += '<h3>Sample changes</h3><table class="widefat striped wstm-samples"><thead><tr><th>Where</th><th>Before</th><th>After</th></tr></thead><tbody>' +
				m.samples.map( ( s ) => '<tr><td>' + esc( s.table + '.' + s.column ) + '<br><span class="wstm-muted">' + esc( s.row + ' · ' + s.kind ) + '</span></td><td><del>' + esc( s.before ) + '</del></td><td><ins>' + esc( s.after ) + '</ins></td></tr>' ).join( '' ) + '</tbody></table>';
		}
		if ( m.remaining && Object.keys( m.remaining ).length ) {
			html += '<p class="wstm-muted">Rows still containing the old text: ' + esc( JSON.stringify( m.remaining ) ) + '</p>';
		}
		report.innerHTML = html;
		report.hidden = false;
	}

	async function run( route, body, onDone ) {
		try {
			const job = await api( route, { method: 'POST', body } );
			A.watch( job.id, ( j ) => {
				if ( 'completed' === j.status ) {
					renderReport( j );
					if ( onDone ) { onDone( j ); }
				}
			} );
		} catch ( err ) {
			notice( page, errorText( err ) );
		}
	}

	document.getElementById( 'wstm-add-pair' ).addEventListener( 'click', () => addPair() );
	tbody.addEventListener( 'input', invalidate );
	page.querySelectorAll( '.wstm-options input, #wstm-url-tables' ).forEach( ( el ) => el.addEventListener( 'change', invalidate ) );

	document.getElementById( 'wstm-url-scan' ).addEventListener( 'click', () => run( 'url/scan', Object.assign( params(), { mode: 'scan' } ) ) );
	document.getElementById( 'wstm-url-dry' ).addEventListener( 'click', () => {
		const p = params();
		const key = JSON.stringify( p );
		run( 'url/scan', Object.assign( {}, p, { mode: 'dry_run' } ), ( j ) => {
			dryKey = key;
			replaceBtn.disabled = ! ( j.metadata.totals && j.metadata.totals.values > 0 );
		} );
	} );
	replaceBtn.addEventListener( 'click', async () => {
		const p = params();
		if ( JSON.stringify( p ) !== dryKey ) {
			invalidate();
			notice( page, 'Settings changed since the dry run — please run the dry run again.' );
			return;
		}
		const list = p.pairs.map( ( x ) => x.old + ' → ' + x.new ).join( '\n' );
		const ok = await confirmDestructive( 'Replace in the database?', 'This operation will modify the database:\n' + list + '\n' + ( checked( 'wstm-opt-url-safety' ) ? 'A safety backup is created first.' : 'No safety backup will be created.' ), ( window.WSTM.i18n || {} ).confirm );
		if ( ! ok ) { return; }
		replaceBtn.disabled = true;
		run( 'url/replace', Object.assign( {}, p, { confirm: true, safety_backup: checked( 'wstm-opt-url-safety' ) } ), () => invalidate() );
	} );

	( async () => {
		try {
			const d = await api( 'url/defaults' );
			addPair( '', d.home_url );
			document.getElementById( 'wstm-url-tables' ).innerHTML = '<p class="wstm-muted">Leave all unticked to process every table of this site.</p>' + d.tables.map( ( t ) => '<label><input type="checkbox" value="' + esc( t.name ) + '"> <code>' + esc( t.name ) + '</code></label>' ).join( '' );
			document.querySelectorAll( '#wstm-url-tables input' ).forEach( ( c ) => c.addEventListener( 'change', invalidate ) );
			const jobs = await api( 'jobs?status=running,pending,paused,failed&per_page=20' );
			const job = jobs.find( ( j ) => 'url_scan' === j.type || 'url_replace' === j.type );
			if ( job ) {
				A.watch( job.id, ( j ) => { if ( 'completed' === j.status ) { renderReport( j ); } } );
			}
		} catch ( err ) {
			notice( page, errorText( err ) );
		}
	} )();
}() );
