/**
 * WP Site Transfer Manager — dashboard tools (health check, caches, link audit) and migration history.
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	if ( ! A || ! A.drive ) {
		return;
	}
	const { api, esc, errorText } = A;
	const badge = ( s ) => '<span class="wstm-badge wstm-badge--' + ( { pass: 'success', warning: 'warning', error: 'error' }[ s ] || 'info' ) + '">' + ( { pass: '✓', warning: '⚠', error: '✕' }[ s ] || '•' ) + '</span>';

	/** Render a health report (also used by the Import screen). */
	A.renderHealth = ( h ) => {
		const head = { pass: 'Everything looks healthy.', warning: 'Working, with warnings.', error: 'Problems found — see below.' }[ h.status ] || '';
		return '<div class="wstm-health"><p>' + badge( h.status ) + ' <strong>' + esc( head ) + '</strong></p><table class="widefat striped"><tbody>' + h.checks.map( ( c ) =>
			'<tr><td style="width:28px">' + badge( c.status ) + '</td><th>' + esc( c.label ) + '</th><td>' + esc( c.value ) + ( c.hint && 'pass' !== c.status ? '<br><span class="wstm-muted">' + esc( c.hint ) + '</span>' : '' ) + '</td></tr>' ).join( '' ) + '</tbody></table></div>';
	};

	const tools = document.querySelector( '[data-wstm-page="tools"]' );
	if ( tools ) {
		const out = document.getElementById( 'wstm-tool-out' );
		tools.querySelectorAll( '[data-tool]' ).forEach( ( b ) => b.addEventListener( 'click', async () => {
			const t = b.dataset.tool;
			b.disabled = true;
			out.innerHTML = '<p class="wstm-muted">Working…</p>';
			try {
				if ( 'health' === t ) {
					out.innerHTML = A.renderHealth( await api( 'tools/health' ) );
				} else if ( 'link-audit' === t ) {
					const job = await api( 'tools/link-audit', { method: 'POST', body: {} } );
					const done = await A.drive( () => api( 'jobs/' + job.id + '/run', { method: 'POST' } ), ( j ) => { out.innerHTML = '<p class="wstm-muted">' + esc( j.current_step ) + ' — ' + Number( j.progress ).toFixed( 0 ) + '%</p>'; } );
					const m = done.metadata;
					const list = ( title, items, fmt ) => items && items.length ? '<h4>' + esc( title ) + '</h4><ul>' + items.map( fmt ).join( '' ) + '</ul>' : '';
					const link = ( i ) => '<li><a href="' + esc( i.url ) + '" target="_blank" rel="noopener">' + esc( i.url ) + '</a> <span class="wstm-muted">in “' + esc( i.title ) + '” (#' + esc( i.post ) + ')' + ( i.status ? ' · HTTP ' + esc( i.status ) : '' ) + '</span></li>';
					out.innerHTML = '<p>' + [ [ 'Posts scanned', m.posts ], [ 'URLs', m.urls ], [ 'Internal', m.internal ], [ 'External (not checked)', m.external ], [ 'Old-domain references', m.old ], [ 'Missing files', m.missing ], [ 'Broken internal links', m.broken ] ].map( ( x ) => '<span class="wstm-stat"><b>' + esc( Number( x[ 1 ] || 0 ).toLocaleString() ) + '</b>' + esc( x[ 0 ] ) + '</span>' ).join( '' ) + '</p>' +
						list( 'Old-domain references (fix with URL Replace)', m.old_samples, link ) + list( 'Missing uploads / assets', m.missing_samples, link ) + list( 'Broken internal links', m.broken_samples, link ) +
						( m.old || m.missing || m.broken ? '' : '<p>' + badge( 'pass' ) + ' No problems found.</p>' ) + ( m.probe_capped ? '<p class="wstm-muted">Only the first 150 unresolved internal links were checked.</p>' : '' );
				} else {
					const r = await api( 'tools/' + t, { method: 'POST' } );
					out.innerHTML = '<p>' + badge( 'pass' ) + ' ' + esc( r.message ) + '</p>';
				}
			} catch ( err ) {
				out.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>';
			} finally {
				b.disabled = false;
			}
		} ) );
	}

	const hist = document.getElementById( 'wstm-history' );
	if ( hist ) {
		const names = { package_export: 'Export', site_restore: 'Import / restore', rollback: 'Undo import', transfer_pull: 'Pull', transfer_push: 'Push', backup_create: 'Backup', url_replace: 'URL replace', db_import: 'Database import', db_export: 'Database export' };
		const dur = ( s ) => null === s ? '—' : ( s >= 60 ? Math.floor( s / 60 ) + 'm ' : '' ) + ( s % 60 ) + 's';
		api( 'tools/history' ).then( ( rows ) => {
			hist.innerHTML = rows.length ? '<table class="widefat striped"><thead><tr><th>Date (UTC)</th><th>Type</th><th>Source → Destination</th><th>Size</th><th>Duration</th><th>Status</th></tr></thead><tbody>' + rows.slice( 0, 25 ).map( ( r ) =>
				'<tr><td class="wstm-nowrap">' + esc( r.date ) + '</td><td>' + esc( names[ r.type ] || r.type ) + '</td><td>' + esc( r.source || '—' ) + ' → ' + esc( r.target || '—' ) + '</td><td>' + ( r.size ? esc( A.fmtBytes( r.size ) ) : '—' ) + '</td><td>' + esc( dur( r.duration ) ) + '</td><td>' + badge( 'completed' === r.status ? ( r.warnings ? 'warning' : 'pass' ) : ( 'failed' === r.status ? 'error' : 'info' ) ) + ' ' + esc( r.status ) + ( r.error ? '<br><span class="wstm-muted">' + esc( r.error ) + '</span>' : '' ) + '</td></tr>' ).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No migrations yet.</p>';
		} ).catch( ( err ) => { hist.innerHTML = '<p class="wstm-error-line">' + errorText( err ) + '</p>'; } );
	}
}() );
