/**
 * WP Site Transfer Manager — cloud destinations (Backups screen).
 */
( function () {
	'use strict';

	const A = window.WSTMAdmin;
	const box = document.getElementById( 'wstm-cloud' );
	if ( ! A || ! box ) {
		return;
	}
	const { api, esc, errorText, notice, fmtBytes, confirmDestructive } = A;
	const list = document.getElementById( 'wstm-cloud-list' );
	const form = document.getElementById( 'wstm-cloud-form' );
	const files = document.getElementById( 'wstm-cloud-files' );
	const preset = document.getElementById( 'wstm-cl-preset' );
	const importUrl = ( window.WSTM.adminBase || 'admin.php' ) + '?page=wstm-import';
	let presets = {};
	let dests = [];

	function fill( d ) {
		form.reset();
		form.elements.id.value = d.id || '';
		[ 'label', 'endpoint', 'region', 'bucket', 'prefix' ].forEach( ( k ) => { form.elements[ k ].value = d[ k ] || ''; } );
		// Saved keys are never sent back in full: leave the field empty (= keep) and show the masked key as a hint.
		form.elements.access_key.value = '';
		form.elements.access_key.placeholder = d.id ? d.access_key + ' (leave empty to keep)' : '';
		form.elements.path_style.checked = !! d.path_style;
		document.getElementById( 'wstm-cl-secret-note' ).hidden = ! d.id;
		form.hidden = false;
	}

	async function load() {
		try {
			const data = await api( 'cloud' );
			presets = data.presets;
			dests = data.destinations;
			if ( ! preset.options.length ) {
				Object.keys( presets ).forEach( ( k ) => preset.add( new Option( presets[ k ].label, k ) ) );
			}
			list.innerHTML = dests.length ? '<table class="widefat striped"><thead><tr><th>Destination</th><th>Bucket</th><th>ID (for scheduled backups)</th><th></th></tr></thead><tbody>' + dests.map( ( d ) =>
				'<tr><td><strong>' + esc( d.label ) + '</strong><br><span class="wstm-muted">' + esc( d.endpoint ) + '</span></td><td><code>' + esc( d.bucket + ( d.prefix ? '/' + d.prefix : '' ) ) + '</code></td><td><code>' + esc( d.id ) + '</code></td>' +
				'<td class="wstm-nowrap"><button type="button" class="button button-small" data-act="test" data-id="' + esc( d.id ) + '">Test</button> <button type="button" class="button button-small" data-act="files" data-id="' + esc( d.id ) + '">Browse</button> <button type="button" class="button button-small" data-act="edit" data-id="' + esc( d.id ) + '">Edit</button> <button type="button" class="button button-small button-link-delete" data-act="remove" data-id="' + esc( d.id ) + '">Remove</button></td></tr>'
			).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No cloud destinations yet.</p>';
		} catch ( err ) {
			notice( box, errorText( err ) );
		}
	}

	async function browse( id ) {
		files.hidden = false;
		files.innerHTML = '<p class="wstm-muted">Loading…</p>';
		try {
			const data = await api( 'cloud/' + id + '/files' );
			files.innerHTML = '<h3>Backups in ' + esc( ( dests.find( ( d ) => d.id === id ) || {} ).label || id ) + '</h3>' + ( data.files.length ? '<table class="widefat striped"><thead><tr><th>File</th><th>Size</th><th>Uploaded</th><th></th></tr></thead><tbody>' + data.files.map( ( f ) =>
				'<tr><td><code>' + esc( f.name ) + '</code></td><td>' + esc( fmtBytes( f.size ) ) + '</td><td>' + esc( f.modified ? new Date( f.modified ).toLocaleString() : '' ) + '</td><td class="wstm-nowrap"><button type="button" class="button button-small button-primary" data-fetch="' + esc( f.key ) + '">Download to this site</button> <button type="button" class="button button-small button-link-delete" data-rm="' + esc( f.key ) + '">Delete</button></td></tr>'
			).join( '' ) + '</tbody></table>' : '<p class="wstm-muted">No .wpmig backups found.</p>' );
			files.querySelectorAll( '[data-fetch]' ).forEach( ( b ) => b.addEventListener( 'click', () => fetchFile( id, b.dataset.fetch, b ) ) );
			files.querySelectorAll( '[data-rm]' ).forEach( ( b ) => b.addEventListener( 'click', async () => {
				if ( ! await confirmDestructive( 'Delete cloud backup?', 'This permanently deletes ' + b.dataset.rm + ' from cloud storage.', 'I understand this backup will be deleted.' ) ) { return; }
				try { await api( 'cloud/' + id + '/files/delete', { method: 'POST', body: { key: b.dataset.rm, confirm: true } } ); browse( id ); } catch ( err ) { notice( box, errorText( err ) ); }
			} ) );
		} catch ( err ) {
			files.innerHTML = '';
			notice( box, errorText( err ) );
		}
	}

	async function fetchFile( id, key, btn ) {
		btn.disabled = true;
		try {
			const job = await api( 'cloud/' + id + '/fetch', { method: 'POST', body: { key } } );
			const done = await A.drive( () => api( 'jobs/' + job.id + '/run', { method: 'POST' } ), ( j ) => { btn.textContent = Math.round( j.progress ) + '%'; } );
			if ( 'completed' === done.status ) {
				btn.outerHTML = '<a class="button button-small button-primary" href="' + esc( importUrl ) + '">Downloaded — restore from Import</a>';
			} else {
				// Job errors carry what/why/action; show them like any other structured error.
				throw Object.assign( new Error( ( done.error && done.error.what ) || done.status ), { data: done.error || null } );
			}
		} catch ( err ) {
			btn.disabled = false;
			btn.textContent = 'Download to this site';
			notice( box, errorText( err ) );
		}
	}

	preset.addEventListener( 'change', () => {
		const p = presets[ preset.value ];
		if ( ! p ) { return; } // Presets not loaded yet.
		form.elements.endpoint.value = p.endpoint;
		form.elements.path_style.checked = !! p.path_style;
		if ( p.region ) { form.elements.region.value = p.region; }
	} );
	document.getElementById( 'wstm-cloud-add' ).addEventListener( 'click', () => { fill( {} ); preset.dispatchEvent( new Event( 'change' ) ); } );
	document.getElementById( 'wstm-cloud-cancel' ).addEventListener( 'click', () => { form.hidden = true; form.reset(); } );
	form.addEventListener( 'submit', async ( e ) => {
		e.preventDefault();
		const body = Object.fromEntries( new FormData( form ).entries() );
		body.path_style = form.elements.path_style.checked;
		if ( /\{(region|account)\}/.test( body.endpoint ) ) {
			notice( box, 'Replace {region}/{account} in the endpoint URL with your real values.' );
			return;
		}
		try {
			await api( 'cloud', { method: 'POST', body } );
			form.hidden = true;
			form.reset();
			load();
		} catch ( err ) {
			notice( box, errorText( err ) );
		}
	} );
	list.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-act]' );
		if ( ! b ) { return; }
		const id = b.dataset.id;
		if ( 'edit' === b.dataset.act ) { fill( dests.find( ( d ) => d.id === id ) ); return; }
		if ( 'files' === b.dataset.act ) { browse( id ); return; }
		b.disabled = true;
		try {
			if ( 'test' === b.dataset.act ) {
				const r = await api( 'cloud/' + id + '/test', { method: 'POST' } );
				notice( box, ( r.ok ? '✓ ' : '✕ ' ) + esc( r.message ), r.ok ? 'success' : 'error' );
			} else if ( 'remove' === b.dataset.act && window.confirm( 'Remove this destination? Files already in the cloud are not deleted.' ) ) {
				await api( 'cloud/' + id + '/delete', { method: 'POST' } );
				load();
			}
		} catch ( err ) {
			notice( box, errorText( err ) );
		}
		b.disabled = false;
	} );
	load();
}() );
