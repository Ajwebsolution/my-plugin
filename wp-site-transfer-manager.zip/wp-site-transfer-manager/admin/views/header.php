<?php
/**
 * Shared page header + tab navigation.
 *
 * @var string $title   Page title.
 * @var string $current Current sub page.
 * @package WSTM
 */

use WSTM\Admin\Admin;

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wstm-wrap">
	<header class="wstm-header">
		<h1 class="wstm-title">
			<span class="dashicons dashicons-migrate" aria-hidden="true"></span>
			<?php esc_html_e( 'WP Site Transfer', 'wp-site-transfer-manager' ); ?>
			<span class="wstm-sep">/</span> <?php echo esc_html( $title ); ?>
		</h1>
		<span class="wstm-version">v<?php echo esc_html( WSTM_VERSION ); ?></span>
	</header>
	<nav class="nav-tab-wrapper wstm-tabs" aria-label="<?php esc_attr_e( 'Plugin sections', 'wp-site-transfer-manager' ); ?>">
		<?php foreach ( Admin::pages() as $key => $def ) : ?>
			<a href="<?php echo esc_url( Admin::url( $key ) ); ?>" class="nav-tab <?php echo $key === $current ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $def[0] ); ?></a>
		<?php endforeach; ?>
	</nav>
	<div class="wstm-body">
