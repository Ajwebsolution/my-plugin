<?php
/**
 * URL Replace view (Phase 5).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-page-url" data-wstm-page="url">
	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Search & replace URLs', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Serialization-safe and JSON-safe: serialized lengths are recalculated, objects are never instantiated, Elementor/block JSON with escaped slashes is handled, and longer domains (example.com.au) are never touched.', 'wp-site-transfer-manager' ); ?></p>
		<table class="wstm-pairs" id="wstm-pairs">
			<thead><tr><th><?php esc_html_e( 'Old URL / text', 'wp-site-transfer-manager' ); ?></th><th></th><th><?php esc_html_e( 'New URL / text', 'wp-site-transfer-manager' ); ?></th><th></th></tr></thead>
			<tbody></tbody>
		</table>
		<p><button type="button" class="button" id="wstm-add-pair"><?php esc_html_e( '+ Add pair', 'wp-site-transfer-manager' ); ?></button></p>
		<fieldset class="wstm-options">
			<label><input type="checkbox" id="wstm-opt-protocol"> <?php esc_html_e( 'Also replace the other protocol of each old URL (http:// ↔ https://)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-encoded"> <?php esc_html_e( 'Also replace URL-encoded forms (https%3A%2F%2F…)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-guid" checked> <?php esc_html_e( 'Leave post GUIDs unchanged (recommended)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-url-safety" checked> <?php esc_html_e( 'Create a safety backup before replacing', 'wp-site-transfer-manager' ); ?></label>
		</fieldset>
		<details><summary><?php esc_html_e( 'Limit to tables', 'wp-site-transfer-manager' ); ?></summary><div id="wstm-url-tables" class="wstm-table-grid"></div></details>
		<p class="wstm-actions">
			<button type="button" class="button" id="wstm-url-scan"><?php esc_html_e( '1. Scan database', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" id="wstm-url-dry"><?php esc_html_e( '2. Dry run', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button button-primary" id="wstm-url-replace" disabled><?php esc_html_e( '3. Replace', 'wp-site-transfer-manager' ); ?></button>
		</p>
		<p class="description" id="wstm-url-hint"><?php esc_html_e( 'Replace becomes available after a dry run with the same settings.', 'wp-site-transfer-manager' ); ?></p>
	</section>

	<section class="wstm-card wstm-card--flat" id="wstm-monitor" hidden></section>
	<section class="wstm-card wstm-card--flat" id="wstm-url-report" hidden></section>
</div>
