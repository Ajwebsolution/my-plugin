<?php
/**
 * One-click import / restore (All-in-One style).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-mig" data-wstm-page="simple-import">
	<section class="wstm-drop" id="wstm-drop" tabindex="0" role="button" aria-label="<?php esc_attr_e( 'Choose a .wpmig file to import', 'wp-site-transfer-manager' ); ?>">
		<input type="file" id="wstm-drop-input" accept=".wpmig" hidden>
		<span class="dashicons dashicons-upload wstm-drop__icon" aria-hidden="true"></span>
		<h2><?php esc_html_e( 'Drag & drop a .wpmig file to import', 'wp-site-transfer-manager' ); ?></h2>
		<p><?php esc_html_e( 'or', 'wp-site-transfer-manager' ); ?> <button type="button" class="button button-primary" id="wstm-drop-pick"><?php esc_html_e( 'Choose file', 'wp-site-transfer-manager' ); ?></button></p>
		<p class="wstm-muted"><?php esc_html_e( 'No upload size limit — files are sent in resumable chunks. If the connection drops, choose the same file again to continue.', 'wp-site-transfer-manager' ); ?></p>
	</section>

	<section class="wstm-run" id="wstm-mig-run" hidden>
		<h2 class="wstm-run__title"></h2>
		<div class="wstm-progress wstm-progress--xl"><span style="width:0"></span></div>
		<p class="wstm-run__meta"><strong class="wstm-run__pct">0%</strong> <span class="wstm-run__step"></span></p>
		<div class="wstm-run__body"></div>
		<p class="wstm-actions wstm-run__actions"></p>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Restore from a file already on this server', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-mig-server"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
		<details class="wstm-adv">
			<summary><?php esc_html_e( 'Import options', 'wp-site-transfer-manager' ); ?></summary>
			<label><input type="checkbox" id="wstm-mig-safety" checked> <?php esc_html_e( 'Back up this site\'s database before importing (recommended)', 'wp-site-transfer-manager' ); ?></label><br>
			<label><input type="checkbox" id="wstm-mig-exec"> <?php esc_html_e( 'Also restore executable files found in uploads (not recommended)', 'wp-site-transfer-manager' ); ?></label><br>
			<label><input type="checkbox" id="wstm-mig-disk"> <?php esc_html_e( 'Proceed if free disk space cannot be determined', 'wp-site-transfer-manager' ); ?></label>
		</details>
	</section>
</div>
