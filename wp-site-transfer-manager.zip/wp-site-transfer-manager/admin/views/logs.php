<?php
/**
 * Logs view (paginated).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

use WSTM\Admin\Admin;
use WSTM\Core\Logger;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
$level  = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : '';
$level  = isset( Logger::LEVELS[ $level ] ) ? $level : '';
$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
$job_id = isset( $_GET['job_id'] ) ? absint( $_GET['job_id'] ) : 0;
// phpcs:enable
$per    = 50;
$result = $plugin->logger()->query( array( 'level' => $level, 'job_id' => $job_id, 'page' => $paged, 'per_page' => $per ) );
$pages  = max( 1, (int) ceil( $result['total'] / $per ) );
$action = static fn( string $do ) => wp_nonce_url( add_query_arg( array( 'action' => 'wstm_logs', 'do' => $do ), admin_url( 'admin-post.php' ) ), Security::nonce_action( 'logs' ), '_wstm_nonce' );
?>
<div class="wstm-toolbar">
	<form method="get">
		<input type="hidden" name="page" value="<?php echo esc_attr( Admin::SLUG . '-logs' ); ?>">
		<label for="wstm-level" class="screen-reader-text"><?php esc_html_e( 'Level', 'wp-site-transfer-manager' ); ?></label>
		<select id="wstm-level" name="level">
			<option value=""><?php esc_html_e( 'All levels', 'wp-site-transfer-manager' ); ?></option>
			<?php foreach ( array_keys( Logger::LEVELS ) as $l ) : ?>
				<option value="<?php echo esc_attr( $l ); ?>" <?php selected( $level, $l ); ?>><?php echo esc_html( strtoupper( $l ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<button class="button"><?php esc_html_e( 'Filter', 'wp-site-transfer-manager' ); ?></button>
	</form>
	<div class="wstm-toolbar__actions">
		<a class="button" href="<?php echo esc_url( $action( 'download' ) ); ?>"><?php esc_html_e( 'Download logs', 'wp-site-transfer-manager' ); ?></a>
		<a class="button" href="<?php echo esc_url( $action( 'prune' ) ); ?>"><?php esc_html_e( 'Delete old logs', 'wp-site-transfer-manager' ); ?></a>
		<a class="button button-link-delete" href="<?php echo esc_url( $action( 'clear' ) ); ?>"
			data-wstm-confirm="<?php esc_attr_e( 'This permanently deletes all log entries.', 'wp-site-transfer-manager' ); ?>"
			data-wstm-confirm-title="<?php esc_attr_e( 'Clear all logs?', 'wp-site-transfer-manager' ); ?>"><?php esc_html_e( 'Clear logs', 'wp-site-transfer-manager' ); ?></a>
	</div>
</div>

<table class="widefat striped wstm-log-table">
	<thead><tr>
		<th><?php esc_html_e( 'Time (UTC)', 'wp-site-transfer-manager' ); ?></th>
		<th><?php esc_html_e( 'Level', 'wp-site-transfer-manager' ); ?></th>
		<th><?php esc_html_e( 'Channel', 'wp-site-transfer-manager' ); ?></th>
		<th><?php esc_html_e( 'Job', 'wp-site-transfer-manager' ); ?></th>
		<th><?php esc_html_e( 'Message', 'wp-site-transfer-manager' ); ?></th>
	</tr></thead>
	<tbody>
	<?php if ( ! $result['rows'] ) : ?>
		<tr><td colspan="5" class="wstm-muted"><?php esc_html_e( 'No log entries.', 'wp-site-transfer-manager' ); ?></td></tr>
	<?php endif; ?>
	<?php foreach ( $result['rows'] as $row ) : ?>
		<tr>
			<td class="wstm-nowrap"><?php echo esc_html( $row['created_at'] ); ?></td>
			<td><span class="wstm-level wstm-level--<?php echo esc_attr( $row['level'] ); ?>"><?php echo esc_html( strtoupper( $row['level'] ) ); ?></span></td>
			<td><?php echo esc_html( $row['channel'] ); ?></td>
			<td><?php echo $row['job_id'] ? '<a href="' . esc_url( Admin::url( 'logs', array( 'job_id' => $row['job_id'] ) ) ) . '">#' . esc_html( $row['job_id'] ) . '</a>' : '—'; ?></td>
			<td>
				<?php echo esc_html( $row['message'] ); ?>
				<?php if ( $row['context'] ) : ?>
					<details><summary><?php esc_html_e( 'Context', 'wp-site-transfer-manager' ); ?></summary><pre><?php echo esc_html( $row['context'] ); ?></pre></details>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>

<?php if ( $pages > 1 ) : ?>
	<div class="tablenav"><div class="tablenav-pages">
		<?php
		echo wp_kses_post(
			paginate_links(
				array(
					'base'    => add_query_arg( 'paged', '%#%' ),
					'format'  => '',
					'current' => $paged,
					'total'   => $pages,
				)
			)
		);
		?>
	</div></div>
<?php endif; ?>
