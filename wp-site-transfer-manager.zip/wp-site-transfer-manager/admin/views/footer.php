<?php
/**
 * Shared page footer + confirmation modal shell.
 *
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
	</div>
	<div class="wstm-modal" id="wstm-confirm-modal" role="dialog" aria-modal="true" aria-labelledby="wstm-modal-title" hidden>
		<div class="wstm-modal__box">
			<h2 id="wstm-modal-title"></h2>
			<p class="wstm-modal__message"></p>
			<label class="wstm-modal__ack"><input type="checkbox" id="wstm-modal-ack"> <span></span></label>
			<div class="wstm-modal__actions">
				<button type="button" class="button" data-wstm-modal="cancel"></button>
				<button type="button" class="button button-primary" data-wstm-modal="continue" disabled></button>
			</div>
		</div>
	</div>
</div>
