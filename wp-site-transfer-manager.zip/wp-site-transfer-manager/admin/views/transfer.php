<?php
/**
 * Direct site-to-site transfer (Phase 8).
 *
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-mig" data-wstm-page="transfer">
	<section class="wstm-hero">
		<div class="wstm-hero__icon" aria-hidden="true"><span class="dashicons dashicons-randomize"></span></div>
		<div class="wstm-hero__body">
			<h2><?php esc_html_e( 'Move a site directly — no downloads', 'wp-site-transfer-manager' ); ?></h2>
			<p><?php esc_html_e( 'The two servers talk to each other with a one-time transfer key (signed with HMAC-SHA256, expires automatically, can be revoked). Both sites need this plugin.', 'wp-site-transfer-manager' ); ?></p>
		</div>
	</section>

	<div class="wstm-grid">
		<section class="wstm-card">
			<h2><span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Pull another site into this one', 'wp-site-transfer-manager' ); ?></h2>
			<ol class="wstm-steps">
				<li><?php esc_html_e( 'On the OTHER site: Transfer → “Allow this site to be pulled” → copy the key.', 'wp-site-transfer-manager' ); ?></li>
				<li><?php esc_html_e( 'Paste it here. This site will be replaced by the other one.', 'wp-site-transfer-manager' ); ?></li>
			</ol>
			<textarea id="wstm-tf-pull-key" class="large-text code" rows="3" placeholder="wstm1.…"></textarea>
			<p><button type="button" class="button button-primary" id="wstm-tf-pull"><?php esc_html_e( 'Pull site', 'wp-site-transfer-manager' ); ?></button></p>
		</section>

		<section class="wstm-card">
			<h2><span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'Push this site to another one', 'wp-site-transfer-manager' ); ?></h2>
			<ol class="wstm-steps">
				<li><?php esc_html_e( 'On the OTHER site: Transfer → “Allow another site to push into this one” → copy the key.', 'wp-site-transfer-manager' ); ?></li>
				<li><?php esc_html_e( 'Paste it here. The other site will be replaced by this one.', 'wp-site-transfer-manager' ); ?></li>
			</ol>
			<textarea id="wstm-tf-push-key" class="large-text code" rows="3" placeholder="wstm1.…"></textarea>
			<p><button type="button" class="button button-primary" id="wstm-tf-push"><?php esc_html_e( 'Push site', 'wp-site-transfer-manager' ); ?></button></p>
		</section>
	</div>

	<details class="wstm-adv wstm-card wstm-card--flat">
		<summary><?php esc_html_e( 'Transfer options', 'wp-site-transfer-manager' ); ?></summary>
		<label><input type="checkbox" id="wstm-tf-keep-users"> <?php esc_html_e( 'Keep the destination site\'s users and passwords', 'wp-site-transfer-manager' ); ?></label><br>
		<label><input type="checkbox" id="wstm-tf-skip-media"> <?php esc_html_e( 'Do not transfer the media library', 'wp-site-transfer-manager' ); ?></label><br>
		<label><input type="checkbox" id="wstm-tf-disk"> <?php esc_html_e( 'Proceed if free disk space cannot be determined', 'wp-site-transfer-manager' ); ?></label>
	</details>

	<section class="wstm-run" id="wstm-mig-run" hidden>
		<h2 class="wstm-run__title"></h2>
		<div class="wstm-progress wstm-progress--xl"><span style="width:0"></span></div>
		<p class="wstm-run__meta"><strong class="wstm-run__pct">0%</strong> <span class="wstm-run__step"></span></p>
		<div class="wstm-run__body"></div>
		<p class="wstm-actions wstm-run__actions"></p>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Transfer keys for this site', 'wp-site-transfer-manager' ); ?></h2>
		<p>
			<button type="button" class="button" data-tf-key="pull"><?php esc_html_e( 'Allow this site to be pulled', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" data-tf-key="push"><?php esc_html_e( 'Allow another site to push into this one', 'wp-site-transfer-manager' ); ?></button>
			<label><?php esc_html_e( 'Expires after', 'wp-site-transfer-manager' ); ?>
				<select id="wstm-tf-ttl"><option value="15">15 min</option><option value="30" selected>30 min</option><option value="60">1 hour</option></select></label>
		</p>
		<div id="wstm-tf-newkey" hidden>
			<p><strong><?php esc_html_e( 'Copy this key now — it is shown only once:', 'wp-site-transfer-manager' ); ?></strong></p>
			<textarea class="large-text code" rows="3" readonly></textarea>
			<p><button type="button" class="button" id="wstm-tf-copy"><?php esc_html_e( 'Copy', 'wp-site-transfer-manager' ); ?></button> <span class="wstm-muted"></span></p>
		</div>
		<div id="wstm-tf-keys"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>
</div>
