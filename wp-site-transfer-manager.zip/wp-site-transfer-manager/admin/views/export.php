<?php
/**
 * Export view: full-site packages and database-only dumps.
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-page" data-wstm-page="export">
	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Full-site package (.wpmig)', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'One sealed file with your database and selected files, built in resumable chunks. wp-config.php credentials are never included.', 'wp-site-transfer-manager' ); ?></p>
		<fieldset class="wstm-options wstm-options--grid" id="wstm-components">
			<label><input type="checkbox" value="database" checked> <?php esc_html_e( 'Database', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="uploads" checked> <?php esc_html_e( 'Uploads (media)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="themes" checked> <?php esc_html_e( 'Themes', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="plugins" checked> <?php esc_html_e( 'Plugins', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="content" checked> <?php esc_html_e( 'Other wp-content (mu-plugins, languages…)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="core"> <?php esc_html_e( 'WordPress core', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" value="root"> <?php esc_html_e( 'Other root files (.htaccess, robots.txt, custom folders)', 'wp-site-transfer-manager' ); ?></label>
		</fieldset>
		<p><label for="wstm-exclusions"><strong><?php esc_html_e( 'Exclusions', 'wp-site-transfer-manager' ); ?></strong></label><br>
			<textarea id="wstm-exclusions" class="large-text code" rows="4"><?php echo esc_textarea( implode( "\n", (array) $plugin->settings()->get( 'default_exclusions' ) ) ); ?></textarea>
			<span class="description"><?php esc_html_e( 'One per line, relative to the WordPress folder. "dir/" = folder, "*.log" = pattern, "node_modules/" = at any depth.', 'wp-site-transfer-manager' ); ?></span></p>
		<p><button type="button" class="button button-primary" id="wstm-start-package"><?php esc_html_e( 'Create package', 'wp-site-transfer-manager' ); ?></button></p>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Packages', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-packages" data-mode="export"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Export database only', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Creates a chunked, resumable SQL dump with a SHA-256 checksum manifest.', 'wp-site-transfer-manager' ); ?></p>

		<div class="wstm-table-picker" id="wstm-table-picker" aria-live="polite">
			<p class="wstm-muted"><?php esc_html_e( 'Loading tables…', 'wp-site-transfer-manager' ); ?></p>
		</div>

		<fieldset class="wstm-options">
			<label><input type="checkbox" id="wstm-opt-gzip" checked> <?php esc_html_e( 'Compress with gzip', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-drop" checked> <?php esc_html_e( 'Include DROP TABLE statements', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-unknown-disk"> <?php esc_html_e( 'Proceed if free disk space cannot be determined', 'wp-site-transfer-manager' ); ?></label>
		</fieldset>
		<p><button type="button" class="button button-primary" id="wstm-start-export"><?php esc_html_e( 'Start export', 'wp-site-transfer-manager' ); ?></button></p>
	</section>

	<section class="wstm-card wstm-card--flat" id="wstm-monitor" hidden></section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Database dumps', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-dumps" data-mode="export"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>
</div>
