<?php
/**
 * One-click export (All-in-One style).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;

$skip = array(
	'media'            => __( 'Media library (uploads)', 'wp-site-transfer-manager' ),
	'themes'           => __( 'Themes', 'wp-site-transfer-manager' ),
	'inactive_themes'  => __( 'Inactive themes', 'wp-site-transfer-manager' ),
	'plugins'          => __( 'Plugins', 'wp-site-transfer-manager' ),
	'inactive_plugins' => __( 'Inactive plugins', 'wp-site-transfer-manager' ),
	'database'         => __( 'Database', 'wp-site-transfer-manager' ),
	'revisions'        => __( 'Post revisions', 'wp-site-transfer-manager' ),
	'spam_comments'    => __( 'Spam & trashed comments', 'wp-site-transfer-manager' ),
	'cache'            => __( 'Cache files', 'wp-site-transfer-manager' ),
);
?>
<div class="wstm-mig" data-wstm-page="simple-export">
	<section class="wstm-hero">
		<div class="wstm-hero__icon" aria-hidden="true"><span class="dashicons dashicons-download"></span></div>
		<div class="wstm-hero__body">
			<h2><?php esc_html_e( 'Export this site', 'wp-site-transfer-manager' ); ?></h2>
			<p><?php esc_html_e( 'Creates one .wpmig file with your database, media, themes and plugins. Import it on any WordPress site with this plugin to move or clone the site — URLs, paths and table prefixes are fixed automatically.', 'wp-site-transfer-manager' ); ?></p>
			<p><button type="button" class="button button-primary button-hero" id="wstm-mig-export"><span class="dashicons dashicons-migrate"></span> <?php esc_html_e( 'Export to file', 'wp-site-transfer-manager' ); ?></button></p>
			<details class="wstm-adv">
				<summary><?php esc_html_e( 'Advanced options', 'wp-site-transfer-manager' ); ?></summary>
				<p class="wstm-muted"><?php esc_html_e( 'Do not export:', 'wp-site-transfer-manager' ); ?></p>
				<div class="wstm-options wstm-options--grid" id="wstm-mig-skip">
					<?php foreach ( $skip as $k => $label ) : ?>
						<label><input type="checkbox" value="<?php echo esc_attr( $k ); ?>" <?php checked( in_array( $k, array( 'revisions', 'spam_comments', 'cache' ), true ) ); ?>> <?php echo esc_html( $label ); ?></label>
					<?php endforeach; ?>
				</div>
				<p><label for="wstm-mig-excl"><?php esc_html_e( 'Also exclude (one path or pattern per line, relative to the WordPress folder):', 'wp-site-transfer-manager' ); ?></label><br>
				<textarea id="wstm-mig-excl" class="large-text code" rows="3" placeholder="wp-content/uploads/backups/&#10;*.log"></textarea></p>
			</details>
		</div>
	</section>

	<section class="wstm-run" id="wstm-mig-run" hidden>
		<h2 class="wstm-run__title"></h2>
		<div class="wstm-progress wstm-progress--xl"><span style="width:0"></span></div>
		<p class="wstm-run__meta"><strong class="wstm-run__pct">0%</strong> <span class="wstm-run__step"></span></p>
		<div class="wstm-run__body"></div>
		<p class="wstm-actions wstm-run__actions"></p>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Recent exports', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-mig-recent"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>
</div>
