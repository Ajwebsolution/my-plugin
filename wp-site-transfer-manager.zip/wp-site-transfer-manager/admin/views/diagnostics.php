<?php
/**
 * Diagnostics view.
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

use WSTM\Admin\Admin;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

$report = $plugin->diagnostics()->run();
$groups = array();
foreach ( $report['checks'] as $c ) {
	$groups[ $c['group'] ][] = $c;
}
$labels = array(
	'php'        => __( 'PHP', 'wp-site-transfer-manager' ),
	'wordpress'  => __( 'WordPress', 'wp-site-transfer-manager' ),
	'database'   => __( 'Database', 'wp-site-transfer-manager' ),
	'filesystem' => __( 'Filesystem & Disk', 'wp-site-transfer-manager' ),
	'archive'    => __( 'Archive support', 'wp-site-transfer-manager' ),
	'network'    => __( 'Network & API', 'wp-site-transfer-manager' ),
	'ecosystem'  => __( 'Detected plugins', 'wp-site-transfer-manager' ),
);
?>
<div class="wstm-toolbar">
	<div class="wstm-score wstm-score--inline">
		<?php
		/* translators: %d: score */
		echo esc_html( sprintf( __( 'Compatibility: %d%%', 'wp-site-transfer-manager' ), $report['score'] ) );
		?>
		<?php if ( $report['blocking'] ) : ?>
			<?php echo wp_kses_post( Admin::badge( 'error', __( 'Blocking issues found — migrations will be refused until fixed.', 'wp-site-transfer-manager' ) ) ); ?>
		<?php endif; ?>
	</div>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-wstm-refresh-diagnostics>
		<input type="hidden" name="action" value="wstm_refresh_diagnostics">
		<?php Security::nonce_field( 'diagnostics' ); ?>
		<button class="button"><?php esc_html_e( 'Re-run checks', 'wp-site-transfer-manager' ); ?></button>
	</form>
</div>

<?php foreach ( $groups as $group => $checks ) : ?>
	<section class="wstm-card wstm-card--flat">
		<h2><?php echo esc_html( $labels[ $group ] ?? ucfirst( $group ) ); ?></h2>
		<table class="widefat striped wstm-diag-table">
			<tbody>
			<?php foreach ( $checks as $c ) : ?>
				<tr>
					<td class="wstm-diag-status"><?php echo wp_kses_post( Admin::badge( $c['status'] ) ); ?></td>
					<th scope="row"><?php echo esc_html( $c['label'] ); ?></th>
					<td><?php echo esc_html( $c['value'] ); ?></td>
					<td class="wstm-muted"><?php echo 'pass' === $c['status'] || 'info' === $c['status'] ? '' : esc_html( $c['recommendation'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</section>
<?php endforeach; ?>
<p class="wstm-muted">
	<?php
	/* translators: %s: date */
	echo esc_html( sprintf( __( 'Generated %s (cached for 10 minutes).', 'wp-site-transfer-manager' ), $report['generated_at'] ) );
	?>
</p>
