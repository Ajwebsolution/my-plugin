<?php
/**
 * Placeholder for sections delivered in later phases.
 *
 * @var string $title Page title.
 * @var int    $phase Phase number.
 * @package WSTM
 */

use WSTM\Admin\Admin;

defined( 'ABSPATH' ) || exit;
?>
<section class="wstm-card wstm-card--flat wstm-empty">
	<span class="dashicons dashicons-clock" aria-hidden="true"></span>
	<h2><?php echo esc_html( $title ); ?></h2>
	<p>
		<?php
		/* translators: %d: phase number */
		echo esc_html( sprintf( __( 'This section is delivered in development Phase %d. No operations are available here yet, so nothing on your site can be modified from this screen.', 'wp-site-transfer-manager' ), $phase ) );
		?>
	</p>
	<p><a class="button" href="<?php echo esc_url( Admin::url( 'diagnostics' ) ); ?>"><?php esc_html_e( 'View diagnostics', 'wp-site-transfer-manager' ); ?></a></p>
</section>
