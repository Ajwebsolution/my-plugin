<?php
/**
 * Import view (Phase 2: database import from plugin storage; uploads arrive in Phase 4).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-page" data-wstm-page="import">
	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Upload a package or dump', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Uploads in resumable, checksummed chunks — if the connection drops, choose the same file again to continue where it stopped. Accepted: .wpmig, .sql, .sql.gz', 'wp-site-transfer-manager' ); ?></p>
		<p><input type="file" id="wstm-upload-file" accept=".wpmig,.sql,.gz"> <button type="button" class="button" id="wstm-upload-start"><?php esc_html_e( 'Upload', 'wp-site-transfer-manager' ); ?></button> <button type="button" class="button" id="wstm-upload-cancel" hidden><?php esc_html_e( 'Stop', 'wp-site-transfer-manager' ); ?></button></p>
		<div id="wstm-upload-progress" hidden><div class="wstm-progress wstm-progress--lg"><span style="width:0"></span></div><p class="wstm-muted"></p></div>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Packages', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Importing a package verifies its seal, imports the database safely (if selected) and extracts files into a protected staging area. Applying staged files to the live site is part of full migration (Phase 6).', 'wp-site-transfer-manager' ); ?></p>
		<label><input type="checkbox" id="wstm-opt-pkg-db" checked> <?php esc_html_e( 'Import the database from the package', 'wp-site-transfer-manager' ); ?></label><br>
		<label><input type="checkbox" id="wstm-opt-exec"> <?php esc_html_e( 'Also extract executable files found in uploads (not recommended)', 'wp-site-transfer-manager' ); ?></label>
		<div id="wstm-packages" data-mode="import"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Import a database dump', 'wp-site-transfer-manager' ); ?></h2>
		<p><?php esc_html_e( 'How the import protects your site:', 'wp-site-transfer-manager' ); ?></p>
		<ol class="wstm-steps">
			<li><?php esc_html_e( 'The dump is checked (checksum, completeness, table prefix) before anything changes.', 'wp-site-transfer-manager' ); ?></li>
			<li><?php esc_html_e( 'A safety backup of the current database is created.', 'wp-site-transfer-manager' ); ?></li>
			<li><?php esc_html_e( 'Data is imported into temporary tables; your live tables are untouched while this runs.', 'wp-site-transfer-manager' ); ?></li>
			<li><?php esc_html_e( 'Row counts are verified, then all tables are switched in one atomic step.', 'wp-site-transfer-manager' ); ?></li>
			<li><?php esc_html_e( 'Replaced tables are kept as rollback copies until you delete them.', 'wp-site-transfer-manager' ); ?></li>
		</ol>
		<p class="wstm-muted">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %s: folder */
					__( 'Upload a dump above, or copy .sql/.sql.gz files (with their .manifest.json) into: %s', 'wp-site-transfer-manager' ),
					$plugin->storage()->area( 'packages' )
				)
			);
			?>
		</p>
		<fieldset class="wstm-options">
			<label><input type="checkbox" id="wstm-opt-safety" checked> <?php esc_html_e( 'Create a safety backup first (strongly recommended)', 'wp-site-transfer-manager' ); ?></label>
			<label><input type="checkbox" id="wstm-opt-unknown-disk"> <?php esc_html_e( 'Proceed if free disk space cannot be determined', 'wp-site-transfer-manager' ); ?></label>
		</fieldset>
		<p class="wstm-muted"><?php esc_html_e( 'After import, users and passwords are those of the imported database — you may need to log in again.', 'wp-site-transfer-manager' ); ?></p>
	</section>

	<section class="wstm-card wstm-card--flat" id="wstm-monitor" hidden></section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Available dumps', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-dumps" data-mode="import"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Rollback copies', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Tables replaced by the last import. They use database space; full rollback arrives in Phase 7.', 'wp-site-transfer-manager' ); ?></p>
		<div id="wstm-previous"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>
</div>
