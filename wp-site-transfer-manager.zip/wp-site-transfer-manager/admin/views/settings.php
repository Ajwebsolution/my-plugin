<?php
/**
 * Settings view (rendered from the settings schema).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

use WSTM\Admin\Admin;
use WSTM\Security\Security;

defined( 'ABSPATH' ) || exit;

$values = $plugin->settings()->all();
$errors = get_site_transient( 'wstm_settings_errors_' . get_current_user_id() );
if ( $errors ) {
	delete_site_transient( 'wstm_settings_errors_' . get_current_user_id() );
}
$titles = array(
	'performance' => __( 'Performance', 'wp-site-transfer-manager' ),
	'migration'   => __( 'Migration', 'wp-site-transfer-manager' ),
	'backups'     => __( 'Backups & Storage', 'wp-site-transfer-manager' ),
	'transfer'    => __( 'Direct Transfer', 'wp-site-transfer-manager' ),
	'logging'     => __( 'Logging & Cleanup', 'wp-site-transfer-manager' ),
	'advanced'    => __( 'Advanced', 'wp-site-transfer-manager' ),
);
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
$updated = isset( $_GET['updated'] ) ? absint( $_GET['updated'] ) : null;
?>
<?php if ( 1 === $updated ) : ?>
	<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'wp-site-transfer-manager' ); ?></p></div>
<?php elseif ( is_array( $errors ) && $errors ) : ?>
	<div class="notice notice-error"><p><?php esc_html_e( 'Settings were not saved:', 'wp-site-transfer-manager' ); ?></p><ul>
		<?php foreach ( $errors as $e ) : ?>
			<li><?php echo esc_html( $e ); ?></li>
		<?php endforeach; ?>
	</ul></div>
<?php endif; ?>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wstm-settings">
	<input type="hidden" name="action" value="wstm_save_settings">
	<?php Security::nonce_field( 'save_settings' ); ?>

	<?php foreach ( Admin::settings_sections() as $section => $fields ) : ?>
		<section class="wstm-card wstm-card--flat">
			<h2><?php echo esc_html( $titles[ $section ] ?? ucfirst( $section ) ); ?></h2>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $f ) : ?>
					<?php $id = 'wstm-' . $key; $v = $values[ $key ] ?? $f['default']; ?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $f['label'] ); ?></label></th>
						<td>
							<?php if ( 'bool' === $f['type'] ) : ?>
								<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="wstm[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( (bool) $v ); ?>>
							<?php elseif ( 'enum' === $f['type'] ) : ?>
								<select id="<?php echo esc_attr( $id ); ?>" name="wstm[<?php echo esc_attr( $key ); ?>]">
									<?php foreach ( $f['choices'] as $choice ) : ?>
										<option value="<?php echo esc_attr( $choice ); ?>" <?php selected( (string) $v, $choice ); ?>><?php echo esc_html( 'auto' === $choice ? __( 'Auto', 'wp-site-transfer-manager' ) : ucfirst( $choice ) ); ?></option>
									<?php endforeach; ?>
								</select>
							<?php elseif ( 'int' === $f['type'] ) : ?>
								<input type="number" class="small-text" id="<?php echo esc_attr( $id ); ?>" name="wstm[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $v ); ?>" min="<?php echo esc_attr( $f['min'] ); ?>" max="<?php echo esc_attr( $f['max'] ); ?>">
							<?php elseif ( 'textarea_list' === $f['type'] ) : ?>
								<textarea class="large-text code" rows="5" id="<?php echo esc_attr( $id ); ?>" name="wstm[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( implode( "\n", (array) $v ) ); ?></textarea>
							<?php else : ?>
								<input type="text" class="regular-text code" id="<?php echo esc_attr( $id ); ?>" name="wstm[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $v ); ?>">
							<?php endif; ?>
							<?php if ( ! empty( $f['description'] ) ) : ?>
								<p class="description"><?php echo esc_html( $f['description'] ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		</section>
	<?php endforeach; ?>
	<?php submit_button( __( 'Save settings', 'wp-site-transfer-manager' ) ); ?>
</form>
