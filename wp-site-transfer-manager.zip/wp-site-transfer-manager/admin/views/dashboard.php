<?php
/**
 * Dashboard view.
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

use WSTM\Admin\Admin;
use WSTM\Diagnostics\Diagnostics;
use WSTM\Files\TempStorage;
use WSTM\Jobs\JobStatus;

defined( 'ABSPATH' ) || exit;

$report = $plugin->diagnostics()->run();
$index  = array();
foreach ( $report['checks'] as $c ) {
	$index[ $c['id'] ] = $c;
}
$val = static fn( string $id ): string => $index[ $id ]['value'] ?? '—';

$active_jobs = $plugin->jobs()->list( array( 'status' => array( JobStatus::RUNNING, JobStatus::PENDING, JobStatus::PAUSED, JobStatus::FAILED ), 'per_page' => 10 ) );
$recent_jobs = $plugin->jobs()->list( array( 'status' => array( JobStatus::COMPLETED, JobStatus::CANCELLED ), 'per_page' => 5 ) );
$problems    = array_filter( $report['checks'], static fn( $c ) => in_array( $c['status'], array( Diagnostics::FAIL, Diagnostics::WARN ), true ) );
$free        = $plugin->storage()->free_space();
$storage     = TempStorage::dir_size( $plugin->storage()->root(), 2 );
$score       = (int) $report['score'];
$score_cls   = $score >= 85 ? 'success' : ( $score >= 60 ? 'warning' : 'error' );
?>
<div class="wstm-grid">

	<section class="wstm-card">
		<h2><?php esc_html_e( 'System Health', 'wp-site-transfer-manager' ); ?></h2>
		<div class="wstm-score wstm-score--<?php echo esc_attr( $score_cls ); ?>">
			<span class="wstm-score__num"><?php echo esc_html( $score ); ?>%</span>
			<span class="wstm-score__label"><?php esc_html_e( 'Compatibility', 'wp-site-transfer-manager' ); ?></span>
		</div>
		<table class="wstm-kv">
			<tr><th><?php esc_html_e( 'WordPress', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'wp_version' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'PHP', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'php_version' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Database', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'db_version' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Site URL', 'wp-site-transfer-manager' ); ?></th><td><code><?php echo esc_html( site_url() ); ?></code></td></tr>
			<tr><th><?php esc_html_e( 'Home URL', 'wp-site-transfer-manager' ); ?></th><td><code><?php echo esc_html( home_url() ); ?></code></td></tr>
			<tr><th><?php esc_html_e( 'Memory limit', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'memory_limit' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Upload limit', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'upload_limit' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Execution time', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'max_execution_time' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Archive support', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( sprintf( 'ZipArchive: %s · Gzip: %s', $val( 'ziparchive' ), $val( 'gzip' ) ) ); ?></td></tr>
		</table>
		<p class="wstm-muted">
			<?php
			/* translators: %s: time */
			echo esc_html( sprintf( __( 'Checked %s ago.', 'wp-site-transfer-manager' ), human_time_diff( strtotime( $report['generated_at'] ) ) ) );
			?>
			<a href="<?php echo esc_url( Admin::url( 'diagnostics' ) ); ?>"><?php esc_html_e( 'Full diagnostics →', 'wp-site-transfer-manager' ); ?></a>
		</p>
	</section>

	<section class="wstm-card">
		<h2><?php esc_html_e( 'Storage', 'wp-site-transfer-manager' ); ?></h2>
		<table class="wstm-kv">
			<tr><th><?php esc_html_e( 'Available disk space', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( null === $free ? __( 'Unknown', 'wp-site-transfer-manager' ) : size_format( $free ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Database size', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( $val( 'db_size' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Plugin storage used', 'wp-site-transfer-manager' ); ?></th><td><?php echo esc_html( size_format( $storage['bytes'] ) . ( $storage['complete'] ? '' : '+' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Storage location', 'wp-site-transfer-manager' ); ?></th><td><?php echo wp_kses_post( Admin::badge( $index['storage_location']['status'] ?? 'info', $val( 'storage_location' ) ) ); ?></td></tr>
		</table>
	</section>

	<section class="wstm-card wstm-card--wide">
		<h2><?php esc_html_e( 'Current Jobs', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-active-jobs" data-wstm-poll="jobs">
			<?php if ( ! $active_jobs ) : ?>
				<p class="wstm-muted"><?php esc_html_e( 'No active jobs.', 'wp-site-transfer-manager' ); ?></p>
			<?php else : ?>
				<?php foreach ( $active_jobs as $job ) : ?>
					<div class="wstm-job">
						<div class="wstm-job__head">
							<?php echo wp_kses_post( Admin::badge( $job->status ) ); ?>
							<strong>#<?php echo esc_html( $job->id ); ?> <?php echo esc_html( $job->type ); ?></strong>
							<span class="wstm-muted"><?php echo esc_html( $job->current_step ); ?></span>
						</div>
						<div class="wstm-progress" role="progressbar" aria-valuenow="<?php echo esc_attr( $job->progress ); ?>" aria-valuemin="0" aria-valuemax="100"><span style="width:<?php echo esc_attr( $job->progress ); ?>%"></span></div>
						<?php if ( $job->error ) : ?>
							<p class="wstm-error-line"><?php echo esc_html( ( $job->error['what'] ?? '' ) . ' — ' . ( $job->error['why'] ?? '' ) ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</section>

	<section class="wstm-card">
		<h2><?php esc_html_e( 'Migration', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Use Export to pack this site into one file, and Import to restore or move a site in one click.', 'wp-site-transfer-manager' ); ?></p>
		<?php if ( $recent_jobs ) : ?>
			<ul class="wstm-list">
				<?php foreach ( $recent_jobs as $job ) : ?>
					<li><?php echo wp_kses_post( Admin::badge( $job->status ) ); ?> #<?php echo esc_html( $job->id . ' ' . $job->type ); ?> <span class="wstm-muted"><?php echo esc_html( $job->finished_at ?? $job->updated_at ); ?> UTC</span></li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p><?php esc_html_e( 'No migrations yet.', 'wp-site-transfer-manager' ); ?></p>
		<?php endif; ?>
	</section>

	<section class="wstm-card">
		<h2><?php esc_html_e( 'Backup', 'wp-site-transfer-manager' ); ?></h2>
		<p><?php esc_html_e( 'No backups yet.', 'wp-site-transfer-manager' ); ?></p>
		<p class="wstm-muted"><?php esc_html_e( 'Backup & restore arrive in Phase 7.', 'wp-site-transfer-manager' ); ?></p>
	</section>

	<section class="wstm-card">
		<h2><?php esc_html_e( 'Transfer', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Secure transfer-key migration arrives in Phase 8.', 'wp-site-transfer-manager' ); ?></p>
	</section>

	<section class="wstm-card wstm-card--wide">
		<h2><?php esc_html_e( 'Warnings & Errors', 'wp-site-transfer-manager' ); ?></h2>
		<?php if ( ! $problems ) : ?>
			<p><?php echo wp_kses_post( Admin::badge( 'pass', __( 'No issues detected.', 'wp-site-transfer-manager' ) ) ); ?></p>
		<?php else : ?>
			<ul class="wstm-list">
				<?php foreach ( $problems as $p ) : ?>
					<li><?php echo wp_kses_post( Admin::badge( $p['status'] ) ); ?> <strong><?php echo esc_html( $p['label'] ); ?>:</strong> <?php echo esc_html( $p['value'] ); ?> <span class="wstm-muted"><?php echo esc_html( $p['recommendation'] ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>

	<section class="wstm-card wstm-card--wide" data-wstm-page="tools">
		<h2><?php esc_html_e( 'Site tools', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-actions">
			<button type="button" class="button button-primary" data-tool="health"><?php esc_html_e( 'Run health check', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" data-tool="link-audit"><?php esc_html_e( 'Scan for broken links', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" data-tool="clear-cache"><?php esc_html_e( 'Clear all caches', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" data-tool="elementor"><?php esc_html_e( 'Regenerate Elementor CSS', 'wp-site-transfer-manager' ); ?></button>
			<button type="button" class="button" data-tool="permalinks"><?php esc_html_e( 'Refresh permalinks', 'wp-site-transfer-manager' ); ?></button>
		</p>
		<div id="wstm-tool-out" aria-live="polite"></div>
	</section>

	<section class="wstm-card wstm-card--wide">
		<h2><?php esc_html_e( 'Migration history', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-history"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>

	<section class="wstm-card wstm-card--wide">
		<h2><?php esc_html_e( 'Recent Activity', 'wp-site-transfer-manager' ); ?></h2>
		<?php $recent_logs = $plugin->logger()->query( array( 'per_page' => 8 ) )['rows']; ?>
		<?php if ( ! $recent_logs ) : ?>
			<p class="wstm-muted"><?php esc_html_e( 'No activity yet.', 'wp-site-transfer-manager' ); ?></p>
		<?php else : ?>
			<table class="widefat striped wstm-log-table">
				<tbody>
				<?php foreach ( $recent_logs as $l ) : ?>
					<tr><td class="wstm-nowrap"><?php echo esc_html( $l['created_at'] ); ?></td><td><span class="wstm-level wstm-level--<?php echo esc_attr( $l['level'] ); ?>"><?php echo esc_html( strtoupper( $l['level'] ) ); ?></span></td><td><?php echo esc_html( $l['message'] ); ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</section>
</div>
