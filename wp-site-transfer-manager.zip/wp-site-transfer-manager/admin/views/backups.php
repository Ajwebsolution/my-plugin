<?php
/**
 * Backups & restore (Phase 7).
 *
 * @var \WSTM\Core\Plugin $plugin Plugin.
 * @package WSTM
 */

use WSTM\Admin\Admin;

defined( 'ABSPATH' ) || exit;
?>
<div class="wstm-mig" data-wstm-page="backups">
	<section class="wstm-hero">
		<div class="wstm-hero__icon" aria-hidden="true"><span class="dashicons dashicons-backup"></span></div>
		<div class="wstm-hero__body">
			<h2><?php esc_html_e( 'Backups', 'wp-site-transfer-manager' ); ?></h2>
			<p><?php esc_html_e( 'Every backup is verified after it is created. Incremental and differential backups only store changed files and restore together with their base automatically.', 'wp-site-transfer-manager' ); ?></p>
			<p class="wstm-backup-form">
				<label><?php esc_html_e( 'Contents', 'wp-site-transfer-manager' ); ?>
					<select id="wstm-bk-type">
						<option value="full"><?php esc_html_e( 'Full site (database + files)', 'wp-site-transfer-manager' ); ?></option>
						<option value="database"><?php esc_html_e( 'Database only', 'wp-site-transfer-manager' ); ?></option>
						<option value="files"><?php esc_html_e( 'Files only', 'wp-site-transfer-manager' ); ?></option>
					</select></label>
				<label><?php esc_html_e( 'Mode', 'wp-site-transfer-manager' ); ?>
					<select id="wstm-bk-mode">
						<option value="full"><?php esc_html_e( 'Complete', 'wp-site-transfer-manager' ); ?></option>
						<option value="incremental"><?php esc_html_e( 'Incremental (changes since last backup)', 'wp-site-transfer-manager' ); ?></option>
						<option value="differential"><?php esc_html_e( 'Differential (changes since last complete backup)', 'wp-site-transfer-manager' ); ?></option>
					</select></label>
				<label class="wstm-bk-cloud" hidden><?php esc_html_e( 'Also upload to', 'wp-site-transfer-manager' ); ?>
					<select id="wstm-bk-cloud"><option value=""><?php esc_html_e( '— this server only —', 'wp-site-transfer-manager' ); ?></option></select></label>
				<button type="button" class="button button-primary button-hero" id="wstm-bk-create"><span class="dashicons dashicons-backup"></span> <?php esc_html_e( 'Back up now', 'wp-site-transfer-manager' ); ?></button>
			</p>
			<p class="wstm-muted" id="wstm-bk-schedule"></p>
			<p class="wstm-muted"><a href="<?php echo esc_url( Admin::url( 'settings' ) ); ?>"><?php esc_html_e( 'Schedule & retention settings →', 'wp-site-transfer-manager' ); ?></a></p>
		</div>
	</section>

	<section class="wstm-run" id="wstm-mig-run" hidden>
		<h2 class="wstm-run__title"></h2>
		<div class="wstm-progress wstm-progress--xl"><span style="width:0"></span></div>
		<p class="wstm-run__meta"><strong class="wstm-run__pct">0%</strong> <span class="wstm-run__step"></span></p>
		<div class="wstm-run__body"></div>
		<p class="wstm-actions wstm-run__actions"></p>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Restore points', 'wp-site-transfer-manager' ); ?></h2>
		<div id="wstm-bk-list"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>

	<section class="wstm-card wstm-card--flat">
		<h2><?php esc_html_e( 'Undo an import', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Each import or restore keeps the files it replaced and the previous database, so it can be reverted.', 'wp-site-transfer-manager' ); ?></p>
		<div id="wstm-bk-undo"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
	</section>
	<section class="wstm-card wstm-card--flat" id="wstm-cloud">
		<h2><?php esc_html_e( 'Cloud storage', 'wp-site-transfer-manager' ); ?></h2>
		<p class="wstm-muted"><?php esc_html_e( 'Send backups to Amazon S3, Cloudflare R2, Backblaze B2, Wasabi, DigitalOcean Spaces or any S3-compatible storage (MinIO). Secret keys are encrypted on this server and never shown again.', 'wp-site-transfer-manager' ); ?></p>
		<div id="wstm-cloud-list"><p class="wstm-muted"><?php esc_html_e( 'Loading…', 'wp-site-transfer-manager' ); ?></p></div>
		<p><button type="button" class="button" id="wstm-cloud-add"><?php esc_html_e( 'Add S3-compatible destination', 'wp-site-transfer-manager' ); ?></button></p>
		<form id="wstm-cloud-form" class="wstm-cloud-form" hidden autocomplete="off">
			<input type="hidden" name="id">
			<table class="form-table" role="presentation">
				<tr><th><label for="wstm-cl-preset"><?php esc_html_e( 'Provider', 'wp-site-transfer-manager' ); ?></label></th><td><select id="wstm-cl-preset"></select></td></tr>
				<tr><th><label for="wstm-cl-label"><?php esc_html_e( 'Name', 'wp-site-transfer-manager' ); ?></label></th><td><input type="text" class="regular-text" id="wstm-cl-label" name="label"></td></tr>
				<tr><th><label for="wstm-cl-endpoint"><?php esc_html_e( 'Endpoint URL', 'wp-site-transfer-manager' ); ?></label></th><td><input type="url" class="regular-text code" id="wstm-cl-endpoint" name="endpoint" required></td></tr>
				<tr><th><label for="wstm-cl-region"><?php esc_html_e( 'Region', 'wp-site-transfer-manager' ); ?></label></th><td><input type="text" class="regular-text code" id="wstm-cl-region" name="region" placeholder="us-east-1"></td></tr>
				<tr><th><label for="wstm-cl-bucket"><?php esc_html_e( 'Bucket', 'wp-site-transfer-manager' ); ?></label></th><td><input type="text" class="regular-text code" id="wstm-cl-bucket" name="bucket" required></td></tr>
				<tr><th><label for="wstm-cl-prefix"><?php esc_html_e( 'Folder (optional)', 'wp-site-transfer-manager' ); ?></label></th><td><input type="text" class="regular-text code" id="wstm-cl-prefix" name="prefix" placeholder="backups/my-site"></td></tr>
				<tr><th><?php esc_html_e( 'Addressing', 'wp-site-transfer-manager' ); ?></th><td><label><input type="checkbox" id="wstm-cl-path" name="path_style" value="1"> <?php esc_html_e( 'Path-style URLs (MinIO, B2, R2)', 'wp-site-transfer-manager' ); ?></label></td></tr>
				<tr><th><label for="wstm-cl-access"><?php esc_html_e( 'Access key ID', 'wp-site-transfer-manager' ); ?></label></th><td><input type="text" class="regular-text code" id="wstm-cl-access" name="access_key" autocomplete="off"></td></tr>
				<tr><th><label for="wstm-cl-secret"><?php esc_html_e( 'Secret access key', 'wp-site-transfer-manager' ); ?></label></th><td><input type="password" class="regular-text code" id="wstm-cl-secret" name="secret_key" autocomplete="new-password"><p class="description" id="wstm-cl-secret-note" hidden><?php esc_html_e( 'Leave empty to keep the saved secret.', 'wp-site-transfer-manager' ); ?></p></td></tr>
			</table>
			<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save destination', 'wp-site-transfer-manager' ); ?></button> <button type="button" class="button" id="wstm-cloud-cancel"><?php esc_html_e( 'Cancel', 'wp-site-transfer-manager' ); ?></button></p>
		</form>
		<div id="wstm-cloud-files" hidden></div>
	</section>
</div>
