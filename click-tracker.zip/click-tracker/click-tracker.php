<?php
/**
 * Plugin Name: Click Tracker Dashboard
 * Description: Tracks phone (tel:) and WhatsApp clicks automatically + admin dashboard with stats and charts.
 * Version: 2.0
 * Author: Amit
 * Author URI: mailto:ac926008@gmail.com
 */

// -----------------------------------------------------
// 1. FRONTEND CLICK TRACKING (NO API, NO ROUTES)
// -----------------------------------------------------
add_action('wp_footer', function () {
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function () {

        // Track ALL tel: links automatically
        document.querySelectorAll('a[href^="tel:"]').forEach(function (el) {
            el.addEventListener("click", function () {
                sendClick("phone");
            });
        });

        // Track WhatsApp:
        // - URLs containing whatsapp.com
        // - JoinChat plugin button
        document.querySelectorAll('a[href*="whatsapp"], .joinchat__open').forEach(function (el) {
            el.addEventListener("click", function () {
                sendClick("whatsapp");
            });
        });

        // Save clicks using AJAX
        function sendClick(type) {
            fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                method: "POST",
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: "action=track_click&type=" + type
            });
        }

    });
    </script>
    <?php
});

// -----------------------------------------------------
// 2. AJAX HANDLER FOR SAVING CLICKS
// -----------------------------------------------------
add_action('wp_ajax_track_click', 'click_tracker_save_click');
add_action('wp_ajax_nopriv_track_click', 'click_tracker_save_click');

function click_tracker_save_click() {
    if (!isset($_POST['type'])) exit;

    $type = sanitize_text_field($_POST['type']);
    $today = date('Y-m-d');

    // Daily count
    $daily_key = "{$type}_clicks_$today";
    update_option($daily_key, get_option($daily_key, 0) + 1);

    // Total count
    $total_key = "{$type}_clicks_total";
    update_option($total_key, get_option($total_key, 0) + 1);

    wp_send_json(['status' => 'ok']);
}

// -----------------------------------------------------
// 3. ADMIN MENU PAGE
// -----------------------------------------------------
add_action('admin_menu', function () {
    add_menu_page(
        'Click Tracker',
        'Click Tracker',
        'manage_options',
        'click-tracker',
        'click_tracker_admin_page',
        'dashicons-chart-area',
        80
    );
});

// -----------------------------------------------------
// 4. ADMIN DASHBOARD PAGE
// -----------------------------------------------------
function click_tracker_admin_page() {

    $total_phone = get_option("phone_clicks_total", 0);
    $total_whatsapp = get_option("whatsapp_clicks_total", 0);

    // Last 30 days
    $dates = [];
    $phone = [];
    $wa = [];

    for ($i = 29; $i >= 0; $i--) {
        $day = date('Y-m-d', strtotime("-$i days"));
        $dates[] = $day;
        $phone[] = get_option("phone_clicks_$day", 0);
        $wa[] = get_option("whatsapp_clicks_$day", 0);
    }

    ?>
    <div class="wrap">
        <h1>📊 Click Tracker Dashboard</h1>

        <h2>Total Stats</h2>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Total Clicks</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>📞 Phone Clicks</td>
                    <td><?php echo $total_phone; ?></td>
                </tr>
                <tr>
                    <td>💬 WhatsApp Clicks</td>
                    <td><?php echo $total_whatsapp; ?></td>
                </tr>
            </tbody>
        </table>

        <br><br>

        <h2>Last 30 Days Activity</h2>
        <canvas id="clickChart" height="100"></canvas>

        <br><br>

        <form method="post">
            <input type="submit" name="export_csv" class="button button-primary" value="Export CSV">
            <input type="submit" name="reset_data" class="button button-secondary" value="Reset All Data" onclick="return confirm('Are you sure?');">
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    new Chart(document.getElementById('clickChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($dates); ?>,
            datasets: [
                {
                    label: 'Phone Clicks',
                    data: <?php echo json_encode($phone); ?>,
                    borderWidth: 3,
                    borderColor: '#0073aa'
                },
                {
                    label: 'WhatsApp Clicks',
                    data: <?php echo json_encode($wa); ?>,
                    borderWidth: 3,
                    borderColor: '#25D366'
                }
            ]
        }
    });
    </script>
    <?php
}

// -----------------------------------------------------
// 5. RESET + CSV EXPORT
// -----------------------------------------------------
add_action('admin_init', function () {

    if (isset($_POST['reset_data'])) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'phone_clicks_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'whatsapp_clicks_%'");
        wp_redirect(admin_url('admin.php?page=click-tracker')); exit;
    }

    if (isset($_POST['export_csv'])) {

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=click-stats.csv');

        $out = fopen('php://output', 'w');
        fputcsv($out, ['Date', 'Phone Clicks', 'WhatsApp Clicks']);

        for ($i = 29; $i >= 0; $i--) {
            $day = date('Y-m-d', strtotime("-$i days"));
            fputcsv($out, [
                $day,
                get_option("phone_clicks_$day", 0),
                get_option("whatsapp_clicks_$day", 0)
            ]);
        }

        fclose($out);
        exit;
    }
});
?>
