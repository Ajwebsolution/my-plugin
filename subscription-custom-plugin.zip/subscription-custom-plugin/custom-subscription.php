<?php
/**
 * Plugin Name:  Subscription Plugin
 * Description: Custom subscription plugin with admin dashboard and welcome email editor.
 * Version: 1.5
 * Author: Amit Chauhan
 */

// Enqueue styles and scripts (Bootstrap, custom styles, and DataTables)
function lr_subscription_styles() {
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_style('lr-subscription-style', plugin_dir_url(__FILE__) . 'style.css'); // Ensure style.css exists
    wp_enqueue_script('jquery');
    wp_enqueue_script('enquiry-form-script', plugin_dir_url(__FILE__) . 'subscription-form.js', ['jquery'], null, true);
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js', ['jquery'], null, true);
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css');
}
add_action('admin_enqueue_scripts', 'lr_subscription_styles');


// Subscription Form Shortcode
function lr_subscription_form_shortcode() {
    ob_start(); ?>

<style>
       table#lr-subscribers-table {
    text-align: left !important;
}
    </style>

    <form id="lr-subscription-form" class="lr-unique-subscription-form">
        <input type="email" name="lr_email" class="lr-unique-email-input" placeholder="Enter your email" required />
        <button type="submit" class="lr-unique-subscribe-button">
            <span class="btn-text">Subscribe</span>
            <span class="spinner" style="display:none;">&#x21bb;</span>
        </button>
    </form>
    <div id="lr-subscription-message"></div>
    <script>
        document.getElementById('lr-subscription-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = e.target;
            const button = form.querySelector('.lr-unique-subscribe-button');
            const spinner = button.querySelector('.spinner');
            const btnText = button.querySelector('.btn-text');
            const email = form.lr_email.value;

            spinner.style.display = 'inline-block';
            btnText.style.display = 'none';

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=lr_subscribe&email=' + encodeURIComponent(email)
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('lr-subscription-message').innerText = data.message;
            })
            .finally(() => {
                spinner.style.display = 'none';
                btnText.style.display = 'inline';
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('lr_subscription_form', 'lr_subscription_form_shortcode');

// Handle Subscription
add_action('wp_ajax_lr_subscribe', 'lr_handle_subscription');
add_action('wp_ajax_nopriv_lr_subscribe', 'lr_handle_subscription');
function lr_handle_subscription() {
    global $wpdb;
    $email = sanitize_email($_POST['email']);

    if (!is_email($email)) {
        wp_send_json(['message' => 'Invalid email address.']);
        return;
    }

    $table_name = $wpdb->prefix . 'lr_subscribers';
    $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE email = %s", $email));

    if ($existing) {
        wp_send_json(['message' => 'You are already subscribed.']);
        return;
    }

    $wpdb->insert($table_name, [ 'email' => $email, 'subscribed_at' => current_time('mysql') ]);

    $welcome_email_content = get_option('lr_welcome_email_content', 'Welcome to Heritage Gold!');
    $domain_name = parse_url(home_url(), PHP_URL_HOST);

    $formatted_email = '<h1>Welcome to Heritage Gold</h1>';
    $formatted_email .= preg_replace_callback('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/', function($matches) {
        $image_url = esc_url($matches[1]);
        return '<img src="' . $image_url . '" alt="Welcome Image" style="max-width:100%; height:auto;" />';
    }, $welcome_email_content);

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $domain_name . ' <no-reply@' . $domain_name . '>',
        'Reply-To: no-reply@' . $domain_name
    ];

    wp_mail($email, 'Welcome to ' . $domain_name, $formatted_email, $headers);

    wp_send_json(['message' => 'Thank you for subscribing!']);
}

// Create Database Table on Plugin Activation
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'lr_subscribers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        subscribed_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Admin Menu for Subscription List, Welcome Email Editor, and Shortcode Info
add_action('admin_menu', function() {
    add_menu_page('Subscribers', 'Subscribers', 'manage_options', 'lr-subscribers', 'lr_subscribers_page');
    add_submenu_page('lr-subscribers', 'Welcome Email', 'Welcome Email', 'manage_options', 'lr-welcome-email', 'lr_welcome_email_page');
    add_submenu_page('lr-subscribers', 'Shortcode Info', 'Shortcode Info', 'manage_options', 'lr-shortcode-info', 'lr_shortcode_info_page');
});

// Subscribers List Page with Delete Option
function lr_subscribers_page() {
    global $wpdb;

    if (isset($_POST['delete_subscriber'])) {
        $id = intval($_POST['subscriber_id']);
        $wpdb->delete($wpdb->prefix . 'lr_subscribers', ['id' => $id]);
        echo '<div class="updated"><p>Subscriber deleted!</p></div>';
    }

    $subscribers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}lr_subscribers ORDER BY subscribed_at DESC");
    ?>
    <h1>Subscribers List</h1>
    <table id="lr-subscribers-table">
        <thead>
            <tr><th>Email</th><th>Subscribed At</th><th>Action</th></tr>
        </thead>
        <tbody>
            <?php foreach ($subscribers as $subscriber) : ?>
                <tr>
                    <td><?php echo esc_html($subscriber->email); ?></td>
                    <td><?php echo esc_html($subscriber->subscribed_at); ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="subscriber_id" value="<?php echo esc_attr($subscriber->id); ?>">
                            <button type="submit" name="delete_subscriber" class="button button-danger" onclick="return confirm('Are you sure you want to delete this subscriber?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <script>
        jQuery(document).ready(function($) {
            $('#lr-subscribers-table').DataTable();
        });
    </script>
    <?php
}

// Welcome Email Editor Page
function lr_welcome_email_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        update_option('lr_welcome_email_content', wp_kses_post($_POST['lr_welcome_email_content']));
        echo '<div class="updated"><p>Welcome email updated!</p></div>';
    }
    $content = get_option('lr_welcome_email_content', 'Welcome to Little Reads!');
    ?>
    <h1>Welcome Email Editor</h1>
    <form method="post">
        <?php wp_editor($content, 'lr_welcome_email_content'); ?>
        <button type="submit" class="button button-primary">Save Changes</button>
    </form>
    <?php
}

// Shortcode Info Page
function lr_shortcode_info_page() {
    echo '<h1>Shortcode Information</h1>';
    echo '<p>Use the following shortcode to display the subscription form on any page or post:</p>';
    echo '<code>[lr_subscription_form]</code>';
} ?>
