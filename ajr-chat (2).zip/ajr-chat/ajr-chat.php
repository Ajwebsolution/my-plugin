<?php
/**
 * Plugin Name: AJR Chat
 * Description: A standalone Skype/Google Chat-style messaging workspace for logged-in WordPress users.
 * Version: 2.8.1
 * Author: AJR Group
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: ajr-chat
 */
if (!defined('ABSPATH')) exit;

final class AJR_Chat {
    const VERSION = '2.8.2';
    const SLUG = 'live-crm';
    private static $instance = null;
    public static function instance() { if (self::$instance === null) self::$instance = new self(); return self::$instance; }
    private function __construct() {
        add_action('init', [$this, 'rewrite']);
        add_action('init', [$this, 'maybe_upgrade'], 20);
        add_action('ajr_chat_daily_retention', [$this, 'run_retention_cleanup']);
        add_action('ajr_chat_daily_retention', [$this, 'cleanup_expired_statuses']);
        if (!wp_next_scheduled('ajr_chat_daily_retention')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'ajr_chat_daily_retention');
        add_filter('query_vars', function($vars){ $vars[] = 'ajr_chat_app'; return $vars; });
        add_action('template_redirect', [$this, 'render_app']);
        add_action('rest_api_init', [$this, 'routes']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_post_ajr_chat_save_admin', [$this, 'save_admin_settings']);
        add_action('admin_post_ajr_chat_report_action', [$this, 'admin_report_action']);
        add_action('admin_post_ajr_chat_support_reply', [$this, 'admin_support_reply']);
        add_action('admin_post_ajr_chat_support_status', [$this, 'admin_support_status']);
        add_action('admin_post_ajr_chat_support_note', [$this, 'admin_support_note']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'links']);
        add_action('wp_footer', [$this, 'floating_widget']);
        add_action('wp_ajax_nopriv_ajr_chat_auth', [$this, 'public_auth']);
        add_action('wp_ajax_ajr_chat_auth', [$this, 'public_auth']);
    }
    public static function activate() { self::create_tables(); update_option('ajr_chat_db_version', self::VERSION); add_rewrite_rule('^live-crm/?$', 'index.php?ajr_chat_app=1', 'top'); flush_rewrite_rules(); }
    public static function deactivate() { wp_clear_scheduled_hook('ajr_chat_daily_retention'); flush_rewrite_rules(); }
    public function rewrite() { add_rewrite_rule('^live-crm/?$', 'index.php?ajr_chat_app=1', 'top'); }
    public function maybe_upgrade() { if (version_compare((string)get_option('ajr_chat_db_version', '0'), self::VERSION, '<')) { self::create_tables(); update_option('ajr_chat_db_version', self::VERSION); } }
    private static function table($name) { global $wpdb; return $wpdb->prefix . 'ajr_chat_' . $name; }
    private static function create_tables() {
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $conversations = self::table('conversations'); $participants = self::table('participants'); $messages = self::table('messages'); $reports = self::table('reports'); $hidden = self::table('hidden_messages'); $statuses=self::table('statuses'); $status_views=self::table('status_views'); $status_interactions=self::table('status_interactions'); $signals=self::table('call_signals');
        dbDelta("CREATE TABLE $conversations (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            type VARCHAR(12) NOT NULL DEFAULT 'direct',
            title VARCHAR(190) NOT NULL DEFAULT '',
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            last_message_id BIGINT UNSIGNED NULL,
            PRIMARY KEY  (id),
            KEY type (type),
            KEY updated_at (updated_at)
        ) $charset;");
        dbDelta("CREATE TABLE $participants (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            last_read_at DATETIME NULL,
            joined_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY conversation_user (conversation_id,user_id),
            KEY user_id (user_id)
        ) $charset;");
        dbDelta("CREATE TABLE $messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            sender_id BIGINT UNSIGNED NOT NULL,
            body LONGTEXT NOT NULL,
            attachment_url TEXT NULL,
            attachment_name VARCHAR(255) NULL,
            attachment_mime VARCHAR(190) NULL,
            reply_to_id BIGINT UNSIGNED NULL,
            reactions LONGTEXT NULL,
            edited_at DATETIME NULL,
            pinned_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_id_id (conversation_id,id),
            KEY sender_id (sender_id)
        ) $charset;");
        dbDelta("CREATE TABLE $reports (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            message_id BIGINT UNSIGNED NOT NULL,
            conversation_id BIGINT UNSIGNED NOT NULL,
            reporter_id BIGINT UNSIGNED NOT NULL,
            reason VARCHAR(40) NOT NULL DEFAULT 'other',
            details TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY status_created (status,created_at),
            KEY message_id (message_id)
        ) $charset;");
        $support_meta = self::table('support_meta'); $support_notes = self::table('support_notes');
        dbDelta("CREATE TABLE $support_meta (
            conversation_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            assigned_user_id BIGINT UNSIGNED NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (conversation_id),
            KEY status_updated (status,updated_at),
            KEY assigned_user_id (assigned_user_id)
        ) $charset;");
        dbDelta("CREATE TABLE $support_notes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            author_id BIGINT UNSIGNED NOT NULL,
            note TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_id_id (conversation_id,id)
        ) $charset;");
        dbDelta("CREATE TABLE $hidden (
            message_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            hidden_at DATETIME NOT NULL,
            PRIMARY KEY  (message_id,user_id),
            KEY user_id (user_id)
        ) $charset;");
        dbDelta("CREATE TABLE $statuses (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            status_type VARCHAR(12) NOT NULL DEFAULT 'text',
            text_content TEXT NULL,
            media_url TEXT NULL,
            media_mime VARCHAR(100) NULL,
            background VARCHAR(20) NOT NULL DEFAULT '#2563eb',
            privacy VARCHAR(20) NOT NULL DEFAULT 'contacts',
            allowed_user_ids LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_expires (user_id,expires_at),
            KEY expires_at (expires_at)
        ) $charset;");
        dbDelta("CREATE TABLE $status_views (
            status_id BIGINT UNSIGNED NOT NULL,
            viewer_id BIGINT UNSIGNED NOT NULL,
            viewed_at DATETIME NOT NULL,
            PRIMARY KEY (status_id,viewer_id),
            KEY viewer_id (viewer_id),
            KEY viewed_at (viewed_at)
        ) $charset;");
        dbDelta("CREATE TABLE $status_interactions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            status_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            interaction_type VARCHAR(12) NOT NULL,
            content TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY status_created (status_id,created_at),
            KEY user_id (user_id)
        ) $charset;");
        dbDelta("CREATE TABLE $signals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            call_id VARCHAR(64) NOT NULL,
            conversation_id BIGINT UNSIGNED NOT NULL,
            from_user BIGINT UNSIGNED NOT NULL,
            to_user BIGINT UNSIGNED NOT NULL,
            signal_type VARCHAR(16) NOT NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id), KEY recipient_id (to_user,id), KEY call_id (call_id,id), KEY conversation_id (conversation_id)
        ) $charset;");
    }
    public function links($links) { $links[] = '<a href="' . esc_url(home_url('/live-crm/')) . '">Open chat</a>'; return $links; }
    public function assets() {
        if (is_admin()) return;
        // Floating login/chat widget is rendered site-wide, so its stylesheet must also load site-wide.
        wp_enqueue_style('ajr-chat-widget', plugin_dir_url(__FILE__) . 'assets/chat.css', [], self::VERSION);
        wp_enqueue_script('ajr-chat-auth', plugin_dir_url(__FILE__) . 'assets/auth-widget.js', [], self::VERSION, true);
        wp_localize_script('ajr-chat-auth', 'AJRChatAuth', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajr_chat_public_auth'),
            'chatUrl' => esc_url_raw(home_url('/live-crm/')),
            'loggedIn' => is_user_logged_in(),
            'userName' => is_user_logged_in() ? wp_get_current_user()->display_name : '',
            'homeUrl' => esc_url_raw(home_url('/')),
        ]);
        if (get_query_var('ajr_chat_app')) {
            // Google Fonts are loaded on demand by chat.js for the selected family only.
            wp_enqueue_script('ajr-chat', plugin_dir_url(__FILE__) . 'assets/chat.js', [], self::VERSION, true);
            wp_localize_script('ajr-chat', 'AJRChat', [
                'api' => esc_url_raw(rest_url('ajr-chat/v1/')),
                'nonce' => wp_create_nonce('wp_rest'),
                'currentUser' => get_current_user_id(),
                'poll' => 4000,
                'maxUpload' => wp_max_upload_size(),
                'siteName' => get_bloginfo('name'),
                'homeUrl' => esc_url_raw(home_url('/')),
            ]);
        }
    }
    public function floating_widget() {
        if (is_admin() || get_query_var('ajr_chat_app')) return;
        echo '<div id="ajr-chat-floating" class="ac-float-root"><button type="button" class="ac-float-button" id="ac-float-open" aria-label="Open chat" title="Choose a chat option"><span class="ac-float-glyph">✉</span><span class="ac-float-label">Chat</span></button><section class="ac-float-panel" id="ac-float-panel" hidden aria-label="Chat account"><header class="ac-float-header"><div><strong>AJR Chat</strong><small>Connect and message your team</small></div><button type="button" id="ac-float-close" aria-label="Close chat">×</button></header><div class="ac-float-content" id="ac-float-content"></div></section></div>';
    }
    public function public_auth() {
        if (!check_ajax_referer('ajr_chat_public_auth', 'nonce', false)) wp_send_json_error(['message'=>'Security check failed. Refresh the page and try again.'], 403);
        $mode = isset($_POST['mode']) ? sanitize_key(wp_unslash($_POST['mode'])) : '';
        if ($mode === 'logout') $this->handle_logout();
        if ($mode === 'forgot') $this->handle_forgot_password();
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $key = 'ajr_chat_auth_' . md5($ip);
        $attempts = (int)get_transient($key);
        if ($attempts >= 12) wp_send_json_error(['message'=>'Too many attempts. Please wait 15 minutes and try again.'], 429);
        set_transient($key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $password = isset($_POST['password']) ? (string)wp_unslash($_POST['password']) : '';
        if (!is_email($email)) wp_send_json_error(['message'=>'Enter a valid email address.'], 400);
        if (strlen($password) < 8 || strlen($password) > 128) wp_send_json_error(['message'=>'Password must be between 8 and 128 characters.'], 400);
        if ($mode === 'register') {
            if (!get_option('ajr_chat_public_registration', 1)) wp_send_json_error(['message'=>'New chat account registration is currently disabled. Please contact the site administrator.'], 403);
            if (email_exists($email)) wp_send_json_error(['message'=>'An account with this email already exists. Please sign in.'], 409);
            $base = sanitize_user(current(explode('@', $email)), true);
            if (!$base) $base = 'chatuser';
            $username = $base; $i = 1;
            while (username_exists($username)) { $username = $base . wp_rand(100, 9999); if (++$i > 20) $username = 'chat' . wp_generate_password(10, false, false); }
            $user_id = wp_create_user($username, $password, $email);
            if (is_wp_error($user_id)) wp_send_json_error(['message'=>$user_id->get_error_message()], 400);
            wp_update_user(['ID'=>$user_id, 'display_name'=>$username, 'role'=>'subscriber']);
            $user = get_user_by('id', $user_id);
            $signed = wp_signon(['user_login'=>$user->user_login, 'user_password'=>$password, 'remember'=>true], is_ssl());
            if (is_wp_error($signed)) wp_send_json_success(['message'=>'Account created. Please sign in.', 'loginRequired'=>true]);
            wp_send_json_success(['message'=>'Account created. Opening your chat…', 'redirect'=>home_url('/live-crm/')]);
        }
        if ($mode === 'login') {
            $user = get_user_by('email', $email);
            if (!$user) wp_send_json_error(['message'=>'Email or password is incorrect.'], 401);
            $signed = wp_signon(['user_login'=>$user->user_login, 'user_password'=>$password, 'remember'=>true], is_ssl());
            if (is_wp_error($signed)) wp_send_json_error(['message'=>'Email or password is incorrect.'], 401);
            wp_send_json_success(['message'=>'Signed in. Opening your chat…', 'redirect'=>home_url('/live-crm/')]);
        }
        wp_send_json_error(['message'=>'Choose sign in or create account.'], 400);
    }
    private function client_ip() { return isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown'; }
    private function handle_logout() {
        if (is_user_logged_in()) { delete_user_meta(get_current_user_id(), 'ajr_chat_last_seen'); wp_logout(); }
        wp_send_json_success(['message'=>'You have been signed out.', 'nonce'=>wp_create_nonce('ajr_chat_public_auth'), 'redirect'=>home_url('/')]);
    }
    private function send_reset_email($login) {
        return retrieve_password($login);
    }
    private function handle_forgot_password() {
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if (!is_email($email)) wp_send_json_error(['message'=>'Enter the email address of your account.'], 400);
        $ip_key = 'ajr_chat_forgot_ip_' . md5($this->client_ip()); $em_key = 'ajr_chat_forgot_em_' . md5(strtolower($email));
        $ip_n = (int)get_transient($ip_key); $em_n = (int)get_transient($em_key);
        if ($ip_n >= 5 || $em_n >= 3) wp_send_json_error(['message'=>'Too many reset requests. Please wait 15 minutes and try again.'], 429);
        set_transient($ip_key, $ip_n + 1, 15 * MINUTE_IN_SECONDS); set_transient($em_key, $em_n + 1, 15 * MINUTE_IN_SECONDS);
        $user = get_user_by('email', $email);
        if ($user) { try { $this->send_reset_email($user->user_login); } catch (Throwable $e) {} }
        // Same reply whether or not the account exists, so emails cannot be probed.
        wp_send_json_success(['message'=>'If an account exists for that email address, a password reset link has been sent. Check your inbox and spam folder.']);
    }
    public function rest_logout() {
        if (is_user_logged_in()) { delete_user_meta($this->current_user(), 'ajr_chat_last_seen'); wp_logout(); }
        return rest_ensure_response(['loggedOut'=>true, 'redirect'=>home_url('/')]);
    }
    public function rest_password_reset() {
        $user = get_userdata($this->current_user());
        if (!$user) return new WP_Error('ajr_reset_user', 'Account not found.', ['status'=>404]);
        $key = 'ajr_chat_reset_user_' . (int)$user->ID; $n = (int)get_transient($key);
        if ($n >= 3) return new WP_Error('ajr_reset_limit', 'Too many reset emails requested. Please try again in an hour.', ['status'=>429]);
        set_transient($key, $n + 1, HOUR_IN_SECONDS);
        $result = $this->send_reset_email($user->user_login);
        if (is_wp_error($result)) return new WP_Error('ajr_reset_failed', wp_strip_all_tags($result->get_error_message()) ?: 'Could not send the reset email.', ['status'=>500]);
        return rest_ensure_response(['sent'=>true, 'email'=>$user->user_email]);
    }
    public function render_app() {
        if (!get_query_var('ajr_chat_app')) return;
        if (!is_user_logged_in()) {
            auth_redirect();
            exit;
        }
        status_header(200); nocache_headers();
        ?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?php echo esc_html(get_bloginfo('name') . ' — Chat'); ?></title><?php wp_head(); ?></head><body class="ajr-chat-body"><div id="ajr-chat-app" aria-live="polite"><div class="ajr-loading">Loading your workspace…</div></div><?php wp_footer(); ?></body></html><?php
        exit;
    }
    private function current_user() { return get_current_user_id(); }
    private function can_access($conversation_id, $user_id = 0) {
        global $wpdb; $user_id = $user_id ?: $this->current_user();
        return (bool) $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::table('participants') . ' WHERE conversation_id=%d AND user_id=%d', $conversation_id, $user_id));
    }
    private function require_member($id) {
        if (!$this->can_access(absint($id))) return new WP_Error('ajr_forbidden', 'You do not have access to this conversation.', ['status' => 403]);
        return true;
    }
    private function user_data($user) {
        $last = (int)get_user_meta($user->ID, 'ajr_chat_last_seen', true);
        return ['id'=>(int)$user->ID, 'name'=>$user->display_name ?: $user->user_login,
            'avatar'=>get_user_meta($user->ID, 'ajr_chat_avatar_url', true) ?: get_avatar_url($user->ID, ['size'=>96, 'default'=>'404']),
            'online'=>$this->is_online($user->ID), 'lastSeen'=>$last,
            'jobTitle'=>(string)get_user_meta($user->ID, 'ajr_chat_job_title', true),
            'about'=>(string)get_user_meta($user->ID, 'ajr_chat_about', true)];
    }
    private function is_online($user_id) {
        $last = (int)get_user_meta($user_id, 'ajr_chat_last_seen', true);
        return $last && $last > (time() - 120);
    }
    private function touch() { update_user_meta($this->current_user(), 'ajr_chat_last_seen', time()); }
    private function local_iso($mysql) {
        if (!$mysql || $mysql === '0000-00-00 00:00:00') return '';
        try { return (new DateTimeImmutable($mysql, wp_timezone()))->format(DateTimeInterface::ATOM); }
        catch (Exception $e) { return ''; }
    }
    private function json_message($row) {
        global $wpdb;
        $sender = get_userdata((int)$row->sender_id);
        $reply_id = isset($row->reply_to_id) ? (int)$row->reply_to_id : 0; $reply_preview = null;
        if ($reply_id) { $parent = $wpdb->get_row($wpdb->prepare('SELECT m.body,m.attachment_name,u.display_name FROM ' . self::table('messages') . ' m LEFT JOIN ' . $wpdb->users . ' u ON u.ID=m.sender_id WHERE m.id=%d AND m.conversation_id=%d', $reply_id, (int)$row->conversation_id)); if ($parent) $reply_preview = ['senderName'=>$parent->display_name ?: 'Unknown', 'body'=>$parent->body ?: ($parent->attachment_name ?: 'Attachment')]; }
        $read_rows = $wpdb->get_results($wpdb->prepare(
            'SELECT p.user_id,p.last_read_at,u.display_name FROM '.self::table('participants').' p LEFT JOIN '.$wpdb->users.' u ON u.ID=p.user_id WHERE p.conversation_id=%d AND p.user_id<>%d AND p.last_read_at IS NOT NULL AND p.last_read_at >= %s ORDER BY p.last_read_at ASC',
            (int)$row->conversation_id, (int)$row->sender_id, $row->created_at
        ));
        $read_by = [];
        foreach ((array)$read_rows as $reader) {
            $read_by[] = ['userId'=>(int)$reader->user_id, 'name'=>$reader->display_name ?: 'User', 'readAt'=>$this->local_iso($reader->last_read_at)];
        }
        $last_read_at = $read_by ? $read_by[count($read_by)-1]['readAt'] : '';
        return ['id'=>(int)$row->id, 'conversationId'=>(int)$row->conversation_id, 'senderId'=>(int)$row->sender_id,
            'senderName'=>$sender ? $sender->display_name : 'Unknown', 'body'=>$row->body,
            'attachmentUrl'=>$row->attachment_url, 'attachmentName'=>$row->attachment_name, 'attachmentMime'=>$row->attachment_mime,
            'createdAt'=>$this->local_iso($row->created_at), 'replyToId'=>$reply_id, 'replyPreview'=>$reply_preview, 'reactions'=>isset($row->reactions) ? (json_decode((string)$row->reactions, true) ?: []) : [], 'editedAt'=>!empty($row->edited_at) ? $this->local_iso($row->edited_at) : '', 'pinnedAt'=>!empty($row->pinned_at) ? $this->local_iso($row->pinned_at) : '', 'readBy'=>$read_by, 'lastReadAt'=>$last_read_at, 'readByCount'=>count($read_by), 'readByTotal'=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('participants').' WHERE conversation_id=%d AND user_id<>%d',(int)$row->conversation_id,(int)$row->sender_id))];
    }
    public function routes() {
        register_rest_route('ajr-chat/v1', '/logout', ['methods'=>'POST','callback'=>[$this,'rest_logout'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/account/password-reset', ['methods'=>'POST','callback'=>[$this,'rest_password_reset'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/statuses', ['methods'=>'GET','callback'=>[$this,'list_statuses'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/statuses', ['methods'=>'POST','callback'=>[$this,'create_status'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/statuses/(?P<id>\d+)/view', ['methods'=>'POST','callback'=>[$this,'view_status'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/statuses/(?P<id>\d+)/interact', ['methods'=>'POST','callback'=>[$this,'interact_status'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/statuses/(?P<id>\d+)', ['methods'=>'DELETE','callback'=>[$this,'delete_status'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/bootstrap', ['methods'=>'GET','callback'=>[$this,'bootstrap'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversation', ['methods'=>'POST','callback'=>[$this,'start_direct'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/support-conversation', ['methods'=>'POST','callback'=>[$this,'start_support_conversation'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/groups', ['methods'=>'POST','callback'=>[$this,'create_group'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/messages', ['methods'=>'GET','callback'=>[$this,'get_messages'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/messages', ['methods'=>'POST','callback'=>[$this,'send_message'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/messages/(?P<message_id>\d+)/action', ['methods'=>'POST','callback'=>[$this,'message_action'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/messages/(?P<message_id>\d+)/forward', ['methods'=>'POST','callback'=>[$this,'forward_message'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/upload', ['methods'=>'POST','callback'=>[$this,'upload'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/presence', ['methods'=>'POST','callback'=>[$this,'presence'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/profile', ['methods'=>'GET','callback'=>[$this,'get_profile'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/profile', ['methods'=>'POST','callback'=>[$this,'update_profile'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/prefs', ['methods'=>'GET','callback'=>[$this,'get_prefs'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/prefs', ['methods'=>'POST','callback'=>[$this,'save_prefs'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/search', ['methods'=>'GET','callback'=>[$this,'search_history'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/report', ['methods'=>'POST','callback'=>[$this,'report_message'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/export', ['methods'=>'GET','callback'=>[$this,'export_conversation'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/conversations/(?P<id>\d+)/clear', ['methods'=>'POST','callback'=>[$this,'clear_conversation'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/calls/signal', ['methods'=>'POST','callback'=>[$this,'call_signal_send'],'permission_callback'=>[$this,'logged_in']]);
        register_rest_route('ajr-chat/v1', '/calls/signals', ['methods'=>'GET','callback'=>[$this,'call_signal_poll'],'permission_callback'=>[$this,'logged_in']]);
    }
    public function call_signal_send($request) {
        global $wpdb; $uid=$this->current_user(); $cid=absint($request->get_param('conversationId')); $to=absint($request->get_param('toUser'));
        $call=sanitize_text_field((string)$request->get_param('callId')); $type=sanitize_key((string)$request->get_param('type'));
        $types=['invite','offer','answer','ice','decline','hangup','busy'];
        if (!$cid || !$to || !$call || strlen($call)>64 || !in_array($type,$types,true)) return new WP_Error('ajr_call_invalid','Invalid call signal.',['status'=>400]);
        if (!$this->can_access($cid,$uid) || !$this->can_access($cid,$to)) return new WP_Error('ajr_call_forbidden','Both users must belong to this conversation.',['status'=>403]);
        $conv=$wpdb->get_var($wpdb->prepare('SELECT type FROM '.self::table('conversations').' WHERE id=%d',$cid));
        if ($conv!=='direct') return new WP_Error('ajr_call_direct_only','Voice calls are currently available for direct conversations only.',['status'=>400]);
        if ($to===$uid) return new WP_Error('ajr_call_self','You cannot call yourself.',['status'=>400]);
        $payload=$request->get_param('payload'); $json=''; if($payload!==null){$json=wp_json_encode($payload);if(!$json||strlen($json)>200000)return new WP_Error('ajr_call_payload','Call payload is too large.',['status'=>413]);}
        $wpdb->insert(self::table('call_signals'),['call_id'=>$call,'conversation_id'=>$cid,'from_user'=>$uid,'to_user'=>$to,'signal_type'=>$type,'payload'=>$json,'created_at'=>current_time('mysql',true)],['%s','%d','%d','%d','%s','%s','%s']);
        if(!$wpdb->insert_id)return new WP_Error('ajr_call_store','Could not store call signal.',['status'=>500]); return rest_ensure_response(['ok'=>true,'id'=>(int)$wpdb->insert_id]);
    }
    public function call_signal_poll($request) {
        global $wpdb; $uid=$this->current_user(); $after=max(0,absint($request->get_param('after'))); $call=sanitize_text_field((string)$request->get_param('callId'));
        $sql='SELECT s.* FROM '.self::table('call_signals').' s INNER JOIN '.self::table('participants').' p ON p.conversation_id=s.conversation_id AND p.user_id=%d WHERE s.to_user=%d AND s.id>%d'; $args=[$uid,$uid,$after];
        if($call!==''){$sql.=' AND s.call_id=%s';$args[]=$call;} $sql.=' ORDER BY s.id ASC LIMIT 100'; $rows=$wpdb->get_results($wpdb->prepare($sql,$args)); $out=[];
        foreach($rows as $r)$out[]=['id'=>(int)$r->id,'callId'=>$r->call_id,'conversationId'=>(int)$r->conversation_id,'fromUser'=>(int)$r->from_user,'type'=>$r->signal_type,'payload'=>$r->payload?json_decode($r->payload,true):null,'createdAt'=>$r->created_at];
        $wpdb->query('DELETE FROM '.self::table('call_signals').' WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 DAY)'); return rest_ensure_response(['signals'=>$out,'lastId'=>$out?end($out)['id']:$after]);
    }
    public function logged_in() { return is_user_logged_in() && current_user_can('read'); }
    public function presence($request) {
        $this->touch(); $uid=$this->current_user(); $cid=absint($request->get_param('conversationId'));
        if (!$cid) return rest_ensure_response(['ok'=>true,'typing'=>[]]);
        $allowed=$this->require_member($cid); if(is_wp_error($allowed)) return $allowed;
        $key='ajr_chat_typing_'.$cid.'_'.$uid;
        if (rest_sanitize_boolean($request->get_param('typing'))) set_transient($key, time(), 8);
        else delete_transient($key);
        global $wpdb; $pt=self::table('participants'); $ids=$wpdb->get_col($wpdb->prepare("SELECT user_id FROM $pt WHERE conversation_id=%d AND user_id<>%d",$cid,$uid));
        $typing=[]; foreach($ids as $other){$stamp=get_transient('ajr_chat_typing_'.$cid.'_'.(int)$other); if($stamp && $stamp>time()-8){$u=get_userdata((int)$other);if($u)$typing[]=$u->display_name?:$u->user_login;}}
        return rest_ensure_response(['ok'=>true,'typing'=>$typing]);
    }
    public function bootstrap() {
        global $wpdb; $this->touch(); $uid = $this->current_user();
        $users = get_users(['fields'=>['ID','display_name','user_login'], 'orderby'=>'display_name','order'=>'ASC', 'number'=>1000, 'exclude'=>[$uid]]);
        $contacts = array_map(function($u){ return $this->user_data($u); }, $users);
        $pt = self::table('participants'); $ct = self::table('conversations'); $mt = self::table('messages');
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, p.last_read_at, (SELECT m.body FROM $mt m WHERE m.id=c.last_message_id) AS last_body,
            (SELECT m.sender_id FROM $mt m WHERE m.id=c.last_message_id) AS last_sender,
            (SELECT m.created_at FROM $mt m WHERE m.id=c.last_message_id) AS last_time,
            (SELECT COUNT(*) FROM $mt um WHERE um.conversation_id=c.id AND um.sender_id<>%d AND (p.last_read_at IS NULL OR um.created_at>p.last_read_at)) AS unread
            FROM $ct c INNER JOIN $pt p ON p.conversation_id=c.id WHERE p.user_id=%d ORDER BY c.updated_at DESC LIMIT 300", $uid, $uid));
        $conversations = [];
        foreach ($rows as $r) {
            $members = $wpdb->get_col($wpdb->prepare("SELECT user_id FROM $pt WHERE conversation_id=%d", $r->id));
            $other = null; foreach ($members as $mid) { if ((int)$mid !== $uid) { $u=get_userdata((int)$mid); if ($u) { $other=$this->user_data($u); break; } } }
            $conversations[] = ['id'=>(int)$r->id, 'type'=>$r->type, 'title'=>$r->type==='group' ? $r->title : ($other ? $other['name'] : 'Conversation'),
                'avatar'=>$r->type==='group' ? '' : ($other ? $other['avatar'] : ''), 'online'=>$other ? $other['online'] : false,
                'members'=>array_map('intval',$members), 'lastBody'=>$r->last_body ?: '', 'lastSender'=>(int)$r->last_sender,
                'lastId'=>(int)$r->last_message_id, 'lastSenderName'=>($ls = ($r->last_sender ? get_userdata((int)$r->last_sender) : null)) ? $ls->display_name : '',
                'lastTime'=>$r->last_time ? mysql2date('c',$r->last_time,false) : '', 'unread'=>(int)$r->unread];
        }
        return rest_ensure_response(['contacts'=>$contacts,'conversations'=>$conversations,'me'=>array_merge($this->user_data(get_userdata($uid)), ['email'=>get_userdata($uid)->user_email]), 'prefs'=>$this->get_prefs_array($uid)]);
    }
    /** Find the site's super administrator (multisite) or first site administrator. */
    private function support_admin_id() {
        $current = $this->current_user();
        $candidates = [];
        if (is_multisite() && function_exists('get_super_admins')) {
            foreach ((array)get_super_admins() as $login) {
                $u = get_user_by('login', $login);
                if ($u && (int)$u->ID !== $current) $candidates[] = (int)$u->ID;
            }
        }
        if (!$candidates) {
            $admins = get_users([
                'role' => 'administrator',
                'orderby' => 'ID',
                'order' => 'ASC',
                'number' => 100,
                'fields' => ['ID'],
            ]);
            foreach ($admins as $u) {
                if ((int)$u->ID !== $current && user_can((int)$u->ID, 'manage_options')) $candidates[] = (int)$u->ID;
            }
        }
        if (!$candidates) {
            $admins = get_users(['capability' => 'manage_options', 'orderby' => 'ID', 'order' => 'ASC', 'number' => 100, 'fields' => ['ID']]);
            foreach ($admins as $u) if ((int)$u->ID !== $current) $candidates[] = (int)$u->ID;
        }
        return $candidates ? (int)$candidates[0] : 0;
    }

    /** Open or create a private conversation between the current user and site admin. */
    public function start_support_conversation($request) {
        global $wpdb;
        $uid = $this->current_user();
        // Administrators should manage customer enquiries in the separate CRM,
        // not start a support conversation with themselves.
        if (user_can($uid, 'manage_options') || (is_multisite() && is_super_admin($uid))) {
            return rest_ensure_response([
                'adminMode' => true,
                'url' => admin_url('admin.php?page=ajr-support-crm')
            ]);
        }
        $admin_id = $this->support_admin_id();
        if (!$admin_id) return new WP_Error('ajr_no_support_admin', 'No support administrator account could be found. Please check that a WordPress administrator account exists and has the Administrator role.', ['status' => 404]);
        $pt = self::table('participants');
        $ct = self::table('conversations');
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT p1.conversation_id FROM $pt p1 INNER JOIN $pt p2 ON p1.conversation_id=p2.conversation_id INNER JOIN $ct c ON c.id=p1.conversation_id WHERE p1.user_id=%d AND p2.user_id=%d AND c.type='direct' ORDER BY c.updated_at DESC LIMIT 1",
            $uid, $admin_id
        ));
        if ($existing) {
            // Mark this direct thread as a support conversation so it appears in the separate admin CRM.
            $wpdb->update($ct, ['title'=>'AJR Support'], ['id'=>(int)$existing], ['%s'], ['%d']);
            $this->mark_read((int)$existing);
            return rest_ensure_response(['id' => (int)$existing, 'adminId' => $admin_id]);
        }
        $now = current_time('mysql');
        $wpdb->insert($ct, ['type'=>'direct','title'=>'AJR Support','created_by'=>$uid,'created_at'=>$now,'updated_at'=>$now], ['%s','%s','%d','%s','%s']);
        $id = (int)$wpdb->insert_id;
        if (!$id) return new WP_Error('ajr_support_db', 'Could not create the support conversation. Please try again.', ['status'=>500]);
        foreach ([$uid, $admin_id] as $member) {
            $wpdb->insert($pt, ['conversation_id'=>$id,'user_id'=>$member,'last_read_at'=>($member===$uid?$now:null),'joined_at'=>$now], ['%d','%d','%s','%s']);
        }
        return rest_ensure_response(['id'=>$id, 'adminId'=>$admin_id]);
    }

    public function start_direct($request) {
        global $wpdb; $other = absint($request->get_param('userId')); $uid=$this->current_user();
        if (!$other || $other===$uid || !get_userdata($other)) return new WP_Error('ajr_bad_user','Choose a valid contact.',['status'=>400]);
        $pt=self::table('participants'); $ct=self::table('conversations');
        $existing=$wpdb->get_var($wpdb->prepare(
            "SELECT p1.conversation_id FROM $pt p1 INNER JOIN $pt p2 ON p1.conversation_id=p2.conversation_id INNER JOIN $ct c ON c.id=p1.conversation_id WHERE p1.user_id=%d AND p2.user_id=%d AND c.type='direct' LIMIT 1",$uid,$other));
        if ($existing) { $this->mark_read($existing); return rest_ensure_response(['id'=>(int)$existing]); }
        $now=current_time('mysql');
        $wpdb->insert($ct,['type'=>'direct','title'=>'','created_by'=>$uid,'created_at'=>$now,'updated_at'=>$now],['%s','%s','%d','%s','%s']);
        $id=(int)$wpdb->insert_id; if (!$id) return new WP_Error('ajr_db','Could not create conversation.',['status'=>500]);
        foreach ([$uid,$other] as $member) $wpdb->insert($pt,['conversation_id'=>$id,'user_id'=>$member,'last_read_at'=>($member===$uid?$now:null),'joined_at'=>$now],['%d','%d','%s','%s']);
        return rest_ensure_response(['id'=>$id]);
    }
    public function create_group($request) {
        global $wpdb; $uid=$this->current_user(); $title=sanitize_text_field((string)$request->get_param('title'));
        $ids=$request->get_param('userIds'); if (!is_array($ids)) $ids=[];
        $ids=array_values(array_unique(array_filter(array_map('absint',$ids),function($id)use($uid){return $id && $id!==$uid && get_userdata($id); })));
        if (!$title) return new WP_Error('ajr_group_title','Enter a group name.',['status'=>400]);
        if (count($ids)<1) return new WP_Error('ajr_group_members','Choose at least one other member.',['status'=>400]);
        if (count($ids)>99) return new WP_Error('ajr_group_limit','A group can have at most 100 members.',['status'=>400]);
        $ct=self::table('conversations'); $pt=self::table('participants'); $now=current_time('mysql');
        $wpdb->insert($ct,['type'=>'group','title'=>$title,'created_by'=>$uid,'created_at'=>$now,'updated_at'=>$now],['%s','%s','%d','%s','%s']);
        $id=(int)$wpdb->insert_id; if(!$id) return new WP_Error('ajr_db','Could not create group.',['status'=>500]);
        foreach (array_merge([$uid],$ids) as $member) $wpdb->insert($pt,['conversation_id'=>$id,'user_id'=>$member,'last_read_at'=>($member===$uid?$now:null),'joined_at'=>$now],['%d','%d','%s','%s']);
        return rest_ensure_response(['id'=>$id]);
    }
    private function mark_read($id) {
        global $wpdb; $wpdb->update(self::table('participants'),['last_read_at'=>current_time('mysql')],['conversation_id'=>absint($id),'user_id'=>$this->current_user()],['%s'],['%d','%d']);
    }
    public function get_messages($request) {
        global $wpdb; $id=absint($request['id']); $allowed=$this->require_member($id); if(is_wp_error($allowed)) return $allowed;
        $mt=self::table('messages');
        $after=max(0,absint($request->get_param('after')));
        $before=absint($request->get_param('before'));
        $around=absint($request->get_param('around'));
        $latest=(bool)$request->get_param('latest');
        $limit=absint($request->get_param('limit')); if($limit<1||$limit>100) $limit=50;
        $paged=false;
        if ($before) {
            $rows=array_reverse((array)$wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d AND id<%d ORDER BY id DESC LIMIT %d",$id,$before,$limit)));
            $paged=true;
        } elseif ($around) {
            $start=(int)$wpdb->get_var($wpdb->prepare("SELECT MIN(id) FROM (SELECT id FROM $mt WHERE conversation_id=%d AND id<=%d ORDER BY id DESC LIMIT 21) t",$id,$around));
            if ($start) $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d AND id>=%d ORDER BY id ASC LIMIT 300",$id,$start));
            else $rows=array_reverse((array)$wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d ORDER BY id DESC LIMIT %d",$id,$limit)));
            $paged=true;
        } elseif ($latest) {
            $rows=array_reverse((array)$wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d ORDER BY id DESC LIMIT %d",$id,$limit)));
            $paged=true;
        } else {
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d AND id>%d ORDER BY id ASC LIMIT 200",$id,$after));
        }
        $rows=is_array($rows)?$rows:[];
        $latest_id = $rows ? (int)end($rows)->id : $after;
        $first_fetched_id = $rows ? (int)$rows[0]->id : 0;
        $hidden_ids = $wpdb->get_col($wpdb->prepare('SELECT message_id FROM '.self::table('hidden_messages').' WHERE user_id=%d', $this->current_user()));
        if ($hidden_ids) { $hidden_lookup=array_fill_keys(array_map('intval',$hidden_ids),true); $rows=array_values(array_filter($rows,function($message) use ($hidden_lookup){ return empty($hidden_lookup[(int)$message->id]); })); }
        // mark=0 lets a hidden browser tab fetch new messages without marking them as read.
        if ((string)$request->get_param('mark')!=='0') $this->mark_read($id);
        $out=['messages'=>array_map([$this,'json_message'],$rows),'latestId'=>$latest_id];
        if ($paged) $out['hasMore']=$first_fetched_id ? (bool)$wpdb->get_var($wpdb->prepare("SELECT 1 FROM $mt WHERE conversation_id=%d AND id<%d LIMIT 1",$id,$first_fetched_id)) : false;
        return rest_ensure_response($out);
    }
    public function send_message($request) {
        global $wpdb; $id=absint($request['id']); $allowed=$this->require_member($id); if(is_wp_error($allowed)) return $allowed;
        $body=trim(sanitize_textarea_field((string)$request->get_param('body')));
        $attachment=$request->get_param('attachment');
        if (is_array($attachment)) {
            $url=esc_url_raw($attachment['url'] ?? ''); $name=sanitize_file_name($attachment['name'] ?? ''); $mime=sanitize_text_field($attachment['mime'] ?? '');
        } else { $url=''; $name=''; $mime=''; }
        if ($body==='' && !$url) return new WP_Error('ajr_empty','Write a message or attach a file.',['status'=>400]);
        if (strlen($body)>12000) return new WP_Error('ajr_long','Message is too long.',['status'=>400]);
        $reply_to = absint($request->get_param('replyToId'));
        if ($reply_to) { $parent=$wpdb->get_row($wpdb->prepare("SELECT id FROM " . self::table('messages') . " WHERE id=%d AND conversation_id=%d", $reply_to, $id)); if (!$parent) return new WP_Error('ajr_bad_reply','The message being replied to was not found.',['status'=>400]); }
        $mt=self::table('messages'); $ct=self::table('conversations'); $now=current_time('mysql');
        $wpdb->insert($mt,['conversation_id'=>$id,'sender_id'=>$this->current_user(),'body'=>$body,'attachment_url'=>$url,'attachment_name'=>$name,'attachment_mime'=>$mime,'reply_to_id'=>$reply_to ?: null,'reactions'=>'{}','created_at'=>$now],['%d','%d','%s','%s','%s','%s','%d','%s','%s']);
        $mid=(int)$wpdb->insert_id; if(!$mid) return new WP_Error('ajr_db','Message could not be saved.',['status'=>500]);
        $wpdb->update($ct,['last_message_id'=>$mid,'updated_at'=>$now],['id'=>$id],['%d','%s'],['%d']);
        $this->mark_read($id); $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $mt WHERE id=%d",$mid));
        return rest_ensure_response(['message'=>$this->json_message($row)]);
    }
    public function forward_message($request) {
        global $wpdb;
        $source_cid = absint($request['id']);
        $message_id = absint($request['message_id']);
        $destination_cid = absint($request->get_param('destinationConversationId'));
        if (!$source_cid || !$message_id || !$destination_cid) {
            return new WP_Error('ajr_forward_invalid', 'Choose a valid destination conversation.', ['status' => 400]);
        }
        $source_allowed = $this->require_member($source_cid);
        if (is_wp_error($source_allowed)) return $source_allowed;
        $destination_allowed = $this->require_member($destination_cid);
        if (is_wp_error($destination_allowed)) return $destination_allowed;
        $messages = self::table('messages');
        $source = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $messages WHERE id=%d AND conversation_id=%d",
            $message_id, $source_cid
        ));
        if (!$source) return new WP_Error('ajr_forward_missing', 'The original message was not found.', ['status' => 404]);
        if (empty($source->body) && empty($source->attachment_url)) {
            return new WP_Error('ajr_forward_empty', 'This message has no content to forward.', ['status' => 400]);
        }
        $now = current_time('mysql');
        $inserted = $wpdb->insert($messages, [
            'conversation_id' => $destination_cid,
            'sender_id' => $this->current_user(),
            'body' => (string)$source->body,
            'attachment_url' => (string)$source->attachment_url,
            'attachment_name' => (string)$source->attachment_name,
            'attachment_mime' => (string)$source->attachment_mime,
            'reply_to_id' => null,
            'reactions' => '{}',
            'created_at' => $now
        ], ['%d','%d','%s','%s','%s','%s','%d','%s','%s']);
        $new_id = (int)$wpdb->insert_id;
        if (!$inserted || !$new_id) return new WP_Error('ajr_forward_db', 'The message could not be forwarded. Please try again.', ['status' => 500]);
        $wpdb->update(self::table('conversations'), ['last_message_id'=>$new_id, 'updated_at'=>$now], ['id'=>$destination_cid], ['%d','%s'], ['%d']);
        $this->mark_read($destination_cid);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $messages WHERE id=%d", $new_id));
        return rest_ensure_response(['message'=>$this->json_message($row), 'forwarded'=>true]);
    }

    public function message_action($request) {
        global $wpdb;
        $cid=absint($request['id']); $mid=absint($request['message_id']);
        $allowed=$this->require_member($cid); if(is_wp_error($allowed)) return $allowed;
        $mt=self::table('messages'); $uid=$this->current_user();
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $mt WHERE id=%d AND conversation_id=%d",$mid,$cid));
        if(!$row) return new WP_Error('ajr_message_missing','Message not found.',['status'=>404]);
        $action=sanitize_key((string)$request->get_param('action'));
        if($action==='react') {
            $emoji=(string)$request->get_param('emoji');
            $allowed_emojis=['👍','❤️','😂','😮','😢','👏'];
            if(!in_array($emoji,$allowed_emojis,true)) return new WP_Error('ajr_reaction','Choose a supported reaction.',['status'=>400]);
            $reactions=json_decode((string)$row->reactions,true); if(!is_array($reactions)) $reactions=[];
            $users=isset($reactions[$emoji])&&is_array($reactions[$emoji])?$reactions[$emoji]:[];
            if(in_array($uid,$users,true)) $users=array_values(array_diff($users,[$uid])); else $users[]=$uid;
            if($users) $reactions[$emoji]=array_map('intval',$users); else unset($reactions[$emoji]);
            $wpdb->update($mt,['reactions'=>wp_json_encode($reactions)],['id'=>$mid],['%s'],['%d']);
        } elseif($action==='edit') {
            if((int)$row->sender_id!==$uid) return new WP_Error('ajr_message_owner','You can only edit your own messages.',['status'=>403]);
            if(strtotime(get_gmt_from_date($row->created_at))<time()-15*MINUTE_IN_SECONDS) return new WP_Error('ajr_edit_expired','Messages can only be edited for 15 minutes.',['status'=>400]);
            $body=trim(sanitize_textarea_field((string)$request->get_param('body')));
            if($body===''||strlen($body)>12000) return new WP_Error('ajr_edit_body','Edited message must contain 1–12000 characters.',['status'=>400]);
            $wpdb->update($mt,['body'=>$body,'edited_at'=>current_time('mysql')],['id'=>$mid],['%s','%s'],['%d']);
        } elseif($action==='pin' || $action==='unpin') {
            $wpdb->update($mt,['pinned_at'=>$action==='pin'?current_time('mysql'):null],['id'=>$mid],['%s'],['%d']);
        } elseif($action==='delete_me') {
            $wpdb->query($wpdb->prepare('INSERT IGNORE INTO '.self::table('hidden_messages').' (message_id,user_id,hidden_at) VALUES (%d,%d,%s)', $mid, $uid, current_time('mysql')));
            return rest_ensure_response(['deleted'=>true,'scope'=>'me','id'=>$mid]);
        } elseif($action==='delete_everyone') {
            if((int)$row->sender_id!==$uid && !current_user_can('moderate_comments')) return new WP_Error('ajr_message_owner','Only the sender or a moderator can delete this message for everyone.',['status'=>403]);
            $wpdb->delete($mt,['id'=>$mid,'conversation_id'=>$cid],['%d','%d']);
            $wpdb->delete(self::table('hidden_messages'),['message_id'=>$mid],['%d']);
            return rest_ensure_response(['deleted'=>true,'scope'=>'everyone','id'=>$mid]);
        } elseif($action==='delete') {
            if((int)$row->sender_id!==$uid && !current_user_can('moderate_comments')) return new WP_Error('ajr_message_owner','You can only delete your own messages.',['status'=>403]);
            $wpdb->delete($mt,['id'=>$mid,'conversation_id'=>$cid],['%d','%d']);
            return rest_ensure_response(['deleted'=>true,'scope'=>'everyone','id'=>$mid]);
        } else return new WP_Error('ajr_message_action','Unsupported message action.',['status'=>400]);
        $updated=$wpdb->get_row($wpdb->prepare("SELECT * FROM $mt WHERE id=%d",$mid));
        return rest_ensure_response(['message'=>$this->json_message($updated)]);
    }
    public function report_message($request) {
        global $wpdb;
        $cid = absint($request->get_param('conversationId')); $mid = absint($request->get_param('messageId')); $uid = $this->current_user();
        $member = $this->require_member($cid); if (is_wp_error($member)) return $member;
        $message = $wpdb->get_row($wpdb->prepare('SELECT id,sender_id FROM ' . self::table('messages') . ' WHERE id=%d AND conversation_id=%d', $mid, $cid));
        if (!$message) return new WP_Error('ajr_report_missing', 'Message not found.', ['status'=>404]);
        if ((int)$message->sender_id === $uid) return new WP_Error('ajr_report_own', 'You cannot report your own message.', ['status'=>400]);
        $reason = sanitize_key((string)$request->get_param('reason'));
        $allowed = ['spam','harassment','inappropriate','scam','other']; if (!in_array($reason, $allowed, true)) $reason = 'other';
        $details = sanitize_textarea_field((string)$request->get_param('details')); $details = mb_substr($details, 0, 1000);
        $table = self::table('reports');
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE message_id=%d AND reporter_id=%d AND status='open'", $mid, $uid));
        if ($existing) return rest_ensure_response(['reported'=>true,'alreadyReported'=>true]);
        $ok = $wpdb->insert($table, ['message_id'=>$mid,'conversation_id'=>$cid,'reporter_id'=>$uid,'reason'=>$reason,'details'=>$details,'status'=>'open','created_at'=>current_time('mysql')], ['%d','%d','%d','%s','%s','%s','%s']);
        if (!$ok) return new WP_Error('ajr_report_save', 'Could not submit report.', ['status'=>500]);
        return rest_ensure_response(['reported'=>true]);
    }
    public function export_conversation($request) {
        global $wpdb;
        $cid = absint($request['id']); $member = $this->require_member($cid); if (is_wp_error($member)) return $member;
        $mt = self::table('messages');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT m.id,m.conversation_id,m.sender_id,m.body,m.attachment_name,m.attachment_url,m.created_at,m.edited_at FROM $mt m WHERE m.conversation_id=%d AND NOT EXISTS (SELECT 1 FROM ".self::table('hidden_messages')." h WHERE h.message_id=m.id AND h.user_id=%d) ORDER BY m.id ASC LIMIT 10000", $cid, $this->current_user()), ARRAY_A);
        $out = [];
        foreach ($rows as $row) { $u = get_userdata((int)$row['sender_id']); $out[] = ['id'=>(int)$row['id'],'senderId'=>(int)$row['sender_id'],'senderName'=>$u ? $u->display_name : 'Unknown','message'=>$row['body'],'attachmentName'=>$row['attachment_name'],'attachmentUrl'=>$row['attachment_url'],'createdAt'=>$this->local_iso($row['created_at']),'editedAt'=>$row['edited_at'] ? $this->local_iso($row['edited_at']) : '']; }
        return rest_ensure_response(['conversationId'=>$cid,'exportedAt'=>$this->local_iso(current_time('mysql')),'count'=>count($out),'messages'=>$out,'truncated'=>count($out)>=10000]);
    }
    public function clear_conversation($request) {
        global $wpdb;
        $cid=absint($request['id']); $member=$this->require_member($cid); if(is_wp_error($member)) return $member;
        $uid=$this->current_user(); $messages=self::table('messages'); $hidden=self::table('hidden_messages'); $now=current_time('mysql');
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $hidden (message_id,user_id,hidden_at) SELECT id,%d,%s FROM $messages WHERE conversation_id=%d",$uid,$now,$cid));
        return rest_ensure_response(['cleared'=>true,'scope'=>'me']);
    }
    public function run_retention_cleanup() {
        $days = absint(get_option('ajr_chat_retention_days', 0));
        if (!$days || !in_array($days, [30, 90, 180, 365], true)) return;
        global $wpdb;
        $messages = self::table('messages'); $conversations = self::table('conversations');
        $cutoff = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
        // Keep pinned messages and delete only unpinned messages beyond the configured retention window.
        $wpdb->query($wpdb->prepare("DELETE FROM $messages WHERE created_at < %s AND (pinned_at IS NULL OR pinned_at = '0000-00-00 00:00:00')", $cutoff));
        // Recalculate each conversation's last message pointer after cleanup.
        $wpdb->query("UPDATE $conversations c SET c.last_message_id = (SELECT MAX(m.id) FROM $messages m WHERE m.conversation_id = c.id)");
    }
    public function admin_menu() {
        add_menu_page('AJR Chat','AJR Chat','manage_options','ajr-chat-admin',[$this,'admin_page'],'dashicons-format-chat',58);
        add_submenu_page('ajr-chat-admin','Reported messages','Reports','manage_options','ajr-chat-admin-reports',[$this,'admin_reports_page']);
        // A deliberately separate CRM screen for customer-to-admin support conversations.
        add_menu_page('AJR Support CRM','Support CRM','manage_options','ajr-support-crm',[$this,'admin_support_crm_page'],'dashicons-sos',59);
    }
    private function can_access_support_crm() {
        return is_multisite() ? is_super_admin() : current_user_can('manage_options');
    }
    private function is_support_participant($conversation_id, $user_id) {
        global $wpdb;
        return (bool)$wpdb->get_var($wpdb->prepare(
            'SELECT p.user_id FROM '.self::table('participants').' p INNER JOIN '.self::table('conversations').' c ON c.id=p.conversation_id WHERE p.conversation_id=%d AND p.user_id=%d AND c.title=%s AND c.type=%s LIMIT 1',
            absint($conversation_id), absint($user_id), 'AJR Support', 'direct'
        ));
    }
    public function admin_support_crm_page() {
        if (!$this->can_access_support_crm()) wp_die('Only the super administrator can access the Support CRM.');
        global $wpdb;
        $uid = get_current_user_id();
        $ct = self::table('conversations'); $pt = self::table('participants'); $mt = self::table('messages');
        $selected = absint($_GET['conversation_id'] ?? 0);
        // Support is routed to the first super admin on Multisite, or first site admin on a single site.
        $crmAdminId = 0;
        if (is_multisite() && function_exists('get_super_admins')) {
            $superLogins = (array)get_super_admins();
            if ($superLogins) { $supportAdmin = get_user_by('login', $superLogins[0]); if ($supportAdmin) $crmAdminId = (int)$supportAdmin->ID; }
        }
        if (!$crmAdminId) {
            $siteAdmins = get_users(['role'=>'administrator','orderby'=>'ID','order'=>'ASC','number'=>1,'fields'=>['ID']]);
            if ($siteAdmins) $crmAdminId = (int)$siteAdmins[0]->ID;
        }
        if (!$crmAdminId) {
            $siteAdmins = get_users(['capability'=>'manage_options','orderby'=>'ID','order'=>'ASC','number'=>1,'fields'=>['ID']]);
            if ($siteAdmins) $crmAdminId = (int)$siteAdmins[0]->ID;
        }
        $sql = "SELECT c.id,c.created_at,c.updated_at,c.created_by,p.user_id AS support_admin_id,p.last_read_at,
                (SELECT COUNT(*) FROM $mt m WHERE m.conversation_id=c.id AND m.sender_id<>p.user_id AND (p.last_read_at IS NULL OR m.created_at>p.last_read_at)) AS unread_count,
                (SELECT m2.body FROM $mt m2 WHERE m2.conversation_id=c.id ORDER BY m2.id DESC LIMIT 1) AS last_body,
                (SELECT m3.created_at FROM $mt m3 WHERE m3.conversation_id=c.id ORDER BY m3.id DESC LIMIT 1) AS last_message_at
                FROM $ct c INNER JOIN $pt p ON p.conversation_id=c.id AND p.user_id=%d
                WHERE c.type='direct' AND c.title='AJR Support'
                ORDER BY COALESCE(last_message_at,c.updated_at) DESC LIMIT 300";
        $rows = $crmAdminId ? $wpdb->get_results($wpdb->prepare($sql,$crmAdminId)) : [];
        echo '<div class="wrap"><h1>AJR Support CRM</h1><p>This is a separate inbox for <strong>Chat with us</strong>. Team conversations remain in the AJR Chat workspace.</p>';
        if (isset($_GET['support_reply']) && $_GET['support_reply']==='sent') echo '<div class="notice notice-success is-dismissible"><p>Reply sent.</p></div>';
        echo '<style>.ajr-support-layout{display:grid;grid-template-columns:minmax(280px,34%) minmax(360px,1fr);gap:18px;margin-top:18px}.ajr-support-list,.ajr-support-thread{background:#fff;border:1px solid #dcdcde;padding:16px;border-radius:8px;min-width:0}.ajr-support-item{display:block;padding:12px;border-bottom:1px solid #eee;text-decoration:none;color:#1d2327}.ajr-support-item.active{background:#eef6ff;border-left:3px solid #2271b1}.ajr-support-unread{display:inline-block;background:#d63638;color:#fff;border-radius:12px;padding:1px 7px;font-size:11px}.ajr-support-message{padding:12px;margin:10px 0;border-radius:8px;background:#f6f7f7;overflow-wrap:anywhere}.ajr-support-message.admin{background:#eaf4ff}.ajr-support-message small{display:block;color:#646970;margin-bottom:5px}.ajr-support-thread textarea{width:100%;min-height:100px}.ajr-support-empty{padding:24px;color:#646970}@media(max-width:900px){.ajr-support-layout{grid-template-columns:1fr}}</style>';
        echo '<div class="ajr-support-layout"><section class="ajr-support-list"><h2>Support conversations</h2>';
        if (!$rows) echo '<p class="ajr-support-empty">No support conversations yet. Conversations started with “Chat with us” will appear here.</p>';
        foreach ((array)$rows as $r) {
            $customerId = (int)$wpdb->get_var($wpdb->prepare('SELECT user_id FROM '.$pt.' WHERE conversation_id=%d AND user_id<>%d ORDER BY id ASC LIMIT 1',(int)$r->id,(int)$r->support_admin_id));
            $customer = $customerId ? get_userdata($customerId) : false;
            $name = $customer ? $customer->display_name : 'Deleted user';
            $preview = $r->last_body ? wp_trim_words(wp_strip_all_tags($r->last_body), 12) : 'No messages yet';
            $active = $selected === (int)$r->id ? ' active' : '';
            echo '<a class="ajr-support-item'.$active.'" href="'.esc_url(add_query_arg(['page'=>'ajr-support-crm','conversation_id'=>(int)$r->id],admin_url('admin.php'))).'">';
            echo '<strong>'.esc_html($name).'</strong> ';
            if ((int)$r->unread_count > 0) echo '<span class="ajr-support-unread">'.(int)$r->unread_count.' unread</span>';
            echo '<br><span>'.esc_html($preview).'</span><br><small>'.esc_html($r->last_message_at ? mysql2date(get_option('date_format').' '.get_option('time_format'),$r->last_message_at) : mysql2date(get_option('date_format'),$r->created_at)).'</small></a>';
        }
        echo '</section><section class="ajr-support-thread">';
        if (!$selected) {
            echo '<div class="ajr-support-empty"><h2>Support inbox</h2><p>Select a conversation to read and reply. This CRM is separate from regular team chat.</p></div>';
        } else {
            $conversation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $ct WHERE id=%d AND type='direct' AND title='AJR Support'",$selected));
            if (!$conversation) {
                echo '<p>This support conversation could not be found.</p>';
            } else {
                $canReply = $this->is_support_participant($selected,$uid);
                if ($canReply) $wpdb->update($pt,['last_read_at'=>current_time('mysql')],['conversation_id'=>$selected,'user_id'=>$uid],['%s'],['%d','%d']);
                $customer = get_userdata((int)$conversation->created_by);
                if ($customer && user_can($customer, 'manage_options')) {
                    $members = $wpdb->get_col($wpdb->prepare('SELECT user_id FROM '.$pt.' WHERE conversation_id=%d ORDER BY id ASC',$selected));
                    foreach ((array)$members as $memberId) { $candidate = get_userdata((int)$memberId); if ($candidate && !user_can($candidate, 'manage_options')) { $customer = $candidate; break; } }
                }
                echo '<h2>'.esc_html($customer ? $customer->display_name : 'Support conversation').' <small>#'.(int)$selected.'</small></h2>';
                $metaTable = self::table('support_meta'); $notesTable = self::table('support_notes');
                $meta = $wpdb->get_row($wpdb->prepare("SELECT * FROM $metaTable WHERE conversation_id=%d", $selected));
                if (!$meta) { $wpdb->insert($metaTable, ['conversation_id'=>$selected,'status'=>'open','assigned_user_id'=>$crmAdminId ?: $uid,'updated_at'=>current_time('mysql')], ['%d','%s','%d','%s']); $meta = (object)['status'=>'open','assigned_user_id'=>$crmAdminId ?: $uid]; }
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0;padding:12px;background:#f6f7f7">';
                wp_nonce_field('ajr_chat_support_status_'.$selected);
                echo '<input type="hidden" name="action" value="ajr_chat_support_status"><input type="hidden" name="conversation_id" value="'.(int)$selected.'"><label>Status <select name="support_status">';
                foreach (['open'=>'Open','pending'=>'Pending','resolved'=>'Resolved'] as $st=>$label) echo '<option value="'.esc_attr($st).'"'.selected($meta->status,$st,false).'>'.esc_html($label).'</option>';
                echo '</select></label><label>Assigned to <select name="assigned_user_id">';
                $admins = get_users(['capability'=>'manage_options','orderby'=>'display_name','order'=>'ASC','fields'=>['ID','display_name'],'number'=>200]);
                foreach ($admins as $a) echo '<option value="'.(int)$a->ID.'"'.selected((int)$meta->assigned_user_id,(int)$a->ID,false).'>'.esc_html($a->display_name).'</option>';
                echo '</select></label><button class="button">Save ticket</button></form>';
                $notes = $wpdb->get_results($wpdb->prepare("SELECT * FROM $notesTable WHERE conversation_id=%d ORDER BY id DESC LIMIT 100",$selected));
                echo '<div style="border:1px solid #dcdcde;padding:12px;margin:12px 0"><h3>Internal notes (visible only in Support CRM)</h3>';
                if ($notes) foreach ($notes as $note) { $author=get_userdata((int)$note->author_id); echo '<p style="border-bottom:1px solid #eee;padding:6px 0"><strong>'.esc_html($author?$author->display_name:'Administrator').'</strong> <small>'.esc_html(mysql2date(get_option('date_format').' '.get_option('time_format'),$note->created_at)).'</small><br>'.nl2br(esc_html($note->note)).'</p>'; }
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('ajr_chat_support_note_'.$selected);
                echo '<input type="hidden" name="action" value="ajr_chat_support_note"><input type="hidden" name="conversation_id" value="'.(int)$selected.'"><textarea name="internal_note" maxlength="4000" placeholder="Add an internal note (not sent to customer)" style="width:100%;min-height:70px" required></textarea><p><button class="button">Add internal note</button></p></form></div>';
                $messages = $wpdb->get_results($wpdb->prepare("SELECT * FROM $mt WHERE conversation_id=%d ORDER BY id ASC LIMIT 500",$selected));
                echo '<div class="ajr-support-messages">';
                if (!$messages) echo '<p>No messages yet.</p>';
                foreach ((array)$messages as $m) {
                    $sender = get_userdata((int)$m->sender_id); $isAdmin = user_can((int)$m->sender_id,'manage_options');
                    echo '<article class="ajr-support-message'.($isAdmin?' admin':'').'">';
                    echo '<small><strong>'.esc_html($sender ? $sender->display_name : 'Deleted user').'</strong> · '.esc_html(mysql2date(get_option('date_format').' '.get_option('time_format'),$m->created_at)).'</small>';
                    if ($m->body !== '') echo '<div>'.nl2br(esc_html($m->body)).'</div>';
                    if (!empty($m->attachment_url)) echo '<p><a href="'.esc_url($m->attachment_url).'" target="_blank" rel="noopener">'.esc_html($m->attachment_name ?: 'Open attachment').'</a></p>';
                    echo '</article>';
                }
                echo '</div>';
                if ($canReply) {
                    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
                    wp_nonce_field('ajr_chat_support_reply_'.$selected);
                    echo '<input type="hidden" name="action" value="ajr_chat_support_reply"><input type="hidden" name="conversation_id" value="'.(int)$selected.'"><p><label for="ajr-support-reply"><strong>Reply to customer</strong></label><textarea id="ajr-support-reply" name="reply" maxlength="12000" required></textarea></p><p><button class="button button-primary">Send reply</button></p></form>';
                } else {
                    echo '<p class="notice notice-info inline"><strong>Read-only:</strong> this conversation is assigned to its support administrator. Only a participant administrator can reply from this CRM.</p>';
                }
            }
        }
        echo '</section></div></div>';
    }
    public function admin_support_status() {
        if (!$this->can_access_support_crm()) wp_die('You are not allowed to manage support tickets.');
        global $wpdb; $id=absint($_POST['conversation_id'] ?? 0); check_admin_referer('ajr_chat_support_status_'.$id);
        if (!$id || !$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::table('conversations')." WHERE id=%d AND type='direct' AND title='AJR Support'",$id))) wp_die('Invalid support conversation.');
        $status=sanitize_key((string)($_POST['support_status'] ?? 'open')); if (!in_array($status,['open','pending','resolved'],true)) $status='open';
        $assigned=absint($_POST['assigned_user_id'] ?? 0); if (!$assigned || !user_can($assigned,'manage_options')) $assigned=get_current_user_id();
        $table=self::table('support_meta'); $exists=$wpdb->get_var($wpdb->prepare("SELECT conversation_id FROM $table WHERE conversation_id=%d",$id));
        $data=['status'=>$status,'assigned_user_id'=>$assigned,'updated_at'=>current_time('mysql')];
        if ($exists) $wpdb->update($table,$data,['conversation_id'=>$id],['%s','%d','%s'],['%d']); else $wpdb->insert($table,['conversation_id'=>$id]+$data,['%d','%s','%d','%s']);
        wp_safe_redirect(add_query_arg(['page'=>'ajr-support-crm','conversation_id'=>$id,'ticket_saved'=>'1'],admin_url('admin.php'))); exit;
    }
    public function admin_support_note() {
        if (!$this->can_access_support_crm()) wp_die('You are not allowed to add support notes.');
        global $wpdb; $id=absint($_POST['conversation_id'] ?? 0); check_admin_referer('ajr_chat_support_note_'.$id);
        if (!$id || !$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::table('conversations')." WHERE id=%d AND type='direct' AND title='AJR Support'",$id))) wp_die('Invalid support conversation.');
        $note=trim(sanitize_textarea_field(wp_unslash((string)($_POST['internal_note'] ?? '')))); if ($note==='' || strlen($note)>4000) wp_die('Enter an internal note of 1–4000 characters.');
        $wpdb->insert(self::table('support_notes'),['conversation_id'=>$id,'author_id'=>get_current_user_id(),'note'=>$note,'created_at'=>current_time('mysql')],['%d','%d','%s','%s']);
        wp_safe_redirect(add_query_arg(['page'=>'ajr-support-crm','conversation_id'=>$id,'note_saved'=>'1'],admin_url('admin.php'))); exit;
    }
    public function admin_support_reply() {
        if (!$this->can_access_support_crm()) wp_die('You are not allowed to reply to support conversations.');
        global $wpdb;
        $id = absint($_POST['conversation_id'] ?? 0);
        check_admin_referer('ajr_chat_support_reply_'.$id);
        $uid = get_current_user_id();
        if (!$this->is_support_participant($id,$uid)) wp_die('This conversation is not assigned to your account.');
        $body = trim(sanitize_textarea_field(wp_unslash((string)($_POST['reply'] ?? ''))));
        if ($body === '' || strlen($body) > 12000) wp_die('Please enter a reply of 1–12000 characters.');
        $now = current_time('mysql');
        $mt = self::table('messages'); $ct = self::table('conversations');
        $ok = $wpdb->insert($mt,['conversation_id'=>$id,'sender_id'=>$uid,'body'=>$body,'attachment_url'=>'','attachment_name'=>'','attachment_mime'=>'','reply_to_id'=>null,'reactions'=>'{}','created_at'=>$now],['%d','%d','%s','%s','%s','%s','%d','%s','%s']);
        if (!$ok) wp_die('Could not save your reply. Please try again.');
        $messageId = (int)$wpdb->insert_id;
        $wpdb->update($ct,['last_message_id'=>$messageId,'updated_at'=>$now],['id'=>$id],['%d','%s'],['%d']);
        $wpdb->update(self::table('participants'),['last_read_at'=>$now],['conversation_id'=>$id,'user_id'=>$uid],['%s'],['%d','%d']);
        wp_safe_redirect(add_query_arg(['page'=>'ajr-support-crm','conversation_id'=>$id,'support_reply'=>'sent'],admin_url('admin.php'))); exit;
    }
    public function save_admin_settings() {
        if (!current_user_can('manage_options')) wp_die('You are not allowed to change these settings.');
        check_admin_referer('ajr_chat_save_admin');
        update_option('ajr_chat_public_registration', isset($_POST['public_registration']) ? 1 : 0);
        $retention = isset($_POST['retention_days']) ? absint($_POST['retention_days']) : 0;
        if (!in_array($retention, [0,30,90,180,365], true)) $retention = 0;
        update_option('ajr_chat_retention_days', $retention);
        wp_safe_redirect(add_query_arg(['page'=>'ajr-chat-admin','updated'=>'1'], admin_url('admin.php'))); exit;
    }
    public function admin_page() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>AJR Chat Settings</h1>';
        if (isset($_GET['updated'])) echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('ajr_chat_save_admin'); echo '<input type="hidden" name="action" value="ajr_chat_save_admin">';
        echo '<table class="form-table"><tr><th scope="row">Public registration</th><td><label><input type="checkbox" name="public_registration" value="1" ' . checked((int)get_option('ajr_chat_public_registration',1),1,false) . '> Allow visitors to create a new chat account</label><p class="description">Turn this off to disable new account registration through the AJR Chat login widget. Existing WordPress accounts can still sign in.</p></td></tr><tr><th scope="row">Message retention</th><td><select name="retention_days"><option value="0" ' . selected((int)get_option('ajr_chat_retention_days',0),0,false) . '>Keep messages indefinitely</option><option value="30" ' . selected((int)get_option('ajr_chat_retention_days',0),30,false) . '>30 days</option><option value="90" ' . selected((int)get_option('ajr_chat_retention_days',0),90,false) . '>90 days</option><option value="180" ' . selected((int)get_option('ajr_chat_retention_days',0),180,false) . '>180 days</option><option value="365" ' . selected((int)get_option('ajr_chat_retention_days',0),365,false) . '>365 days</option></select><p class="description">Daily cleanup removes older unpinned messages. Pinned messages are preserved. Choose carefully: deleted messages cannot be recovered.</p></td></tr></table>';
        submit_button('Save settings'); echo '</form><hr><p><a class="button" href="' . esc_url(admin_url('admin.php?page=ajr-chat-admin-reports')) . '">Review reported messages</a></p></div>';
    }
    public function admin_reports_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $table=self::table('reports'); $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY FIELD(status,'open','reviewed','dismissed'), created_at DESC LIMIT 200");
        echo '<div class="wrap"><h1>AJR Chat — Reported Messages</h1><p>Review reports submitted by chat participants. Deleting a message is permanent.</p>';
        if (isset($_GET['report_action_done'])) echo '<div class="notice notice-success is-dismissible"><p>Report updated.</p></div>';
        if (!$rows) { echo '<p>No reports have been submitted.</p></div>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>Reported message</th><th>Conversation</th><th>Reporter</th><th>Reason</th><th>Details</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $msg=$wpdb->get_row($wpdb->prepare('SELECT body,sender_id FROM '.self::table('messages').' WHERE id=%d',$r->message_id)); $sender=$msg?get_userdata((int)$msg->sender_id):false; $reporter=get_userdata((int)$r->reporter_id);
            echo '<tr><td>'.esc_html($msg ? wp_trim_words(wp_strip_all_tags($msg->body),22) : '[Message deleted]').'<br><small>Message #'.(int)$r->message_id.($sender?' · '.esc_html($sender->display_name):'').'</small></td><td>#'.(int)$r->conversation_id.'</td><td>'.esc_html($reporter?$reporter->display_name:'Deleted user').'</td><td>'.esc_html($r->reason).'</td><td>'.esc_html($r->details).'</td><td>'.esc_html($r->status).'</td><td><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            wp_nonce_field('ajr_chat_report_'.$r->id); echo '<input type="hidden" name="action" value="ajr_chat_report_action"><input type="hidden" name="report_id" value="'.(int)$r->id.'"><button class="button" name="report_action" value="reviewed">Mark reviewed</button> <button class="button" name="report_action" value="dismissed">Dismiss</button> ';
            if ($msg) echo '<button class="button button-link-delete" name="report_action" value="delete_message" onclick="return confirm(\'Permanently delete this message?\')">Delete message</button>';
            echo '</form></td></tr>';
        }
        echo '</tbody></table></div>';
    }
    public function admin_report_action() {
        if (!current_user_can('manage_options')) wp_die('You are not allowed to manage reports.');
        global $wpdb; $id=absint($_POST['report_id']??0); check_admin_referer('ajr_chat_report_'.$id);
        $table=self::table('reports'); $report=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id));
        if ($report) { $action=sanitize_key((string)($_POST['report_action']??'')); if ($action==='delete_message') $wpdb->delete(self::table('messages'),['id'=>(int)$report->message_id,'conversation_id'=>(int)$report->conversation_id],['%d','%d']); if (in_array($action,['reviewed','dismissed','delete_message'],true)) $wpdb->update($table,['status'=>$action==='delete_message'?'reviewed':$action],['id'=>$id],['%s'],['%d']); }
        wp_safe_redirect(add_query_arg(['page'=>'ajr-chat-admin-reports','report_action_done'=>'1'],admin_url('admin.php'))); exit;
    }
    public function get_profile($request) {
        $user = get_userdata($this->current_user());
        if (!$user) return new WP_Error('ajr_profile_user', 'User profile could not be found.', ['status'=>404]);
        $data = $this->user_data($user);
        $data['email'] = $user->user_email;
        return rest_ensure_response($data);
    }
    public function update_profile($request) {
        $uid = $this->current_user();
        $name = sanitize_text_field((string)$request->get_param('displayName'));
        if (mb_strlen($name) < 2 || mb_strlen($name) > 80) return new WP_Error('ajr_profile_name', 'Display name must be between 2 and 80 characters.', ['status'=>400]);
        $updated = wp_update_user(['ID'=>$uid, 'display_name'=>$name]);
        if (is_wp_error($updated)) return $updated;
        if ($request->get_param('jobTitle') !== null) {
            $title = mb_substr(sanitize_text_field((string)$request->get_param('jobTitle')), 0, 80);
            if ($title === '') delete_user_meta($uid, 'ajr_chat_job_title'); else update_user_meta($uid, 'ajr_chat_job_title', $title);
        }
        if ($request->get_param('about') !== null) {
            $about = mb_substr(sanitize_text_field((string)$request->get_param('about')), 0, 140);
            if ($about === '') delete_user_meta($uid, 'ajr_chat_about'); else update_user_meta($uid, 'ajr_chat_about', $about);
        }
        $avatar = esc_url_raw((string)$request->get_param('avatarUrl'));
        $uploads = wp_get_upload_dir();
        if ($avatar && wp_http_validate_url($avatar) && !empty($uploads['baseurl']) && strpos($avatar, trailingslashit($uploads['baseurl'])) === 0) update_user_meta($uid, 'ajr_chat_avatar_url', $avatar);
        elseif ($request->get_param('removeAvatar')) delete_user_meta($uid, 'ajr_chat_avatar_url');
        $profile = $this->user_data(get_userdata($uid));
        $profile['email'] = get_userdata($uid)->user_email;
        return rest_ensure_response(['profile'=>$profile]);
    }
    private function default_prefs() {
        return ['sound'=>true,'soundType'=>'chime','volume'=>70,'activeSound'=>false,'toasts'=>true,'desktop'=>true,'preview'=>true,'notifyDirect'=>true,'notifyGroup'=>true,'font'=>'inter','fontWeight'=>'400','messageAnimation'=>'default','size'=>'md','theme'=>'light','enterToSend'=>true,'bgStyle'=>'solid','bgColor'=>'#f3f5fa','bgGradient'=>'blue','bgGradientStart'=>'#eff6ff','bgGradientEnd'=>'#e0e7ff','bgGradientAngle'=>135,'bgGradientType'=>'linear','bgGradientStop1'=>0,'bgGradientStop2'=>100,'bgRadialExtent'=>'farthest-corner','bgImage'=>'','messageAnimationImage'=>'','messageAnimationSize'=>48,'accentColor'=>'#2563eb','myBubbleColor'=>'#2563eb','theirBubbleColor'=>'#ffffff','muted'=>[]];
    }
    private function clean_prefs($in) {
        $o = $this->default_prefs(); if (!is_array($in)) return $o;
        foreach (['sound','activeSound','toasts','desktop','preview','notifyDirect','notifyGroup','enterToSend'] as $k) if (isset($in[$k])) $o[$k] = rest_sanitize_boolean($in[$k]);
        $enums = ['soundType'=>['chime','pop','ding','bell','chirp','none'], 'font'=>['inter','system','nunito','poppins','serif','mono','roboto','opensans','lato','sourcesans','dmsans','worksans','montserrat','rubik','manrope','georgia','outfit','jakarta','spacegrotesk','urbanist','raleway','oswald','ubuntu','firasans','ibmplex','dmmono','playfair'], 'fontWeight'=>['300','400','500','600','700','800'], 'messageAnimation'=>['default','birds','dynamic','bars','custom'], 'size'=>['sm','md','lg'], 'theme'=>['light','dark','auto'], 'bgStyle'=>['solid','gradient','image'], 'bgGradient'=>['blue','sunset','mint','lavender','dark','ocean'], 'bgGradientType'=>['linear','radial'], 'bgRadialExtent'=>['closest-side','farthest-corner']];
        foreach ($enums as $k=>$allowed) if (isset($in[$k]) && in_array($in[$k], $allowed, true)) $o[$k] = $in[$k];
        if (isset($in['volume'])) $o['volume'] = max(0, min(100, (int)$in['volume']));
        foreach (['bgGradientStart'=>'#eff6ff','bgGradientEnd'=>'#e0e7ff'] as $k=>$fallback) { if (isset($in[$k])) { $v=sanitize_hex_color((string)$in[$k]); $o[$k]=$v ? $v : $fallback; } }
        if (isset($in['bgGradientAngle'])) $o['bgGradientAngle']=max(0,min(360,(int)$in['bgGradientAngle']));
        if (isset($in['bgGradientStop1'])) $o['bgGradientStop1']=max(0,min(100,(int)$in['bgGradientStop1']));
        if (isset($in['bgGradientStop2'])) $o['bgGradientStop2']=max($o['bgGradientStop1'],min(100,(int)$in['bgGradientStop2']));
        if (isset($in['messageAnimationSize'])) $o['messageAnimationSize']=max(16,min(160,(int)$in['messageAnimationSize']));
        foreach (['bgColor'=>'#f3f5fa','accentColor'=>'#2563eb','myBubbleColor'=>'#2563eb','theirBubbleColor'=>'#ffffff'] as $k=>$fallback) { if (isset($in[$k])) { $v=sanitize_hex_color((string)$in[$k]); $o[$k]=$v ? $v : $fallback; } }
        if (isset($in['bgImage'])) { $url=esc_url_raw((string)$in['bgImage'], ['http','https']); $o['bgImage']=strlen($url)<=1500 ? $url : ''; }
        if (isset($in['messageAnimationImage'])) { $url=esc_url_raw((string)$in['messageAnimationImage'], ['http','https']); $o['messageAnimationImage']=strlen($url)<=1500 ? $url : ''; }
        if (isset($in['muted']) && is_array($in['muted'])) $o['muted'] = array_slice(array_values(array_unique(array_filter(array_map('absint', $in['muted'])))), 0, 300);
        return $o;
    }
    private function get_prefs_array($uid) { $saved = get_user_meta($uid, 'ajr_chat_prefs', true); return $this->clean_prefs(is_array($saved) ? $saved : []); }
    public function get_prefs() { return rest_ensure_response(['prefs'=>$this->get_prefs_array($this->current_user())]); }
    public function save_prefs($request) {
        $prefs = $this->clean_prefs($request->get_param('prefs'));
        update_user_meta($this->current_user(), 'ajr_chat_prefs', $prefs);
        return rest_ensure_response(['prefs'=>$prefs]);
    }
    private function snippet($text, $q) {
        $text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)$text)));
        if ($text === '') return '';
        $pos = $q === '' ? false : mb_stripos($text, $q); if ($pos === false) $pos = 0;
        $start = max(0, $pos - 40);
        return ($start > 0 ? '…' : '') . mb_substr($text, $start, 140) . (mb_strlen($text) > $start + 140 ? '…' : '');
    }
    public function search_history($request) {
        global $wpdb;
        $q = mb_substr(sanitize_text_field((string)$request->get_param('q')), 0, 100);
        $conv = absint($request->get_param('conversation'));
        $filter = sanitize_key((string)$request->get_param('filter'));
        if (!in_array($filter, ['files','images','links','mine','theirs'], true)) $filter = '';
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$request->get_param('from')) ? (string)$request->get_param('from') : '';
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$request->get_param('to')) ? (string)$request->get_param('to') : '';
        // Global search needs 2+ characters. Inside one conversation, a filter or date range alone is enough.
        $scoped = $conv && ($filter || $from || $to);
        if (strlen($q) < 2 && !$scoped) return rest_ensure_response(['results'=>[]]);
        $uid = $this->current_user();
        if ($conv) { $allowed = $this->require_member($conv); if (is_wp_error($allowed)) return $allowed; }
        $mt = self::table('messages'); $pt = self::table('participants'); $ct = self::table('conversations');
        $where = ['p.user_id=%d']; $args = [$uid];
        if ($conv) { $where[] = 'm.conversation_id=%d'; $args[] = $conv; }
        if (strlen($q) >= 2) { $like = '%' . $wpdb->esc_like($q) . '%'; $where[] = '(m.body LIKE %s OR m.attachment_name LIKE %s)'; $args[] = $like; $args[] = $like; }
        if ($filter === 'files') $where[] = "(m.attachment_url IS NOT NULL AND m.attachment_url<>'')";
        if ($filter === 'images') { $where[] = 'm.attachment_mime LIKE %s'; $args[] = 'image/%'; }
        if ($filter === 'links') { $where[] = '(m.body LIKE %s OR m.body LIKE %s)'; $args[] = '%http://%'; $args[] = '%https://%'; }
        if ($filter === 'mine') { $where[] = 'm.sender_id=%d'; $args[] = $uid; }
        if ($filter === 'theirs') { $where[] = 'm.sender_id<>%d'; $args[] = $uid; }
        if ($from) { $where[] = 'm.created_at>=%s'; $args[] = $from . ' 00:00:00'; }
        if ($to) { $where[] = 'm.created_at<=%s'; $args[] = $to . ' 23:59:59'; }
        $limit = $conv ? 100 : 50;
        $sql = "SELECT m.id,m.conversation_id,m.sender_id,m.body,m.attachment_name,m.attachment_mime,m.created_at,c.type,c.title
             FROM $mt m INNER JOIN $pt p ON p.conversation_id=m.conversation_id
             INNER JOIN $ct c ON c.id=m.conversation_id
             WHERE " . implode(' AND ', $where) . " ORDER BY m.id DESC LIMIT $limit";
        $rows = $wpdb->get_results($wpdb->prepare($sql, $args));
        $results = []; $titles = [];
        foreach ((array)$rows as $r) {
            $sender = get_userdata((int)$r->sender_id);
            $cid = (int)$r->conversation_id;
            if (!isset($titles[$cid])) {
                $title = $r->title;
                if ($r->type !== 'group') {
                    $members = $wpdb->get_col($wpdb->prepare("SELECT user_id FROM $pt WHERE conversation_id=%d", $cid));
                    foreach ($members as $member_id) if ((int)$member_id !== $uid) { $u=get_userdata((int)$member_id); if($u){$title=$u->display_name;break;} }
                }
                $titles[$cid] = $title;
            }
            $results[] = ['id'=>(int)$r->id, 'conversationId'=>$cid, 'title'=>$titles[$cid],
                'sender'=>$sender ? $sender->display_name : 'Unknown', 'senderId'=>(int)$r->sender_id, 'body'=>$this->snippet($r->body, $q), 'attachmentName'=>(string)$r->attachment_name,
                'attachmentMime'=>(string)$r->attachment_mime, 'createdAt'=>mysql2date('c',$r->created_at,false)];
        }
        return rest_ensure_response(['results'=>$results]);
    }
    private function status_visible_to($status, $uid) {
        if (!$status || strtotime($status->expires_at) <= current_time('timestamp')) return false;
        if ((int)$status->user_id === (int)$uid) return true;
        $privacy = $status->privacy ?: 'contacts';
        $allowed = json_decode((string)$status->allowed_user_ids, true); if (!is_array($allowed)) $allowed=[];
        if ($privacy === 'selected') return in_array((int)$uid, array_map('intval',$allowed), true);
        if ($privacy === 'except') return !in_array((int)$uid, array_map('intval',$allowed), true);
        return true; // contacts = registered chat users, consistent with AJR Chat's existing contacts list.
    }
    private function status_payload($row, $uid) {
        global $wpdb;
        $user=get_userdata((int)$row->user_id); if(!$user) return null;
        $views=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('status_views').' WHERE status_id=%d',(int)$row->id));
        $viewers=[];
        if ((int)$row->user_id === (int)$uid) {
            $v=$wpdb->get_results($wpdb->prepare('SELECT sv.viewer_id,sv.viewed_at,u.display_name FROM '.self::table('status_views').' sv LEFT JOIN '.$wpdb->users.' u ON u.ID=sv.viewer_id WHERE sv.status_id=%d ORDER BY sv.viewed_at DESC',(int)$row->id));
            foreach($v as $x) $viewers[]=['id'=>(int)$x->viewer_id,'name'=>$x->display_name?:'User','viewedAt'=>$this->local_iso($x->viewed_at)];
        }
        $interactions=$wpdb->get_results($wpdb->prepare('SELECT interaction_type,content,user_id,created_at FROM '.self::table('status_interactions').' WHERE status_id=%d ORDER BY id ASC',(int)$row->id));
        $reactions=[];$replies=[]; foreach($interactions as $it){$u=get_userdata((int)$it->user_id); if($it->interaction_type==='reaction')$reactions[]=['userId'=>(int)$it->user_id,'name'=>$u?$u->display_name:'User','emoji'=>$it->content]; else $replies[]=['userId'=>(int)$it->user_id,'name'=>$u?$u->display_name:'User','text'=>$it->content,'createdAt'=>$this->local_iso($it->created_at)];}
        return ['id'=>(int)$row->id,'userId'=>(int)$row->user_id,'userName'=>$user->display_name,'avatar'=>get_avatar_url($user->ID,['size'=>96]),'type'=>$row->status_type,'text'=>$row->text_content,'mediaUrl'=>$row->media_url,'mediaMime'=>$row->media_mime,'background'=>$row->background,'createdAt'=>$this->local_iso($row->created_at),'expiresAt'=>$this->local_iso($row->expires_at),'viewCount'=>$views,'viewers'=>$viewers,'reactions'=>$reactions,'replies'=>$replies,'mine'=>(int)$row->user_id===(int)$uid];
    }
    public function list_statuses() {
        global $wpdb; $uid=$this->current_user(); $table=self::table('statuses'); $now=current_time('mysql');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE expires_at>%s ORDER BY created_at DESC LIMIT 500",$now)); $out=[];
        foreach($rows as $row) if($this->status_visible_to($row,$uid)) { $payload=$this->status_payload($row,$uid); if($payload)$out[]=$payload; }
        return rest_ensure_response(['statuses'=>$out]);
    }
    public function create_status($request) {
        global $wpdb; $uid=$this->current_user(); $text=sanitize_textarea_field((string)$request->get_param('text')); $background=sanitize_hex_color((string)$request->get_param('background')) ?: '#2563eb';
        $type='text';$media_url='';$mime='';
        if (isset($_FILES['media']) && is_array($_FILES['media']) && !empty($_FILES['media']['name'])) {
            $file=$_FILES['media'];
            if (!empty($file['error'])) {
                $upload_errors=[UPLOAD_ERR_INI_SIZE=>'The video or image exceeds the server upload_max_filesize limit.',UPLOAD_ERR_FORM_SIZE=>'The selected file is too large.',UPLOAD_ERR_PARTIAL=>'The upload was interrupted. Please try again.',UPLOAD_ERR_NO_FILE=>'Choose a photo or video first.',UPLOAD_ERR_NO_TMP_DIR=>'The server upload temporary folder is missing.',UPLOAD_ERR_CANT_WRITE=>'The server could not save the uploaded file.',UPLOAD_ERR_EXTENSION=>'A server extension stopped the upload.'];
                return new WP_Error('ajr_status_upload',$upload_errors[(int)$file['error']] ?? 'The media upload failed. Please try again.',['status'=>400]);
            }
            $max=min((int)wp_max_upload_size(), 100*1024*1024);
            if ((int)$file['size']>$max) return new WP_Error('ajr_status_size','This file is too large. Maximum allowed by WordPress/server is '.size_format($max).'.',['status'=>400]);
            $allowed=['jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp','mp4'=>'video/mp4','webm'=>'video/webm','mov'=>'video/quicktime'];
            $check=wp_check_filetype_and_ext($file['tmp_name'],$file['name'],$allowed);
            if (empty($check['type']) || !in_array($check['type'],$allowed,true)) return new WP_Error('ajr_status_type','Unsupported file type. Use JPG, PNG, GIF, WebP, MP4, WebM or MOV.',['status'=>400]);
            require_once ABSPATH.'wp-admin/includes/file.php';
            $uploaded=wp_handle_upload($file,['test_form'=>false,'mimes'=>$allowed]);
            if(isset($uploaded['error'])) return new WP_Error('ajr_status_upload','Upload failed: '.$uploaded['error'],['status'=>400]);
            if (empty($uploaded['url']) || empty($uploaded['type'])) return new WP_Error('ajr_status_upload','WordPress did not return a valid uploaded media file.',['status'=>500]);
            $media_url=esc_url_raw($uploaded['url']);$mime=sanitize_mime_type($uploaded['type']);$type=strpos($mime,'video/')===0?'video':'image';
        }
        if(!$text && !$media_url) return new WP_Error('ajr_status_empty','Add text or select a photo/video.',['status'=>400]);
        if(strlen($text)>500) return new WP_Error('ajr_status_text','Status text must be 500 characters or fewer.',['status'=>400]);
        $privacy=sanitize_key((string)$request->get_param('privacy')); if(!in_array($privacy,['contacts','except','selected'],true))$privacy='contacts';
        $allowed_ids=$request->get_param('allowedUserIds'); if(is_string($allowed_ids)){ $decoded=json_decode($allowed_ids,true); $allowed_ids=is_array($decoded)?$decoded:[]; } if(!is_array($allowed_ids))$allowed_ids=[]; $allowed_ids=array_values(array_unique(array_filter(array_map('absint',$allowed_ids),function($id)use($uid){return $id && $id!==$uid && get_userdata($id);}))); if(count($allowed_ids)>1000)return new WP_Error('ajr_status_privacy','Too many selected users.',['status'=>400]);
        if($privacy==='selected'&&!$allowed_ids)return new WP_Error('ajr_status_privacy','Select at least one person for this status.',['status'=>400]);
        $now=current_time('mysql');$expires=wp_date('Y-m-d H:i:s',time()+DAY_IN_SECONDS,wp_timezone());$table=self::table('statuses');
        $ok=$wpdb->insert($table,['user_id'=>$uid,'status_type'=>$type,'text_content'=>$text,'media_url'=>$media_url,'media_mime'=>$mime,'background'=>$background,'privacy'=>$privacy,'allowed_user_ids'=>wp_json_encode($allowed_ids),'created_at'=>$now,'expires_at'=>$expires],['%d','%s','%s','%s','%s','%s','%s','%s','%s','%s']);
        if(!$ok)return new WP_Error('ajr_status_db','Could not save status.',['status'=>500]);$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$wpdb->insert_id));return rest_ensure_response(['status'=>$this->status_payload($row,$uid)]);
    }
    public function view_status($request) {
        global $wpdb; $id=absint($request['id']);$uid=$this->current_user();$table=self::table('statuses');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id));
        if(!$row||!$this->status_visible_to($row,$uid))return new WP_Error('ajr_status_missing','This status is unavailable or you do not have permission to view it.',['status'=>404]);
        if((int)$row->user_id!==$uid)$wpdb->replace(self::table('status_views'),['status_id'=>$id,'viewer_id'=>$uid,'viewed_at'=>current_time('mysql')],['%d','%d','%s']);
        return rest_ensure_response(['status'=>$this->status_payload($row,$uid)]);
    }
    public function interact_status($request) {
        global $wpdb;$id=absint($request['id']);$uid=$this->current_user();$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table('statuses').' WHERE id=%d',$id));
        if(!$row||!$this->status_visible_to($row,$uid))return new WP_Error('ajr_status_missing','This status is unavailable.',['status'=>404]);
        if((int)$row->user_id===$uid)return new WP_Error('ajr_status_owner','You cannot reply to your own status.',['status'=>400]);
        $kind=sanitize_key((string)$request->get_param('type'));$content=(string)$request->get_param('content');
        if($kind==='reaction') { $allowed=['👍','❤️','😂','😮','😢','👏','🔥']; if(!in_array($content,$allowed,true))return new WP_Error('ajr_status_reaction','Invalid reaction.',['status'=>400]); }
        elseif($kind==='reply') { $content=sanitize_textarea_field($content);if(!$content||strlen($content)>1000)return new WP_Error('ajr_status_reply','Reply must be between 1 and 1000 characters.',['status'=>400]); }
        else return new WP_Error('ajr_status_interaction','Invalid status interaction.',['status'=>400]);
        $wpdb->insert(self::table('status_interactions'),['status_id'=>$id,'user_id'=>$uid,'interaction_type'=>$kind,'content'=>$content,'created_at'=>current_time('mysql')],['%d','%d','%s','%s','%s']);
        return rest_ensure_response(['ok'=>true]);
    }
    public function delete_status($request) {
        global $wpdb;$id=absint($request['id']);$uid=$this->current_user();$table=self::table('statuses');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id));
        if(!$row||(int)$row->user_id!==$uid)return new WP_Error('ajr_status_delete','You can only delete your own status.',['status'=>403]);
        $wpdb->delete($table,['id'=>$id],['%d']);$wpdb->delete(self::table('status_views'),['status_id'=>$id],['%d']);$wpdb->delete(self::table('status_interactions'),['status_id'=>$id],['%d']);return rest_ensure_response(['ok'=>true]);
    }
    public function cleanup_expired_statuses() {
        global $wpdb;$table=self::table('statuses');$ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM $table WHERE expires_at<=%s",current_time('mysql')));if(!$ids)return;
        $views=self::table('status_views');$interactions=self::table('status_interactions');foreach($ids as $id){$wpdb->delete($views,['status_id'=>(int)$id],['%d']);$wpdb->delete($interactions,['status_id'=>(int)$id],['%d']);}
        $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE expires_at<=%s",current_time('mysql')));
    }
    public function upload($request) {
        if (empty($_FILES['file']) || !is_array($_FILES['file'])) return new WP_Error('ajr_no_file','Choose a file first.',['status'=>400]);
        $file=$_FILES['file'];
        $upload_error = isset($file['error']) ? (int)$file['error'] : UPLOAD_ERR_NO_FILE;
        if ($upload_error !== UPLOAD_ERR_OK) {
            $errors = [UPLOAD_ERR_INI_SIZE=>'The file exceeds the server upload_max_filesize limit.',UPLOAD_ERR_FORM_SIZE=>'The file exceeds the form upload limit.',UPLOAD_ERR_PARTIAL=>'The upload was interrupted. Please try again.',UPLOAD_ERR_NO_FILE=>'Choose a file first.',UPLOAD_ERR_NO_TMP_DIR=>'The server upload temporary directory is missing.',UPLOAD_ERR_CANT_WRITE=>'The server could not save the uploaded file.',UPLOAD_ERR_EXTENSION=>'A server extension blocked this upload.'];
            return new WP_Error('ajr_upload_error', $errors[$upload_error] ?? 'The upload failed. Please try again.', ['status'=>400]);
        }
        $max=min((int)wp_max_upload_size(), 100*1024*1024);
        if ((int)$file['size'] > $max) return new WP_Error('ajr_file_size','File exceeds the current upload limit of '.size_format($max).'.',['status'=>400]);
        $allowed=['jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp','bmp'=>'image/bmp','mp4|m4v'=>'video/mp4','webm'=>'video/webm','mov'=>'video/quicktime','ogv'=>'video/ogg','avi'=>'video/x-msvideo','mkv'=>'video/x-matroska','mp3'=>'audio/mpeg','m4a'=>'audio/mp4','aac'=>'audio/aac','wav'=>'audio/wav','ogg|oga'=>'audio/ogg','flac'=>'audio/flac','pdf'=>'application/pdf','txt|log'=>'text/plain','csv'=>'text/csv','rtf'=>'application/rtf','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','xls'=>'application/vnd.ms-excel','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','ppt'=>'application/vnd.ms-powerpoint','pptx'=>'application/vnd.openxmlformats-officedocument.presentationml.presentation','odt'=>'application/vnd.oasis.opendocument.text','ods'=>'application/vnd.oasis.opendocument.spreadsheet','odp'=>'application/vnd.oasis.opendocument.presentation','zip'=>'application/zip','gz'=>'application/gzip','tar'=>'application/x-tar','7z'=>'application/x-7z-compressed','rar'=>'application/vnd.rar','json'=>'application/json','xml'=>'application/xml'];
        $check=wp_check_filetype_and_ext($file['tmp_name'],$file['name'],$allowed);
        if (empty($check['type']) || !in_array($check['type'],$allowed,true)) return new WP_Error('ajr_file_type','This file type is not allowed.',['status'=>400]);
        require_once ABSPATH.'wp-admin/includes/file.php';
        $uploaded=wp_handle_upload($file,['test_form'=>false,'mimes'=>$allowed]);
        if (isset($uploaded['error'])) return new WP_Error('ajr_upload',$uploaded['error'],['status'=>400]);
        return rest_ensure_response(['url'=>esc_url_raw($uploaded['url']),'name'=>sanitize_file_name(basename($uploaded['file'])),'mime'=>sanitize_text_field($uploaded['type'])]);
    }
}
register_activation_hook(__FILE__, ['AJR_Chat','activate']);
register_deactivation_hook(__FILE__, ['AJR_Chat','deactivate']);
AJR_Chat::instance();
