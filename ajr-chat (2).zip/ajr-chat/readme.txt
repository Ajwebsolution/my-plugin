AJR CHAT v2.6.0 UPDATE
======================
- NEW: Added a separate WordPress admin menu called Support CRM for customer conversations started through “Chat with us”; regular team chat stays in the existing AJR Chat workspace.
- NEW: Support CRM lists customer conversations, latest-message previews, timestamps, and unread counts for the assigned support administrator.
- NEW: Assigned support administrators can read and reply from the CRM; replies are saved to the same conversation and appear in the customer's existing chat.
- SECURITY: CRM access is restricted to site administrators on single-site WordPress and super administrators on Multisite; reply actions require a nonce and require the current administrator to be a participant in that support conversation.
- PRESERVED: Existing chat, team conversations, attachments, statuses, preferences, moderation, reports, and retention features.

AJR CHAT v2.5.0 UPDATE
======================
- NEW: The public chat launcher offers two separate destinations: “Chat with us” opens a private direct conversation with the site's super administrator (multisite) or first available site administrator; “Chat with team” opens the existing AJR Chat workspace.
- NEW: If a visitor is not signed in, their selected destination is preserved through sign-in/registration.
- NEW: Added a permission-checked REST endpoint to find/create the current user's support conversation. It never lets the visitor choose an arbitrary administrator.
- PRESERVED: Existing direct/group chats, search, attachments, forwarding, reactions, pins, statuses, appearance settings, notifications, moderation, and retention.

AJR CHAT v2.4.0 UPDATE
======================
- NEW: Sign out. Available in the chat sidebar (door icon), in Profile & settings > Account & security, and in the floating website widget when signed in. Ends the WordPress session, clears the "online" presence marker, and returns to the site home page.
- NEW: Forgot password. The floating sign-in widget now has "Forgot your password?", which emails the standard WordPress reset link. The reply is identical whether or not the email exists (no account probing), and requests are rate limited (5 per IP / 3 per email per 15 minutes).
- NEW: Signed-in users can request a reset link for their own account from Profile & settings (limited to 3 per hour).
- FIXED: The "jump to latest message" arrow threw a JavaScript error when clicked (undefined variable).
- FIXED: Plugin header and internal version constant were out of sync (2.3.4 vs 2.3.2); both are now 2.4.0 so database upgrades run correctly.
- All existing features (chat, groups, search, status, forwarding, attachments, reactions, pins, reports, retention, appearance and notification settings) are unchanged.

AJR CHAT v2.3.1 UPDATE
======================
- Fixed live synchronisation for edited and deleted messages without refreshing the browser.
- Active chats reconcile the latest 50 server messages during polling, updating changed message content and removing messages no longer present in that recent window.
- Preserves the current scroll position unless the user is already near the bottom.

AJR Chat — WordPress Plugin v2.3.1
=================================

NEW IN 2.2.0 — WHATSAPP-STYLE STATUS
- Added a Status tab in the chat workspace.
- Create text statuses, image statuses, video statuses, or text with media.
- Statuses expire after 24 hours; an existing daily scheduled cleanup removes expired status records, views, and interactions.
- Default privacy is My contacts (the existing AJR Chat contact directory is WordPress users available in the chat).
- Optional Only selected people and My contacts except selected people visibility.
- Status visibility is checked server-side on list and view requests.
- Status owners can see viewer names and recorded view timestamps.
- Status viewers can send supported emoji reactions and text replies.
- Owners can delete their own statuses.
- Media uploads are type-checked and limited to 50 MB or the server's configured upload maximum, whichever is lower.
- Database migration creates status, status-view, and status-interaction tables using WordPress dbDelta on activation or version upgrade.

IMPORTANT
- Back up the database and test on a staging site before production deployment.
- WordPress scheduled tasks (WP-Cron) are traffic-driven unless the site has a real system cron configured.
- Privacy choices are enforced by the server. “My contacts” uses the same contact population as the current AJR Chat directory.
- This package has been syntax/archive checked; full live WordPress, media playback, multi-user, and privacy integration testing still needs to be completed on the target site.

Existing AJR Chat chat, search, messaging, preferences, appearance and moderation files are retained in this package.

2.2.1: Improved status upload validation and visible upload feedback; reports server upload limits and PHP upload errors instead of failing silently.

= 2.3.4 =
* Added a Forward message action for forwarding text and attachment messages to another existing conversation.
* Expanded safe attachment support for common video, audio, image, document, spreadsheet, presentation, archive, and text formats.
* Added inline video/audio playback where supported by the browser, with download/open links for other files.
* Uploads remain subject to WordPress/PHP server upload limits and the plugin 100 MB cap. Executable files are intentionally not allowed.

AJR Chat 2.7.8 — Voice calling preview
- Adds authenticated REST signalling endpoints for one-to-one voice calls.
- Adds a voice-call control in direct conversation headers.
- Uses browser WebRTC audio and Google public STUN for initial connectivity.
- Requires HTTPS and microphone permission. Networks requiring TURN relay may not connect until a TURN server is configured in the WebRTC ICE server list.
- Voice calling is a preview feature and must be tested between two accounts on the target site before production use. Group calls and video calls are not included.
