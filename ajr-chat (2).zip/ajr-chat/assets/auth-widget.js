(function(){
'use strict';
const cfg=window.AJRChatAuth, root=document.getElementById('ajr-chat-floating');
if(!cfg||!root)return;
const panel=document.getElementById('ac-float-panel'), content=document.getElementById('ac-float-content');
let chosenChat='team';
function chatHref(kind){return cfg.chatUrl+(kind==='support'?'?ajr_chat_support=1':'');}
function choiceMarkup(){return '<div class="ac-chat-choices" aria-label="Choose chat destination"><button type="button" data-chat-choice="support" class="'+(chosenChat==='support'?'selected':'')+'"><strong>Chat with us</strong><small>Private chat with the site administrator</small></button><button type="button" data-chat-choice="team" class="'+(chosenChat==='team'?'selected':'')+'"><strong>Chat with team</strong><small>Open your existing team workspace</small></button></div>';}
function bindChoices(){content.querySelectorAll('[data-chat-choice]').forEach(function(b){b.onclick=function(){chosenChat=b.dataset.chatChoice;content.querySelectorAll('[data-chat-choice]').forEach(function(x){x.classList.toggle('selected',x===b);});};});}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function arrow(label){return label+' <span>→</span>';}
async function post(fields){
 const fd=new FormData();fd.append('action','ajr_chat_auth');fd.append('nonce',cfg.nonce);
 Object.keys(fields).forEach(k=>fd.append(k,fields[k]));
 const r=await fetch(cfg.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd});
 let data;try{data=await r.json();}catch(e){throw new Error('Unexpected server response. Please try again.');}
 if(!data.success)throw new Error(data.data&&data.data.message?data.data.message:'Request failed.');
 return data.data||{};
}
function renderWelcome(){
 content.innerHTML='<div class="ac-float-welcome"><div class="ac-float-avatar">'+esc((cfg.userName||'U').trim().charAt(0).toUpperCase())+'</div><h3>Welcome, '+esc(cfg.userName||'there')+'</h3><p>Choose how you would like to chat.</p>'+choiceMarkup()+'<a class="ac-float-submit" id="ac-open-selected-chat" href="'+esc(chatHref(chosenChat))+'">'+(chosenChat==='support'?'Chat with us':'Chat with team')+' <span>→</span></a><button type="button" class="ac-float-logout" id="ac-float-logout">Sign out</button><div class="ac-auth-error" id="ac-logout-error" role="alert"></div></div>';
 bindChoices();
 content.querySelectorAll('[data-chat-choice]').forEach(function(b){b.addEventListener('click',function(){var a=content.querySelector('#ac-open-selected-chat');if(a){a.href=chatHref(chosenChat);a.textContent=(chosenChat==='support'?'Chat with us':'Chat with team')+' →';}});});
 const btn=content.querySelector('#ac-float-logout'),err=content.querySelector('#ac-logout-error');
 btn.onclick=async()=>{err.textContent='';btn.disabled=true;btn.textContent='Signing out…';
  try{const d=await post({mode:'logout'});if(d.nonce)cfg.nonce=d.nonce;cfg.loggedIn=false;cfg.userName='';render('login','You have been signed out.');}
  catch(e){err.textContent=e.message||'Could not sign out.';btn.disabled=false;btn.textContent='Sign out';}};
}
function renderForgot(prefill){
 content.innerHTML='<p class="ac-auth-intro">Enter the email address of your account and we will send you a link to reset your password.</p><form id="ac-forgot-form"><label>Email address<input type="email" name="email" autocomplete="email" required maxlength="190" placeholder="you@example.com" value="'+esc(prefill||'')+'"></label><div class="ac-auth-error" id="ac-auth-error" role="alert"></div><div class="ac-auth-success" id="ac-auth-success" role="status"></div><button type="submit" class="ac-float-submit" id="ac-forgot-submit">'+arrow('Send reset link')+'</button></form><button type="button" class="ac-auth-link" id="ac-back-login">← Back to sign in</button>';
 const form=content.querySelector('#ac-forgot-form'),err=content.querySelector('#ac-auth-error'),ok=content.querySelector('#ac-auth-success');
 content.querySelector('#ac-back-login').onclick=()=>render('login');
 form.onsubmit=async e=>{e.preventDefault();err.textContent='';ok.textContent='';const btn=form.querySelector('button[type="submit"]');btn.disabled=true;btn.textContent='Please wait…';
  try{const d=await post({mode:'forgot',email:form.elements.email.value.trim()});ok.textContent=d.message||'If an account exists, a reset link has been sent.';}
  catch(ex){err.textContent=ex.message||'Something went wrong.';}
  finally{btn.disabled=false;btn.innerHTML=arrow('Send reset link');}};
}
function render(view,notice){
 if(cfg.loggedIn){renderWelcome();return;}
 if(view==='forgot'){renderForgot();return;}
 content.innerHTML=choiceMarkup()+'<div class="ac-auth-tabs"><button type="button" data-mode="login" class="active">Sign in</button><button type="button" data-mode="register">Create account</button></div><p class="ac-auth-intro" id="ac-auth-intro">Sign in with your email and password to message registered users.</p><form id="ac-auth-form"><label>Email address<input type="email" name="email" autocomplete="email" required maxlength="190" placeholder="you@example.com"></label><label>Password<input type="password" name="password" autocomplete="current-password" required minlength="8" maxlength="128" placeholder="At least 8 characters"></label><div class="ac-auth-error" id="ac-auth-error" role="alert"></div><div class="ac-auth-success" id="ac-auth-success" role="status">'+esc(notice||'')+'</div><button type="submit" class="ac-float-submit" id="ac-auth-submit">'+arrow('Sign in')+'</button></form><button type="button" class="ac-auth-link" id="ac-forgot-link">Forgot your password?</button><p class="ac-auth-privacy">Your account is created on this website. Use a unique password.</p>';
 const tabs=content.querySelectorAll('[data-mode]'),form=content.querySelector('#ac-auth-form'),forgot=content.querySelector('#ac-forgot-link');
 bindChoices();
 form.dataset.mode='login';
 tabs.forEach(b=>b.onclick=()=>{tabs.forEach(x=>x.classList.toggle('active',x===b));const mode=b.dataset.mode;form.dataset.mode=mode;form.querySelector('input[name="password"]').autocomplete=mode==='register'?'new-password':'current-password';content.querySelector('#ac-auth-intro').textContent=mode==='register'?'Create an account with your email and a password of at least 8 characters.':'Sign in with your email and password to message registered users.';content.querySelector('#ac-auth-submit').innerHTML=arrow(mode==='register'?'Create account':'Sign in');content.querySelector('#ac-auth-error').textContent='';content.querySelector('#ac-auth-success').textContent='';forgot.hidden=mode==='register';});
 forgot.onclick=()=>{renderForgot(form.elements.email.value.trim());};
 form.onsubmit=async e=>{e.preventDefault();const btn=form.querySelector('button[type="submit"]'),error=content.querySelector('#ac-auth-error'),ok=content.querySelector('#ac-auth-success');error.textContent='';ok.textContent='';btn.disabled=true;btn.textContent='Please wait…';
  try{const d=await post({mode:form.dataset.mode||'login',email:form.elements.email.value,password:form.elements.password.value});
   if(d.redirect){window.location.href=chatHref(chosenChat);return;}
   error.textContent=d.message?d.message:'Please sign in.';}
  catch(err){error.textContent=err.message||'Something went wrong.';}
  finally{btn.disabled=false;btn.innerHTML=arrow(form.dataset.mode==='register'?'Create account':'Sign in');}};
}
document.getElementById('ac-float-open').addEventListener('click',()=>{panel.hidden=!panel.hidden;if(!panel.hidden)render();});
document.getElementById('ac-float-close').addEventListener('click',()=>{panel.hidden=true;});
document.addEventListener('keydown',e=>{if(e.key==='Escape')panel.hidden=true;});
})();
