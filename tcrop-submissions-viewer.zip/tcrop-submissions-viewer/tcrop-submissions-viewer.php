<?php
/*
Plugin Name: Elementor Form Meta Exporter (Advanced Filters)
Description: Display & export Elementor Pro form submissions with name, month & date range filters.
Version: 1.7
Author: Amit Chauhan
*/

if (!defined('ABSPATH')) exit;

class Elementor_Meta_Form_Exporter {

    private $table_submissions;
    private $table_values;

    private $form_fields = [
        'name' => 'Your Name',
        'email' => 'Your Email',
        'field_ddad479' => 'Contact Number',
        'field_ebdb6cd' => 'Location postcode',
        'field_8d26bdc' => 'Property Type',
        'field_d12174c' => 'How did you hear about us',
        'message' => 'Additional Details',
        'field_af869bd' => 'Do you have any detailed photographs?',
        'field_507aeeb' => 'Have you had an asbestos report carried out?',
    ];

    public function __construct() {
        global $wpdb;
        $this->table_submissions = $wpdb->prefix . 'e_submissions';
        $this->table_values      = $wpdb->prefix . 'e_submissions_values';

        add_action('admin_menu', [$this, 'add_admin_page']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function add_admin_page() {
        add_menu_page(
            'Elementor Submissions',
            'Form Submissions',
            'manage_options',
            'elementor-form-submissions',
            [$this, 'render_admin_page'],
            'dashicons-feedback',
            30
        );
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_elementor-form-submissions') return;

        wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
        wp_enqueue_style('datatables-buttons-css', 'https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css');
        wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css');

        wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['jquery'], null, true);
        wp_enqueue_script('datatables-buttons', 'https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js', ['datatables-js'], null, true);
        wp_enqueue_script('buttons-html5', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js', ['datatables-buttons'], null, true);
        wp_enqueue_script('buttons-print', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js', ['datatables-buttons'], null, true);
        wp_enqueue_script('jquery-ui-datepicker');

        wp_add_inline_script('datatables-js', "
        jQuery(document).ready(function($){

            $('#date-from, #date-to').datepicker({
                dateFormat: 'yy-mm-dd'
            });

            $.fn.dataTable.ext.search.push(function(settings, data) {
                var min = $('#date-from').val();
                var max = $('#date-to').val();
                var createdAt = data[2].substring(0,10);

                if (
                    (min === '' && max === '') ||
                    (min === '' && createdAt <= max) ||
                    (max === '' && createdAt >= min) ||
                    (createdAt >= min && createdAt <= max)
                ) {
                    return true;
                }
                return false;
            });

            var table = $('#elementor-submissions').DataTable({
                dom: 'Bfrtip',
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                pageLength: 50,
                order: [[0, 'desc']]
            });

            $('#filter-name').on('keyup', function () {
                table.column(3).search(this.value).draw();
            });

            $('#filter-month').on('change', function () {
                table.column(2).search(this.value).draw();
            });

            $('#date-from, #date-to').on('change', function () {
                table.draw();
            });

            $('#clear-filters').on('click', function(){
                $('#filter-name').val('');
                $('#filter-month').val('');
                $('#date-from').val('');
                $('#date-to').val('');
                table.search('').columns().search('').draw();
            });

        });
        ");
    }

    public function render_admin_page() {
        global $wpdb;

        $submissions = $wpdb->get_results("SELECT * FROM {$this->table_submissions} ORDER BY id DESC");
        $values = $wpdb->get_results("SELECT * FROM {$this->table_values}");

        $submission_values = [];
        foreach ($values as $val) {
            $submission_values[$val->submission_id][$val->key] = $val->value;
        }
        ?>

        <div class="wrap">
            <h1>Elementor Form Submissions</h1>

            <!-- FILTERS -->
            <div style="margin:15px 0; display:flex; gap:12px; flex-wrap:wrap;">
                <input type="text" id="filter-name" placeholder="Filter by Name" class="regular-text">

                <select id="filter-month">
                    <option value="">All Months</option>
                    <option value="-01-">January</option>
                    <option value="-02-">February</option>
                    <option value="-03-">March</option>
                    <option value="-04-">April</option>
                    <option value="-05-">May</option>
                    <option value="-06-">June</option>
                    <option value="-07-">July</option>
                    <option value="-08-">August</option>
                    <option value="-09-">September</option>
                    <option value="-10-">October</option>
                    <option value="-11-">November</option>
                    <option value="-12-">December</option>
                </select>

                <input type="text" id="date-from" placeholder="From date">
                <input type="text" id="date-to" placeholder="To date">

                <button class="button" id="clear-filters">Clear Filters</button>
            </div>

            <table id="elementor-submissions" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Submission ID</th>
                        <th>Form Name</th>
                        <th>Created At</th>
                        <?php foreach ($this->form_fields as $label): ?>
                            <th><?php echo esc_html($label); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $sub): ?>
                        <tr>
                            <td><?php echo esc_html($sub->id); ?></td>
                            <td><?php echo esc_html($sub->form_name); ?></td>
                            <td><?php echo esc_html($sub->created_at); ?></td>

                            <?php foreach ($this->form_fields as $key => $label): ?>
                                <td><?php echo esc_html($submission_values[$sub->id][$key] ?? ''); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php
    }
}

new Elementor_Meta_Form_Exporter();
