<?php

/*

Plugin Name: Elementor Form Meta Exporter (Stylish with Image Preview + Filters)

Description: Display & export all Elementor Pro form submissions with thumbnails, date filters, and sorting.

Version: 2.0

Author: Amit Chauhan

*/



if (!defined('ABSPATH'))

    exit;



class Elementor_Meta_Form_Exporter
{



    private $table_submissions;

    private $table_values;



    public function __construct()
    {

        global $wpdb;

        $this->table_submissions = $wpdb->prefix . 'e_submissions';

        $this->table_values = $wpdb->prefix . 'e_submissions_values';



        add_action('admin_menu', [$this, 'add_admin_page']);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);

    }



    public function add_admin_page()
    {

        add_menu_page(

            'Elementor Submissions',

            'Form Submissions',

            'manage_options',

            'elementor-form-submissions',

            [$this, 'render_admin_page'],

            'dashicons-feedback',

            30

        );

    }



    public function enqueue_assets($hook)
    {

        if ($hook !== 'toplevel_page_elementor-form-submissions')

            return;



        // DataTables

        wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');

        wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['jquery'], null, true);



        wp_enqueue_style('datatables-buttons-css', 'https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css');

        wp_enqueue_script('datatables-buttons', 'https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js', ['datatables-js'], null, true);

        wp_enqueue_script('buttons-html5', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js', ['datatables-buttons'], null, true);

        wp_enqueue_script('buttons-print', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js', ['datatables-buttons'], null, true);



        // jQuery UI Datepicker

        wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css');

        wp_enqueue_script('jquery-ui-datepicker');



        // Styles

        wp_add_inline_style('datatables-css', "

            .filter-bar {

                display: flex;

                gap: 15px;

                padding: 15px;

                background: #fff;

                border: 1px solid #ccd0d4;

                margin-bottom: 15px;

                align-items: center;

            }

            #elementor-submissions_filter {

             margin-bottom: 12px;

    

                }

                th.sorting {

    text-transform: capitalize;

}

            .filter-bar label {

                font-weight: 600;

            }

            .filter-bar select,

            .filter-bar input {

                padding: 5px 8px;

            }

            table.dataTable thead th {

                background: #1d2327;

                color: #fff;

            }

            table.dataTable tbody tr:hover {

                background: #eef5ff;

            }

            .dataTables_wrapper {

    overflow-x: auto;

}



table.dataTable {

    table-layout: auto !important;

    width: max-content !important;

    min-width: 100%;

}



table.dataTable th,

table.dataTable td {

    white-space: normal !important;

    word-break: break-word;

    vertical-align: top;

}



            table.dataTable img {

                width: 50px;

                border-radius: 4px;

                border: 1px solid #ddd;

            }

        ");



        // JS Filters + Sorting

        wp_add_inline_script('datatables-js', "

        jQuery(document).ready(function($){



            $('#from_date, #to_date').datepicker({ dateFormat: 'yy-mm-dd' });



            var table = $('#elementor-submissions').DataTable({

               destroy: true,

    dom: 'Bfrtip',

    buttons: ['copy','csv','excel','print'],

      pageLength: 10,              // 👈 first page = 10 rows
    lengthMenu: [10,25,50,100],  // 👈 user can change

    autoWidth: true,

    order: [[3,'desc']]

            });



            // Month / Year Filter

            $.fn.dataTable.ext.search.push(function(settings, data){

                var month = $('#filter-month').val();

                var year  = $('#filter-year').val();

                var date  = data[3]; // Created At

                if (!date) return true;



                var d = new Date(date);

                if (month && d.getMonth() + 1 != month) return false;

                if (year && d.getFullYear() != year) return false;

                return true;

            });



            // Date Range Filter

            $.fn.dataTable.ext.search.push(function(settings, data){

                var min = $('#from_date').val();

                var max = $('#to_date').val();

                var date = data[3];



                if (!date) return true;

                var d = new Date(date);



                if (min && d < new Date(min)) return false;

                if (max && d > new Date(max)) return false;

                return true;

            });



            $('#filter-month, #filter-year, #from_date, #to_date').on('change', function(){

                table.draw();

            });



        });

        ");

    }



    private function get_form_field_labels($form_id)
    {

        $labels = [];

        $data = get_post_meta($form_id, '_elementor_data', true);

        if (!$data)

            return $labels;



        $elements = is_string($data) ? json_decode($data, true) : $data;

        if (!is_array($elements))

            return $labels;



        $walk = function ($elements) use (&$walk, &$labels) {

            foreach ($elements as $el) {

                if (!empty($el['elements']))

                    $walk($el['elements']);

                if (($el['widgetType'] ?? '') === 'form') {

                    foreach ($el['settings']['form_fields'] ?? [] as $f) {

                        $id = $f['field_id'] ?? $f['custom_id'] ?? '';

                        if ($id)

                            $labels[$id] = $f['field_label'];

                    }

                }

            }

        };

        $walk($elements);

        return $labels;

    }



    public function render_admin_page()
    {

        global $wpdb;



        $submissions = $wpdb->get_results("SELECT * FROM {$this->table_submissions} ORDER BY id DESC");

        $values = $wpdb->get_results("SELECT * FROM {$this->table_values}");



        $all_keys = array_unique(array_column($values, 'key'));



        $submission_values = [];

        foreach ($values as $v) {

            $submission_values[$v->submission_id][$v->key] = $v->value;

        }
  /* 🔹 BUILD GLOBAL FIELD LABEL MAP */
      $field_labels = [];
$processed_posts = [];

foreach ($submissions as $s) {
    if (!empty($s->post_id) && !isset($processed_posts[$s->post_id])) {
        $processed_posts[$s->post_id] = true;
        $field_labels = array_merge(
            $field_labels,
            $this->get_form_field_labels($s->post_id)
        );
    }
}

        ?>



        <div class="wrap">

            <h1>Elementor Form Submissions</h1>



            <!-- Filters -->

            <div class="filter-bar">

                <label>Month:</label>

                <select id="filter-month">

                    <option value="">All</option>

                    <?php for ($m = 1; $m <= 12; $m++): ?>

                        <option value="<?= $m ?>"><?= date('F', mktime(0, 0, 0, $m, 1)) ?></option>

                    <?php endfor; ?>

                </select>



                <label>Year:</label>

                <select id="filter-year">

                    <option value="">All</option>

                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>

                        <option value="<?= $y ?>"><?= $y ?></option>

                    <?php endfor; ?>

                </select>



                <label>From:</label>

                <input type="text" id="from_date" placeholder="YYYY-MM-DD">



                <label>To:</label>

                <input type="text" id="to_date" placeholder="YYYY-MM-DD">

            </div>



            <table id="elementor-submissions" class="display" style="width:100%">

                <thead>

                    <tr>

                        <!--<th>ID</th>-->

                        <th>Sr No</th>



                        <th>Form Name</th>

                        <th>Page Name</th>

                        <th>Date</th>

                        <?php foreach ($all_keys as $k): ?>

                             <th>
        <?= esc_html($field_labels[$k] ?? ucwords(str_replace('_', ' ', $k))) ?>
    </th>

                        <?php endforeach; ?>

                    </tr>

                </thead>

                <tbody>

                    <?php $sr_no = 1;
                    foreach ($submissions as $s): ?>



                        <tr>

                            <!--<td><?= esc_html($s->id) ?></td>-->

                            <td><?= esc_html($sr_no++) ?></td>



                            <td><?= esc_html($s->form_name) ?></td>

                            <td>

                                <?php

                                if ($s->post_id) {

                                    $title = get_the_title($s->post_id);

                                    $link = get_permalink($s->post_id);



                                    if ($link) {

                                        echo '<a href="' . esc_url($link) . '" target="_blank" rel="noopener noreferrer">'

                                            . esc_html($title) .

                                            '</a>';

                                    } else {

                                        echo esc_html($title);

                                    }

                                } else {

                                    echo '�';

                                }

                                ?>

                            </td>



                            <td><?= esc_html($s->created_at) ?></td>

                            <?php foreach ($all_keys as $k):

                                $val = $submission_values[$s->id][$k] ?? '';


                                $val = $submission_values[$s->id][$k] ?? '';

                                $file_urls = [];

                                /**
                                 * 1️⃣ Handle attachment ID
                                 */
                                if (is_numeric($val)) {
                                    $url = wp_get_attachment_url($val);
                                    if ($url) {
                                        $file_urls[] = $url;
                                    }
                                }

                                /**
                                 * 2️⃣ Handle JSON / serialized array
                                 */ elseif (is_string($val) && (str_starts_with($val, '[') || str_starts_with($val, '{'))) {
                                    $decoded = json_decode($val, true);
                                    if (is_array($decoded)) {
                                        foreach ($decoded as $item) {
                                            if (!empty($item['url'])) {
                                                $file_urls[] = $item['url'];
                                            }
                                        }
                                    }
                                }

                                /**
                                 * 3️⃣ Handle direct URL
                                 */ elseif (filter_var($val, FILTER_VALIDATE_URL)) {
                                    $file_urls[] = $val;
                                }

                                /**
                                 * OUTPUT
                                 */
                        if (!empty($file_urls)) {

    $image_files = [];
    $doc_files   = [];

    foreach ($file_urls as $file) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $image_files[] = $file;
        } else {
            $doc_files[] = [
                'url' => $file,
                'ext' => strtoupper($ext)
            ];
        }
    }

    echo '<td data-export="' . esc_attr(implode(', ', $file_urls)) . '">';

    // 🔹 IMAGE PREVIEW
    if (!empty($image_files)) {
        echo '<div class="efme-gallery">';
        foreach ($image_files as $img) {
            echo '<a href="'.esc_url($img).'" target="_blank">
                    <img src="'.esc_url($img).'" />
                  </a>';
        }
        echo '</div>';
    }

    // 🔹 DOCUMENT FILES
    foreach ($doc_files as $doc) {
        echo '<div class="efme-doc-file">
                <span class="efme-file-ext">'.$doc['ext'].'</span>
                <a href="'.esc_url($doc['url']).'" download class="button button-small">Download</a>
              </div>';
    }

    // 🔹 CSV EXPORT VALUE
    echo '<span class="efme-export-url" style="display:none;">'
        . esc_html(implode(', ', $file_urls)) .
        '</span>';

    echo '</td>';

} else {
    echo '<td>' . esc_html($val) . '</td>';
}





                            endforeach; ?>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

        <?php

    }

}



new Elementor_Meta_Form_Exporter();