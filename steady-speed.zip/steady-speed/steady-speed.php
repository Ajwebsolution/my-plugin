<?php
/**
 * Plugin Name:       Steady Speed
 * Description:       Stability-first performance engine: smart incremental page cache, dependency-aware CSS/JS optimization, Critical CSS, unused CSS removal, third-party delay, LCP/image/font optimization, Elementor/slider/header protection, automatic error fallback and a performance report.
 * Version:           1.2.8
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Steady Speed
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       steady-speed
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

define( 'WPSS_VERSION', '1.2.9' );
define( 'WPSS_DB_VERSION', '2' );
define( 'WPSS_FILE', __FILE__ );
define( 'WPSS_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPSS_URL', plugin_dir_url( __FILE__ ) );

if ( ! defined( 'WPSS_CACHE_DIR' ) ) {
	define( 'WPSS_CACHE_DIR', WP_CONTENT_DIR . '/cache/steady-speed' );
}

foreach ( array( 'settings', 'logger', 'fs', 'context', 'exclusions', 'compat', 'minify', 'css-parser', 'stats', 'debug', 'analysis', 'page-cache', 'warmup', 'invalidation', 'assets', 'css-delivery', 'thirdparty', 'preload', 'images', 'fonts', 'html', 'browser-cache', 'monitor', 'report', 'database', 'cron', 'admin', 'plugin' ) as $wpss_module ) {
	require_once WPSS_DIR . 'includes/class-wpss-' . $wpss_module . '.php';
}
unset( $wpss_module );

// Page analysis renders (signed URL, admin-initiated) are always anonymous. Added this early so
// no plugin can resolve the current user before the filter exists.
add_filter( 'determine_current_user', array( 'WPSS_Analysis', 'maybe_anonymous' ), 999 );
add_filter( 'wp_is_mobile', array( 'WPSS_Analysis', 'maybe_mobile' ), 999 );

// Serve a cached page as early as possible. Returns silently when the request is not servable.
WPSS_Page_Cache::maybe_serve();

register_activation_hook( __FILE__, array( 'WPSS_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPSS_Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'WPSS_Plugin', 'init' ) );
