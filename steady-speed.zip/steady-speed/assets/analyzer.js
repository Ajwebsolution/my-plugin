/*!
 * Steady Speed page analyzer.
 *
 * Runs in an administrator's browser only. Each queued page is loaded in a hidden iframe with
 * scripts disabled (sandbox="allow-same-origin"), once at a desktop and once at a mobile
 * viewport, rendered as an anonymous visitor would see it (signed URL). The real layout engine
 * then tells us:
 *   - which CSS rules style something in the first viewport (Critical CSS),
 *   - which selectors match nothing on the page (unused CSS candidates),
 *   - which images are above the fold, what the likely LCP element is, which fonts it needs.
 * Results go to this site's own REST API. No data leaves the site.
 */
( function () {
	'use strict';

	var C = window.WPSS_ANALYZER || {};
	var VIEW = { d: [ 1350, 900 ], m: [ 412, 915 ] };
	var FRAME_TIMEOUT = 45000;
	var CRITICAL_MAX = 300 * 1024;

	// Class names that scripts typically add or toggle at runtime. A rule that only fails to match
	// because of one of these (or a :hover-like state) is treated as used.
	var STATE = /(^|-)(is|has)-|active|open|show|visible|hidden|init|load|sticky|fixed|scroll|toggle|expand|collaps|current|select|animat|inview|in-view|hover|focus|ready|done|play|pause|swiper|slick|owl|splide|glide|flickity|fade|zoom|lazy|error|success|valid|disabled|enabled|menu|mobile|js|e--|elementor-motion|elementor-sticky/i;

	/* Must stay identical to WPSS_CSS_Parser::normalize_selector(). */
	function normSel( s ) {
		s = String( s ).replace( /\/\*[\s\S]*?\*\//g, '' );
		s = s.replace( /\s+/g, ' ' ).trim();
		s = s.replace( /\s*([>+~,])\s*/g, '$1' );
		s = s.replace( /::?(before|after|first-line|first-letter)\b/gi, function ( m, a ) {
			return ':' + a.toLowerCase();
		} );
		s = s.replace( /\[\s*([^\]=~|^$*\s"']+)\s*([~|^$*]?=)\s*(["']?)([^"'\]]*?)\3\s*(\s[iIsS])?\s*\]/g, function ( m, a, op, q, v, f ) {
			return '[' + a + op + v + ( f && f.trim() ? ' ' + f.trim().toLowerCase() : '' ) + ']';
		} );
		return s;
	}

	function relax( sel ) {
		var s = sel
			.replace( /::?(before|after|first-line|first-letter|marker|placeholder|selection|backdrop|file-selector-button|-webkit-[\w-]+|-moz-[\w-]+|-ms-[\w-]+)(\([^()]*\))?/gi, '' )
			.replace( /:(hover|focus-within|focus-visible|focus|active|visited|link|any-link|target|checked|disabled|enabled|invalid|valid|placeholder-shown|autofill|indeterminate|empty|user-invalid|user-valid|open|popover-open|modal|fullscreen|playing|paused)(?![\w-])/gi, '' );
		s = s.replace( /\.((?:\\.|[\w-])+)/g, function ( m, c ) {
			return STATE.test( c ) ? '' : m;
		} );
		s = s.replace( /\[(aria-expanded|aria-hidden|aria-selected|aria-current|aria-pressed|open|hidden|data-[\w-]*(?:state|active|open|show)[\w-]*)[^\]]*\]/gi, '' );
		s = s.replace( /\s+/g, ' ' ).replace( /\s*([>+~,])\s*/g, '$1' ).trim();
		s = s.replace( /(^|[\s>+~(,])(?=$|[\s>+~),])/g, '$1*' );
		return s || '*';
	}

	function tokens( sel ) {
		var out = [],
			m,
			re = /[.#]((?:\\.|[\w-])+)/g;
		while ( ( m = re.exec( sel ) ) ) {
			out.push( m[ 1 ].replace( /\\(.)/g, '$1' ) );
		}
		return out;
	}

	function api( path, body ) {
		return fetch( C.rest + path, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': C.nonce, 'Content-Type': 'application/json' },
			body: JSON.stringify( body || {} ),
		} ).then( function ( r ) {
			if ( ! r.ok ) {
				throw new Error( 'HTTP ' + r.status );
			}
			return r.json();
		} );
	}

	function wait( ms ) {
		return new Promise( function ( r ) {
			setTimeout( r, ms );
		} );
	}

	function loadFrame( url, w, h ) {
		return new Promise( function ( resolve, reject ) {
			var f = document.createElement( 'iframe' );
			var done = false;
			f.setAttribute( 'sandbox', 'allow-same-origin' );
			f.setAttribute( 'aria-hidden', 'true' );
			f.tabIndex = -1;
			f.style.cssText = 'position:fixed;left:-30000px;top:0;width:' + w + 'px;height:' + h + 'px;border:0;visibility:hidden;pointer-events:none';
			var t = setTimeout( function () {
				if ( ! done ) {
					done = true;
					f.remove();
					reject( new Error( 'Timeout loading page' ) );
				}
			}, FRAME_TIMEOUT );
			f.onload = function () {
				if ( done ) {
					return;
				}
				done = true;
				clearTimeout( t );
				var doc;
				try {
					doc = f.contentDocument;
				} catch ( e ) {
					doc = null;
				}
				if ( ! doc || ! doc.body || /^(about|chrome-error)/.test( doc.URL ) ) {
					f.remove();
					reject( new Error( 'The page could not be framed (X-Frame-Options / CSP?)' ) );
					return;
				}
				resolve( f );
			};
			f.src = url;
			document.body.appendChild( f );
		} );
	}

	function settle( f ) {
		var doc = f.contentDocument;
		var fonts = doc.fonts && doc.fonts.ready ? doc.fonts.ready : Promise.resolve();
		return Promise.race( [ fonts, wait( 4000 ) ] ).then( function () {
			return wait( 300 );
		} );
	}

	/* ------------------------------------------------------------------
	 * Analysis of one rendered page
	 * ---------------------------------------------------------------- */

	function analyzeDoc( f ) {
		var doc = f.contentDocument,
			win = f.contentWindow;
		var vw = win.innerWidth,
			vh = win.innerHeight;
		var origin = win.location.origin;
		var all = doc.body.getElementsByTagName( '*' );
		var atf = new Set( [ doc.documentElement, doc.body ] );
		var protectedRoots = 'header,nav,[role="banner"],[role="navigation"],.elementor-location-header,.site-header,#masthead,#site-header';
		var i, el, r;

		function visArea( rc ) {
			var w = Math.min( rc.right, vw ) - Math.max( rc.left, 0 ),
				h = Math.min( rc.bottom, vh ) - Math.max( rc.top, 0 );
			return w > 0 && h > 0 ? w * h : 0;
		}
		for ( i = 0; i < all.length; i++ ) {
			el = all[ i ];
			r = el.getBoundingClientRect();
			// In (or within 200 px of) the first viewport, or not rendered at all (menus, popups,
			// toggled content), or part of the header/navigation (mega menus open below the fold).
			// An element that is below the fold only because of its OWN margin is included too:
			// without its rules it would move up into the first screen.
			var inView = r.top < vh + 200 || ( 0 === r.width && 0 === r.height ) || el.closest( protectedRoots );
			if ( ! inView && r.top < vh * 3 ) {
				var st = win.getComputedStyle( el );
				inView = r.top - ( parseFloat( st.marginTop ) || 0 ) - ( parseFloat( st.paddingTop ) || 0 ) - ( parseFloat( st.borderTopWidth ) || 0 ) < vh;
			}
			if ( inView ) {
				atf.add( el );
			}
		}

		function absUrl( u, base ) {
			try {
				var x = new URL( u, base || doc.baseURI );
				return x.origin === origin ? x.pathname + x.search + x.hash : x.href;
			} catch ( e ) {
				return u;
			}
		}
		function fixUrls( text, base ) {
			return text.replace( /url\(\s*(['"]?)([^'")]+)\1\s*\)/g, function ( m, q, u ) {
				if ( /^(data:|#|about:)/i.test( u ) ) {
					return m;
				}
				return 'url("' + absUrl( u, base ) + '")';
			} );
		}

		// ---- Collect rules in cascade order.
		var items = [],
			faces = [],
			frames = {},
			covered = [],
			seq = 0;
		function walk( rules, base, wrap, sheet ) {
			for ( var k = 0; k < rules.length; k++ ) {
				var rule = rules[ k ];
				var name = rule.constructor && rule.constructor.name;
				if ( 1 === rule.type ) {
					items.push( { seq: seq++, sel: rule.selectorText, text: fixUrls( rule.cssText, base ), wrap: wrap, sheet: sheet } );
				} else if ( 3 === rule.type ) {
					var mt = rule.media && rule.media.mediaText;
					if ( mt && /^\s*print\s*$/i.test( mt ) ) {
						continue;
					}
					try {
						if ( rule.styleSheet ) {
							walk( rule.styleSheet.cssRules, rule.styleSheet.href || base, mt ? wrap.concat( '@media ' + mt ) : wrap, sheet );
						}
					} catch ( e ) {}
				} else if ( 5 === rule.type ) {
					faces.push( {
						text: fixUrls( rule.cssText, base ),
						family: ( rule.style.getPropertyValue( 'font-family' ) || '' ).replace( /["']/g, '' ).trim().toLowerCase(),
						weight: rule.style.getPropertyValue( 'font-weight' ) || '400',
						style: rule.style.getPropertyValue( 'font-style' ) || 'normal',
						src: rule.style.getPropertyValue( 'src' ) || '',
						base: base,
						wrap: wrap,
					} );
				} else if ( 7 === rule.type ) {
					frames[ rule.name ] = { text: rule.cssText, wrap: wrap };
				} else if ( rule.cssRules && ( 4 === rule.type || 12 === rule.type || /^CSS(Layer(Block)?|Container|Scope|StartingStyle)Rule$/.test( name ) ) ) {
					if ( 4 === rule.type && /^\s*print\s*$/i.test( rule.media.mediaText ) ) {
						continue;
					}
					var head = rule.cssText.slice( 0, rule.cssText.indexOf( '{' ) ).trim();
					walk( rule.cssRules, base, wrap.concat( head ), sheet );
				} else if ( /^CSS(Property|LayerStatement|Namespace)Rule$/.test( name ) ) {
					items.push( { seq: seq++, sel: null, always: true, text: rule.cssText, wrap: wrap, sheet: sheet } );
				}
			}
		}
		var links = doc.querySelectorAll( 'link[rel~="stylesheet" i]' );
		var sig = [].map.call( links, function ( l ) {
			return l.getAttribute( 'href' );
		} );
		for ( i = 0; i < doc.styleSheets.length; i++ ) {
			var sh = doc.styleSheets[ i ];
			var owner = sh.ownerNode;
			if ( ! owner || 'LINK' !== owner.tagName ) {
				continue; // Inline <style> blocks are already in the HTML.
			}
			var href = owner.getAttribute( 'href' );
			var media = sh.media && sh.media.mediaText;
			if ( media && /^\s*print\s*$/i.test( media ) ) {
				continue;
			}
			var rules;
			try {
				rules = sh.cssRules;
			} catch ( e ) {
				continue; // Cross-origin: never made async, never filtered.
			}
			covered.push( href );
			walk( rules, sh.href, media && 'all' !== media ? [ '@media ' + media ] : [], href );
		}

		// ---- Selector tests.
		var memoAtf = new Map(),
			memoAny = new Map();
		function test( sel, set ) {
			var nodes;
			try {
				nodes = doc.querySelectorAll( sel );
			} catch ( e ) {
				return 'err';
			}
			if ( ! set ) {
				return nodes.length ? 'yes' : 'no';
			}
			for ( var n = 0; n < nodes.length; n++ ) {
				if ( set.has( nodes[ n ] ) ) {
					return 'yes';
				}
			}
			return 'no';
		}
		function inAtf( sel ) {
			if ( memoAtf.has( sel ) ) {
				return memoAtf.get( sel );
			}
			var res = 'yes' === test( sel, atf );
			if ( ! res ) {
				var rl = relax( sel );
				res = rl !== sel && 'yes' === test( rl, atf );
			}
			memoAtf.set( sel, res );
			return res;
		}
		var html = doc.documentElement.outerHTML;
		var tokMemo = new Map();
		function hasToken( t ) {
			if ( tokMemo.has( t ) ) {
				return tokMemo.get( t );
			}
			var idx = html.indexOf( t ),
				found = false;
			while ( idx >= 0 ) {
				var b = html.charAt( idx - 1 ),
					a = html.charAt( idx + t.length );
				if ( ! /[\w-]/.test( b ) && ! /[\w-]/.test( a ) ) {
					found = true;
					break;
				}
				idx = html.indexOf( t, idx + 1 );
			}
			tokMemo.set( t, found );
			return found;
		}
		// null = keep, 'b' = unused (balanced & aggressive), 'a' = unused (aggressive only).
		function unusedLevel( sel ) {
			if ( memoAny.has( sel ) ) {
				return memoAny.get( sel );
			}
			var res = null;
			if ( 'no' === test( sel, null ) ) {
				var rl = relax( sel );
				if ( rl === sel || 'no' === test( rl, null ) ) {
					var toks = tokens( sel );
					if ( ! toks.length ) {
						res = 'a'; // Only type/attribute selectors: uncertain, aggressive only.
					} else {
						var present = toks.filter( hasToken ).length;
						res = 0 === present ? 'b' : present < toks.length ? 'a' : null;
					}
				}
			}
			memoAny.set( sel, res );
			return res;
		}

		// ---- Critical CSS.
		var included = [];
		items.forEach( function ( it ) {
			if ( it.always || ( it.sel && inAtf( it.sel ) ) ) {
				included.push( it.seq );
			}
		} );

		// ---- Unused selectors per stylesheet.
		var unused = {};
		items.forEach( function ( it ) {
			if ( ! it.sel ) {
				return;
			}
			var lv = unusedLevel( it.sel );
			if ( ! lv ) {
				return;
			}
			var u = unused[ it.sheet ] || ( unused[ it.sheet ] = { b: [], a: [] } );
			var n = normSel( it.sel );
			u.a.push( n );
			if ( 'b' === lv ) {
				u.b.push( n );
			}
		} );

		// ---- Above-the-fold images, LCP candidate, fonts.
		var atfImgs = [],
			best = null,
			bestArea = 0,
			fontArea = {},
			fontUsage = {};
		var textTags = /^(H[1-6]|P|LI|BLOCKQUOTE|TD|TH|DIV|SPAN|A|BUTTON|LABEL|STRONG|EM|B|FIGCAPTION|DT|DD)$/;
		for ( i = 0; i < all.length; i++ ) {
			el = all[ i ];
			var hasText = false;
			for ( var c = el.firstChild; c; c = c.nextSibling ) {
				if ( 3 === c.nodeType && c.nodeValue.trim() ) {
					hasText = true;
					break;
				}
			}
			var cs = null;
			if ( hasText && textTags.test( el.tagName ) ) {
				cs = win.getComputedStyle( el );
				var fam = ( cs.fontFamily.split( ',' )[ 0 ] || '' ).replace( /["']/g, '' ).trim();
				var key = fam + '|' + cs.fontWeight + '|' + ( 'normal' === cs.fontStyle ? 'normal' : 'italic' );
				fontUsage[ key ] = 1;
			}
			r = el.getBoundingClientRect();
			var area = visArea( r );
			if ( ! area ) {
				continue;
			}
			var cand = null;
			if ( 'IMG' === el.tagName ) {
				var s = el.getAttribute( 'src' ) || '';
				if ( s && ! /^data:/i.test( s ) ) {
					atfImgs.push( s );
					cand = { type: 'img', src: s, srcset: el.getAttribute( 'srcset' ) || '', sizes: el.getAttribute( 'sizes' ) || '' };
				}
			} else if ( 'VIDEO' === el.tagName && el.getAttribute( 'poster' ) ) {
				cand = { type: 'video', src: el.getAttribute( 'poster' ) };
			} else {
				cs = cs || win.getComputedStyle( el );
				var m = /url\(\s*["']?([^"')]+)["']?\s*\)/.exec( cs.backgroundImage || '' );
				if ( m && ! /^data:/i.test( m[ 1 ] ) && el !== doc.body && el !== doc.documentElement ) {
					cand = { type: 'bg', src: absUrl( m[ 1 ] ) };
				} else if ( hasText && textTags.test( el.tagName ) ) {
					cand = { type: 'text', tag: el.tagName.toLowerCase() };
					var fk = ( cs.fontFamily.split( ',' )[ 0 ] || '' ).replace( /["']/g, '' ).trim().toLowerCase() + '|' + cs.fontWeight + '|' + ( 'normal' === cs.fontStyle ? 'normal' : 'italic' );
					fontArea[ fk ] = ( fontArea[ fk ] || 0 ) + area;
				}
			}
			if ( cand && area > bestArea ) {
				best = cand;
				bestArea = area;
			}
		}

		function weightNum( w ) {
			return 'bold' === w ? 700 : 'normal' === w ? 400 : parseInt( w, 10 ) || 400;
		}
		function faceFor( key ) {
			var p = key.split( '|' ),
				want = weightNum( p[ 1 ] ),
				bestF = null,
				bestD = 1e9;
			faces.forEach( function ( fc ) {
				if ( fc.family !== p[ 0 ] ) {
					return;
				}
				var st = /italic|oblique/.test( fc.style ) ? 'italic' : 'normal';
				if ( st !== p[ 2 ] ) {
					return;
				}
				var ws = String( fc.weight ).split( /\s+/ ).map( weightNum );
				var d = ws.length > 1 && want >= ws[ 0 ] && want <= ws[ 1 ] ? 0 : Math.abs( ws[ 0 ] - want );
				if ( d < bestD ) {
					bestD = d;
					bestF = fc;
				}
			} );
			if ( ! bestF ) {
				return null;
			}
			var urls = [],
				mm,
				re = /url\(\s*["']?([^"')]+)["']?\s*\)(\s*format\(\s*["']?([\w-]+)["']?\s*\))?/g;
			while ( ( mm = re.exec( bestF.src ) ) ) {
				urls.push( { u: mm[ 1 ], f: ( mm[ 3 ] || '' ).toLowerCase() } );
			}
			var pick = urls.filter( function ( x ) {
				return 'woff2' === x.f || /\.woff2(\?|#|$)/i.test( x.u );
			} )[ 0 ];
			return pick ? absUrl( pick.u, bestF.base ) : null;
		}
		var fonts = [];
		Object.keys( fontArea )
			.sort( function ( a, b ) {
				return fontArea[ b ] - fontArea[ a ];
			} )
			.forEach( function ( k ) {
				if ( fonts.length >= 2 ) {
					return;
				}
				var u = faceFor( k );
				if ( u && fonts.indexOf( u ) < 0 ) {
					fonts.push( u );
				}
			} );

		return {
			vw: vw,
			vh: vh,
			sig: sig,
			covered: covered,
			items: items,
			faces: faces,
			frames: frames,
			included: included,
			unused: unused,
			atf: atfImgs.slice( 0, 30 ),
			lcp: best,
			fonts: fonts,
			fontUsage: Object.keys( fontUsage ),
		};
	}

	/* ------------------------------------------------------------------
	 * Build the critical CSS text from included rules (cascade order kept)
	 * ---------------------------------------------------------------- */

	// Returns [[stylesheet href, css], ...] in cascade order; extras (@font-face, @keyframes) last with href ''.
	function buildCritical( items, seqs, faces, frames ) {
		var set = new Set( seqs ),
			segs = [],
			curKey = null,
			curSheet = null,
			buf = '',
			curWrap = [];
		function wrapIt( text, wrap ) {
			for ( var w = wrap.length - 1; w >= 0; w-- ) {
				text = wrap[ w ] + '{' + text + '}';
			}
			return text;
		}
		function flush() {
			if ( buf ) {
				var css = wrapIt( buf, curWrap );
				var last = segs[ segs.length - 1 ];
				if ( last && last[ 0 ] === curSheet ) {
					last[ 1 ] += css;
				} else {
					segs.push( [ curSheet, css ] );
				}
			}
			buf = '';
		}
		items.forEach( function ( it ) {
			if ( ! set.has( it.seq ) ) {
				return;
			}
			var key = it.sheet + '\u0002' + it.wrap.join( '\u0001' );
			if ( key !== curKey ) {
				flush();
				curKey = key;
				curWrap = it.wrap;
				curSheet = it.sheet;
			}
			buf += it.text;
		} );
		flush();
		if ( ! segs.length ) {
			return [];
		}
		var low = segs
			.map( function ( x ) {
				return x[ 1 ];
			} )
			.join( '' );
		var extra = '';
		var lower = low.toLowerCase();
		faces.forEach( function ( fc ) {
			if ( fc.family && lower.indexOf( fc.family ) >= 0 ) {
				extra += wrapIt( fc.text, fc.wrap );
			}
		} );
		Object.keys( frames ).forEach( function ( n ) {
			if ( new RegExp( 'animation[^;}]*[\\s:,]' + n.replace( /[.*+?^${}()|[\]\\]/g, '\\$&' ) + '([\\s;,}]|$)' ).test( low ) ) {
				extra += wrapIt( frames[ n ].text, frames[ n ].wrap );
			}
		} );
		if ( extra ) {
			segs.push( [ '', extra ] );
		}
		return segs;
	}

	function critSize( segs ) {
		return segs.reduce( function ( n, x ) {
			return n + x[ 1 ].length;
		}, 0 );
	}

	function device( a ) {
		var crit = buildCritical( a.items, a.included, a.faces, a.frames );
		return {
			vw: a.vw,
			vh: a.vh,
			sig: a.sig,
			covered: a.covered,
			critical: critSize( crit ) > CRITICAL_MAX ? [] : crit,
			atf: a.atf,
			lcp: a.lcp,
			fonts: a.fonts.map( function ( u ) {
				return { url: u };
			} ),
			unused: a.unused,
		};
	}

	function union( d, m ) {
		if ( d.sig.join( '\n' ) !== m.sig.join( '\n' ) ) {
			return null;
		}
		var crit = [];
		if ( d.items.length === m.items.length ) {
			var seqs = Array.from( new Set( d.included.concat( m.included ) ) ).sort( function ( a, b ) {
				return a - b;
			} );
			crit = buildCritical( d.items, seqs, d.faces, d.frames );
		}
		var unused = {};
		Object.keys( d.unused ).forEach( function ( href ) {
			if ( ! m.unused[ href ] ) {
				return;
			}
			var mb = new Set( m.unused[ href ].b ),
				ma = new Set( m.unused[ href ].a );
			unused[ href ] = {
				b: d.unused[ href ].b.filter( function ( s ) {
					return mb.has( s );
				} ),
				a: d.unused[ href ].a.filter( function ( s ) {
					return ma.has( s );
				} ),
			};
		} );
		var fonts = d.fonts.concat( m.fonts ).filter( function ( u, idx, arr ) {
			return arr.indexOf( u ) === idx;
		} );
		return {
			vw: 0,
			vh: 0,
			sig: d.sig,
			covered: d.covered.filter( function ( h ) {
				return m.covered.indexOf( h ) >= 0;
			} ),
			critical: critSize( crit ) > CRITICAL_MAX ? [] : crit,
			atf: Array.from( new Set( d.atf.concat( m.atf ) ) ).slice( 0, 40 ),
			lcp: d.lcp,
			fonts: fonts.slice( 0, 2 ).map( function ( u ) {
				return { url: u };
			} ),
			unused: unused,
		};
	}

	function analyzeUrl( url, dev ) {
		var v = VIEW[ dev ];
		return loadFrame( url, v[ 0 ], v[ 1 ] ).then( function ( f ) {
			return settle( f )
				.then( function () {
					var res = analyzeDoc( f );
					f.remove();
					return res;
				} )
				.catch( function ( e ) {
					f.remove();
					throw e;
				} );
		} );
	}

	function analyzeItem( item ) {
		var d, m;
		return analyzeUrl( item.d, 'd' )
			.then( function ( r ) {
				d = r;
				return analyzeUrl( item.m, 'm' );
			} )
			.then( function ( r ) {
				m = r;
				var devices = { d: device( d ), m: device( m ) };
				var u = union( d, m );
				if ( u ) {
					devices.u = u;
				}
				var usage = Array.from( new Set( d.fontUsage.concat( m.fontUsage ) ) );
				return api( 'analysis/result', { path: item.path, devices: devices, fontUsage: usage } );
			} )
			.catch( function ( e ) {
				return api( 'analysis/result', { path: item.path, error: String( ( e && e.message ) || e ) } ).then( function () {
					return { stored: false, error: String( ( e && e.message ) || e ) };
				} );
			} );
	}

	var running = false;

	/**
	 * Process queued pages.
	 *
	 * @param {Object} opts max (pages), onProgress(done, remaining, path, result)
	 */
	function run( opts ) {
		opts = opts || {};
		var max = opts.max || 2,
			done = 0;
		if ( running ) {
			return Promise.resolve( 0 );
		}
		running = true;
		function step() {
			if ( done >= max ) {
				return Promise.resolve( done );
			}
			return api( 'analysis/next', { n: 1 } ).then( function ( q ) {
				if ( ! q.items || ! q.items.length ) {
					return done;
				}
				var item = q.items[ 0 ];
				return analyzeItem( item ).then( function ( res ) {
					done++;
					if ( opts.onProgress ) {
						opts.onProgress( done, Math.max( 0, q.remaining - 1 ), item.path, res );
					}
					return step();
				} );
			} );
		}
		return step().then(
			function ( n ) {
				running = false;
				return n;
			},
			function ( e ) {
				running = false;
				throw e;
			}
		);
	}

	window.WPSSAnalyzer = { run: run, normSel: normSel, relax: relax, analyzeDoc: analyzeDoc, buildCritical: buildCritical };

	if ( C.auto ) {
		var start = function () {
			setTimeout( function () {
				run( { max: C.batch || 2 } ).catch( function () {} );
			}, 3000 );
		};
		if ( 'complete' === document.readyState ) {
			start();
		} else {
			window.addEventListener( 'load', start );
		}
	}
} )();
