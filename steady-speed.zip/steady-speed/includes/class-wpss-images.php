<?php
/**
 * Image loading: lazy loading (never for logo/hero/first images), missing dimensions,
 * <picture> WebP/AVIF delivery when copies exist, and WebP copy generation (originals untouched).
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Images {

	const BULK = 'wpss_webp_bulk';
	const FRONTEND_QUEUE = 'wpss_webp_frontend_queue';

	public static function init() {
		add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_metadata' ), 20, 2 );
		add_action( 'delete_attachment', array( __CLASS__, 'on_delete' ) );
		add_action( 'wp_head', array( __CLASS__, 'frontend_delivery_script' ), 1 );
		// WebP delivery must also work for logged-in administrators while testing the frontend.
		// Other Steady Speed optimizations can remain disabled for logged-in users.
		add_action( 'template_redirect', array( __CLASS__, 'start_logged_in_webp_buffer' ), 2 );
	}

	/**
	 * Client-side WebP delivery for images inserted after the server response.
	 *
	 * Some themes, sliders and custom apps create <img> elements with JavaScript
	 * after output buffering has already finished. Server-side HTML rewriting cannot
	 * see those elements. This lightweight observer applies the same WebP mapping
	 * to dynamically inserted frontend images. The original URL is retained and
	 * restored automatically if the WebP file is unavailable.
	 */
	public static function frontend_delivery_script() {
		if ( is_admin() ) {
			return;
		}
		// WebP delivery is deliberately independent from the main optimization context.
		// This means an administrator can verify WebP on the live frontend without enabling
		// every other optimization for logged-in users.
		if ( ! WPSS_Context::optimize() && ! is_user_logged_in() ) {
			return;
		}
		if ( ! ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) ) {
			return;
		}
		?>
<script id="wpss-webp-delivery">
(function(){
    'use strict';
    if (window.__WPSS_WEBP_DELIVERY__) return;
    window.__WPSS_WEBP_DELIVERY__ = true;

    function localImageUrl(value){
        if (!value || /^data:|^blob:|^javascript:/i.test(value)) return null;
        try {
            var u = new URL(value, document.baseURI);
            if (u.origin !== location.origin) return null;
            if (!/\.(jpe?g|png)$/i.test(u.pathname)) return null;
            return u;
        } catch(e){ return null; }
    }

    function webpUrl(value){
        var u = localImageUrl(value);
        if (!u) return null;
        u.pathname = u.pathname.replace(/\.(jpe?g|png)$/i, '.webp');
        return u.href;
    }

    function convertSrcset(value){
        if (!value) return value;
        var out=[];
        value.split(',').forEach(function(part){
            var bits=part.trim().split(/\s+/);
            if (!bits[0]) return;
            var u=webpUrl(bits[0]);
            out.push((u || bits[0]) + (bits.length>1 ? ' ' + bits.slice(1).join(' ') : ''));
        });
        return out.join(', ');
    }

    function apply(img){
        if (!img || img.nodeType !== 1 || img.tagName !== 'IMG') return;
        if (img.dataset.wpssWebpDone === '1' || img.dataset.wpssWebpChecking === '1') return;

        var src = img.getAttribute('src');
        var lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src');
        var original = src && !/\.webp(?:\?|$)/i.test(src) ? src : lazy;
        if (!original) return;
        var candidate = webpUrl(original);
        if (!candidate) return;

        img.dataset.wpssWebpChecking = '1';
        var probe = new Image();
        probe.onload = function(){
            img.dataset.wpssWebpChecking = '';
            img.dataset.wpssOriginalSrc = original;
            img.setAttribute('data-wpss-webp', '1');
            img.setAttribute('data-wpss-webp-original', original);
            if (src && !/\.webp(?:\?|$)/i.test(src)) img.setAttribute('src', candidate);
            if (img.getAttribute('data-src')) img.setAttribute('data-src', candidate);
            if (img.getAttribute('data-lazy-src')) img.setAttribute('data-lazy-src', candidate);
            var ss = img.getAttribute('srcset') || img.getAttribute('data-srcset');
            if (ss) {
                var converted = convertSrcset(ss);
                if (img.getAttribute('srcset')) img.setAttribute('srcset', converted);
                if (img.getAttribute('data-srcset')) img.setAttribute('data-srcset', converted);
            }
            img.dataset.wpssWebpDone = '1';
        };
        probe.onerror = function(){
            img.dataset.wpssWebpChecking = '';
            img.dataset.wpssWebpDone = '1';
        };
        probe.src = candidate;
    }

    function scan(root){
        if (!root) return;
        if (root.nodeType === 1 && root.tagName === 'IMG') apply(root);
        var imgs = root.querySelectorAll ? root.querySelectorAll('img') : [];
        for (var i=0;i<imgs.length;i++) apply(imgs[i]);
    }

    function start(){
        scan(document);
        if (!window.MutationObserver) return;
        var observer = new MutationObserver(function(records){
            for (var i=0;i<records.length;i++) {
                var added = records[i].addedNodes;
                for (var j=0;j<added.length;j++) scan(added[j]);
                var target = records[i].target;
                if (target && target.nodeType === 1 && target.tagName === 'IMG') apply(target);
            }
        });
        observer.observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:['src','data-src','data-lazy-src']});
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
    else start();
})();
</script>
		<?php
	}

	/**
	 * Start a small output buffer only for logged-in frontend requests.
	 *
	 * The normal HTML optimization buffer is intentionally bypassed for logged-in users.
	 * That is useful for safety, but it previously meant the WebP delivery layer could not
	 * rewrite custom HTML such as the meal-card markup shown in the user's frontend. This
	 * buffer performs ONLY WebP URL replacement and does not run the other optimizations.
	 */
	public static function start_logged_in_webp_buffer() {
		if ( is_admin() || ! is_user_logged_in() ) {
			return;
		}
		if ( ! ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) ) {
			return;
		}
		if ( WPSS_Context::is_rest_like() || WPSS_Context::is_editor_request() ) {
			return;
		}
		ob_start( array( __CLASS__, 'logged_in_webp_buffer' ) );
	}

	/**
	 * Rewrite only local JPEG/PNG image URLs for logged-in frontend testing.
	 * The replacement happens only when the corresponding WebP file exists.
	 *
	 * @param string $html Final HTML.
	 * @return string
	 */
	public static function logged_in_webp_buffer( $html ) {
		if ( ! is_string( $html ) || '' === $html || false === stripos( $html, '<img' ) ) {
			return $html;
		}
		return (string) preg_replace_callback(
			'/<img\b[^>]*>/i',
			static function ( $m ) {
				$tag = $m[0];
				$src = self::attr( $tag, 'src' );
				if ( null !== $src && '' !== $src ) {
					$webp = self::variant_url( html_entity_decode( $src, ENT_QUOTES ), 'webp' );
					if ( false !== $webp ) {
						if ( null === self::attr( $tag, 'data-wpss-original-src' ) ) {
							$tag = preg_replace( '/^<img\b/i', '<img data-wpss-original-src="' . esc_attr( html_entity_decode( $src, ENT_QUOTES ) ) . '"', $tag );
						}
						$tag = preg_replace( '/\s+src\s*=\s*("|\')(.*?)\1/i', ' src="' . esc_attr( $webp ) . '"', $tag, 1 );
						if ( false === stripos( $tag, 'data-wpss-webp="1"' ) ) {
							$tag = preg_replace( '/^<img\b/i', '<img data-wpss-webp="1"', $tag );
						}
					}
				}
				foreach ( array( 'data-src', 'data-lazy-src' ) as $attr ) {
					$value = self::attr( $tag, $attr );
					if ( null === $value || '' === $value ) {
						continue;
					}
					$webp = self::variant_url( html_entity_decode( $value, ENT_QUOTES ), 'webp' );
					if ( false !== $webp ) {
						$tag = preg_replace( '/\s+' . preg_quote( $attr, '/' ) . '\s*=\s*("|\')(.*?)\1/i', ' ' . $attr . '="' . esc_attr( $webp ) . '"', $tag, 1 );
					}
				}
				// Do not blindly replace srcset candidates: browsers can choose a candidate before
				// asynchronous JavaScript probing finishes. Existing WebP src is the reliable path.
				return $tag;
			},
			$html
		);
	}

	/** @var bool Dimensions were added (the height:auto guard is needed). */
	private static $dims_added = false;

	/** @var array|null Sources chosen by the last picture() call. */
	private static $last_picture = null;

	/**
	 * Rewrite <img> (and <iframe>) tags in the body.
	 *
	 * @param string $html HTML.
	 */
	public static function process( $html ) {
		$lazy   = (bool) WPSS_Settings::get( 'lazy' );
		$dims   = (bool) WPSS_Settings::get( 'img_dimensions' );
		$pict   = (bool) WPSS_Settings::get( 'img_opt' ) || (bool) WPSS_Settings::get( 'img_avif' ) || (bool) WPSS_Settings::get( 'img_all' );
		$srcset = (bool) WPSS_Settings::get( 'img_srcset' );
		$lcp_on = (bool) WPSS_Settings::get( 'lcp_opt' );
		$atf_on = (bool) WPSS_Settings::get( 'atf_opt' );
		$iframe = (bool) WPSS_Settings::get( 'iframe_lazy' );
		if ( ! $lazy && ! $dims && ! $pict && ! $srcset && ! $lcp_on && ! $atf_on && ! $iframe ) {
			return $html;
		}
		// Discover every local JPEG/PNG actually present in the rendered frontend page.
		// Media Library items are handled by the bulk queue; non-media/theme/plugin images
		// are queued here so they are converted too without blocking the visitor request.
		if ( $pict ) {
			self::queue_frontend_images_from_html( $html );
		}
		$body = stripos( $html, '<body' );
		if ( false === $body ) {
			return $html;
		}
		$head = substr( $html, 0, $body );
		$rest = substr( $html, $body );

		// Page analysis (real layout): which images are in the first viewport, which is the LCP.
		$rec     = ( $atf_on || $lcp_on ) ? WPSS_Analysis::for_request() : null;
		$atf     = array();
		$lcp_src = '';
		if ( $rec ) {
			foreach ( $rec['atf'] as $u ) {
				$atf[ self::norm_src( $u ) ] = true;
			}
			if ( $lcp_on && ! empty( $rec['lcp'] ) && 'img' === $rec['lcp']['type'] ) {
				$lcp_src = self::norm_src( $rec['lcp']['src'] );
			}
		}
		// Without analysis: the first large, non-logo image gets priority unless something already has it.
		$heuristic_lcp = $lcp_on && ! $rec && false === stripos( $rest, 'fetchpriority="high"' ) && false === stripos( $rest, "fetchpriority='high'" );

		$count = 0;
		$skip  = (int) WPSS_Settings::get( 'lazy_skip' );
		// Protected regions: <picture>, <noscript>, <script>, <template>, <textarea>.
		$regions = array();
		if ( preg_match_all( '#<(picture|noscript|script|template|textarea)\b.*?</\1>#is', $rest, $mm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $mm[0] as $i => $m ) {
				$regions[] = array( $m[1], $m[1] + strlen( $m[0] ), strtolower( $mm[1][ $i ][0] ) );
			}
		}
		$lcp_done = false;

		$rest = preg_replace_callback(
			'/<img\b[^>]*>/i',
			static function ( $m ) use ( &$count, &$lcp_done, &$heuristic_lcp, $skip, $lazy, $dims, $pict, $srcset, $atf_on, $rec, $atf, $lcp_src, $regions ) {
				$tag    = $m[0][0];
				$offset = $m[0][1];
				$region = '';
				foreach ( $regions as $r ) {
					if ( $offset >= $r[0] && $offset < $r[1] ) {
						$region = $r[2];
						break;
					}
				}
				if ( in_array( $region, array( 'noscript', 'script', 'template', 'textarea' ), true ) ) {
					return $tag;
				}
				++$count;
				$orig = $tag;
				try {
					$src  = (string) self::attr( $tag, 'src' );
					$norm = self::norm_src( $src );
					if ( $dims ) {
						$tag = self::add_dimensions( $tag );
					}
					if ( $srcset ) {
						$tag = self::add_srcset( $tag );
					}
					$is_atf = $rec ? isset( $atf[ $norm ] ) : $count <= $skip;
					$is_lcp = false;
					if ( ! $lcp_done && '' !== $norm ) {
						if ( '' !== $lcp_src && $norm === $lcp_src ) {
							$is_lcp = true;
						} elseif ( $heuristic_lcp && $count <= max( 1, $skip ) && self::likely_hero( $tag ) ) {
							$is_lcp        = true;
							$heuristic_lcp = false;
						}
					}
					if ( $is_lcp ) {
						$lcp_done = true;
						$tag      = self::make_priority( $tag );
					} elseif ( $is_atf && $atf_on && $rec ) {
						$tag = self::remove_lazy( $tag ); // In the first viewport: never lazy.
					} elseif ( $lazy && ! $is_atf ) {
						$tag = self::add_lazy( $tag );
					}
					self::$last_picture = null;
					if ( $pict && '' === $region ) {
						$tag = self::picture( $tag );
					}
					if ( $is_lcp ) {
						self::record_lcp( $tag, $src, '' !== $lcp_src ? 'analysis' : 'heuristic' );
					}
					self::stats( $tag, $src );
				} catch ( Throwable $e ) {
					return $orig;
				}
				return $tag;
			},
			$rest,
			-1,
			$n,
			PREG_OFFSET_CAPTURE
		);
		if ( null === $rest ) {
			return $html;
		}
		if ( WPSS_Settings::get( 'iframe_lazy' ) ) {
			$rest = self::lazy_iframes( $rest );
		}
		if ( self::$dims_added ) {
			// Width/height we add only reserve space; :where() has zero specificity, so any theme
			// rule setting a height still wins. Prevents stretched images.
			$head = preg_replace( '#</head>#i', '<style id="wpss-dim">:where(img[data-wpss-dim]){height:auto}</style></head>', $head, 1 );
		}
		return $head . $rest;
	}

	/**
	 * Comparable form of an image URL (entities decoded, scheme/host dropped for same-site).
	 *
	 * @param string $src Src.
	 */
	private static function norm_src( $src ) {
		$src = trim( html_entity_decode( (string) $src, ENT_QUOTES ) );
		if ( '' === $src || 0 === stripos( $src, 'data:' ) ) {
			return '';
		}
		$p = wp_parse_url( $src );
		if ( ! empty( $p['host'] ) && WPSS_FS::url_host( $src ) !== WPSS_FS::home_host() ) {
			return strtolower( $p['host'] ) . ( $p['path'] ?? '' );
		}
		return ( $p['path'] ?? '' ) . ( isset( $p['query'] ) ? '?' . $p['query'] : '' );
	}

	/**
	 * Heuristic hero image (used only without page analysis).
	 *
	 * @param string $tag Tag.
	 */
	private static function likely_hero( $tag ) {
		$class = strtolower( (string) self::attr( $tag, 'class' ) );
		$src   = (string) self::attr( $tag, 'src' );
		if ( '' === $src || 0 === stripos( $src, 'data:' ) || preg_match( '/logo|icon|avatar|emoji|gravatar/i', $class . ' ' . basename( (string) wp_parse_url( $src, PHP_URL_PATH ) ) ) ) {
			return false;
		}
		$w = (int) self::attr( $tag, 'width' );
		return 0 === $w || $w >= 400;
	}

	/**
	 * LCP image: never lazy, high fetch priority.
	 *
	 * @param string $tag Tag.
	 */
	private static function make_priority( $tag ) {
		$tag = self::remove_lazy( $tag );
		if ( null === self::attr( $tag, 'fetchpriority' ) ) {
			$tag = preg_replace( '/^<img\b/i', '<img fetchpriority="high"', $tag );
		} else {
			$tag = preg_replace( '/\sfetchpriority\s*=\s*(["\']?)(low|auto)\1/i', ' fetchpriority="high"', $tag );
		}
		return $tag;
	}

	/**
	 * Remove loading="lazy" (set by the theme, core or us) from an above-the-fold image.
	 *
	 * @param string $tag Tag.
	 */
	private static function remove_lazy( $tag ) {
		return preg_replace( '/\sloading\s*=\s*(["\']?)lazy\1/i', '', $tag );
	}

	/**
	 * Remember what to preload for the LCP image (the format the browser will actually pick).
	 *
	 * @param string $tag Final markup (possibly <picture>).
	 * @param string $src Original src.
	 * @param string $how analysis|heuristic.
	 */
	private static function record_lcp( $tag, $src, $how ) {
		$img = preg_match( '/<img\b[^>]*>/i', $tag, $m ) ? $m[0] : $tag;
		WPSS_Stats::set( 'lcp', wp_basename( (string) wp_parse_url( html_entity_decode( $src ), PHP_URL_PATH ) ) . ( 'heuristic' === $how ? ' (estimated)' : '' ) );
		if ( 'analysis' !== $how ) {
			return; // Only preload what the real layout confirmed.
		}
		if ( self::$last_picture ) {
			WPSS_Preload::$lcp_image = self::$last_picture;
			return;
		}
		WPSS_Preload::$lcp_image = array(
			'href'   => html_entity_decode( $src, ENT_QUOTES ),
			'srcset' => html_entity_decode( (string) self::attr( $img, 'srcset' ), ENT_QUOTES ),
			'sizes'  => html_entity_decode( (string) self::attr( $img, 'sizes' ), ENT_QUOTES ),
		);
	}

	/**
	 * Responsive images for attachment images that lack srcset (core API only; never guessed).
	 *
	 * @param string $tag Tag.
	 */
	private static function add_srcset( $tag ) {
		if ( null !== self::attr( $tag, 'srcset' ) || ! preg_match( '/\bwp-image-(\d+)\b/', (string) self::attr( $tag, 'class' ), $m ) ) {
			return $tag;
		}
		$meta = wp_get_attachment_metadata( (int) $m[1] );
		if ( ! is_array( $meta ) || empty( $meta['sizes'] ) ) {
			return $tag;
		}
		$new = wp_image_add_srcset_and_sizes( $tag, $meta, (int) $m[1] );
		return is_string( $new ) && '' !== $new ? $new : $tag;
	}

	/**
	 * loading="lazy" for iframes (videos, maps). Browsers load in-viewport iframes immediately anyway.
	 *
	 * @param string $html Body HTML.
	 */
	private static function lazy_iframes( $html ) {
		return preg_replace_callback(
			'#<(noscript|template|script)\b.*?</\1>|<iframe\b[^>]*>#is',
			static function ( $m ) {
				$tag = $m[0];
				if ( 0 !== stripos( $tag, '<iframe' ) ) {
					return $tag;
				}
				if ( null !== self::attr( $tag, 'loading' ) || null !== self::attr( $tag, 'data-src' ) || null !== self::attr( $tag, 'data-no-lazy' ) ) {
					return $tag;
				}
				$src = (string) self::attr( $tag, 'src' );
				if ( '' === $src || 0 === stripos( $src, 'about:' ) || 0 === stripos( $src, 'javascript:' ) ) {
					return $tag;
				}
				return preg_replace( '/^<iframe\b/i', '<iframe loading="lazy"', $tag );
			},
			$html
		);
	}

	/**
	 * Size statistics for the report.
	 *
	 * @param string $tag Final markup.
	 * @param string $src Original src.
	 */
	private static function stats( $tag, $src ) {
		WPSS_Stats::add( 'img_count' );
		if ( preg_match( '/\sloading\s*=\s*["\']?lazy/i', $tag ) ) {
			WPSS_Stats::add( 'img_lazy' );
		}
		$path = '' !== $src && 0 !== stripos( $src, 'data:' ) ? WPSS_FS::url_to_path( html_entity_decode( $src ) ) : false;
		if ( false === $path ) {
			return;
		}
		$orig = (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		WPSS_Stats::add( 'img_orig', $orig );
		$served = $orig;
		if ( false !== strpos( $tag, '<picture' ) ) {
			foreach ( array( 'avif', 'webp' ) as $ext ) {
				if ( false !== strpos( $tag, 'image/' . $ext ) && is_file( $path . '.' . $ext ) ) {
					$served = min( $served, (int) @filesize( $path . '.' . $ext ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					break;
				}
			}
		}
		WPSS_Stats::add( 'img_served', $served );
	}

	/**
	 * @param string $tag  Tag.
	 * @param string $name Attribute.
	 * @return string|null
	 */
	private static function attr( $tag, $name ) {
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '\s*=\s*(["\'])(.*?)\1/is', $tag, $m ) ) {
			return $m[2];
		}
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '\s*=\s*([^\s>"\']+)/i', $tag, $m ) ) {
			return $m[1];
		}
		return null;
	}

	/**
	 * Add loading="lazy" unless the image is (likely) above the fold or managed elsewhere.
	 *
	 * @param string $tag Tag.
	 */
	private static function add_lazy( $tag ) {
		if ( null !== self::attr( $tag, 'loading' ) || null !== self::attr( $tag, 'data-no-lazy' ) ) {
			return $tag;
		}
		$fp = self::attr( $tag, 'fetchpriority' );
		if ( null !== $fp && 'high' === strtolower( $fp ) ) {
			return $tag; // Hero / LCP image.
		}
		if ( null !== self::attr( $tag, 'data-src' ) || null !== self::attr( $tag, 'data-lazy-src' ) || null !== self::attr( $tag, 'data-lazyload' ) ) {
			return $tag; // Another lazy loader (e.g. Revolution Slider) manages it.
		}
		$class = strtolower( (string) self::attr( $tag, 'class' ) );
		foreach ( array( 'logo', 'no-lazy', 'skip-lazy', 'wpss-no-lazy', 'hero' ) as $c ) {
			if ( false !== strpos( $class, $c ) ) {
				return $tag;
			}
		}
		$src = (string) self::attr( $tag, 'src' );
		if ( '' === $src || 0 === stripos( $src, 'data:' ) || false !== stripos( basename( (string) wp_parse_url( $src, PHP_URL_PATH ) ), 'logo' ) ) {
			return $tag;
		}
		$add = ' loading="lazy"';
		if ( null === self::attr( $tag, 'decoding' ) ) {
			$add .= ' decoding="async"';
		}
		return preg_replace( '/^<img\b/i', '<img' . $add, $tag );
	}

	/**
	 * Add width/height when both are missing and the file is local (reduces CLS).
	 *
	 * @param string $tag Tag.
	 */
	private static function add_dimensions( $tag ) {
		if ( null !== self::attr( $tag, 'width' ) || null !== self::attr( $tag, 'height' ) ) {
			return $tag;
		}
		$src = (string) self::attr( $tag, 'src' );
		if ( '' === $src || 0 === stripos( $src, 'data:' ) || preg_match( '/\.svg(\?|$)/i', $src ) ) {
			return $tag;
		}
		$path = WPSS_FS::url_to_path( html_entity_decode( $src ) );
		if ( false === $path ) {
			return $tag;
		}
		$size = wp_getimagesize( $path );
		if ( empty( $size[0] ) || empty( $size[1] ) ) {
			return $tag;
		}
		self::$dims_added = true;
		return preg_replace( '/^<img\b/i', '<img width="' . (int) $size[0] . '" height="' . (int) $size[1] . '" data-wpss-dim', $tag );
	}

	/**
	 * Wrap in <picture> when AVIF/WebP copies exist for src (and every srcset candidate).
	 *
	 * @param string $tag Tag.
	 */
	private static function picture( $tag ) {
		$src = self::attr( $tag, 'src' );
		if ( null === $src || 0 === stripos( $src, 'data:' ) ) {
			return $tag;
		}
		$sources = '';
		$formats = array();
		if ( WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) {
			$formats['avif'] = 'image/avif';
		}
		if ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) {
			$formats['webp'] = 'image/webp';
		}
		foreach ( $formats as $ext => $mime ) {
			$set = self::variant_srcset( $tag, html_entity_decode( $src ), $ext );
			if ( false !== $set ) {
				$sizes    = self::attr( $tag, 'sizes' );
				$sources .= '<source type="' . esc_attr( $mime ) . '" srcset="' . esc_attr( $set ) . '"' . ( null !== $sizes ? ' sizes="' . esc_attr( $sizes ) . '"' : '' ) . '>';
				if ( null === self::$last_picture ) {
					// Preload must match the source the browser picks (the first supported one).
					$single              = false === strpos( $set, ',' ) && ! preg_match( '/\s\d+[wx]$/', trim( $set ) );
					self::$last_picture = array(
						'href'   => $single ? $set : html_entity_decode( $src, ENT_QUOTES ),
						'srcset' => $single ? '' : $set,
						'sizes'  => null !== $sizes ? html_entity_decode( $sizes, ENT_QUOTES ) : '',
						'type'   => $mime,
					);
				}
			}
		}
		// If a WebP copy exists, make the actual <img> src/srcset point at WebP too.
		// This makes DevTools and browser requests clearly show WebP, while data-wpss-original-*
		// attributes retain the original URL for a safe fallback on very old browsers.
		if ( ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) && false !== self::variant_url( html_entity_decode( $src ), 'webp' ) ) {
			$webp = self::variant_url( html_entity_decode( $src ), 'webp' );
			$tag  = self::prefer_webp_tag( $tag, $webp );
		}
		return '' === $sources ? $tag : '<picture class="wpss-picture" style="display:contents">' . $sources . $tag . '</picture>';
	}

	/**
	 * Prefer an existing WebP URL in the actual img element while retaining the
	 * original as a fallback. Modern browsers therefore request WebP directly;
	 * older browsers can recover through onerror.
	 *
	 * @param string $tag  Image tag.
	 * @param string $webp WebP URL.
	 * @return string
	 */
	private static function prefer_webp_tag( $tag, $webp ) {
		$src = self::attr( $tag, 'src' );
		if ( null === $src || '' === $src || '' === $webp || false !== stripos( $src, '.webp' ) ) {
			return $tag;
		}
		if ( null === self::attr( $tag, 'data-wpss-original-src' ) ) {
			$tag = preg_replace( '/^<img\b/i', '<img data-wpss-original-src="' . esc_attr( html_entity_decode( $src, ENT_QUOTES ) ) . '"', $tag );
		}
		$tag = preg_replace( '/\s+src\s*=\s*(\"|\')(.*?)\1/i', ' src="' . esc_attr( $webp ) . '"', $tag, 1 );
		if ( false === stripos( $tag, 'data-wpss-webp="1"' ) ) {
			$tag = preg_replace( '/^<img\b/i', '<img data-wpss-webp="1"', $tag );
		}
		// Very old clients that cannot decode WebP fall back to the original.
		if ( false === stripos( $tag, 'onerror=' ) ) {
			$tag = preg_replace( '/^<img\b/i', '<img onerror="if(this.dataset.wpssFallbackApplied)return;this.dataset.wpssFallbackApplied=1;this.src=this.dataset.wpssOriginalSrc;"', $tag );
		}
		return $tag;
	}

	/**
	 * Srcset string using $ext copies, or false unless ALL candidates have a copy.
	 *
	 * @param string $tag Tag.
	 * @param string $src Src.
	 * @param string $ext avif|webp.
	 * @return string|false
	 */
	private static function variant_srcset( $tag, $src, $ext ) {
		$srcset = self::attr( $tag, 'srcset' );
		if ( null === $srcset ) {
			$v = self::variant_url( $src, $ext );
			return false === $v ? false : $v;
		}
		$out = array();
		foreach ( explode( ',', html_entity_decode( $srcset ) ) as $cand ) {
			$cand = trim( $cand );
			if ( '' === $cand ) {
				continue;
			}
			$parts = preg_split( '/\s+/', $cand, 2 );
			$v     = self::variant_url( $parts[0], $ext );
			// A partially converted responsive set should still use the converted
			// candidates that exist instead of disabling WebP for the whole image.
			if ( false === $v ) {
				continue;
			}
			$out[] = $v . ( isset( $parts[1] ) ? ' ' . $parts[1] : '' );
		}
		return $out ? implode( ', ', $out ) : false;
	}

	/**
	 * URL of an existing, up-to-date copy: file.jpg.webp or file.webp.
	 *
	 * @param string $url URL.
	 * @param string $ext Extension.
	 * @return string|false
	 */
	private static function variant_url( $url, $ext ) {
		if ( ! preg_match( '/\.(jpe?g|png)(\?.*)?$/i', $url ) ) {
			return false;
		}
		$path = WPSS_FS::url_to_path( $url );
		if ( false === $path ) {
			return false;
		}
		$clean = preg_replace( '/\?.*$/', '', $url );
		$replaced_path = preg_replace( '/\.(jpe?g|png)$/i', '.' . $ext, $path );
		$replaced_url  = preg_replace( '/\.(jpe?g|png)$/i', '.' . $ext, $clean );
		$cands = array(
			array( $replaced_path, $replaced_url ),
			array( $path . '.' . $ext, $clean . '.' . $ext ),
		);
		$mtime = (int) @filemtime( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		foreach ( $cands as $c ) {
			if ( is_file( $c[0] ) && (int) @filemtime( $c[0] ) >= $mtime && @filesize( $c[0] ) > 0 ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				return $c[1];
			}
		}
		return false;
	}

	/* ---------------------------------------------------------------------
	 * WebP copy generation (never modifies originals)
	 * ------------------------------------------------------------------- */

	/**
	 * @param array $meta          Metadata.
	 * @param int   $attachment_id ID.
	 */
	public static function on_metadata( $meta, $attachment_id ) {
		if ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) {
			self::generate_for( $attachment_id, $meta );
		}
		return $meta;
	}

	/**
	 * Create WebP copies for the original and all sizes.
	 *
	 * @param int        $id   Attachment.
	 * @param array|null $meta Metadata.
	 * @return int Copies created.
	 */
	public static function optimize_attachment( $id ) {
		$id = absint( $id );
		if ( ! $id || ! wp_attachment_is_image( $id ) ) {
			return 0;
		}
		return self::generate_for( $id );
	}

	public static function generate_for( $id, $meta = null ) {
		$file = get_attached_file( $id );
		if ( ! $file ) {
			return 0;
		}
		$meta  = is_array( $meta ) ? $meta : wp_get_attachment_metadata( $id );
		$files = array( $file );
		if ( ! empty( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $s ) {
				if ( ! empty( $s['file'] ) ) {
					$files[] = path_join( dirname( $file ), $s['file'] );
				}
			}
		}
		return self::generate_files( $files );
	}

	/**
	 * Generate smaller WebP/AVIF copies for a list of local JPEG/PNG files.
	 * Originals are never modified.
	 *
	 * @param string[] $files Local image paths.
	 * @return int Number of copies created.
	 */

	/**
	 * Write a WebP derivative using WordPress first, then GD/Imagick directly.
	 * This makes conversion reliable on hosts where WP reports WebP support
	 * incorrectly or a custom image editor is unavailable.
	 *
	 * @param string $source Source image path.
	 * @param string $dest Destination WebP path.
	 * @param int    $quality WebP quality.
	 * @return bool True on success.
	 */
	private static function write_webp( $source, $dest, $quality = 82 ) {
		$editor = wp_get_image_editor( $source );
		if ( ! is_wp_error( $editor ) ) {
			$editor->set_quality( $quality );
			$saved = $editor->save( $dest, 'image/webp' );
			if ( ! is_wp_error( $saved ) && is_file( $dest ) && filesize( $dest ) > 0 ) {
				return true;
			}
		}

		// GD fallback.
		if ( function_exists( 'imagewebp' ) ) {
			$mime = function_exists( 'mime_content_type' ) ? @mime_content_type( $source ) : ''; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$im   = false;
			if ( 'image/png' === $mime && function_exists( 'imagecreatefrompng' ) ) {
				$im = @imagecreatefrompng( $source ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			} elseif ( function_exists( 'imagecreatefromjpeg' ) ) {
				$im = @imagecreatefromjpeg( $source ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
			if ( $im ) {
				if ( function_exists( 'imagepalettetotruecolor' ) ) {
					@imagepalettetotruecolor( $im ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				}
				if ( function_exists( 'imagealphablending' ) ) {
					@imagealphablending( $im, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				}
				if ( function_exists( 'imagesavealpha' ) ) {
					@imagesavealpha( $im, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				}
				$ok = @imagewebp( $im, $dest, max( 1, min( 100, $quality ) ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				imagedestroy( $im );
				if ( $ok && is_file( $dest ) && filesize( $dest ) > 0 ) {
					return true;
				}
			}
		}

		// Imagick fallback.
		if ( class_exists( 'Imagick' ) ) {
			try {
				$im = new Imagick();
				$im->readImage( $source );
				if ( method_exists( $im, 'setIteratorIndex' ) ) {
					$im->setIteratorIndex( 0 );
				}
				$im->setImageFormat( 'webp' );
				$im->setImageCompressionQuality( max( 1, min( 100, $quality ) ) );
				$im->stripImage();
				$ok = $im->writeImage( $dest );
				$im->clear();
				$im->destroy();
				if ( $ok && is_file( $dest ) && filesize( $dest ) > 0 ) {
					return true;
				}
			} catch ( Throwable $e ) {
				WPSS_Logger::log( 'Imagick WebP conversion failed: ' . $e->getMessage() );
			}
		}
		return false;
	}

	private static function generate_files( $files ) {
		$formats = array();
		// WebP is the primary automatic format. Do NOT gate the feature only on
		// wp_image_editor_supports(): some hosts expose GD/Imagick WebP encoding
		// but WordPress reports the MIME as unsupported. The actual writer below
		// has a direct GD/Imagick fallback, so the user's WebP setting really does
		// convert the images instead of silently reporting 0 copies created.
		if ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) {
			$formats['webp'] = array( 'image/webp', 82 );
		}
		if ( WPSS_Settings::get( 'img_avif' ) && self::avif_supported() ) {
			$formats['avif'] = array( 'image/avif', 60 );
		}
		if ( ! $formats ) {
			return 0;
		}

		$made = 0;
		foreach ( array_unique( (array) $files ) as $f ) {
			$f = wp_normalize_path( $f );
			if ( ! is_file( $f ) || ! preg_match( '/\.(jpe?g|png)$/i', $f ) ) {
				continue;
			}
			foreach ( $formats as $ext => $fmt ) {
				$dest = preg_replace( '/\.(jpe?g|png)$/i', '.' . $ext, $f );
				$legacy_dest = $f . '.' . $ext;
				if ( $dest && is_file( $dest ) && (int) @filemtime( $dest ) >= (int) @filemtime( $f ) && (int) @filesize( $dest ) > 0 ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					continue;
				}
				if ( is_file( $legacy_dest ) && (int) @filemtime( $legacy_dest ) >= (int) @filemtime( $f ) && (int) @filesize( $legacy_dest ) > 0 ) {
					continue;
				}
				$saved = self::write_webp( $f, $dest, (int) $fmt[1] );
				if ( ! $saved || ! is_file( $dest ) || (int) @filesize( $dest ) <= 0 ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					if ( is_file( $dest ) ) {
						wp_delete_file( $dest );
					}
					WPSS_Logger::log( 'WebP conversion failed: ' . $f );
					continue;
				}
				// The user explicitly enabled WebP delivery, so keep a valid WebP copy
				// even if a particular source JPEG happens to be smaller. The frontend
				// will therefore always have a real WebP resource to request.
				++$made;
			}
		}
		return $made;
	}

	/**
	 * Start a background conversion of all JPEG/PNG images under wp-content.
	 */
	public static function start_bulk() {
		$ids = self::media_attachment_ids();
		update_option(
			self::BULK,
			array(
				'offset'       => 0,
				'done'         => 0,
				'scanned'      => 0,
				'running'      => 1,
				'total'        => count( $ids ),
				'media_total'  => count( $ids ),
				'media_done'   => 0,
				'frontend_done'=> 0,
				'started'      => time(),
				'scope'        => 'media-v2',
			),
			false
		);
		if ( ! wp_next_scheduled( 'wpss_webp_batch' ) ) {
			wp_schedule_single_event( time() + 5, 'wpss_webp_batch' );
		}
	}

	/**
	 * Cron: convert the next 15 website images.
	 */
	public static function batch() {
		$state = get_option( self::BULK, array() );
		if ( ! is_array( $state ) ) {
			$state = array();
		}
		$enabled = WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' );
		if ( ! $enabled ) {
			return;
		}

		$ids    = self::media_attachment_ids();
		$total  = count( $ids );
		$offset = isset( $state['offset'] ) ? max( 0, (int) $state['offset'] ) : 0;
		$batch  = array_slice( $ids, $offset, 10 );
		$made   = 0;

		foreach ( $batch as $id ) {
			$made += self::generate_for( (int) $id );
		}

		$state['total']       = $total;
		$state['media_total'] = $total;
		$state['offset']      = $offset + count( $batch );
		$state['scanned']     = $state['offset'];
		$state['media_done']  = $state['offset'];
		$state['done']        = (int) ( $state['done'] ?? 0 ) + $made;

		// Process a small number of frontend-discovered files as well. This covers
		// theme/plugin images and other local images that are not Media Library attachments.
		$frontend = self::frontend_queue();
		$f_batch  = array_slice( $frontend, 0, 10 );
		$f_made   = 0;
		if ( $f_batch ) {
			$f_made = self::generate_files( $f_batch );
			$remaining_front = array_values( array_diff( $frontend, $f_batch ) );
			update_option( self::FRONTEND_QUEUE, $remaining_front, false );
			$state['frontend_done'] = (int) ( $state['frontend_done'] ?? 0 ) + count( $f_batch );
			$state['done'] += $f_made;
		}

		if ( $state['offset'] >= $total && empty( self::frontend_queue() ) ) {
			$state['running'] = 0;
			$state['scanned'] = $total;
			update_option( self::BULK, $state, false );
			WPSS_Logger::log( sprintf( 'Media Library image conversion finished (%d Media Library items, %d WebP/AVIF copies created).', $total, (int) $state['done'] ) );
			if ( class_exists( 'WPSS_Page_Cache' ) ) {
				WPSS_Page_Cache::purge_all( 'Image format conversion completed' );
			}
			return;
		}

		$state['running'] = 1;
		update_option( self::BULK, $state, false );
		if ( ! wp_next_scheduled( 'wpss_webp_batch' ) ) {
			wp_schedule_single_event( time() + 15, 'wpss_webp_batch' );
		}
	}

	/**
	 * Return local JPEG/PNG files under wp-content, excluding caches and generated formats.
	 *
	 * This intentionally includes uploads, themes and plugins so images referenced
	 * outside the Media Library can also receive WebP/AVIF derivatives.
	 *
	 * @return string[]
	 */
	private static function all_image_files() {
		$root = realpath( WP_CONTENT_DIR );
		if ( ! $root || ! is_dir( $root ) ) {
			return array();
		}
		$files = array();
		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
			foreach ( $iterator as $file ) {
				if ( $file->isFile() && preg_match( '/\\.(jpe?g|png)$/i', $file->getPathname() ) ) {
					$files[] = wp_normalize_path( $file->getPathname() );
				}
			}
		} catch ( Throwable $e ) {
			WPSS_Logger::log( 'Website image scan failed: ' . $e->getMessage() );
		}
		sort( $files, SORT_STRING );
		return $files;
	}

	/** Return Media Library attachment IDs, one progress item per uploaded image. */
	private static function media_attachment_ids() {
		$ids = get_posts( array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		) );
		return array_map( 'intval', (array) $ids );
	}

	/** Queue a local frontend image for conversion. */
	private static function queue_frontend_path( $path ) {
		$path = wp_normalize_path( (string) $path );
		if ( ! $path || ! is_file( $path ) || ! preg_match( '/\\.(jpe?g|png)$/i', $path ) ) {
			return;
		}
		$queue = self::frontend_queue();
		if ( ! in_array( $path, $queue, true ) ) {
			$queue[] = $path;
			update_option( self::FRONTEND_QUEUE, array_values( array_unique( $queue ) ), false );
		}
	}

	/** Discover local image URLs actually rendered on a frontend page. */
	private static function queue_frontend_images_from_html( $html ) {
		if ( ! WPSS_Context::optimize() ) {
			return;
		}
		$urls = array();
		if ( preg_match_all( "/(?:src|data-src|data-lazy-src|poster)\\s*=\\s*[\"']([^\"']+)[\"']/i", $html, $m ) ) {
			$urls = array_merge( $urls, $m[1] );
		}
		if ( preg_match_all( "/(?:srcset|data-srcset)\\s*=\\s*[\"']([^\"']+)[\"']/i", $html, $m ) ) {
			foreach ( $m[1] as $set ) {
				foreach ( explode( ',', $set ) as $candidate ) {
					$parts = preg_split( '/\\s+/', trim( $candidate ) );
					if ( ! empty( $parts[0] ) ) {
						$urls[] = $parts[0];
					}
				}
			}
		}
		if ( preg_match_all( "/url\\(\\s*[\"']?([^\"')]+)[\"']?\\s*\\)/i", $html, $m ) ) {
			$urls = array_merge( $urls, $m[1] );
		}
		foreach ( $urls as $url ) {
			$url = html_entity_decode( trim( $url ), ENT_QUOTES );
			if ( ! $url || 0 === stripos( $url, 'data:' ) || 0 === stripos( $url, '#' ) ) {
				continue;
			}
			$path = WPSS_FS::url_to_path( $url );
			if ( false !== $path ) {
				self::queue_frontend_path( $path );
			}
		}
	}

	private static function frontend_queue() {
		$q = get_option( self::FRONTEND_QUEUE, array() );
		return is_array( $q ) ? array_values( array_filter( $q, 'is_string' ) ) : array();
	}

	/**
	 * Process one background image batch immediately. Used by the admin progress UI
	 * as a fallback when WP-Cron is delayed or disabled.
	 *
	 * @return array Current bulk state.
	 */
	public static function process_batch_now() {
		self::batch();
		return self::bulk_state();
	}

	/**
	 * Can this server encode AVIF (WordPress 6.5+ with a capable GD/Imagick)?
	 */
	public static function avif_supported() {
		return wp_image_editor_supports( array( 'mime_type' => 'image/avif' ) );
	}

	/**
	 * Remove our copies with the attachment.
	 *
	 * @param int $id Attachment.
	 */
	public static function on_delete( $id ) {
		$file = get_attached_file( $id );
		if ( ! $file ) {
			return;
		}
		$meta  = wp_get_attachment_metadata( $id );
		$files = array( $file );
		if ( ! empty( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $s ) {
				if ( ! empty( $s['file'] ) ) {
					$files[] = path_join( dirname( $file ), $s['file'] );
				}
			}
		}
		foreach ( $files as $f ) {
			foreach ( array( '.webp', '.avif' ) as $ext ) {
				$legacy = $f . $ext;
				$replaced = preg_replace( '/\.(jpe?g|png)$/i', $ext, $f );
				foreach ( array( $legacy, $replaced ) as $copy ) {
					if ( $copy && is_file( $copy ) ) {
						wp_delete_file( $copy );
					}
				}
			}
		}
	}

	/**
	 * Start a background bulk conversion.
	 */
	/** Return the current number of JPEG/PNG source images under wp-content. */
	public static function image_count() {
		return count( self::media_attachment_ids() );
	}

	public static function frontend_queue_count() {
		return count( self::frontend_queue() );
	}

	public static function bulk_state() {
		$s = get_option( self::BULK, array() );
		return is_array( $s ) ? $s : array();
	}
}
