<?php
/**
 * Admin performance report: before/after sizes and request counts (from per-page render
 * statistics) and Core Web Vitals field data from real visitors (anonymous, sampled).
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Report {

	const CWV     = 'wpss_cwv';
	const SAMPLES = 'wpss_cwv_samples';

	/**
	 * Fold rum.log into rolling samples (last 28 days, max 3000) and daily p75 values.
	 */
	public static function aggregate_rum() {
		$file = WPSS_CACHE_DIR . '/data/rum.log';
		if ( ! is_file( $file ) ) {
			return;
		}
		$tmp = $file . '.' . wp_rand( 1000, 9999 );
		if ( ! @rename( $file, $tmp ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.rename_rename
			return;
		}
		$samples = get_option( self::SAMPLES, array() );
		$samples = is_array( $samples ) ? $samples : array();
		foreach ( (array) file( $tmp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) as $line ) {
			$row = json_decode( (string) $line, true );
			if ( is_array( $row ) && 6 === count( $row ) ) {
				$samples[] = $row;
			}
		}
		wp_delete_file( $tmp );
		$cut     = time() - 28 * DAY_IN_SECONDS;
		$samples = array_values(
			array_filter(
				$samples,
				static function ( $r ) use ( $cut ) {
					return (int) $r[0] >= $cut;
				}
			)
		);
		$samples = array_slice( $samples, -3000 );
		update_option( self::SAMPLES, $samples, false );

		$daily = array();
		foreach ( $samples as $r ) {
			$day                         = gmdate( 'Y-m-d', (int) $r[0] );
			$daily[ $day ][ $r[1] ][]    = $r;
		}
		$out = array();
		foreach ( $daily as $day => $devs ) {
			foreach ( $devs as $dev => $rows ) {
				$out[ $day ][ $dev ] = self::p75_rows( $rows );
			}
		}
		ksort( $out );
		update_option( self::CWV, $out, false );
	}

	/**
	 * p75 of LCP, CLS, INP for sample rows.
	 *
	 * @param array $rows Rows.
	 */
	public static function p75_rows( $rows ) {
		$p = static function ( $vals ) {
			if ( ! $vals ) {
				return null;
			}
			sort( $vals );
			return $vals[ (int) floor( 0.75 * ( count( $vals ) - 1 ) ) ];
		};
		$inp = array_values(
			array_filter(
				array_column( $rows, 4 ),
				static function ( $v ) {
					return $v > 0;
				}
			)
		);
		return array(
			'lcp' => $p( array_column( $rows, 2 ) ),
			'cls' => $p( array_column( $rows, 3 ) ),
			'inp' => $p( $inp ),
			'n'   => count( $rows ),
		);
	}

	/**
	 * Field data summary for the last N days per device.
	 *
	 * @param int $days Days.
	 * @return array dev => p75 row
	 */
	public static function field_summary( $days = 28 ) {
		$samples = get_option( self::SAMPLES, array() );
		$cut     = time() - $days * DAY_IN_SECONDS;
		$by      = array();
		foreach ( is_array( $samples ) ? $samples : array() as $r ) {
			if ( (int) $r[0] >= $cut ) {
				$by[ $r[1] ][] = $r;
			}
		}
		$out = array();
		foreach ( $by as $dev => $rows ) {
			$out[ $dev ] = self::p75_rows( $rows );
		}
		return $out;
	}

	/**
	 * Google's published thresholds (good / needs improvement / poor).
	 *
	 * @param string    $metric lcp|cls|inp.
	 * @param float|int $v      Value.
	 */
	public static function rating( $metric, $v ) {
		if ( null === $v ) {
			return '';
		}
		$t = array(
			'lcp' => array( 2500, 4000 ),
			'cls' => array( 0.1, 0.25 ),
			'inp' => array( 200, 500 ),
		);
		if ( $v <= $t[ $metric ][0] ) {
			return 'good';
		}
		return $v <= $t[ $metric ][1] ? 'needs-improvement' : 'poor';
	}

	/**
	 * Totals over the stored page reports (latest per page/device).
	 *
	 * @return array{pages:int,before:array,after:array,rows:array}
	 */
	public static function totals() {
		$reports = WPSS_Stats::reports();
		$sum     = static function ( $key ) use ( $reports ) {
			$t = 0;
			foreach ( $reports as $r ) {
				$t += (int) ( $r['stats'][ $key ] ?? 0 );
			}
			return $t;
		};
		$n = max( 1, count( $reports ) );
		return array(
			'pages'  => count( $reports ),
			'before' => array(
				'css'      => $sum( 'css_orig' ) / $n,
				'blocking' => $sum( 'css_orig' ) / $n,
				'js'       => $sum( 'js_orig' ) / $n,
				'img'      => $sum( 'img_orig' ) / $n,
				'requests' => ( $sum( 'css_req_before' ) + $sum( 'js_req_before' ) + $sum( 'img_count' ) ) / $n,
			),
			'after'  => array(
				'css'      => $sum( 'css_opt' ) / $n,
				'blocking' => ( $sum( 'css_opt' ) - $sum( 'css_async_bytes' ) + $sum( 'critical_bytes' ) ) / $n,
				'js'       => $sum( 'js_opt' ) / $n,
				'img'      => $sum( 'img_served' ) / $n,
				'requests' => ( $sum( 'css_req_after' ) + $sum( 'js_req_after' ) + $sum( 'img_count' ) - $sum( 'img_lazy' ) ) / $n,
			),
			'rows'   => $reports,
		);
	}
}
