<?php
/**
 * Rule-level CSS filter used by "Remove unused CSS".
 *
 * The browser analysis reports selectors it proved unused. This parser walks the original
 * stylesheet text and drops only style rules whose (normalized) selector list is in that set.
 * Everything it does not fully understand is kept verbatim, and any structural surprise makes
 * the whole operation return false so the complete stylesheet is served instead.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_CSS_Parser {

	/** At-rules whose body contains rules (recursed into). */
	const GROUPING = array( 'media', 'supports', 'layer', 'container', 'document', '-moz-document', 'scope', 'starting-style' );

	/**
	 * Normalize a selector list so that the browser's serialization and the source text compare
	 * equal when (and only when) they differ in insignificant ways. Must stay identical to
	 * normSel() in assets/analyzer.js.
	 *
	 * @param string $s Selector text.
	 */
	public static function normalize_selector( $s ) {
		$s = preg_replace( '#/\*.*?\*/#s', '', (string) $s );
		$s = trim( preg_replace( '/\s+/', ' ', $s ) );
		$s = preg_replace( '/\s*([>+~,])\s*/', '$1', $s );
		$s = preg_replace_callback(
			'/::?(before|after|first-line|first-letter)\b/i',
			static function ( $m ) {
				return ':' . strtolower( $m[1] );
			},
			$s
		);
		$s = preg_replace_callback(
			'/\[\s*([^\]=~|^$*\s"\']+)\s*([~|^$*]?=)\s*(["\']?)([^"\'\]]*?)\3\s*(\s[iIsS])?\s*\]/',
			static function ( $m ) {
				return '[' . $m[1] . $m[2] . $m[4] . ( isset( $m[5] ) && '' !== trim( $m[5] ) ? ' ' . strtolower( trim( $m[5] ) ) : '' ) . ']';
			},
			$s
		);
		return $s;
	}

	/**
	 * Remove style rules whose selector is unused.
	 *
	 * @param string   $css      Stylesheet text.
	 * @param array    $unused   Normalized selector => true.
	 * @param int|null $removed  Out: bytes removed.
	 * @return string|false Filtered CSS, or false when the stylesheet could not be parsed safely.
	 */
	public static function remove_unused( $css, array $unused, &$removed = null ) {
		$removed = 0;
		if ( empty( $unused ) ) {
			return $css;
		}
		$keep = static function ( $prelude ) use ( $unused ) {
			return ! isset( $unused[ self::normalize_selector( $prelude ) ] );
		};
		return self::filter( $css, $keep, $removed );
	}

	/**
	 * Generic filter: $keep( $selector_prelude ) decides for every style rule.
	 *
	 * @param string   $css     CSS.
	 * @param callable $keep    Callback.
	 * @param int      $removed Out: bytes removed.
	 * @return string|false
	 */
	public static function filter( $css, $keep, &$removed = 0 ) {
		$css     = (string) $css;
		$len     = strlen( $css );
		$i       = 0;
		$removed = 0;
		if ( $len > 5 * 1024 * 1024 ) {
			return false;
		}
		$out = self::block( $css, $i, $len, $keep, 0, $removed );
		if ( false === $out || $i < $len ) {
			return false;
		}
		return $out;
	}

	/**
	 * Parse a list of rules until "}" (depth > 0) or end of input.
	 *
	 * @param string   $css     CSS.
	 * @param int      $i       Offset (by ref).
	 * @param int      $len     Length.
	 * @param callable $keep    Callback.
	 * @param int      $depth   Nesting depth.
	 * @param int      $removed Bytes removed (by ref).
	 * @return string|false
	 */
	private static function block( $css, &$i, $len, $keep, $depth, &$removed ) {
		$out = '';
		while ( $i < $len ) {
			$c = $css[ $i ];
			if ( ' ' === $c || "\n" === $c || "\t" === $c || "\r" === $c || "\f" === $c ) {
				++$i;
				continue;
			}
			if ( '/' === $c && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return false;
				}
				if ( '!' === ( $css[ $i + 2 ] ?? '' ) ) {
					$out .= substr( $css, $i, $end + 2 - $i ); // License comment.
				}
				$i = $end + 2;
				continue;
			}
			if ( '}' === $c ) {
				if ( 0 === $depth ) {
					return false; // Unbalanced.
				}
				return $out; // Caller consumes the brace.
			}

			$term    = '';
			$prelude = self::prelude( $css, $i, $len, $term );
			if ( false === $prelude ) {
				return false;
			}
			if ( ';' === $term ) {
				$out .= $prelude . ';'; // @import, @charset, @layer a, b; or stray text.
				++$i;
				continue;
			}
			if ( '}' === $term || '' === $term ) {
				if ( '' === $term && '' !== trim( $prelude ) ) {
					return false; // Text after the last rule without a block.
				}
				$out .= $prelude; // Declarations inside nested rules.
				continue;
			}

			// $term === '{'.
			++$i;
			$pt = trim( $prelude );
			if ( '@' === ( $pt[0] ?? '' ) ) {
				$name = strtolower( (string) preg_replace( '/^@([-a-zA-Z]+).*$/s', '$1', $pt ) );
				if ( in_array( $name, self::GROUPING, true ) ) {
					$inner = self::block( $css, $i, $len, $keep, $depth + 1, $removed );
					if ( false === $inner || $i >= $len || '}' !== $css[ $i ] ) {
						return false;
					}
					++$i;
					if ( '' !== trim( $inner ) || 'layer' === $name ) {
						$out .= $pt . '{' . $inner . '}';
					}
					continue;
				}
				$body = self::raw_block( $css, $i, $len );
				if ( false === $body ) {
					return false;
				}
				$out .= $pt . '{' . $body . '}';
				continue;
			}
			$body = self::raw_block( $css, $i, $len );
			if ( false === $body ) {
				return false;
			}
			if ( '' === $pt || call_user_func( $keep, $pt ) ) {
				$out .= $pt . '{' . $body . '}';
			} else {
				$removed += strlen( $pt ) + strlen( $body ) + 2;
			}
		}
		return $depth > 0 ? false : $out;
	}

	/**
	 * Read a prelude up to "{", ";" or "}" (outside strings, comments and parentheses).
	 *
	 * @param string $css  CSS.
	 * @param int    $i    Offset (by ref) – left on the terminator.
	 * @param int    $len  Length.
	 * @param string $term Out: terminator char or '' at end of input.
	 * @return string|false
	 */
	private static function prelude( $css, &$i, $len, &$term ) {
		$start  = $i;
		$parens = 0;
		while ( $i < $len ) {
			$c = $css[ $i ];
			if ( '\\' === $c ) {
				$i += 2;
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				$end = self::string_end( $css, $i, $len );
				if ( false === $end ) {
					return false;
				}
				$i = $end + 1;
				continue;
			}
			if ( '/' === $c && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return false;
				}
				$i = $end + 2;
				continue;
			}
			if ( '(' === $c ) {
				++$parens;
			} elseif ( ')' === $c ) {
				--$parens;
			} elseif ( 0 === $parens && ( '{' === $c || ';' === $c || '}' === $c ) ) {
				$term = $c;
				return substr( $css, $start, $i - $start );
			}
			++$i;
		}
		$term = '';
		return substr( $css, $start, $i - $start );
	}

	/**
	 * Body of a block up to its matching "}" (strings/comments aware). Leaves $i after the brace.
	 *
	 * @param string $css CSS.
	 * @param int    $i   Offset just after "{" (by ref).
	 * @param int    $len Length.
	 * @return string|false
	 */
	private static function raw_block( $css, &$i, $len ) {
		$start = $i;
		$depth = 1;
		while ( $i < $len ) {
			$c = $css[ $i ];
			if ( '\\' === $c ) {
				$i += 2;
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				$end = self::string_end( $css, $i, $len );
				if ( false === $end ) {
					return false;
				}
				$i = $end + 1;
				continue;
			}
			if ( '/' === $c && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return false;
				}
				$i = $end + 2;
				continue;
			}
			if ( '{' === $c ) {
				++$depth;
			} elseif ( '}' === $c ) {
				--$depth;
				if ( 0 === $depth ) {
					$body = substr( $css, $start, $i - $start );
					++$i;
					return $body;
				}
			}
			++$i;
		}
		return false;
	}

	/**
	 * Closing quote offset of a CSS string, or false.
	 *
	 * @param string $s   CSS.
	 * @param int    $i   Opening quote offset.
	 * @param int    $len Length.
	 * @return int|false
	 */
	private static function string_end( $s, $i, $len ) {
		$q = $s[ $i ];
		for ( $j = $i + 1; $j < $len; $j++ ) {
			$ch = $s[ $j ];
			if ( '\\' === $ch ) {
				++$j;
				continue;
			}
			if ( "\n" === $ch ) {
				return false;
			}
			if ( $ch === $q ) {
				return $j;
			}
		}
		return false;
	}
}
