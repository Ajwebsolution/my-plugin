<?php
/**
 * Smart cache warmup.
 *
 * After an invalidation only the affected URLs are queued (changed pages first, then the home
 * page, then frequently visited pages). A background job warms a small batch per minute
 * (configurable) so the server is never flooded. Popular pages come from a lightweight hit log
 * written by the page cache (no database writes per request).
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Warmup {

	const QUEUE   = 'wpss_warm_queue';
	const POPULAR = 'wpss_popular';
	const HOOK    = 'wpss_warm';

	const PRIO_CHANGED = 300;
	const PRIO_HOME    = 200;
	const PRIO_POPULAR = 100;

	const MAX_QUEUE = 1000;

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
	}

	/**
	 * @return array url => priority
	 */
	public static function queue() {
		$q = get_option( self::QUEUE, array() );
		return is_array( $q ) ? $q : array();
	}

	/**
	 * Queue URLs (same site only).
	 *
	 * @param string[] $urls URLs.
	 * @param int      $prio Priority.
	 */
	public static function add( $urls, $prio ) {
		if ( ! WPSS_Settings::get( 'warm' ) || ! WPSS_Settings::get( 'page_cache' ) ) {
			return;
		}
		$q    = self::queue();
		$home = WPSS_FS::home_host();
		$max  = (int) WPSS_Settings::get( 'warm_max' );
		$new  = 0;
		foreach ( (array) $urls as $url ) {
			$url = esc_url_raw( (string) $url );
			if ( '' === $url || WPSS_FS::url_host( $url ) !== $home ) {
				continue;
			}
			// A URL whose path equals the home page always gets the home priority at least.
			$p = '/' === (string) wp_parse_url( $url, PHP_URL_PATH ) ? max( $prio, self::PRIO_HOME ) : $prio;
			if ( ! isset( $q[ $url ] ) || $q[ $url ] < $p ) {
				if ( ! isset( $q[ $url ] ) ) {
					++$new;
				}
				$q[ $url ] = $p;
			}
			if ( $new >= $max ) {
				break; // Per-invalidation limit.
			}
		}
		arsort( $q );
		$q = array_slice( $q, 0, self::MAX_QUEUE, true );
		update_option( self::QUEUE, $q, false );
		self::schedule();
	}

	/**
	 * After a full purge: home page + most visited pages (never the whole site).
	 */
	public static function after_purge() {
		$urls = array( home_url( '/' ) );
		self::add( $urls, self::PRIO_HOME );
		$pop = array_slice( array_keys( self::popular() ), 0, max( 0, (int) WPSS_Settings::get( 'warm_max' ) - 1 ) );
		if ( $pop ) {
			self::add( $pop, self::PRIO_POPULAR );
		}
	}

	/**
	 * Schedule the next batch (60 s gap keeps the load low).
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 60, self::HOOK );
		}
	}

	/**
	 * Warm one batch.
	 */
	public static function run() {
		if ( ! WPSS_Settings::get( 'warm' ) || ! WPSS_Settings::get( 'page_cache' ) || WPSS_Settings::safe_mode() ) {
			delete_option( self::QUEUE );
			return;
		}
		// Back off when the server is busy.
		if ( function_exists( 'sys_getloadavg' ) ) {
			$load = @sys_getloadavg(); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( is_array( $load ) && $load[0] > 4 * self::cpus() ) {
				self::schedule();
				return;
			}
		}
		$q = self::queue();
		if ( ! $q ) {
			return;
		}
		arsort( $q );
		$batch = array_slice( array_keys( $q ), 0, (int) WPSS_Settings::get( 'warm_batch' ) );
		foreach ( $batch as $url ) {
			unset( $q[ $url ] );
		}
		update_option( self::QUEUE, $q, false );

		$start = microtime( true );
		$uas   = array( 'desktop' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36 SteadySpeedWarmup' );
		if ( WPSS_Settings::get( 'cache_mobile' ) ) {
			$uas['mobile'] = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36 SteadySpeedWarmup';
		}
		$done = 0;
		foreach ( $batch as $url ) {
			if ( microtime( true ) - $start > 25 ) {
				$q[ $url ] = self::PRIO_POPULAR; // Out of time: back in the queue.
				continue;
			}
			foreach ( $uas as $ua ) {
				wp_remote_get(
					$url,
					array(
						'timeout'     => 15,
						'redirection' => 2,
						'user-agent'  => $ua,
						'headers'     => array( 'X-WPSS-Warmup' => '1' ),
						'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core filter.
						'cookies'     => array(),
					)
				);
			}
			++$done;
		}
		if ( $done ) {
			WPSS_Logger::log( sprintf( 'Cache warmup: %d page(s) warmed, %d waiting', $done, count( $q ) ), 'debug' );
		}
		if ( count( $q ) !== count( self::queue() ) ) {
			update_option( self::QUEUE, $q, false );
		}
		if ( $q ) {
			self::schedule();
		}
	}

	/**
	 * CPU count (best effort).
	 */
	private static function cpus() {
		$n = 1;
		if ( is_readable( '/proc/cpuinfo' ) ) {
			$n = max( 1, substr_count( (string) @file_get_contents( '/proc/cpuinfo' ), 'processor' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}
		return $n;
	}

	/**
	 * @return array url => score (most visited first)
	 */
	public static function popular() {
		$p = get_option( self::POPULAR, array() );
		return is_array( $p ) ? $p : array();
	}

	/**
	 * Fold the hit log into the popularity list (hourly cron). Scores decay so the list follows
	 * current traffic.
	 */
	public static function aggregate_hits() {
		$file = WPSS_CACHE_DIR . '/data/hits.log';
		if ( ! is_file( $file ) ) {
			return;
		}
		$tmp = $file . '.' . wp_rand( 1000, 9999 );
		if ( ! @rename( $file, $tmp ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.rename_rename
			return;
		}
		$counts = array();
		$fh     = @fopen( $tmp, 'r' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$total  = 0;
		if ( $fh ) {
			while ( false !== ( $line = fgets( $fh ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
				$u = trim( $line );
				if ( '' !== $u && strlen( $u ) < 2000 ) {
					$counts[ $u ] = ( $counts[ $u ] ?? 0 ) + 1;
					++$total;
				}
			}
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		}
		wp_delete_file( $tmp );
		$pop = self::popular();
		foreach ( $pop as $u => $score ) {
			$pop[ $u ] = $score * 0.8; // Decay.
		}
		foreach ( $counts as $u => $c ) {
			$pop[ $u ] = ( $pop[ $u ] ?? 0 ) + $c;
		}
		$pop = array_filter(
			$pop,
			static function ( $s ) {
				return $s >= 0.5;
			}
		);
		arsort( $pop );
		update_option( self::POPULAR, array_slice( $pop, 0, 200, true ), false );
		$stats          = get_option( 'wpss_hit_stats', array() );
		$stats          = is_array( $stats ) ? $stats : array();
		$day            = gmdate( 'Y-m-d' );
		$stats[ $day ]  = ( $stats[ $day ] ?? 0 ) + $total;
		ksort( $stats );
		update_option( 'wpss_hit_stats', array_slice( $stats, -30, null, true ), false );
	}
}
