<?php
/**
 * Settings storage, defaults and sanitization.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Settings {

	const OPTION      = 'wpss_settings';
	const SAFE_OPTION = 'wpss_safe_mode';

	/** @var array|null */
	private static $cache = null;

	/**
	 * Defaults: stability first.
	 */
	public static function defaults() {
		return array(
			// Page cache.
			'page_cache'         => 1,
			'cache_ttl'          => 36000,
			'cache_mobile'       => 1,
			'cache_skip_nonce'   => 1,
			'cache_ignore_qs'    => "utm_source\nutm_medium\nutm_campaign\nutm_term\nutm_content\nfbclid\ngclid\nmsclkid\n_ga",
			'never_cache_urls'   => '',
			// CSS / JS.
			'css_opt'            => 1,
			'css_mode'           => 'safe',
			'js_opt'             => 1,
			'js_mode'            => 'safe',
			'delay_list'         => '',
			// Images.
			'lazy'               => 1,
			'lazy_skip'          => 3,
			'img_opt'            => 0,
			'img_all'             => 0,
			'img_dimensions'     => 0,
			// Browser cache.
			'browser_cache'      => 1,
			// Protection.
			'elementor_compat'   => 1,
			'slider_protect'     => 1,
			'header_protect'     => 1,
			'error_detect'       => 1,
			// Developer.
			'debug'              => 0,
			'optimize_logged_in' => 0,
			// Fonts (all opt-in; can change design).
			'font_preconnect'    => 0,
			'font_swap'          => 0,
			'font_local'         => 0,
			'font_disable'       => 0,
			// ---- 1.1: performance mode (preset selector; 'custom' once toggles are edited).
			'perf_mode'          => 'safe',
			// Advanced CSS.
			'critical_css'       => 0,
			'css_async'          => 0,
			'rucss'              => 0,
			'rucss_mode'         => 'safe',
			// Advanced JavaScript.
			'js_delay_noncritical' => 0,
			'tp_delay'           => 0,
			'tp_mode'            => 'safe',
			'tp_trigger'         => 'interaction',
			'tp_timeout'         => 5,
			// Core Web Vitals.
			'lcp_opt'            => 0,
			'lcp_preload'        => 0,
			'atf_opt'            => 0,
			'inp_opt'            => 0,
			'preload'            => 0,
			'hints'              => 0,
			// Images (img_mode is a preset selector for the image toggles).
			'img_mode'           => 'safe',
			'img_avif'           => 0,
			'img_srcset'         => 0,
			'iframe_lazy'        => 0,
			// Fonts.
			'font_preload'       => 0,
			'font_prune'         => 0,
			// Elementor.
			'el_asset_opt'       => 1,
			'el_widget_detect'   => 1,
			'el_css_opt'         => 0,
			// Page analysis (critical CSS / unused CSS / LCP data).
			'analysis_bg'        => 1,
			// Cache warmup.
			'warm'               => 1,
			'warm_batch'         => 5,
			'warm_max'           => 50,
			// Field data (Core Web Vitals from real visitors, anonymous).
			'cwv'                => 0,
			'cwv_rate'           => 10,
			// Exclusions.
			'excl_critical'      => '',
			'excl_rucss'         => '',
			'excl_tp'            => '',
			'excl_all'           => '',
			'excl_minify'        => '',
			'excl_combine'       => '',
			'excl_defer'         => '',
			'excl_delay'         => '',
			'excl_urls'          => '',
		);
	}

	/**
	 * Checkbox keys.
	 */
	public static function checkboxes() {
		return array( 'page_cache', 'cache_mobile', 'cache_skip_nonce', 'css_opt', 'js_opt', 'lazy', 'img_opt', 'img_all', 'img_dimensions', 'browser_cache', 'elementor_compat', 'slider_protect', 'header_protect', 'error_detect', 'debug', 'optimize_logged_in', 'font_preconnect', 'font_swap', 'font_local', 'font_disable', 'critical_css', 'css_async', 'rucss', 'js_delay_noncritical', 'tp_delay', 'lcp_opt', 'lcp_preload', 'atf_opt', 'inp_opt', 'preload', 'hints', 'img_avif', 'img_srcset', 'iframe_lazy', 'font_preload', 'font_prune', 'el_asset_opt', 'el_widget_detect', 'el_css_opt', 'analysis_bg', 'warm', 'cwv' );
	}

	/**
	 * Which keys belong to which admin form (so saving one tab never resets another).
	 */
	public static function tabs() {
		return array(
			'mode'       => array( 'perf_mode' ),
			'settings'   => array( 'page_cache', 'cache_ttl', 'cache_mobile', 'cache_skip_nonce', 'cache_ignore_qs', 'css_opt', 'css_mode', 'js_opt', 'js_mode', 'lazy', 'lazy_skip', 'browser_cache', 'elementor_compat', 'slider_protect', 'header_protect', 'error_detect', 'debug', 'optimize_logged_in' ),
			'advanced'   => array( 'critical_css', 'css_async', 'rucss', 'rucss_mode', 'js_delay_noncritical', 'tp_delay', 'tp_mode', 'tp_trigger', 'tp_timeout', 'lcp_opt', 'lcp_preload', 'atf_opt', 'inp_opt', 'preload', 'hints', 'img_dimensions', 'img_mode', 'img_opt', 'img_all', 'img_avif', 'img_srcset', 'iframe_lazy', 'font_preconnect', 'font_swap', 'font_local', 'font_disable', 'font_preload', 'font_prune', 'el_asset_opt', 'el_widget_detect', 'el_css_opt', 'analysis_bg', 'warm', 'warm_batch', 'warm_max', 'cwv', 'cwv_rate' ),
			'exclusions' => array( 'excl_all', 'excl_minify', 'excl_combine', 'excl_defer', 'excl_delay', 'delay_list', 'excl_urls', 'never_cache_urls', 'excl_critical', 'excl_rucss', 'excl_tp' ),
		);
	}

	/**
	 * Performance presets. Only the keys listed here are changed by a preset; everything else
	 * (page cache, protections, exclusions, developer options) is never touched.
	 *
	 * @return array mode => settings
	 */
	public static function presets() {
		$safe = array(
			'css_mode'             => 'safe',
			'js_mode'              => 'safe',
			'critical_css'         => 0,
			'css_async'            => 0,
			'rucss'                => 0,
			'rucss_mode'           => 'safe',
			'js_delay_noncritical' => 0,
			'tp_delay'             => 0,
			'tp_mode'              => 'safe',
			'lcp_opt'              => 0,
			'lcp_preload'          => 0,
			'atf_opt'              => 0,
			'inp_opt'              => 0,
			'preload'              => 0,
			'hints'                => 0,
			'img_dimensions'       => 0,
			'font_preconnect'      => 0,
			'font_swap'            => 0,
			'font_preload'         => 0,
			'el_css_opt'           => 0,
			'cwv'                  => 0,
		) + self::img_presets()['safe'];

		$balanced = array_merge(
			$safe,
			array(
				'css_mode'        => 'balanced',
				'js_mode'         => 'balanced',
				'critical_css'    => 1,
				'css_async'       => 1,
				'tp_delay'        => 1,
				'lcp_opt'         => 1,
				'lcp_preload'     => 1,
				'atf_opt'         => 1,
				'preload'         => 1,
				'hints'           => 1,
				'img_dimensions'  => 1,
				'font_preconnect' => 1,
				'font_swap'       => 1,
				'font_preload'    => 1,
				'cwv'             => 1,
			),
			self::img_presets()['balanced']
		);

		$performance = array_merge(
			$balanced,
			array(
				'js_mode'              => 'aggressive',
				'rucss'                => 1,
				'rucss_mode'           => 'balanced',
				'js_delay_noncritical' => 1,
				'tp_mode'              => 'advanced',
				'inp_opt'              => 1,
				'el_css_opt'           => 1,
			),
			self::img_presets()['advanced']
		);

		return array(
			'safe'        => $safe,
			'balanced'    => $balanced,
			'performance' => $performance,
		);
	}

	/**
	 * Image optimization mode presets (img_mode).
	 */
	public static function img_presets() {
		return array(
			'safe'     => array(
				'img_opt'     => 0,
				'img_avif'    => 0,
				'img_srcset'  => 0,
				'iframe_lazy' => 0,
			),
			'balanced' => array(
				'img_opt'     => 1,
				'img_avif'    => 0,
				'img_srcset'  => 1,
				'iframe_lazy' => 1,
			),
			'advanced' => array(
				'img_opt'     => 1,
				'img_avif'    => 1,
				'img_srcset'  => 1,
				'iframe_lazy' => 1,
			),
		);
	}

	/**
	 * Which preset (if any) the values match.
	 *
	 * @param array  $values  Settings.
	 * @param array  $presets Presets.
	 * @return string Preset key or 'custom'.
	 */
	public static function matching_preset( $values, $presets ) {
		foreach ( $presets as $name => $preset ) {
			$match = true;
			foreach ( $preset as $k => $v ) {
				if ( ! isset( $values[ $k ] ) || (string) $values[ $k ] !== (string) $v ) {
					$match = false;
					break;
				}
			}
			if ( $match ) {
				return $name;
			}
		}
		return 'custom';
	}

	/**
	 * All settings merged with defaults.
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	/**
	 * Single value.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Clear the in-request cache.
	 */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Textarea setting as a list of non-empty, non-comment lines.
	 *
	 * @param string $key Key.
	 * @return string[]
	 */
	public static function lines( $key ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get( $key ) ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line && '#' !== $line[0] ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/**
	 * Emergency Safe Mode: option toggle or constant in wp-config.php.
	 */
	public static function safe_mode() {
		if ( defined( 'WPSS_SAFE_MODE' ) && WPSS_SAFE_MODE ) {
			return true;
		}
		return (bool) get_option( self::SAFE_OPTION, false );
	}

	/**
	 * Settings API sanitize callback.
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input   = is_array( $input ) ? $input : array();
		$current = get_option( self::OPTION, array() );
		$out     = wp_parse_args( is_array( $current ) ? $current : array(), self::defaults() );
		$tabs    = self::tabs();
		$full    = ! isset( $input['_tab'] );
		$tab     = $full ? '' : sanitize_key( $input['_tab'] );
		$keys    = $full ? array_keys( self::defaults() ) : ( isset( $tabs[ $tab ] ) ? $tabs[ $tab ] : array() );
		$boxes   = self::checkboxes();

		foreach ( $keys as $key ) {
			$present = array_key_exists( $key, $input );
			if ( $full && ! $present ) {
				continue;
			}
			$value = $present ? $input[ $key ] : null;

			if ( in_array( $key, $boxes, true ) ) {
				$out[ $key ] = empty( $value ) ? 0 : 1;
			} elseif ( in_array( $key, array( 'css_mode', 'js_mode', 'rucss_mode' ), true ) ) {
				$out[ $key ] = in_array( $value, array( 'safe', 'balanced', 'aggressive' ), true ) ? $value : 'safe';
			} elseif ( 'perf_mode' === $key ) {
				$out[ $key ] = in_array( $value, array( 'safe', 'balanced', 'performance', 'custom' ), true ) ? $value : 'custom';
			} elseif ( 'img_mode' === $key ) {
				$out[ $key ] = in_array( $value, array( 'safe', 'balanced', 'advanced', 'custom' ), true ) ? $value : 'custom';
			} elseif ( 'tp_mode' === $key ) {
				$out[ $key ] = in_array( $value, array( 'safe', 'advanced' ), true ) ? $value : 'safe';
			} elseif ( 'tp_trigger' === $key ) {
				$out[ $key ] = in_array( $value, array( 'interaction', 'idle', 'timeout' ), true ) ? $value : 'interaction';
			} elseif ( 'tp_timeout' === $key ) {
				$out[ $key ] = min( 30, max( 1, absint( $value ) ) );
			} elseif ( 'warm_batch' === $key ) {
				$out[ $key ] = min( 20, max( 1, absint( $value ) ) );
			} elseif ( 'warm_max' === $key ) {
				$out[ $key ] = min( 500, max( 1, absint( $value ) ) );
			} elseif ( 'cwv_rate' === $key ) {
				$out[ $key ] = min( 100, max( 1, absint( $value ) ) );
			} elseif ( 'cache_ttl' === $key ) {
				$out[ $key ] = min( WEEK_IN_SECONDS, max( 300, absint( $value ) ) );
			} elseif ( 'lazy_skip' === $key ) {
				$out[ $key ] = min( 20, absint( $value ) );
			} else {
				$out[ $key ] = sanitize_textarea_field( (string) $value );
			}
		}
		return self::apply_presets( $out, is_array( $current ) ? $current : array(), $keys );
	}

	/**
	 * Preset logic: choosing a (different) preset applies it; editing individual toggles turns the
	 * selector into "custom" unless the values happen to match a preset exactly.
	 *
	 * @param array $out     Sanitized values.
	 * @param array $current Previously stored values.
	 * @param array $keys    Keys submitted in this save.
	 * @return array
	 */
	private static function apply_presets( $out, $current, $keys ) {
		$prev_img  = isset( $current['img_mode'] ) ? $current['img_mode'] : '';
		$prev_perf = isset( $current['perf_mode'] ) ? $current['perf_mode'] : '';
		$img       = self::img_presets();
		$perf      = self::presets();

		// Image mode first (a performance preset below may override it again).
		if ( in_array( 'img_mode', $keys, true ) && isset( $img[ $out['img_mode'] ] ) && $out['img_mode'] !== $prev_img ) {
			$out = array_merge( $out, $img[ $out['img_mode'] ] );
		}
		if ( in_array( 'perf_mode', $keys, true ) && isset( $perf[ $out['perf_mode'] ] ) && $out['perf_mode'] !== $prev_perf ) {
			$out = array_merge( $out, $perf[ $out['perf_mode'] ] );
		}
		// WebP is an automatic delivery feature: when enabled, generate WebP
		// derivatives for the whole site (uploads, themes and plugins) and serve
		// them automatically through <picture>. Originals are never replaced.
		if ( ! empty( $out['img_opt'] ) ) {
			$out['img_all']    = 1;
			$out['img_srcset'] = 1;
		}

		$out['img_mode']  = self::matching_preset( $out, $img );
		$out['perf_mode'] = self::matching_preset( $out, $perf );
		return $out;
	}
}
