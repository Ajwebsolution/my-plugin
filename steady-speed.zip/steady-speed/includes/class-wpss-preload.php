<?php
/**
 * Preload manager + resource hints (final HTML pass).
 *
 * Deliberately small: at most ONE image preload (the likely LCP resource), at most TWO font
 * preloads (fonts used by above-the-fold text, from the page analysis), at most three
 * preconnects to origins that serve render-critical files, and dns-prefetch for delayed
 * third-party origins. Never every image/CSS/JS file: that causes network contention.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Preload {

	const MAX_FONTS       = 2;
	const MAX_PRECONNECT  = 3;
	const MAX_DNSPREFETCH = 4;

	/** @var array|null Set by WPSS_Images for the LCP image: href, srcset, sizes, type. */
	public static $lcp_image = null;

	/**
	 * @param string $html HTML.
	 */
	public static function process( $html ) {
		if ( ! WPSS_Context::optimize() || WPSS_Analysis::is_analysis_request() ) {
			return $html;
		}
		$rec  = WPSS_Analysis::for_request();
		$tags = array();

		// ---- LCP image.
		if ( WPSS_Settings::get( 'lcp_opt' ) && WPSS_Settings::get( 'lcp_preload' ) ) {
			$p = self::$lcp_image;
			if ( ! $p && $rec && ! empty( $rec['lcp'] ) && in_array( $rec['lcp']['type'], array( 'bg', 'video' ), true ) && '' !== $rec['lcp']['src'] ) {
				$p = array( 'href' => $rec['lcp']['src'] );
				WPSS_Stats::set( 'lcp', ( 'bg' === $rec['lcp']['type'] ? 'Background image: ' : 'Video poster: ' ) . wp_basename( (string) wp_parse_url( $rec['lcp']['src'], PHP_URL_PATH ) ) );
			}
			if ( $p && ! empty( $p['href'] ) && ! self::already( $html, 'preload', $p['href'] ) ) {
				$t = '<link rel="preload" as="image" href="' . esc_url( $p['href'] ) . '" fetchpriority="high"';
				if ( ! empty( $p['srcset'] ) ) {
					$t .= ' imagesrcset="' . esc_attr( $p['srcset'] ) . '"';
					if ( ! empty( $p['sizes'] ) ) {
						$t .= ' imagesizes="' . esc_attr( $p['sizes'] ) . '"';
					}
				}
				if ( ! empty( $p['type'] ) ) {
					$t .= ' type="' . esc_attr( $p['type'] ) . '"';
				}
				$tags[] = $t . '>';
				WPSS_Stats::add( 'preloads' );
			}
		}
		if ( $rec && ! empty( $rec['lcp'] ) && 'text' === $rec['lcp']['type'] && ! WPSS_Stats::get( 'lcp' ) ) {
			WPSS_Stats::set( 'lcp', 'Text block <' . $rec['lcp']['tag'] . '>' );
		}

		// ---- Critical fonts.
		if ( WPSS_Settings::get( 'font_preload' ) && $rec && ! empty( $rec['fonts'] ) ) {
			$n = 0;
			foreach ( $rec['fonts'] as $f ) {
				if ( $n >= self::MAX_FONTS ) {
					break;
				}
				$url  = $f['url'];
				$host = WPSS_FS::url_host( $url );
				if ( '' !== $host && $host !== WPSS_FS::home_host() && 'fonts.gstatic.com' !== $host ) {
					continue;
				}
				if ( self::already( $html, 'preload', $url ) ) {
					continue;
				}
				$tags[] = '<link rel="preload" as="font" type="font/woff2" href="' . esc_url( $url ) . '" crossorigin>';
				++$n;
				WPSS_Stats::add( 'preloads' );
			}
		}

		// ---- Resource hints.
		if ( WPSS_Settings::get( 'hints' ) ) {
			foreach ( self::critical_origins( $html ) as $origin => $cors ) {
				if ( self::already( $html, 'preconnect', $origin ) ) {
					continue;
				}
				$tags[] = '<link rel="preconnect" href="' . esc_url( $origin ) . '"' . ( $cors ? ' crossorigin' : '' ) . '>';
				WPSS_Stats::add( 'hints' );
			}
			$n = 0;
			foreach ( (array) WPSS_Stats::get( 'tp_hosts' ) as $host ) {
				if ( $n >= self::MAX_DNSPREFETCH || ! is_string( $host ) || self::already( $html, 'dns-prefetch', $host ) || self::already( $html, 'preconnect', $host ) ) {
					continue;
				}
				$tags[] = '<link rel="dns-prefetch" href="//' . esc_attr( $host ) . '">';
				++$n;
				WPSS_Stats::add( 'hints' );
			}
		}

		if ( ! $tags ) {
			return $html;
		}
		return self::insert_head( $html, implode( '', $tags ) );
	}

	/**
	 * Is there already a hint of this kind for the URL/host?
	 *
	 * @param string $html HTML.
	 * @param string $rel  Rel.
	 * @param string $url  URL or host.
	 */
	private static function already( $html, $rel, $url ) {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		$needle = 'preload' === $rel ? $url : ( '' !== $host ? $host : $url );
		if ( ! preg_match_all( '#<link\b[^>]*rel=["\']?' . preg_quote( $rel, '#' ) . '["\'\s>][^>]*>#i', $html, $m ) ) {
			return false;
		}
		foreach ( $m[0] as $tag ) {
			if ( false !== strpos( html_entity_decode( $tag ), $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * External origins serving render-critical resources, most important first.
	 *
	 * @param string $html HTML.
	 * @return array origin => needs crossorigin
	 */
	private static function critical_origins( $html ) {
		$home = WPSS_FS::home_host();
		$out  = array();
		$head = substr( $html, 0, (int) stripos( $html, '</head>' ) );
		// Google Fonts: the stylesheet host is referenced; the font files come from gstatic.
		if ( false !== stripos( $html, 'fonts.googleapis.com' ) && ! WPSS_Settings::get( 'font_local' ) ) {
			$out['https://fonts.gstatic.com'] = true;
		}
		if ( preg_match_all( '#<link\b[^>]*rel=["\']?stylesheet[^>]*>#i', $head, $m ) ) {
			foreach ( $m[0] as $tag ) {
				if ( preg_match( '/href=["\']((?:https?:)?\/\/([^\/"\']+))/i', $tag, $h ) && strtolower( $h[2] ) !== $home && false === stripos( $tag, 'media="print"' ) ) {
					$out[ 'https://' . strtolower( $h[2] ) ] = false !== strpos( $h[2], 'fonts.' );
				}
			}
		}
		if ( preg_match_all( '#<script\b[^>]*\ssrc=["\']((?:https?:)?//([^/"\']+))[^>]*>#i', $head, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $s ) {
				if ( strtolower( $s[2] ) !== $home && ! preg_match( '/\s(async|defer)\b|wpss\/delayed/i', $s[0] ) ) {
					$out[ 'https://' . strtolower( $s[2] ) ] = false;
				}
			}
		}
		if ( self::$lcp_image && ! empty( self::$lcp_image['href'] ) ) {
			$h = WPSS_FS::url_host( self::$lcp_image['href'] );
			if ( '' !== $h && $h !== $home ) {
				$out[ 'https://' . $h ] = false;
			}
		}
		return array_slice( $out, 0, self::MAX_PRECONNECT, true );
	}

	/**
	 * Insert right after <meta charset> (or at the start of <head>).
	 *
	 * @param string $html HTML.
	 * @param string $tags Tags.
	 */
	private static function insert_head( $html, $tags ) {
		$head_end = stripos( $html, '</head>' );
		if ( false === $head_end ) {
			return $html;
		}
		if ( preg_match( '#<meta\b[^>]*charset[^>]*>#i', substr( $html, 0, $head_end ), $m, PREG_OFFSET_CAPTURE ) ) {
			$pos = $m[0][1] + strlen( $m[0][0] );
			return substr_replace( $html, $tags, $pos, 0 );
		}
		if ( preg_match( '#<head\b[^>]*>#i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			$pos = $m[0][1] + strlen( $m[0][0] );
			return substr_replace( $html, $tags, $pos, 0 );
		}
		return $html;
	}
}
