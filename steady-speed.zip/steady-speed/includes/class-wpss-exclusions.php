<?php
/**
 * User exclusion lists and automatic (error-driven) exclusions.
 *
 * Pattern syntax (one per line):
 *   handle:elementor-frontend   exact script/style handle
 *   plugin:revslider            everything inside /plugins/revslider/
 *   /themes/my-theme/js/*.js    wildcard match against the source URL
 *   swiper                      exact handle, or partial match of the source URL (file name, path)
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Exclusions {

	const AUTO     = 'wpss_auto_exclusions';
	const AUTO_URL = 'wpss_auto_url_exclusions';

	/**
	 * Patterns for a scope: all|minify|combine|defer|delay.
	 *
	 * @param string $scope Scope.
	 * @return string[]
	 */
	public static function patterns( $scope ) {
		return WPSS_Settings::lines( 'excl_' . $scope );
	}

	/**
	 * Does one pattern match a handle/source?
	 *
	 * @param string $p      Pattern.
	 * @param string $handle Handle.
	 * @param string $src    Source URL.
	 */
	public static function matches( $p, $handle, $src ) {
		$p = trim( (string) $p );
		if ( '' === $p ) {
			return false;
		}
		if ( 0 === stripos( $p, 'handle:' ) ) {
			return strtolower( trim( substr( $p, 7 ) ) ) === strtolower( (string) $handle );
		}
		if ( 0 === stripos( $p, 'plugin:' ) ) {
			$slug = trim( substr( $p, 7 ), " /\t" );
			return '' !== $slug && false !== stripos( (string) $src, '/plugins/' . $slug . '/' );
		}
		if ( false !== strpos( $p, '*' ) ) {
			return self::wildcard( $p, (string) $src ) || self::wildcard( $p, (string) $handle );
		}
		if ( '' !== (string) $handle && strtolower( $p ) === strtolower( (string) $handle ) ) {
			return true;
		}
		return '' !== (string) $src && false !== stripos( (string) $src, $p );
	}

	/**
	 * First matching pattern of a list, or false.
	 *
	 * @param string[] $patterns Patterns.
	 * @param string   $handle   Handle.
	 * @param string   $src      Source.
	 * @return string|false
	 */
	public static function match_list( $patterns, $handle, $src ) {
		foreach ( (array) $patterns as $p ) {
			if ( self::matches( $p, $handle, $src ) ) {
				return $p;
			}
		}
		return false;
	}

	/**
	 * Case-insensitive "*" wildcard match anywhere in the subject.
	 *
	 * @param string $pattern Pattern.
	 * @param string $subject Subject.
	 */
	public static function wildcard( $pattern, $subject ) {
		$regex = '#' . str_replace( '\*', '.*', preg_quote( $pattern, '#' ) ) . '#i';
		return (bool) preg_match( $regex, (string) $subject );
	}

	/* ---------------------------------------------------------------------
	 * Automatic exclusions (written by WPSS_Monitor).
	 * ------------------------------------------------------------------- */

	/** Strike history (key => count) so repeat offenders are protected for longer. */
	const HISTORY = 'wpss_auto_history';

	/**
	 * Protection period for the Nth strike: 7 days, 30 days, then permanent (until removed).
	 *
	 * @param int $strike Strike number (1-based).
	 * @return int Seconds, 0 = permanent.
	 */
	public static function protection_period( $strike ) {
		if ( $strike <= 1 ) {
			return 7 * DAY_IN_SECONDS;
		}
		if ( 2 === $strike ) {
			return 30 * DAY_IN_SECONDS;
		}
		return 0;
	}

	/**
	 * Active automatic exclusions. Expired temporary ones are ignored (the asset is retried).
	 *
	 * @param bool $include_expired Include expired entries (admin listing).
	 * @return array key => array(scope, reason, time, until, strike)
	 */
	public static function auto( $include_expired = false ) {
		$v = get_option( self::AUTO, array() );
		$v = is_array( $v ) ? $v : array();
		if ( $include_expired ) {
			return $v;
		}
		$now = time();
		return array_filter(
			$v,
			static function ( $info ) use ( $now ) {
				return empty( $info['until'] ) || (int) $info['until'] > $now;
			}
		);
	}

	/**
	 * Drop expired entries (cron). Their strike history is kept.
	 */
	public static function prune_expired() {
		$changed = false;
		foreach ( array( self::AUTO => array( self::auto( true ), self::auto() ), self::AUTO_URL => array( self::auto_urls( true ), self::auto_urls() ) ) as $option => $sets ) {
			list( $all, $live ) = $sets;
			if ( count( $all ) === count( $live ) ) {
				continue;
			}
			update_option( $option, $live, true );
			foreach ( array_keys( array_diff_key( $all, $live ) ) as $key ) {
				WPSS_Logger::log( sprintf( 'Protection period ended for %s – optimization will be retried.', $key ) );
			}
			$changed = true;
		}
		if ( $changed && class_exists( 'WPSS_Page_Cache' ) ) {
			WPSS_Page_Cache::queue_purge_all( 'Temporary protection ended (retrying optimization)' );
		}
	}

	/**
	 * Auto exclusion entry matching a source URL.
	 *
	 * @param string $src Source.
	 * @return array|false
	 */
	public static function auto_match( $src ) {
		if ( '' === (string) $src ) {
			return false;
		}
		foreach ( self::auto() as $key => $info ) {
			if ( '' !== $key && false !== stripos( $src, $key ) ) {
				return $info;
			}
		}
		return false;
	}

	/**
	 * @param string $key    Relative file key (e.g. plugins/foo/slider.js).
	 * @param string $scope  all|combine.
	 * @param string $reason Reason.
	 */
	public static function add_auto( $key, $scope, $reason ) {
		$history         = get_option( self::HISTORY, array() );
		$history         = is_array( $history ) ? $history : array();
		$strike          = isset( $history[ $key ] ) ? (int) $history[ $key ] + 1 : 1;
		$history[ $key ] = $strike;
		if ( count( $history ) > 500 ) {
			$history = array_slice( $history, -500, null, true );
		}
		update_option( self::HISTORY, $history, false );

		$period      = self::protection_period( $strike );
		$all         = self::auto( true );
		$all[ $key ] = array(
			'scope'  => 'combine' === $scope ? 'combine' : 'all',
			'reason' => sanitize_text_field( $reason ),
			'time'   => time(),
			'until'  => $period ? time() + $period : 0,
			'strike' => $strike,
		);
		update_option( self::AUTO, $all, true );
		WPSS_Logger::log(
			sprintf(
				'Auto-excluded %s (%s): %s – %s',
				$key,
				$all[ $key ]['scope'],
				$reason,
				$period ? sprintf( 'original served for %d days, then optimization is retried', $period / DAY_IN_SECONDS ) : 'protected permanently after repeated failures'
			),
			'warning'
		);
	}

	/**
	 * @param string $key Key.
	 */
	public static function remove_auto( $key ) {
		$all = self::auto( true );
		unset( $all[ $key ] );
		update_option( self::AUTO, $all, true );
		$history = get_option( self::HISTORY, array() );
		if ( is_array( $history ) && isset( $history[ $key ] ) ) {
			unset( $history[ $key ] ); // Manual removal = fresh start.
			update_option( self::HISTORY, $history, false );
		}
	}

	/**
	 * @return array path => info
	 */
	public static function auto_urls( $include_expired = false ) {
		$v = get_option( self::AUTO_URL, array() );
		$v = is_array( $v ) ? $v : array();
		if ( $include_expired ) {
			return $v;
		}
		$now = time();
		return array_filter(
			$v,
			static function ( $info ) use ( $now ) {
				return empty( $info['until'] ) || (int) $info['until'] > $now;
			}
		);
	}

	/**
	 * @param string $path   Request path.
	 * @param string $reason Reason.
	 */
	public static function add_auto_url( $path, $reason ) {
		$history                   = get_option( self::HISTORY, array() );
		$history                   = is_array( $history ) ? $history : array();
		$hk                        = 'url:' . $path;
		$strike                    = isset( $history[ $hk ] ) ? (int) $history[ $hk ] + 1 : 1;
		$history[ $hk ]            = $strike;
		update_option( self::HISTORY, $history, false );
		$period       = self::protection_period( $strike );
		$all          = self::auto_urls( true );
		$all[ $path ] = array(
			'reason' => sanitize_text_field( $reason ),
			'time'   => time(),
			'until'  => $period ? time() + $period : 0,
			'strike' => $strike,
		);
		update_option( self::AUTO_URL, $all, true );
		WPSS_Logger::log( sprintf( 'Optimization disabled for page %s: %s', $path, $reason ), 'warning' );
	}

	/**
	 * @param string $path Path.
	 */
	public static function remove_auto_url( $path ) {
		$all = self::auto_urls( true );
		unset( $all[ $path ] );
		update_option( self::AUTO_URL, $all, true );
	}

	/**
	 * Is the current request path auto-excluded?
	 */
	public static function url_auto_excluded() {
		$all = self::auto_urls();
		if ( empty( $all ) ) {
			return false;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		return isset( $all[ $path ] ) || isset( $all[ untrailingslashit( $path ) ] ) || isset( $all[ trailingslashit( $path ) ] );
	}
}
