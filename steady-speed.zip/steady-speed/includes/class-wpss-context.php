<?php
/**
 * Per-request decisions: may this response be optimized?
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Context {

	/** @var bool|null */
	private static $optimize = null;

	/**
	 * Page builders / previews (never optimize or cache these).
	 */
	public static function is_editor_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only detection.
		$keys = array( 'elementor-preview', 'elementor_library', 'fl_builder', 'et_fb', 'ct_builder', 'brizy-edit', 'brizy-edit-iframe', 'vc_editable', 'vc_action', 'tve', 'bricks', 'oxygen_iframe', 'customize_changeset_uuid', 'customize_theme', 'preview', 'preview_id', 'preview_nonce' );
		foreach ( $keys as $key ) {
			if ( isset( $_GET[ $key ] ) ) {
				return true;
			}
		}
		if ( isset( $_GET['action'] ) && 'elementor' === $_GET['action'] ) {
			return true;
		}
		// phpcs:enable
		return false;
	}

	/**
	 * AJAX / REST / JSON.
	 */
	public static function is_rest_like() {
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_is_json_request() ) {
			return true;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return false !== strpos( $uri, '/wp-json/' ) || isset( $_GET['rest_route'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Does the current request URI match any pattern? (substring, or "*" wildcards)
	 *
	 * @param string[] $patterns Patterns.
	 */
	public static function url_in_list( $patterns ) {
		if ( empty( $patterns ) ) {
			return false;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		foreach ( $patterns as $p ) {
			if ( false !== strpos( $p, '*' ) ) {
				if ( WPSS_Exclusions::wildcard( $p, $uri ) ) {
					return true;
				}
			} elseif ( false !== stripos( $uri, $p ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Transactional pages (WooCommerce cart, checkout, account): scripts are never delayed there.
	 */
	public static function is_transactional() {
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
			return true;
		}
		return (bool) apply_filters( 'wpss_is_transactional_page', false );
	}

	/**
	 * Admin previewing the optimized front end with ?wpss_debug=1.
	 */
	public static function admin_debug_preview() {
		return isset( $_GET['wpss_debug'] ) && function_exists( 'current_user_can' ) && did_action( 'init' ) && current_user_can( 'manage_options' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * May we optimize assets/HTML for this request? Resolved once after template_redirect starts.
	 */
	public static function optimize() {
		if ( null !== self::$optimize ) {
			return self::$optimize;
		}
		if ( ! did_action( 'template_redirect' ) ) {
			return false;
		}
		self::$optimize = self::compute();
		return self::$optimize;
	}

	/**
	 * Decision logic.
	 */
	private static function compute() {
		if ( WPSS_Settings::safe_mode() ) {
			return false;
		}
		if ( is_admin() || self::is_rest_like() || is_feed() || is_robots() || is_trackback() || is_embed() || is_customize_preview() || is_preview() || self::is_editor_request() ) {
			return false;
		}
		if ( defined( 'DONOTOPTIMIZE' ) && DONOTOPTIMIZE ) {
			return false;
		}
		// Dynamic requests: form posts, WooCommerce AJAX/API endpoints, logins.
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
			return false;
		}
		if ( isset( $_GET['wc-ajax'] ) || isset( $_GET['wc-api'] ) || wp_doing_ajax() || ( isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
			return false;
		}
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			return false;
		}
		if ( isset( $_GET['wpss_disable'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- comparison view, never cached.
			return false;
		}
		if ( is_user_logged_in() && ! WPSS_Settings::get( 'optimize_logged_in' ) && ! self::admin_debug_preview() ) {
			return false;
		}
		if ( self::url_in_list( WPSS_Settings::lines( 'excl_urls' ) ) || WPSS_Exclusions::url_auto_excluded() ) {
			return false;
		}
		return (bool) apply_filters( 'wpss_optimize_request', true );
	}
}
