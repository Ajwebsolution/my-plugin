<?php
/**
 * Admin screens, actions and admin-bar shortcuts.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin.
 */
class WPSS_Admin {

	const SLUG = 'steady-speed';
	const CAP  = 'manage_options';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_post_wpss_action', array( __CLASS__, 'handle' ) );
		add_action( 'admin_post_wpss_media_webp', array( __CLASS__, 'media_single_webp' ) );
		add_filter( 'bulk_actions-upload', array( __CLASS__, 'media_bulk_action' ) );
		add_filter( 'handle_bulk_actions-upload', array( __CLASS__, 'handle_media_bulk_action' ), 10, 3 );
		add_filter( 'media_row_actions', array( __CLASS__, 'media_row_action' ), 10, 2 );
		add_filter( 'manage_media_columns', array( __CLASS__, 'media_column' ) );
		add_action( 'manage_media_custom_column', array( __CLASS__, 'media_column_value' ), 10, 2 );
		add_action( 'wp_ajax_wpss_image_progress', array( __CLASS__, 'ajax_image_progress' ) );
		add_action( 'wp_ajax_wpss_image_batch', array( __CLASS__, 'ajax_image_batch' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( WPSS_FILE ), array( __CLASS__, 'action_links' ) );
	}


	/** Add a dedicated single-image WebP action to Media Library rows. */
	public static function media_row_action( $actions, $post ) {
		if ( ! $post instanceof WP_Post || 'attachment' !== $post->post_type || ! wp_attachment_is_image( $post->ID ) || ! current_user_can( self::CAP ) ) {
			return $actions;
		}
		$url = wp_nonce_url(
			admin_url( 'admin-post.php?action=wpss_media_webp&attachment_id=' . (int) $post->ID ),
			'wpss_media_webp_' . (int) $post->ID
		);
		$actions['wpss_webp'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Optimize WebP', 'steady-speed' ) . '</a>';
		return $actions;
	}

	/** Add a WebP status column in Media Library. */
	public static function media_column( $columns ) {
		$columns['wpss_webp'] = __( 'Steady Speed WebP', 'steady-speed' );
		return $columns;
	}

	/** Render WebP status/action for Media Library rows. */
	public static function media_column_value( $column, $post_id ) {
		if ( 'wpss_webp' !== $column ) {
			return;
		}
		if ( ! wp_attachment_is_image( $post_id ) ) {
			echo '&mdash;';
			return;
		}
		$file = get_attached_file( $post_id );
		$has  = false;
		if ( $file && preg_match( '/\.(jpe?g|png)$/i', $file ) ) {
			$replacement = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
			$double      = $file . '.webp';
			$has         = ( $replacement && is_file( $replacement ) && filesize( $replacement ) > 0 ) || is_file( $double );
		}
		if ( $has ) {
			echo '<span style="color:#008a20;font-weight:600">' . esc_html__( 'WebP ready', 'steady-speed' ) . '</span>';
		} else {
			echo '<span style="color:#b32d2e">' . esc_html__( 'Not converted', 'steady-speed' ) . '</span>';
		}
	}

	/** Add a bulk action to Media Library. */
	public static function media_bulk_action( $actions ) {
		if ( current_user_can( self::CAP ) ) {
			$actions['wpss_optimize_webp'] = __( 'Steady Speed: Optimize to WebP', 'steady-speed' );
		}
		return $actions;
	}

	/** Handle Media Library bulk WebP conversion. */
	public static function handle_media_bulk_action( $redirect_to, $doaction, $post_ids ) {
		if ( 'wpss_optimize_webp' !== $doaction || ! current_user_can( self::CAP ) ) {
			return $redirect_to;
		}
		if ( ! ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) ) {
			$redirect_to = add_query_arg( 'wpss_webp_error', 'enable', $redirect_to );
			return $redirect_to;
		}
		$count = 0;
		foreach ( (array) $post_ids as $id ) {
			if ( wp_attachment_is_image( $id ) ) {
				$count += WPSS_Images::optimize_attachment( (int) $id );
			}
		}
		WPSS_Page_Cache::queue_purge_all( 'Media Library WebP bulk optimization' );
		return add_query_arg( 'wpss_webp_optimized', $count, $redirect_to );
	}

	/** Handle one Media Library image WebP conversion. */
	public static function media_single_webp() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Permission denied.', 'steady-speed' ), 403 );
		}
		$id = isset( $_GET['attachment_id'] ) ? absint( $_GET['attachment_id'] ) : 0;
		check_admin_referer( 'wpss_media_webp_' . $id );
		if ( ! $id || ! wp_attachment_is_image( $id ) ) {
			wp_safe_redirect( admin_url( 'upload.php?wpss_webp_error=invalid' ) );
			exit;
		}
		if ( ! ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_all' ) ) ) {
			wp_safe_redirect( add_query_arg( 'wpss_webp_error', 'enable', admin_url( 'upload.php' ) ) );
			exit;
		}
		$count = WPSS_Images::optimize_attachment( $id );
		WPSS_Page_Cache::queue_purge_all( 'Media Library WebP single optimization' );
		wp_safe_redirect( add_query_arg( 'wpss_webp_optimized', $count, admin_url( 'upload.php' ) ) );
		exit;
	}

	/* =====================================================================
	 * Wiring
	 * =================================================================== */

	public static function menu() {
		add_menu_page( __( 'Steady Speed', 'steady-speed' ), __( 'Steady Speed', 'steady-speed' ), self::CAP, self::SLUG, array( __CLASS__, 'page' ), 'dashicons-performance', 81 );
	}

	public static function register() {
		register_setting(
			'wpss_settings_group',
			WPSS_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'WPSS_Settings', 'sanitize' ),
				'default'           => WPSS_Settings::defaults(),
			)
		);
	}

	/**
	 * @param string $hook Hook suffix.
	 */
	public static function enqueue( $hook ) {
		$ours = 'toplevel_page_' . self::SLUG === $hook;
		if ( $ours ) {
			wp_enqueue_style( 'wpss-admin', WPSS_URL . 'assets/admin.css', array(), WPSS_VERSION );
		}
		// Page analyzer: runs in the administrator's browser. On our "Critical CSS" tab it is driven
		// by the buttons; elsewhere in wp-admin it analyzes a couple of queued pages in the background.
		if ( ! current_user_can( self::CAP ) || ! WPSS_Analysis::enabled() || WPSS_Settings::safe_mode() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';
		if ( 'elementor' === $action || in_array( $hook, array( 'customize.php', 'site-editor.php' ), true ) ) {
			return; // Never compete with an editor.
		}
		$ui   = $ours && isset( $_GET['tab'] ) && 'critical' === $_GET['tab']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$auto = ! $ui && WPSS_Settings::get( 'analysis_bg' ) && WPSS_Analysis::queue();
		if ( ! $ui && ! $auto ) {
			return;
		}
		wp_enqueue_script( 'wpss-analyzer', WPSS_URL . 'assets/analyzer.js', array(), WPSS_VERSION, true );
		wp_add_inline_script(
			'wpss-analyzer',
			'window.WPSS_ANALYZER=' . wp_json_encode(
				array(
					'rest'  => esc_url_raw( rest_url( 'wpss/v1/' ) ),
					'nonce' => wp_create_nonce( 'wp_rest' ),
					'auto'  => (bool) $auto,
					'batch' => 2,
				)
			) . ';',
			'before'
		);
	}

	/**
	 * @param array $links Links.
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Dashboard', 'steady-speed' ) . '</a>' );
		return $links;
	}

	/**
	 * Return image conversion progress to the admin UI.
	 */
	public static function ajax_image_progress() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'steady-speed' ) ), 403 );
		}
		check_ajax_referer( 'wpss_image_progress', 'nonce' );
		$s = WPSS_Images::bulk_state();
		$current_media_total = WPSS_Images::image_count();
		$total = isset( $s['total'] ) ? (int) $s['total'] : 0;
		// 1.2.5 counts one progress item per Media Library attachment, not every
		// generated thumbnail file. If an older 1.2.x state is present, show the
		// current Media Library count until the administrator starts the new queue.
		if ( ( $s['scope'] ?? '' ) !== 'media-v2' ) {
			$total = $current_media_total;
		}
		if ( 0 === $total && ! empty( $s['running'] ) ) {
			$total = $current_media_total;
		}
		$processed = isset( $s['scanned'] ) ? min( $total, (int) $s['scanned'] ) : 0;
		$remaining = max( 0, $total - $processed );
		$percent = $total > 0 ? min( 100, (int) floor( ( $processed / $total ) * 100 ) ) : ( empty( $s['running'] ) ? 100 : 0 );
		wp_send_json_success( array(
			'running'   => ! empty( $s['running'] ),
			'total'    => $total,
			'processed'=> $processed,
			'remaining'=> $remaining,
			'created'  => isset( $s['done'] ) ? (int) $s['done'] : 0,
			'frontend_queue' => WPSS_Images::frontend_queue_count(),
			'percent'  => $percent,
		) );
	}

	/**
	 * Process one image batch from the admin progress UI. This makes conversion
	 * continue even when WP-Cron is disabled or delayed on the hosting server.
	 */
	public static function ajax_image_batch() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'steady-speed' ) ), 403 );
		}
		check_ajax_referer( 'wpss_image_progress', 'nonce' );
		if ( ! ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Enable WebP or image optimization first.', 'steady-speed' ) ), 400 );
		}
		wp_send_json_success( WPSS_Images::process_batch_now() );
	}

	/**
	 * Settings saved: new settings take effect immediately and cached pages are rebuilt lazily.
	 *
	 * @param mixed $old Old.
	 * @param mixed $new New.
	 */
	public static function settings_changed( $old = null, $new = null ) {
		WPSS_Settings::flush();
		WPSS_Browser_Cache::sync();

		// Turning WebP on automatically starts a background site-wide conversion.
		// This keeps the admin request fast and avoids PHP timeouts on large media libraries.
		if ( is_array( $new ) && ! empty( $new['img_opt'] ) ) {
			WPSS_Images::start_bulk();
		}
		WPSS_Page_Cache::queue_purge_all( 'Settings changed' );
		if ( WPSS_Analysis::enabled() ) {
			WPSS_Analysis::queue_add( '/', 90 );
			foreach ( array_slice( array_keys( WPSS_Warmup::popular() ), 0, 20 ) as $url ) {
				WPSS_Analysis::queue_add( WPSS_Analysis::path_key( $url ), 20 );
			}
		}
	}

	/**
	 * @param string $tab  Tab.
	 * @param array  $args Extra query args.
	 */
	public static function url( $tab = 'dashboard', $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Nonced action URL (GET actions only; destructive DB ops need POST + confirmation).
	 *
	 * @param string $do   Action.
	 * @param array  $args Args.
	 */
	public static function action_url( $do, $args = array() ) {
		return wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'wpss_action', 'do' => $do ), $args ), admin_url( 'admin-post.php' ) ), 'wpss_action' );
	}

	/* =====================================================================
	 * Actions
	 * =================================================================== */

	public static function handle() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'steady-speed' ), 403 );
		}
		check_admin_referer( 'wpss_action' );
		$do       = isset( $_REQUEST['do'] ) ? sanitize_key( wp_unslash( $_REQUEST['do'] ) ) : '';
		$redirect = wp_get_referer() ? wp_get_referer() : self::url();
		$msg      = '';
		$type     = 'success';

		switch ( $do ) {
			case 'purge_all':
				WPSS_Page_Cache::purge_all( 'Manual purge by ' . wp_get_current_user()->user_login );
				$msg = __( 'All cached pages were cleared. They will be rebuilt automatically on the next visits.', 'steady-speed' );
				break;

			case 'purge_url':
				$url = isset( $_REQUEST['url'] ) ? esc_url_raw( wp_unslash( $_REQUEST['url'] ) ) : '';
				if ( $url ) {
					WPSS_Page_Cache::delete_keys( WPSS_Page_Cache::keys_for_url( $url ), 'Manual purge of ' . $url );
					$redirect = wp_validate_redirect( $url, $redirect );
					$msg      = __( 'This page was cleared from the cache.', 'steady-speed' );
				}
				break;

			case 'safe_on':
				update_option( WPSS_Settings::SAFE_OPTION, 1, true );
				WPSS_Browser_Cache::sync();
				WPSS_Logger::log( 'Emergency Safe Mode enabled by ' . wp_get_current_user()->user_login, 'warning' );
				$msg  = __( 'Emergency Safe Mode is ON. Every optimization and the page cache are bypassed; visitors get the original site.', 'steady-speed' );
				$type = 'warning';
				break;

			case 'safe_off':
				update_option( WPSS_Settings::SAFE_OPTION, 0, true );
				WPSS_Page_Cache::purge_all( 'Safe Mode disabled' );
				WPSS_Browser_Cache::sync();
				WPSS_Logger::log( 'Emergency Safe Mode disabled by ' . wp_get_current_user()->user_login );
				$msg = __( 'Emergency Safe Mode is OFF. Optimizations are active again.', 'steady-speed' );
				break;

			case 'db':
				$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
				if ( empty( $_POST['confirm_backup'] ) ) {
					$msg  = __( 'Nothing was changed: please confirm you have a recent database backup.', 'steady-speed' );
					$type = 'error';
				} elseif ( ! array_key_exists( $op, WPSS_Database::ops() ) ) {
					$msg  = __( 'Unknown operation.', 'steady-speed' );
					$type = 'error';
				} else {
					$msg = WPSS_Database::run( $op );
				}
				$redirect = self::url( 'database' );
				break;

			case 'remove_auto':
				$key = isset( $_REQUEST['key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['key'] ) ) : '';
				WPSS_Exclusions::remove_auto( $key );
				WPSS_Page_Cache::purge_all( 'Automatic exclusion removed' );
				$msg = __( 'Automatic exclusion removed. The file will be optimized again.', 'steady-speed' );
				break;

			case 'remove_auto_url':
				$path = isset( $_REQUEST['path'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['path'] ) ) : '';
				WPSS_Exclusions::remove_auto_url( $path );
				WPSS_Page_Cache::purge_all( 'Automatic page exclusion removed' );
				$msg = __( 'Page exclusion removed.', 'steady-speed' );
				break;

			case 'reset_counters':
				WPSS_Monitor::reset();
				$msg = __( 'Error counters reset.', 'steady-speed' );
				break;

			case 'clear_log':
				WPSS_Logger::clear();
				delete_option( WPSS_Debug::COUNTERS );
				delete_transient( WPSS_Debug::REPORTS );
				$msg = __( 'Log cleared.', 'steady-speed' );
				break;

			case 'webp_bulk':
				if ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) {
					WPSS_Images::start_bulk();
					$msg = __( 'Website image optimization started in the background. Originals are never modified.', 'steady-speed' );
				} else {
					$msg  = __( 'Enable WebP, AVIF or Optimize all website images first.', 'steady-speed' );
					$type = 'error';
				}
				break;

			case 'clear_assets':
				foreach ( array( 'css' => '*.css', 'js' => '*.js', 'map' => '*' ) as $t => $pat ) {
					foreach ( (array) glob( WPSS_CACHE_DIR . '/assets/' . $t . '/' . $pat ) as $f ) {
						if ( $f ) {
							wp_delete_file( $f );
						}
					}
				}
				WPSS_Page_Cache::purge_all( 'Optimized files cleared' );
				$msg = __( 'Optimized CSS/JS files and cached pages were cleared. They are rebuilt automatically.', 'steady-speed' );
				break;

			case 'analysis_requeue':
				WPSS_Analysis::requeue_all();
				$msg      = __( 'All analyzed pages were queued for a fresh analysis.', 'steady-speed' );
				$redirect = self::url( 'critical' );
				break;

			case 'analysis_clear':
				WPSS_Analysis::clear();
				delete_option( WPSS_Analysis::QUEUE );
				WPSS_Page_Cache::purge_all( 'Page analysis cleared' );
				$msg      = __( 'All page analyses were deleted. Pages are served with their complete CSS until analyzed again.', 'steady-speed' );
				$redirect = self::url( 'critical' );
				break;

			case 'clear_events':
				delete_option( WPSS_Monitor::EVENTS );
				$msg = __( 'Protection events cleared.', 'steady-speed' );
				break;

			case 'recheck_server':
				WPSS_Browser_Cache::sync();
				$msg = __( 'Server rules re-checked.', 'steady-speed' );
				break;

			default:
				$msg  = __( 'Unknown action.', 'steady-speed' );
				$type = 'error';
		}

		if ( $msg ) {
			set_transient( 'wpss_notice_' . get_current_user_id(), array( 'msg' => $msg, 'type' => $type ), 60 );
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	public static function notices() {
		if ( isset( $_GET['wpss_webp_optimized'] ) ) {
			$count = absint( wp_unslash( $_GET['wpss_webp_optimized'] ) );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( _n( '%d WebP copy created.', '%d WebP copies created.', $count, 'steady-speed' ), $count ) ) . '</p></div>';
		}
		if ( isset( $_GET['wpss_webp_error'] ) && 'enable' === sanitize_key( wp_unslash( $_GET['wpss_webp_error'] ) ) ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Enable Steady Speed WebP in Steady Speed → Images first.', 'steady-speed' ) . '</p></div>';
		}

		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$n = get_transient( 'wpss_notice_' . get_current_user_id() );
		if ( is_array( $n ) ) {
			delete_transient( 'wpss_notice_' . get_current_user_id() );
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $n['type'] ), esc_html( $n['msg'] ) );
		}
		if ( WPSS_Settings::safe_mode() ) {
			$off = defined( 'WPSS_SAFE_MODE' ) && WPSS_SAFE_MODE
				? esc_html__( '(forced by the WPSS_SAFE_MODE constant in wp-config.php)', 'steady-speed' )
				: '<a href="' . esc_url( self::action_url( 'safe_off' ) ) . '">' . esc_html__( 'Turn off', 'steady-speed' ) . '</a>';
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Steady Speed: Emergency Safe Mode is ON', 'steady-speed' ) . '</strong> – ' . esc_html__( 'all optimizations are disabled.', 'steady-speed' ) . ' ' . $off . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && in_array( $screen->id, array( 'plugins', 'toplevel_page_' . self::SLUG, 'dashboard' ), true ) ) {
			$conflicts = WPSS_Compat::conflicts();
			if ( $conflicts ) {
				echo '<div class="notice notice-warning"><p><strong>Steady Speed:</strong> ' . esc_html( WPSS_Compat::conflict_message() ) . ' (' . esc_html( implode( ', ', $conflicts ) ) . ')</p></div>';
			}
		}
	}

	/**
	 * Admin bar shortcuts (front end and admin).
	 *
	 * @param WP_Admin_Bar $bar Bar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! current_user_can( self::CAP ) || ! is_admin_bar_showing() ) {
			return;
		}
		$safe = WPSS_Settings::safe_mode();
		$bar->add_node(
			array(
				'id'    => 'wpss',
				'title' => $safe ? 'Steady Speed: SAFE MODE' : 'Steady Speed',
				'href'  => self::url(),
			)
		);
		$bar->add_node(
			array(
				'parent' => 'wpss',
				'id'     => 'wpss-purge',
				'title'  => __( 'Clear all cached pages', 'steady-speed' ),
				'href'   => self::action_url( 'purge_all' ),
			)
		);
		if ( ! is_admin() ) {
			$scheme  = is_ssl() ? 'https://' : 'http://';
			$host    = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
			$uri     = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
			$current = $scheme . $host . $uri;
			$bar->add_node(
				array(
					'parent' => 'wpss',
					'id'     => 'wpss-purge-url',
					'title'  => __( 'Clear this page', 'steady-speed' ),
					'href'   => self::action_url( 'purge_url', array( 'url' => rawurlencode( remove_query_arg( array( 'wpss_debug', 'wpss_disable' ), $current ) ) ) ),
				)
			);
			$bar->add_node(
				array(
					'parent' => 'wpss',
					'id'     => 'wpss-debug',
					'title'  => __( 'Debug view of this page', 'steady-speed' ),
					'href'   => add_query_arg( 'wpss_debug', '1', $current ),
				)
			);
			$bar->add_node(
				array(
					'parent' => 'wpss',
					'id'     => 'wpss-orig',
					'title'  => __( 'View without optimization', 'steady-speed' ),
					'href'   => add_query_arg( 'wpss_disable', '1', $current ),
				)
			);
		}
		$bar->add_node(
			array(
				'parent' => 'wpss',
				'id'     => 'wpss-safe',
				'title'  => $safe ? __( 'Turn off Emergency Safe Mode', 'steady-speed' ) : __( 'Emergency Safe Mode (disable everything)', 'steady-speed' ),
				'href'   => self::action_url( $safe ? 'safe_off' : 'safe_on' ),
			)
		);
	}

	/* =====================================================================
	 * Page
	 * =================================================================== */

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tabs = array(
			'dashboard'  => __( 'Dashboard', 'steady-speed' ),
			'settings'   => __( 'Settings', 'steady-speed' ),
			'advanced'   => __( 'Advanced Performance', 'steady-speed' ),
			'critical'   => __( 'Critical CSS & Analysis', 'steady-speed' ),
			'report'     => __( 'Performance Report', 'steady-speed' ),
			'exclusions' => __( 'Exclusions', 'steady-speed' ),
			'database'   => __( 'Database', 'steady-speed' ),
			'debug'      => __( 'Debug & Log', 'steady-speed' ),
		);
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $tabs[ $tab ] ) ? $tab : 'dashboard';

		echo '<div class="wrap wpss"><h1>' . esc_html__( 'Steady Speed', 'steady-speed' ) . '</h1>';
		settings_errors( WPSS_Settings::OPTION );
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $id => $label ) {
			printf( '<a href="%s" class="nav-tab%s">%s</a>', esc_url( self::url( $id ) ), $id === $tab ? ' nav-tab-active' : '', esc_html( $label ) );
		}
		echo '</nav><div class="wpss-body">';
		call_user_func( array( __CLASS__, 'tab_' . $tab ) );
		echo '</div></div>';
	}

	/**
	 * @param int $bytes Bytes.
	 */
	private static function size( $bytes ) {
		return size_format( (int) $bytes, 1 ) ? size_format( (int) $bytes, 1 ) : '0 B';
	}

	/**
	 * One status row.
	 *
	 * @param string $label Label.
	 * @param string $value Value (already safe HTML from pill()/esc_html).
	 */
	private static function row( $label, $value ) {
		echo '<tr><th>' . esc_html( $label ) . '</th><td>' . wp_kses_post( $value ) . '</td></tr>';
	}

	/**
	 * @param string $text  Text.
	 * @param string $state good|warn|bad|off.
	 */
	private static function pill( $text, $state = 'good' ) {
		return '<span class="wpss-pill wpss-' . esc_attr( $state ) . '">' . esc_html( $text ) . '</span>';
	}

	/**
	 * @param bool $on On.
	 */
	private static function onoff( $on ) {
		return $on ? self::pill( __( 'On', 'steady-speed' ) ) : self::pill( __( 'Off', 'steady-speed' ), 'off' );
	}

	/**
	 * Warnings for the dashboard.
	 *
	 * @return string[]
	 */
	private static function warnings() {
		global $wp_version;
		$w = array();
		if ( WPSS_Compat::conflicts() ) {
			$w[] = WPSS_Compat::conflict_message() . ' (' . implode( ', ', WPSS_Compat::conflicts() ) . ')';
		}
		if ( ! WPSS_FS::ready() ) {
			$w[] = __( 'Direct file access is not available, so files cannot be written. Page cache and file optimization are inactive; the site is served unmodified.', 'steady-speed' );
		} elseif ( ! wp_is_writable( WPSS_CACHE_DIR ) ) {
			$w[] = sprintf( /* translators: %s dir */ __( 'Cache directory is not writable: %s', 'steady-speed' ), WPSS_CACHE_DIR );
		}
		if ( version_compare( $wp_version, '6.4', '<' ) ) {
			$w[] = __( 'WordPress 6.4+ is required for dependency-safe script deferring. Deferring is limited.', 'steady-speed' );
		}
		$problems = WPSS_Logger::recent_problems();
		if ( $problems ) {
			$w[] = sprintf( /* translators: %d count */ _n( '%d warning in the last 24 hours – see Debug & Log.', '%d warnings in the last 24 hours – see Debug & Log.', $problems, 'steady-speed' ), $problems );
		}
		if ( 'custom' === WPSS_Settings::get( 'perf_mode' ) && ( 'aggressive' === WPSS_Settings::get( 'css_mode' ) || 'aggressive' === WPSS_Settings::get( 'js_mode' ) ) ) {
			$w[] = __( 'Aggressive mode is enabled. Test key pages (header, sliders, forms, checkout) after every change.', 'steady-speed' );
		}
		if ( ! WPSS_Settings::get( 'elementor_compat' ) && defined( 'ELEMENTOR_VERSION' ) ) {
			$w[] = __( 'Elementor is active but Elementor Compatibility Mode is off.', 'steady-speed' );
		}
		$bc = WPSS_Browser_Cache::status();
		if ( WPSS_Settings::get( 'browser_cache' ) && isset( $bc['assets'] ) && 'rolled-back' === $bc['assets'] ) {
			$w[] = __( 'The server rejected the browser-cache rules; they were removed automatically.', 'steady-speed' );
		}
		return $w;
	}

	private static function tab_dashboard() {
		$safe     = WPSS_Settings::safe_mode();
		$warnings = self::warnings();
		$cache    = WPSS_Page_Cache::stats();
		$assets   = WPSS_Assets::stats();
		$auto     = WPSS_Exclusions::auto();
		$auto_url = WPSS_Exclusions::auto_urls();
		$bc       = WPSS_Browser_Cache::status();

		if ( $safe ) {
			$status = array( 'SAFE MODE', 'warn', __( 'All optimizations are bypassed.', 'steady-speed' ) );
		} elseif ( $warnings ) {
			$status = array( 'ATTENTION', 'warn', __( 'The site is optimized; review the notes below.', 'steady-speed' ) );
		} else {
			$status = array( 'GOOD', 'good', __( 'Everything is running normally.', 'steady-speed' ) );
		}
		echo '<div class="wpss-hero wpss-hero-' . esc_attr( $status[1] ) . '"><div class="wpss-hero-label">' . esc_html__( 'Performance Status', 'steady-speed' ) . '</div><div class="wpss-hero-value">' . esc_html( $status[0] ) . '</div><p>' . esc_html( $status[2] ) . '</p>';
		echo '<p class="wpss-buttons">';
		echo '<a class="button button-primary" href="' . esc_url( self::action_url( 'purge_all' ) ) . '">' . esc_html__( 'Clear all cached pages', 'steady-speed' ) . '</a> ';
		if ( $safe ) {
			if ( ! ( defined( 'WPSS_SAFE_MODE' ) && WPSS_SAFE_MODE ) ) {
				echo '<a class="button" href="' . esc_url( self::action_url( 'safe_off' ) ) . '">' . esc_html__( 'Turn off Emergency Safe Mode', 'steady-speed' ) . '</a> ';
			}
		} else {
			echo '<a class="button wpss-danger" href="' . esc_url( self::action_url( 'safe_on' ) ) . '" onclick="return confirm(\'' . esc_js( __( 'Disable every optimization now?', 'steady-speed' ) ) . '\')">' . esc_html__( 'Emergency Safe Mode', 'steady-speed' ) . '</a> ';
		}
		echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'wpss_disable', '1', home_url( '/' ) ) ) . '">' . esc_html__( 'Preview original site', 'steady-speed' ) . '</a> ';
		echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'wpss_debug', '1', home_url( '/' ) ) ) . '">' . esc_html__( 'Debug view of home page', 'steady-speed' ) . '</a>';
		echo '</p><p class="description">' . esc_html__( 'You never need to clear the cache after editing: changed posts, menus, widgets, Elementor pages and CSS/JS files are detected and only affected pages are rebuilt.', 'steady-speed' ) . '</p></div>';

		if ( $warnings ) {
			echo '<div class="wpss-card wpss-warnings"><h2>' . esc_html__( 'Warnings', 'steady-speed' ) . '</h2><ul>';
			foreach ( $warnings as $w ) {
				echo '<li>' . esc_html( $w ) . '</li>';
			}
			echo '</ul></div>';
		}

		$modes = array(
			'safe'       => __( 'Safe', 'steady-speed' ),
			'balanced'   => __( 'Balanced', 'steady-speed' ),
			'aggressive' => __( 'Aggressive', 'steady-speed' ),
		);
		echo '<div class="wpss-grid"><div class="wpss-card"><h2>' . esc_html__( 'Optimization', 'steady-speed' ) . '</h2><table class="wpss-table">';
		self::row( __( 'Page cache', 'steady-speed' ), WPSS_Settings::get( 'page_cache' ) ? self::pill( sprintf( /* translators: 1 pages 2 size */ __( 'Active – %1$d pages, %2$s', 'steady-speed' ), $cache['pages'], self::size( $cache['size'] ) ) ) : self::pill( __( 'Off', 'steady-speed' ), 'off' ) );
		$css_mode = WPSS_Settings::get( 'css_mode' );
		$js_mode  = WPSS_Settings::get( 'js_mode' );
		self::row( __( 'CSS optimization', 'steady-speed' ), WPSS_Settings::get( 'css_opt' ) ? self::pill( $modes[ $css_mode ] ?? $css_mode, 'safe' === $css_mode ? 'good' : 'warn' ) . ' ' . esc_html( sprintf( /* translators: %d files */ __( '%d optimized files', 'steady-speed' ), $assets['css'] ) ) : self::onoff( false ) );
		self::row( __( 'JS optimization', 'steady-speed' ), WPSS_Settings::get( 'js_opt' ) ? self::pill( $modes[ $js_mode ] ?? $js_mode, 'safe' === $js_mode ? 'good' : 'warn' ) . ' ' . esc_html( sprintf( /* translators: %d files */ __( '%d optimized files', 'steady-speed' ), $assets['js'] ) ) : self::onoff( false ) );
		self::row( __( 'Optimized files size', 'steady-speed' ), esc_html( self::size( $assets['size'] ) ) );
		$bulk = WPSS_Images::bulk_state();
		$img  = WPSS_Settings::get( 'lazy' ) ? __( 'Lazy loading on', 'steady-speed' ) : __( 'Lazy loading off', 'steady-speed' );
		$img .= ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) ? ' · ' . __( 'WebP/AVIF on', 'steady-speed' ) : '';
		$img .= ! empty( $bulk['running'] ) ? ' · ' . sprintf( /* translators: %d */ __( 'converting (%d done)', 'steady-speed' ), (int) $bulk['done'] ) : '';
		self::row( __( 'Images', 'steady-speed' ), esc_html( $img ) );
		$bc_txt = WPSS_Settings::get( 'browser_cache' ) ? ( isset( $bc['assets'] ) ? $bc['assets'] . ' / root: ' . ( $bc['root'] ?? '-' ) : __( 'pending', 'steady-speed' ) ) : '';
		self::row( __( 'Browser caching', 'steady-speed' ), WPSS_Settings::get( 'browser_cache' ) ? self::pill( __( 'On', 'steady-speed' ) ) . ' <code>' . esc_html( $bc_txt ) . '</code>' : self::onoff( false ) );
		echo '</table></div>';

		echo '<div class="wpss-card"><h2>' . esc_html__( 'Protection', 'steady-speed' ) . '</h2><table class="wpss-table">';
		self::row( __( 'Elementor protection', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'elementor_compat' ) ) );
		self::row( __( 'Slider protection', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'slider_protect' ) ) );
		self::row( __( 'Header / menu protection', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'header_protect' ) ) );
		self::row( __( 'Automatic error detection', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'error_detect' ) ) );
		self::row( __( 'Automatic exclusions', 'steady-speed' ), esc_html( sprintf( /* translators: 1 files 2 pages */ __( '%1$d files, %2$d pages', 'steady-speed' ), count( $auto ), count( $auto_url ) ) ) . ( $auto || $auto_url ? ' – <a href="' . esc_url( self::url( 'exclusions' ) ) . '">' . esc_html__( 'review', 'steady-speed' ) . '</a>' : '' ) );
		self::row( __( 'Debug mode', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'debug' ) ) );
		self::row( __( 'Database', 'steady-speed' ), '<a href="' . esc_url( self::url( 'database' ) ) . '">' . esc_html__( 'View cleanup status', 'steady-speed' ) . '</a>' );
		echo '</table></div>';

		echo '<div class="wpss-card"><h2>' . esc_html__( 'Compatibility Status', 'steady-speed' ) . '</h2><table class="wpss-table">';
		foreach ( WPSS_Compat::status() as $r ) {
			self::row( $r[0], self::pill( $r[1], $r[2] ) );
		}
		echo '</table>';
		if ( WPSS_Compat::conflicts() ) {
			echo '<p class="wpss-warn-text"><strong>' . esc_html__( 'WARNING:', 'steady-speed' ) . '</strong> ' . esc_html__( 'Multiple optimization engines may conflict.', 'steady-speed' ) . ' ' . esc_html( WPSS_Compat::conflict_message() ) . ' ' . esc_html__( 'Steady Speed does not disable other plugins. Use only one page cache and one CSS/JS optimizer.', 'steady-speed' ) . '</p>';
		}
		echo '</div>';

		$counts = WPSS_Analysis::counts();
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Advanced performance', 'steady-speed' ) . '</h2><table class="wpss-table">';
		self::row( __( 'Performance mode', 'steady-speed' ), self::pill( self::mode_label( (string) WPSS_Settings::get( 'perf_mode' ) ), 'safe' === WPSS_Settings::get( 'perf_mode' ) ? 'good' : 'warn' ) . ' <a href="' . esc_url( self::url( 'settings' ) ) . '">' . esc_html__( 'change', 'steady-speed' ) . '</a>' );
		self::row( __( 'Critical CSS', 'steady-speed' ), self::onoff( WPSS_Settings::get( 'critical_css' ) && WPSS_Settings::get( 'css_async' ) ) );
		self::row( __( 'Remove unused CSS', 'steady-speed' ), WPSS_Settings::get( 'rucss' ) ? self::pill( ucfirst( (string) WPSS_Settings::get( 'rucss_mode' ) ) ) : self::onoff( false ) );
		self::row( __( 'Third-party delay', 'steady-speed' ), WPSS_Settings::get( 'tp_delay' ) ? self::pill( ucfirst( (string) WPSS_Settings::get( 'tp_mode' ) ) . ' · ' . WPSS_Settings::get( 'tp_trigger' ) ) : self::onoff( false ) );
		if ( WPSS_Analysis::enabled() ) {
			/* translators: 1 analyzed 2 stale 3 queued */
			self::row( __( 'Page analysis', 'steady-speed' ), esc_html( sprintf( __( '%1$d analyzed · %2$d outdated · %3$d queued', 'steady-speed' ), $counts['analyzed'], $counts['stale'], $counts['queued'] ) ) . ' – <a href="' . esc_url( self::url( 'critical' ) ) . '">' . esc_html__( 'details', 'steady-speed' ) . '</a>' );
		}
		self::row( __( 'Automatic fallbacks (7 days)', 'steady-speed' ), esc_html( (string) WPSS_Monitor::recent_fallbacks() ) );
		echo '</table></div>';

		$detected = WPSS_Compat::detect();
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Detected components', 'steady-speed' ) . '</h2>';
		echo $detected ? '<p>' . esc_html( implode( ', ', $detected ) ) . '</p>' : '<p>' . esc_html__( 'None of the known builders/plugins detected.', 'steady-speed' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<p class="description">' . esc_html__( 'Their scripts and styles are recognised automatically and handled with built-in compatibility rules.', 'steady-speed' ) . '</p></div>';

		global $is_nginx;
		if ( ! empty( $is_nginx ) ) {
			echo '<div class="wpss-card"><h2>' . esc_html__( 'Nginx configuration (optional)', 'steady-speed' ) . '</h2><p>' . esc_html__( 'Nginx ignores .htaccess. Add this to your server block for long browser caching:', 'steady-speed' ) . '</p><pre class="wpss-pre">' . esc_html( WPSS_Browser_Cache::nginx_snippet() ) . '</pre></div>';
		}
		echo '</div>';
	}

	/* ---------------- Settings form helpers ---------------- */

	/**
	 * @param string $key   Key.
	 * @param string $label Label.
	 * @param string $desc  Description.
	 */
	private static function checkbox( $key, $label, $desc = '' ) {
		printf(
			'<tr><th scope="row">%1$s</th><td><label><input type="checkbox" name="%2$s[%3$s]" value="1" %4$s> %5$s</label>%6$s</td></tr>',
			esc_html( $label ),
			esc_attr( WPSS_Settings::OPTION ),
			esc_attr( $key ),
			checked( 1, (int) WPSS_Settings::get( $key ), false ),
			esc_html__( 'Enabled', 'steady-speed' ),
			$desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : ''
		);
	}

	/**
	 * @param string $key     Key.
	 * @param string $label   Label.
	 * @param array  $choices Choices.
	 * @param string $desc    Description.
	 */
	private static function select( $key, $label, $choices, $desc = '' ) {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td><select name="' . esc_attr( WPSS_Settings::OPTION . '[' . $key . ']' ) . '">';
		foreach ( $choices as $v => $l ) {
			echo '<option value="' . esc_attr( $v ) . '" ' . selected( WPSS_Settings::get( $key ), $v, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select>' . ( $desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : '' ) . '</td></tr>';
	}

	/**
	 * @param string $key   Key.
	 * @param string $label Label.
	 * @param string $desc  Description.
	 * @param array  $attr  min/max/step.
	 */
	private static function number( $key, $label, $desc = '', $attr = array() ) {
		printf(
			'<tr><th scope="row">%1$s</th><td><input type="number" class="small-text" name="%2$s[%3$s]" value="%4$s" min="%5$s" max="%6$s">%7$s</td></tr>',
			esc_html( $label ),
			esc_attr( WPSS_Settings::OPTION ),
			esc_attr( $key ),
			esc_attr( WPSS_Settings::get( $key ) ),
			esc_attr( $attr['min'] ?? 0 ),
			esc_attr( $attr['max'] ?? '' ),
			$desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : ''
		);
	}

	/**
	 * @param string $key   Key.
	 * @param string $label Label.
	 * @param string $desc  Description.
	 */
	private static function textarea( $key, $label, $desc = '' ) {
		printf(
			'<tr><th scope="row">%1$s</th><td><textarea class="large-text code" rows="4" name="%2$s[%3$s]">%4$s</textarea>%5$s</td></tr>',
			esc_html( $label ),
			esc_attr( WPSS_Settings::OPTION ),
			esc_attr( $key ),
			esc_textarea( (string) WPSS_Settings::get( $key ) ),
			$desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : ''
		);
	}

	/**
	 * @param string $tab Tab id stored in _tab so saving one tab never resets another.
	 */
	private static function form_open( $tab ) {
		echo '<form method="post" action="options.php">';
		settings_fields( 'wpss_settings_group' );
		echo '<input type="hidden" name="' . esc_attr( WPSS_Settings::OPTION ) . '[_tab]" value="' . esc_attr( $tab ) . '">';
	}

	/**
	 * @param string $title Section title.
	 * @param string $intro Intro.
	 */
	private static function section( $title, $intro = '' ) {
		echo '<h2 class="wpss-section">' . esc_html( $title ) . '</h2>' . ( $intro ? '<p class="description">' . esc_html( $intro ) . '</p>' : '' ) . '<table class="form-table" role="presentation">';
	}

	private static function tab_settings() {
		$modes = array(
			'safe'       => __( 'Safe – minify only (recommended)', 'steady-speed' ),
			'balanced'   => __( 'Balanced – + combine within the same plugin/theme, defer footer scripts', 'steady-speed' ),
			'aggressive' => __( 'Aggressive – + combine across sources, defer all eligible scripts, delay third-party', 'steady-speed' ),
		);
		self::mode_form();
		self::form_open( 'settings' );

		self::section( __( 'Page cache', 'steady-speed' ), __( 'Never cached: admin, logged-in users, editors/previews, REST/AJAX, WooCommerce cart/checkout/account, carts in session, forms with security tokens, searches and 404s.', 'steady-speed' ) );
		self::checkbox( 'page_cache', __( 'Page cache', 'steady-speed' ) );
		self::number( 'cache_ttl', __( 'Maximum page age (seconds)', 'steady-speed' ), __( 'Safety net only; changes are detected automatically. 300 – 604800.', 'steady-speed' ), array( 'min' => 300, 'max' => WEEK_IN_SECONDS ) );
		self::checkbox( 'cache_mobile', __( 'Separate mobile cache', 'steady-speed' ), __( 'Keep on if your theme outputs different HTML for phones.', 'steady-speed' ) );
		self::checkbox( 'cache_skip_nonce', __( 'Skip pages with nonce forms', 'steady-speed' ), __( 'Prevents expired security tokens in cached forms.', 'steady-speed' ) );
		self::textarea( 'cache_ignore_qs', __( 'Ignored query parameters', 'steady-speed' ), __( 'One per line. Other query strings are never cached.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'CSS & JavaScript', 'steady-speed' ), __( 'Original files are never modified. Optimized copies are versioned by content, so changes appear instantly without clearing anything.', 'steady-speed' ) );
		self::checkbox( 'css_opt', __( 'Optimize CSS', 'steady-speed' ) );
		self::select( 'css_mode', __( 'CSS mode', 'steady-speed' ), $modes );
		self::checkbox( 'js_opt', __( 'Optimize JavaScript', 'steady-speed' ) );
		self::select( 'js_mode', __( 'JavaScript mode (defer non-critical JS)', 'steady-speed' ), $modes, __( 'JavaScript files are never combined. Deferring uses WordPress’s dependency-aware loading strategies: a script is only deferred when core confirms nothing that runs earlier depends on it.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'Protection', 'steady-speed' ) );
		self::checkbox( 'elementor_compat', __( 'Elementor Compatibility Mode', 'steady-speed' ), __( 'Elementor & Elementor Pro scripts are never deferred/delayed and their CSS is never combined.', 'steady-speed' ) );
		self::checkbox( 'slider_protect', __( 'Slider protection', 'steady-speed' ), __( 'Swiper, Slick, Owl, Revolution Slider and similar keep their loading order.', 'steady-speed' ) );
		self::checkbox( 'header_protect', __( 'Header / navigation protection', 'steady-speed' ), __( 'Menu, sticky header and mobile navigation assets are never deferred, delayed or combined.', 'steady-speed' ) );
		self::checkbox( 'error_detect', __( 'Automatic error detection', 'steady-speed' ), __( 'Visitors’ browsers fall back to original files instantly if an optimized file fails; after 3 reports the file or page is excluded automatically.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'Images', 'steady-speed' ) );
		self::checkbox( 'lazy', __( 'Lazy load images', 'steady-speed' ), __( 'Logos, high-priority images and the first images on the page are never lazy-loaded.', 'steady-speed' ) );
		self::number( 'lazy_skip', __( 'Load first N images normally', 'steady-speed' ), __( 'Used when a page has not been analyzed yet. Once analyzed, the real above-the-fold images are never lazy-loaded (Advanced Performance → Above-the-fold). 0 – 20.', 'steady-speed' ), array( 'min' => 0, 'max' => 20 ) );
		echo '</table><p class="description">' . esc_html__( 'WebP/AVIF, responsive images, image dimensions and fonts are under Advanced Performance.', 'steady-speed' ) . '</p>';

		self::section( __( 'Browser caching & developer', 'steady-speed' ) );
		self::checkbox( 'browser_cache', __( 'Browser caching headers', 'steady-speed' ), __( 'Apache/LiteSpeed only. Rules are tested and rolled back automatically if the server rejects them.', 'steady-speed' ) );
		self::checkbox( 'debug', __( 'Debug mode', 'steady-speed' ), __( 'Adds an HTML comment listing optimized/excluded files with reasons, and records cache hit/miss counts.', 'steady-speed' ) );
		self::checkbox( 'optimize_logged_in', __( 'Optimize for logged-in users', 'steady-speed' ), __( 'Off = logged-in users always see original assets (pages are never cached for them either way).', 'steady-speed' ) );
		echo '</table>';

		submit_button();
		echo '</form>';
	}

	/**
	 * @param string $mode Mode key.
	 */
	private static function mode_label( $mode ) {
		$l = array(
			'safe'        => __( 'Safe', 'steady-speed' ),
			'balanced'    => __( 'Balanced', 'steady-speed' ),
			'performance' => __( 'Performance', 'steady-speed' ),
			'custom'      => __( 'Custom', 'steady-speed' ),
		);
		return $l[ $mode ] ?? $mode;
	}

	/**
	 * Performance mode selector (its own form: choosing a mode applies its preset).
	 */
	private static function mode_form() {
		$current = (string) WPSS_Settings::get( 'perf_mode' );
		$modes   = array(
			'safe'        => array( __( 'Focus on stability: page cache, CSS/JS minification, lazy loading, browser caching, asset versioning.', 'steady-speed' ), '' ),
			'balanced'    => array( __( 'Everything in Safe + Critical CSS, deferred non-critical JS, third-party delay, LCP, font and image optimization.', 'steady-speed' ), __( 'Recommended for most websites', 'steady-speed' ) ),
			'performance' => array( __( 'Everything in Balanced + unused CSS removal, advanced JS delay, advanced third-party and Elementor CSS optimization. Protections still apply.', 'steady-speed' ), '' ),
		);
		self::form_open( 'mode' );
		echo '<h2 class="wpss-section">' . esc_html__( 'Performance mode', 'steady-speed' ) . '</h2><div class="wpss-modes">';
		foreach ( $modes as $key => $info ) {
			printf(
				'<label class="wpss-mode%1$s"><input type="radio" name="%2$s[perf_mode]" value="%3$s" %4$s> <strong>%5$s</strong>%6$s<span>%7$s</span></label>',
				$current === $key ? ' wpss-mode-on' : '',
				esc_attr( WPSS_Settings::OPTION ),
				esc_attr( $key ),
				checked( $current, $key, false ),
				esc_html( self::mode_label( $key ) ),
				$info[1] ? ' <em>' . esc_html( $info[1] ) . '</em>' : '',
				esc_html( $info[0] )
			);
		}
		if ( 'custom' === $current ) {
			echo '<label class="wpss-mode wpss-mode-on"><input type="radio" name="' . esc_attr( WPSS_Settings::OPTION ) . '[perf_mode]" value="custom" checked> <strong>' . esc_html__( 'Custom', 'steady-speed' ) . '</strong><span>' . esc_html__( 'Individual settings were changed. Choosing a mode above replaces the performance options with that mode’s values.', 'steady-speed' ) . '</span></label>';
		}
		echo '</div><p class="description">' . esc_html__( 'A mode only changes performance options. Page cache, protections, exclusions and developer options are never touched. No mode can guarantee a specific PageSpeed score.', 'steady-speed' ) . '</p>';
		submit_button( __( 'Apply mode', 'steady-speed' ), 'secondary' );
		echo '</form>';
	}

	private static function tab_advanced() {
		self::form_open( 'advanced' );

		self::section( __( 'Advanced CSS', 'steady-speed' ), __( 'Critical CSS and unused-CSS removal use a page analysis made in your own browser (see “Critical CSS & Analysis”). Pages without a fresh analysis always get their complete, original CSS.', 'steady-speed' ) );
		self::checkbox( 'critical_css', __( 'Critical CSS', 'steady-speed' ), __( 'Inline the CSS needed for the first screen (header, navigation, hero, LCP element, buttons, typography, Elementor containers) per page, separately for desktop and mobile.', 'steady-speed' ) );
		self::checkbox( 'css_async', __( 'Async non-critical CSS', 'steady-speed' ), __( 'Load the remaining CSS without blocking rendering (only on pages with Critical CSS). Header, navigation, slider, WooCommerce, payment and consent styles always stay render-blocking. Scripts using jQuery wait for the CSS (max 3 s).', 'steady-speed' ) );
		self::checkbox( 'rucss', __( 'Remove unused CSS', 'steady-speed' ), __( 'Per page: rules that match nothing on the page are removed from eligible stylesheets. Never applied to Elementor, sliders, navigation, forms, WooCommerce, popups, icon fonts or dynamic content. When in doubt, the rule is kept.', 'steady-speed' ) );
		self::select(
			'rucss_mode',
			__( 'Unused CSS mode', 'steady-speed' ),
			array(
				'safe'       => __( 'Safe – only WordPress block styles, only clearly unused rules', 'steady-speed' ),
				'balanced'   => __( 'Balanced – + theme and unprotected plugin styles, confidently unused rules', 'steady-speed' ),
				'aggressive' => __( 'Aggressive – + rules whose classes appear on the page only partly', 'steady-speed' ),
			)
		);
		echo '</table>';

		self::section( __( 'Advanced JavaScript', 'steady-speed' ), __( '“Defer non-critical JS” is the JavaScript mode on the Settings tab. Scripts in the Core, Elementor, Slider, Header, Navigation, Forms, WooCommerce, Payment and Consent groups are never deferred or delayed, and a script is never delayed if another script depends on it.', 'steady-speed' ) );
		self::checkbox( 'js_delay_noncritical', __( 'Delay non-critical JS', 'steady-speed' ), __( 'Footer scripts outside all protected groups, with no dependents and no inline code after them, load when the browser is idle after the page has loaded.', 'steady-speed' ) );
		self::checkbox( 'tp_delay', __( 'Delay third-party JS', 'steady-speed' ), __( 'Google Analytics, Tag Manager, Meta Pixel, Hotjar, Clarity, chat, review and social widgets. Never: payment, CAPTCHA, cookie consent, login, forms, maps with inline initialisation, and nothing on cart/checkout/account pages.', 'steady-speed' ) );
		self::select(
			'tp_mode',
			__( 'Third-party strategy', 'steady-speed' ),
			array(
				'safe'     => __( 'Safe – only external scripts of known services; their inline setup code still runs immediately', 'steady-speed' ),
				'advanced' => __( 'Advanced – also delays known inline loader snippets (GTM, Pixel…), with call queues so nothing is lost', 'steady-speed' ),
			)
		);
		self::select(
			'tp_trigger',
			__( 'Load third-party scripts', 'steady-speed' ),
			array(
				'interaction' => __( 'On first interaction (or after the delay below)', 'steady-speed' ),
				'idle'        => __( 'When the browser is idle after load', 'steady-speed' ),
				'timeout'     => __( 'After a fixed delay after load', 'steady-speed' ),
			),
			__( 'Analytics may record slightly fewer very short visits when loading is delayed.', 'steady-speed' )
		);
		self::number( 'tp_timeout', __( 'Delay (seconds)', 'steady-speed' ), __( '1 – 30.', 'steady-speed' ), array( 'min' => 1, 'max' => 30 ) );
		echo '</table>';

		self::section( __( 'Core Web Vitals', 'steady-speed' ) );
		self::checkbox( 'lcp_opt', __( 'LCP optimization', 'steady-speed' ), __( 'The likely Largest Contentful Paint image is never lazy-loaded and gets fetchpriority="high".', 'steady-speed' ) );
		self::checkbox( 'lcp_preload', __( 'LCP image preload', 'steady-speed' ), __( 'Preload exactly one resource: the LCP image found by the page analysis (in WebP/AVIF when that is what the browser will use).', 'steady-speed' ) );
		self::checkbox( 'img_dimensions', __( 'CLS optimization', 'steady-speed' ), __( 'Add width/height to images that lack them, only when the real file size can be read. A zero-specificity height:auto rule prevents stretched images.', 'steady-speed' ) );
		self::checkbox( 'inp_opt', __( 'INP optimization', 'steady-speed' ), __( 'Delayed scripts run one at a time, yielding to user input between them.', 'steady-speed' ) );
		self::checkbox( 'atf_opt', __( 'Above-the-fold optimization', 'steady-speed' ), __( 'Use the page analysis: images really visible in the first screen are never lazy; everything below it can be.', 'steady-speed' ) );
		self::checkbox( 'preload', __( 'Preload manager', 'steady-speed' ), __( 'Allows the limited automatic preloads (max 1 image, 2 fonts). Nothing is preloaded if this is off.', 'steady-speed' ) );
		self::checkbox( 'hints', __( 'Resource hints', 'steady-speed' ), __( 'preconnect to at most 3 origins serving render-critical files; dns-prefetch for delayed third-party origins.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'Images', 'steady-speed' ), __( 'Media Library images are converted by attachment: one progress item per uploaded image, while WordPress thumbnail sizes are converted automatically as part of that image. WebP copies are stored next to the original (image.webp). Frontend images outside the Media Library are discovered from rendered pages and queued automatically. Originals are never modified.', 'steady-speed' ) );
		self::select(
			'img_mode',
			__( 'Image optimization mode', 'steady-speed' ),
			array(
				'safe'     => __( 'Safe – lazy loading only', 'steady-speed' ),
				'balanced' => __( 'Balanced – + WebP, responsive srcset/sizes, lazy iframes', 'steady-speed' ),
				'advanced' => __( 'Advanced – + AVIF where the server supports it', 'steady-speed' ),
				'custom'   => __( 'Custom (individual options below)', 'steady-speed' ),
			),
			__( 'Choosing a mode sets the options below. WebP automatically enables site-wide conversion and delivery.', 'steady-speed' )
		);
		self::checkbox( 'img_opt', __( 'WebP – automatic delivery for all images', 'steady-speed' ), __( 'Convert JPEG/PNG Media Library images and their generated sizes to WebP, then automatically serve the WebP copy on the frontend when it exists. The original URL is retained as a fallback. Originals are never modified.', 'steady-speed' ) );
		self::checkbox( 'img_all', __( 'Optimize all website images', 'steady-speed' ), __( 'Scans uploads, themes and plugins for JPEG/PNG images and creates smaller WebP/AVIF copies. Originals are never modified.', 'steady-speed' ) );
		self::checkbox( 'img_avif', __( 'AVIF', 'steady-speed' ), WPSS_Images::avif_supported() ? __( 'Supported by this server.', 'steady-speed' ) : __( 'This server cannot encode AVIF; existing .avif copies are still used.', 'steady-speed' ) );
		self::checkbox( 'img_srcset', __( 'Responsive images', 'steady-speed' ), __( 'Adds srcset/sizes to media-library images that lack them (WordPress’s own sizes only).', 'steady-speed' ) );
		self::checkbox( 'iframe_lazy', __( 'Lazy-load iframes', 'steady-speed' ), __( 'YouTube, Vimeo, Maps and other embeds.', 'steady-speed' ) );
		echo '</table>';
		if ( WPSS_Settings::get( 'img_opt' ) || WPSS_Settings::get( 'img_avif' ) || WPSS_Settings::get( 'img_all' ) ) {
			$bulk = WPSS_Images::bulk_state();
			echo '<div id="wpss-image-bulk" class="wpss-image-bulk" data-nonce="' . esc_attr( wp_create_nonce( 'wpss_image_progress' ) ) . '">';
			echo '<p><a class="button button-primary" id="wpss-start-image-bulk" href="' . esc_url( self::action_url( 'webp_bulk' ) ) . '">' . esc_html__( 'Start / restart image optimization', 'steady-speed' ) . '</a></p>';
			$bt = max( 0, (int) ( $bulk['total'] ?? 0 ) ); $bp = min( $bt, (int) ( $bulk['scanned'] ?? 0 ) ); $br = max( 0, $bt - $bp ); $bc = (int) ( $bulk['done'] ?? 0 ); $bpc = $bt > 0 ? min( 100, (int) floor( ( $bp / $bt ) * 100 ) ) : 0;
			echo '<div class="wpss-image-progress"><div class="wpss-image-progress-bar" id="wpss-image-progress-bar" style="width:' . esc_attr( (string) $bpc ) . '%"></div></div>';
			echo '<p class="wpss-image-progress-text" id="wpss-image-progress-text">' . esc_html( ! empty( $bulk['running'] ) ? sprintf( __( '%d%% complete — processing images…', 'steady-speed' ), $bpc ) : ( $bt > 0 ? __( 'Optimization complete.', 'steady-speed' ) : __( 'Waiting to start…', 'steady-speed' ) ) ) . '</p>';
			echo '<div class="wpss-image-progress-stats"><strong id="wpss-img-processed">' . esc_html( (string) $bp ) . '</strong> ' . esc_html__( 'Media Library images processed', 'steady-speed' ) . ' / <strong id="wpss-img-total">' . esc_html( (string) $bt ) . '</strong> ' . esc_html__( 'Media Library images', 'steady-speed' ) . ' · <strong id="wpss-img-remaining">' . esc_html( (string) $br ) . '</strong> ' . esc_html__( 'remaining', 'steady-speed' ) . ' · <strong id="wpss-img-created">' . esc_html( (string) $bc ) . '</strong> ' . esc_html__( 'WebP/AVIF copies created', 'steady-speed' ) . ' · <strong id="wpss-img-frontend">' . esc_html( (string) WPSS_Images::frontend_queue_count() ) . '</strong> ' . esc_html__( 'frontend images queued', 'steady-speed' ) . '</div>';
		echo '<p class="description">' . esc_html__( 'Runs in small batches. The progress is shown live. If WP-Cron is delayed or disabled, this admin page processes the next batch automatically. Originals are never modified.', 'steady-speed' ) . '</p>';
		echo '</div>';
		echo '<script>(function(){var box=document.getElementById("wpss-image-bulk");if(!box)return;var n=box.getAttribute("data-nonce"),bar=document.getElementById("wpss-image-progress-bar"),txt=document.getElementById("wpss-image-progress-text"),p=document.getElementById("wpss-img-processed"),t=document.getElementById("wpss-img-total"),r=document.getElementById("wpss-img-remaining"),c=document.getElementById("wpss-img-created"),f=document.getElementById("wpss-img-frontend"),busy=false;function ajax(action,cb){var f=new FormData();f.append("action",action);f.append("nonce",n);fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:f}).then(function(x){return x.json()}).then(cb).catch(function(){busy=false;});}function render(d){if(!d)return;var pct=parseInt(d.percent||0,10);bar.style.width=pct+"%";p.textContent=d.processed||0;t.textContent=d.total||0;r.textContent=d.remaining||0;c.textContent=d.created||0;if(f)f.textContent=d.frontend_queue||0;txt.textContent=d.running?(pct+"% complete — processing images…"):((d.total||0)>0?"Optimization complete — all images processed.":"Waiting to start…");}function tick(){ajax("wpss_image_progress",function(res){if(!res||!res.success)return;var d=res.data;render(d);if(d.running&&!busy){busy=true;ajax("wpss_image_batch",function(){busy=false;setTimeout(tick,700);});}else if(d.running){setTimeout(tick,1200);} });}document.getElementById("wpss-start-image-bulk").addEventListener("click",function(){/* normal action starts the queue; progress resumes after redirect */});tick();setInterval(tick,3000);})();</script>';
		}

		self::section( __( 'Fonts', 'steady-speed' ), __( 'The typography of the site is never changed automatically.', 'steady-speed' ) );
		self::checkbox( 'font_preconnect', __( 'Preconnect to Google Fonts', 'steady-speed' ) );
		self::checkbox( 'font_swap', __( 'font-display: swap', 'steady-speed' ), __( 'Text is shown immediately in a fallback font while the web font loads.', 'steady-speed' ) );
		self::checkbox( 'font_preload', __( 'Font preload', 'steady-speed' ), __( 'Preload at most 2 font files used by above-the-fold text (from the page analysis).', 'steady-speed' ) );
		self::checkbox( 'font_local', __( 'Local fonts (host Google Fonts on this site)', 'steady-speed' ) );
		self::checkbox( 'font_prune', __( 'Remove unused font weights', 'steady-speed' ), __( 'Requests only the Google Fonts weights/styles found on analyzed pages (needs at least 3 analyzed pages including the home page; 400 is always kept). Off by default: a page that was never analyzed could use a removed weight.', 'steady-speed' ) );
		self::checkbox( 'font_disable', __( 'Disable Google Fonts', 'steady-speed' ), __( 'Removes Google Fonts stylesheets (including Elementor’s). Text falls back to your theme’s font stack.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'Elementor', 'steady-speed' ), __( 'The Elementor editor and preview always use original assets. Elementor JavaScript is never deferred or delayed.', 'steady-speed' ) );
		self::checkbox( 'el_asset_opt', __( 'Elementor asset optimization', 'steady-speed' ), __( 'Minify and content-version Elementor CSS/JS files; saves and “Regenerate CSS” refresh affected pages automatically.', 'steady-speed' ) );
		self::checkbox( 'el_widget_detect', __( 'Widget asset detection', 'steady-speed' ), __( 'Widget-specific CSS/JS, Swiper and popup assets are recognised and protected.', 'steady-speed' ) );
		self::checkbox( 'el_css_opt', __( 'Elementor CSS optimization', 'steady-speed' ), __( 'Allows Elementor stylesheets to load asynchronously behind Critical CSS and to be combined in order. Elementor CSS is never removed.', 'steady-speed' ) );
		echo '</table>';

		self::section( __( 'Page analysis, cache warmup & field data', 'steady-speed' ) );
		self::checkbox( 'analysis_bg', __( 'Analyze pages in the background', 'steady-speed' ), __( 'While an administrator uses wp-admin, up to 2 queued pages are analyzed per page view in a hidden frame.', 'steady-speed' ) );
		self::checkbox( 'warm', __( 'Smart cache warmup', 'steady-speed' ), __( 'After an invalidation, only affected pages are rebuilt in the background: changed pages first, then the home page, then the most visited pages.', 'steady-speed' ) );
		self::number( 'warm_batch', __( 'Pages per minute', 'steady-speed' ), __( '1 – 20.', 'steady-speed' ), array( 'min' => 1, 'max' => 20 ) );
		self::number( 'warm_max', __( 'Maximum pages per invalidation', 'steady-speed' ), __( '1 – 500.', 'steady-speed' ), array( 'min' => 1, 'max' => 500 ) );
		self::checkbox( 'cwv', __( 'Collect Core Web Vitals from visitors', 'steady-speed' ), __( 'A sample of visits reports LCP, CLS and INP numbers to this site only (no cookies, no IP stored, no third parties).', 'steady-speed' ) );
		self::number( 'cwv_rate', __( 'Sample rate (%)', 'steady-speed' ), '', array( 'min' => 1, 'max' => 100 ) );
		echo '</table>';

		submit_button();
		echo '</form>';
	}

	private static function tab_critical() {
		$counts = WPSS_Analysis::counts();
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Page analysis', 'steady-speed' ) . '</h2>';
		echo '<p>' . esc_html__( 'Critical CSS, unused-CSS removal, above-the-fold images, the LCP element and critical fonts are measured by loading each page in your browser (hidden, with scripts disabled) at a desktop (1350 px) and a mobile (412 px) viewport, exactly as an anonymous visitor would get it. No external service is used.', 'steady-speed' ) . '</p>';
		echo '<p>' . esc_html__( 'An analysis is only used while the page’s stylesheets are identical to the analyzed ones and the page has not been edited since; otherwise the complete CSS is served and the page is re-queued automatically.', 'steady-speed' ) . '</p>';
		if ( ! WPSS_Analysis::enabled() ) {
			echo '<p class="wpss-warn-text">' . esc_html__( 'No feature that needs page analysis is enabled (Critical CSS, Remove unused CSS, Above-the-fold, LCP, font preload/pruning).', 'steady-speed' ) . '</p>';
		}
		echo '<table class="wpss-table">';
		self::row( __( 'Analyzed pages', 'steady-speed' ), esc_html( (string) $counts['analyzed'] ) );
		self::row( __( 'Outdated (content changed)', 'steady-speed' ), esc_html( (string) $counts['stale'] ) );
		self::row( __( 'Queued', 'steady-speed' ), '<span id="wpss-queued">' . esc_html( (string) $counts['queued'] ) . '</span>' );
		echo '</table>';
		if ( WPSS_Analysis::enabled() ) {
			echo '<p class="wpss-buttons"><button type="button" class="button button-primary" id="wpss-analyze-now">' . esc_html__( 'Analyze queued pages now', 'steady-speed' ) . '</button> ';
			echo '<input type="url" id="wpss-analyze-url" class="regular-text" placeholder="' . esc_attr( home_url( '/' ) ) . '"> <button type="button" class="button" id="wpss-analyze-add">' . esc_html__( 'Add page to queue', 'steady-speed' ) . '</button></p>';
			echo '<p id="wpss-analyze-status" class="description" aria-live="polite"></p>';
			echo '<p class="wpss-buttons"><a class="button" href="' . esc_url( self::action_url( 'analysis_requeue' ) ) . '">' . esc_html__( 'Re-analyze all pages', 'steady-speed' ) . '</a> ';
			echo '<a class="button" href="' . esc_url( self::action_url( 'analysis_clear' ) ) . '" onclick="return confirm(\'' . esc_js( __( 'Delete all analyses?', 'steady-speed' ) ) . '\')">' . esc_html__( 'Delete all analyses', 'steady-speed' ) . '</a></p>';
			$js = "(function(){var b=document.getElementById('wpss-analyze-now'),a=document.getElementById('wpss-analyze-add'),u=document.getElementById('wpss-analyze-url'),st=document.getElementById('wpss-analyze-status'),q=document.getElementById('wpss-queued'),C=window.WPSS_ANALYZER||{};"
				. "function say(t){st.textContent=t}"
				. "b&&b.addEventListener('click',function(){if(!window.WPSSAnalyzer)return;b.disabled=true;say(" . wp_json_encode( __( 'Analyzing… keep this tab open.', 'steady-speed' ) ) . ");"
				. "WPSSAnalyzer.run({max:500,onProgress:function(d,r,p,res){q.textContent=r;say(d+' " . esc_js( __( 'done', 'steady-speed' ) ) . " – '+p+(res&&res.stored===false?' ('+(res.error||'failed')+')':' ✓')+' – '+r+' " . esc_js( __( 'left', 'steady-speed' ) ) . "')}}).then(function(n){b.disabled=false;say(n+' " . esc_js( __( 'page(s) analyzed. Their cached copies were refreshed.', 'steady-speed' ) ) . "')},function(e){b.disabled=false;say(String(e))})});"
				. "a&&a.addEventListener('click',function(){fetch(C.rest+'analysis/add',{method:'POST',credentials:'same-origin',headers:{'X-WP-Nonce':C.nonce,'Content-Type':'application/json'},body:JSON.stringify({url:u.value||'/'})}).then(function(r){return r.json()}).then(function(j){say(j.queued?(" . wp_json_encode( __( 'Queued: ', 'steady-speed' ) ) . "+j.queued):(j.message||'error'));q.textContent=(+q.textContent||0)+1})});})();";
			wp_add_inline_script( 'wpss-analyzer', $js );
		}
		echo '</div>';

		$queue = WPSS_Analysis::queue();
		if ( $queue ) {
			uasort( $queue, array( 'WPSS_Analysis', 'by_priority' ) );
			echo '<div class="wpss-card"><h2>' . esc_html__( 'Queue', 'steady-speed' ) . '</h2><table class="widefat striped"><tbody>';
			foreach ( array_slice( $queue, 0, 30, true ) as $path => $info ) {
				echo '<tr><td><code>' . esc_html( $path ) . '</code></td><td>' . esc_html( (string) $info['p'] ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}

		$files = (array) glob( WPSS_Analysis::dir() . '/*.json' );
		if ( $files ) {
			echo '<div class="wpss-card"><h2>' . esc_html__( 'Analyzed pages', 'steady-speed' ) . '</h2><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Page', 'steady-speed' ) . '</th><th>' . esc_html__( 'Critical CSS (desktop / mobile)', 'steady-speed' ) . '</th><th>' . esc_html__( 'LCP element', 'steady-speed' ) . '</th><th>' . esc_html__( 'Analyzed', 'steady-speed' ) . '</th></tr></thead><tbody>';
			foreach ( array_slice( $files, 0, 100 ) as $f ) {
				$d = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				if ( ! is_array( $d ) ) {
					continue;
				}
				$size = static function ( $dev ) use ( $d ) {
					$n = 0;
					foreach ( (array) ( $d['devices'][ $dev ]['critical'] ?? array() ) as $seg ) {
						$n += strlen( (string) $seg[1] );
					}
					return $n ? size_format( $n, 1 ) : '–';
				};
				$lcp = $d['devices']['d']['lcp'] ?? array();
				$lcp_txt = empty( $lcp ) ? '–' : ( 'text' === $lcp['type'] ? '<' . $lcp['tag'] . '> text' : $lcp['type'] . ': ' . wp_basename( (string) wp_parse_url( (string) $lcp['src'], PHP_URL_PATH ) ) );
				printf(
					'<tr><td><code>%s</code>%s</td><td>%s / %s</td><td>%s</td><td>%s</td></tr>',
					esc_html( $d['path'] ),
					! empty( $d['stale'] ) ? ' ' . self::pill( __( 'outdated', 'steady-speed' ), 'warn' ) : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_html( $size( 'd' ) ),
					esc_html( $size( 'm' ) ),
					esc_html( $lcp_txt ),
					esc_html( wp_date( 'Y-m-d H:i', (int) $d['time'] ) )
				);
			}
			echo '</tbody></table></div>';
		}
	}

	private static function tab_report() {
		$t   = WPSS_Report::totals();
		$kb  = static function ( $b ) {
			return size_format( max( 0, (int) $b ), 1 ) ? size_format( max( 0, (int) $b ), 1 ) : '0 B';
		};
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Before / after optimization', 'steady-speed' ) . '</h2>';
		if ( ! $t['pages'] ) {
			echo '<p>' . esc_html__( 'No data yet. Numbers are recorded each time a page is generated for an anonymous visitor.', 'steady-speed' ) . '</p></div>';
		} else {
			/* translators: %d pages */
			echo '<p class="description">' . esc_html( sprintf( __( 'Average per page over the %d most recently generated pages. “After” counts what the browser downloads at page load; lazy images and delayed scripts load later.', 'steady-speed' ), $t['pages'] ) ) . '</p>';
			echo '<table class="widefat striped wpss-report"><thead><tr><th></th><th>' . esc_html__( 'Before optimization', 'steady-speed' ) . '</th><th>' . esc_html__( 'After optimization', 'steady-speed' ) . '</th></tr></thead><tbody>';
			foreach ( array(
				'css'      => __( 'Total CSS', 'steady-speed' ),
				'blocking' => __( 'Render-blocking CSS (incl. inlined critical CSS)', 'steady-speed' ),
				'js'       => __( 'Total JS', 'steady-speed' ),
				'img'      => __( 'Total image size', 'steady-speed' ),
				'requests' => __( 'Number of requests (CSS + JS + images)', 'steady-speed' ),
			) as $k => $label ) {
				$b = 'requests' === $k ? number_format_i18n( $t['before'][ $k ], 1 ) : $kb( $t['before'][ $k ] );
				$a = 'requests' === $k ? number_format_i18n( $t['after'][ $k ], 1 ) : $kb( $t['after'][ $k ] );
				echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $b ) . '</td><td>' . esc_html( $a ) . '</td></tr>';
			}
			echo '</tbody></table>';
			echo '<details><summary>' . esc_html__( 'Per page', 'steady-speed' ) . '</summary><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Page', 'steady-speed' ) . '</th><th>CSS</th><th>JS</th><th>' . esc_html__( 'Images', 'steady-speed' ) . '</th><th>' . esc_html__( 'Critical CSS', 'steady-speed' ) . '</th><th>LCP</th></tr></thead><tbody>';
			foreach ( array_slice( $t['rows'], 0, 100 ) as $r ) {
				$s = $r['stats'];
				printf(
					'<tr><td><code>%s</code> %s</td><td>%s → %s</td><td>%s → %s</td><td>%s → %s</td><td>%s</td><td>%s</td></tr>',
					esc_html( $r['path'] ),
					esc_html( 'm' === $r['device'] ? '📱' : '🖥' ),
					esc_html( $kb( $s['css_orig'] ?? 0 ) ),
					esc_html( $kb( $s['css_opt'] ?? 0 ) ),
					esc_html( $kb( $s['js_orig'] ?? 0 ) ),
					esc_html( $kb( $s['js_opt'] ?? 0 ) ),
					esc_html( $kb( $s['img_orig'] ?? 0 ) ),
					esc_html( $kb( $s['img_served'] ?? 0 ) ),
					esc_html( (string) ( $s['critical'] ?? '–' ) ),
					esc_html( (string) ( $s['lcp'] ?? '–' ) )
				);
			}
			echo '</tbody></table></details></div>';
		}

		echo '<div class="wpss-card"><h2>' . esc_html__( 'Core Web Vitals (field data from your visitors)', 'steady-speed' ) . '</h2>';
		$field = WPSS_Report::field_summary();
		if ( ! WPSS_Settings::get( 'cwv' ) && ! $field ) {
			echo '<p>' . esc_html__( 'Enable “Collect Core Web Vitals from visitors” under Advanced Performance to track LCP, CLS and INP of real visits.', 'steady-speed' ) . '</p>';
		} elseif ( ! $field ) {
			echo '<p>' . esc_html__( 'Collecting… samples are aggregated hourly.', 'steady-speed' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th></th><th>LCP (p75)</th><th>CLS (p75)</th><th>INP (p75)</th><th>' . esc_html__( 'Samples', 'steady-speed' ) . '</th></tr></thead><tbody>';
			foreach ( array( 'd' => __( 'Desktop', 'steady-speed' ), 'm' => __( 'Mobile', 'steady-speed' ) ) as $dev => $label ) {
				if ( empty( $field[ $dev ] ) ) {
					continue;
				}
				$f = $field[ $dev ];
				printf(
					'<tr><th>%s</th><td>%s</td><td>%s</td><td>%s</td><td>%d</td></tr>',
					esc_html( $label ),
					self::pill( null === $f['lcp'] ? '–' : number_format_i18n( $f['lcp'] / 1000, 2 ) . ' s', self::cwv_state( 'lcp', $f['lcp'] ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					self::pill( null === $f['cls'] ? '–' : number_format_i18n( $f['cls'], 3 ), self::cwv_state( 'cls', $f['cls'] ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					self::pill( null === $f['inp'] ? '–' : (int) $f['inp'] . ' ms', self::cwv_state( 'inp', $f['inp'] ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					(int) $f['n']
				);
			}
			echo '</tbody></table>';
		}
		echo '<p class="description">' . esc_html__( 'Last 28 days, 75th percentile (the value Google uses). Thresholds: LCP ≤ 2.5 s, CLS ≤ 0.1, INP ≤ 200 ms are “good”. Field data depends on visitors’ devices and networks, hosting and page content; Steady Speed cannot guarantee any particular PageSpeed score.', 'steady-speed' ) . '</p></div>';
	}

	/**
	 * @param string    $metric Metric.
	 * @param float|int $v      Value.
	 */
	private static function cwv_state( $metric, $v ) {
		$r = WPSS_Report::rating( $metric, $v );
		return 'good' === $r ? 'good' : ( 'poor' === $r ? 'bad' : 'warn' );
	}

	private static function tab_exclusions() {
		self::form_open( 'exclusions' );
		self::section(
			__( 'Asset exclusions', 'steady-speed' ),
			__( 'One rule per line. Formats: a file name or partial path (slick.min.js), a script/style handle (handle:elementor-frontend), a whole plugin (plugin:contact-form-7), or a wildcard (*/uploads/custom-*.css). Lines starting with # are comments.', 'steady-speed' )
		);
		self::textarea( 'excl_all', __( 'Exclude from all optimization', 'steady-speed' ) );
		self::textarea( 'excl_minify', __( 'Exclude from minify', 'steady-speed' ) );
		self::textarea( 'excl_combine', __( 'Exclude from combine', 'steady-speed' ) );
		self::textarea( 'excl_defer', __( 'Exclude from defer', 'steady-speed' ) );
		self::textarea( 'excl_delay', __( 'Exclude from delay', 'steady-speed' ) );
		self::textarea( 'delay_list', __( 'Delay until interaction', 'steady-speed' ), __( 'Scripts to load only after the first click/scroll/keypress (or 8 seconds), e.g. chat widgets. Protected scripts are never delayed.', 'steady-speed' ) );
		echo '</table>';
		self::section( __( 'Page exclusions', 'steady-speed' ), __( 'URL paths or patterns, e.g. /landing-page/ or /shop/*.', 'steady-speed' ) );
		self::textarea( 'excl_urls', __( 'Do not optimize these pages', 'steady-speed' ) );
		self::textarea( 'never_cache_urls', __( 'Never cache these pages', 'steady-speed' ) );
		self::textarea( 'excl_critical', __( 'No Critical CSS / async CSS on these pages', 'steady-speed' ) );
		echo '</table>';
		self::section( __( 'Advanced exclusions', 'steady-speed' ) );
		self::textarea( 'excl_rucss', __( 'Never remove unused CSS from / load asynchronously', 'steady-speed' ), __( 'Stylesheets (same formats as above).', 'steady-speed' ) );
		self::textarea( 'excl_tp', __( 'Never delay these third-party scripts', 'steady-speed' ), __( 'URL or code fragments, e.g. widget.trustpilot.com or fbq(.', 'steady-speed' ) );
		echo '</table>';
		submit_button();
		echo '</form>';

		$auto = WPSS_Exclusions::auto();
		echo '<h2 class="wpss-section">' . esc_html__( 'Automatic exclusions', 'steady-speed' ) . '</h2><p class="description">' . esc_html__( 'Added by error detection after repeated failures reported by visitors’ browsers. They are temporary: the original file is served for 7 days, then optimization is retried; after a second failure 30 days; after a third failure the protection is permanent until you remove it.', 'steady-speed' ) . '</p>';
		if ( ! $auto ) {
			echo '<p>' . esc_html__( 'None.', 'steady-speed' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'File', 'steady-speed' ) . '</th><th>' . esc_html__( 'Scope', 'steady-speed' ) . '</th><th>' . esc_html__( 'Reason', 'steady-speed' ) . '</th><th>' . esc_html__( 'Date', 'steady-speed' ) . '</th><th>' . esc_html__( 'Retry', 'steady-speed' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $auto as $key => $info ) {
				printf(
					'<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href="%s">%s</a></td></tr>',
					esc_html( $key ),
					esc_html( $info['scope'] ?? 'all' ),
					esc_html( $info['reason'] ?? '' ),
					esc_html( isset( $info['time'] ) ? wp_date( 'Y-m-d H:i', (int) $info['time'] ) : '' ),
					esc_html( empty( $info['until'] ) ? __( 'Permanent', 'steady-speed' ) : wp_date( 'Y-m-d', (int) $info['until'] ) ),
					esc_url( self::action_url( 'remove_auto', array( 'key' => rawurlencode( $key ) ) ) ),
					esc_html__( 'Remove', 'steady-speed' )
				);
			}
			echo '</tbody></table>';
		}
		$urls = WPSS_Exclusions::auto_urls();
		if ( $urls ) {
			echo '<h3>' . esc_html__( 'Pages with optimization disabled automatically', 'steady-speed' ) . '</h3><table class="widefat striped"><tbody>';
			foreach ( $urls as $path => $info ) {
				printf(
					'<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td><a href="%s">%s</a></td></tr>',
					esc_html( $path ),
					esc_html( $info['reason'] ?? '' ),
					esc_html( isset( $info['time'] ) ? wp_date( 'Y-m-d H:i', (int) $info['time'] ) : '' ),
					esc_url( self::action_url( 'remove_auto_url', array( 'path' => rawurlencode( $path ) ) ) ),
					esc_html__( 'Remove', 'steady-speed' )
				);
			}
			echo '</tbody></table>';
		}
		$counters = WPSS_Monitor::counters();
		if ( $counters ) {
			echo '<h3>' . esc_html__( 'Pending reports (below threshold)', 'steady-speed' ) . '</h3><table class="widefat striped"><tbody>';
			foreach ( $counters as $row ) {
				printf( '<tr><td>%s</td><td>%d / %d</td></tr>', esc_html( $row['label'] ?? '' ), count( $row['clients'] ?? array() ), (int) WPSS_Monitor::THRESHOLD );
			}
			echo '</tbody></table><p><a class="button" href="' . esc_url( self::action_url( 'reset_counters' ) ) . '">' . esc_html__( 'Reset counters', 'steady-speed' ) . '</a></p>';
		}
	}

	private static function tab_database() {
		$stats = WPSS_Database::stats();
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Database cleanup', 'steady-speed' ) . '</h2><p>' . esc_html__( 'Nothing runs automatically. Each operation runs only when you confirm it.', 'steady-speed' ) . '</p>';
		/* translators: %d total revisions */
		echo '<p class="description">' . esc_html( sprintf( __( 'Total revisions: %d. Recent revisions are always kept.', 'steady-speed' ), $stats['revisions_total'] ) ) . '</p>';
		echo '<table class="widefat striped"><tbody>';
		foreach ( WPSS_Database::ops() as $op => $label ) {
			$count = 'optimize' === $op ? self::size( $stats[ $op ] ) : number_format_i18n( $stats[ $op ] );
			echo '<tr><td>' . esc_html( $label ) . '</td><td><strong>' . esc_html( $count ) . '</strong></td><td>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="wpss-inline" onsubmit="return confirm(\'' . esc_js( __( 'Run this cleanup now? This cannot be undone.', 'steady-speed' ) ) . '\')">';
			wp_nonce_field( 'wpss_action' );
			echo '<input type="hidden" name="action" value="wpss_action"><input type="hidden" name="do" value="db"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
			echo '<label><input type="checkbox" name="confirm_backup" value="1" required> ' . esc_html__( 'I have a recent database backup', 'steady-speed' ) . '</label> ';
			echo '<button class="button" ' . disabled( empty( $stats[ $op ] ), true, false ) . '>' . esc_html__( 'Run', 'steady-speed' ) . '</button></form></td></tr>';
		}
		echo '</tbody></table><p class="description">' . esc_html__( 'Table optimization can briefly lock large tables; run it during low traffic.', 'steady-speed' ) . '</p></div>';
	}

	private static function tab_debug() {
		$c = get_option( WPSS_Debug::COUNTERS, array() );
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Tools', 'steady-speed' ) . '</h2><p class="wpss-buttons">';
		echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'wpss_debug', '1', home_url( '/' ) ) ) . '">' . esc_html__( 'Open debug view', 'steady-speed' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( self::action_url( 'clear_assets' ) ) . '">' . esc_html__( 'Rebuild optimized files', 'steady-speed' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( self::action_url( 'recheck_server' ) ) . '">' . esc_html__( 'Re-check server rules', 'steady-speed' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( self::action_url( 'clear_log' ) ) . '">' . esc_html__( 'Clear log', 'steady-speed' ) . '</a></p>';
		if ( WPSS_Settings::get( 'debug' ) ) {
			/* translators: 1 hits 2 misses */
			echo '<p>' . esc_html( sprintf( __( 'Cache hits: %1$d · misses: %2$d', 'steady-speed' ), (int) ( $c['hit'] ?? 0 ), (int) ( $c['miss'] ?? 0 ) ) ) . '</p>';
		} else {
			echo '<p class="description">' . esc_html__( 'Enable Debug mode in Settings to record per-page reports and hit/miss counts. Response header X-WPSS-Cache always shows HIT or MISS.', 'steady-speed' ) . '</p>';
		}
		echo '<p class="description">' . esc_html__( 'Emergency switch without wp-admin: add define( \'WPSS_SAFE_MODE\', true ); to wp-config.php.', 'steady-speed' ) . '</p></div>';

		$events = WPSS_Monitor::events();
		echo '<div class="wpss-card"><h2>' . esc_html__( 'Protection events', 'steady-speed' ) . '</h2>';
		if ( ! $events ) {
			echo '<p>' . esc_html__( 'No JavaScript errors or failed assets have been reported.', 'steady-speed' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'When', 'steady-speed' ) . '</th><th>' . esc_html__( 'Asset / page', 'steady-speed' ) . '</th><th>' . esc_html__( 'Problem', 'steady-speed' ) . '</th><th>' . esc_html__( 'Dependency', 'steady-speed' ) . '</th><th>' . esc_html__( 'Status', 'steady-speed' ) . '</th><th>' . esc_html__( 'Action', 'steady-speed' ) . '</th></tr></thead><tbody>';
			foreach ( array_slice( $events, 0, 50 ) as $e ) {
				printf(
					'<tr><td>%s</td><td><code>%s</code><br><small>%s</small></td><td>%s%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
					esc_html( wp_date( 'Y-m-d H:i', (int) $e['t'] ) ),
					esc_html( $e['asset'] ),
					esc_html( $e['group'] . ( '' !== $e['handle'] ? ' · ' . $e['handle'] : '' ) ),
					esc_html( $e['what'] ),
					'' !== $e['msg'] ? '<br><small>' . esc_html( $e['msg'] ) . '</small>' : '',
					esc_html( '' !== $e['deps'] ? $e['deps'] : '–' ),
					self::pill( $e['status'], 'Protected' === $e['status'] ? 'warn' : 'off' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_html( $e['action'] )
				);
			}
			echo '</tbody></table><p><a class="button" href="' . esc_url( self::action_url( 'clear_events' ) ) . '">' . esc_html__( 'Clear events', 'steady-speed' ) . '</a></p>';
		}
		echo '<p class="description">' . esc_html__( 'Reports contain only the file or page path and the error message – no visitor data – and never leave this site.', 'steady-speed' ) . '</p></div>';

		$graph = WPSS_Assets::graph();
		if ( $graph ) {
			$groups = array();
			foreach ( $graph as $key => $g ) {
				$groups[ $g['group'] ][] = $g;
			}
			ksort( $groups );
			echo '<div class="wpss-card"><h2>' . esc_html__( 'Dependency map', 'steady-speed' ) . '</h2><p class="description">' . esc_html__( 'Assets seen on your pages, by dependency group. Scripts always load after everything they depend on; protected groups are never deferred or delayed.', 'steady-speed' ) . '</p>';
			foreach ( $groups as $name => $items ) {
				echo '<details><summary><strong>' . esc_html( $name ) . '</strong> (' . count( $items ) . ')</summary><ul class="wpss-deps">';
				foreach ( $items as $g ) {
					echo '<li><code>' . esc_html( $g['handle'] ) . '</code> [' . esc_html( strtoupper( $g['type'] ) ) . ']' . ( $g['deps'] ? ' ← ' . esc_html( implode( ', ', $g['deps'] ) ) : '' ) . '</li>';
				}
				echo '</ul></details>';
			}
			echo '</div>';
		}

		$reports = WPSS_Debug::reports();
		if ( $reports ) {
			echo '<div class="wpss-card"><h2>' . esc_html__( 'Recent page reports', 'steady-speed' ) . '</h2>';
			foreach ( $reports as $r ) {
				echo '<details><summary><code>' . esc_html( $r['url'] ) . '</code> – ' . esc_html( wp_date( 'Y-m-d H:i:s', (int) $r['time'] ) ) . '</summary><pre class="wpss-pre">' . esc_html( implode( "\n", (array) $r['lines'] ) ) . '</pre></details>';
			}
			echo '</div>';
		}

		echo '<div class="wpss-card"><h2>' . esc_html__( 'Activity log', 'steady-speed' ) . '</h2>';
		$entries = WPSS_Logger::entries();
		if ( ! $entries ) {
			echo '<p>' . esc_html__( 'Empty.', 'steady-speed' ) . '</p>';
		} else {
			echo '<table class="widefat striped wpss-log"><tbody>';
			foreach ( array_slice( $entries, 0, 200 ) as $e ) {
				printf( '<tr class="wpss-l-%1$s"><td>%2$s</td><td>%3$s</td><td>%4$s</td></tr>', esc_attr( $e['l'] ), esc_html( wp_date( 'Y-m-d H:i:s', (int) $e['t'] ) ), esc_html( $e['l'] ), esc_html( $e['m'] ) );
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
