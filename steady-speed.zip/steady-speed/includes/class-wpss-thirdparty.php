<?php
/**
 * Third-party script delay (final HTML pass).
 *
 * Safe strategy (default): only EXTERNAL script tags of well-known, self-contained services are
 * delayed (analytics loaders, chat, review and social widgets). Their inline configuration
 * snippets keep running immediately, so calls like gtag('event', …) are simply queued.
 *
 * Advanced strategy: additionally delays well-known inline "injector" snippets (Google Tag
 * Manager, Meta Pixel, Hotjar, Clarity, chat widgets, ad/pixel tags). Queue stubs are installed
 * first so other code calling fbq()/hj()/clarity() keeps working; queued calls are replayed.
 *
 * Never delayed: payment, CAPTCHA, cookie consent, authentication, form services, maps with
 * inline initialisation, anything on WooCommerce cart/checkout/account pages, user exclusions.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_ThirdParty {

	/**
	 * Known services. src: URL fragments of external scripts. inline: fragments identifying an
	 * inline injector snippet (advanced only). stub: JS installed before the delayed code.
	 */
	public static function services() {
		return apply_filters(
			'wpss_third_party_services',
			array(
				'ga'        => array(
					'label'  => 'Google Analytics',
					'src'    => array( 'googletagmanager.com/gtag/js', 'google-analytics.com/analytics.js', 'google-analytics.com/ga.js' ),
					'inline' => array( 'google-analytics.com/analytics.js' ),
					'stub'   => 'window.dataLayer=window.dataLayer||[];window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;',
				),
				'gtm'       => array(
					'label'  => 'Google Tag Manager',
					'src'    => array( 'googletagmanager.com/gtm.js' ),
					'inline' => array( 'googletagmanager.com/gtm.js' ),
					'stub'   => 'window.dataLayer=window.dataLayer||[];',
				),
				'fbq'       => array(
					'label'  => 'Meta (Facebook) Pixel',
					'src'    => array( 'connect.facebook.net/en_US/fbevents.js', '/fbevents.js' ),
					'inline' => array( 'fbevents.js' ),
					'stub'   => '!function(w){if(w.fbq)return;var q=[],f=function(){q.push([].slice.call(arguments))};f.wpssq=q;w.fbq=f;w._fbq=f}(window);',
					'reset'  => 'fbq,_fbq',
					'replay' => 'fbq',
				),
				'fbsdk'     => array(
					'label'  => 'Facebook SDK / social embeds',
					'src'    => array( 'connect.facebook.net/', 'platform.twitter.com/widgets.js', 'instagram.com/embed.js', 'tiktok.com/embed.js', 'assets.pinterest.com/js/pinit', 'platform.linkedin.com/in.js' ),
					'inline' => array(),
				),
				'hotjar'    => array(
					'label'  => 'Hotjar',
					'src'    => array( 'static.hotjar.com' ),
					'inline' => array( 'static.hotjar.com' ),
					'stub'   => 'window.hj=window.hj||function(){(hj.q=hj.q||[]).push(arguments)};',
				),
				'clarity'   => array(
					'label'  => 'Microsoft Clarity',
					'src'    => array( 'clarity.ms/tag' ),
					'inline' => array( 'clarity.ms/tag' ),
					'stub'   => 'window.clarity=window.clarity||function(){(window.clarity.q=window.clarity.q||[]).push(arguments)};',
				),
				'chat'      => array(
					'label'  => 'Chat widget',
					'src'    => array( 'embed.tawk.to', 'widget.intercom.io', 'js.intercomcdn.com', 'client.crisp.chat', 'js.driftt.com', 'cdn.livechatinc.com', 'code.tidio.co', 'static.zdassets.com', 'wchat.freshchat.com', 'widget.manychat.com', 'js.hs-scripts.com', 'embed.small.chat', 'userlike-cdn-widgets', 'app.chatwoot.com' ),
					'inline' => array( 'embed.tawk.to', 'client.crisp.chat', 'widget.intercom.io', 'js.driftt.com', 'cdn.livechatinc.com', 'code.tidio.co' ),
				),
				'reviews'   => array(
					'label'  => 'Review widget',
					'src'    => array( 'widget.trustpilot.com', 'apps.elfsight.com', 'static.elfsight.com', 'elfsightcdn.com', 'cdn.trustindex.io', 'widget.reviews.io', 'reviewsonmywebsite.com', 'featurable.com', 'widget.judge.me', 'staticw2.yotpo.com' ),
					'inline' => array(),
				),
				'youtube'   => array(
					'label'  => 'YouTube API',
					'src'    => array( 'youtube.com/iframe_api', 'youtube.com/player_api' ),
					'inline' => array(),
					'advanced_only' => true,
				),
				'ads'       => array(
					'label'  => 'Ad / conversion pixels',
					'src'    => array( 'pagead2.googlesyndication.com', 'googleads.g.doubleclick.net', 'static.ads-twitter.com', 'snap.licdn.com', 'analytics.tiktok.com', 's.pinimg.com/ct', 'bat.bing.com', 'sc-static.net/scevent', 'cdn.taboola.com', 'static.klaviyo.com/onsite' ),
					'inline' => array( 'snap.licdn.com', 'analytics.tiktok.com', 'bat.bing.com', 's.pinimg.com/ct', 'static.ads-twitter.com' ),
					'advanced_only' => true,
				),
				'maps'      => array(
					'label'  => 'Google Maps API (callback loading only)',
					'src'    => array( 'maps.googleapis.com/maps/api/js' ),
					'inline' => array(),
					'advanced_only' => true,
					'require' => 'callback=',
				),
			)
		);
	}

	/**
	 * Never delay scripts matching these fragments.
	 */
	public static function never() {
		return apply_filters(
			'wpss_third_party_never',
			array(
				// Payment / checkout.
				'js.stripe.com', 'paypal.com/sdk', 'paypalobjects.com', 'squareup.com', 'squarecdn.com', 'braintreegateway.com', 'klarna', 'mollie.com', 'checkout.razorpay.com', 'pay.google.com', 'applepay', 'adyen', 'afterpay', 'clearpay',
				// CAPTCHA / bot protection.
				'recaptcha', 'hcaptcha', 'turnstile', 'challenges.cloudflare.com', 'grecaptcha',
				// Consent (must run before trackers).
				'cookiebot', 'cookielaw.org', 'onetrust', 'cookieyes', 'complianz', 'cmplz', 'iubenda', 'usercentrics', 'termly', 'cookie-script', 'osano', 'consensu.org', 'borlabs', 'gtag(\'consent\'', 'gtag("consent"',
				// Authentication.
				'accounts.google.com/gsi', 'appleid.cdn-apple.com', 'connect.facebook.net/en_US/sdk/xfbml.customerchat',
				// Forms.
				'js.hsforms.net', 'forms.hsforms', 'jotform', 'typeform', 'calendly', 'wpforms', 'gform', 'wpcf7',
			)
		);
	}

	/**
	 * @param string $html HTML.
	 */
	public static function process( $html ) {
		if ( ! WPSS_Settings::get( 'tp_delay' ) || ! WPSS_Context::optimize() || WPSS_Analysis::is_analysis_request() ) {
			return $html;
		}
		if ( WPSS_Context::is_transactional() ) {
			WPSS_Debug::note( 'Third-party delay', 'Off on WooCommerce cart/checkout/account pages' );
			return $html;
		}
		if ( WPSS_CSS_Delivery::csp_blocks_inline() ) {
			return $html;
		}
		$advanced = 'advanced' === WPSS_Settings::get( 'tp_mode' );
		$trigger  = (string) WPSS_Settings::get( 'tp_trigger' );
		$services = self::services();
		$never    = self::never();
		$user     = WPSS_Settings::lines( 'excl_tp' );
		$stubs    = array();
		$count    = 0;
		$hosts    = array();

		$html = preg_replace_callback(
			'#<script\b([^>]*)>(.*?)</script>#is',
			static function ( $m ) use ( $advanced, $trigger, $services, $never, $user, &$stubs, &$count, &$hosts ) {
				$attrs = $m[1];
				$body  = $m[2];
				if ( preg_match( '/\stype\s*=\s*["\']?(?!text\/javascript|application\/javascript|module)[^"\'\s>]+/i', $attrs ) ) {
					return $m[0]; // JSON, templates, already delayed, …
				}
				if ( false !== stripos( $attrs, 'data-wpss' ) || false !== stripos( $attrs, 'data-no-delay' ) || false !== stripos( $attrs, 'data-cfasync' ) ) {
					return $m[0];
				}
				$src      = '';
				$external = preg_match( '/\ssrc\s*=\s*(["\'])(.*?)\1/is', $attrs, $sm );
				if ( $external ) {
					$src = html_entity_decode( $sm[2], ENT_QUOTES );
				}
				$subject = $external ? $src : $body;
				if ( '' === trim( $subject ) || strlen( $body ) > 20000 ) {
					return $m[0];
				}
				foreach ( $never as $n ) {
					if ( false !== stripos( $subject, $n ) || ( $external && false !== stripos( $attrs, $n ) ) ) {
						return $m[0];
					}
				}
				foreach ( $user as $pattern ) {
					if ( false !== stripos( $subject, $pattern ) || false !== stripos( $attrs, $pattern ) ) {
						return $m[0];
					}
				}
				$hit = null;
				foreach ( $services as $id => $svc ) {
					if ( ! empty( $svc['advanced_only'] ) && ! $advanced ) {
						continue;
					}
					$list = $external ? $svc['src'] : ( $advanced ? $svc['inline'] : array() );
					foreach ( $list as $frag ) {
						if ( false !== stripos( $subject, $frag ) ) {
							$hit = $id;
							break 2;
						}
					}
				}
				if ( null === $hit ) {
					return $m[0];
				}
				$svc = $services[ $hit ];
				if ( ! empty( $svc['require'] ) && false === stripos( $subject, $svc['require'] ) ) {
					return $m[0];
				}
				if ( ! $external && preg_match( '/document\.write\s*\(/', $body ) ) {
					return $m[0]; // Would wipe the page if run late.
				}
				++$count;
				$inline_injector = ! $external;
				if ( ! empty( $svc['stub'] ) && ( $inline_injector || empty( $svc['reset'] ) ) ) {
					$stubs[ $hit ] = $svc['stub'];
				}
				if ( $external ) {
					$h = strtolower( (string) wp_parse_url( $src, PHP_URL_HOST ) );
					if ( '' !== $h ) {
						$hosts[ $h ] = true;
					}
				}
				WPSS_Debug::add( 'js', $svc['label'] . ( $external ? ' (' . wp_basename( (string) wp_parse_url( $src, PHP_URL_PATH ) ) . ')' : ' (inline snippet)' ), 'Delayed', 'Third-party: ' . $trigger );

				$new = $attrs;
				$new = preg_replace( '/\s(defer|async|data-wp-strategy)(\s*=\s*(["\'])[^"\']*\3)?(?=[\s>\/]|$)/i', '', $new );
				if ( preg_match( '/\stype\s*=\s*(["\'])module\1/i', $new ) ) {
					$new = preg_replace( '/\stype\s*=\s*(["\'])module\1/i', ' data-wpss-type="module"', $new );
				} else {
					$new = preg_replace( '/\stype\s*=\s*(["\'])[^"\']*\1/i', '', $new );
				}
				if ( $external ) {
					$new = preg_replace( '/\ssrc\s*=/i', ' data-wpss-src=', $new, 1 );
				}
				$extra = ' type="wpss/delayed" data-wpss-trigger="' . esc_attr( $trigger ) . '" data-wpss-tp="' . esc_attr( $hit ) . '"';
				if ( ! empty( $svc['reset'] ) && $inline_injector ) {
					$extra .= ' data-wpss-reset="' . esc_attr( $svc['reset'] ) . '" data-wpss-replay="' . esc_attr( $svc['replay'] ) . '"';
				}
				return '<script' . $extra . $new . '>' . $body . '</script>';
			},
			$html
		);
		if ( ! $count || null === $html ) {
			return (string) $html;
		}
		WPSS_Stats::add( 'tp_delayed', $count );
		WPSS_Stats::set( 'tp_hosts', array_keys( $hosts ) );

		// Queue stubs as early as possible in <head>.
		if ( $stubs ) {
			$stub = wp_get_inline_script_tag( implode( '', $stubs ), array( 'id' => 'wpss-tp-stubs' ) );
			$html = preg_replace( '#(<head\b[^>]*>)#i', '$1' . $stub, $html, 1 );
		}
		// Loader (unless the dependency system already printed it).
		if ( ! WPSS_Assets::$loader_printed && false === strpos( $html, 'id="wpss-delay-loader"' ) ) {
			$pos  = strripos( $html, '</body>' );
			$tag  = WPSS_Assets::loader_tag();
			$html = false === $pos ? $html . $tag : substr_replace( $html, $tag, $pos, 0 );
		}
		return $html;
	}
}
