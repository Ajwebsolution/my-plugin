<?php
/**
 * Filesystem helpers (WP_Filesystem based) and safe URL <-> path mapping.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_FS {

	/** @var bool|null */
	private static $ready = null;

	/**
	 * Initialise WP_Filesystem with the "direct" method only.
	 * Optimized files are generated during front-end requests, where credentials cannot be requested.
	 */
	public static function ready() {
		if ( null !== self::$ready ) {
			return self::$ready;
		}
		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( 'direct' !== get_filesystem_method( array(), WP_CONTENT_DIR ) ) {
			self::$ready = false;
			return false;
		}
		self::$ready = WP_Filesystem() && is_object( $wp_filesystem );
		return self::$ready;
	}

	/**
	 * Create cache directories and protective files.
	 */
	public static function ensure_dirs() {
		foreach ( array( '', '/assets/css', '/assets/js', '/assets/map', '/pages', '/fonts', '/analysis', '/reports', '/data' ) as $sub ) {
			wp_mkdir_p( WPSS_CACHE_DIR . $sub );
		}
		if ( ! self::ready() ) {
			return;
		}
		$silence = "<?php\n// Silence is golden.\n";
		foreach ( array( '', '/assets', '/assets/css', '/assets/js', '/assets/map', '/pages', '/fonts', '/analysis', '/reports', '/data' ) as $sub ) {
			$index = WPSS_CACHE_DIR . $sub . '/index.php';
			if ( ! file_exists( $index ) ) {
				self::put( $index, $silence );
			}
		}
		foreach ( array( '/pages', '/assets/map', '/analysis', '/reports', '/data' ) as $private ) {
			$deny = WPSS_CACHE_DIR . $private . '/.htaccess';
			if ( ! file_exists( $deny ) ) {
				self::put( $deny, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
			}
		}
	}

	/**
	 * Atomic-ish write: temp file + move.
	 *
	 * @param string $file    Absolute path.
	 * @param string $content Content.
	 */
	public static function put( $file, $content ) {
		if ( ! self::ready() ) {
			return false;
		}
		global $wp_filesystem;
		wp_mkdir_p( dirname( $file ) );
		$tmp = $file . '.' . wp_rand( 100000, 999999 ) . '.tmp';
		if ( ! $wp_filesystem->put_contents( $tmp, $content, FS_CHMOD_FILE ) ) {
			return false;
		}
		if ( ! $wp_filesystem->move( $tmp, $file, true ) ) {
			$wp_filesystem->delete( $tmp );
			return false;
		}
		return true;
	}

	/**
	 * Refresh mtime (used for "still in use" tracking of optimized files).
	 *
	 * @param string $file File.
	 */
	public static function touch( $file ) {
		if ( self::ready() ) {
			global $wp_filesystem;
			$wp_filesystem->touch( $file );
		}
	}

	/**
	 * Move/rename.
	 *
	 * @param string $from From.
	 * @param string $to   To.
	 */
	public static function move( $from, $to ) {
		if ( ! self::ready() ) {
			return false;
		}
		global $wp_filesystem;
		return $wp_filesystem->move( $from, $to, false );
	}

	/**
	 * Recursive delete (restricted to the plugin cache directory).
	 *
	 * @param string $dir Directory.
	 */
	public static function rrmdir( $dir ) {
		if ( ! self::is_inside( $dir, WPSS_CACHE_DIR ) || ! self::ready() ) {
			return false;
		}
		global $wp_filesystem;
		return $wp_filesystem->delete( $dir, true );
	}

	/**
	 * Is $path inside $root?
	 *
	 * @param string $path Path.
	 * @param string $root Root.
	 */
	public static function is_inside( $path, $root ) {
		$path = wp_normalize_path( $path );
		$root = trailingslashit( wp_normalize_path( $root ) );
		return 0 === strpos( trailingslashit( $path ), $root ) && false === strpos( $path, '..' );
	}

	/**
	 * Public URL of a file relative to the cache dir.
	 *
	 * @param string $rel Relative path.
	 * @return string|false
	 */
	public static function cache_url( $rel = '' ) {
		$content = wp_normalize_path( WP_CONTENT_DIR );
		$cache   = wp_normalize_path( WPSS_CACHE_DIR );
		if ( 0 !== strpos( $cache, $content ) ) {
			return false;
		}
		return set_url_scheme( content_url( substr( $cache, strlen( $content ) ) . '/' . ltrim( $rel, '/' ) ) );
	}

	/**
	 * Site host (with port).
	 */
	/**
	 * host[:port] of a URL ('' for relative URLs).
	 *
	 * @param string $url URL.
	 */
	public static function url_host( $url ) {
		$parts = wp_parse_url( (string) $url );
		if ( empty( $parts['host'] ) ) {
			return '';
		}
		return strtolower( $parts['host'] ) . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
	}

	/**
	 * host[:port] of the site.
	 */
	public static function home_host() {
		$parts = wp_parse_url( home_url() );
		$host  = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
		return $host . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
	}

	/**
	 * Map a local asset URL to an absolute file path. Returns false for remote or unsafe URLs.
	 *
	 * @param string $url URL (absolute, protocol-relative or root-relative).
	 * @return string|false
	 */
	public static function url_to_path( $url ) {
		static $map = null, $memo = array();
		if ( ! is_string( $url ) || '' === $url || false !== strpos( $url, "\0" ) ) {
			return false;
		}
		if ( isset( $memo[ $url ] ) ) {
			return $memo[ $url ];
		}
		$clean = preg_replace( '/[?#].*$/', '', $url );
		if ( 0 === strpos( $clean, '//' ) ) {
			$clean = 'http:' . $clean;
		} elseif ( 0 === strpos( $clean, '/' ) ) {
			$clean = 'http://' . self::home_host() . $clean;
		}
		$clean = set_url_scheme( $clean, 'http' );

		if ( null === $map ) {
			$up  = wp_get_upload_dir();
			$map = array(
				array( WP_PLUGIN_URL, WP_PLUGIN_DIR ),
				array( $up['baseurl'], $up['basedir'] ),
				array( content_url(), WP_CONTENT_DIR ),
				array( includes_url(), ABSPATH . WPINC ),
				array( site_url(), ABSPATH ),
			);
			foreach ( $map as $i => $pair ) {
				$map[ $i ] = array( trailingslashit( set_url_scheme( untrailingslashit( $pair[0] ), 'http' ) ), untrailingslashit( wp_normalize_path( $pair[1] ) ) );
			}
		}

		$result = false;
		foreach ( $map as $pair ) {
			if ( 0 === stripos( $clean, $pair[0] ) ) {
				$rel = rawurldecode( substr( $clean, strlen( $pair[0] ) ) );
				if ( '' === $rel || false !== strpos( $rel, '..' ) || false !== strpos( $rel, "\0" ) ) {
					break;
				}
				$file = $pair[1] . '/' . ltrim( $rel, '/' );
				if ( is_file( $file ) ) {
					$result = $file;
				}
				break;
			}
		}
		$memo[ $url ] = $result;
		return $result;
	}

	/**
	 * Stable key for a file, matching as a substring of its URL (used for exclusions).
	 *
	 * @param string $path Absolute path.
	 */
	public static function relative_key( $path ) {
		$p = wp_normalize_path( $path );
		foreach ( array( trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ), trailingslashit( wp_normalize_path( ABSPATH ) ) ) as $base ) {
			if ( 0 === strpos( $p, $base ) ) {
				return substr( $p, strlen( $base ) );
			}
		}
		return basename( $p );
	}

	/**
	 * Count and size of files in a directory tree.
	 *
	 * @param string $dir     Directory.
	 * @param string $pattern Optional filename regex.
	 * @return array{0:int,1:int}
	 */
	public static function dir_stats( $dir, $pattern = '' ) {
		$count = 0;
		$size  = 0;
		if ( ! is_dir( $dir ) ) {
			return array( 0, 0 );
		}
		try {
			$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $f ) {
				if ( $f->isFile() && ( '' === $pattern || preg_match( $pattern, $f->getFilename() ) ) ) {
					++$count;
					$size += $f->getSize();
				}
			}
		} catch ( Exception $e ) {
			return array( $count, $size );
		}
		return array( $count, $size );
	}
}
