<?php
/**
 * Browser caching headers.
 *
 * Optimized files are content-addressed (hash in the file name), so they get a one-year
 * immutable lifetime. Original theme/plugin files keep their ?ver= busting and get a modest
 * lifetime. Every server config change is verified with a loopback request and rolled back
 * if the site stops answering.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * .htaccess management.
 */
class WPSS_Browser_Cache {

	const MARKER = 'Steady Speed';
	const STATUS = 'wpss_browser_cache_status';

	/**
	 * Rules for the plugin's own cache folders (hashed files only).
	 */
	private static function asset_rules() {
		return "# Steady Speed – hashed files never change.\n"
			. "<IfModule mod_headers.c>\n"
			. "<FilesMatch \"\\.(css|js|woff2?|ttf|otf)$\">\n"
			. "Header set Cache-Control \"public, max-age=31536000, immutable\"\n"
			. "</FilesMatch>\n"
			. "</IfModule>\n";
	}

	/**
	 * Lines for the root .htaccess.
	 *
	 * @return string[]
	 */
	private static function root_rules() {
		$lines = array( '<IfModule mod_expires.c>', 'ExpiresActive On' );
		$types = array(
			'text/css'                 => '7 days',
			'text/javascript'          => '7 days',
			'application/javascript'   => '7 days',
			'application/x-javascript' => '7 days',
			'image/jpeg'               => '30 days',
			'image/png'                => '30 days',
			'image/gif'                => '30 days',
			'image/webp'               => '30 days',
			'image/avif'               => '30 days',
			'image/svg+xml'            => '30 days',
			'image/x-icon'             => '30 days',
			'image/vnd.microsoft.icon' => '30 days',
			'font/woff2'               => '1 year',
			'font/woff'                => '1 year',
			'font/ttf'                 => '1 year',
			'application/font-woff2'   => '1 year',
			'application/font-woff'    => '1 year',
		);
		foreach ( $types as $mime => $life ) {
			$lines[] = sprintf( 'ExpiresByType %s "access plus %s"', $mime, $life );
		}
		$lines[] = '</IfModule>';
		return $lines;
	}

	/**
	 * Is this Apache/LiteSpeed (reads .htaccess)?
	 */
	private static function is_apache() {
		global $is_apache;
		return ! empty( $is_apache );
	}

	/**
	 * Bring the server config in line with the setting. Called on activation and settings save.
	 */
	public static function sync() {
		$on     = WPSS_Settings::get( 'browser_cache' ) && ! WPSS_Settings::safe_mode();
		$status = array(
			'assets' => 'off',
			'root'   => 'off',
			'time'   => time(),
		);
		if ( ! WPSS_FS::ready() ) {
			$status['assets'] = $on ? 'no-filesystem' : 'off';
			update_option( self::STATUS, $status, false );
			return;
		}
		WPSS_FS::ensure_dirs();
		$asset_files = array( WPSS_CACHE_DIR . '/assets/.htaccess', WPSS_CACHE_DIR . '/fonts/.htaccess' );

		if ( ! $on || ! self::is_apache() ) {
			foreach ( $asset_files as $f ) {
				if ( is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
			self::remove_root_rules();
			if ( $on ) {
				$status['assets'] = 'not-apache';
				$status['root']   = 'not-apache';
			}
			update_option( self::STATUS, $status, false );
			return;
		}

		// 1. Plugin folders (low risk, but still verified).
		foreach ( $asset_files as $f ) {
			WPSS_FS::put( $f, self::asset_rules() );
		}
		$probe = WPSS_CACHE_DIR . '/assets/css/wpss-probe.css';
		WPSS_FS::put( $probe, '/* probe */' );
		$check = self::probe( WPSS_FS::cache_url( 'assets/css/wpss-probe.css' ) );
		wp_delete_file( $probe );
		if ( 'fail' === $check ) {
			foreach ( $asset_files as $f ) {
				wp_delete_file( $f );
			}
			WPSS_Logger::log( 'Browser-cache rules for optimized files were rolled back: the server rejected them.', 'warning' );
			$status['assets'] = 'rolled-back';
		} else {
			$status['assets'] = 'ok' === $check ? 'active' : 'unverified';
		}

		// 2. Root .htaccess: only when writable AND we can prove the site still works.
		if ( ! function_exists( 'get_home_path' ) || ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		$htaccess = get_home_path() . '.htaccess';
		if ( ( is_file( $htaccess ) && ! wp_is_writable( $htaccess ) ) || ( ! is_file( $htaccess ) && ! wp_is_writable( dirname( $htaccess ) ) ) ) {
			$status['root'] = 'not-writable';
		} else {
			insert_with_markers( $htaccess, self::MARKER, self::root_rules() );
			$check = self::probe( add_query_arg( 'wpss_selftest', time(), home_url( '/' ) ) );
			if ( 'ok' !== $check ) {
				self::remove_root_rules();
				$status['root'] = 'fail' === $check ? 'rolled-back' : 'unverified-skipped';
				if ( 'fail' === $check ) {
					WPSS_Logger::log( 'Root .htaccess expiry rules were rolled back: the site returned a server error.', 'warning' );
				}
			} else {
				$status['root'] = 'active';
			}
		}
		update_option( self::STATUS, $status, false );
	}

	/**
	 * Loopback check. ok | fail (5xx/403) | unknown (loopback not possible).
	 *
	 * @param string $url URL.
	 */
	private static function probe( $url ) {
		$r = wp_remote_get(
			$url,
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'sslverify'   => false,
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return 'unknown';
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( $code >= 500 || 403 === $code ) {
			return 'fail';
		}
		return ( $code >= 200 && $code < 400 ) ? 'ok' : 'unknown';
	}

	/**
	 * Remove the root .htaccess block (deactivation / off).
	 */
	public static function remove_root_rules() {
		if ( ! function_exists( 'get_home_path' ) || ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		$htaccess = get_home_path() . '.htaccess';
		if ( is_file( $htaccess ) && wp_is_writable( $htaccess ) ) {
			$current = extract_from_markers( $htaccess, self::MARKER );
			if ( ! empty( $current ) ) {
				insert_with_markers( $htaccess, self::MARKER, array() );
			}
		}
	}

	/**
	 * @return array
	 */
	public static function status() {
		$s = get_option( self::STATUS, array() );
		return is_array( $s ) ? $s : array();
	}

	/**
	 * Equivalent config for Nginx (shown on the dashboard; we never edit server config we can't verify).
	 */
	public static function nginx_snippet() {
		$rel = wp_make_link_relative( WPSS_FS::cache_url() );
		return "# Steady Speed – optimized files are content-hashed\n"
			. 'location ^~ ' . untrailingslashit( $rel ) . "/assets/ {\n"
			. "    add_header Cache-Control \"public, max-age=31536000, immutable\";\n"
			. "}\n"
			. 'location ^~ ' . untrailingslashit( $rel ) . "/pages/ { deny all; }\n"
			. "location ~* \\.(css|js)$ { expires 7d; }\n"
			. "location ~* \\.(jpe?g|png|gif|webp|avif|svg|ico)$ { expires 30d; }\n"
			. "location ~* \\.(woff2?|ttf|otf)$ { expires 1y; }\n";
	}
}
