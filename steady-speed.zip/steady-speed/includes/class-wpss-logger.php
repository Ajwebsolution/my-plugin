<?php
/**
 * Buffered event log stored in a non-autoloaded option (written once per request).
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Logger {

	const OPTION = 'wpss_log';
	const MAX    = 300;

	/** @var array */
	private static $buffer = array();

	/** @var bool */
	private static $hooked = false;

	public static function init() {
		// Nothing to wire eagerly; flushing is registered on first write.
	}

	/**
	 * Add an entry. "debug" entries are only kept when Debug Mode is on.
	 *
	 * @param string $message Message.
	 * @param string $level   info|debug|warning|error.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( 'debug' === $level && ! WPSS_Settings::get( 'debug' ) ) {
			return;
		}
		self::$buffer[] = array(
			't' => time(),
			'l' => $level,
			'm' => wp_strip_all_tags( (string) $message ),
		);
		if ( ! self::$hooked ) {
			self::$hooked = true;
			add_action( 'shutdown', array( __CLASS__, 'flush' ), 99 );
		}
	}

	/**
	 * Persist buffered entries.
	 */
	public static function flush() {
		if ( empty( self::$buffer ) ) {
			return;
		}
		$log = get_option( self::OPTION, array() );
		$log = array_merge( is_array( $log ) ? $log : array(), self::$buffer );
		if ( count( $log ) > self::MAX ) {
			$log = array_slice( $log, -self::MAX );
		}
		self::$buffer = array();
		update_option( self::OPTION, $log, false );
	}

	/**
	 * Entries, newest first.
	 */
	public static function entries() {
		$log = get_option( self::OPTION, array() );
		return is_array( $log ) ? array_reverse( $log ) : array();
	}

	/**
	 * Count recent warnings/errors.
	 *
	 * @param int $seconds Window.
	 */
	public static function recent_problems( $seconds = DAY_IN_SECONDS ) {
		$n = 0;
		foreach ( self::entries() as $e ) {
			if ( $e['t'] < time() - $seconds ) {
				break;
			}
			if ( in_array( $e['l'], array( 'warning', 'error' ), true ) ) {
				++$n;
			}
		}
		return $n;
	}

	public static function clear() {
		delete_option( self::OPTION );
	}
}
