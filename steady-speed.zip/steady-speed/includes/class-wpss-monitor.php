<?php
/**
 * Receives client error reports and turns repeated failures into automatic exclusions.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * Error detection back end.
 */
class WPSS_Monitor {

	const COUNTERS  = 'wpss_error_counters';
	const EVENTS    = 'wpss_events';
	const MAX_EVENTS = 100;
	const THRESHOLD = 3;
	const MAX_KEYS  = 200;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			'wpss/v1',
			'/report',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'report' ),
				// Anonymous visitors must be able to report. Input is untrusted: validated, rate
				// limited, and it can only ever make the plugin do LESS (exclude more).
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Client IP (only used hashed).
	 */
	private static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	}

	/**
	 * @param WP_REST_Request $request Request.
	 */
	public static function report( $request ) {
		$ok = new WP_REST_Response( null, 204 );
		if ( WPSS_Settings::safe_mode() || ( ! WPSS_Settings::get( 'error_detect' ) && ! WPSS_Settings::get( 'cwv' ) ) ) {
			return $ok;
		}

		// Rate limit: 30 reports / 10 min / IP.
		$rl_key = 'wpss_rl_' . md5( wp_hash( self::ip() ) );
		$n      = (int) get_transient( $rl_key );
		if ( $n >= 30 ) {
			return new WP_REST_Response( null, 429 );
		}
		set_transient( $rl_key, $n + 1, 10 * MINUTE_IN_SECONDS );

		$body = json_decode( (string) $request->get_body(), true );
		if ( ! is_array( $body ) || empty( $body['type'] ) ) {
			return $ok;
		}
		$type = sanitize_key( $body['type'] );
		if ( 'cwv' === $type ) {
			if ( WPSS_Settings::get( 'cwv' ) ) {
				self::field_data( $body );
			}
			return $ok;
		}
		if ( ! WPSS_Settings::get( 'error_detect' ) ) {
			return $ok;
		}
		$page = isset( $body['page'] ) ? esc_url_raw( (string) $body['page'] ) : '';
		$msg  = isset( $body['msg'] ) ? sanitize_text_field( substr( (string) $body['msg'], 0, 200 ) ) : '';
		$parts = '' === $page ? array() : wp_parse_url( $page );
		$host  = isset( $parts['host'] ) ? strtolower( $parts['host'] ) . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) : '';
		if ( '' === $host || WPSS_FS::home_host() !== $host ) {
			return $ok;
		}
		$client = wp_hash( self::ip() . '|' . gmdate( 'YmdH' ) );

		if ( in_array( $type, array( 'asset', 'js' ), true ) ) {
			self::asset_failure( $type, isset( $body['orig'] ) ? (string) $body['orig'] : '', $msg, $client );
		} elseif ( in_array( $type, array( 'slider', 'inline' ), true ) ) {
			self::page_failure( $type, $page, $msg, $client );
		}
		return $ok;
	}

	/**
	 * Optimized file failed (load error or JS exception).
	 *
	 * @param string $type   asset|js.
	 * @param string $orig   Space separated original URLs.
	 * @param string $msg    Message.
	 * @param string $client Client-hour hash.
	 */
	private static function asset_failure( $type, $orig, $msg, $client ) {
		$keys = array();
		foreach ( array_slice( preg_split( '/\s+/', trim( $orig ) ), 0, 60 ) as $url ) {
			$path = WPSS_FS::url_to_path( esc_url_raw( $url ) );
			if ( $path ) {
				$key = WPSS_FS::relative_key( $path );
				if ( $key ) {
					$keys[ $key ] = true;
				}
			}
		}
		$keys = array_keys( $keys );
		if ( empty( $keys ) ) {
			return;
		}
		sort( $keys );
		$id    = $type . '|' . md5( implode( '|', $keys ) );
		$count = self::hit( $id, $client, $type . ': ' . implode( ', ', array_slice( $keys, 0, 3 ) ) . ( count( $keys ) > 3 ? '…' : '' ) );
		self::event(
			$keys[0],
			'js' === $type ? 'JavaScript error' : 'Failed to load',
			$msg,
			$count < self::THRESHOLD ? sprintf( 'Detected (%d/%d reports)', $count, self::THRESHOLD ) : 'Protected',
			'asset' === $type ? 'Original file loaded for that visitor' : ( $count < self::THRESHOLD ? 'Watching' : 'Original asset restored for everyone' )
		);
		if ( $count < self::THRESHOLD ) {
			return;
		}
		$is_css = (bool) preg_match( '/\.css$/i', $keys[0] );
		// A combined file failing says nothing about which member is broken: stop combining them,
		// keep minifying each (its own failure would be reported separately).
		$scope  = ( $is_css && count( $keys ) > 1 ) ? 'combine' : 'all';
		$reason = sprintf( '%s failure reported by %d visitors%s', 'js' === $type ? 'JavaScript' : 'Load', $count, '' !== $msg ? ' – ' . $msg : '' );
		foreach ( $keys as $key ) {
			WPSS_Exclusions::add_auto( $key, $scope, $reason );
		}
		self::forget( $id );
		WPSS_Page_Cache::queue_purge_all( 'Automatic exclusion added' );
	}

	/**
	 * A page-level symptom (uninitialised slider / missing dependency in inline code).
	 *
	 * @param string $type   slider|inline.
	 * @param string $page   Page URL.
	 * @param string $msg    Message.
	 * @param string $client Client hash.
	 */
	private static function page_failure( $type, $page, $msg, $client ) {
		$path = (string) wp_parse_url( $page, PHP_URL_PATH );
		$path = '' === $path ? '/' : $path;
		if ( strlen( $path ) > 300 ) {
			return;
		}
		$id    = $type . '|' . $path;
		$count = self::hit( $id, $client, $type . ': ' . $path );
		if ( $count < self::THRESHOLD ) {
			self::event( $path, 'slider' === $type ? 'Slider/carousel not initialized' : 'Inline script error', $msg, sprintf( 'Detected (%d/%d reports)', $count, self::THRESHOLD ), 'Watching' );
			return;
		}
		$label = 'slider' === $type ? 'Slider/carousel did not initialize' : 'Inline script error after optimization';
		self::event( $path, $label, $msg, 'Protected', 'Optimization paused for this page (temporary)' );
		WPSS_Exclusions::add_auto_url( $path, sprintf( '%s (%d visitors)%s', $label, $count, '' !== $msg ? ' – ' . $msg : '' ) );
		self::forget( $id );
		$scheme = (string) wp_parse_url( home_url(), PHP_URL_SCHEME );
		WPSS_Page_Cache::queue_url( $scheme . '://' . WPSS_FS::home_host() . $path, 'Optimization disabled for this page' );
	}

	/**
	 * Register one report; returns number of distinct client-hours for this problem.
	 *
	 * @param string $id     Problem id.
	 * @param string $client Client hash.
	 * @param string $label  Human label.
	 */
	private static function hit( $id, $client, $label ) {
		$all = self::counters();
		if ( ! isset( $all[ $id ] ) ) {
			$all[ $id ] = array(
				'label'   => $label,
				'clients' => array(),
			);
		}
		$all[ $id ]['clients'][ substr( $client, 0, 16 ) ] = time();
		$all[ $id ]['last']                                 = time();
		if ( count( $all ) > self::MAX_KEYS ) {
			uasort(
				$all,
				static function ( $a, $b ) {
					return $b['last'] <=> $a['last'];
				}
			);
			$all = array_slice( $all, 0, self::MAX_KEYS, true );
		}
		update_option( self::COUNTERS, $all, false );
		return count( $all[ $id ]['clients'] );
	}

	/**
	 * @param string $id Problem id.
	 */
	private static function forget( $id ) {
		$all = self::counters();
		unset( $all[ $id ] );
		update_option( self::COUNTERS, $all, false );
	}

	/**
	 * Record a protection event (no personal data: file key/path, message, status only).
	 *
	 * @param string $subject File key or page path.
	 * @param string $what    What happened.
	 * @param string $msg     Error message.
	 * @param string $status  Status.
	 * @param string $action  Action taken.
	 */
	public static function event( $subject, $what, $msg, $status, $action ) {
		$graph = WPSS_Assets::graph();
		$info  = isset( $graph[ $subject ] ) ? $graph[ $subject ] : null;
		$group = $info ? $info['group'] : ( preg_match( '/\.(js|css)$/i', $subject ) ? WPSS_Compat::group( preg_match( '/\.css$/i', $subject ) ? 'css' : 'js', '', content_url( $subject ) ) : 'Page' );
		$all   = self::events();
		array_unshift(
			$all,
			array(
				't'      => time(),
				'asset'  => $subject,
				'handle' => $info ? $info['handle'] : '',
				'deps'   => $info ? implode( ', ', array_slice( $info['deps'], 0, 6 ) ) : '',
				'group'  => $group,
				'what'   => $what,
				'msg'    => $msg,
				'status' => $status,
				'action' => $action,
			)
		);
		update_option( self::EVENTS, array_slice( $all, 0, self::MAX_EVENTS ), false );
	}

	/**
	 * @return array[]
	 */
	public static function events() {
		$v = get_option( self::EVENTS, array() );
		return is_array( $v ) ? $v : array();
	}

	/**
	 * Automatic fallbacks (restores / protections) in the last 7 days.
	 */
	public static function recent_fallbacks() {
		$cut = time() - WEEK_IN_SECONDS;
		$n   = 0;
		foreach ( self::events() as $e ) {
			if ( $e['t'] >= $cut && ( 'Protected' === $e['status'] || 0 === strpos( $e['action'], 'Original file loaded' ) ) ) {
				++$n;
			}
		}
		return $n;
	}

	/**
	 * Store one anonymous Core Web Vitals sample (numbers, device class and path only).
	 *
	 * @param array $b Body.
	 */
	private static function field_data( $b ) {
		$lcp = isset( $b['lcp'] ) ? (int) $b['lcp'] : 0;
		$cls = isset( $b['cls'] ) ? (float) $b['cls'] : 0;
		$inp = isset( $b['inp'] ) ? (int) $b['inp'] : 0;
		$dev = isset( $b['dev'] ) && 'm' === $b['dev'] ? 'm' : 'd';
		$path = isset( $b['page'] ) ? (string) $b['page'] : '/';
		if ( $lcp <= 0 || $lcp > 60000 || $cls < 0 || $cls > 10 || $inp < 0 || $inp > 60000 || strlen( $path ) > 300 || '/' !== ( $path[0] ?? '' ) ) {
			return;
		}
		$file = WPSS_CACHE_DIR . '/data/rum.log';
		if ( is_file( $file ) && filesize( $file ) > 2 * MB_IN_BYTES ) {
			return; // Aggregated hourly by cron.
		}
		$line = wp_json_encode( array( time(), $dev, $lcp, round( $cls, 3 ), $inp, WPSS_Analysis::path_key( $path ) ) ) . "\n";
		file_put_contents( $file, $line, FILE_APPEND | LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}

	/**
	 * @return array
	 */
	public static function counters() {
		$v = get_option( self::COUNTERS, array() );
		return is_array( $v ) ? $v : array();
	}

	public static function reset() {
		delete_option( self::COUNTERS );
	}

	/**
	 * Drop reports older than 7 days (cron).
	 */
	public static function prune() {
		$all     = self::counters();
		$cut     = time() - WEEK_IN_SECONDS;
		$changed = false;
		foreach ( $all as $id => $row ) {
			if ( empty( $row['last'] ) || $row['last'] < $cut ) {
				unset( $all[ $id ] );
				$changed = true;
			}
		}
		if ( $changed ) {
			update_option( self::COUNTERS, $all, false );
		}
	}
}
