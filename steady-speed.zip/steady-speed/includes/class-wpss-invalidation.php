<?php
/**
 * Dependency collection (while a page renders) and targeted invalidation (when content changes).
 *
 * Dependency ids:
 *   post:ID        a post/page/template rendered on the page (incl. Elementor header/footer/popup templates)
 *   term:ID        a term archive
 *   listing:TYPE   a page listing posts of TYPE (archives, home, widgets that loop posts)
 *   archive:TYPE   post type archive
 *   author:ID      author archive
 *   menu:ID        a nav menu rendered on the page
 *   sidebar        any widget area rendered on the page
 *   home           the front page
 *   global         every cached page (used only by the full purge)
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Invalidation {

	/** Post types that never affect front-end output. */
	const IGNORED_TYPES = array( 'revision', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_font_face', 'wp_font_family', 'scheduled-action' );

	/** Block-theme / global objects: change the whole site. */
	const GLOBAL_TYPES = array( 'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation', 'wp_block', 'custom_css' );

	public static function init() {
		// ---- Collectors (front end).
		add_action( 'template_redirect', array( __CLASS__, 'collect_query' ), 99 );
		add_action( 'the_post', array( __CLASS__, 'collect_post' ) );
		add_filter( 'wp_nav_menu_objects', array( __CLASS__, 'collect_menu' ), 10, 2 );
		add_action( 'dynamic_sidebar_before', array( __CLASS__, 'collect_sidebar' ) );
		add_action( 'elementor/frontend/before_get_builder_content', array( __CLASS__, 'collect_elementor' ), 10, 1 );

		// ---- Content events.
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 10, 3 );
		add_action( 'post_updated', array( __CLASS__, 'on_post_updated' ), 10, 3 );
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete_post' ) );
		add_action( 'comment_post', array( __CLASS__, 'on_comment' ) );
		add_action( 'edit_comment', array( __CLASS__, 'on_comment' ) );
		add_action( 'wp_set_comment_status', array( __CLASS__, 'on_comment' ) );
		add_action( 'edited_term', array( __CLASS__, 'on_term' ), 10, 3 );
		add_action( 'delete_term', array( __CLASS__, 'on_term' ), 10, 3 );
		add_action( 'wp_update_nav_menu', array( __CLASS__, 'on_menu' ) );
		add_action( 'wp_delete_nav_menu', array( __CLASS__, 'on_menu_deleted' ) );
		add_action( 'update_option_sidebars_widgets', array( __CLASS__, 'on_widgets' ) );
		add_action( 'updated_option', array( __CLASS__, 'on_option' ), 10, 1 );

		// ---- Site-wide events.
		foreach ( array( 'customize_save_after', 'switch_theme', 'activated_plugin', 'deactivated_plugin' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'purge_all_' . str_replace( array( '-' ), '_', $hook ) ) );
		}
		add_action( 'upgrader_process_complete', array( __CLASS__, 'on_upgrade' ), 10, 2 );

		// ---- Elementor.
		add_action( 'elementor/editor/after_save', array( __CLASS__, 'on_elementor_save' ), 10, 1 );
		add_action( 'elementor/core/files/clear_cache', array( __CLASS__, 'on_elementor_clear' ) );

		// ---- ACF options pages / fields.
		add_action( 'acf/save_post', array( __CLASS__, 'on_acf_save' ), 20 );

		// ---- WooCommerce stock changes (product page shows stock).
		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'on_wc_stock' ) );
		// Any WooCommerce settings screen save can change prices, notices or store visibility.
		add_action(
			'woocommerce_settings_saved',
			static function () {
				WPSS_Page_Cache::queue_purge_all( 'WooCommerce settings saved' );
			}
		);
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'on_wc_stock' ) );
	}

	/* ---------------------------------------------------------------------
	 * Collectors
	 * ------------------------------------------------------------------- */

	public static function collect_query() {
		if ( is_front_page() || is_home() ) {
			WPSS_Page_Cache::add_dep( 'home' );
			WPSS_Page_Cache::add_dep( 'listing:post' );
		}
		if ( is_singular() ) {
			WPSS_Page_Cache::add_dep( 'post:' . get_queried_object_id() );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				WPSS_Page_Cache::add_dep( 'term:' . $term->term_id );
				$tax = get_taxonomy( $term->taxonomy );
				foreach ( $tax ? (array) $tax->object_type : array() as $pt ) {
					WPSS_Page_Cache::add_dep( 'listing:' . $pt );
				}
			}
		} elseif ( is_post_type_archive() ) {
			$pt = get_query_var( 'post_type' );
			foreach ( (array) $pt as $type ) {
				WPSS_Page_Cache::add_dep( 'archive:' . $type );
				WPSS_Page_Cache::add_dep( 'listing:' . $type );
			}
		} elseif ( is_author() ) {
			WPSS_Page_Cache::add_dep( 'author:' . get_queried_object_id() );
			WPSS_Page_Cache::add_dep( 'listing:post' );
		} elseif ( is_date() ) {
			WPSS_Page_Cache::add_dep( 'listing:post' );
		}
	}

	/**
	 * Every post rendered in a loop (main or secondary) is a dependency.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function collect_post( $post ) {
		if ( ! $post instanceof WP_Post || ! did_action( 'template_redirect' ) ) {
			return;
		}
		WPSS_Page_Cache::add_dep( 'post:' . $post->ID );
		if ( (int) get_queried_object_id() !== (int) $post->ID ) {
			// The page lists posts of this type (recent posts widget, related, grids…).
			WPSS_Page_Cache::add_dep( 'listing:' . $post->post_type );
		}
	}

	/**
	 * @param array    $items Menu items.
	 * @param stdClass $args  Args.
	 */
	public static function collect_menu( $items, $args ) {
		$menu = isset( $args->menu ) ? $args->menu : null;
		if ( is_object( $menu ) && isset( $menu->term_id ) ) {
			WPSS_Page_Cache::add_dep( 'menu:' . $menu->term_id );
		} elseif ( ! empty( $items ) ) {
			$first = reset( $items );
			$terms = isset( $first->db_id ) ? wp_get_object_terms( $first->db_id, 'nav_menu', array( 'fields' => 'ids' ) ) : array();
			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				WPSS_Page_Cache::add_dep( 'menu:' . (int) $terms[0] );
			} else {
				WPSS_Page_Cache::add_dep( 'menu:any' );
			}
		}
		return $items;
	}

	public static function collect_sidebar() {
		WPSS_Page_Cache::add_dep( 'sidebar' );
	}

	/**
	 * Elementor templates (header, footer, single, popup, section…) rendered on the page.
	 *
	 * @param object $document Elementor document.
	 */
	public static function collect_elementor( $document ) {
		if ( is_object( $document ) && method_exists( $document, 'get_main_id' ) ) {
			WPSS_Page_Cache::add_dep( 'post:' . (int) $document->get_main_id() );
		}
	}

	/* ---------------------------------------------------------------------
	 * Events
	 * ------------------------------------------------------------------- */

	/**
	 * Should changes of this post be ignored?
	 *
	 * @param WP_Post $post Post.
	 */
	private static function ignored( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return true;
		}
		if ( in_array( $post->post_type, self::IGNORED_TYPES, true ) || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return true;
		}
		return (bool) apply_filters( 'wpss_ignore_post_change', false, $post );
	}

	/**
	 * Status transitions (publish, unpublish, trash, schedule going live).
	 *
	 * @param string  $new  New status.
	 * @param string  $old  Old status.
	 * @param WP_Post $post Post.
	 */
	public static function on_transition( $new, $old, $post ) {
		if ( self::ignored( $post ) ) {
			return;
		}
		if ( in_array( $post->post_type, self::GLOBAL_TYPES, true ) ) {
			WPSS_Page_Cache::queue_purge_all( sprintf( 'Site template "%s" changed', $post->post_type ) );
			return;
		}
		if ( 'publish' !== $new && 'publish' !== $old ) {
			return; // Drafts, pending, auto-drafts: nothing public changed.
		}
		if ( self::is_active_kit( $post->ID ) ) {
			WPSS_Page_Cache::queue_purge_all( 'Elementor global kit changed' );
			return;
		}
		$reason = sprintf( '%s #%d %s', $post->post_type, $post->ID, $new === $old ? 'updated' : $old . ' → ' . $new );
		self::invalidate_post( $post, $reason, $new !== $old );
	}

	/**
	 * Slug/permalink changed while published: old URL must go too.
	 *
	 * @param int     $id     Post ID.
	 * @param WP_Post $after  After.
	 * @param WP_Post $before Before.
	 */
	public static function on_post_updated( $id, $after, $before ) {
		if ( self::ignored( $after ) || 'publish' !== $before->post_status ) {
			return;
		}
		if ( $after->post_name !== $before->post_name || (int) $after->post_parent !== (int) $before->post_parent ) {
			$old_url = get_permalink( $before );
			WPSS_Page_Cache::queue_url( $old_url, 'Permalink changed' );
			WPSS_Page_Cache::queue( 'listing:' . $after->post_type, 'Permalink changed' );
		}
	}

	/**
	 * Invalidate a post and, when its visibility changed, the listings it appears in.
	 *
	 * @param WP_Post $post          Post.
	 * @param string  $reason        Reason.
	 * @param bool    $status_change Status changed.
	 */
	public static function invalidate_post( $post, $reason, $status_change = false ) {
		WPSS_Page_Cache::queue( 'post:' . $post->ID, $reason );
		WPSS_Page_Cache::queue_url( get_permalink( $post ), $reason );
		WPSS_Analysis::mark_stale( (string) get_permalink( $post ) ); // Content changed: re-analyze.

		if ( $status_change || 'post' === $post->post_type ) {
			// Listing pages show titles/excerpts: new, removed or edited entries change them.
			WPSS_Page_Cache::queue( 'listing:' . $post->post_type, $reason );
			WPSS_Page_Cache::queue( 'archive:' . $post->post_type, $reason );
			WPSS_Page_Cache::queue( 'author:' . $post->post_author, $reason );
			if ( 'post' === $post->post_type ) {
				WPSS_Page_Cache::queue( 'home', $reason );
			}
			$taxes = get_object_taxonomies( $post->post_type );
			if ( $taxes ) {
				$terms = wp_get_object_terms( $post->ID, $taxes, array( 'fields' => 'ids' ) );
				if ( ! is_wp_error( $terms ) ) {
					foreach ( $terms as $tid ) {
						WPSS_Page_Cache::queue( 'term:' . (int) $tid, $reason );
					}
				}
			}
		}
		do_action( 'wpss_invalidate_post', $post, $reason );
	}

	/**
	 * @param int $post_id Post ID.
	 */
	public static function on_delete_post( $post_id ) {
		$post = get_post( $post_id );
		if ( self::ignored( $post ) || 'publish' !== $post->post_status ) {
			return;
		}
		self::invalidate_post( $post, sprintf( '%s #%d deleted', $post->post_type, $post->ID ), true );
	}

	/**
	 * @param int $comment_id Comment ID.
	 */
	public static function on_comment( $comment_id ) {
		$comment = get_comment( $comment_id );
		if ( $comment && $comment->comment_post_ID ) {
			WPSS_Page_Cache::queue( 'post:' . (int) $comment->comment_post_ID, 'Comment changed' );
		}
	}

	/**
	 * @param int    $term_id  Term.
	 * @param int    $tt_id    Term taxonomy.
	 * @param string $taxonomy Taxonomy.
	 */
	public static function on_term( $term_id, $tt_id = 0, $taxonomy = '' ) {
		if ( 'nav_menu' === $taxonomy ) {
			return;
		}
		WPSS_Page_Cache::queue( 'term:' . (int) $term_id, 'Term changed' );
		if ( $taxonomy ) {
			$tax = get_taxonomy( $taxonomy );
			if ( $tax && $tax->public ) {
				foreach ( (array) $tax->object_type as $pt ) {
					WPSS_Page_Cache::queue( 'listing:' . $pt, 'Term changed' );
				}
			}
		}
	}

	/**
	 * @param int $menu_id Menu term ID.
	 */
	public static function on_menu( $menu_id ) {
		WPSS_Page_Cache::queue( 'menu:' . (int) $menu_id, 'Menu updated' );
		WPSS_Page_Cache::queue( 'menu:any', 'Menu updated' );
	}

	public static function on_menu_deleted() {
		WPSS_Page_Cache::queue_purge_all( 'Menu deleted' );
	}

	public static function on_widgets() {
		WPSS_Page_Cache::queue( 'sidebar', 'Widgets updated' );
	}

	/**
	 * Option updates: widget instances, and a list of site-wide options.
	 *
	 * @param string $option Option.
	 */
	public static function on_option( $option ) {
		if ( 0 === strpos( $option, 'widget_' ) ) {
			WPSS_Page_Cache::queue( 'sidebar', 'Widget settings updated' );
			return;
		}
		static $list = null;
		if ( null === $list ) {
			$list = (array) apply_filters(
				'wpss_purge_all_options',
				array( 'blogname', 'blogdescription', 'permalink_structure', 'category_base', 'tag_base', 'show_on_front', 'page_on_front', 'page_for_posts', 'posts_per_page', 'site_icon', 'date_format', 'time_format', 'WPLANG', 'timezone_string', 'gmt_offset', 'start_of_week', 'theme_mods_' . get_option( 'stylesheet' ), 'elementor_active_kit', 'elementor_css_print_method', 'elementor_disable_color_schemes', 'elementor_disable_typography_schemes', 'elementor_load_fa4_shim', 'elementor_font_display', 'woocommerce_currency', 'woocommerce_price_num_decimals', 'woocommerce_currency_pos', 'woocommerce_price_thousand_sep', 'woocommerce_price_decimal_sep', 'woocommerce_tax_display_shop', 'woocommerce_hide_out_of_stock_items', 'woocommerce_coming_soon', 'woocommerce_store_pages_only', 'woocommerce_shop_page_display', 'woocommerce_catalog_rows', 'woocommerce_catalog_columns', 'woocommerce_demo_store', 'woocommerce_demo_store_notice' )
			);
		}
		if ( in_array( $option, $list, true ) || 0 === strpos( $option, 'elementor_experiment-' ) ) {
			WPSS_Page_Cache::queue_purge_all( 'Site setting changed: ' . $option );
		}
	}

	/**
	 * Generic purge-all handlers for site-wide hooks.
	 */
	public static function purge_all_customize_save_after() {
		WPSS_Page_Cache::queue_purge_all( 'Customizer / theme settings saved' );
	}

	public static function purge_all_switch_theme() {
		WPSS_Page_Cache::queue_purge_all( 'Theme switched' );
	}

	public static function purge_all_activated_plugin() {
		WPSS_Page_Cache::queue_purge_all( 'Plugin activated' );
	}

	public static function purge_all_deactivated_plugin() {
		WPSS_Page_Cache::queue_purge_all( 'Plugin deactivated' );
	}

	/**
	 * Theme/plugin/core updates: output markup may change everywhere.
	 * (Changed asset files alone would be caught by serve-time freshness.)
	 *
	 * @param object $upgrader Upgrader.
	 * @param array  $extra    Extra.
	 */
	public static function on_upgrade( $upgrader, $extra ) {
		$type = isset( $extra['type'] ) ? $extra['type'] : '';
		if ( in_array( $type, array( 'plugin', 'theme', 'core' ), true ) ) {
			WPSS_Page_Cache::queue_purge_all( ucfirst( $type ) . ' updated' );
		}
	}

	/**
	 * Elementor editor save (also fires for templates: header/footer/popup/kit).
	 *
	 * @param int $post_id Post ID.
	 */
	public static function on_elementor_save( $post_id ) {
		$post_id = (int) $post_id;
		if ( self::is_active_kit( $post_id ) ) {
			WPSS_Page_Cache::queue_purge_all( 'Elementor global kit (site settings) saved' );
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}
		// Header/footer/popup templates are dependencies ("post:ID") of every page that rendered them.
		WPSS_Page_Cache::queue( 'post:' . $post_id, 'Elementor content saved' );
		WPSS_Page_Cache::queue_url( get_permalink( $post ), 'Elementor content saved' );
		WPSS_Analysis::mark_stale( (string) get_permalink( $post ) );
	}

	/**
	 * Elementor "Regenerate CSS & Data" – all generated CSS files are rebuilt.
	 */
	public static function on_elementor_clear() {
		// With external CSS files every cached page records the Elementor CSS files it uses and is
		// regenerated automatically the next time one of them is missing or changed – no full purge.
		if ( 'internal' !== get_option( 'elementor_css_print_method', 'external' ) && WPSS_Settings::get( 'css_opt' ) ) {
			WPSS_Logger::log( 'Elementor CSS regenerated – affected pages refresh automatically (per-page file check)' );
			if ( WPSS_Settings::get( 'warm' ) ) {
				WPSS_Warmup::after_purge();
			}
			return;
		}
		WPSS_Page_Cache::queue_purge_all( 'Elementor CSS regenerated (inline CSS print method)' );
	}

	/**
	 * @param int $post_id Post ID.
	 */
	private static function is_active_kit( $post_id ) {
		return (int) get_option( 'elementor_active_kit' ) === (int) $post_id && $post_id > 0;
	}

	/**
	 * @param int|string $post_id ACF post id ("options", term_12, 123).
	 */
	public static function on_acf_save( $post_id ) {
		if ( is_string( $post_id ) && 0 === strpos( $post_id, 'option' ) ) {
			WPSS_Page_Cache::queue_purge_all( 'ACF options page saved' );
		} elseif ( is_numeric( $post_id ) ) {
			WPSS_Page_Cache::queue( 'post:' . (int) $post_id, 'ACF fields saved' );
		} elseif ( is_string( $post_id ) && preg_match( '/^term_(\d+)$/', $post_id, $m ) ) {
			WPSS_Page_Cache::queue( 'term:' . (int) $m[1], 'ACF term fields saved' );
		}
	}

	/**
	 * @param object $product WC product.
	 */
	public static function on_wc_stock( $product ) {
		if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
			$id = method_exists( $product, 'get_parent_id' ) && $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
			WPSS_Page_Cache::queue( 'post:' . (int) $id, 'Stock changed' );
		}
	}
}
