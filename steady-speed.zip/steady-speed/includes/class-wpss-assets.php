<?php
/**
 * CSS/JS optimization inside the WordPress dependency system.
 *
 * Invariants:
 *  - Order is never recomputed: it comes from WP_Dependencies::all_deps().
 *  - Only src URLs and tag attributes are changed; inline before/after code stays where core prints it.
 *  - Defer eligibility is decided by core (WP 6.3+ "strategy" API), not by this plugin.
 *  - Optimized copies are content-versioned; originals are never modified.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Assets {

	const MAX_BYTES = 3145728; // 3 MB.

	/** @var array Source path => "mtime-size" used by this page (for serve-time freshness). */
	private static $sources = array();

	/** @var array Output files (relative to cache dir) used by this page. */
	private static $outputs = array();

	/** @var array handle => array(orig urls, label) for tag annotation. */
	private static $css_tags = array();

	/** @var array */
	private static $js_tags = array();

	/** @var array handle => true */
	private static $delayed = array();

	/** @var array Per-request memo of built files. */
	private static $built = array();

	/** @var array type => handle => array(orig bytes, served bytes) */
	private static $sizes = array( 'css' => array(), 'js' => array() );

	/** @var array combined handle => array(handles, orig bytes, count) */
	private static $combined = array();

	/** @var array Dependency graph entries seen in this request: file key => info. */
	private static $graph_seen = array();

	const GRAPH = 'wpss_asset_graph';

	public static function init() {
		add_filter( 'style_loader_src', array( __CLASS__, 'style_src' ), 20, 2 );
		add_filter( 'script_loader_src', array( __CLASS__, 'script_src' ), 20, 2 );
		add_filter( 'print_styles_array', array( __CLASS__, 'combine_styles' ), 50 );
		add_filter( 'print_scripts_array', array( __CLASS__, 'script_strategies' ), 50 );
		add_filter( 'style_loader_tag', array( __CLASS__, 'style_tag' ), 20, 4 );
		add_filter( 'script_loader_tag', array( __CLASS__, 'script_tag' ), 20, 3 );
		add_action( 'wp_footer', array( __CLASS__, 'delay_loader' ), PHP_INT_MAX );
	}

	/**
	 * Is the optimization of a type active for this request?
	 *
	 * @param string $type css|js.
	 */
	private static function active( $type ) {
		return WPSS_Context::optimize() && WPSS_Settings::get( 'css' === $type ? 'css_opt' : 'js_opt' );
	}

	/**
	 * @param string $type css|js.
	 */
	private static function mode( $type ) {
		$m = WPSS_Settings::get( 'css' === $type ? 'css_mode' : 'js_mode' );
		return in_array( $m, array( 'safe', 'balanced', 'aggressive' ), true ) ? $m : 'safe';
	}

	/**
	 * "mtime-size" signature of a file.
	 *
	 * @param string $path Path.
	 */
	private static function sig( $path ) {
		return (int) @filemtime( $path ) . '-' . (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	}

	/**
	 * Record a source file used by this page.
	 *
	 * @param string $path Path.
	 */
	private static function track_source( $path ) {
		self::$sources[ $path ] = self::sig( $path );
	}

	/**
	 * Absolute URL for a registered src.
	 *
	 * @param string          $src Src.
	 * @param WP_Dependencies $deps Registry.
	 */
	private static function absolute( $src, $deps ) {
		if ( ! is_string( $src ) || '' === $src ) {
			return '';
		}
		if ( preg_match( '#^(https?:)?//#i', $src ) || ( $deps->content_url && 0 === strpos( $src, $deps->content_url ) ) ) {
			return $src;
		}
		return $deps->base_url . $src;
	}

	/* =====================================================================
	 * Per-file optimization (style_loader_src / script_loader_src)
	 * =================================================================== */

	/**
	 * @param string $src    Src.
	 * @param string $handle Handle.
	 */
	public static function style_src( $src, $handle ) {
		return self::file_src( 'css', $src, $handle );
	}

	/**
	 * @param string $src    Src.
	 * @param string $handle Handle.
	 */
	public static function script_src( $src, $handle ) {
		return self::file_src( 'js', $src, $handle );
	}

	/**
	 * Shared per-file logic.
	 *
	 * @param string $type   css|js.
	 * @param string $src    Src.
	 * @param string $handle Handle.
	 */
	private static function file_src( $type, $src, $handle ) {
		if ( ! is_string( $src ) || '' === $src || ! self::active( $type ) || 0 === strpos( (string) $handle, 'wpss-' ) ) {
			return $src;
		}
		$path = WPSS_FS::url_to_path( $src );
		if ( false === $path ) {
			WPSS_Debug::add( $type, $handle, 'Original', 'External file' );
			self::$sizes[ $type ][ $handle ] = array( 0, 0 );
			return $src;
		}
		if ( WPSS_FS::is_inside( $path, WPSS_CACHE_DIR ) ) {
			return $src;
		}
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		if ( $ext !== $type ) {
			return $src;
		}

		$c = WPSS_Compat::classify( $type, $handle, $src );
		self::track_source( $path );
		$orig_size                       = (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		self::$sizes[ $type ][ $handle ] = array( $orig_size, $orig_size );
		if ( ! empty( $c['rules'] ) || ! empty( $c['reasons'] ) ) {
			WPSS_Stats::protect( $type, $handle, implode( '; ', $c['reasons'] ) );
		}
		WPSS_Page_Cache::add_dep( 'file:' . WPSS_FS::relative_key( $path ) );
		self::note_graph( $type, $handle, $src, $path );

		$fully_excluded = $c['no_minify'] && $c['no_defer'] && $c['no_delay'] && $c['no_combine'] && self::user_all_excluded( $handle, $src );
		if ( $fully_excluded ) {
			WPSS_Debug::add( $type, $handle, 'Excluded', implode( '; ', $c['reasons'] ) );
			return $src;
		}

		if ( $c['no_minify'] || preg_match( '/[.-]min\.(css|js)$/i', $path ) ) {
			// Not minified, but still versioned by content so edits are picked up without a purge.
			$reason = $c['no_minify'] ? implode( '; ', $c['reasons'] ) : 'Already minified';
			WPSS_Debug::add( $type, $handle, $c['no_minify'] ? 'Protected' : 'Versioned', $reason . self::protection_suffix( $c ) );
			return add_query_arg( 'v', self::content_version( $path ), $src );
		}

		$rel = self::build( $type, $path, $src );
		if ( false === $rel ) {
			WPSS_Debug::add( $type, $handle, 'Original', 'Optimization failed validation – original kept' );
			return add_query_arg( 'v', self::content_version( $path ), $src );
		}
		self::$sizes[ $type ][ $handle ][1] = (int) @filesize( WPSS_CACHE_DIR . '/' . $rel ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$url = WPSS_FS::cache_url( $rel );
		if ( ! $url ) {
			return $src;
		}
		$info = array(
			'orig' => array( $src ),
			'opt'  => 'min',
		);
		if ( 'css' === $type ) {
			self::$css_tags[ $handle ] = $info;
		} else {
			self::$js_tags[ $handle ] = array_merge( isset( self::$js_tags[ $handle ] ) ? self::$js_tags[ $handle ] : array(), $info );
		}
		WPSS_Debug::add( $type, $handle, 'Optimized', 'Minified copy' . self::protection_suffix( $c ) );
		return $url;
	}

	/**
	 * Only the user "exclude from all" list / auto "all" means "leave the URL completely untouched".
	 *
	 * @param string $handle Handle.
	 * @param string $src    Src.
	 */
	private static function user_all_excluded( $handle, $src ) {
		if ( false !== WPSS_Exclusions::match_list( WPSS_Exclusions::patterns( 'all' ), $handle, $src ) ) {
			return true;
		}
		$auto = WPSS_Exclusions::auto_match( $src );
		return false !== $auto && 'all' === $auto['scope'];
	}

	/**
	 * " – protected: …" suffix for debug output.
	 *
	 * @param array $c Classification.
	 */
	private static function protection_suffix( $c ) {
		return empty( $c['rules'] ) ? '' : ' – protected: ' . implode( '; ', $c['reasons'] );
	}

	/**
	 * Build (or reuse) the optimized copy of one file.
	 *
	 * @param string $type css|js.
	 * @param string $path Source path.
	 * @param string $src  Source URL.
	 * @return string|false Relative path inside the cache dir.
	 */
	private static function build( $type, $path, $src ) {
		$strip = 'js' === $type && 'safe' !== self::mode( 'js' );
		$query = (string) wp_parse_url( $src, PHP_URL_QUERY );
		$key   = md5( $path . '|' . self::sig( $path ) . '|' . ( $strip ? 's' : 'k' ) . '|' . $query . '|' . WPSS_VERSION );
		if ( isset( self::$built[ $key ] ) ) {
			return self::$built[ $key ];
		}
		$rel = self::map_get( $key );
		if ( false !== $rel ) {
			self::$outputs[ $rel ] = true;
			self::$built[ $key ]   = $rel;
			return $rel;
		}

		$fail_key = 'wpss_fail_' . substr( $key, 0, 20 );
		if ( get_transient( $fail_key ) ) {
			self::$built[ $key ] = false;
			return false;
		}

		$out = self::transform( $type, $path, $src, $strip );
		$rel = false === $out ? false : self::store_output( $type, basename( $path ), $out );
		if ( false === $rel ) {
			set_transient( $fail_key, 1, DAY_IN_SECONDS );
			WPSS_Logger::log( sprintf( 'Could not optimize %s – original kept', WPSS_FS::relative_key( $path ) ), 'warning' );
			self::$built[ $key ] = false;
			return false;
		}
		self::map_put( $key, $rel );
		self::$outputs[ $rel ] = true;
		self::$built[ $key ]   = $rel;
		return $rel;
	}

	/**
	 * Write an optimized file under a name derived from its CONTENT (identical output = identical
	 * URL, so browsers keep their cached copy even when a source file is merely touched).
	 *
	 * @param string $type css|js.
	 * @param string $base Source basename.
	 * @param string $code Optimized code.
	 * @return string|false Relative path.
	 */
	public static function store_output( $type, $base, $code ) {
		$name = substr( sanitize_file_name( preg_replace( '/\.(css|js)$/i', '', $base ) ), 0, 40 );
		$rel  = 'assets/' . $type . '/' . ( '' === $name ? 'file' : $name ) . '-' . substr( md5( $code ), 0, 12 ) . '.' . $type;
		$abs  = WPSS_CACHE_DIR . '/' . $rel;
		if ( is_file( $abs ) ) {
			return $rel;
		}
		return WPSS_FS::put( $abs, $code ) ? $rel : false;
	}

	/**
	 * Resolve a build key (source signature) to the content-addressed output, if it still exists.
	 *
	 * @param string $key Key.
	 * @return string|false
	 */
	public static function map_get( $key ) {
		$map = WPSS_CACHE_DIR . '/assets/map/' . $key;
		if ( ! is_file( $map ) ) {
			return false;
		}
		$rel = trim( (string) file_get_contents( $map ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( ! preg_match( '#^assets/(css|js)/[A-Za-z0-9._-]+\.(css|js)$#', $rel ) || ! is_file( WPSS_CACHE_DIR . '/' . $rel ) ) {
			return false;
		}
		if ( @filemtime( WPSS_CACHE_DIR . '/' . $rel ) < time() - DAY_IN_SECONDS ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			WPSS_FS::touch( WPSS_CACHE_DIR . '/' . $rel ); // "Still in use" for the cleanup job.
			WPSS_FS::touch( $map );
		}
		return $rel;
	}

	/**
	 * @param string $key Key.
	 * @param string $rel Relative output path.
	 */
	public static function map_put( $key, $rel ) {
		WPSS_FS::put( WPSS_CACHE_DIR . '/assets/map/' . $key, $rel );
	}

	/**
	 * Content version for files served in place (already minified / protected): first 10 chars of
	 * the MD5 of the file content, computed once per source signature.
	 *
	 * @param string $path Path.
	 */
	public static function content_version( $path ) {
		static $memo = array();
		$key = md5( 'v|' . $path . '|' . self::sig( $path ) );
		if ( isset( $memo[ $key ] ) ) {
			return $memo[ $key ];
		}
		$map = WPSS_CACHE_DIR . '/assets/map/' . $key;
		$v   = is_file( $map ) ? trim( (string) file_get_contents( $map ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( ! preg_match( '/^[a-f0-9]{10}$/', $v ) ) {
			$h = @md5_file( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$v = $h ? substr( $h, 0, 10 ) : substr( md5( self::sig( $path ) ), 0, 10 );
			if ( $h && WPSS_FS::ready() ) {
				WPSS_FS::put( $map, $v );
			}
		}
		$memo[ $key ] = $v;
		return $v;
	}

	/**
	 * Read + minify + validate one file.
	 *
	 * @param string $type  css|js.
	 * @param string $path  Path.
	 * @param string $src   URL (for relative url() rewriting).
	 * @param bool   $strip JS: strip comments.
	 * @return string|false
	 */
	private static function transform( $type, $path, $src, $strip = false ) {
		$size = @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! $size || $size > self::MAX_BYTES ) {
			return false;
		}
		$code = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local, validated path.
		if ( ! is_string( $code ) || '' === trim( $code ) ) {
			return false;
		}
		if ( 'css' === $type ) {
			$min = WPSS_Minify::css( $code );
			if ( false === $min || ! self::css_balanced( $min ) ) {
				return false;
			}
			$dir = dirname( (string) wp_parse_url( $src, PHP_URL_PATH ) );
			return WPSS_Minify::rewrite_urls( $min, $dir );
		}
		$min = WPSS_Minify::js( $code, $strip );
		if ( false === $min ) {
			return false;
		}
		return $min;
	}

	/**
	 * Balanced braces outside strings (sanity check on minified CSS).
	 *
	 * @param string $css CSS.
	 */
	private static function css_balanced( $css ) {
		$bare = preg_replace( '/"(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|\/\*.*?\*\//s', '', $css );
		return substr_count( $bare, '{' ) === substr_count( $bare, '}' ) && substr_count( $bare, '(' ) === substr_count( $bare, ')' );
	}

	/* =====================================================================
	 * CSS combining (print_styles_array) – Balanced / Aggressive only
	 * =================================================================== */

	/**
	 * Replace runs of contiguous, compatible stylesheets with one combined stylesheet.
	 *
	 * @param string[] $to_do Sorted handles (from all_deps).
	 * @return string[]
	 */
	public static function combine_styles( $to_do ) {
		if ( ! is_array( $to_do ) || count( $to_do ) < 2 || ! self::active( 'css' ) || 'safe' === self::mode( 'css' ) || ! WPSS_FS::ready() ) {
			return $to_do;
		}
		$styles = wp_styles();
		$mode   = self::mode( 'css' );
		$result = array();
		$group  = array();
		$gkey   = null;

		foreach ( array_values( $to_do ) as $handle ) {
			$info = self::combinable( $styles, $handle, $mode );
			if ( false === $info ) {
				$result = array_merge( $result, self::flush_group( $styles, $group ) );
				$group  = array();
				$gkey   = null;
				$result[] = $handle;
				continue;
			}
			// A stylesheet containing @import may only start a group (imports must come first).
			if ( null !== $gkey && ( $info['key'] !== $gkey || $info['import'] ) ) {
				$result = array_merge( $result, self::flush_group( $styles, $group ) );
				$group  = array();
			}
			$gkey    = $info['key'];
			$group[] = $info;
		}
		return array_merge( $result, self::flush_group( $styles, $group ) );
	}

	/**
	 * Can a handle be combined? Returns info or false.
	 *
	 * @param WP_Styles $styles Registry.
	 * @param string    $handle Handle.
	 * @param string    $mode   Mode.
	 * @return array|false
	 */
	private static function combinable( $styles, $handle, $mode ) {
		if ( in_array( $handle, $styles->done, true ) || ! isset( $styles->registered[ $handle ] ) || 0 === strpos( $handle, 'wpss-' ) ) {
			return false;
		}
		$obj = $styles->registered[ $handle ];
		if ( empty( $obj->src ) || ! empty( $obj->extra['conditional'] ) || ! empty( $obj->extra['alt'] ) || ! empty( $obj->extra['title'] ) || ! empty( $obj->extra['after'] ) || ! empty( $obj->extra['before'] ) ) {
			return false;
		}
		if ( is_rtl() && ! empty( $obj->extra['rtl'] ) ) {
			return false;
		}
		$src  = self::absolute( $obj->src, $styles );
		$path = WPSS_FS::url_to_path( $src );
		if ( false === $path || 'css' !== strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) || WPSS_FS::is_inside( $path, WPSS_CACHE_DIR ) ) {
			return false;
		}
		$c = WPSS_Compat::classify( 'css', $handle, $src );
		if ( $c['no_combine'] || $c['no_minify'] ) {
			WPSS_Debug::add( 'css', $handle, 'Not combined', implode( '; ', $c['reasons'] ) );
			return false;
		}
		$ver = false === $obj->ver ? $styles->default_version : $obj->ver;
		if ( null !== $ver && '' !== (string) $ver ) {
			$src = add_query_arg( 'ver', $ver, $src );
		}
		$media  = $obj->args ? (string) $obj->args : 'all';
		$family = 'aggressive' === $mode ? 'any' : WPSS_Compat::family( $path );
		$code   = self::member_css( $path, $src );
		if ( false === $code ) {
			return false;
		}
		return array(
			'handle' => $handle,
			'src'    => $src,
			'path'   => $path,
			'media'  => $media,
			'key'    => $media . '|' . $family,
			'code'   => $code,
			'import' => (bool) preg_match( '/@import\b/i', $code ),
		);
	}

	/**
	 * Transformed CSS for a combine member (cached per request).
	 *
	 * @param string $path Path.
	 * @param string $src  Src.
	 * @return string|false
	 */
	private static function member_css( $path, $src ) {
		static $memo = array();
		$k = $path . '|' . self::sig( $path );
		if ( ! array_key_exists( $k, $memo ) ) {
			$code = self::transform( 'css', $path, $src );
			if ( false !== $code ) {
				$code = trim( preg_replace( '/@charset\s+(["\']).*?\1\s*;/i', '', $code ) );
			}
			$memo[ $k ] = $code;
		}
		return $memo[ $k ];
	}

	/**
	 * Emit a group: 0–1 members stay as they are; 2+ become one combined handle.
	 *
	 * @param WP_Styles $styles Registry.
	 * @param array     $group  Members.
	 * @return string[] Handles to print.
	 */
	private static function flush_group( $styles, $group ) {
		if ( count( $group ) < 2 ) {
			return wp_list_pluck( $group, 'handle' );
		}
		$sigs = '';
		foreach ( $group as $m ) {
			$sigs .= $m['path'] . '|' . self::sig( $m['path'] ) . '|' . $m['src'] . ';';
		}
		$key = md5( 'combined|' . $sigs . WPSS_VERSION );
		$rel = self::map_get( $key );
		if ( false === $rel ) {
			$parts = array();
			foreach ( $group as $m ) {
				$parts[] = $m['code'];
			}
			$rel = self::store_output( 'css', 'combined.css', implode( "\n", $parts ) . "\n" );
			if ( false === $rel ) {
				return wp_list_pluck( $group, 'handle' );
			}
			self::map_put( $key, $rel );
		}
		$url = WPSS_FS::cache_url( $rel );
		if ( ! $url ) {
			return wp_list_pluck( $group, 'handle' );
		}
		$hash   = substr( md5( $rel ), 0, 12 );
		$handle = 'wpss-combined-' . $hash;
		$styles->add( $handle, $url, array(), null, $group[0]['media'] );
		$orig    = array();
		$members = array();
		$bytes   = 0;
		foreach ( $group as $m ) {
			$styles->done[] = $m['handle']; // Never printed separately (not even as a late style).
			$orig[]         = $m['src'];
			$members[]      = $m['handle'];
			$bytes         += (int) @filesize( $m['path'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			self::track_source( $m['path'] );
			WPSS_Page_Cache::add_dep( 'file:' . WPSS_FS::relative_key( $m['path'] ) );
			self::note_graph( 'css', $m['handle'], $m['src'], $m['path'] );
			WPSS_Debug::add( 'css', $m['handle'], 'Combined', $handle . ' (' . WPSS_Compat::family( $m['path'] ) . ')' );
		}
		self::$outputs[ $rel ]       = true;
		self::$css_tags[ $handle ]   = array(
			'orig' => $orig,
			'opt'  => 'combined',
		);
		self::$combined[ $handle ]      = array( $members, $bytes, count( $group ) );
		self::$sizes['css'][ $handle ] = array( $bytes, (int) @filesize( WPSS_CACHE_DIR . '/' . $rel ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return array( $handle );
	}

	/* =====================================================================
	 * JS strategies (print_scripts_array)
	 * =================================================================== */

	/**
	 * Request defer (core validates it) or mark scripts as delayed. Order is untouched.
	 *
	 * @param string[] $to_do Sorted handles.
	 * @return string[]
	 */
	public static function script_strategies( $to_do ) {
		if ( ! is_array( $to_do ) || ! self::active( 'js' ) ) {
			return $to_do;
		}
		$scripts    = wp_scripts();
		$mode       = self::mode( 'js' );
		$no_delay   = WPSS_Context::is_transactional();
		$delay_list = WPSS_Settings::lines( 'delay_list' );
		$home_host  = WPSS_FS::home_host();

		foreach ( $to_do as $handle ) {
			if ( ! isset( $scripts->registered[ $handle ] ) || in_array( $handle, $scripts->done, true ) ) {
				continue;
			}
			$obj = $scripts->registered[ $handle ];
			if ( empty( $obj->src ) ) {
				continue; // Alias handle: nothing is printed for it.
			}
			$src = self::absolute( $obj->src, $scripts );
			$c   = WPSS_Compat::classify( 'js', $handle, $src );

			// ---- Delay: explicit list, or (Aggressive) third-party leaf scripts.
			$host         = strtolower( (string) wp_parse_url( $src, PHP_URL_HOST ) );
			$external     = '' !== $host && $host !== $home_host && false === strpos( $home_host, $host );
			$wants_delay  = ! $no_delay && ( false !== WPSS_Exclusions::match_list( $delay_list, $handle, $src ) || ( 'aggressive' === $mode && $external ) );
			if ( $wants_delay ) {
				$block = '';
				if ( $c['no_delay'] ) {
					$block = 'Protected: ' . implode( '; ', $c['reasons'] );
				} elseif ( ! empty( $obj->extra['after'] ) ) {
					$block = 'Has inline "after" code';
				} elseif ( ! empty( $obj->extra['conditional'] ) ) {
					$block = 'Conditional script';
				} elseif ( self::has_dependents( $scripts, $handle ) ) {
					$block = 'Other scripts depend on it';
				}
				if ( '' === $block ) {
					self::$delayed[ $handle ] = 'interaction';
					WPSS_Debug::add( 'js', $handle, 'Delayed', sprintf( 'Loads on first interaction (or after %ds)', self::interaction_timeout() / 1000 ) );
					continue;
				}
				WPSS_Debug::add( 'js', $handle, 'Not delayed', $block );
			}

			// ---- Delay non-critical first-party scripts until the browser is idle after load.
			if ( ! $no_delay && WPSS_Settings::get( 'js_delay_noncritical' ) && ! $external && self::noncritical( $scripts, $handle, $obj, $c ) ) {
				self::$delayed[ $handle ] = 'idle';
				WPSS_Debug::add( 'js', $handle, 'Delayed', 'Non-critical script: loads when the browser is idle after the page has loaded' );
				continue;
			}
			if ( $c['no_defer'] ) {
				WPSS_Stats::protect( 'js', $handle, implode( '; ', $c['reasons'] ) );
			}

			// ---- Defer.
			if ( 'safe' === $mode ) {
				continue;
			}
			$in_footer = isset( $scripts->groups[ $handle ] ) && $scripts->groups[ $handle ] > 0;
			if ( 'balanced' === $mode && ! $in_footer ) {
				continue;
			}
			if ( $c['no_defer'] ) {
				WPSS_Debug::add( 'js', $handle, 'Protected', implode( '; ', $c['reasons'] ) );
				continue;
			}
			if ( ! empty( $obj->extra['conditional'] ) || ! empty( $obj->extra['strategy'] ) ) {
				continue; // Respect the script's own loading attribute.
			}
			$scripts->add_data( $handle, 'strategy', 'defer' );
			self::$js_tags[ $handle ]['defer_requested'] = true;
		}
		return $to_do;
	}

	/**
	 * A first-party script that nothing depends on, printed in the footer, with no inline code
	 * after it, and not in any protected dependency group.
	 *
	 * @param WP_Scripts $scripts Registry.
	 * @param string     $handle  Handle.
	 * @param object     $obj     Registered script.
	 * @param array      $c       Classification.
	 */
	private static function noncritical( $scripts, $handle, $obj, $c ) {
		if ( ! empty( $c['rules'] ) || $c['no_delay'] || $c['no_defer'] ) {
			return false;
		}
		$in_footer = isset( $scripts->groups[ $handle ] ) && $scripts->groups[ $handle ] > 0;
		if ( ! $in_footer || ! empty( $obj->extra['after'] ) || ! empty( $obj->extra['conditional'] ) || 'async' === ( $obj->extra['strategy'] ?? '' ) ) {
			return false;
		}
		if ( self::has_dependents( $scripts, $handle ) ) {
			return false;
		}
		return (bool) apply_filters( 'wpss_js_noncritical', true, $handle, $obj );
	}

	/**
	 * Remember handle, dependencies and group of a file (used to explain protection events and
	 * to show the dependency map in the admin).
	 *
	 * @param string $type   css|js.
	 * @param string $handle Handle.
	 * @param string $src    Src.
	 * @param string $path   Path.
	 */
	private static function note_graph( $type, $handle, $src, $path ) {
		$key = WPSS_FS::relative_key( $path );
		if ( ! $key ) {
			return;
		}
		$reg  = 'js' === $type ? wp_scripts() : wp_styles();
		$deps = isset( $reg->registered[ $handle ] ) ? array_values( array_map( 'strval', (array) $reg->registered[ $handle ]->deps ) ) : array();
		self::$graph_seen[ $key ] = array(
			'type'   => $type,
			'handle' => (string) $handle,
			'deps'   => $deps,
			'group'  => WPSS_Compat::group( $type, $handle, $src ),
		);
		if ( 1 === count( self::$graph_seen ) ) {
			add_action( 'shutdown', array( __CLASS__, 'save_graph' ), 5 );
		}
	}

	/**
	 * Persist new/changed graph entries (anonymous renders only; one option write when changed).
	 */
	public static function save_graph() {
		if ( ! self::$graph_seen || is_user_logged_in() ) {
			return;
		}
		$graph   = self::graph();
		$changed = false;
		foreach ( self::$graph_seen as $k => $v ) {
			if ( ! isset( $graph[ $k ] ) || $graph[ $k ] != $v ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
				unset( $graph[ $k ] );
				$graph[ $k ] = $v;
				$changed     = true;
			}
		}
		if ( $changed ) {
			if ( count( $graph ) > 600 ) {
				$graph = array_slice( $graph, -600, null, true );
			}
			update_option( self::GRAPH, $graph, false );
		}
	}

	/**
	 * @return array file key => array(type, handle, deps, group)
	 */
	public static function graph() {
		$g = get_option( self::GRAPH, array() );
		return is_array( $g ) ? $g : array();
	}

	/**
	 * Register a derived output file (and its source) in this page's freshness manifest.
	 *
	 * @param string $rel  Relative output path.
	 * @param string $path Source path.
	 */
	public static function register_output( $rel, $path = '' ) {
		self::$outputs[ $rel ] = true;
		if ( '' !== $path ) {
			self::track_source( $path );
		}
	}

	/**
	 * Member handle => original src of a combined stylesheet handle (empty if not combined).
	 *
	 * @param string $handle Handle.
	 * @return array
	 */
	public static function combined_members( $handle ) {
		if ( ! isset( self::$combined[ $handle ], self::$css_tags[ $handle ] ) ) {
			return array();
		}
		$srcs = self::$css_tags[ $handle ]['orig'];
		$out  = array();
		foreach ( self::$combined[ $handle ][0] as $i => $h ) {
			$out[ $h ] = isset( $srcs[ $i ] ) ? $srcs[ $i ] : '';
		}
		return $out;
	}

	/**
	 * Fallback timeout (ms) for interaction-triggered scripts.
	 */
	public static function interaction_timeout() {
		return WPSS_Settings::get( 'tp_delay' ) ? 1000 * (int) WPSS_Settings::get( 'tp_timeout' ) : 8000;
	}

	/**
	 * Does any enqueued/printed script depend on $handle?
	 *
	 * @param WP_Scripts $scripts Registry.
	 * @param string     $handle  Handle.
	 */
	private static function has_dependents( $scripts, $handle ) {
		$active = array_unique( array_merge( (array) $scripts->queue, (array) $scripts->to_do, (array) $scripts->done ) );
		foreach ( $active as $h ) {
			if ( isset( $scripts->registered[ $h ] ) && in_array( $handle, (array) $scripts->registered[ $h ]->deps, true ) ) {
				return true;
			}
		}
		return false;
	}

	/* =====================================================================
	 * Tags
	 * =================================================================== */

	/**
	 * @param string $tag    Tag.
	 * @param string $handle Handle.
	 * @param string $href   Href.
	 * @param string $media  Media.
	 */
	public static function style_tag( $tag, $handle, $href = '', $media = '' ) {
		if ( WPSS_Context::optimize() ) {
			if ( isset( self::$combined[ $handle ] ) ) {
				WPSS_Stats::add( 'css_req_before', self::$combined[ $handle ][2] );
			} else {
				WPSS_Stats::add( 'css_req_before' );
			}
			WPSS_Stats::add( 'css_req_after' );
			if ( isset( self::$sizes['css'][ $handle ] ) ) {
				WPSS_Stats::add( 'css_orig', self::$sizes['css'][ $handle ][0] );
				WPSS_Stats::add( 'css_opt', self::$sizes['css'][ $handle ][1] );
			}
		}
		if ( ! isset( self::$css_tags[ $handle ] ) ) {
			return $tag;
		}
		$info  = self::$css_tags[ $handle ];
		$attrs = ' data-wpss-orig="' . esc_attr( implode( ' ', $info['orig'] ) ) . '" data-wpss-opt="' . esc_attr( $info['opt'] ) . '"';
		return preg_replace( '/<link\b/i', '<link' . $attrs, $tag, 1 );
	}

	/**
	 * @param string $tag    Tag.
	 * @param string $handle Handle.
	 * @param string $src    Src.
	 */
	public static function script_tag( $tag, $handle, $src = '' ) {
		$info    = isset( self::$js_tags[ $handle ] ) ? self::$js_tags[ $handle ] : array();
		$delayed = isset( self::$delayed[ $handle ] );
		$trigger = $delayed ? self::$delayed[ $handle ] : '';
		if ( WPSS_Context::optimize() && '' !== (string) $src ) {
			WPSS_Stats::add( 'js_req_before' );
			if ( isset( self::$sizes['js'][ $handle ] ) ) {
				WPSS_Stats::add( 'js_orig', self::$sizes['js'][ $handle ][0] );
				if ( ! $delayed ) {
					WPSS_Stats::add( 'js_opt', self::$sizes['js'][ $handle ][1] );
				}
			}
			if ( $delayed ) {
				WPSS_Stats::add( 'js_delayed' );
			} else {
				WPSS_Stats::add( 'js_req_after' );
			}
		}
		if ( empty( $info ) && ! $delayed ) {
			return $tag;
		}
		$pattern = '/<script\b[^>]*\bid=(["\'])' . preg_quote( $handle . '-js', '/' ) . '\1[^>]*>/i';
		return preg_replace_callback(
			$pattern,
			static function ( $m ) use ( $info, $delayed, $handle, $trigger ) {
				$open = $m[0];
				$opt  = array();
				if ( ! empty( $info['orig'] ) ) {
					$open  = preg_replace( '/<script\b/i', '<script data-wpss-orig="' . esc_attr( implode( ' ', $info['orig'] ) ) . '"', $open, 1 );
					$opt[] = 'min';
				}
				if ( ! empty( $info['defer_requested'] ) ) {
					if ( preg_match( '/\sdefer\b/i', $open ) ) {
						$opt[] = 'defer';
						WPSS_Stats::add( 'js_deferred' );
						WPSS_Debug::add( 'js', $handle, 'Deferred', 'Core confirmed defer is dependency-safe' );
					} else {
						WPSS_Debug::add( 'js', $handle, 'Blocking', 'Core kept it blocking (a dependent or inline code needs it)' );
					}
				}
				if ( $delayed ) {
					$open  = preg_replace( '/\s(type|defer|async|data-wp-strategy)(=(["\'])[^"\']*\3)?(?=[\s>\/])/i', '', $open );
					$open  = preg_replace( '/\ssrc=/i', ' data-wpss-src=', $open, 1 );
					$open  = preg_replace( '/<script\b/i', '<script type="wpss/delayed" data-wpss-trigger="' . esc_attr( $trigger ) . '"', $open, 1 );
					$opt[] = 'delay';
				}
				if ( $opt ) {
					$open = preg_replace( '/<script\b/i', '<script data-wpss-opt="' . esc_attr( implode( ' ', $opt ) ) . '"', $open, 1 );
				}
				return $open;
			},
			$tag,
			1
		);
	}

	/**
	 * Print the loader when scripts were delayed through the dependency system.
	 */
	public static function delay_loader() {
		if ( empty( self::$delayed ) ) {
			return;
		}
		self::$loader_printed = true;
		echo self::loader_tag(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static script built below.
	}

	/** @var bool */
	public static $loader_printed = false;

	/**
	 * Loader for <script type="wpss/delayed"> elements.
	 *
	 * Triggers (data-wpss-trigger): "interaction" (first key/pointer/scroll/touch, or the fallback
	 * timeout), "idle" (after window load, when the browser is idle) and "timeout" (N seconds after
	 * load). Within a trigger group scripts run strictly in document order: an external script is
	 * fully loaded and executed before the next one is inserted, so dependencies are never inverted.
	 * With INP optimization each script runs in its own task, yielding to user input in between.
	 */
	public static function loader_tag() {
		$cfg = array(
			't' => self::interaction_timeout(),
			'i' => WPSS_Settings::get( 'inp_opt' ) ? 1 : 0,
		);
		$js  = 'window.WPSSD=' . wp_json_encode( $cfg ) . ';(function(){var C=window.WPSSD,S={};'
			. 'function L(t){return[].filter.call(document.querySelectorAll(\'script[type="wpss/delayed"]\'),function(s){return(s.getAttribute("data-wpss-trigger")||"interaction")===t})}'
			. 'function Y(f){C.i?setTimeout(f,0):f()}'
			. 'function R(t){if(S[t])return;S[t]=1;var l=L(t),i=0;function n(){if(i>=l.length)return;var o=l[i++];if(!o.parentNode){return n()}var s=document.createElement("script"),a;'
			. 'for(a=0;a<o.attributes.length;a++){var k=o.attributes[a].name;if(k!=="type"&&k!=="data-wpss-src"&&k!=="data-wpss-type")s.setAttribute(k,o.attributes[a].value)}'
			. 'if(o.getAttribute("data-wpss-type"))s.type=o.getAttribute("data-wpss-type");if(o.nonce)s.nonce=o.nonce;'
			. 'var rp=o.getAttribute("data-wpss-replay"),q=rp&&window[rp]&&window[rp].wpssq?window[rp].wpssq:null,rs=o.getAttribute("data-wpss-reset");'
			. 'if(rs)rs.split(",").forEach(function(g){try{delete window[g]}catch(e){window[g]=void 0}});'
			. 'var u=o.getAttribute("data-wpss-src");if(u){s.async=false;s.onload=s.onerror=function(){Y(n)};s.src=u;o.parentNode.replaceChild(s,o)}'
			. 'else{s.text=o.text;o.parentNode.replaceChild(s,o);if(q&&window[rp]&&!window[rp].wpssq){q.forEach(function(x){try{window[rp].apply(window,x)}catch(e){}})}Y(n)}}n()}'
			. 'var E=["keydown","mousedown","pointerdown","mousemove","touchstart","scroll","wheel"];'
			. 'function I(){E.forEach(function(e){removeEventListener(e,I,{passive:true})});R("interaction")}'
			. 'E.forEach(function(e){addEventListener(e,I,{passive:true})});setTimeout(I,C.t);'
			. 'function A(){var r=window.requestIdleCallback||function(f){setTimeout(f,200)};r(function(){R("idle")},{timeout:3000});setTimeout(function(){R("timeout")},C.t)}'
			. 'if(document.readyState==="complete")A();else addEventListener("load",A)})();';
		return wp_get_inline_script_tag( $js, array( 'id' => 'wpss-delay-loader' ) );
	}

	/* =====================================================================
	 * Manifest for the page cache
	 * =================================================================== */

	/**
	 * @return array{sources:array,outputs:array}
	 */
	public static function manifest() {
		return array(
			'sources' => self::$sources,
			'outputs' => array_keys( self::$outputs ),
		);
	}

	/**
	 * Counts for the dashboard.
	 *
	 * @return array{css:int,js:int,size:int}
	 */
	public static function stats() {
		list( $css, $s1 ) = WPSS_FS::dir_stats( WPSS_CACHE_DIR . '/assets/css', '/\.css$/' );
		list( $js, $s2 )  = WPSS_FS::dir_stats( WPSS_CACHE_DIR . '/assets/js', '/\.js$/' );
		return array(
			'css'  => $css,
			'js'   => $js,
			'size' => $s1 + $s2,
		);
	}
}
