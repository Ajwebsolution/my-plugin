<?php
/**
 * Database cleanup. Only ever runs on an explicit, confirmed admin action.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * DB maintenance.
 */
class WPSS_Database {

	const REVISION_AGE  = 30; // days.
	const DRAFT_AGE     = 7;  // days.
	const TIME_BUDGET   = 20; // seconds per request.

	/**
	 * Operations shown in the admin.
	 *
	 * @return array op => label
	 */
	public static function ops() {
		return array(
			'revisions'           => sprintf( /* translators: %d days */ __( 'Delete post revisions older than %d days', 'steady-speed' ), self::REVISION_AGE ),
			'auto_drafts'         => sprintf( /* translators: %d days */ __( 'Delete auto-drafts older than %d days', 'steady-speed' ), self::DRAFT_AGE ),
			'transients'          => __( 'Delete expired transients', 'steady-speed' ),
			'orphan_postmeta'     => __( 'Delete orphaned post meta', 'steady-speed' ),
			'orphan_commentmeta'  => __( 'Delete orphaned comment meta', 'steady-speed' ),
			'optimize'            => __( 'Optimize database tables (reclaim overhead)', 'steady-speed' ),
		);
	}

	/**
	 * @param int $days Days.
	 */
	private static function cutoff( $days ) {
		return gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	}

	/**
	 * Counts per operation.
	 *
	 * @return array op => int (bytes for optimize)
	 */
	public static function stats() {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$s                       = array();
		$s['revisions_total']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" );
		$s['revisions']          = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < %s", self::cutoff( self::REVISION_AGE ) ) );
		$s['auto_drafts']        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < %s", self::cutoff( self::DRAFT_AGE ) ) );
		$s['transients']         = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d", $wpdb->esc_like( '_transient_timeout_' ) . '%', time() ) );
		$s['orphan_postmeta']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.ID IS NULL" );
		$s['orphan_commentmeta'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL" );
		$s['optimize']           = 0;
		foreach ( self::tables() as $t ) {
			$s['optimize'] += (int) $t['free'];
		}
		// phpcs:enable
		return $s;
	}

	/**
	 * This site's tables with overhead.
	 *
	 * @return array[] name, engine, free
	 */
	private static function tables() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SHOW TABLE STATUS LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out  = array();
		foreach ( (array) $rows as $r ) {
			if ( empty( $r['Name'] ) || ! preg_match( '/^[A-Za-z0-9_$]+$/', $r['Name'] ) ) {
				continue;
			}
			$out[] = array(
				'name'   => $r['Name'],
				'engine' => isset( $r['Engine'] ) ? $r['Engine'] : '',
				'free'   => isset( $r['Data_free'] ) ? (int) $r['Data_free'] : 0,
			);
		}
		return $out;
	}

	/**
	 * Run one operation.
	 *
	 * @param string $op Operation.
	 * @return string Result message.
	 */
	public static function run( $op ) {
		global $wpdb;
		$start = time();
		$n     = 0;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		switch ( $op ) {
			case 'revisions':
				do {
					$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < %s LIMIT 500", self::cutoff( self::REVISION_AGE ) ) );
					foreach ( $ids as $id ) {
						if ( wp_delete_post_revision( (int) $id ) ) {
							++$n;
						}
					}
				} while ( count( $ids ) === 500 && time() - $start < self::TIME_BUDGET );
				break;

			case 'auto_drafts':
				do {
					$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < %s LIMIT 500", self::cutoff( self::DRAFT_AGE ) ) );
					foreach ( $ids as $id ) {
						if ( wp_delete_post( (int) $id, true ) ) {
							++$n;
						}
					}
				} while ( count( $ids ) === 500 && time() - $start < self::TIME_BUDGET );
				break;

			case 'transients':
				$before = self::stats()['transients'];
				delete_expired_transients( true );
				$n = max( 0, $before - self::stats()['transients'] );
				break;

			case 'orphan_postmeta':
				$n = (int) $wpdb->query( "DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.ID IS NULL" );
				wp_cache_flush_group( 'post_meta' );
				break;

			case 'orphan_commentmeta':
				$n = (int) $wpdb->query( "DELETE cm FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL" );
				wp_cache_flush_group( 'comment_meta' );
				break;

			case 'optimize':
				foreach ( self::tables() as $t ) {
					if ( $t['free'] <= 0 || time() - $start > self::TIME_BUDGET ) {
						continue;
					}
					$wpdb->query( 'OPTIMIZE TABLE `' . $t['name'] . '`' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- name validated against [A-Za-z0-9_$].
					++$n;
				}
				break;

			default:
				return __( 'Unknown operation.', 'steady-speed' );
		}
		// phpcs:enable
		$label = self::ops()[ $op ];
		WPSS_Logger::log( sprintf( 'Database: %s – %d item(s).', $label, $n ) );
		return sprintf( /* translators: 1: op label, 2: count */ __( '%1$s: %2$d item(s) processed.', 'steady-speed' ), $label, $n );
	}
}
