<?php
/**
 * Background housekeeping.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cron tasks.
 */
class WPSS_Cron {

	const ASSET_MAX_AGE = 14; // days since last use (build() touches files daily while in use).

	public static function init() {
		add_action( 'wpss_cleanup', array( __CLASS__, 'cleanup' ) );
		add_action( 'wpss_webp_batch', array( 'WPSS_Images', 'batch' ) );
		WPSS_Warmup::init();
		if ( ! wp_next_scheduled( 'wpss_cleanup' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'wpss_cleanup' );
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'wpss_cleanup' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'wpss_cleanup' );
		}
	}

	public static function unschedule() {
		foreach ( array( 'wpss_cleanup', 'wpss_webp_batch', 'wpss_font_download', 'wpss_warm' ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
	}

	/**
	 * Hourly: remove trashed page folders, expired pages, unused optimized files, stale counters.
	 */
	public static function cleanup() {
		if ( ! WPSS_FS::ready() || ! is_dir( WPSS_CACHE_DIR ) ) {
			return;
		}
		$start = time();

		// 1. Old page-cache folders renamed away by purge_all().
		foreach ( (array) glob( WPSS_CACHE_DIR . '/trash-*', GLOB_ONLYDIR ) as $dir ) {
			if ( $dir && WPSS_FS::is_inside( $dir, WPSS_CACHE_DIR ) ) {
				WPSS_FS::rrmdir( $dir );
			}
			if ( time() - $start > 20 ) {
				return;
			}
		}

		// 2. Expired pages.
		$ttl     = (int) WPSS_Settings::get( 'cache_ttl' );
		$expired = array();
		foreach ( (array) glob( WPSS_Page_Cache::dir() . '/*/*.html' ) as $file ) {
			if ( $file && @filemtime( $file ) < time() - $ttl ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				$expired[] = basename( $file, '.html' );
				if ( count( $expired ) >= 2000 ) {
					break;
				}
			}
		}
		if ( $expired ) {
			WPSS_Page_Cache::delete_keys( $expired, 'Expired (TTL)', false );
		}

		// 3. Optimized files not used for a while (pages still referencing them are
		// already expired, and serve-time checks regenerate anything missing).
		$cut = time() - self::ASSET_MAX_AGE * DAY_IN_SECONDS;
		foreach ( array( 'css' => '*.css', 'js' => '*.js', 'map' => '*' ) as $type => $pattern ) {
			foreach ( (array) glob( WPSS_CACHE_DIR . '/assets/' . $type . '/' . $pattern ) as $file ) {
				if ( 'map' === $type && ( '.htaccess' === basename( $file ) || 'index.php' === basename( $file ) ) ) {
					continue;
				}
				if ( $file && @filemtime( $file ) < $cut ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					wp_delete_file( $file );
				}
			}
		}

		// 4. Old error reports.
		WPSS_Monitor::prune();

		// 5. Temporary protections that have ended: retry optimization.
		WPSS_Exclusions::prune_expired();

		// 6. Popular pages (for the warmup) and anonymous Core Web Vitals samples.
		WPSS_Warmup::aggregate_hits();
		WPSS_Report::aggregate_rum();

		// 7. Source CSS/JS edited outside WordPress (FTP, theme editor): invalidate only the pages
		// that use the file, then warm them. (Serve-time checks already prevent stale output.)
		if ( time() - $start < 20 ) {
			self::scan_files();
		}

		// 8. Old page reports.
		foreach ( (array) glob( WPSS_Stats::dir() . '/*.json' ) as $file ) {
			if ( $file && @filemtime( $file ) < time() - 30 * DAY_IN_SECONDS ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				wp_delete_file( $file );
			}
		}
	}

	/**
	 * Compare the signature of every source file that cached pages depend on with the last scan.
	 */
	public static function scan_files() {
		global $wpdb;
		$table = WPSS_Page_Cache::table();
		$deps  = (array) $wpdb->get_col( "SELECT DISTINCT dep FROM {$table} WHERE dep LIKE 'file:%' LIMIT 3000" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
		$old   = get_option( 'wpss_file_sigs', array() );
		$old   = is_array( $old ) ? $old : array();
		$new   = array();
		foreach ( $deps as $dep ) {
			$key  = substr( $dep, 5 );
			$path = is_file( WP_CONTENT_DIR . '/' . $key ) ? WP_CONTENT_DIR . '/' . $key : ABSPATH . $key;
			$sig  = is_file( $path ) ? (int) @filemtime( $path ) . '-' . (int) @filesize( $path ) : 'gone'; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$new[ $key ] = $sig;
			if ( isset( $old[ $key ] ) && $old[ $key ] !== $sig ) {
				WPSS_Page_Cache::queue( $dep, 'Source file changed: ' . $key );
			}
		}
		update_option( 'wpss_file_sigs', $new, false );
	}
}
