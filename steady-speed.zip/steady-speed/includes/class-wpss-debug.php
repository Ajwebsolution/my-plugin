<?php
/**
 * Developer Debug Mode: per-request report of every optimization decision.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Debug {

	const REPORTS  = 'wpss_debug_reports';
	const COUNTERS = 'wpss_cache_counters';

	/** @var array */
	private static $assets = array();

	/** @var array */
	private static $notes = array();

	/**
	 * Is debug output active for this request?
	 */
	public static function on() {
		return (bool) WPSS_Settings::get( 'debug' ) || WPSS_Context::admin_debug_preview();
	}

	/**
	 * Record an asset decision.
	 *
	 * @param string $type   css|js.
	 * @param string $name   Handle or file.
	 * @param string $status Optimized|Protected|Excluded|Skipped|Combined|Deferred|Delayed|Original.
	 * @param string $reason Reason.
	 */
	public static function add( $type, $name, $status, $reason = '' ) {
		if ( ! self::on() ) {
			return;
		}
		$key = $type . ':' . $name;
		if ( isset( self::$assets[ $key ] ) && self::$assets[ $key ]['status'] !== $status ) {
			// Several decisions per asset (e.g. minified + deferred): keep them all.
			$prev   = self::$assets[ $key ];
			$status = $prev['status'] . ' + ' . $status;
			$reason = ( $prev['reason'] === $reason || '' === $reason ) ? $prev['reason'] : trim( $prev['reason'] . ( '' !== $prev['reason'] ? '; ' : '' ) . $reason );
		}
		self::$assets[ $key ] = array(
			'type'   => $type,
			'name'   => $name,
			'status' => $status,
			'reason' => $reason,
		);
	}

	/**
	 * Free-form note (cache decisions, detections, invalidation reasons).
	 *
	 * @param string $label Label.
	 * @param string $value Value.
	 */
	public static function note( $label, $value ) {
		if ( self::on() ) {
			self::$notes[ $label ] = $value;
		}
	}

	/**
	 * Count cache hit/miss (debug only, to avoid a DB write on every request).
	 *
	 * @param string $what hit|miss.
	 */
	public static function count( $what ) {
		if ( ! WPSS_Settings::get( 'debug' ) ) {
			return;
		}
		$c = get_option( self::COUNTERS, array() );
		$c = is_array( $c ) ? $c : array();
		$c[ $what ] = isset( $c[ $what ] ) ? (int) $c[ $what ] + 1 : 1;
		update_option( self::COUNTERS, $c, false );
	}

	/**
	 * Build the report text.
	 */
	private static function report_lines() {
		$lines   = array();
		$lines[] = 'Steady Speed debug – ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		$detect  = WPSS_Compat::detect();
		$lines[] = 'Detected: ' . ( $detect ? implode( ', ', $detect ) : 'none' );
		$lines[] = sprintf(
			'Protection: Elementor %s | Slider %s | Header %s',
			WPSS_Settings::get( 'elementor_compat' ) ? 'on' : 'off',
			WPSS_Settings::get( 'slider_protect' ) ? 'on' : 'off',
			WPSS_Settings::get( 'header_protect' ) ? 'on' : 'off'
		);
		$lines[] = 'Performance mode: ' . ucfirst( (string) WPSS_Settings::get( 'perf_mode' ) );
		foreach ( self::$notes as $label => $value ) {
			$lines[] = $label . ': ' . $value;
		}
		$lines[] = '';
		$lines[] = '— Summary —';
		foreach ( WPSS_Stats::summary_lines() as $l ) {
			$lines[] = $l;
		}
		$prot = WPSS_Stats::protected_list();
		if ( $prot['css'] || $prot['js'] ) {
			$lines[] = '';
			$lines[] = '— Protected assets (why) —';
			foreach ( array( 'js', 'css' ) as $t ) {
				foreach ( $prot[ $t ] as $name => $why ) {
					$lines[] = sprintf( '%s [%s] PROTECTED – Reason: %s', $name, strtoupper( $t ), $why );
				}
			}
		}
		$lines[] = '';
		$lines[] = '— Assets —';
		foreach ( self::$assets as $a ) {
			$lines[] = sprintf( '[%s] %s → %s%s', strtoupper( $a['type'] ), $a['name'], $a['status'], '' !== $a['reason'] ? ' (' . $a['reason'] . ')' : '' );
		}
		$groups = self::dependency_groups();
		if ( $groups ) {
			$lines[] = '';
			$lines[] = '— Dependency groups (scripts in load order) —';
			foreach ( $groups as $g => $items ) {
				$lines[] = $g . ': ' . implode( ', ', $items );
			}
		}
		return $lines;
	}

	/**
	 * Scripts printed on this page grouped by dependency group, "handle ← deps".
	 *
	 * @return array group => string[]
	 */
	public static function dependency_groups() {
		$scripts = wp_scripts();
		$out     = array();
		foreach ( (array) $scripts->done as $h ) {
			if ( ! isset( $scripts->registered[ $h ] ) || empty( $scripts->registered[ $h ]->src ) ) {
				continue;
			}
			$obj  = $scripts->registered[ $h ];
			$src  = preg_match( '#^(https?:)?//#', (string) $obj->src ) ? (string) $obj->src : $scripts->base_url . $obj->src;
			$g    = WPSS_Compat::group( 'js', $h, $src );
			$deps = array_filter( (array) $obj->deps );
			$out[ $g ][] = $h . ( $deps ? ' ← ' . implode( '+', $deps ) : '' );
		}
		ksort( $out );
		return $out;
	}

	/**
	 * Inject the report into the HTML (comment; plus a visible panel for ?wpss_debug=1 admins).
	 *
	 * @param string $html HTML.
	 */
	public static function inject( $html ) {
		if ( ! self::on() ) {
			return $html;
		}
		$lines = self::report_lines();
		self::store( $lines );

		$comment = "\n<!-- " . str_replace( '--', '- -', implode( "\n", $lines ) ) . " -->\n";
		$panel   = '';
		if ( WPSS_Context::admin_debug_preview() ) {
			$panel = '<div id="wpss-debug" style="position:fixed;z-index:2147483647;bottom:0;left:0;right:0;max-height:40vh;overflow:auto;background:#111;color:#eee;font:12px/1.5 monospace;padding:10px;white-space:pre-wrap">'
				. esc_html( implode( "\n", $lines ) )
				. '</div>';
		}
		$pos = strripos( $html, '</body>' );
		if ( '' !== $panel && false !== $pos ) {
			$html = substr_replace( $html, $panel, $pos, 0 );
		}
		$pos = strripos( $html, '</html>' );
		return false === $pos ? $html . $comment : substr_replace( $html, $comment, $pos + 7, 0 );
	}

	/**
	 * Keep the last reports for the admin Debug tab.
	 *
	 * @param string[] $lines Lines.
	 */
	private static function store( $lines ) {
		$uri     = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$reports = get_transient( self::REPORTS );
		$reports = is_array( $reports ) ? $reports : array();
		array_unshift(
			$reports,
			array(
				'url'   => $uri,
				'time'  => time(),
				'lines' => $lines,
			)
		);
		set_transient( self::REPORTS, array_slice( $reports, 0, 15 ), DAY_IN_SECONDS );
	}

	/**
	 * @return array
	 */
	public static function reports() {
		$r = get_transient( self::REPORTS );
		return is_array( $r ) ? $r : array();
	}
}
