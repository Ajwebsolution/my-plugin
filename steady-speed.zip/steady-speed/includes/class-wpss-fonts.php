<?php
/**
 * Optional Google Fonts optimization. Everything is opt-in because fonts affect design.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Fonts {

	const MAP = 'wpss_fonts_map';

	public static function init() {
		add_filter( 'style_loader_src', array( __CLASS__, 'filter_src' ), 15, 2 );
		add_filter( 'wp_resource_hints', array( __CLASS__, 'hints' ), 10, 2 );
		add_action( 'wpss_font_download', array( __CLASS__, 'download' ) );
		if ( WPSS_Settings::get( 'font_disable' ) && ! WPSS_Settings::safe_mode() ) {
			add_filter( 'elementor/frontend/print_google_fonts', array( __CLASS__, 'elementor_fonts' ) );
		}
	}

	/**
	 * @param bool $print Print.
	 */
	public static function elementor_fonts( $print ) {
		return WPSS_Context::optimize() ? false : $print;
	}

	/**
	 * @param string $src Src.
	 */
	private static function is_google( $src ) {
		return is_string( $src ) && false !== stripos( $src, 'fonts.googleapis.com/css' );
	}

	/**
	 * @param string $src    Src.
	 * @param string $handle Handle.
	 * @return string|false
	 */
	public static function filter_src( $src, $handle ) {
		if ( ! self::is_google( $src ) || ! WPSS_Context::optimize() ) {
			return $src;
		}
		if ( WPSS_Settings::get( 'font_disable' ) ) {
			WPSS_Debug::add( 'css', $handle, 'Removed', 'Google Fonts disabled in settings' );
			return false;
		}
		if ( WPSS_Settings::get( 'font_prune' ) ) {
			$pruned = self::prune( $src );
			if ( $pruned !== $src ) {
				WPSS_Debug::add( 'css', $handle, 'Font weights reduced', 'Only weights/styles used on analyzed pages are requested' );
				$src = $pruned;
			}
		}
		if ( WPSS_Settings::get( 'font_local' ) ) {
			$key = self::key( $src );
			$map = get_option( self::MAP, array() );
			if ( isset( $map[ $key ] ) && is_file( WPSS_CACHE_DIR . '/' . $map[ $key ] ) ) {
				$url = WPSS_FS::cache_url( $map[ $key ] );
				if ( $url ) {
					WPSS_Debug::add( 'css', $handle, 'Local font', 'Served from the site' );
					return $url;
				}
			}
			self::schedule( $src );
		}
		if ( WPSS_Settings::get( 'font_swap' ) ) {
			if ( false === stripos( $src, 'display=' ) ) {
				$src = add_query_arg( 'display', 'swap', $src );
			} else {
				$src = preg_replace( '/([?&]display=)auto\b/i', '$1swap', $src );
			}
		}
		return $src;
	}

	/**
	 * Remove Google Fonts weights/styles that no analyzed page uses.
	 * Families without usage data, variable-font ranges and unknown syntax are left untouched.
	 * Weight 400 (normal) is always kept.
	 *
	 * @param string $src Google Fonts URL.
	 */
	public static function prune( $src ) {
		$usage = WPSS_Analysis::font_usage();
		if ( null === $usage ) {
			return $src;
		}
		$url = html_entity_decode( $src, ENT_QUOTES );
		$is2 = false !== strpos( $url, '/css2' );
		$out = preg_replace_callback(
			'/([?&])family=([^&]*)/',
			static function ( $m ) use ( $usage, $is2 ) {
				$val = urldecode( $m[2] );
				if ( $is2 ) {
					return $m[1] . 'family=' . self::prune_css2( $val, $usage );
				}
				$fams = array();
				foreach ( explode( '|', $val ) as $fam ) {
					$fams[] = self::prune_css1( $fam, $usage );
				}
				return $m[1] . 'family=' . str_replace( ' ', '+', implode( '|', $fams ) );
			},
			$url
		);
		return is_string( $out ) ? $out : $src;
	}

	/**
	 * @param string $name  Family name (as in the URL, '+' for spaces).
	 * @param array  $usage Usage.
	 * @return array|null Used "weight|style" set, or null if unknown.
	 */
	private static function used( $name, $usage ) {
		$k = strtolower( trim( str_replace( '+', ' ', $name ) ) );
		if ( empty( $usage[ $k ] ) ) {
			return null;
		}
		$u               = $usage[ $k ];
		$u['400|normal'] = 1;
		return $u;
	}

	/**
	 * css (v1) syntax: Name:100,300italic,regular,700i
	 *
	 * @param string $fam   Family spec.
	 * @param array  $usage Usage.
	 */
	private static function prune_css1( $fam, $usage ) {
		$parts = explode( ':', $fam, 2 );
		if ( 2 !== count( $parts ) || false !== strpos( $parts[1], '..' ) ) {
			return $fam;
		}
		$used = self::used( $parts[0], $usage );
		if ( null === $used ) {
			return $fam;
		}
		$keep = array();
		foreach ( explode( ',', $parts[1] ) as $v ) {
			$t = strtolower( trim( $v ) );
			if ( 'regular' === $t ) {
				$w = 400;
				$st = 'normal';
			} elseif ( 'italic' === $t ) {
				$w = 400;
				$st = 'italic';
			} elseif ( preg_match( '/^(\d{3})(italic|i)?$/', $t, $mm ) ) {
				$w  = (int) $mm[1];
				$st = empty( $mm[2] ) ? 'normal' : 'italic';
			} else {
				$keep[] = $v; // Unknown token: keep.
				continue;
			}
			if ( isset( $used[ $w . '|' . $st ] ) ) {
				$keep[] = $v;
			}
		}
		return $keep ? $parts[0] . ':' . implode( ',', $keep ) : $fam;
	}

	/**
	 * css2 syntax: Name:wght@400;700 or Name:ital,wght@0,400;1,700
	 *
	 * @param string $fam   Family spec.
	 * @param array  $usage Usage.
	 */
	private static function prune_css2( $fam, $usage ) {
		if ( ! preg_match( '/^([^:]+):(ital,wght|wght)@(.+)$/', $fam, $m ) || false !== strpos( $m[3], '..' ) ) {
			return str_replace( ' ', '+', $fam );
		}
		$used = self::used( $m[1], $usage );
		if ( null === $used ) {
			return str_replace( ' ', '+', $fam );
		}
		$keep = array();
		foreach ( explode( ';', $m[3] ) as $tuple ) {
			$v = explode( ',', $tuple );
			if ( 'wght' === $m[2] && 1 === count( $v ) ) {
				$key = (int) $v[0] . '|normal';
			} elseif ( 'ital,wght' === $m[2] && 2 === count( $v ) ) {
				$key = (int) $v[1] . '|' . ( '1' === $v[0] ? 'italic' : 'normal' );
			} else {
				$keep[] = $tuple;
				continue;
			}
			if ( isset( $used[ $key ] ) ) {
				$keep[] = $tuple;
			}
		}
		return str_replace( ' ', '+', $m[1] ) . ':' . $m[2] . '@' . ( $keep ? implode( ';', $keep ) : $m[3] );
	}

	/**
	 * Map key: URL without ver.
	 *
	 * @param string $src Src.
	 */
	private static function key( $src ) {
		return md5( remove_query_arg( 'ver', html_entity_decode( $src ) ) );
	}

	/**
	 * Queue a background download.
	 *
	 * @param string $src Src.
	 */
	private static function schedule( $src ) {
		$src   = remove_query_arg( 'ver', html_entity_decode( $src ) );
		$guard = 'wpss_font_dl_' . md5( $src );
		if ( get_transient( $guard ) ) {
			return;
		}
		set_transient( $guard, 1, HOUR_IN_SECONDS );
		wp_schedule_single_event( time() + 10, 'wpss_font_download', array( $src ) );
	}

	/**
	 * Cron: download CSS + font files. All-or-nothing.
	 *
	 * @param string $src Google Fonts CSS URL.
	 */
	public static function download( $src ) {
		if ( ! self::is_google( $src ) || ! WPSS_FS::ready() ) {
			return;
		}
		$url = set_url_scheme( $src, 'https' );
		if ( false === stripos( $url, 'display=' ) && WPSS_Settings::get( 'font_swap' ) ) {
			$url = add_query_arg( 'display', 'swap', $url );
		}
		$res = wp_safe_remote_get(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
			)
		);
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			return;
		}
		$css = (string) wp_remote_retrieve_body( $res );
		if ( '' === $css || ! preg_match_all( '#url\((https://fonts\.gstatic\.com/[^)\s\'"]+\.(woff2|woff|ttf|otf))\)#i', $css, $m ) ) {
			return;
		}
		$key     = self::key( $src );
		$dir_rel = 'fonts/' . $key;
		$replace = array();
		foreach ( array_unique( $m[1] ) as $font_url ) {
			$name = sanitize_file_name( basename( (string) wp_parse_url( $font_url, PHP_URL_PATH ) ) );
			$r    = wp_safe_remote_get( $font_url, array( 'timeout' => 15 ) );
			$body = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_body( $r );
			if ( '' === $body || strlen( $body ) > 3145728 || 200 !== wp_remote_retrieve_response_code( $r ) ) {
				return; // All-or-nothing: keep using Google until every file is local.
			}
			$rel = $dir_rel . '/' . substr( md5( $font_url ), 0, 8 ) . '-' . $name;
			if ( ! WPSS_FS::put( WPSS_CACHE_DIR . '/' . $rel, $body ) ) {
				return;
			}
			$local = WPSS_FS::cache_url( $rel );
			if ( ! $local ) {
				return;
			}
			$replace[ $font_url ] = (string) wp_parse_url( $local, PHP_URL_PATH );
		}
		$css_rel = $dir_rel . '/fonts.css';
		if ( ! WPSS_FS::put( WPSS_CACHE_DIR . '/' . $css_rel, strtr( $css, $replace ) ) ) {
			return;
		}
		$map         = get_option( self::MAP, array() );
		$map         = is_array( $map ) ? $map : array();
		$map[ $key ] = $css_rel;
		update_option( self::MAP, $map, true );
		WPSS_Logger::log( 'Google Font stored locally: ' . $src );
		WPSS_Page_Cache::queue_purge_all( 'Local fonts ready' );
	}

	/**
	 * Preconnect (only when fonts are still loaded from Google).
	 *
	 * @param array  $urls Hints.
	 * @param string $type Relation.
	 */
	public static function hints( $urls, $type ) {
		if ( 'preconnect' !== $type || ! WPSS_Settings::get( 'font_preconnect' ) || WPSS_Settings::get( 'font_local' ) || WPSS_Settings::get( 'font_disable' ) || ! WPSS_Context::optimize() ) {
			return $urls;
		}
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
		return $urls;
	}
}
