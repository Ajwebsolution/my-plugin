<?php
/**
 * Plugin lifecycle: boot, activation, deactivation, upgrades.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Plugin {

	/**
	 * Wire all modules.
	 */
	public static function init() {
		load_plugin_textdomain( 'steady-speed', false, dirname( plugin_basename( WPSS_FILE ) ) . '/languages' );
		self::maybe_upgrade();

		WPSS_Logger::init();
		WPSS_Analysis::init();
		WPSS_Invalidation::init();
		WPSS_Page_Cache::init();
		WPSS_Fonts::init();
		WPSS_Assets::init();
		WPSS_Images::init();
		WPSS_HTML::init();
		WPSS_Monitor::init();
		WPSS_Cron::init();

		if ( is_admin() ) {
			WPSS_Admin::init();
		}
		add_action( 'admin_bar_menu', array( 'WPSS_Admin', 'admin_bar' ), 100 );
		// Settings can change from anywhere (admin, WP-CLI, migrations): always apply + rebuild lazily.
		add_action( 'update_option_' . WPSS_Settings::OPTION, array( 'WPSS_Admin', 'settings_changed' ), 10, 2 );
		add_action( 'add_option_' . WPSS_Settings::OPTION, array( 'WPSS_Admin', 'settings_changed' ), 10, 2 );
	}

	/**
	 * Activation.
	 */
	public static function activate() {
		self::install();
		WPSS_Cron::schedule();
		WPSS_Browser_Cache::sync();
	}

	/**
	 * Create table, default options and cache directories.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = WPSS_Page_Cache::table();
		$charset = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			cache_key char(32) NOT NULL,
			dep varchar(191) NOT NULL,
			url varchar(2000) NOT NULL DEFAULT '',
			created int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY cache_key (cache_key),
			KEY dep (dep)
		) {$charset};"
		);

		$previous = get_option( 'wpss_db_version' );
		add_option( WPSS_Settings::OPTION, WPSS_Settings::defaults() );
		if ( $previous && version_compare( (string) $previous, '2', '<' ) ) {
			self::migrate_1_to_2();
		}
		update_option( 'wpss_db_version', WPSS_DB_VERSION, true );
		WPSS_FS::ensure_dirs();
	}

	/**
	 * 1.0 → 1.1: keep every existing value, add the new keys with their (off / Safe) defaults and
	 * derive the preset selectors from what is actually configured. Cached pages and optimized
	 * files are kept; nothing is purged.
	 */
	private static function migrate_1_to_2() {
		$saved = get_option( WPSS_Settings::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$all   = array_merge( WPSS_Settings::defaults(), $saved );
		$all['img_mode']  = WPSS_Settings::matching_preset( $all, WPSS_Settings::img_presets() );
		$all['perf_mode'] = WPSS_Settings::matching_preset( $all, WPSS_Settings::presets() );
		// Written directly (no sanitize/preset logic, no "settings changed" purge side effects).
		$had = remove_action( 'update_option_' . WPSS_Settings::OPTION, array( 'WPSS_Admin', 'settings_changed' ), 10 );
		update_option( WPSS_Settings::OPTION, $all );
		if ( $had ) {
			add_action( 'update_option_' . WPSS_Settings::OPTION, array( 'WPSS_Admin', 'settings_changed' ), 10, 2 );
		}
		WPSS_Settings::flush();
		// Existing automatic exclusions become temporary protections (retried in 7 days).
		$auto = get_option( 'wpss_auto_exclusions', array() );
		if ( is_array( $auto ) ) {
			foreach ( $auto as $k => $info ) {
				if ( is_array( $info ) && ! isset( $info['until'] ) ) {
					$auto[ $k ]['until']  = time() + 7 * DAY_IN_SECONDS;
					$auto[ $k ]['strike'] = 1;
				}
			}
			update_option( 'wpss_auto_exclusions', $auto, true );
		}
		WPSS_Logger::log( 'Upgraded to Steady Speed 1.1 – existing settings, cache and exclusions preserved.' );
	}

	/**
	 * Run install again when the schema version changes.
	 */
	private static function maybe_upgrade() {
		if ( WPSS_DB_VERSION !== get_option( 'wpss_db_version' ) ) {
			self::install();
		}
	}

	/**
	 * Deactivation: stop cron, remove server rules, drop cached HTML (keep settings).
	 */
	public static function deactivate() {
		WPSS_Cron::unschedule();
		WPSS_Browser_Cache::remove_root_rules();
		WPSS_Page_Cache::purge_all( 'Plugin deactivated' );
	}
}
