<?php
/**
 * Smart page cache.
 *
 * - Served at plugin load (before the theme and most plugins run).
 * - Each page stores a meta file listing the source assets (path => mtime-size) and the optimized
 *   files it references. At serve time, a changed source or a missing optimized file makes the page
 *   a MISS, so a changed CSS/JS file only regenerates the pages that actually use it.
 * - Content dependencies (post:ID, term:ID, menu:ID, sidebar, listing:type …) live in a DB table
 *   and drive targeted invalidation.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Page_Cache {

	/** @var string|null Cache key for this request, when cacheable. */
	private static $key = null;

	/** @var string Normalized URL for this request. */
	private static $url = '';

	/** @var array Collected dependencies. */
	private static $deps = array();

	/** @var bool Output buffer saw a flush (partial output) – never store. */
	private static $flushed = false;

	/** @var array Invalidation queue. */
	private static $queue = array(
		'all'  => '',
		'deps' => array(),
		'urls' => array(),
	);

	/** @var bool */
	private static $queue_hooked = false;

	/**
	 * Dependency table name.
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wpss_deps';
	}

	/**
	 * Pages directory.
	 */
	public static function dir() {
		return WPSS_CACHE_DIR . '/pages';
	}

	/**
	 * Paths for a key: [html, meta].
	 *
	 * @param string $key Key.
	 */
	private static function paths( $key ) {
		$base = self::dir() . '/' . substr( $key, 0, 2 ) . '/' . $key;
		return array( $base . '.html', $base . '.php' );
	}

	/**
	 * Marker file touched on every invalidation (race guard).
	 */
	private static function marker() {
		return WPSS_CACHE_DIR . '/last-invalidation.txt';
	}

	/**
	 * Cookies that mean "personalised response – do not serve or store".
	 */
	private static function bypass_cookies() {
		$list = array( 'wordpress_logged_in_', 'wp-postpass_', 'comment_author_', 'woocommerce_items_in_cart', 'woocommerce_cart_hash', 'wp_woocommerce_session_', 'edd_items_in_cart', 'wpss_nocache' );
		return function_exists( 'apply_filters' ) ? (array) apply_filters( 'wpss_bypass_cookies', $list ) : $list;
	}

	/**
	 * @return string|false Matching cookie prefix.
	 */
	private static function has_bypass_cookie() {
		if ( empty( $_COOKIE ) ) {
			return false;
		}
		foreach ( array_keys( $_COOKIE ) as $name ) {
			foreach ( self::bypass_cookies() as $prefix ) {
				if ( 0 === strpos( (string) $name, $prefix ) ) {
					return $prefix;
				}
			}
		}
		return false;
	}

	/**
	 * Device variant.
	 */
	public static function variant() {
		return ( WPSS_Settings::get( 'cache_mobile' ) && wp_is_mobile() ) ? 'm' : 'd';
	}

	/**
	 * Normalized URL of the request, or false when it may not be cached (foreign host, remaining query).
	 *
	 * @return string|false
	 */
	public static function normalize_request() {
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput -- compared and hashed only.
		$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		// phpcs:enable
		if ( '' === $host || WPSS_FS::home_host() !== $host ) {
			return false;
		}
		$path  = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
		if ( '' === $path || false !== strpos( $path, '..' ) ) {
			return false;
		}
		if ( '' !== $query ) {
			parse_str( $query, $args );
			foreach ( WPSS_Settings::lines( 'cache_ignore_qs' ) as $ignored ) {
				if ( '*' === substr( $ignored, -1 ) ) {
					foreach ( array_keys( $args ) as $k ) {
						if ( 0 === strpos( (string) $k, substr( $ignored, 0, -1 ) ) ) {
							unset( $args[ $k ] );
						}
					}
				} else {
					unset( $args[ $ignored ] );
				}
			}
			if ( ! empty( $args ) ) {
				return false;
			}
		}
		return ( is_ssl() ? 'https' : 'http' ) . '://' . $host . strtolower( $path );
	}

	/**
	 * Cache key.
	 *
	 * @param string $variant d|m.
	 * @param string $url     Normalized URL.
	 */
	public static function key( $variant, $url ) {
		return md5( $variant . '|' . $url );
	}

	/**
	 * Cheap request-level checks shared by serve and store.
	 */
	private static function can_serve() {
		if ( ! WPSS_Settings::get( 'page_cache' ) || ( defined( 'WP_USE_THEMES' ) && ! WP_USE_THEMES ) ) {
			return false;
		}
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
			return false;
		}
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return false;
		}
		if ( false !== self::has_bypass_cookie() || WPSS_Context::is_editor_request() ) {
			return false;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		foreach ( array( '/wp-json/', '/wp-admin', '/wp-login.php', '/wp-register.php', '/wp-cron.php', '/xmlrpc.php', '/wp-comments-post.php', '/wp-signup.php', '/wp-activate.php', '/wp-trackback.php', 'sitemap', '.xml', '.txt', '/feed/' ) as $never ) {
			if ( false !== stripos( $uri, $never ) ) {
				return false;
			}
		}
		if ( WPSS_Context::url_in_list( WPSS_Settings::lines( 'never_cache_urls' ) ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Serve a cached copy if one exists and is fresh. Called while the plugin file loads.
	 */
	public static function maybe_serve() {
		if ( WPSS_Settings::safe_mode() || ! self::can_serve() ) {
			return;
		}
		$url = self::normalize_request();
		if ( false === $url ) {
			return;
		}
		$key                 = self::key( self::variant(), $url );
		list( $html, $meta ) = self::paths( $key );
		if ( ! is_file( $html ) || ! is_file( $meta ) ) {
			return;
		}
		$data = self::read_meta( $meta );
		$ttl  = (int) WPSS_Settings::get( 'cache_ttl' );
		if ( ! $data || ( (int) $data['created'] + $ttl ) < time() || ! self::assets_fresh( $data ) ) {
			return; // Regenerated (and overwritten) by this request.
		}

		$age = max( 0, time() - (int) $data['created'] );
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset', 'UTF-8' ) );
			header( 'X-WPSS-Cache: HIT' );
			header( 'Age: ' . $age );
			header( 'Vary: Accept-Encoding, Cookie' );
		}
		WPSS_Debug::count( 'hit' );
		self::log_hit( $url );
		if ( 'HEAD' !== strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			readfile( $html ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		}
		exit;
	}

	/**
	 * Append a cache hit to a small log (aggregated hourly into "popular pages" for the warmup).
	 * One append per hit, no database access; skipped once the log is large.
	 *
	 * @param string $url URL.
	 */
	private static function log_hit( $url ) {
		if ( isset( $_SERVER['HTTP_X_WPSS_WARMUP'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated
			return;
		}
		$file = WPSS_CACHE_DIR . '/data/hits.log';
		if ( is_file( $file ) && filesize( $file ) > 2097152 ) {
			return;
		}
		@file_put_contents( $file, $url . "\n", FILE_APPEND | LOCK_EX ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}

	/**
	 * @param string $file Meta file.
	 * @return array|false
	 */
	private static function read_meta( $file ) {
		$raw = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.
		if ( ! is_string( $raw ) ) {
			return false;
		}
		$pos = strpos( $raw, '?>' );
		$data = json_decode( false === $pos ? $raw : substr( $raw, $pos + 2 ), true );
		return is_array( $data ) && isset( $data['created'] ) ? $data : false;
	}

	/**
	 * Serve-time freshness: every original asset unchanged and every optimized file still present.
	 *
	 * @param array $data Meta.
	 */
	private static function assets_fresh( $data ) {
		if ( ! empty( $data['sources'] ) ) {
			foreach ( $data['sources'] as $path => $sig ) {
				$mtime = @filemtime( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				if ( false === $mtime || $sig !== $mtime . '-' . @filesize( $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					return false;
				}
			}
		}
		if ( ! empty( $data['outputs'] ) ) {
			foreach ( $data['outputs'] as $rel ) {
				if ( ! is_file( WPSS_CACHE_DIR . '/' . $rel ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/* =====================================================================
	 * Generation
	 * =================================================================== */

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start' ), 1 );
	}

	/**
	 * Why can't this (fully resolved) request be stored?
	 *
	 * @return string Empty when cacheable.
	 */
	private static function bypass_reason() {
		if ( WPSS_Settings::safe_mode() ) {
			return 'Emergency Safe Mode';
		}
		if ( ! self::can_serve() ) {
			return 'Request type / cookie / excluded URL';
		}
		if ( is_user_logged_in() ) {
			return 'Logged-in user';
		}
		if ( is_search() || is_404() || is_feed() || is_preview() || is_trackback() || is_robots() || is_embed() ) {
			return 'Search, 404, feed or preview';
		}
		if ( is_singular() && post_password_required() ) {
			return 'Password protected';
		}
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
			return 'WooCommerce cart/checkout/account';
		}
		if ( defined( 'DONOTCACHEPAGE' ) && DONOTCACHEPAGE ) {
			return 'DONOTCACHEPAGE';
		}
		if ( false === self::normalize_request() ) {
			return 'Query string or foreign host';
		}
		return (string) apply_filters( 'wpss_cache_bypass_reason', '' );
	}

	/**
	 * template_redirect: decide, start the buffer.
	 */
	public static function start() {
		$reason = self::bypass_reason();
		if ( '' === $reason ) {
			self::$url = self::normalize_request();
			self::$key = self::key( self::variant(), self::$url );
			if ( ! headers_sent() ) {
				header( 'X-WPSS-Cache: MISS' );
			}
			WPSS_Debug::note( 'Page cache', 'MISS (will be stored)' );
			WPSS_Debug::count( 'miss' );
		} else {
			WPSS_Debug::note( 'Page cache', 'Bypass – ' . $reason );
		}

		if ( null !== self::$key || WPSS_Context::optimize() || WPSS_Debug::on() ) {
			ob_start( array( __CLASS__, 'ob_callback' ) );
		}
	}

	/**
	 * Record a dependency of the page being generated.
	 *
	 * @param string $dep Dependency id.
	 */
	public static function add_dep( $dep ) {
		if ( null !== self::$key && count( self::$deps ) < 300 ) {
			self::$deps[ (string) $dep ] = true;
		}
	}

	/**
	 * Output buffer callback.
	 *
	 * @param string $buffer Buffer.
	 * @param int    $phase  Phase.
	 */
	public static function ob_callback( $buffer, $phase ) {
		if ( ! ( $phase & PHP_OUTPUT_HANDLER_FINAL ) ) {
			if ( $phase & ( PHP_OUTPUT_HANDLER_FLUSH | PHP_OUTPUT_HANDLER_WRITE ) ) {
				self::$flushed = true; // Partial output already sent: pass through untouched.
			}
			return $buffer;
		}
		if ( self::$flushed || ! is_string( $buffer ) || '' === $buffer ) {
			return $buffer;
		}
		try {
			$html = WPSS_HTML::process( $buffer );
			if ( null !== self::$key && self::should_store( $html ) ) {
				self::store( $html );
			}
			return $html;
		} catch ( Throwable $e ) {
			WPSS_Logger::log( 'Output processing failed, original served: ' . $e->getMessage(), 'error' );
			return $buffer;
		}
	}

	/**
	 * Final checks on the generated response.
	 *
	 * @param string $html HTML.
	 */
	private static function should_store( $html ) {
		if ( 200 !== http_response_code() || ( defined( 'DONOTCACHEPAGE' ) && DONOTCACHEPAGE ) ) {
			return false;
		}
		foreach ( headers_list() as $h ) {
			if ( 0 === stripos( $h, 'set-cookie:' ) ) {
				return false;
			}
			if ( 0 === stripos( $h, 'content-type:' ) && false === stripos( $h, 'text/html' ) ) {
				return false;
			}
		}
		if ( false === stripos( $html, '</html>' ) ) {
			return false;
		}
		if ( WPSS_Settings::get( 'cache_skip_nonce' ) && preg_match( '/<input[^>]+name=["\'][^"\']*nonce[^"\']*["\']/i', $html ) ) {
			WPSS_Logger::log( 'Not cached (form with nonce): ' . self::$url, 'debug' );
			return false;
		}
		// Race guard: an invalidation happened while this page was being generated.
		$marker = self::marker();
		if ( is_file( $marker ) ) {
			$last = (float) file_get_contents( $marker ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$t0   = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : 0.0; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			if ( $last >= $t0 ) {
				return false;
			}
		}
		return (bool) apply_filters( 'wpss_should_store_page', true, $html, self::$url );
	}

	/**
	 * Write the page, its meta and its dependency rows.
	 *
	 * @param string $html HTML.
	 */
	private static function store( $html ) {
		global $wpdb;
		if ( ! WPSS_FS::ready() ) {
			return;
		}
		list( $file, $meta_file ) = self::paths( self::$key );
		$manifest = WPSS_Assets::manifest();
		$meta     = array(
			'url'     => self::$url,
			'created' => time(),
			'sources' => $manifest['sources'],
			'outputs' => $manifest['outputs'],
		);
		$stamp = "\n<!-- Cached by Steady Speed on " . gmdate( 'Y-m-d H:i:s' ) . ' UTC -->';
		if ( ! WPSS_FS::put( $file, $html . $stamp ) || ! WPSS_FS::put( $meta_file, '<?php exit; ?>' . wp_json_encode( $meta ) ) ) {
			return;
		}

		$table = self::table();
		$now   = time();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE cache_key = %s", self::$key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
		$rows   = array( '(%s, %s, %s, %d)' );
		$values = array( self::$key, 'global', self::$url, $now );
		foreach ( array_keys( self::$deps ) as $dep ) {
			$rows[]   = '(%s, %s, %s, %d)';
			array_push( $values, self::$key, substr( $dep, 0, 191 ), '', $now );
		}
		$sql = "INSERT INTO {$table} (cache_key, dep, url, created) VALUES " . implode( ',', $rows );
		$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery

		WPSS_Logger::log( sprintf( 'Cached %s (%d deps)', self::$url, count( self::$deps ) ), 'debug' );
		if ( WPSS_Analysis::enabled() ) {
			WPSS_Analysis::note_page( WPSS_Analysis::path_key( self::$url ) );
		}
		delete_transient( 'wpss_cache_stats' );
	}

	/* =====================================================================
	 * Invalidation (queued, processed once at shutdown)
	 * =================================================================== */

	/**
	 * Hook the queue processor once.
	 */
	private static function hook_queue() {
		if ( ! self::$queue_hooked ) {
			self::$queue_hooked = true;
			add_action( 'shutdown', array( __CLASS__, 'process_queue' ), 0 );
		}
	}

	/**
	 * @param string $dep    Dependency id.
	 * @param string $reason Reason.
	 */
	public static function queue( $dep, $reason ) {
		self::$queue['deps'][ $dep ] = $reason;
		self::hook_queue();
	}

	/**
	 * @param string $url    URL.
	 * @param string $reason Reason.
	 */
	public static function queue_url( $url, $reason ) {
		if ( is_string( $url ) && '' !== $url ) {
			self::$queue['urls'][ $url ] = $reason;
			self::hook_queue();
		}
	}

	/**
	 * @param string $reason Reason.
	 */
	public static function queue_purge_all( $reason ) {
		if ( '' === self::$queue['all'] ) {
			self::$queue['all'] = $reason;
		}
		self::hook_queue();
	}

	/**
	 * Execute queued invalidations.
	 */
	public static function process_queue() {
		$q           = self::$queue;
		self::$queue = array(
			'all'  => '',
			'deps' => array(),
			'urls' => array(),
		);
		if ( '' !== $q['all'] ) {
			self::purge_all( $q['all'] );
			return;
		}
		foreach ( $q['deps'] as $dep => $reason ) {
			self::delete_keys( self::keys_for_dep( $dep ), $reason . ' [' . $dep . ']' );
		}
		foreach ( $q['urls'] as $url => $reason ) {
			self::delete_keys( self::keys_for_url( $url ), $reason . ' [' . $url . ']' );
		}
	}

	/**
	 * Cache keys depending on $dep.
	 *
	 * @param string $dep Dependency.
	 * @return string[]
	 */
	public static function keys_for_dep( $dep ) {
		global $wpdb;
		$table = self::table();
		return (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT cache_key FROM {$table} WHERE dep = %s", $dep ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * All variant keys for a URL.
	 *
	 * @param string $url URL.
	 * @return string[]
	 */
	public static function keys_for_url( $url ) {
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) ) {
			return array();
		}
		$host = strtolower( $parts['host'] ) . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
		$path = strtolower( isset( $parts['path'] ) ? $parts['path'] : '/' );
		$keys = array();
		foreach ( array( 'http', 'https' ) as $scheme ) {
			foreach ( array( 'd', 'm' ) as $v ) {
				$keys[] = self::key( $v, $scheme . '://' . $host . $path );
			}
		}
		return $keys;
	}

	/**
	 * Delete cached pages by key.
	 *
	 * @param string[] $keys   Keys.
	 * @param string   $reason Reason.
	 */
	public static function delete_keys( $keys, $reason, $warm = true ) {
		global $wpdb;
		$keys = array_values( array_unique( array_filter( (array) $keys, static function ( $k ) {
			return is_string( $k ) && preg_match( '/^[a-f0-9]{32}$/', $k );
		} ) ) );
		self::touch_marker();
		if ( empty( $keys ) ) {
			return 0;
		}
		$deleted = 0;
		foreach ( $keys as $key ) {
			foreach ( self::paths( $key ) as $f ) {
				if ( is_file( $f ) ) {
					wp_delete_file( $f );
					$deleted += '.html' === substr( $f, -5 ) ? 1 : 0;
				}
			}
		}
		$table = self::table();
		if ( $warm && WPSS_Settings::get( 'warm' ) ) {
			$urls = array();
			foreach ( array_chunk( $keys, 200 ) as $chunk ) {
				$in   = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
				$urls = array_merge( $urls, (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT url FROM {$table} WHERE dep = 'global' AND cache_key IN ({$in})", $chunk ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
			}
			if ( $urls ) {
				WPSS_Warmup::add( $urls, WPSS_Warmup::PRIO_CHANGED );
			}
		}
		foreach ( array_chunk( $keys, 200 ) as $chunk ) {
			$in = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE cache_key IN ({$in})", $chunk ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
		}
		if ( $deleted ) {
			WPSS_Logger::log( sprintf( 'Invalidated %d cached page(s): %s', $deleted, $reason ) );
			delete_transient( 'wpss_cache_stats' );
		}
		return $deleted;
	}

	/**
	 * Drop all cached HTML (optimized assets are kept: they are content-addressed).
	 *
	 * @param string $reason Reason.
	 */
	public static function purge_all( $reason ) {
		global $wpdb;
		self::touch_marker();
		$dir = self::dir();
		if ( is_dir( $dir ) && WPSS_FS::ready() ) {
			$trash = WPSS_CACHE_DIR . '/trash-' . time() . '-' . wp_rand( 1000, 9999 );
			if ( ! WPSS_FS::move( $dir, $trash ) ) {
				WPSS_FS::rrmdir( $dir );
			}
		}
		WPSS_FS::ensure_dirs();
		$table = self::table();
		$wpdb->query( "DELETE FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery
		WPSS_Logger::log( 'Full page cache purge: ' . $reason );
		delete_transient( 'wpss_cache_stats' );
		if ( WPSS_Settings::get( 'warm' ) && WPSS_Settings::get( 'page_cache' ) ) {
			WPSS_Warmup::after_purge();
		}
	}

	/**
	 * Mark "an invalidation happened now".
	 */
	private static function touch_marker() {
		WPSS_FS::put( self::marker(), sprintf( '%.4F', microtime( true ) ) );
	}

	/**
	 * Cached pages count/size (cached 5 min).
	 *
	 * @return array{pages:int,size:int}
	 */
	public static function stats() {
		$s = get_transient( 'wpss_cache_stats' );
		if ( is_array( $s ) ) {
			return $s;
		}
		list( $pages, $size ) = WPSS_FS::dir_stats( self::dir(), '/\.html$/' );
		$s                    = array(
			'pages' => $pages,
			'size'  => $size,
		);
		set_transient( 'wpss_cache_stats', $s, 5 * MINUTE_IN_SECONDS );
		return $s;
	}
}
