<?php
/**
 * Final HTML processing and the tiny client-side error reporter.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML pass (images, debug report) + monitor script.
 */
class WPSS_HTML {

	public static function init() {
		// Priority 1: before wp_print_styles (8) and wp_print_head_scripts (9), so
		// load failures of any optimized asset are observed.
		add_action( 'wp_head', array( __CLASS__, 'monitor_script' ), 1 );
	}

	/**
	 * Print the reporter. It only acts on assets this plugin changed (data-wpss-orig / data-wpss-opt).
	 */
	public static function monitor_script() {
		if ( ! WPSS_Context::optimize() || WPSS_Analysis::is_analysis_request() ) {
			return;
		}
		$errors = (bool) WPSS_Settings::get( 'error_detect' );
		$rate   = WPSS_Settings::get( 'cwv' ) && ! is_user_logged_in() ? (int) WPSS_Settings::get( 'cwv_rate' ) : 0;
		if ( ! $errors && ! $rate ) {
			return;
		}
		$cfg = 'window.WPSS=' . wp_json_encode(
			array(
				'u' => esc_url_raw( rest_url( 'wpss/v1/report' ) ),
				'e' => $errors ? 1 : 0,
				'r' => $rate,
			)
		) . ';';
		wp_print_inline_script_tag( $cfg . self::reporter_js(), array( 'id' => 'wpss-monitor' ) );
	}

	/**
	 * Reporter source. Behaviour:
	 *  - an optimized <link>/<script> fails to load → the original file(s) are injected immediately
	 *    (visitor sees the original site) and the failure is reported;
	 *  - a JS error thrown inside a minified file → reported with the original URL;
	 *  - "x is not defined / not a function" on a page with deferred/delayed scripts → page reported;
	 *  - 10 s after load, a visible uninitialised Owl/Swiper carousel on an optimized page → page reported.
	 */
	public static function reporter_js() {
		return <<<'JS'
(function(){try{
var W=window.WPSS||{},sent={},failed=0;
if(W.e){
function base(u){return String(u||"").split("#")[0].split("?")[0];}
function send(t,o,m){var k=t+"|"+o+"|"+m;if(sent[k]||!W.u)return;sent[k]=1;
try{var b=JSON.stringify({type:t,orig:String(o||"").slice(0,4000),msg:String(m||"").slice(0,200),page:location.origin+location.pathname});
if(navigator.sendBeacon){navigator.sendBeacon(W.u,new Blob([b],{type:"text/plain"}));}
else if(window.fetch){fetch(W.u,{method:"POST",body:b,keepalive:true,credentials:"omit"});}}catch(e){}}
function restore(el,orig){var urls=orig.split(" "),ref=el;
for(var i=0;i<urls.length;i++){if(!urls[i])continue;var n;
if(el.tagName==="LINK"){n=document.createElement("link");n.rel="stylesheet";n.href=urls[i];var md=el.getAttribute("data-wpss-media")||el.media;if(md&&md!=="print")n.media=md;}
else{n=document.createElement("script");n.src=urls[i];n.async=false;}
n.setAttribute("data-wpss-restored","1");ref.parentNode.insertBefore(n,ref.nextSibling);ref=n;}}
addEventListener("error",function(e){try{var t=e.target;
if(t&&t!==window&&t.getAttribute){var o=t.getAttribute("data-wpss-orig");
if(o&&!t.getAttribute("data-wpss-restored")){failed=1;restore(t,o);send("asset",o,"load failed");}return;}
if(failed)return;
var f=base(e.filename);if(!f)return;
var s=document.querySelectorAll("script[data-wpss-orig]");
for(var i=0;i<s.length;i++){var src=base(s[i].src||s[i].getAttribute("data-wpss-src"));
if(src&&(src===f||f.indexOf(src)===0)){send("js",s[i].getAttribute("data-wpss-orig"),e.message);return;}}
if(f===base(location.href)&&/not defined|is not a function/i.test(e.message||"")&&document.querySelector('script[data-wpss-opt*="defer"],script[data-wpss-opt*="delay"]')){send("inline","",e.message);}
}catch(x){}},true);
addEventListener("load",function(){setTimeout(function(){try{
if(document.visibilityState&&document.visibilityState!=="visible")return;
if(!document.querySelector("[data-wpss-opt]"))return;
var bad=0,i,l,r;
function vis(el){r=el.getBoundingClientRect();return r.width>0&&r.height>0;}
l=document.querySelectorAll(".owl-carousel");for(i=0;i<l.length;i++){if(vis(l[i])&&!/\bowl-loaded\b/.test(l[i].className))bad++;}
l=document.querySelectorAll(".swiper,.swiper-container");for(i=0;i<l.length;i++){var c=l[i].className;
if(vis(l[i])&&!l[i].swiper&&!/swiper-(container-)?initialized/.test(c)&&l[i].querySelector(".swiper-slide"))bad++;}
if(bad)send("slider","",bad+" carousel(s) not initialized");}catch(x){}},10000);});
}
if(W.r&&W.u&&Math.random()*100<W.r&&window.PerformanceObserver&&navigator.sendBeacon){(function(){
var v={lcp:0,cls:0,inp:0},sv=0,last=0,first=0,done=0;
function po(t,cb,o){try{var ob=new PerformanceObserver(function(l){l.getEntries().forEach(cb)});var c={type:t,buffered:true};if(o)for(var k in o)c[k]=o[k];ob.observe(c)}catch(e){}}
po("largest-contentful-paint",function(e){v.lcp=e.startTime});
po("layout-shift",function(e){if(e.hadRecentInput)return;if(sv&&e.startTime-last<1000&&e.startTime-first<5000){sv+=e.value}else{sv=e.value;first=e.startTime}last=e.startTime;if(sv>v.cls)v.cls=sv});
po("event",function(e){if(e.interactionId&&e.duration>v.inp)v.inp=e.duration},{durationThreshold:40});
function flush(){if(done||!v.lcp)return;done=1;try{navigator.sendBeacon(W.u,new Blob([JSON.stringify({type:"cwv",lcp:Math.round(v.lcp),cls:Math.round(v.cls*1000)/1000,inp:Math.round(v.inp),dev:innerWidth<768?"m":"d",page:location.pathname})],{type:"text/plain"}))}catch(e){}}
addEventListener("visibilitychange",function(){if(document.visibilityState==="hidden")flush()});addEventListener("pagehide",flush);
})();}
}catch(e){}})();
JS;
	}

	/**
	 * Transform the final HTML. Never throws: failures return the input unchanged.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public static function process( $html ) {
		if ( WPSS_Context::optimize() ) {
			$analysis = WPSS_Analysis::is_analysis_request();
			// Order matters: images decide the LCP resource, CSS delivery decides what is async,
			// third-party delay decides which origins are deferred, the preload manager uses all three.
			$steps = array(
				'Image pass'        => array( 'WPSS_Images', 'process' ),
				'CSS delivery'      => array( 'WPSS_CSS_Delivery', 'process' ),
				'Third-party delay' => array( 'WPSS_ThirdParty', 'process' ),
				'Preload manager'   => array( 'WPSS_Preload', 'process' ),
			);
			foreach ( $steps as $label => $cb ) {
				try {
					$out = call_user_func( $cb, $html );
					if ( is_string( $out ) && '' !== $out ) {
						$html = $out;
					}
				} catch ( Throwable $e ) {
					WPSS_Logger::log( $label . ' skipped: ' . $e->getMessage(), 'error' );
				}
			}
			if ( $analysis ) {
				// The analyzer runs without scripts; <noscript> content would not be shown to real
				// visitors (and would fire tracking pixels), so it is removed from the analysis view.
				$html = (string) preg_replace( '#<noscript\b.*?</noscript>#is', '', $html );
				// Scripts never run in the analyzer's sandboxed frame. Make them inert (no requests,
				// no console noise) but keep their text: class names in inline code/JSON still count
				// as "used" for unused-CSS safety.
				$html = (string) preg_replace_callback(
					'#<script\b([^>]*)>#i',
					static function ( $m ) {
						$a = preg_replace( '/\s(type|src|async|defer)(\s*=\s*(["\'])[^"\']*\3|\s*=\s*[^\s>]+)?(?=[\s>\/]|$)/i', '', $m[1] );
						return '<script type="text/wpss-inert"' . $a . '>';
					},
					$html
				);
				if ( ! headers_sent() ) {
					header_remove( 'X-Frame-Options' );
					header( 'X-Robots-Tag: noindex, nofollow' );
				}
			} elseif ( ! is_user_logged_in() ) {
				WPSS_Stats::save_report( WPSS_Analysis::current_path(), WPSS_Page_Cache::variant() );
			}
		}
		try {
			$html = WPSS_Debug::inject( $html );
		} catch ( Throwable $e ) {
			WPSS_Logger::log( 'Debug report failed: ' . $e->getMessage(), 'error' );
		}
		return $html;
	}
}
