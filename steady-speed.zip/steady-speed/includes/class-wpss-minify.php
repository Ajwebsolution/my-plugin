<?php
/**
 * Conservative tokenizing minifiers. Any state the tokenizer does not fully understand
 * (unterminated string/comment/regex/template) returns false, and the caller keeps the original file.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Minify {

	/* =====================================================================
	 * CSS
	 * =================================================================== */

	/**
	 * Minify CSS. Only removes comments and whitespace; never rewrites values or selectors.
	 *
	 * @param string $css CSS.
	 * @return string|false
	 */
	public static function css( $css ) {
		$css = self::strip_bom( (string) $css );
		$len = strlen( $css );
		$out = '';
		$ws  = false; // Pending whitespace.
		$i   = 0;
		// Whitespace next to these characters is never significant in CSS.
		$tight = '{};,';
		$depth  = 0;     // Parenthesis depth: commas inside functions keep their spacing.
		$custom = false; // Inside a custom property value: whitespace is part of the value.

		while ( $i < $len ) {
			$c = $css[ $i ];

			// Strings.
			if ( '"' === $c || "'" === $c ) {
				$end = self::css_string_end( $css, $i, $len );
				if ( false === $end ) {
					return false;
				}
				$out .= self::css_ws( $out, $ws, $c, $tight, $custom, $depth );
				$ws   = false;
				$out .= substr( $css, $i, $end - $i + 1 );
				$i    = $end + 1;
				continue;
			}

			// Comments.
			if ( '/' === $c && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return false;
				}
				if ( $i + 2 < $len && '!' === $css[ $i + 2 ] ) {
					$out .= self::css_ws( $out, $ws, '/', $tight, $custom, $depth ) . substr( $css, $i, $end + 2 - $i ) . "\n";
					$ws   = false;
				} else {
					$ws = true; // A comment separates tokens like whitespace does.
				}
				$i = $end + 2;
				continue;
			}

			// Whitespace.
			if ( ' ' === $c || "\t" === $c || "\n" === $c || "\r" === $c || "\f" === $c ) {
				$ws = true;
				++$i;
				continue;
			}

			// Escapes outside strings.
			if ( '\\' === $c ) {
				$out .= self::css_ws( $out, $ws, $c, $tight, $custom, $depth ) . substr( $css, $i, 2 );
				$ws   = false;
				$i   += 2;
				continue;
			}

			// Unquoted url(...) is copied verbatim.
			if ( '(' === $c && preg_match( '/url$/i', substr( $out, -3 ) ) && ! $ws ) {
				$j = $i + 1;
				while ( $j < $len && ctype_space( $css[ $j ] ) ) {
					++$j;
				}
				if ( $j < $len && '"' !== $css[ $j ] && "'" !== $css[ $j ] ) {
					$end = strpos( $css, ')', $j );
					if ( false === $end ) {
						return false;
					}
					$out .= '(' . trim( substr( $css, $i + 1, $end - $i - 1 ) ) . ')';
					$i    = $end + 1;
					continue;
				}
			}

			$out .= self::css_ws( $out, $ws, $c, $tight, $custom, $depth ) . $c;
			$ws   = false;
			++$i;
			if ( '(' === $c ) {
				++$depth;
			} elseif ( ')' === $c && $depth > 0 ) {
				--$depth;
			} elseif ( ':' === $c && 0 === $depth && preg_match( '/(?:^|[{;])--[A-Za-z0-9_\\-]*:$/', substr( $out, -200 ) ) ) {
				$custom = true;
			} elseif ( ( ';' === $c || '}' === $c ) && 0 === $depth ) {
				$custom = false;
			}
		}
		return trim( $out );
	}

	/**
	 * Emit a pending space if significant.
	 *
	 * @param string $out   Output so far.
	 * @param bool   $ws    Pending whitespace.
	 * @param string $next  Next char.
	 * @param string $tight Chars that make whitespace insignificant.
	 */
	private static function css_ws( $out, $ws, $next, $tight, $custom = false, $depth = 0 ) {
		if ( ! $ws || '' === $out ) {
			return '';
		}
		$prev = substr( $out, -1 );
		if ( $custom ) {
			// Custom property values are token streams: keep one space everywhere except the
			// trailing whitespace. An empty value keeps its space ("--x: ;").
			if ( ( ';' === $next || '}' === $next ) && ':' !== $prev ) {
				return '';
			}
			return ' ';
		}
		if ( $depth > 0 && ( ',' === $prev || ',' === $next ) ) {
			return ' ';
		}
		if ( false !== strpos( $tight, $prev ) || false !== strpos( $tight, $next ) || "\n" === $prev ) {
			return '';
		}
		return ' ';
	}

	/**
	 * End offset of a CSS string starting at $i, or false.
	 */
	private static function css_string_end( $s, $i, $len ) {
		$q = $s[ $i ];
		for ( $j = $i + 1; $j < $len; $j++ ) {
			$ch = $s[ $j ];
			if ( '\\' === $ch ) {
				++$j;
				continue;
			}
			if ( "\n" === $ch || "\r" === $ch ) {
				return false;
			}
			if ( $ch === $q ) {
				return $j;
			}
		}
		return false;
	}

	/**
	 * Rewrite relative url() and @import references to root-relative URLs,
	 * so the CSS keeps working when served from the cache directory.
	 *
	 * @param string $css      CSS.
	 * @param string $base_dir URL path of the original file's directory (e.g. /wp-content/themes/x/css/).
	 */
	public static function rewrite_urls( $css, $base_dir ) {
		$base_dir = '/' . trim( $base_dir, '/' ) . '/';
		$css      = preg_replace_callback(
			'/url\(\s*([\'"]?)([^\'")]*)\1\s*\)/i',
			static function ( $m ) use ( $base_dir ) {
				$u = trim( $m[2] );
				if ( ! self::is_relative( $u ) ) {
					return $m[0];
				}
				return 'url(' . $m[1] . self::resolve( $base_dir, $u ) . $m[1] . ')';
			},
			$css
		);
		return preg_replace_callback(
			'/@import\s+([\'"])([^\'"]+)\1/i',
			static function ( $m ) use ( $base_dir ) {
				if ( ! self::is_relative( $m[2] ) ) {
					return $m[0];
				}
				return '@import ' . $m[1] . self::resolve( $base_dir, $m[2] ) . $m[1];
			},
			$css
		);
	}

	/**
	 * @param string $u URL.
	 */
	private static function is_relative( $u ) {
		return '' !== $u && ! preg_match( '#^([a-z][a-z0-9+.-]*:|/|\#|%23)#i', $u );
	}

	/**
	 * Resolve a relative URL against a directory path, keeping query/fragment.
	 *
	 * @param string $base_dir Directory path with trailing slash.
	 * @param string $rel      Relative URL.
	 */
	public static function resolve( $base_dir, $rel ) {
		$suffix = '';
		if ( preg_match( '/^([^?#]*)([?#].*)$/', $rel, $m ) ) {
			$rel    = $m[1];
			$suffix = $m[2];
		}
		$parts = explode( '/', trim( $base_dir, '/' ) . '/' . $rel );
		$stack = array();
		foreach ( $parts as $p ) {
			if ( '' === $p || '.' === $p ) {
				continue;
			}
			if ( '..' === $p ) {
				array_pop( $stack );
				continue;
			}
			$stack[] = $p;
		}
		$path = '/' . implode( '/', $stack );
		if ( '/' === substr( $rel, -1 ) ) {
			$path .= '/';
		}
		return $path . $suffix;
	}

	/* =====================================================================
	 * JavaScript
	 * =================================================================== */

	/**
	 * Minify JavaScript conservatively. Line structure is always preserved (no ASI risk).
	 * $strip = false: only trims lines and removes blank lines (comments kept).
	 * $strip = true : also removes comments (except license/preserve) and insignificant spaces.
	 *
	 * @param string $js    Source.
	 * @param bool   $strip Strip comments and intra-line whitespace.
	 * @return string|false
	 */
	public static function js( $js, $strip = false ) {
		$js  = str_replace( array( "\r\n", "\r" ), "\n", self::strip_bom( (string) $js ) );
		$len = strlen( $js );
		$out = '';
		$i   = 0;

		$pending    = ''; // Pending whitespace: '', ' ' or "\n".
		$prev_sig   = ''; // Last significant emitted char.
		$prev_word  = ''; // Last emitted identifier (for regex detection).
		$tpl_stack  = array(); // Brace depth per open template-literal expression.
		$in_tpl     = false;
		$parens     = array(); // Keyword (or '') before each open "(".
		$paren_kw   = ''; // Keyword owning the ")" just emitted (if/while/for/with → a "/" after it starts a regex).

		while ( $i < $len ) {
			// ---- Template literal body.
			if ( $in_tpl ) {
				$start = $i;
				while ( $i < $len ) {
					$ch = $js[ $i ];
					if ( '\\' === $ch ) {
						$i += 2;
						continue;
					}
					if ( '`' === $ch ) {
						++$i;
						$in_tpl = false;
						break;
					}
					if ( '$' === $ch && $i + 1 < $len && '{' === $js[ $i + 1 ] ) {
						$i          += 2;
						$tpl_stack[] = 0;
						$in_tpl      = false;
						break;
					}
					++$i;
				}
				if ( $i > $len || ( $i >= $len && $in_tpl ) ) {
					return false;
				}
				$out      .= substr( $js, $start, $i - $start );
				$prev_sig  = substr( $out, -1 );
				$prev_word = '';
				// Reached the end while still inside the literal.
				if ( $in_tpl ) {
					return false;
				}
				continue;
			}

			$c = $js[ $i ];

			// ---- Whitespace.
			if ( ' ' === $c || "\t" === $c || "\n" === $c || "\f" === $c || "\v" === $c || "\xC2" === $c && $i + 1 < $len && "\xA0" === $js[ $i + 1 ] ) {
				if ( "\xC2" === $c ) {
					// Non-breaking space is whitespace in JS; keep it verbatim to be safe.
					$out     .= self::js_flush( $pending, $out, "\xC2" ) . "\xC2\xA0";
					$pending  = '';
					$i       += 2;
					continue;
				}
				if ( "\n" === $c ) {
					$pending = "\n";
				} elseif ( '' === $pending ) {
					$pending = $strip ? ' ' : $c;
				} elseif ( ! $strip && "\n" !== $pending ) {
					$pending .= $c; // Keep intra-line whitespace verbatim in non-strip mode.
				}
				++$i;
				continue;
			}

			// ---- Comments.
			if ( '/' === $c && $i + 1 < $len && ( '/' === $js[ $i + 1 ] || '*' === $js[ $i + 1 ] ) ) {
				if ( '/' === $js[ $i + 1 ] ) {
					$end = strpos( $js, "\n", $i );
					$end = false === $end ? $len : $end;
				} else {
					$end = strpos( $js, '*/', $i + 2 );
					if ( false === $end ) {
						return false;
					}
					$end += 2;
				}
				$comment = substr( $js, $i, $end - $i );
				$keep    = ! $strip || preg_match( '#^/\*!|@license|@preserve|@cc_on|@jsx|@ts-#', $comment );
				if ( $keep ) {
					$out     .= self::js_flush( $pending, $out, '/', $strip );
					$pending  = '';
					$out     .= $comment;
					// A block comment is not a token: regex detection keeps the previous token.
				} elseif ( '*' === $comment[1] && false !== strpos( $comment, "\n" ) ) {
					$pending = "\n"; // Multi-line comment acts as a line terminator (ASI).
				} elseif ( '' === $pending ) {
					$pending = ' ';
				}
				$i = $end;
				continue;
			}

			// ---- Strings.
			if ( '"' === $c || "'" === $c ) {
				$end = self::js_string_end( $js, $i, $len );
				if ( false === $end ) {
					return false;
				}
				$out      .= self::js_flush( $pending, $out, $c, $strip );
				$pending   = '';
				$out      .= substr( $js, $i, $end - $i + 1 );
				$prev_sig  = $c;
				$prev_word = '';
				$i         = $end + 1;
				continue;
			}

			// ---- Template literal start.
			if ( '`' === $c ) {
				$out      .= self::js_flush( $pending, $out, $c, $strip ) . '`';
				$pending   = '';
				$in_tpl    = true;
				++$i;
				continue;
			}

			// ---- Regex literal.
			if ( '/' === $c && ( self::regex_allowed( $prev_sig, $prev_word ) || ( ')' === $prev_sig && in_array( $paren_kw, array( 'if', 'while', 'for', 'with' ), true ) ) ) ) {
				$end = self::js_regex_end( $js, $i, $len );
				if ( false === $end ) {
					return false;
				}
				$out      .= self::js_flush( $pending, $out, $c, $strip );
				$pending   = '';
				$out      .= substr( $js, $i, $end - $i + 1 );
				$prev_sig  = '/';
				$prev_word = '';
				$i         = $end + 1;
				continue;
			}

			// ---- Identifiers / numbers.
			if ( self::is_word( $c ) ) {
				$j = $i;
				while ( $j < $len && ( self::is_word( $js[ $j ] ) || '\\' === $js[ $j ] ) ) {
					$j += '\\' === $js[ $j ] ? 2 : 1;
				}
				$word      = substr( $js, $i, $j - $i );
				$out      .= self::js_flush( $pending, $out, $c, $strip );
				$pending   = '';
				$out      .= $word;
				$prev_sig  = substr( $word, -1 );
				$prev_word = $word;
				$i         = $j;
				continue;
			}

			// ---- Template expression braces.
			if ( ! empty( $tpl_stack ) ) {
				$top = count( $tpl_stack ) - 1;
				if ( '{' === $c ) {
					++$tpl_stack[ $top ];
				} elseif ( '}' === $c ) {
					if ( 0 === $tpl_stack[ $top ] ) {
						array_pop( $tpl_stack );
						$out    .= self::js_flush( $pending, $out, $c, $strip ) . '}';
						$pending = '';
						$in_tpl  = true;
						++$i;
						continue;
					}
					--$tpl_stack[ $top ];
				}
			}

			// ---- Punctuation.
			if ( '(' === $c ) {
				$parens[] = $prev_word;
				$paren_kw = '';
			} elseif ( ')' === $c ) {
				$paren_kw = empty( $parens ) ? '' : (string) array_pop( $parens );
			} else {
				$paren_kw = '';
			}
			$out      .= self::js_flush( $pending, $out, $c, $strip ) . $c;
			$pending   = '';
			$prev_sig  = $c;
			$prev_word = '';
			++$i;
		}

		if ( $in_tpl || ! empty( $tpl_stack ) ) {
			return false;
		}
		return trim( $out ) . "\n";
	}

	/**
	 * Emit pending whitespace before the next char.
	 *
	 * @param string $pending Pending whitespace.
	 * @param string $out     Output.
	 * @param string $next    Next char.
	 * @param bool   $strip   Strip mode.
	 */
	private static function js_flush( $pending, $out, $next, $strip = false ) {
		if ( '' === $pending || '' === $out ) {
			return '';
		}
		if ( "\n" === $pending ) {
			// Collapse blank lines, drop trailing spaces (the newline itself is always kept).
			return "\n";
		}
		if ( "\n" === substr( $out, -1 ) ) {
			return ''; // Leading indentation.
		}
		if ( ! $strip ) {
			return $pending;
		}
		$prev = substr( $out, -1 );
		if ( ( self::is_word( $prev ) || '.' === $prev || '\\' === $prev ) && ( self::is_word( $next ) || '.' === $next || '\\' === $next ) ) {
			return ' ';
		}
		// Keep spaces that prevent operator merging or comment/HTML-comment formation.
		$pair = $prev . $next;
		if ( in_array( $pair, array( '++', '--', '+-', '-+', '//', '/*', '*/', '<!', '->', '==', '=>', '&&', '||' ), true ) || '/' === $prev || '/' === $next ) {
			return ' ';
		}
		// Anything else adjacent to punctuation is insignificant.
		return '';
	}

	/**
	 * Identifier/number char (including non-ASCII bytes).
	 *
	 * @param string $c Char.
	 */
	private static function is_word( $c ) {
		return '' !== $c && ( ctype_alnum( $c ) || '_' === $c || '$' === $c || ord( $c ) >= 128 );
	}

	/**
	 * Can a "/" at this point start a regex literal?
	 *
	 * @param string $prev_sig  Previous significant char.
	 * @param string $prev_word Previous identifier.
	 */
	private static function regex_allowed( $prev_sig, $prev_word ) {
		if ( '' === $prev_sig ) {
			return true;
		}
		if ( '' !== $prev_word ) {
			return in_array( $prev_word, array( 'return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void', 'throw', 'case', 'do', 'else', 'yield', 'await' ), true );
		}
		return false !== strpos( '(,=:[!&|?{};+-*%<>~^}', $prev_sig );
	}

	/**
	 * End offset of a JS string, or false (unescaped newline = unterminated).
	 */
	private static function js_string_end( $s, $i, $len ) {
		$q = $s[ $i ];
		for ( $j = $i + 1; $j < $len; $j++ ) {
			$ch = $s[ $j ];
			if ( '\\' === $ch ) {
				++$j;
				continue;
			}
			if ( "\n" === $ch ) {
				return false;
			}
			if ( $ch === $q ) {
				return $j;
			}
		}
		return false;
	}

	/**
	 * End offset (closing slash) of a regex literal, or false.
	 */
	private static function js_regex_end( $s, $i, $len ) {
		$class = false;
		for ( $j = $i + 1; $j < $len; $j++ ) {
			$ch = $s[ $j ];
			if ( '\\' === $ch ) {
				++$j;
				continue;
			}
			if ( "\n" === $ch ) {
				return false;
			}
			if ( $class ) {
				if ( ']' === $ch ) {
					$class = false;
				}
				continue;
			}
			if ( '[' === $ch ) {
				$class = true;
			} elseif ( '/' === $ch ) {
				return $j;
			}
		}
		return false;
	}

	/**
	 * @param string $s String.
	 */
	private static function strip_bom( $s ) {
		return 0 === strpos( $s, "\xEF\xBB\xBF" ) ? substr( $s, 3 ) : $s;
	}
}
