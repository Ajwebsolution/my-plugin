<?php
/**
 * Per-request optimization statistics: feed the debug report and the admin performance report.
 * Nothing here changes output.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Stats {

	/** @var array */
	private static $s = array();

	/** @var array Protected assets: name => reason (for "why was this protected"). */
	private static $protected = array( 'css' => array(), 'js' => array() );

	/**
	 * @param string $key Counter.
	 * @param int    $n   Increment.
	 */
	public static function add( $key, $n = 1 ) {
		self::$s[ $key ] = ( isset( self::$s[ $key ] ) ? self::$s[ $key ] : 0 ) + $n;
	}

	/**
	 * @param string $key   Key.
	 * @param mixed  $value Value.
	 */
	public static function set( $key, $value ) {
		self::$s[ $key ] = $value;
	}

	/**
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function get( $key ) {
		return isset( self::$s[ $key ] ) ? self::$s[ $key ] : 0;
	}

	/**
	 * @param string $type   css|js.
	 * @param string $name   Handle.
	 * @param string $reason Reason.
	 */
	public static function protect( $type, $name, $reason ) {
		self::$protected[ $type ][ $name ] = $reason;
	}

	/**
	 * @return array
	 */
	public static function all() {
		return self::$s + array(
			'css_protected' => count( self::$protected['css'] ),
			'js_protected'  => count( self::$protected['js'] ),
		);
	}

	/**
	 * @return array
	 */
	public static function protected_list() {
		return self::$protected;
	}

	/**
	 * Human summary lines for the debug report.
	 *
	 * @return string[]
	 */
	public static function summary_lines() {
		$a  = self::all();
		$kb = static function ( $b ) {
			return number_format_i18n( ( (int) $b ) / 1024, 1 ) . ' KB';
		};
		$l   = array();
		$l[] = 'LCP resource: ' . ( self::get( 'lcp' ) ? self::get( 'lcp' ) : 'not identified' );
		$l[] = 'Critical CSS: ' . ( self::get( 'critical' ) ? self::get( 'critical' ) : 'not used' );
		$l[] = 'Deferred JS: ' . (int) self::get( 'js_deferred' );
		$l[] = 'Delayed JS (first-party): ' . (int) self::get( 'js_delayed' );
		$l[] = 'Third-party scripts delayed: ' . (int) self::get( 'tp_delayed' );
		$l[] = 'Protected JS: ' . (int) $a['js_protected'];
		$l[] = 'Protected CSS: ' . (int) $a['css_protected'];
		$l[] = 'Async CSS files: ' . (int) self::get( 'css_async' );
		$l[] = 'Unused CSS removed: ' . $kb( self::get( 'rucss_removed' ) );
		$l[] = 'Original CSS: ' . $kb( self::get( 'css_orig' ) ) . ' in ' . (int) self::get( 'css_req_before' ) . ' file(s)';
		$l[] = 'Optimized CSS: ' . $kb( self::get( 'css_opt' ) ) . ' in ' . (int) self::get( 'css_req_after' ) . ' file(s)';
		$l[] = 'Original JS: ' . $kb( self::get( 'js_orig' ) ) . ' in ' . (int) self::get( 'js_req_before' ) . ' file(s)';
		$l[] = 'Optimized JS: ' . $kb( self::get( 'js_opt' ) ) . ' in ' . (int) self::get( 'js_req_after' ) . ' file(s) at load';
		$l[] = 'Images: ' . (int) self::get( 'img_count' ) . ' (' . (int) self::get( 'img_lazy' ) . ' lazy) – ' . $kb( self::get( 'img_orig' ) ) . ' original, ' . $kb( self::get( 'img_served' ) ) . ' served format';
		$l[] = 'Preloads: ' . (int) self::get( 'preloads' ) . ' | Resource hints: ' . (int) self::get( 'hints' );
		$c   = get_option( WPSS_Debug::COUNTERS, array() );
		$l[] = 'Cache hits: ' . (int) ( isset( $c['hit'] ) ? $c['hit'] : 0 ) . ' | Cache misses: ' . (int) ( isset( $c['miss'] ) ? $c['miss'] : 0 );
		$l[] = 'Automatic fallbacks (7 days): ' . WPSS_Monitor::recent_fallbacks();
		return $l;
	}

	/* ---------------------------------------------------------------------
	 * Page reports (one small JSON file per page and device)
	 * ------------------------------------------------------------------- */

	/**
	 * Directory of page reports.
	 */
	public static function dir() {
		return WPSS_CACHE_DIR . '/reports';
	}

	/**
	 * Persist this render's numbers for the admin performance report.
	 *
	 * @param string $path    Request path.
	 * @param string $variant d|m.
	 */
	public static function save_report( $path, $variant ) {
		if ( ! WPSS_FS::ready() || '' === (string) $path ) {
			return;
		}
		$data = array(
			'path'    => $path,
			'device'  => $variant,
			'time'    => time(),
			'stats'   => self::all(),
		);
		WPSS_FS::put( self::dir() . '/' . md5( $path ) . '-' . ( 'm' === $variant ? 'm' : 'd' ) . '.json', wp_json_encode( $data ) );
	}

	/**
	 * Load all page reports (newest first, capped).
	 *
	 * @param int $limit Max.
	 * @return array[]
	 */
	public static function reports( $limit = 300 ) {
		$files = glob( self::dir() . '/*.json' );
		if ( ! $files ) {
			return array();
		}
		usort(
			$files,
			static function ( $a, $b ) {
				return (int) @filemtime( $b ) - (int) @filemtime( $a ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
		);
		$out = array();
		foreach ( array_slice( $files, 0, $limit ) as $f ) {
			$d = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( is_array( $d ) && isset( $d['stats'] ) ) {
				$out[] = $d;
			}
		}
		return $out;
	}
}
