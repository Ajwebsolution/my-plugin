<?php
/**
 * Compatibility engine: classifies every enqueued asset before any optimization is applied,
 * detects active components and conflicting optimization plugins.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Compat {

	/** @var array */
	private static $memo = array();

	/** @var array|null */
	private static $rules = null;

	/**
	 * Protection rules. js/css list the optimizations that are forbidden for matching assets.
	 */
	public static function rules() {
		if ( null !== self::$rules ) {
			return self::$rules;
		}
		$el_css = WPSS_Settings::get( 'el_css_opt' ) ? array( 'no_rucss' ) : array( 'no_combine', 'no_async', 'no_rucss' );
		$rules  = array(
			array(
				'id'       => 'core',
				'group'    => 'Core',
				'label'    => 'Core library (jQuery / WP scripts) – render critical dependency',
				'setting'  => '',
				'handles'  => array( 'jquery', 'jquery-core', 'jquery-migrate', 'wp-polyfill', 'wp-hooks', 'wp-i18n', 'regenerator-runtime', 'react', 'react-dom', 'react-jsx-runtime', 'wp-element', 'wp-dom-ready', 'underscore', 'backbone', 'wp-util', 'lodash', 'wp-api-fetch', 'imagesloaded', 'masonry', 'wp-interactivity', 'wp-data', 'wp-compose', 'wp-url' ),
				'prefixes' => array( '@wordpress/' ),
				'paths'    => array( '/wp-includes/js/jquery/' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array(),
			),
			array(
				'id'       => 'elementor',
				'group'    => 'Elementor',
				'label'    => 'Elementor dependency',
				'setting'  => 'elementor_compat',
				'handles'  => array(),
				'prefixes' => array( 'elementor', 'e-', 'swiper', 'font-awesome', 'widget-', 'eicons' ),
				'paths'    => array( '/plugins/elementor/', '/plugins/elementor-pro/', '/uploads/elementor/' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => $el_css,
			),
			array(
				'id'       => 'slider',
				'group'    => 'Slider',
				'label'    => 'Slider dependency',
				'setting'  => 'slider_protect',
				'handles'  => array(),
				'prefixes' => array(),
				'paths'    => array( '/plugins/revslider/', '/plugins/smart-slider-3/', '/plugins/ml-slider/' ),
				'keywords' => array( 'swiper', 'slick', 'owl', 'carousel', 'slider', 'revslider', 'revolution', 'rs6', 'sr7', 'themepunch', 'flexslider', 'splide', 'glide', 'flickity', 'slides' ),
				'js'       => array( 'no_defer', 'no_delay', 'no_combine' ),
				'css'      => array( 'no_combine', 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'header',
				'group'    => 'Header',
				'label'    => 'Header protection',
				'setting'  => 'header_protect',
				'handles'  => array(),
				'prefixes' => array(),
				'paths'    => array(),
				'keywords' => array( 'header', 'sticky', 'offcanvas', 'off-canvas', 'hamburger', 'masthead' ),
				'js'       => array( 'no_defer', 'no_delay', 'no_combine' ),
				'css'      => array( 'no_combine', 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'navigation',
				'group'    => 'Navigation',
				'label'    => 'Navigation / menu protection',
				'setting'  => 'header_protect',
				'handles'  => array(),
				'prefixes' => array(),
				'paths'    => array( '/plugins/megamenu/' ),
				'keywords' => array( 'nav', 'menu', 'smartmenus', 'hoverintent', 'superfish', 'megamenu', 'mega-menu', 'navigation', 'dropdown' ),
				'js'       => array( 'no_defer', 'no_delay', 'no_combine' ),
				'css'      => array( 'no_combine', 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'woocommerce',
				'group'    => 'WooCommerce',
				'label'    => 'WooCommerce dependency',
				'setting'  => '',
				'handles'  => array( 'woocommerce' ),
				'prefixes' => array( 'wc-', 'woocommerce' ),
				'paths'    => array( '/plugins/woocommerce/' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'forms',
				'group'    => 'Forms',
				'label'    => 'Form / CAPTCHA script',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'contact-form-7', 'wpcf7', 'wpforms', 'gform', 'gravityforms', 'ninja-forms', 'nf-', 'fluentform', 'fluent-form', 'formidable', 'frm' ),
				'paths'    => array( '/plugins/contact-form-7/', '/plugins/wpforms', '/plugins/gravityforms/', '/plugins/ninja-forms/', '/plugins/fluentform/', '/plugins/formidable/' ),
				'keywords' => array( 'recaptcha', 'hcaptcha', 'turnstile', 'captcha' ),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_rucss' ),
			),
			array(
				'id'       => 'payment',
				'group'    => 'Payment',
				'label'    => 'Payment / checkout script (never delayed)',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'stripe', 'wc-stripe', 'paypal', 'ppcp', 'square', 'braintree', 'klarna', 'mollie', 'razorpay', 'wc-payment', 'wcpay' ),
				'paths'    => array( 'js.stripe.com', 'paypal.com/sdk', 'paypalobjects.com', 'squareup.com', 'braintreegateway.com', 'klarna', 'mollie.com', 'checkout.razorpay.com', 'pay.google.com', 'applepay.cdn-apple.com' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'consent',
				'group'    => 'Consent',
				'label'    => 'Cookie consent (must run first – never delayed)',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'cookie-law-info', 'cookieyes', 'cmplz', 'complianz', 'borlabs', 'real-cookie-banner', 'iubenda', 'cookiebot', 'moove_gdpr', 'gdpr-cookie' ),
				'paths'    => array( 'consent.cookiebot.com', 'cdn.cookielaw.org', 'onetrust', 'cdn-cookieyes.com', 'cdn.iubenda.com', 'app.usercentrics.eu', 'termly.io', 'cookie-script.com', 'osano.com', 'quantcast.mgr.consensu.org' ),
				'keywords' => array( 'consent', 'gdpr', 'cookie-notice', 'cookie-banner' ),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_async', 'no_rucss' ),
			),
			array(
				'id'       => 'analytics',
				'group'    => 'Third-party',
				'label'    => 'Analytics / Tag Manager (third-party delay is off)',
				'setting'  => '',
				'unless'   => 'tp_delay',
				'handles'  => array(),
				'prefixes' => array(),
				'paths'    => array( 'googletagmanager.com', 'google-analytics.com' ),
				'keywords' => array( 'gtag', 'gtm', 'google-analytics', 'googletagmanager' ),
				'js'       => array( 'no_delay' ),
				'css'      => array(),
			),
			array(
				'id'       => 'popups',
				'group'    => 'Popups',
				'label'    => 'Popup script',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'pum-', 'popup-maker', 'optinmonster', 'om-' ),
				'paths'    => array( '/plugins/popup-maker/', '/plugins/optinmonster/' ),
				'keywords' => array( 'popup' ),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_rucss' ),
			),
			array(
				'id'       => 'buddypress',
				'group'    => 'Dynamic content',
				'label'    => 'BuddyPress dependency',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'bp-' ),
				'paths'    => array( '/plugins/buddypress/' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_rucss' ),
			),
			array(
				'id'       => 'acf',
				'group'    => 'Dynamic content',
				'label'    => 'ACF dependency',
				'setting'  => '',
				'handles'  => array(),
				'prefixes' => array( 'acf' ),
				'paths'    => array( '/plugins/advanced-custom-fields' ),
				'keywords' => array(),
				'js'       => array( 'no_defer', 'no_delay' ),
				'css'      => array( 'no_rucss' ),
			),
			array(
				'id'       => 'icons',
				'group'    => 'Icons',
				'label'    => 'Icon font (classes are often added by scripts)',
				'setting'  => '',
				'handles'  => array( 'dashicons', 'genericons' ),
				'prefixes' => array( 'fontawesome', 'font-awesome', 'fa-', 'icomoon', 'ionicons', 'themify-icons', 'line-awesome' ),
				'paths'    => array( 'fontawesome', 'font-awesome' ),
				'keywords' => array( 'icons' ),
				'js'       => array(),
				'css'      => array( 'no_rucss' ),
			),
		);
		self::$rules = apply_filters( 'wpss_compat_rules', $rules );
		return self::$rules;
	}

	/**
	 * Does a rule match?
	 *
	 * @param array  $rule   Rule.
	 * @param string $handle Handle.
	 * @param string $src    Source URL.
	 */
	private static function rule_matches( $rule, $handle, $src ) {
		$h = strtolower( (string) $handle );
		$s = strtolower( (string) $src );
		if ( in_array( $h, $rule['handles'], true ) ) {
			return true;
		}
		foreach ( $rule['prefixes'] as $p ) {
			if ( 0 === strpos( $h, $p ) ) {
				return true;
			}
		}
		foreach ( $rule['paths'] as $p ) {
			if ( '' !== $s && false !== strpos( $s, $p ) ) {
				return true;
			}
		}
		if ( ! empty( $rule['keywords'] ) ) {
			// Keywords are matched on the handle and the file name only (not the full path),
			// so "/plugins/some-slider-addon/" does not protect unrelated files by accident.
			$base    = strtolower( basename( (string) wp_parse_url( $s, PHP_URL_PATH ) ) );
			$subject = $h . ' ' . $base;
			foreach ( $rule['keywords'] as $k ) {
				if ( preg_match( '/(^|[^a-z0-9])' . preg_quote( $k, '/' ) . '/', $subject ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Classify an asset.
	 *
	 * @param string $type   css|js.
	 * @param string $handle Handle.
	 * @param string $src    Source URL.
	 * @return array{no_minify:bool,no_combine:bool,no_defer:bool,no_delay:bool,reasons:array}
	 */
	public static function classify( $type, $handle, $src ) {
		$memo_key = $type . '|' . $handle . '|' . $src;
		if ( isset( self::$memo[ $memo_key ] ) ) {
			return self::$memo[ $memo_key ];
		}
		$c = array(
			'no_minify'  => false,
			'no_combine' => false,
			'no_defer'   => false,
			'no_delay'   => false,
			'no_async'   => false,
			'no_rucss'   => false,
			'reasons'    => array(),
			'rules'      => array(),
			'groups'     => array(),
		);

		// 1. User exclusions.
		$m = WPSS_Exclusions::match_list( WPSS_Exclusions::patterns( 'all' ), $handle, $src );
		if ( false !== $m ) {
			$c['no_minify']  = true;
			$c['no_combine'] = true;
			$c['no_defer']   = true;
			$c['no_delay']   = true;
			$c['no_async']   = true;
			$c['no_rucss']   = true;
			$c['reasons'][]  = sprintf( 'User exclusion (all): %s', $m );
		}
		if ( 'css' === $type ) {
			$m = WPSS_Exclusions::match_list( WPSS_Settings::lines( 'excl_rucss' ), $handle, $src );
			if ( false !== $m ) {
				$c['no_async']  = true;
				$c['no_rucss']  = true;
				$c['reasons'][] = sprintf( 'User exclusion (unused CSS / async): %s', $m );
			}
		}
		foreach ( array( 'minify', 'combine', 'defer', 'delay' ) as $scope ) {
			$m = WPSS_Exclusions::match_list( WPSS_Exclusions::patterns( $scope ), $handle, $src );
			if ( false !== $m ) {
				$c[ 'no_' . $scope ] = true;
				$c['reasons'][]      = sprintf( 'User exclusion (%s): %s', $scope, $m );
				if ( 'minify' === $scope ) {
					$c['no_combine'] = true; // Combining implies minifying.
				}
			}
		}

		// 2. Automatic exclusions from error detection.
		$auto = WPSS_Exclusions::auto_match( $src );
		if ( false !== $auto ) {
			$c['no_combine'] = true;
			if ( 'all' === $auto['scope'] ) {
				$c['no_minify'] = true;
				$c['no_defer']  = true;
				$c['no_delay']  = true;
			}
			$c['no_async']  = true;
			$c['no_rucss']  = true;
			$c['reasons'][] = 'Protected / Excluded automatically: ' . $auto['reason'];
		}

		// 3. Compatibility rules.
		foreach ( self::rules() as $rule ) {
			if ( '' !== $rule['setting'] && ! WPSS_Settings::get( $rule['setting'] ) ) {
				continue;
			}
			if ( ! empty( $rule['unless'] ) && WPSS_Settings::get( $rule['unless'] ) ) {
				continue;
			}
			if ( ! self::rule_matches( $rule, $handle, $src ) ) {
				continue;
			}
			$flags = 'css' === $type ? $rule['css'] : $rule['js'];
			foreach ( $flags as $f ) {
				$c[ $f ] = true;
			}
			$c['rules'][]   = $rule['id'];
			$c['groups'][]  = isset( $rule['group'] ) ? $rule['group'] : $rule['id'];
			$c['reasons'][] = $rule['label'];
		}

		$c                       = apply_filters( 'wpss_asset_classification', $c, $type, $handle, $src );
		self::$memo[ $memo_key ] = $c;
		return $c;
	}

	/**
	 * Asset family (combining never crosses families in Balanced mode).
	 *
	 * @param string $path Absolute path.
	 */
	public static function family( $path ) {
		$p = wp_normalize_path( $path );
		if ( false !== strpos( $p, '/plugins/elementor' ) || false !== strpos( $p, '/uploads/elementor/' ) ) {
			return 'elementor';
		}
		if ( preg_match( '#/plugins/([^/]+)/#', $p, $m ) ) {
			return 'plugin:' . $m[1];
		}
		if ( preg_match( '#/themes/([^/]+)/#', $p, $m ) ) {
			return 'theme:' . $m[1];
		}
		if ( false !== strpos( $p, '/' . WPINC . '/' ) ) {
			return 'core';
		}
		return 'other';
	}

	/**
	 * Detected components (for dashboard + debug).
	 *
	 * @return string[]
	 */
	public static function detect() {
		$found  = array();
		$checks = array(
			'Elementor'        => defined( 'ELEMENTOR_VERSION' ),
			'Elementor Pro'    => defined( 'ELEMENTOR_PRO_VERSION' ),
			'WooCommerce'      => class_exists( 'WooCommerce' ),
			'Slider Revolution' => defined( 'RS_REVISION' ) || class_exists( 'RevSliderFront' ),
			'Contact Form 7'   => defined( 'WPCF7_VERSION' ),
			'WPForms'          => defined( 'WPFORMS_VERSION' ),
			'Gravity Forms'    => class_exists( 'GFForms' ),
			'ACF'              => class_exists( 'ACF' ),
			'BuddyPress'       => class_exists( 'BuddyPress' ),
			'Popup Maker'      => class_exists( 'Popup_Maker' ) || defined( 'POPMAKE_VERSION' ),
			'OptinMonster'     => class_exists( 'OMAPI' ),
			'Max Mega Menu'    => class_exists( 'Mega_Menu' ),
			'Smart Slider 3'   => defined( 'NEXTEND_SMARTSLIDER_3_URL_PATH' ) || class_exists( 'SmartSlider3' ),
			'MetaSlider'       => class_exists( 'MetaSliderPlugin' ),
			'Yoast SEO'        => defined( 'WPSEO_VERSION' ),
			'Rank Math'        => class_exists( 'RankMath' ),
			'All in One SEO'   => defined( 'AIOSEO_VERSION' ),
			'SEOPress'         => defined( 'SEOPRESS_VERSION' ),
		);
		foreach ( $checks as $name => $on ) {
			if ( $on ) {
				$found[] = $name;
			}
		}
		return $found;
	}

	/**
	 * Other cache / optimization plugins that are active. Never disabled automatically.
	 *
	 * @return string[] Names.
	 */
	public static function conflicts() {
		$known  = array(
			'wp-rocket'          => 'WP Rocket',
			'w3-total-cache'     => 'W3 Total Cache',
			'wp-super-cache'     => 'WP Super Cache',
			'litespeed-cache'    => 'LiteSpeed Cache',
			'nitropack'          => 'NitroPack',
			'autoptimize'        => 'Autoptimize',
			'wp-fastest-cache'   => 'WP Fastest Cache',
			'sg-cachepress'      => 'SiteGround Optimizer',
			'hummingbird-performance' => 'Hummingbird',
			'perfmatters'        => 'Perfmatters',
			'flying-press'       => 'FlyingPress',
			'wp-optimize'        => 'WP-Optimize',
			'breeze'             => 'Breeze',
			'swift-performance'  => 'Swift Performance',
			'swift-performance-lite' => 'Swift Performance Lite',
			'cache-enabler'      => 'Cache Enabler',
			'comet-cache'        => 'Comet Cache',
			'wp-asset-clean-up'  => 'Asset CleanUp',
			'jetpack-boost'      => 'Jetpack Boost',
			'rocket-lazy-load'   => 'Rocket Lazy Load',
			'speed-booster-pack' => 'Speed Booster Pack',
			'powered-cache'      => 'Powered Cache',
		);
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		$found = array();
		foreach ( $active as $plugin ) {
			$slug = strtolower( dirname( (string) $plugin ) );
			if ( isset( $known[ $slug ] ) ) {
				$found[ $slug ] = $known[ $slug ];
			}
		}
		$drop = WP_CONTENT_DIR . '/advanced-cache.php';
		if ( file_exists( $drop ) && defined( 'WP_CACHE' ) && WP_CACHE ) {
			$found['advanced-cache'] = __( 'A page-cache drop-in (wp-content/advanced-cache.php) from another plugin', 'steady-speed' );
		}
		return array_values( apply_filters( 'wpss_conflicts', $found ) );
	}

	/**
	 * Standard warning text.
	 */
	public static function conflict_message() {
		return __( 'Another performance optimization system is active. Running multiple optimization engines may cause CSS/JS conflicts.', 'steady-speed' );
	}

	/**
	 * Dependency group of an asset (first matching rule, else family based).
	 *
	 * @param string $type   css|js.
	 * @param string $handle Handle.
	 * @param string $src    Src.
	 */
	public static function group( $type, $handle, $src ) {
		$c = self::classify( $type, $handle, $src );
		if ( ! empty( $c['groups'] ) ) {
			return $c['groups'][0];
		}
		$host = WPSS_FS::url_host( $src );
		if ( '' !== $host && $host !== WPSS_FS::home_host() ) {
			return 'Third-party';
		}
		$path = WPSS_FS::url_to_path( $src );
		if ( $path ) {
			$f = self::family( $path );
			if ( 'core' === $f ) {
				return 'Core';
			}
			if ( 0 === strpos( $f, 'theme:' ) ) {
				return 'Theme';
			}
		}
		return 'Other';
	}

	/**
	 * Compatibility status rows for the dashboard.
	 *
	 * @return array[] label, value, state (good|warn|off)
	 */
	public static function status() {
		$rows      = array();
		$conflicts = self::conflicts();
		foreach ( $conflicts as $name ) {
			$rows[] = array( $name, __( 'Detected', 'steady-speed' ), 'warn' );
		}
		$rows[] = array( __( 'Steady Speed Cache', 'steady-speed' ), WPSS_Settings::get( 'page_cache' ) ? __( 'Enabled', 'steady-speed' ) : __( 'Disabled', 'steady-speed' ), WPSS_Settings::get( 'page_cache' ) ? 'good' : 'off' );
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			$method = get_option( 'elementor_css_print_method', 'external' );
			$rows[] = array( 'Elementor ' . ELEMENTOR_VERSION, 'external' === $method ? __( 'CSS print method: External file (recommended)', 'steady-speed' ) : __( 'CSS print method: Internal embedding (every Elementor change clears the whole cache)', 'steady-speed' ), 'external' === $method ? 'good' : 'warn' );
		}
		if ( defined( 'WC_VERSION' ) ) {
			$rows[] = array( 'WooCommerce ' . WC_VERSION, __( 'Cart, checkout and account pages are never cached or delayed', 'steady-speed' ), 'good' );
		}
		return $rows;
	}
}
