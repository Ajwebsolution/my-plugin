<?php
/**
 * Page analysis: the data behind Critical CSS, unused-CSS removal, above-the-fold / LCP
 * handling and font preloading.
 *
 * WordPress hosting has no headless browser, so the analysis runs in the administrator's own
 * browser (assets/analyzer.js): pages are loaded in hidden, script-less iframes at a desktop and
 * a mobile viewport and inspected with the real layout engine. Results are posted back here.
 * Nothing is sent to any external service.
 *
 * A stored analysis is only ever USED when it still matches the page: the exact list of
 * stylesheets (their content-hashed URLs) must be identical, and the page must not have been
 * edited since. Otherwise the page is served with its normal, complete CSS and re-queued.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_Analysis {

	const QUEUE      = 'wpss_analysis_queue';
	const FONT_USAGE = 'wpss_font_usage';
	const PARAM      = 'wpss_analyze';
	const MAX_QUEUE  = 500;

	/** @var array path => record|false */
	private static $memo = array();

	/** @var bool|null */
	private static $is_analysis = null;

	/** @var string */
	private static $analysis_device = '';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Is any feature that needs page analysis enabled?
	 */
	public static function enabled() {
		foreach ( array( 'critical_css', 'rucss', 'atf_opt', 'lcp_opt', 'font_preload', 'font_prune' ) as $k ) {
			if ( WPSS_Settings::get( $k ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Directory.
	 */
	public static function dir() {
		return WPSS_CACHE_DIR . '/analysis';
	}

	/**
	 * Canonical path key.
	 *
	 * @param string $path Path or URL.
	 */
	public static function path_key( $path ) {
		$p = (string) wp_parse_url( (string) $path, PHP_URL_PATH );
		$p = '' === $p ? '/' : $p;
		return strtolower( $p );
	}

	/**
	 * Current request path key.
	 */
	public static function current_path() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return self::path_key( $uri );
	}

	/**
	 * @param string $path Path key.
	 */
	private static function file( $path ) {
		return self::dir() . '/' . md5( $path ) . '.json';
	}

	/**
	 * Stored record for a path (or null).
	 *
	 * @param string $path Path key.
	 * @return array|null
	 */
	public static function get( $path ) {
		if ( ! array_key_exists( $path, self::$memo ) ) {
			$f = self::file( $path );
			$d = is_file( $f ) ? json_decode( (string) file_get_contents( $f ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			self::$memo[ $path ] = is_array( $d ) && isset( $d['devices'] ) ? $d : false;
		}
		return false === self::$memo[ $path ] ? null : self::$memo[ $path ];
	}

	/**
	 * Which stored device record applies to the HTML being built.
	 * Separate mobile cache: the visitor's variant. Shared cache: the union of both viewports.
	 */
	public static function device_key() {
		if ( ! WPSS_Settings::get( 'cache_mobile' ) ) {
			return 'u';
		}
		return 'm' === WPSS_Page_Cache::variant() ? 'm' : 'd';
	}

	/**
	 * Usable (fresh, not stale) device record for the current request, or null.
	 *
	 * @return array|null
	 */
	public static function for_request() {
		static $done = false, $rec = null;
		if ( $done ) {
			return $rec;
		}
		$done = true;
		if ( self::is_analysis_request() || WPSS_Context::is_transactional() ) {
			return null; // Cart / checkout / account always get their complete, original CSS.
		}
		$path = self::current_path();
		$all  = self::get( $path );
		if ( ! $all ) {
			self::note_page( $path );
			return null;
		}
		if ( ! empty( $all['stale'] ) || ( $all['v'] ?? '' ) !== WPSS_VERSION ) {
			self::queue_add( $path, 100 );
			return null;
		}
		$key = self::device_key();
		if ( empty( $all['devices'][ $key ] ) ) {
			return null;
		}
		$rec = $all['devices'][ $key ];
		return $rec;
	}

	/**
	 * Mark a page's analysis stale (content changed) and queue a new one.
	 *
	 * @param string $path_or_url Path or URL.
	 */
	public static function mark_stale( $path_or_url ) {
		$path = self::path_key( $path_or_url );
		$rec  = self::get( $path );
		if ( $rec && empty( $rec['stale'] ) ) {
			$rec['stale']        = 1;
			self::$memo[ $path ] = $rec;
			WPSS_FS::put( self::file( $path ), wp_json_encode( $rec ) );
		}
		if ( $rec ) {
			self::queue_add( $path, 100 );
		}
	}

	/**
	 * A page was rendered without analysis: queue it (cheap; option only written when new).
	 *
	 * @param string $path Path key.
	 */
	public static function note_page( $path ) {
		if ( self::enabled() && ! self::get( $path ) ) {
			self::queue_add( $path, '/' === $path ? 90 : 10 );
		}
	}

	/* ---------------------------------------------------------------------
	 * Queue
	 * ------------------------------------------------------------------- */

	/**
	 * @return array path => array(p => priority, t => time, l => lock until)
	 */
	public static function queue() {
		$q = get_option( self::QUEUE, array() );
		return is_array( $q ) ? $q : array();
	}

	/**
	 * @param string $path Path key.
	 * @param int    $prio Priority (higher first).
	 */
	public static function queue_add( $path, $prio = 10 ) {
		if ( ! self::enabled() || '' === $path || strlen( $path ) > 500 ) {
			return;
		}
		$q = self::queue();
		if ( isset( $q[ $path ] ) && $q[ $path ]['p'] >= $prio ) {
			return;
		}
		$q[ $path ] = array(
			'p' => $prio,
			't' => time(),
			'l' => 0,
		);
		if ( count( $q ) > self::MAX_QUEUE ) {
			uasort( $q, array( __CLASS__, 'by_priority' ) );
			$q = array_slice( $q, 0, self::MAX_QUEUE, true );
		}
		update_option( self::QUEUE, $q, false );
	}

	/**
	 * @param array $a A.
	 * @param array $b B.
	 */
	public static function by_priority( $a, $b ) {
		return ( $b['p'] <=> $a['p'] ) ?: ( $a['t'] <=> $b['t'] );
	}

	/**
	 * Queue every page that has an analysis (re-analyze all).
	 */
	public static function requeue_all() {
		foreach ( (array) glob( self::dir() . '/*.json' ) as $f ) {
			$d = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( is_array( $d ) && ! empty( $d['path'] ) ) {
				self::queue_add( $d['path'], 50 );
			}
		}
		self::queue_add( '/', 90 );
	}

	/**
	 * Delete all analyses.
	 */
	public static function clear() {
		foreach ( (array) glob( self::dir() . '/*.json' ) as $f ) {
			wp_delete_file( $f );
		}
		self::$memo = array();
		delete_option( self::FONT_USAGE );
	}

	/**
	 * Counts for the admin.
	 *
	 * @return array{analyzed:int,stale:int,queued:int}
	 */
	public static function counts() {
		$files = (array) glob( self::dir() . '/*.json' );
		$stale = 0;
		foreach ( $files as $f ) {
			if ( false !== strpos( (string) file_get_contents( $f, false, null, 0, 200 ), '"stale":1' ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				++$stale;
			}
		}
		return array(
			'analyzed' => count( $files ),
			'stale'    => $stale,
			'queued'   => count( self::queue() ),
		);
	}

	/* ---------------------------------------------------------------------
	 * Signed analysis URLs: the page is rendered as an anonymous visitor would see it
	 * ------------------------------------------------------------------- */

	/**
	 * @param string $path   Path key.
	 * @param string $device d|m.
	 * @param int    $exp    Expiry timestamp.
	 */
	private static function sign( $path, $device, $exp ) {
		return substr( hash_hmac( 'sha256', $path . '|' . $device . '|' . $exp, wp_salt( 'nonce' ) ), 0, 24 );
	}

	/**
	 * Signed URL for analyzing $path.
	 *
	 * @param string $path   Path key.
	 * @param string $device d|m.
	 */
	public static function url( $path, $device ) {
		$exp = time() + 15 * MINUTE_IN_SECONDS;
		$tok = $device . '.' . $exp . '.' . self::sign( $path, $device, $exp );
		$url = set_url_scheme( home_url( '/' ) );
		$url = preg_replace( '#^(https?://[^/]+).*$#', '$1', $url ) . $path;
		return add_query_arg( self::PARAM, $tok, $url );
	}

	/**
	 * Valid analysis request? (Token matches this exact path and has not expired.)
	 */
	public static function is_analysis_request() {
		if ( null !== self::$is_analysis ) {
			return self::$is_analysis;
		}
		self::$is_analysis = false;
		if ( empty( $_GET[ self::PARAM ] ) || ! function_exists( 'wp_salt' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		$tok   = sanitize_text_field( wp_unslash( $_GET[ self::PARAM ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$parts = explode( '.', $tok );
		if ( 3 !== count( $parts ) || ! in_array( $parts[0], array( 'd', 'm' ), true ) || (int) $parts[1] < time() ) {
			return false;
		}
		if ( ! hash_equals( self::sign( self::current_path(), $parts[0], (int) $parts[1] ), $parts[2] ) ) {
			return false;
		}
		self::$is_analysis     = true;
		self::$analysis_device = $parts[0];
		return true;
	}

	/**
	 * determine_current_user: an analysis render is always anonymous (can only lower privileges).
	 *
	 * @param int|false $user_id User.
	 * @return int|false
	 */
	public static function maybe_anonymous( $user_id ) {
		if ( ! empty( $_GET[ self::PARAM ] ) && self::is_analysis_request() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 0;
		}
		return $user_id;
	}

	/**
	 * wp_is_mobile: force the mobile variant for mobile analyses when a separate mobile cache exists.
	 *
	 * @param bool $is_mobile Detected.
	 */
	public static function maybe_mobile( $is_mobile ) {
		if ( ! empty( $_GET[ self::PARAM ] ) && self::is_analysis_request() && WPSS_Settings::get( 'cache_mobile' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return 'm' === self::$analysis_device;
		}
		return $is_mobile;
	}

	/* ---------------------------------------------------------------------
	 * REST (administrators only)
	 * ------------------------------------------------------------------- */

	public static function routes() {
		$perm = static function () {
			return current_user_can( 'manage_options' );
		};
		register_rest_route(
			'wpss/v1',
			'/analysis/next',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_next' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			'wpss/v1',
			'/analysis/result',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_result' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			'wpss/v1',
			'/analysis/add',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_add' ),
				'permission_callback' => $perm,
			)
		);
	}

	/**
	 * Hand out the next queued pages (locked for 3 minutes so parallel admin tabs don't collide).
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public static function rest_next( $request ) {
		$n   = min( 10, max( 1, (int) $request->get_param( 'n' ) ) );
		$q   = self::queue();
		$now = time();
		uasort( $q, array( __CLASS__, 'by_priority' ) );
		$items = array();
		foreach ( $q as $path => $info ) {
			if ( count( $items ) >= $n ) {
				break;
			}
			if ( ! empty( $info['l'] ) && $info['l'] > $now ) {
				continue;
			}
			$q[ $path ]['l'] = $now + 3 * MINUTE_IN_SECONDS;
			$items[]         = array(
				'path' => $path,
				'd'    => self::url( $path, 'd' ),
				'm'    => self::url( $path, 'm' ),
			);
		}
		if ( $items ) {
			update_option( self::QUEUE, $q, false );
		}
		return rest_ensure_response(
			array(
				'items'     => $items,
				'remaining' => count( $q ),
				'mobile'    => (bool) WPSS_Settings::get( 'cache_mobile' ),
				'mode'      => WPSS_Settings::get( 'rucss_mode' ),
			)
		);
	}

	/**
	 * Queue a URL on request (admin "Analyze this URL").
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public static function rest_add( $request ) {
		$url  = esc_url_raw( (string) $request->get_param( 'url' ) );
		$host = WPSS_FS::url_host( $url );
		if ( '' !== $host && WPSS_FS::home_host() !== $host ) {
			return new WP_Error( 'wpss_foreign', __( 'Only pages of this site can be analyzed.', 'steady-speed' ), array( 'status' => 400 ) );
		}
		self::queue_add( self::path_key( $url ), 1000 );
		return rest_ensure_response( array( 'queued' => self::path_key( $url ) ) );
	}

	/**
	 * Store an analysis.
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public static function rest_result( $request ) {
		$body = json_decode( (string) $request->get_body(), true );
		if ( ! is_array( $body ) || empty( $body['path'] ) ) {
			return new WP_Error( 'wpss_bad', 'Bad payload', array( 'status' => 400 ) );
		}
		$path = self::path_key( (string) $body['path'] );
		$q    = self::queue();
		unset( $q[ $path ] );
		update_option( self::QUEUE, $q, false );

		if ( ! empty( $body['error'] ) ) {
			WPSS_Logger::log( sprintf( 'Page analysis failed for %s: %s', $path, sanitize_text_field( substr( (string) $body['error'], 0, 200 ) ) ), 'warning' );
			return rest_ensure_response( array( 'stored' => false ) );
		}
		$devices = array();
		foreach ( array( 'd', 'm', 'u' ) as $k ) {
			if ( ! empty( $body['devices'][ $k ] ) && is_array( $body['devices'][ $k ] ) ) {
				$clean = self::clean_device( $body['devices'][ $k ] );
				if ( $clean ) {
					$devices[ $k ] = $clean;
				}
			}
		}
		if ( ! $devices ) {
			return new WP_Error( 'wpss_empty', 'No usable device data', array( 'status' => 400 ) );
		}
		$rec = array(
			'path'    => $path,
			'time'    => time(),
			'stale'   => 0,
			'v'       => WPSS_VERSION,
			'devices' => $devices,
		);
		if ( ! WPSS_FS::put( self::file( $path ), wp_json_encode( $rec ) ) ) {
			return new WP_Error( 'wpss_fs', 'Could not write', array( 'status' => 500 ) );
		}
		self::$memo[ $path ] = $rec;
		self::merge_font_usage( $path, isset( $body['fontUsage'] ) ? (array) $body['fontUsage'] : array() );

		// The page can now be served with the new data.
		WPSS_Page_Cache::delete_keys( WPSS_Page_Cache::keys_for_url( home_url( $path ) ), 'Page analysis updated' );
		WPSS_Logger::log( sprintf( 'Page analysis stored for %s (%s)', $path, implode( ', ', array_keys( $devices ) ) ), 'debug' );
		return rest_ensure_response(
			array(
				'stored'   => true,
				'devices'  => array_keys( $devices ),
			)
		);
	}

	/**
	 * Validate / sanitize one device record.
	 *
	 * @param array $d Raw.
	 * @return array|null
	 */
	private static function clean_device( $d ) {
		$url_list = static function ( $list, $max ) {
			$out = array();
			foreach ( array_slice( (array) $list, 0, $max ) as $u ) {
				if ( is_string( $u ) && '' !== $u && strlen( $u ) < 2000 ) {
					$out[] = $u;
				}
			}
			return $out;
		};
		// Critical CSS arrives as [stylesheet href, css] segments in cascade order.
		$crit  = array();
		$bytes = 0;
		foreach ( array_slice( (array) ( $d['critical'] ?? array() ), 0, 400 ) as $seg ) {
			if ( ! is_array( $seg ) || 2 !== count( $seg ) || ! is_string( $seg[0] ) || ! is_string( $seg[1] ) || strlen( $seg[0] ) > 2000 ) {
				continue;
			}
			$css    = str_ireplace( '</style', '<\/style', $seg[1] );
			$bytes += strlen( $css );
			$crit[] = array( $seg[0], $css );
		}
		if ( $bytes > 300 * 1024 ) {
			$crit = array(); // Too large to inline: better no critical CSS than a huge inline block.
		}
		$unused = array();
		$total  = 0;
		if ( ! empty( $d['unused'] ) && is_array( $d['unused'] ) ) {
			foreach ( $d['unused'] as $href => $sets ) {
				if ( ! is_string( $href ) || strlen( $href ) > 2000 || ! is_array( $sets ) ) {
					continue;
				}
				foreach ( array( 'b', 'a' ) as $level ) {
					$list = array();
					foreach ( (array) ( $sets[ $level ] ?? array() ) as $sel ) {
						if ( is_string( $sel ) && '' !== $sel && strlen( $sel ) < 2000 && $total < 60000 ) {
							$list[] = WPSS_CSS_Parser::normalize_selector( $sel );
							++$total;
						}
					}
					$unused[ $href ][ $level ] = array_values( array_unique( $list ) );
				}
			}
		}
		$lcp = array();
		if ( ! empty( $d['lcp'] ) && is_array( $d['lcp'] ) ) {
			$type = sanitize_key( $d['lcp']['type'] ?? '' );
			if ( in_array( $type, array( 'img', 'bg', 'text', 'video' ), true ) ) {
				$lcp = array(
					'type'   => $type,
					'src'    => substr( (string) ( $d['lcp']['src'] ?? '' ), 0, 2000 ),
					'srcset' => substr( (string) ( $d['lcp']['srcset'] ?? '' ), 0, 4000 ),
					'sizes'  => substr( (string) ( $d['lcp']['sizes'] ?? '' ), 0, 500 ),
					'tag'    => sanitize_key( $d['lcp']['tag'] ?? '' ),
				);
			}
		}
		$fonts = array();
		foreach ( array_slice( (array) ( $d['fonts'] ?? array() ), 0, 4 ) as $f ) {
			$u = is_array( $f ) ? (string) ( $f['url'] ?? '' ) : '';
			if ( preg_match( '#^(https?:)?//|^/#', $u ) && strlen( $u ) < 2000 ) {
				$fonts[] = array( 'url' => esc_url_raw( $u ) );
			}
		}
		return array(
			'sig'      => $url_list( $d['sig'] ?? array(), 300 ),
			'covered'  => $url_list( $d['covered'] ?? array(), 300 ),
			'critical' => $crit,
			'atf'      => $url_list( $d['atf'] ?? array(), 40 ),
			'lcp'      => $lcp,
			'fonts'    => $fonts,
			'unused'   => $unused,
			'vw'       => (int) ( $d['vw'] ?? 0 ),
			'vh'       => (int) ( $d['vh'] ?? 0 ),
		);
	}

	/**
	 * Aggregate which font family/weight/style combinations are really used (for weight pruning).
	 *
	 * @param string $path  Path.
	 * @param array  $usage Items "family|weight|style".
	 */
	private static function merge_font_usage( $path, $usage ) {
		$all = get_option( self::FONT_USAGE, array() );
		$all = is_array( $all ) ? $all : array();
		$all += array(
			'pages' => array(),
			'fonts' => array(),
		);
		$all['pages'][ $path ] = time();
		foreach ( array_slice( $usage, 0, 400 ) as $item ) {
			$parts = explode( '|', (string) $item );
			if ( 3 !== count( $parts ) ) {
				continue;
			}
			$family = strtolower( trim( $parts[0], " \t\"'" ) );
			$weight = (string) (int) $parts[1];
			$style  = 'italic' === $parts[2] || 'oblique' === $parts[2] ? 'italic' : 'normal';
			if ( '' === $family || strlen( $family ) > 100 ) {
				continue;
			}
			$all['fonts'][ $family ][ $weight . '|' . $style ] = 1;
		}
		if ( count( $all['pages'] ) > 1000 ) {
			$all['pages'] = array_slice( $all['pages'], -1000, null, true );
		}
		update_option( self::FONT_USAGE, $all, false );
	}

	/**
	 * Font usage data if enough pages (including the home page) were analyzed, else null.
	 *
	 * @return array|null family => array("weight|style" => 1)
	 */
	public static function font_usage() {
		$all = get_option( self::FONT_USAGE, array() );
		if ( ! is_array( $all ) || empty( $all['pages'] ) || count( $all['pages'] ) < 3 || ! isset( $all['pages']['/'] ) ) {
			return null;
		}
		return isset( $all['fonts'] ) ? $all['fonts'] : array();
	}
}
