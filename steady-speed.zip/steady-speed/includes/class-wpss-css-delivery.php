<?php
/**
 * CSS delivery for the final HTML: Remove Unused CSS, inline Critical CSS, async non-critical CSS.
 *
 * Safety model:
 *  - Everything depends on a FRESH page analysis: the page's stylesheet list must be byte-for-byte
 *    the list that was analyzed. Any CSS change produces new content-hashed URLs, the lists differ,
 *    and the page is served with its complete, render-blocking CSS until it is re-analyzed.
 *  - Stylesheets in protected groups (Elementor unless enabled, sliders, header, navigation,
 *    WooCommerce, payment, consent, …) always stay render-blocking and complete.
 *  - Async stylesheets keep their position in the document, so the final cascade is unchanged.
 *  - jQuery "ready" handlers (sliders, menus, Elementor) are held until async stylesheets have
 *    loaded (max 3 s), so scripts never measure a half-styled page.
 *  - A <noscript> copy keeps the page styled without JavaScript.
 *
 * @package SteadySpeed
 */

defined( 'ABSPATH' ) || exit;

final class WPSS_CSS_Delivery {

	/** Core stylesheets eligible for unused-CSS removal in Safe mode. */
	const SAFE_HANDLES = array( 'wp-block-library', 'wp-block-library-theme', 'classic-theme-styles' );

	/**
	 * @param string $html HTML.
	 * @return string
	 */
	public static function process( $html ) {
		$critical_on = WPSS_Settings::get( 'critical_css' ) && WPSS_Settings::get( 'css_async' );
		$rucss_on    = (bool) WPSS_Settings::get( 'rucss' );
		if ( ! $critical_on && ! $rucss_on ) {
			return $html;
		}
		if ( ! WPSS_Context::optimize() || WPSS_Analysis::is_analysis_request() ) {
			return $html;
		}
		if ( self::csp_blocks_inline() ) {
			WPSS_Stats::set( 'critical', 'not used – the page sends a Content-Security-Policy without unsafe-inline' );
			return $html;
		}
		$links = self::links( $html );
		if ( ! $links ) {
			return $html;
		}
		$rec = WPSS_Analysis::for_request();
		if ( ! $rec ) {
			WPSS_Stats::set( 'critical', 'waiting for page analysis (complete CSS served)' );
			return $html;
		}
		if ( array_column( $links, 'href' ) !== $rec['sig'] ) {
			WPSS_Analysis::queue_add( WPSS_Analysis::current_path(), 60 );
			WPSS_Stats::set( 'critical', 'analysis outdated – stylesheets changed; complete CSS served, re-analysis queued' );
			return $html;
		}

		$mode    = (string) WPSS_Settings::get( 'rucss_mode' );
		$covered = array_flip( $rec['covered'] );
		$crit_ok = $critical_on && ! empty( $rec['critical'] ) && ! WPSS_Context::url_in_list( WPSS_Settings::lines( 'excl_critical' ) );
		$async   = array();
		$new     = array();

		foreach ( $links as $i => $l ) {
			$tag = $l['tag'];
			// ---- Remove unused CSS.
			if ( $rucss_on && ! empty( $rec['unused'][ $l['href'] ] ) && self::rucss_eligible( $l, $mode ) ) {
				$list = $rec['unused'][ $l['href'] ][ 'aggressive' === $mode ? 'a' : 'b' ];
				$url  = $list ? self::filtered_url( $l['href'], $list, $mode ) : false;
				if ( $url ) {
					$tag = self::set_attr( $tag, 'href', $url );
					$tag = self::add_opt( $tag, 'rucss', $l['href'] );
				}
			}
			// ---- Async (only with critical CSS for this page).
			if ( $crit_ok && isset( $covered[ $l['href'] ] ) && self::async_eligible( $l ) ) {
				$media    = '' === $l['media'] ? 'all' : $l['media'];
				$fallback = $tag;
				$tag      = self::set_attr( $tag, 'media', 'print' );
				$tag      = preg_replace( '/<link\b/i', '<link data-wpss-media="' . esc_attr( $media ) . '" onload="this.media=this.getAttribute(\'data-wpss-media\')"', $tag, 1 );
				$tag     .= '<noscript>' . $fallback . '</noscript>';
				$async[ $l['href'] ] = $i;
				WPSS_Stats::add( 'css_async' );
				$served = WPSS_FS::url_to_path( html_entity_decode( (string) self::attr( $tag, 'href' ), ENT_QUOTES ) );
				WPSS_Stats::add( 'css_async_bytes', $served ? (int) @filesize( $served ) : 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
			$new[ $i ] = $tag;
		}

		// Critical rules of each async stylesheet are inlined exactly where that stylesheet is, so
		// the cascade order between critical copies and render-blocking stylesheets is the original
		// one. @font-face / @keyframes (order independent) go with the first block.
		$segments = array();
		$extra    = '';
		if ( $async ) {
			foreach ( $rec['critical'] as $seg ) {
				if ( '' === $seg[0] ) {
					$extra .= $seg[1];
				} elseif ( isset( $async[ $seg[0] ] ) ) {
					$idx              = $async[ $seg[0] ];
					$segments[ $idx ] = ( $segments[ $idx ] ?? '' ) . $seg[1];
				}
			}
		}
		$critical = implode( '', $segments ) . $extra;
		$first    = $async ? min( $async ) : -1;
		for ( $i = count( $links ) - 1; $i >= 0; $i-- ) {
			$tag = $new[ $i ];
			if ( '' !== $critical && isset( $segments[ $i ] ) || ( $i === $first && '' !== $extra ) ) {
				$css = ( $segments[ $i ] ?? '' ) . ( $i === $first ? $extra : '' );
				$tag = '<style' . ( $i === $first ? ' id="wpss-critical"' : '' ) . ' class="wpss-critical">' . $css . '</style>' . $tag;
			}
			if ( $tag !== $links[ $i ]['tag'] ) {
				$html = substr_replace( $html, $tag, $links[ $i ]['offset'], strlen( $links[ $i ]['tag'] ) );
			}
		}
		if ( $async && '' !== $critical ) {
			WPSS_Stats::set( 'critical_bytes', strlen( $critical ) );
			$html = self::add_gate( $html );
			WPSS_Stats::set( 'critical', sprintf( 'generated – %s KB inline, %d stylesheet(s) loaded asynchronously', number_format_i18n( strlen( $critical ) / 1024, 1 ), count( $async ) ) );
		} elseif ( $crit_ok ) {
			WPSS_Stats::set( 'critical', 'not needed – every stylesheet on this page is protected (render-blocking)' );
		} elseif ( $critical_on ) {
			WPSS_Stats::set( 'critical', empty( $rec['critical'] ) ? 'not available for this page (analysis produced none – complete CSS served)' : 'excluded for this URL' );
		}
		return $html;
	}

	/**
	 * Stylesheet <link> tags outside <noscript>, in document order.
	 *
	 * @param string $html HTML.
	 * @return array[] tag, offset, href, media, handle
	 */
	private static function links( $html ) {
		$skip = array();
		if ( preg_match_all( '#<noscript\b.*?</noscript>#is', $html, $mm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $mm[0] as $m ) {
				$skip[] = array( $m[1], $m[1] + strlen( $m[0] ) );
			}
		}
		$out = array();
		if ( ! preg_match_all( '#<link\b[^>]*>#i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return $out;
		}
		foreach ( $m[0] as $hit ) {
			list( $tag, $off ) = $hit;
			foreach ( $skip as $r ) {
				if ( $off >= $r[0] && $off < $r[1] ) {
					continue 2;
				}
			}
			$rel = strtolower( (string) self::attr( $tag, 'rel' ) );
			if ( ! preg_match( '/(^|\s)stylesheet(\s|$)/', $rel ) ) {
				continue;
			}
			$href = self::attr( $tag, 'href' );
			if ( null === $href || '' === $href ) {
				continue;
			}
			$id    = (string) self::attr( $tag, 'id' );
			$out[] = array(
				'tag'       => $tag,
				'offset'    => $off,
				'href'      => html_entity_decode( $href, ENT_QUOTES ),
				'media'     => strtolower( trim( (string) self::attr( $tag, 'media' ) ) ),
				'handle'    => preg_replace( '/-css$/', '', $id ),
				// Classification must use the ORIGINAL source (the optimized URL lives in the cache dir).
				'orig'      => html_entity_decode( (string) self::attr( $tag, 'data-wpss-orig' ), ENT_QUOTES ),
				'alternate' => false !== strpos( $rel, 'alternate' ),
				'onload'    => null !== self::attr( $tag, 'onload' ),
			);
		}
		return $out;
	}

	/**
	 * @param string $tag  Tag.
	 * @param string $name Attribute.
	 * @return string|null
	 */
	private static function attr( $tag, $name ) {
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '\s*=\s*(["\'])(.*?)\1/is', $tag, $m ) ) {
			return $m[2];
		}
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '\s*=\s*([^\s>"\']+)/i', $tag, $m ) ) {
			return $m[1];
		}
		return null;
	}

	/**
	 * Set (replace or add) an attribute.
	 *
	 * @param string $tag   Tag.
	 * @param string $name  Name.
	 * @param string $value Value.
	 */
	private static function set_attr( $tag, $name, $value ) {
		$attr = $name . '="' . esc_attr( $value ) . '"';
		$re   = '/\s' . preg_quote( $name, '/' ) . '\s*=\s*(["\']).*?\1|\s' . preg_quote( $name, '/' ) . '\s*=\s*[^\s>"\']+/is';
		if ( preg_match( $re, $tag ) ) {
			return preg_replace( $re, ' ' . $attr, $tag, 1 );
		}
		return preg_replace( '/<link\b/i', '<link ' . $attr, $tag, 1 );
	}

	/**
	 * Record an optimization flag (+ original URL for the error monitor's fallback).
	 *
	 * @param string $tag  Tag.
	 * @param string $flag Flag.
	 * @param string $orig Original href.
	 */
	private static function add_opt( $tag, $flag, $orig ) {
		$opt = self::attr( $tag, 'data-wpss-opt' );
		$tag = null === $opt ? preg_replace( '/<link\b/i', '<link data-wpss-opt="' . esc_attr( $flag ) . '"', $tag, 1 ) : self::set_attr( $tag, 'data-wpss-opt', trim( $opt . ' ' . $flag ) );
		if ( null === self::attr( $tag, 'data-wpss-orig' ) ) {
			$tag = preg_replace( '/<link\b/i', '<link data-wpss-orig="' . esc_attr( $orig ) . '"', $tag, 1 );
		}
		return $tag;
	}

	/**
	 * Same-origin URL?
	 *
	 * @param string $href Href.
	 */
	private static function same_origin( $href ) {
		if ( 0 === strpos( $href, '/' ) && 0 !== strpos( $href, '//' ) ) {
			return true;
		}
		return WPSS_FS::url_host( $href ) === WPSS_FS::home_host();
	}

	/**
	 * Classification of a link (combined stylesheets: every member must allow it).
	 *
	 * @param array  $l    Link.
	 * @param string $flag no_async|no_rucss.
	 * @return string '' when allowed, else the reason.
	 */
	private static function blocked( $l, $flag ) {
		$members = WPSS_Assets::combined_members( $l['handle'] );
		if ( ! $members ) {
			$src     = '' !== $l['orig'] ? strtok( $l['orig'], ' ' ) : $l['href'];
			$members = array( $l['handle'] => $src );
		}
		foreach ( $members as $h => $src ) {
			$c = WPSS_Compat::classify( 'css', $h, $src );
			if ( $c[ $flag ] ) {
				WPSS_Stats::protect( 'css', $h, implode( '; ', $c['reasons'] ) );
				return implode( '; ', $c['reasons'] );
			}
		}
		return '';
	}

	/**
	 * @param array  $l    Link.
	 * @param string $mode safe|balanced|aggressive.
	 */
	private static function rucss_eligible( $l, $mode ) {
		if ( $l['alternate'] || ! self::same_origin( $l['href'] ) ) {
			return false;
		}
		$members = WPSS_Assets::combined_members( $l['handle'] );
		$handles = $members ? array_keys( $members ) : array( $l['handle'] );
		if ( 'safe' === $mode ) {
			foreach ( $handles as $h ) {
				if ( ! in_array( $h, self::SAFE_HANDLES, true ) && 0 !== strpos( $h, 'wp-block-' ) ) {
					return false;
				}
			}
		}
		$why = self::blocked( $l, 'no_rucss' );
		if ( '' !== $why ) {
			WPSS_Debug::add( 'css', $l['handle'], 'Unused CSS kept', $why );
			return false;
		}
		return true;
	}

	/**
	 * @param array $l Link.
	 */
	private static function async_eligible( $l ) {
		if ( $l['alternate'] || $l['onload'] || ! in_array( $l['media'], array( '', 'all', 'screen' ), true ) || ! self::same_origin( $l['href'] ) ) {
			return false;
		}
		$why = self::blocked( $l, 'no_async' );
		if ( '' !== $why ) {
			WPSS_Debug::add( 'css', $l['handle'], 'Render-blocking (protected)', $why );
			return false;
		}
		return true;
	}

	/**
	 * URL of the stylesheet without the rules proven unused on this page (built once, cached).
	 *
	 * @param string   $href   Stylesheet URL.
	 * @param string[] $unused Normalized unused selectors.
	 * @param string   $mode   Mode.
	 * @return string|false
	 */
	private static function filtered_url( $href, $unused, $mode ) {
		$path = WPSS_FS::url_to_path( $href );
		if ( false === $path || ! is_file( $path ) ) {
			return false;
		}
		$sig = (int) @filemtime( $path ) . '-' . (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$key = md5( 'rucss|' . $href . '|' . $sig . '|' . $mode . '|' . md5( implode( "\n", $unused ) ) . '|' . WPSS_VERSION );
		$rel = WPSS_Assets::map_get( $key );
		if ( false === $rel ) {
			$fail = 'wpss_fail_' . substr( $key, 0, 20 );
			if ( get_transient( $fail ) ) {
				return false;
			}
			$css = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$out = WPSS_CSS_Parser::remove_unused( $css, array_fill_keys( $unused, true ), $removed );
			if ( false === $out || $removed < 200 ) {
				set_transient( $fail, 1, DAY_IN_SECONDS ); // Unparseable or not worth a separate file.
				return false;
			}
			$out = WPSS_Minify::rewrite_urls( $out, dirname( (string) wp_parse_url( $href, PHP_URL_PATH ) ) );
			$rel = WPSS_Assets::store_output( 'css', 'u-' . basename( $path ), $out );
			if ( false === $rel ) {
				return false;
			}
			WPSS_Assets::map_put( $key, $rel );
		}
		WPSS_Assets::register_output( $rel, $path );
		$saved = max( 0, (int) @filesize( $path ) - (int) @filesize( WPSS_CACHE_DIR . '/' . $rel ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		WPSS_Stats::add( 'rucss_removed', $saved );
		WPSS_Stats::add( 'css_opt', -$saved );
		return WPSS_FS::cache_url( $rel );
	}

	/**
	 * Hold jQuery ready handlers until async stylesheets have loaded (max 3 s).
	 *
	 * @param string $html HTML.
	 */
	private static function add_gate( $html ) {
		if ( ! preg_match( '#<script\b[^>]*\bid=(["\'])jquery-core-js\1[^>]*>\s*</script>#i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return $html;
		}
		$js   = '(function(){var $=window.jQuery;if(!$||!$.holdReady)return;var p=[].filter.call(document.querySelectorAll("link[data-wpss-media]"),function(l){return l.media==="print"&&!l.sheet});'
			. 'if(!p.length)return;var n=p.length,d=0;function f(){if(d)return;if(--n<=0){d=1;$.holdReady(false)}}$.holdReady(true);'
			. 'p.forEach(function(l){l.addEventListener("load",f);l.addEventListener("error",f)});setTimeout(function(){if(!d){d=1;$.holdReady(false)}},3000)})();';
		$gate = wp_get_inline_script_tag( $js, array( 'id' => 'wpss-css-gate' ) );
		$pos  = $m[0][1] + strlen( $m[0][0] );
		return substr_replace( $html, $gate, $pos, 0 );
	}

	/**
	 * Would a Content-Security-Policy header block inline code (critical CSS / onload handlers)?
	 */
	public static function csp_blocks_inline() {
		if ( ! function_exists( 'headers_list' ) ) {
			return false;
		}
		foreach ( headers_list() as $h ) {
			if ( 0 === stripos( $h, 'content-security-policy:' ) ) {
				$v = strtolower( $h );
				if ( ( false !== strpos( $v, 'script-src' ) || false !== strpos( $v, 'default-src' ) ) && false === strpos( $v, "'unsafe-inline'" ) ) {
					return true;
				}
			}
		}
		return false;
	}
}
