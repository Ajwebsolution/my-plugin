# Steady Speed — Architecture & Asset-Lifecycle Analysis

This document was written before the code. Every optimization in the plugin is placed at a
specific point in the WordPress request lifecycle, and each placement was chosen so that CSS
cascade order and JavaScript execution order can never be changed by the plugin.

---

## 1. The WordPress asset lifecycle (where things can go wrong)

```
wp-settings.php
 ├─ mu-plugins, plugins load ........................ [A] Steady Speed serves cached HTML here
 ├─ plugins_loaded / init
 ├─ wp()  → main query
 ├─ template_redirect ............................... [B] decide: cacheable? optimizable? start buffer
 ├─ template include
 │   ├─ wp_head
 │   │   ├─ wp_enqueue_scripts (prio 1)  themes/plugins register + enqueue
 │   │   ├─ wp_print_styles (prio 8)
 │   │   │   └─ WP_Styles::do_items()
 │   │   │       ├─ all_deps()  → topological sort by declared dependencies
 │   │   │       ├─ filter print_styles_array ....... [C] contiguous CSS grouping (Balanced/Aggressive)
 │   │   │       └─ do_item() → _css_href()
 │   │   │           ├─ filter style_loader_src ..... [D] per-file optimized copy + hash version
 │   │   │           └─ filter style_loader_tag ..... [E] data-wpss-orig (client fallback)
 │   │   └─ wp_print_head_scripts (prio 9)
 │   │       └─ WP_Scripts::do_items()
 │   │           ├─ all_deps()  → topological sort
 │   │           ├─ filter print_scripts_array ...... [F] request "defer" strategy / mark delayed
 │   │           └─ do_item()
 │   │               ├─ get_eligible_loading_strategy()  ← CORE verifies defer is dependency-safe
 │   │               ├─ filter script_loader_src .... [G] per-file optimized copy
 │   │               └─ filter script_loader_tag .... [H] delayed transform / fallback attrs
 │   ├─ body: Elementor renders widgets → late enqueues (swiper, e-swiper, smartmenus, popups)
 │   └─ wp_footer
 │       ├─ print_late_styles + footer scripts → same C–H path, separate group
 │       └─ delayed-script loader (only if something was delayed)
 └─ shutdown → output buffer callback ................ [I] images, debug report, store cache + manifest
```

### Failure modes of aggressive optimizers, mapped to lifecycle points

| Symptom | Root cause | How this design avoids it |
|---|---|---|
| Broken layout after combining | Files concatenated out of cascade order, across `media`, or with inline `<style>` blocks moved | [C] only merges **contiguous** handles from the already-sorted queue, same `media`, no `before/after` inline CSS, no conditional/alt/title/RTL-replace. Order is inherited from `all_deps()`, never recomputed. |
| Missing background images/fonts | Relative `url()` breaks when CSS moves directory | Minifier rewrites every relative `url()` / `@import` to root-relative paths based on the source file's URL. |
| Slider/menu dead after defer | A deferred library is used by a blocking script or by inline `after` code | [F] never decides eligibility itself: it sets the WP 6.3+ `strategy` flag, and **core** downgrades to blocking when any dependent is blocking or inline "after" code exists. Protected groups (jQuery, Elementor, sliders, header/nav, forms, WooCommerce, popups) are never flagged. |
| Delayed JS never runs its init | Delayed script listens for `DOMContentLoaded` or has dependents | Delay applies only to leaf scripts (no dependents), with no inline "after" code, never to protected groups, and only when listed by the admin or (Aggressive) off-site third-party scripts. A timeout loads them anyway. |
| Stale CSS/JS after edits | Optimized copies keyed by handle, cache needs manual purge | [D]/[G] file names contain a hash of path + mtime + size + mode + ver. A changed file produces a new URL automatically. |
| "Clear the cache after every Elementor save" | Cache is invalidated globally or not at all | Dependency index (section 3) + serve-time asset freshness check (section 4). |

### Elementor specifics

* Page CSS lives in `uploads/elementor/css/post-{ID}.css`; Elementor rewrites the **same path** on save.
  Our versioning keys on mtime, so a re-save yields a new optimized URL without any purge.
* The global kit CSS (`post-{kit}.css`) is loaded everywhere; saving the kit purges everything
  (it genuinely affects every page).
* `elementor-frontend` carries a `before` inline config (`elementorFrontendConfig`) and is the
  hub every widget handler depends on → protected (never deferred/delayed/combined).
* Swiper is loaded as a dependency (`swiper`, `e-swiper`) → slider protection.
* Elementor Pro Nav Menu uses SmartMenus → header protection.
* Theme Builder headers/footers/popups are rendered through
  `elementor/frontend/before_get_builder_content` → we record the template ID as a dependency, so
  editing a header template invalidates exactly the pages that rendered that header.
* The editor (`?elementor-preview`, `action=elementor`) and all builder previews are never
  optimized or cached.

---

## 2. Optimization invariants (enforced in code)

1. **Never reorder.** CSS order and JS order come from `all_deps()`; we only replace or annotate.
2. **Never move inline code.** Handles with inline `before`/`after` code are never combined or delayed.
3. **Delegate defer safety to core** (`strategy` API, WP ≥ 6.4).
4. **Protected beats optimized.** Classification flags (`no_minify`, `no_combine`, `no_defer`,
   `no_delay`) are the union of user exclusions, auto-exclusions and compatibility rules.
5. **Originals are never touched.** Optimized copies go to `wp-content/cache/steady-speed/assets/`.
6. **Validate or fall back.** Minifiers are tokenizer-based and return `false` on any unterminated
   string/comment/regex/template; CSS output must have balanced braces. Failure → original file.
7. **Fail-safe client fallback.** Optimized tags carry `data-wpss-orig`; if an optimized file fails to
   load, the browser immediately injects the original(s).

### Modes

| | CSS | JavaScript |
|---|---|---|
| **Safe** (default) | Per-file minify + URL rewrite | Whitespace-only minify (comments kept), no defer, no delay |
| **Balanced** | + combine contiguous files of the **same family** (Elementor / one plugin / theme / core) | + comment removal, defer **footer** scripts (core-verified) |
| **Aggressive** | + combine contiguous files across families (Elementor still separate when compat mode is on) | + defer header scripts, auto-delay off-site leaf scripts |

---

## 3. Cache dependency map (incremental invalidation)

Each cached page stores rows in `{prefix}wpss_deps (cache_key, dep)`. Deps are collected while
the page renders:

| Collected from | Dependency |
|---|---|
| Queried object | `post:ID`, `term:ID`, `author:ID`, `archive:{type}`, `home` |
| `the_post` (every loop, incl. Elementor Posts widgets) | `post:ID`, `listing:{type}` |
| `wp_nav_menu_objects` (incl. Elementor Nav Menu) | `menu:ID` |
| `dynamic_sidebar_before` | `sidebar` |
| `elementor/frontend/before_get_builder_content` | `post:{template ID}` (headers, footers, popups, sections) |

Invalidation events map to dependencies:

| Event | Invalidates |
|---|---|
| Post/page updated | `post:ID` (+ its URL) |
| Post published/unpublished/trashed | + `listing:type`, `archive:type`, `home`, its `term:*`, `author:*` |
| Elementor save | `post:ID`; kit save → everything |
| Elementor header/footer/popup template save | every page that rendered it (`post:templateID`) |
| Menu saved | `menu:ID` only |
| Widgets saved | `sidebar` |
| Comment approved/edited | `post:ID` |
| Term edited | `term:ID` |
| Customizer, theme switch, site-wide options, plugin (de)activation/update | everything (these change every page) |

Example:

```
Homepage ──┬─ post:2 (front page)
           ├─ post:311 (Elementor header template) ── Nav Menu → menu:4
           ├─ listing:post (latest-posts widget)
           └─ assets (manifest): elementor post-2.css, post-311.css, swiper.css, slider.js …
```

Editing menu 4 purges only pages that rendered menu 4. Editing slider CSS purges nothing
proactively — see section 4.

Invalidations are **queued and deduplicated** and run once at `shutdown`. A generation-race
guard (`last-invalidation` timestamp) prevents a request that started before an invalidation from
storing stale HTML.

---

## 4. Automatic asset versioning & serve-time freshness

Optimized file name: `{name}-{md5(path | mtime-size | mode | ver | plugin version)[0..12]}.{ext}`

Each cached page has a manifest `{key}.php` (guarded with `<?php exit; ?>`):

```json
{ "sources": { "/abs/path/slider.js": "1727000000-18342", ... },
  "outputs": [ "/abs/cache/assets/js/slider-3fa9c1d2e8b1.js", ... ] }
```

When a cached page is requested, before sending it we `stat()` its source files (~20 stats,
sub-millisecond). If any source changed, or an optimized output is missing, that page alone is
regenerated on this request — which creates the new optimized file and new URL automatically.
Unaffected pages remain cached. No cron, no purge button, no "regenerate CSS".

Old optimized files are kept (pages cached earlier may still reference them). Files whose mtime
has not been refreshed for 14 days are removed by the hourly cleanup (every page render "touches"
the files it uses, at most once a day).

---

## 5. Automatic error detection

A ~1.5 KB inline script (printed first in `<head>`) listens in capture phase for:

* optimized `<link>`/`<script>` load failures → immediately loads the originals and reports;
* JS errors whose `filename` is an optimized file → reports that source;
* inline-script errors on pages where scripts were deferred/delayed → reports the URL;
* sliders (Swiper/Owl) still uninitialized 4 s after `load` on optimized pages → reports the URL.

The REST endpoint `wpss/v1/report` is public by design, so it is rate-limited, validates that
reported originals map to real local files and counts at most one report per client per hour.
After 3 counted reports, the asset is auto-excluded (or the URL is excluded from optimization),
and the cache is invalidated. Abuse can only ever *reduce* optimization, never break a page.

---

## 6. Module map

| File | Responsibility |
|---|---|
| `class-wpss-page-cache.php` | Early serve, buffer, store, manifest, dependency rows, invalidation API |
| `class-wpss-invalidation.php` | Dependency collection + WordPress/Elementor/Woo/ACF event hooks |
| `class-wpss-assets.php` | Per-file optimization, contiguous CSS combining, defer strategy, delay |
| `class-wpss-minify.php` | Tokenizer-based CSS/JS minifiers with validation, URL rewriting |
| `class-wpss-compat.php` | Compatibility rules, classification, component & conflict detection |
| `class-wpss-exclusions.php` | User and automatic exclusions (file, partial, `plugin:`, `handle:`, wildcard) |
| `class-wpss-context.php` | Per-request decision: may we optimize? |
| `class-wpss-images.php` | Lazy loading, dimensions, `<picture>` WebP/AVIF, WebP copy generation |
| `class-wpss-fonts.php` | Preconnect, `display=swap`, local Google Fonts, disable |
| `class-wpss-browser-cache.php` | `.htaccess` rules (cache dir + optional root block), Nginx snippet |
| `class-wpss-monitor.php` | Error-report endpoint, thresholds, auto-exclusion |
| `class-wpss-database.php` | Opt-in, confirmed cleanup operations |
| `class-wpss-debug.php` | Per-request decision report (HTML comment / admin panel) |
| `class-wpss-admin.php` | Dashboard, settings, exclusions, database, debug, admin bar, Safe Mode |
| `class-wpss-cron.php` | Hourly cleanup (expired pages, old assets, trash dirs) |

## 7. Known limits (by design)

* JavaScript is never combined. The HTTP/2 gain is small and it is the #1 source of breakage.
* No async/"critical CSS" loading — it trades CLS and flashes of unstyled content for a score.
* Caching is served from the plugin (after other plugins load) rather than an `advanced-cache.php`
  drop-in, so `wp-config.php` is never edited. Typical TTFB for a hit is still a small fraction of
  a full render.
* Layout regressions that raise no error (e.g. a colour change) cannot be detected automatically;
  that is what Safe mode defaults, per-file exclusions, `?wpss_disable=1` comparison and Emergency
  Safe Mode are for.
* Client-side fallback cannot un-run code. If an optimized *blocking* script fails to load, its
  original is injected right after it, but inline/dependent scripts that already executed may throw
  once on that page view. Follow-on errors are not reported (only the load failure is), so the right
  file is auto-excluded after the threshold. `document.write` was rejected as a fallback because it
  can wipe the document in some browsers.
* The minifiers are tokenizers, not full parsers. Whenever they meet something ambiguous or
  unterminated they return `false` and the original file is served. Verified on jQuery 3.7.1,
  Slick 1.8.1, Owl 2.3.4, Bootstrap 5.3.3, Swiper 8.4.7 and ~290 WordPress core JS / ~250 core CSS
  files: every output parses to an identical AST (acorn for JS, css-tree for CSS) in both modes.
* Error reports come from anonymous visitors. They are rate-limited, deduplicated per IP-hour and
  can only ever make the plugin do *less* (exclude a file or a page), never more.
* Image width/height insertion is off by default: adding dimensions to images that relied on
  missing ones can change layouts.

## 8. Test log (development)

WordPress 6.8.1 (SQLite), PHP 8.3, jsdom: cache MISS→HIT, targeted invalidation on post update
(post + listing pages only), full purge on settings/site options, CSS combine limits (media,
`@import`), dependency-safe defer (core refused defer where inline "after" code existed), delayed
third-party script, runtime order in jsdom with zero errors, simulated 404 of optimized CSS/JS →
originals restored + reported, 3-report threshold → auto-exclusion applied on next request,
page-level auto-exclusion, admin tabs render without notices, tab-scoped settings save,
Emergency Safe Mode on/off, DB cleanup with confirmation, deactivate/uninstall leave nothing behind.

## 9. Version 1.1 — advanced performance pipeline

### 9.1 Final HTML pipeline (order matters)
1. **Images** (`WPSS_Images`): dimensions (only from the real file; `data-wpss-dim` + `:where(img[data-wpss-dim]){height:auto}`), srcset for `wp-image-ID` images via core, above-the-fold (analysis) → never lazy, LCP → `fetchpriority=high`, `<picture>` WebP/AVIF, lazy iframes, size stats.
2. **CSS delivery** (`WPSS_CSS_Delivery`): unused-CSS removal → async + critical CSS → jQuery CSS-ready gate.
3. **Third-party delay** (`WPSS_ThirdParty`).
4. **Preload manager / resource hints** (`WPSS_Preload`): ≤1 image, ≤2 fonts, ≤3 preconnect, dns-prefetch for delayed origins.
5. Per-page report file (`WPSS_Stats`) and debug report.

### 9.2 Page analysis (`WPSS_Analysis`, `assets/analyzer.js`)
* Queue (`wpss_analysis_queue`) filled when pages are rendered/cached without a fresh analysis, when content changes (post / Elementor save marks the analysis stale) and on demand.
* The administrator's browser loads `?wpss_analyze=<device>.<expiry>.<hmac>` in hidden iframes with `sandbox="allow-same-origin"` (no scripts) at 1350×900 and 412×915. The signed URL renders anonymously (`determine_current_user` → 0, lowers privileges only), forces the mobile variant when a separate mobile cache exists, strips `<noscript>`, makes scripts inert text, never stores in the page cache.
* Per device the analyzer returns: stylesheet signature, readable ("covered") stylesheets, critical CSS as `[stylesheet, css]` segments in cascade order, above-the-fold image URLs, LCP candidate, ≤2 critical woff2 fonts, unused selectors per stylesheet (`b` = safe/balanced level, `a` = aggressive), font usage.
* "Above the fold" = element top < viewport + 200 px, OR not rendered (menus/popups), OR inside header/navigation, OR below the fold only because of its own margin/padding/border (otherwise dropping its rules would move it up).
* Rule matching is relaxed for runtime state: pseudo-classes/elements and class names typically toggled by scripts are ignored when testing; unmatched rules whose class/id tokens appear anywhere in the raw HTML (including inline scripts/JSON) are kept.

### 9.3 Critical CSS & async CSS invariants
* Used only when the page's stylesheet list equals the analyzed list exactly (content-hashed URLs ⇒ any CSS change invalidates) and the analysis is not stale/outdated-version. Otherwise the complete CSS is served and the page is re-queued.
* Only same-origin, covered, `all`/`screen` stylesheets outside protected groups (`no_async`) become async; classification uses the ORIGINAL source (`data-wpss-orig`).
* Each async stylesheet's critical rules are inlined immediately before that stylesheet ⇒ cascade order identical to the original at every moment.
* `media="print"` + `onload` swap, `<noscript>` fallback, not used when a CSP forbids inline code, never on cart/checkout/account.
* `jQuery.holdReady(true)` until pending async stylesheets load/error (max 3 s).

### 9.4 Unused CSS
`WPSS_CSS_Parser` walks the original stylesheet text; a style rule is removed only if its normalized selector list is in the proven-unused set (normalization identical in PHP and JS). Grouping at-rules recurse; everything else is kept verbatim; any structural surprise ⇒ full stylesheet. Filtered copies are content-hashed files registered in the page's freshness manifest.

### 9.5 Asset versions
Build key (source path + mtime/size + options) → map file `assets/map/<key>` → content-hashed output (`name-<md5(output)>.css|js`). Files served in place get `?v=<md5(content)>`. Touching a file without changing it keeps the URL.

### 9.6 Invalidation additions
* `file:<path>` dependency rows + hourly signature scan ⇒ edits made outside WordPress invalidate only pages using the file.
* Elementor "Regenerate CSS" with external CSS files: no purge; per-page freshness checks detect regenerated files.
* WooCommerce store-display options and settings saves purge (prices/visibility change everywhere).
* Plugin/theme updates still purge everything (code can change any page), followed by warmup.
* Smart warmup (`WPSS_Warmup`): changed URLs (priority 300) > home (200) > popular pages from the hit log (100); `warm_batch` pages/minute, `warm_max` per invalidation, backs off under high load.

### 9.7 Protection & monitoring
* Automatic exclusions are temporary: 7 days, 30 days, then permanent (`wpss_auto_history`).
* Protection events (`wpss_events`): asset/page, dependency group, handle and its dependencies (from `wpss_asset_graph`), status, action. No visitor data.
* Field data: sampled visits beacon LCP/CLS/INP + path + device class to `rum.log`; hourly p75 aggregation.

### 9.8 Known limits (1.1)
* Critical CSS / unused CSS / above-the-fold data exist only for pages an administrator's browser has analyzed (background analysis while using wp-admin, or "Analyze now").
* Rules for content injected later by scripts that never appears in the HTML may still be removed in Balanced/Aggressive unused-CSS modes; protected groups and the Safe mode avoid this. The automatic error detection cannot see purely visual issues.
* Plugin/theme updates purge the whole cache (then warm it).
* Font weight pruning is opt-in; a page that was never analyzed could use a removed weight (browser synthesizes it).
* No particular PageSpeed score can be guaranteed.

### 9.9 Acceptance test log (1.1.0)
WordPress 7.1.2 (+ 6.8.1 back-compat), Elementor 4.4, WooCommerce 11.1, Contact Form 7, Twenty Twenty-One, real Slick 1.8.1 / Owl 2.3.4 / Swiper 8.4.7, GA/GTM/Meta Pixel/Twitter snippets. Headless Chromium 131, desktop 1350×900 + mobile 412×915, Safe / Balanced / Performance modes:
* Final render vs original: 0.000 % pixel difference on every tested page and device.
* First screen with ONLY the inlined critical CSS (async sheets blocked): 0.00 % difference on every page/device.
* CLS equal to or lower than the original; all sliders + Elementor carousel initialize; jQuery init sees fully styled slides; mobile menu works; no JS errors.
* Third-party (Performance): no third-party request before interaction; `fbq()` calls queued and replayed.
* CF7 AJAX submit identical to original; WooCommerce AJAX add-to-cart, cart, block checkout (order placed), My Account; transactional pages never cached, delayed or given critical CSS.
* Elementor save → only that page invalidated, analysis marked stale, new content served; Regenerate CSS → no purge, per-page refresh; editor/preview: original assets only.
* CSS/JS edit → new content-hashed URL, only affected pages regenerate; touch → same URL; hourly scan → targeted invalidation + warmup.
* 1.0.0 → 1.1.0 upgrade: settings, cached pages and exclusions preserved; no PHP warnings from the plugin on any page type.
