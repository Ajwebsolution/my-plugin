=== Steady Speed ===
Contributors: steadyspeed
Tags: cache, performance, minify, elementor, page cache
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Stability-first performance: smart page cache, safe CSS/JS optimization, automatic fallback and emergency rollback.

== Description ==

Steady Speed optimizes a site without breaking it. Priorities, in order: site functionality, layout, JavaScript behaviour, CSS styling, caching, raw speed.

* Page cache with targeted, automatic invalidation (only pages that used the changed post/menu/widget/Elementor document are rebuilt).
* CSS/JS minification into versioned copies (originals are never touched). Safe / Balanced / Aggressive modes; Safe is the default.
* Dependency-safe script deferring via WordPress's own loading strategies; JavaScript is never combined.
* Built-in protection for Elementor, sliders, headers/menus, WooCommerce, form plugins, reCAPTCHA and analytics.
* Client-side fallback: if an optimized file fails, the original loads instantly; repeated failures are auto-excluded.
* Emergency Safe Mode (admin bar, dashboard, or `define( 'WPSS_SAFE_MODE', true );` in wp-config.php).
* Lazy loading, optional WebP, optional font handling, browser caching with automatic rollback, manual database cleanup.
* Debug mode: `?wpss_debug=1` (administrators) shows what was optimized or excluded and why. `?wpss_disable=1` shows the original page.

See ARCHITECTURE.md for the design.

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/ and activate.
2. Open Steady Speed → Dashboard. Defaults are safe; test on staging before Balanced/Aggressive.

= New in 1.1: Advanced performance =

* Performance modes: Safe (default), Balanced (recommended), Performance. A mode only changes performance options.
* Critical CSS per page, separately for desktop and mobile, inlined at each stylesheet's own position; the rest loads asynchronously. Header, navigation, slider, WooCommerce, payment and consent styles always stay render-blocking.
* Remove unused CSS per page (Safe / Balanced / Aggressive). Never applied to Elementor, sliders, navigation, forms, WooCommerce, popups or icon fonts.
* Page analysis runs in an administrator's browser (hidden frame, scripts disabled, desktop + mobile). No external service. An analysis is only used while the page's stylesheets are unchanged and the page has not been edited.
* Third-party delay (analytics, Tag Manager, Meta Pixel, Hotjar, Clarity, chat, reviews, social embeds) on interaction / idle / timeout, with call queues. Never payment, CAPTCHA, consent, login, forms, or anything on cart/checkout/account.
* Delay of non-critical first-party scripts until idle; INP-friendly one-at-a-time execution.
* LCP: the real LCP image is never lazy, gets fetchpriority=high and a single preload (in WebP/AVIF when that is what the browser uses).
* Images: modes Safe / Balanced / Advanced, WebP + AVIF copies (separate files, originals untouched, kept only if smaller), responsive srcset, lazy iframes, reliable width/height with a zero-specificity height:auto guard.
* Fonts: font preload (max 2), font-display swap, optional removal of unused Google Fonts weights (opt-in).
* Content-hashed file names, temporary protection periods (7 days, 30 days, then permanent), protection events with dependency groups, dependency map, smart cache warmup, anonymous Core Web Vitals field data, performance report, compatibility status.

== Frequently Asked Questions ==

= Does Critical CSS need an external service? =

No. Pages are analyzed in your own browser while you use wp-admin (or with "Analyze queued pages now" on the Critical CSS & Analysis tab). Until a page is analyzed it is served with its complete, original CSS.

= Can Steady Speed guarantee a PageSpeed score? =

No. Scores depend on hosting, theme, content and third-party services. The Performance Report shows before/after sizes and real-visitor Core Web Vitals so you can judge the effect.


= Do I need to clear the cache after editing? =
No. Content, menu, widget, Elementor and asset-file changes are detected automatically.

= Something looks wrong. =
Click "Emergency Safe Mode" in the admin bar. Then use Exclusions or the debug view to find the asset.

== Changelog ==

= 1.1.0 =
* Advanced Performance Update (see Description). Existing settings, options, cache files and exclusions are preserved; database version 2 migration adds the new options with Safe defaults.

= 1.0.0 =
* Initial release.


1.2.0 image optimization: added background scanning of wp-content for JPEG/PNG files and generation of smaller WebP/AVIF derivatives. Originals are never modified. Includes uploads, themes and plugins and processes files in small WP-Cron batches.
