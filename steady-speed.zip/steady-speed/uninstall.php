<?php
/**
 * Uninstall: remove every option, transient, table, cron event, server rule and generated file.
 * Original theme/plugin/upload files were never modified, so nothing needs restoring.
 * (Generated .webp/.avif copies next to uploads are kept: they are harmless and may be referenced by other caches.)
 *
 * @package SteadySpeed
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

foreach ( array( 'wpss_settings', 'wpss_safe_mode', 'wpss_log', 'wpss_auto_exclusions', 'wpss_auto_url_exclusions', 'wpss_error_counters', 'wpss_fonts_map', 'wpss_webp_bulk', 'wpss_db_version', 'wpss_cache_counters', 'wpss_browser_cache_status', 'wpss_analysis_queue', 'wpss_font_usage', 'wpss_popular', 'wpss_cwv', 'wpss_cwv_samples', 'wpss_events', 'wpss_auto_history', 'wpss_file_sigs', 'wpss_warm_queue', 'wpss_asset_graph', 'wpss_hit_stats' ) as $wpss_opt ) {
	delete_option( $wpss_opt );
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_wpss_' ) . '%', $wpdb->esc_like( '_transient_timeout_wpss_' ) . '%' ) );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpss_deps" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuerySchemaChange
// phpcs:enable

foreach ( array( 'wpss_cleanup', 'wpss_webp_batch', 'wpss_font_download', 'wpss_warm' ) as $wpss_hook ) {
	wp_clear_scheduled_hook( $wpss_hook );
}

require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/misc.php';
$wpss_htaccess = get_home_path() . '.htaccess';
if ( is_file( $wpss_htaccess ) && wp_is_writable( $wpss_htaccess ) ) {
	insert_with_markers( $wpss_htaccess, 'Steady Speed', array() );
}

$wpss_dir = defined( 'WPSS_CACHE_DIR' ) ? WPSS_CACHE_DIR : WP_CONTENT_DIR . '/cache/steady-speed';
if ( is_dir( $wpss_dir ) && WP_Filesystem() ) {
	global $wp_filesystem;
	if ( 'direct' === $wp_filesystem->method && 0 === strpos( wp_normalize_path( $wpss_dir ), wp_normalize_path( WP_CONTENT_DIR ) . '/cache/' ) ) {
		$wp_filesystem->delete( $wpss_dir, true );
	}
}
