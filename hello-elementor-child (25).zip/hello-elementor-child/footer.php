<footer>
    <div class="footer-logo">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/bottom-logo.png" alt="Footer Logo">
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
