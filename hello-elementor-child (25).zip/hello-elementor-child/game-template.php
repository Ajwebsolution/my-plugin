<?php
/**
 * Template Name: Game Template
 * Description: Custom template for the game page
 */

get_header(); ?>

<div class="urban-game-template">

    <header class="header">
        <nav class="nav custom-navbar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="nav-logo">
                            <a href="<?php echo home_url(); ?>">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <section class="main-content-form">
        <div class="container-fluid">
            <div class="main-content-form-inner">

                <div class="form-inner">
                    <!-- Team Form -->
                    <div id="teamName-form" style="display:block">
                        <div class="title">
                            <h1><?php the_field('start_game_title'); ?></h1>
                        </div>
                        <div class="form-bg form-layout teamName-form-layout">
                            <form action="">
                                <div class="form-group">
                                    <input type="text" id="team1Name" placeholder="Enter your team name"
                                        class="form-control" maxlength="20">
                                </div>
                                <div class="form-group">
                                    <input type="text" id="team2Name" placeholder="Enter your team name"
                                        class="form-control" maxlength="20">
                                </div>
                                <div class="submit-btn">
                                    <button type="submit" class="default-btn w-100" disabled>Start Game</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Scoreboard -->
                    <div class="form-bg form-layout scoreboard-form-layout" id="scoreboard-form" style="display:none">
                        <div class="form-title">
                            <h1>Scoreboard</h1>
                        </div>
                        <div class="table-wrapper">
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th>Frame</th>
                                        <?php for ($i = 1; $i <= 10; $i++): ?>
                                            <th><?php echo $i; ?></th>
                                        <?php endfor; ?>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr data-team="1">
                                        <td class="teamName1">Team 1</td>
                                        <?php for ($i = 1; $i <= 10; $i++): ?>
                                            <td class="frame-score <?php echo $i == 1 ? 'highlight' : ''; ?>"
                                                data-frame="<?php echo $i; ?>"></td>
                                        <?php endfor; ?>
                                        <td class="totalScore">0</td>
                                    </tr>
                                    <tr data-team="2">
                                        <td class="teamName2">Team 2</td>
                                        <?php for ($i = 1; $i <= 10; $i++): ?>
                                            <td class="frame-score <?php echo $i == 1 ? 'highlight' : ''; ?>"
                                                data-frame="<?php echo $i; ?>"></td>
                                        <?php endfor; ?>
                                        <td class="totalScore">0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="submit-btn text-center">
                            <button type="button" class="default-btn" id="scoredBtn">Enter Frame 1 Score</button>
                        </div>
                    </div>

                    <!-- Winner Frame -->
                    <div class="form-bg form-layout winnerFramePopup-form-layout" id="frameWinner-form"
                        style="display:none">
                        <div class="title">
                            <h2>Who Won Frame <span id="framCount">1</span>?</h2>
                        </div>
                        <form>
                            <div class="form-group">
                                <button type="button" class="default-btn w-100" id="selectTeam1"></button>
                            </div>
                            <div class="form-group">
                                <button type="button" class="default-btn w-100" id="selectTeam2"></button>
                            </div>
                            <div class="submit-btn text-center">
                                <button type="button" class="default-btn w-100 secondary-btn" id="noScore" value="0">NO
                                    Score</button>
                            </div>
                        </form>
                    </div>

                    <!-- Score Number -->
                    <div class="form-bg form-layout winnerFramePopup-form-layout" id="scoreNumber-form"
                        style="display:none">
                        <div class="title">
                            <h2>Scores</h2>
                        </div>
                        <div class="number-grid">
                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                <button class="number-btn" value="<?php echo $i; ?>"><?php echo $i; ?></button>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <!-- Winner Announcement -->
                    <div class="form-bg form-layout winner-announcment-form-layout" id="winnerAnnoucment"
                        style="display:none">
                        <div class="congrats-container">
                            <div class="emoji">🎉</div>
                            <h2 class="congrats-heading">Congratulations!</h2>
                            <div class="winner-card">
                                <p class="winner-label">Winner:</p>
                                <p class="winner-name"></p>
                                <p class="winner-score">Final Score: <span class="finalscore"></span></p>
                            </div>
                        </div>
                        <div class="qr-section">
                            <div class="price-annoucement">
                                <h4>You Won: <span class="theme-color"><?php the_field('before_spin_own'); ?></span></h4>
                            </div>
                            <div class="qr-im">
                                <img src="<?php the_field('before_spin_qr'); ?>" alt="">
                            </div>
                        </div>
                        <p class="congrats-msg"><?php the_field('congrats_message'); ?></p>
                        <?php echo do_shortcode('[custom_airship_form]'); ?>
                    </div>

                    <!-- Draw Popup -->
                    <div class="form-bg form-layout winnerFramePopup-form-layout" id="drawPopup-form"
                        style="display:none">
                        <div class="title">
                            <h2>It's A Draw! Play An Additional Frame</h2>
                            <h5>Who won the deciding frame?</h5>
                        </div>
                        <form>
                            <div class="form-group">
                                <button type="button" class="default-btn w-100" id="selectTeam1Winner"></button>
                            </div>
                            <div class="form-group">
                                <button type="button" class="default-btn w-100" id="selectTeam2Winner"></button>
                            </div>
                        </form>
                    </div>
                    <!-----Draw Popup------>
                    <!-- Final Score Board Popup  -->
                    <div class="final-scores-container form-bg form-layout" id="FinaleScore-form" style="display:none">
                        <div class="section-header">
                            <h1 class="final-title">Final Scores</h1>
                        </div>

                        <div class="winner-section">
                            <h2 class="winner-text"> <span class="winner-text-inner"></span> Is The Winner!</h2>
                            <div class="winner-bg"></div>

                            <!-- spinner lines -->
                            <div class="spinner-line" style="--rotate:0deg; --delay:0s;"></div>
                            <div class="spinner-line" style="--rotate:45deg; --delay:0.1s;"></div>
                            <div class="spinner-line" style="--rotate:90deg; --delay:0.2s;"></div>
                            <div class="spinner-line" style="--rotate:135deg; --delay:0.3s;"></div>
                            <div class="spinner-line" style="--rotate:180deg; --delay:0.4s;"></div>
                            <div class="spinner-line" style="--rotate:225deg; --delay:0.5s;"></div>
                            <div class="spinner-line" style="--rotate:270deg; --delay:0.6s;"></div>
                            <div class="spinner-line" style="--rotate:315deg; --delay:0.7s;"></div>
                        </div>


                        <div class="score-table-wrapper">
                            <table class="score-table">
                                <thead>
                                    <tr>
                                        <th>Team</th>
                                        <th>Final Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><span class="oneTeam"></span></td>
                                        <td class="totalScore1">0</td>
                                    </tr>
                                    <tr class="highlight">
                                        <td><span class="twoTeam"></span></td>
                                        <td class="totalScore2">0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="action-buttons">
                            <button class="default-btn w-100 " id="playBonusGame">
                                <span>Play Bonus Game</span>
                                <div class="shine"></div>
                            </button>
                            <a href="">
                                <div class="form-group text-center">
                                    <button class="default-btn secondary-btn">Start New Game</button>
                                </div>
                            </a>>
                        </div>
                    </div>
                    <!-- Final Score Board Popup  -->
                    <!-- Form 5  -->
                    <!-- Bonus Game Popup -->
                    <div class="bonusGame-form-layout" id="BonusGamePopUp" style="display:none">
                        <div class="bonus-game">
                            <!-- Header -->
                            <div class="bonus-header">
                                <h1>Bonus Game</h1>
                            </div>

                            <!-- Instructions -->
                            <div class="instructions">
                                <p class="main">Spin the wheel to win a prize!</p>
                                <p class="sub">Tap the SPIN button to start</p>
                            </div>

                            <!-- Wheel -->
                            <div class="wheel-container">
                                <div class="wheel-wrapper">

                                    <div class="wheel" id="wheel">
                                        <?php
                                        if (have_rows('price_list')):
                                            $offers = get_field('price_list');
                                            $count = count($offers);
                                            $anglePerSlice = 360 / $count;
                                            $i = 0;
                                            $colors = ['#ff7100', '#ff9500', '#333', '#555'];

                                            while (have_rows('price_list')):
                                                the_row();

                                                $offer = get_sub_field('spin_offers');
                                                $qr = get_sub_field('price_qr_image');

                                                $qty = get_sub_field('total_quantity');
                                                $wins = get_sub_field('wins_per_spins');

                                                $color = $colors[$i % count($colors)];
                                                $rotation = $i * $anglePerSlice;
                                                ?>

                                                <div class="wheel-segment" data-prize="<?= sanitize_title($offer) ?>"
                                                    data-qr="<?= esc_url($qr) ?>" data-index="<?= $i ?>"
                                                    data-qty="<?= intval($qty) ?>" data-maxwins="<?= intval($wins) ?>"
                                                    data-spinsdone="<?= intval(get_sub_field('spins_done')) ?>"
                                                    data-slug="<?= sanitize_title($offer) ?>" style="transform: rotate(<?= $rotation ?>deg) skewY(-<?= 90 - $anglePerSlice ?>deg);
                                                     background: <?= esc_attr($color) ?>;">
                                                    <span><?= esc_html($offer) ?></span>
                                                </div>



                                                <?php
                                                $i++;
                                            endwhile;

                                        endif;
                                        ?>
                                    </div>



                                    <div class="wheel-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="2rem" height="2rem"
                                            viewBox="0 0 24 24">
                                            <path fill="#ff7100" fill-rule="evenodd"
                                                d="M19 13a1 1 0 0 0 .707-1.707l-7-7a1 1 0 0 0-1.414 0l-7 7A1 1 0 0 0 5 13h6v6a1 1 0 1 0 2 0v-6z"
                                                clip-rule="evenodd" stroke-width="0.5" stroke="#ff7100" />
                                        </svg>
                                    </div>
                                    <div class="wheel-pointer"></div>
                                    <!-- ✅ NEW HIGHLIGHT POINTER -->
                                    <div class="wheel-pointer-highlight"></div>
                                </div>

                                <!-- Spin Button -->
                                <button class="default-btn spin-btn">Spin to Win!</button>

                                <!-- Prize List -->
                                <div class="prizes">
                                    <h3>Available Prizes</h3>
                                    <div class="prize-grid">
                                        <?php if (have_rows('price_list')):
                                            $i = 0; ?>
                                            <?php while (have_rows('price_list')):
                                                the_row();
                                                $offer = get_sub_field('spin_offers');
                                                $colors = ['#ff7100', '#ff9500', '#333', '#555'];
                                                $color = $colors[$i % count($colors)];
                                                ?>
                                                <div class="prize-item">
                                                    <div class="prize-dot" style="background:<?php echo esc_attr($color); ?>">
                                                    </div>
                                                    <?php echo esc_html($offer); ?>
                                                </div>
                                                <?php $i++; endwhile; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Last Pop up -->
                    <div class="form-bg form-layout last-pop-up" id="LastPopUp" style="display:none">
                        <div class="congrats-container">
                            <div class="emoji">🎉</div>
                            <h2 class="congrats-heading">Congratulations!</h2>
                        </div>
                        <div class="qr-section">
                            <div class="price-annoucement border-none">
                                <h3>You Won: </h3>
                                <h3 class="theme-color">VIP Seating</h3> <!-- This will be updated by JS -->
                            </div>
                            <div class="qr-im">
                                <img id="winnerQr" src="" alt="QR Code">
                            </div>
                        </div>
                        <a href="">
                            <div class="form-group text-center">
                                <button class="default-btn secondary-btn">Start New Game</button>
                            </div>
                        </a>>
                    </div>
                    <!--  Last Pop up  -->
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-logo text-center">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/bottom-logo.png" alt="">
        </div>
    </footer>

</div><!-- .urban-game-template -->

<?php get_footer(); ?>