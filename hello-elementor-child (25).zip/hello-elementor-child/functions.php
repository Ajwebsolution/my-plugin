<?php
/**
 * Enqueue Parent + Child + Extra CSS & JS
 */
function child_theme_enqueue_styles() {
    // Parent + Child CSS
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style') );
    wp_enqueue_style( 'bootstrap-css', get_stylesheet_directory_uri() . '/css/bootstrap.min.css', array('child-style'), null );
    wp_enqueue_style( 'custom-style', get_stylesheet_directory_uri() . '/css/style.css', array('bootstrap-css'), null );
    wp_enqueue_style( 'responsive-style', get_stylesheet_directory_uri() . '/css/responsive.css', array('custom-style'), null );

    // Scripts
    wp_enqueue_script( 'jquery' );
	// Custom jQuery (if you need your own copy instead of WP’s default)
    wp_enqueue_script( 'jquery-custom', get_stylesheet_directory_uri() . '/js/jquery.min.js', array(), null, true );
    wp_enqueue_script( 'popper-js', get_stylesheet_directory_uri() . '/js/popper.min.js', array('jquery'), null, true );
    wp_enqueue_script( 'bootstrap-js', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array('jquery','popper-js'), null, true );
    wp_enqueue_script( 'custom-js', get_stylesheet_directory_uri() . '/js/custom.js', array('jquery'), null, true );

     // Localize AJAX
    wp_localize_script('custom-js', 'ajax_object', array(
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}
add_action( 'wp_enqueue_scripts', 'child_theme_enqueue_styles', 999 );




// -----------------------------
// CUSTOM AIRSHIP SHORTCODE
// -----------------------------
function custom_airship_form_shortcode() {
    ob_start(); ?>

  <form id="customAirshipForm" method="post">
        <div class="form-group">
            <input type="text" name="first_name" required class="form-control" placeholder="Enter your full name">
        </div>
        <div class="form-group">
            <input type="email" name="email" required class="form-control" placeholder="Enter your email">
        </div>
        <!-- NEW: Hidden fields for score data -->
             <input type="hidden" name="game_score" id="game_score" value="">
        <button type="submit" name="airship_submit" class="default-btn w-100 text-center">Submit</button>
    </form>
    <div id="airshipResponse"></div>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_airship_form', 'custom_airship_form_shortcode');


// -----------------------------
// AJAX HANDLER FOR AIRSHIP FORM
// -----------------------------
add_action('wp_ajax_submit_airship_form', 'handle_airship_form_ajax');
add_action('wp_ajax_nopriv_submit_airship_form', 'handle_airship_form_ajax');

function handle_airship_form_ajax() {

    if (!isset($_POST['first_name'], $_POST['email'], $_POST['game_score'])) {
        wp_send_json_error(['message' => 'Missing required fields']);
    }

    $first_name = sanitize_text_field($_POST['first_name']);
    $email      = sanitize_email($_POST['email']);
    $game_score = sanitize_text_field($_POST['game_score']); // ← NEW

    // ---------------------------------------------
    // 1. SEND DATA TO AIRSHIP (now includes score)
    // ---------------------------------------------

    $payload = [
        "form_id" => 2251799840000029,
        "first_name" => $first_name,
        "email" => $email,
        "udfs" => [
            [
                "id" => "game_score",
                "value" => $game_score
            ]
        ]
    ];

    if (!defined('AIRSHIP_API_TOKEN')) {
        wp_send_json_error(['message' => 'API token not defined']);
    }

    $response = wp_remote_post('https://api.airship.co.uk/v1/public/contact', [
        'headers' => [
            'Authorization' => 'Bearer ' . AIRSHIP_API_TOKEN,
            'Content-Type'  => 'application/json'
        ],
        'body' => json_encode($payload),
        'timeout' => 20
    ]);

    // ---------------------------------------------
    // 2. SEND EMAIL TO USER
    // ---------------------------------------------
    $subject = "Your Mini Ice Curling Game Score!";
    $message = "Hi $first_name,<br><br>"
             . "Thank you for playing Mini Ice Curling!<br>"
             . "Your final score is: <strong>$game_score</strong><br><br>"
             . "Regards,<br>Urban Fun Team";

    add_filter('wp_mail_content_type', function() { return 'text/html'; });

    wp_mail($email, $subject, $message);

    remove_filter('wp_mail_content_type', 'set_html_content_type');

    // ---------------------------------------------
    // 3. FINAL RESPONSE
    // ---------------------------------------------
    wp_send_json_success([
        'message' => 'Score submitted, Airship updated, and email sent!'
    ]);
}











add_action("wp_ajax_reduce_spin_stock", "reduce_spin_stock");
add_action("wp_ajax_nopriv_reduce_spin_stock", "reduce_spin_stock");

function reduce_spin_stock() {

    if (!isset($_POST['prize_slug'])) {
        wp_send_json_error("Missing prize slug");
    }

    $slug = sanitize_text_field($_POST['prize_slug']);
    $page_id = 10; 

    $rows = get_field('price_list', $page_id);

    if ($rows) {
        foreach ($rows as $i => $row) {

            // Compare slug with sanitized spin offer
            if (sanitize_title($row['spin_offers']) == $slug) {

                $qty = intval($row['total_quantity']); // MATCHES ACF FIELD NAME

                if ($qty > 0) {
                    $qty--; // reduce stock

                    update_sub_field(
                        ['price_list', $i + 1, 'total_quantity'],  // correct field
                        $qty,
                        $page_id
                    );
                }

            }
        }
    }

    wp_send_json_success("Stock updated");
}






// add_action("wp_ajax_update_spin_done", "update_spin_done");
// add_action("wp_ajax_nopriv_update_spin_done", "update_spin_done");

// function update_spin_done() {

//     $page_id = 10;
//     $rows = get_field('price_list', $page_id);

//     if ($rows) {
//         foreach ($rows as $i => $row) {

//             $spinsDone = intval($row['spins_done']);
//             $maxWins   = intval($row['wins_per_spins']);

         
//             $spinsDone++;

          
//             if ($spinsDone >= $maxWins) {
//                 $spinsDone = 0;
//             }

//             update_sub_field(
//                 ['price_list', $i + 1, 'spins_done'],
//                 $spinsDone,
//                 $page_id
//             );
//         }
//     }

//     wp_send_json_success("Spins updated for all rows");
// }

add_action("wp_ajax_update_spin_done", "update_spin_done");
add_action("wp_ajax_nopriv_update_spin_done", "update_spin_done");

function update_spin_done() {
    $page_id = 10;
    $rows = get_field('price_list', $page_id);
    
    // Check if we need to reset all spins_done to 0
    $reset_all_spins = false;
    
    if ($rows) {
        // Find the highest wins_per_spins value
        $highest_wins = 0;
        $current_highest_index = -1;
        
        foreach ($rows as $i => $row) {
            $maxWins = intval($row['wins_per_spins']);
            if ($maxWins > $highest_wins) {
                $highest_wins = $maxWins;
                $current_highest_index = $i;
            }
        }
        
        // Update spins for all rows
        foreach ($rows as $i => $row) {
            $spinsDone = intval($row['spins_done']);
            $maxWins = intval($row['wins_per_spins']);
            
            $spinsDone++;
            
            // Check if current row has the highest wins_per_spins AND reached its limit
            if ($i == $current_highest_index && $spinsDone >= $maxWins) {
                $reset_all_spins = true;
            }
            
            // If not resetting all, handle normal reset for this row
            if (!$reset_all_spins) {
                if ($spinsDone >= $maxWins) {
                    $spinsDone = 0;
                }
            }
            
            update_sub_field(
                ['price_list', $i + 1, 'spins_done'],
                $spinsDone,
                $page_id
            );
        }
        
        // If we need to reset all spins_done to 0
        if ($reset_all_spins) {
            foreach ($rows as $i => $row) {
                update_sub_field(
                    ['price_list', $i + 1, 'spins_done'],
                    0, // Reset to 0 for all rows
                    $page_id
                );
            }
            
            wp_send_json_success("Highest wins reached! All spins_done reset to 0");
        } else {
            wp_send_json_success("Spins updated for all rows");
        }
    } else {
        wp_send_json_error("No rows found");
    }
}