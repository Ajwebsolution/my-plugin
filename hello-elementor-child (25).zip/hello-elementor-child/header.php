<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title(); ?></title>
 
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<header class="header">
    <nav class="nav custom-navbar">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="nav-logo">
                        <a href="<?php echo home_url(); ?>">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo.png" alt="Logo">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>
