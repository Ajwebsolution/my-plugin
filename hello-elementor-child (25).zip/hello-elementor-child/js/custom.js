$(document).ready(function () {
  // -----------------------------
  // SCOREBOARD VARIABLES
  // -----------------------------
  let currentFrame = 1;
  let scores = { team1: Array(10).fill(0), team2: Array(10).fill(0) };
  let selectedTeam = null;
  let manualWinner = null;

  // -----------------------------
  // HIGHLIGHT CURRENT FRAME
  // -----------------------------
  function highlightCurrentFrame() {
    $(".frame-score").removeClass("highlight");
    $(`.frame-score[data-frame='${currentFrame}']`).addClass("highlight");
  }

  // -----------------------------
  // ENABLE/DISABLE BUTTONS BASED ON INPUT
  // -----------------------------
  $(".teamName-form-layout .form-control").on("input", function () {
    let allFilled = $(".teamName-form-layout .form-control")
      .toArray()
      .every((inp) => $(inp).val().trim() !== "");
    $("#teamName-form .default-btn")
      .prop("disabled", !allFilled)
      .toggleClass("disabled", !allFilled);
  });

  $(".winner-announcment-form-layout .form-control").on("input", function () {
    let allFilled = $(".winner-announcment-form-layout .form-control")
      .toArray()
      .every((inp) => $(inp).val().trim() !== "");
    $("#winnerAnnoucment .default-btn")
      .prop("disabled", !allFilled)
      .toggleClass("disabled", !allFilled);
  });

  // -----------------------------
  // TEAM NAME FORM SUBMIT
  // -----------------------------
  $("#teamName-form form").on("submit", function (e) {
    e.preventDefault();
    $("#teamName-form").hide();
    $("#scoreboard-form").show();

    let team1Name = $("#team1Name").val().trim();
    let team2Name = $("#team2Name").val().trim();

    $("tr[data-team='1'] .teamName1").text(team1Name);
    $("tr[data-team='2'] .teamName2").text(team2Name);

    $("#selectTeam1, .oneTeam").text(team1Name).val(team1Name);
    $("#selectTeam2, .twoTeam").text(team2Name).val(team2Name);

    $("#scoredBtn").text(`Enter Frame ${currentFrame} Score`);
    $("#framCount").text(`${currentFrame}`);

    highlightCurrentFrame();
  });

  // -----------------------------
  // START FRAME SCORING
  // -----------------------------
  $("#scoredBtn").on("click", function () {
    if ($(this).text() === "End Game") {
      showWinnerPopup();
      return;
    }
    $("#scoreboard-form").hide();
    $("#frameWinner-form").show();
    $("<div>", { class: "overlay" }).insertAfter("#frameWinner-form");
  });

  // -----------------------------
  // SELECT WINNING TEAM FOR FRAME
  // -----------------------------
  $("#selectTeam1, #selectTeam2").on("click", function () {
    selectedTeam = $(this).attr("id") === "selectTeam1" ? "team1" : "team2";
    $("#frameWinner-form").hide();
    $("#scoreNumber-form").show();
    $("<div>", { class: "overlay" }).insertAfter("#frameWinner-form");
  });

  // -----------------------------
  // ADD FRAME SCORE
  // -----------------------------
  $(".number-btn").on("click", function (e) {
    e.preventDefault();
    let scoreValue = parseInt($(this).val());

    if (selectedTeam && scoreValue >= 0) {
      let opponentTeam = selectedTeam === "team1" ? "team2" : "team1";

      $(`tr[data-team='${selectedTeam === "team1" ? 1 : 2}']`)
        .find(`.frame-score[data-frame='${currentFrame}']`)
        .text(scoreValue);
      scores[selectedTeam][currentFrame - 1] = scoreValue;

      $(`tr[data-team='${opponentTeam === "team1" ? 1 : 2}']`)
        .find(`.frame-score[data-frame='${currentFrame}']`)
        .text(0);
      scores[opponentTeam][currentFrame - 1] = 0;

      updateTotalsAndNextFrame();
    }
  });

  // -----------------------------
  // NO SCORE OPTION
  // -----------------------------
  $("#noScore").on("click", function () {
    $("tr[data-team='1']").find(`.frame-score[data-frame='${currentFrame}']`).text(0);
    $("tr[data-team='2']").find(`.frame-score[data-frame='${currentFrame}']`).text(0);

    scores.team1[currentFrame - 1] = 0;
    scores.team2[currentFrame - 1] = 0;

    updateTotalsAndNextFrame();
  });

  // -----------------------------
  // UPDATE TOTALS & NEXT FRAME
  // -----------------------------
  function updateTotalsAndNextFrame() {
    let total1 = scores.team1.reduce((a, b) => a + b, 0);
    let total2 = scores.team2.reduce((a, b) => a + b, 0);

    $("tr[data-team='1'] .totalScore").text(total1);
    $("tr[data-team='2'] .totalScore").text(total2);

    if (currentFrame >= 10) {
      $(".frame-score").removeClass("highlight");
      $("#scoredBtn").text("End Game").addClass("endTask");
    } else {
      currentFrame++;
      $("#scoredBtn").text(`Enter Frame ${currentFrame} Score`);
      $("#framCount").text(`${currentFrame}`);
      highlightCurrentFrame();
    }

    $(".form-layout").hide();
    $(".overlay").remove();
    $("#scoreboard-form").show();
  }

  // -----------------------------
  // SHOW WINNER POPUP
  // -----------------------------
  function showWinnerPopup() {
    let total1 = scores.team1.reduce((a, b) => a + b, 0);
    let total2 = scores.team2.reduce((a, b) => a + b, 0);

    $(".score-table tbody tr").removeClass("highlight");

    if (total1 > total2) {
      openWinnerPopup($("tr[data-team='1'] .teamName1").text(), total1);
    } else if (total2 > total1) {
      openWinnerPopup($("tr[data-team='2'] .teamName2").text(), total2);
    } else {
      let team1Name = $("#team1Name").val().trim();
      let team2Name = $("#team2Name").val().trim();

      $("#selectTeam1Winner").text(team1Name).val("team1");
      $("#selectTeam2Winner").text(team2Name).val("team2");

      $("#scoreboard-form").hide();
      $("#drawPopup-form").show();
      $("<div>", { class: "overlay" }).insertAfter("#drawPopup-form");

      $("#selectTeam1Winner").off("click").on("click", function () {
        manualWinner = "team1";
        openExtraScorePopup();
      });

      $("#selectTeam2Winner").off("click").on("click", function () {
        manualWinner = "team2";
        openExtraScorePopup();
      });
    }
  }

  function openExtraScorePopup() {
    $("#drawPopup-form").hide();
    $("#scoreNumber-form").show();
    $(".overlay").remove();
    $("<div>", { class: "overlay" }).insertAfter("#scoreNumber-form");

    $(".number-btn").off("click").on("click", function (e) {
      e.preventDefault();
      let extra = parseInt($(this).val());

      if (manualWinner === "team1") {
        scores.team1.push(extra);
      } else {
        scores.team2.push(extra);
      }

      let total1 = scores.team1.reduce((a, b) => a + b, 0);
      let total2 = scores.team2.reduce((a, b) => a + b, 0);

      $("#scoreNumber-form").hide();
      $(".overlay").remove();

      openWinnerPopup(
        manualWinner === "team1"
          ? $("tr[data-team='1'] .teamName1").text()
          : $("tr[data-team='2'] .teamName2").text(),
        manualWinner === "team1" ? total1 : total2
      );
    });
  }

  function openWinnerPopup(winnerText, score) {
    let total1 = scores.team1.reduce((a, b) => a + b, 0);
    let total2 = scores.team2.reduce((a, b) => a + b, 0);

    $("#scoreboard-form").hide();
    $("#winnerAnnoucment").show();
    $(".totalScore1").text(total1);
    $(".totalScore2").text(total2);

    if (total1 > total2) {
      $(".score-table tbody tr:eq(0)").addClass("highlight");
    } else if (total2 > total1) {
      $(".score-table tbody tr:eq(1)").addClass("highlight");
    }

    $(".winner-name, .winner-text-inner").text(winnerText);
    $(".finalscore").text(score);

    $("<div>", { class: "overlay winning-bg" }).insertAfter("#winnerAnnoucment");
  }

  // -----------------------------
  // WINNER FORM AJAX
  // -----------------------------
 // -----------------------------
// WINNER FORM AJAX (UPDATED)
// -----------------------------
$("#customAirshipForm").on("submit", function (e) {
    e.preventDefault();

    let form = $(this);

    // GET TOTAL SCORE BEFORE SUBMIT
    let totalFinalScore =
      scores.team1.reduce((a, b) => a + b, 0) +
      scores.team2.reduce((a, b) => a + b, 0);

    // Or if you want only winning team score:
    // let finalWinnerScore = $(".finalscore").text().trim();

    let data = {
        action: "submit_airship_form",
        first_name: form.find("input[name='first_name']").val(),
        email: form.find("input[name='email']").val(),
        game_score: totalFinalScore,  // ← ★ SEND FINAL SCORE ★
    };

    // Set hidden input for PHP (optional)
    $("#game_score").val(totalFinalScore);

    $.ajax({
      url: ajax_object.ajaxurl,
      method: "POST",
      data: data,
      dataType: "json",
      success: function (response) {
        if (response.success) {
          $("#airshipResponse").html(
            '<p style="color:green;">' + response.data.message + "</p>"
          );
          form.hide();

          if ($("#winnerAnnoucment").is(":visible")) {
            $("#winnerAnnoucment").hide();
          }

          // Move to final popup
          $("#FinaleScore-form").show();
        } else {
          $("#airshipResponse").html(
            '<p style="color:red;">' + response.data.message + "</p>"
          );
        }
      },
      error: function () {
        $("#airshipResponse").html(
          '<p style="color:red;">AJAX error occurred.</p>'
        );
      },
    });
});


  // -----------------------------
  // BONUS SPIN GAME WITH POINTER NUDGE
  // -----------------------------
function initSpinGame(popupSelector, resultPopupSelector) {
    const popup = document.querySelector(popupSelector);
    if (!popup) return;

    const wheel = popup.querySelector(".wheel");
    const spinBtn = popup.querySelector(".spin-btn");
    const pointer = popup.querySelector(".wheel-pointer");
    const segments = popup.querySelectorAll(".wheel-segment");
    const prizeItems = popup.querySelectorAll(".prize-grid .prize-item");

    if (!wheel || !spinBtn || !pointer || !segments.length) return;

    let hasSpun = false;
    let wheelSpinning = false;
    const prizes = Array.from(prizeItems).map(item => item.textContent.trim());

    // Create highlight pointer if not exists
    let highlightPointer = popup.querySelector(".wheel-pointer-highlight");
    if (!highlightPointer) {
        highlightPointer = document.createElement("div");
        highlightPointer.className = "wheel-pointer-highlight";
        wheel.appendChild(highlightPointer);
    }

    highlightPointer.style.opacity = 0; // hidden initially
    highlightPointer.style.transform = "translateX(-50%) rotate(0deg) scale(0)";

    function nudgePointer() {
        pointer.classList.add("nudge");
        setTimeout(() => pointer.classList.remove("nudge"), 1000);
    }

   function spinWheel() {
    if (hasSpun || wheelSpinning) return;
    hasSpun = true;
    wheelSpinning = true;

    $(spinBtn).prop("disabled", true).addClass("disabled");
    $(segments).removeClass("highlighted");

     // -------------------------------
    // FILTER ELIGIBLE SEGMENTS
    // -------------------------------
    const eligibleSegments = Array.from(segments).filter(seg => {
        const maxWins = parseInt(seg.dataset.maxwins) || 1;
        const spinsDone = parseInt(seg.dataset.spinsdone) || 0;
        const qty = parseInt(seg.dataset.qty) || 0;

        // Segment is eligible if qty > 0 AND spins done + 1 >= maxWins
        return qty > 0 && (spinsDone + 1 >= maxWins);
    });

    // Pick winning segment WITH PRIORITY
    let winningSegment;
    if (eligibleSegments.length > 0) {
        // Sort eligible segments by maxWins (highest first) for priority
        eligibleSegments.sort((a, b) => {
            const aWins = parseInt(a.dataset.maxwins) || 1;
            const bWins = parseInt(b.dataset.maxwins) || 1;
            return bWins - aWins; // Higher wins first
        });
        
        // Always pick the first one (highest priority)
        winningSegment = eligibleSegments[0];
    } else {
        // fallback to fully random if no segment eligible
        winningSegment = segments[Math.floor(Math.random() * segments.length)];
    }

    const winningIndex = Array.from(segments).indexOf(winningSegment);
    const prizesCount = segments.length;
    const segmentSize = 360 / prizesCount;

    // -------------------------------
    // CALCULATE ROTATION
    // -------------------------------
    const fullRotations = 4 + Math.floor(Math.random() * 3);
    const targetRotation = segmentSize * (prizesCount - 1 - winningIndex) + segmentSize / 2;
    const totalRotation = (fullRotations * 360) + targetRotation;

    wheel.style.transition = "transform 5s cubic-bezier(0.17, 0.67, 0.21, 0.99)";
    wheel.style.transform = `rotate(${totalRotation}deg)`;

    wheel.addEventListener("transitionend", function handler() {
        wheel.removeEventListener("transitionend", handler);
        wheelSpinning = false;
        $(spinBtn).prop("disabled", false).removeClass("disabled");

        const winningPrize = winningSegment.dataset.prize;
        const winningQR = winningSegment.dataset.qr;

        $(segments).removeClass("highlighted");
        $(winningSegment).addClass("highlighted");

        // Hide original pointer
        pointer.style.opacity = 0;

        // -------------------------------
        // AJAX → Reduce Stock
        // -------------------------------
        $.ajax({
            url: ajax_object.ajaxurl,
            type: "POST",
            data: {
                action: "reduce_spin_stock",
                prize_slug: winningPrize
            },
            success: function (response) {
                console.log("Stock Updated:", response);
            },
            error: function () {
                console.log("Error updating stock");
            }
        });

        // -------------------------------
        // AJAX → Update Spins Done
        // -------------------------------
       // AJAX → Update Spins Done
            $.ajax({
            url: ajax_object.ajaxurl,
            type: "POST",
            data: {
                action: "update_spin_done",
                prize_slug: winningPrize
            },
            success: function (response) {
                console.log("Spins Done Updated:", response);

                // 🔥 FIX: Update the DOM attribute immediately
                winningSegment.dataset.spinsdone = 0;
            },
            error: function () {
                console.log("Error updating spins done");
            }
        });


        // Highlight pointer animation
        highlightPointer.style.transition = "transform 0.8s ease-out, opacity 0.8s ease-out";
        highlightPointer.style.transform = `translateX(-50%) rotate(${targetRotation}deg) scale(1)`;
        highlightPointer.style.opacity = 1;

        setTimeout(() => {
            pointer.classList.add("nudge");
            setTimeout(() => pointer.classList.remove("nudge"), 1000);
        }, 200);

        // Show result popup
        setTimeout(() => {
            const resultPopup = document.querySelector(resultPopupSelector);
            if (resultPopup) {
                const prizeEl = resultPopup.querySelector(".theme-color");
                if (prizeEl) prizeEl.textContent = winningPrize;

                const qrImg = resultPopup.querySelector("#winnerQr");
                if (qrImg && winningQR) qrImg.src = winningQR;
            }

            $(".overlay").remove();
            $(resultPopup).show();
            $("<div>", { class: "overlay winning-bg" }).insertAfter(resultPopupSelector);
            $(popup).hide();
        }, 2000);
    });
}

    $(spinBtn).off("click").on("click", spinWheel);
}



  // Trigger when bonus game opens
  $("#playBonusGame").on("click", function (e) {
    e.preventDefault();
    $("#FinaleScore-form").hide();
    $("#BonusGamePopUp").show();
    $("<div>", { class: "overlay" }).insertAfter("#BonusGamePopUp");
    initSpinGame("#BonusGamePopUp", "#LastPopUp");
  });
});
