<?php
/*
Plugin Name: Custom Post Type Slug Manager
Description: Change base slug for Posts and all Custom Post Types dynamically.
Version: 2.0
Author: Amit
*/

if (!defined('ABSPATH')) exit;


/* =========================
   GET POST TYPES (SAFE)
========================= */
function cpsm_get_post_types() {

    $cpts = get_post_types([
        'public' => true,
        '_builtin' => false
    ], 'objects');

    // Manually include default post type
    $cpts['post'] = get_post_type_object('post');

    return $cpts;
}


/* =========================
   ADMIN MENU
========================= */
add_action('admin_menu', function() {
    add_options_page(
        'CPT Slug Manager',
        'CPT Slug Manager',
        'manage_options',
        'cpsm-settings',
        'cpsm_settings_page'
    );
});


/* =========================
   SETTINGS PAGE UI
========================= */
function cpsm_settings_page() {
    $post_types = cpsm_get_post_types();
    ?>
    <div class="wrap">
        <h1>Custom Post Type Slug Manager</h1>

        <form method="post" action="options.php">
            <?php settings_fields('cpsm_settings_group'); ?>

            <table class="form-table">
                <?php foreach ($post_types as $pt): 
                    $option_name = 'cpsm_slug_' . $pt->name;
                    $default = $pt->rewrite['slug'] ?? $pt->name;
                    $value = get_option($option_name, $default);
                ?>
                <tr>
                    <th><?php echo esc_html($pt->labels->name); ?></th>
                    <td>
                        <input type="text" name="<?php echo esc_attr($option_name); ?>" value="<?php echo esc_attr($value); ?>" />
                        <p>Example: news, blog, products</p>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}


/* =========================
   REGISTER SETTINGS
========================= */
add_action('admin_init', function() {

    $post_types = cpsm_get_post_types();

    foreach ($post_types as $pt) {
        register_setting('cpsm_settings_group', 'cpsm_slug_' . $pt->name);
    }
});


/* =========================
   FIX PERMALINKS FOR POSTS
========================= */
add_filter('post_link', function($permalink, $post) {

    if ($post->post_type !== 'post') return $permalink;

    $base = get_option('cpsm_slug_post');

    if ($base) {
        return home_url('/' . $base . '/' . $post->post_name . '/');
    }

    return $permalink;

}, 10, 2);


/* =========================
   FIX PERMALINKS FOR CPT
========================= */
add_filter('post_type_link', function($permalink, $post) {

    if ($post->post_type === 'post') return $permalink;

    $base = get_option('cpsm_slug_' . $post->post_type);

    if ($base) {
        return home_url('/' . $base . '/' . $post->post_name . '/');
    }

    return $permalink;

}, 10, 2);


/* =========================
   REWRITE RULES
========================= */
add_action('init', function() {

    $post_types = cpsm_get_post_types();

    foreach ($post_types as $pt) {

        $base = get_option('cpsm_slug_' . $pt->name);

        if (!$base) continue;

        // DEFAULT POSTS
        if ($pt->name === 'post') {

            add_rewrite_rule(
                '^' . $base . '/([^/]+)/?$',
                'index.php?name=$matches[1]',
                'top'
            );

        } else {

            add_rewrite_rule(
                '^' . $base . '/([^/]+)/?$',
                'index.php?post_type=' . $pt->name . '&name=$matches[1]',
                'top'
            );
        }
    }
});


/* =========================
   FLUSH RULES ON SAVE
========================= */
add_action('updated_option', function($option) {

    if (strpos($option, 'cpsm_slug_') !== false) {
        flush_rewrite_rules();
    }

});


/* =========================
   FLUSH ON ACTIVATION
========================= */
register_activation_hook(__FILE__, function() {
    flush_rewrite_rules();
});