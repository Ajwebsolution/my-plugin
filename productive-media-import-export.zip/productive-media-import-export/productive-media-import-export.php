<?php
/**
 * Plugin Name: Complete Media Import Export
 * Plugin URI: https://yourwebsite.com/
 * Description: Export entire media library as ZIP with all images and metadata. Import from ZIP files seamlessly.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: complete-media-ie
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Complete_Media_Import_Export {
    
    private $plugin_path;
    private $plugin_url;
    
    public function __construct() {
        $this->plugin_path = plugin_dir_path(__FILE__);
        $this->plugin_url = plugin_dir_url(__FILE__);
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Handle exports
        add_action('admin_post_export_media_zip', array($this, 'handle_zip_export'));
        add_action('admin_post_export_media_csv', array($this, 'handle_csv_export'));
        
        // Handle imports
        add_action('admin_post_import_media_zip', array($this, 'handle_zip_import'));
        add_action('admin_post_import_media_csv', array($this, 'handle_csv_import'));
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Create necessary directories on activation
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    /**
     * Create necessary directories on activation
     */
    public function activate() {
        $upload_dir = wp_upload_dir();
        $export_dir = $upload_dir['basedir'] . '/media-export-temp';
        $import_dir = $upload_dir['basedir'] . '/media-import-temp';
        
        if (!file_exists($export_dir)) {
            wp_mkdir_p($export_dir);
        }
        if (!file_exists($import_dir)) {
            wp_mkdir_p($import_dir);
        }
        
        // Add htaccess to protect directories
        $htaccess = $export_dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, 'deny from all');
        }
        
        $htaccess = $import_dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, 'deny from all');
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_media_page(
            'Complete Media Import/Export',
            'Media Import/Export',
            'manage_options',
            'complete-media-ie',
            array($this, 'render_admin_page')
        );
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts($hook) {
        if ($hook != 'media_page_complete-media-ie') {
            return;
        }
        
        wp_enqueue_style('complete-media-ie-css', $this->plugin_url . 'style.css', array(), '1.0.0');
        wp_enqueue_script('complete-media-ie-js', $this->plugin_url . 'script.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('complete-media-ie-js', 'mediaIE', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('media_ie_nonce'),
            'max_upload_size' => size_format(wp_max_upload_size())
        ));
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>Complete Media Import/Export</h1>
            
            <div class="nav-tab-wrapper">
                <a href="#export" class="nav-tab nav-tab-active" id="export-tab">Export Media</a>
                <a href="#import" class="nav-tab" id="import-tab">Import Media</a>
            </div>
            
            <!-- Export Tab -->
            <div id="export-section" class="tab-section active">
                <div class="card">
                    <h2>Export Media Library as ZIP</h2>
                    <p>Export all media files with their metadata in a single ZIP file.</p>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="export-form">
                        <?php wp_nonce_field('export_media_zip_action', 'export_media_zip_nonce'); ?>
                        <input type="hidden" name="action" value="export_media_zip">
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Export Options</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="include_metadata" value="1" checked>
                                        Include metadata (alt text, titles, captions)
                                    </label>
                                    <br>
                                    <label>
                                        <input type="checkbox" name="preserve_folders" value="1" checked>
                                        Preserve folder structure (year/month)
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">File Types</th>
                                <td>
                                    <select name="file_types[]" multiple style="min-width:200px; height:120px;">
                                        <option value="all" selected>All Files</option>
                                        <option value="image/jpeg">JPEG Images</option>
                                        <option value="image/png">PNG Images</option>
                                        <option value="image/gif">GIF Images</option>
                                        <option value="image/svg+xml">SVG Files</option>
                                        <option value="image/webp">WebP Images</option>
                                        <option value="video/mp4">MP4 Videos</option>
                                        <option value="application/pdf">PDF Documents</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Date Range</th>
                                <td>
                                    <input type="date" name="date_from" placeholder="From">
                                    <input type="date" name="date_to" placeholder="To">
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-download"></span> Export as ZIP
                            </button>
                        </p>
                    </form>
                </div>
                
                <div class="card">
                    <h2>Export as CSV Only</h2>
                    <p>Export only metadata as CSV (no images).</p>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="export-form">
                        <?php wp_nonce_field('export_media_csv_action', 'export_media_csv_nonce'); ?>
                        <input type="hidden" name="action" value="export_media_csv">
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Include</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="include_urls" value="1" checked>
                                        File URLs
                                    </label>
                                    <br>
                                    <label>
                                        <input type="checkbox" name="include_paths" value="1">
                                        Local file paths
                                    </label>
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-secondary">
                                <span class="dashicons dashicons-media-spreadsheet"></span> Export CSV
                            </button>
                        </p>
                    </form>
                </div>
                
                <div class="card">
                    <h3>Media Library Stats</h3>
                    <?php
                    $total_files = wp_count_posts('attachment');
                    $total_count = array_sum((array)$total_files);
                    $total_size = $this->get_media_library_size();
                    ?>
                    <p>Total Files: <strong><?php echo $total_count; ?></strong></p>
                    <p>Total Size: <strong><?php echo size_format($total_size); ?></strong></p>
                </div>
            </div>
            
            <!-- Import Tab -->
            <div id="import-section" class="tab-section">
                <div class="card">
                    <h2>Import from ZIP</h2>
                    <p>Upload a ZIP file containing images and a CSV file. The ZIP should contain:</p>
                    <ul style="list-style:disc; margin-left:20px;">
                        <li><strong>images/</strong> folder with all media files</li>
                        <li><strong>media-export.csv</strong> file with metadata</li>
                    </ul>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data" class="import-form">
                        <?php wp_nonce_field('import_media_zip_action', 'import_media_zip_nonce'); ?>
                        <input type="hidden" name="action" value="import_media_zip">
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">ZIP File</th>
                                <td>
                                    <input type="file" name="zip_file" accept=".zip" required class="regular-text">
                                    <p class="description">Max file size: <?php echo size_format(wp_max_upload_size()); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Import Options</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="skip_duplicates" value="1" checked>
                                        Skip duplicate files
                                    </label>
                                    <br>
                                    <label>
                                        <input type="checkbox" name="overwrite_existing" value="1">
                                        Overwrite existing files
                                    </label>
                                    <br>
                                    <label>
                                        <input type="checkbox" name="skip_thumbnails" value="1">
                                        Skip thumbnail generation (faster import)
                                    </label>
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-upload"></span> Import ZIP
                            </button>
                        </p>
                    </form>
                </div>
                
                <div class="card">
                    <h2>Import from CSV</h2>
                    <p>Import media using a CSV file with URLs or file paths.</p>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data" class="import-form">
                        <?php wp_nonce_field('import_media_csv_action', 'import_media_csv_nonce'); ?>
                        <input type="hidden" name="action" value="import_media_csv">
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">CSV File</th>
                                <td>
                                    <input type="file" name="csv_file" accept=".csv" required>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Source Type</th>
                                <td>
                                    <select name="source_type" id="source_type">
                                        <option value="url">URLs (download from web)</option>
                                        <option value="path">Local file paths</option>
                                    </select>
                                </td>
                            </tr>
                            <tr class="path-options" style="display:none;">
                                <th scope="row">Base Path</th>
                                <td>
                                    <input type="text" name="base_path" value="<?php echo ABSPATH; ?>" class="regular-text">
                                    <p class="description">Prepended to relative paths in CSV</p>
                                </td>
                            </tr>
                        </table>
                        
                        <h3>CSV Format Examples:</h3>
                        <div style="background:#f5f5f5; padding:10px; margin:10px 0;">
                            <p><strong>URL Format:</strong></p>
                            <pre>url,alt,title,caption,description
https://example.com/image.jpg,Alt text,Title,Caption,Description</pre>
                            
                            <p><strong>Local Path Format:</strong></p>
                            <pre>file_path,alt,title,caption,description
wp-content/uploads/2026/02/image.jpg,Alt text,Title,Caption,Description</pre>
                        </div>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary">
                                <span class="dashicons dashicons-upload"></span> Import CSV
                            </button>
                        </p>
                    </form>
                </div>
            </div>
            
            <!-- Results Section (hidden by default) -->
            <div id="results-section" class="card" style="display:none; margin-top:20px;">
                <h2>Import Results</h2>
                <div id="results-content"></div>
            </div>
        </div>
        
        <style>
            .wrap { max-width: 1200px; margin: 20px auto; }
            .nav-tab-wrapper { margin-bottom: 20px; }
            .tab-section { display: none; }
            .tab-section.active { display: block; }
            .card { background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
            .card h2 { margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; }
            .form-table th { width: 150px; }
            .success { color: #46b450; }
            .error { color: #dc3232; }
            .warning { color: #f56e28; }
            .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 20px 0; }
            .stat-item { text-align: center; padding: 15px; background: #f8f9fa; border-radius: 4px; }
            .stat-value { font-size: 24px; font-weight: bold; display: block; }
            .stat-label { color: #666; }
            .progress-bar { height: 30px; background: #f0f0f1; border-radius: 4px; overflow: hidden; margin: 15px 0; }
            .progress-fill { height: 100%; background: #2271b1; width: 0; transition: width 0.3s; }
            .error-list { background: #fbeaea; border-left: 4px solid #dc3232; padding: 15px; margin: 15px 0; }
            .dashicons { margin-right: 5px; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.nav-tab').click(function(e) {
                e.preventDefault();
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                var target = $(this).attr('href');
                $('.tab-section').removeClass('active');
                if (target == '#export') {
                    $('#export-section').addClass('active');
                } else {
                    $('#import-section').addClass('active');
                }
            });
            
            // Show/hide path options based on source type
            $('#source_type').change(function() {
                if ($(this).val() == 'path') {
                    $('.path-options').show();
                } else {
                    $('.path-options').hide();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Handle ZIP export
     */
    public function handle_zip_export() {
        // Verify nonce and permissions
        if (!isset($_POST['export_media_zip_nonce']) || 
            !wp_verify_nonce($_POST['export_media_zip_nonce'], 'export_media_zip_action') ||
            !current_user_can('manage_options')) {
            wp_die('Security check failed');
        }
        
        // Create temp directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/media-export-temp/' . uniqid();
        wp_mkdir_p($temp_dir);
        
        // Create images directory
        $images_dir = $temp_dir . '/images';
        wp_mkdir_p($images_dir);
        
        // Get media items
        $args = array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        // Filter by date
        if (!empty($_POST['date_from'])) {
            $args['date_query'][] = array(
                'after' => sanitize_text_field($_POST['date_from']),
                'inclusive' => true
            );
        }
        if (!empty($_POST['date_to'])) {
            $args['date_query'][] = array(
                'before' => sanitize_text_field($_POST['date_to']),
                'inclusive' => true
            );
        }
        
        // Filter by file types
        if (isset($_POST['file_types']) && !in_array('all', $_POST['file_types'])) {
            $args['post_mime_type'] = array_map('sanitize_text_field', $_POST['file_types']);
        }
        
        $media_items = get_posts($args);
        
        if (empty($media_items)) {
            wp_die('No media found to export.');
        }
        
        // Create CSV file
        $csv_file = $temp_dir . '/media-export.csv';
        $this->generate_csv($csv_file, $media_items);
        
        // Copy images
        $preserve_folders = isset($_POST['preserve_folders']);
        $copied_files = 0;
        
        foreach ($media_items as $media) {
            $file_path = get_attached_file($media->ID);
            if (file_exists($file_path)) {
                if ($preserve_folders) {
                    $relative_path = str_replace($upload_dir['basedir'], '', $file_path);
                    $dest_dir = $images_dir . dirname($relative_path);
                    if (!file_exists($dest_dir)) {
                        wp_mkdir_p($dest_dir);
                    }
                    $dest = $images_dir . $relative_path;
                } else {
                    $dest = $images_dir . '/' . basename($file_path);
                }
                
                if (copy($file_path, $dest)) {
                    $copied_files++;
                }
            }
        }
        
        // Create ZIP
        $zip_file = $temp_dir . '/media-export.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file, ZipArchive::CREATE) !== TRUE) {
            wp_die('Could not create ZIP file');
        }
        
        // Add CSV
        $zip->addFile($csv_file, 'media-export.csv');
        
        // Add images
        $this->add_folder_to_zip($images_dir, $zip, 'images');
        
        $zip->close();
        
        // Send ZIP to browser
        $filename = 'media-export-' . date('Y-m-d-His') . '.zip';
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($zip_file));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        
        readfile($zip_file);
        
        // Clean up
        $this->recursive_rmdir($temp_dir);
        exit;
    }
    
    /**
     * Handle CSV export
     */
    public function handle_csv_export() {
        // Verify nonce and permissions
        if (!isset($_POST['export_media_csv_nonce']) || 
            !wp_verify_nonce($_POST['export_media_csv_nonce'], 'export_media_csv_action') ||
            !current_user_can('manage_options')) {
            wp_die('Security check failed');
        }
        
        $filename = 'media-export-' . date('Y-m-d-His') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
        
        // Headers
        $headers = array('ID', 'URL', 'File Name', 'File Type', 'File Size', 'Title', 'Alt Text', 'Caption', 'Description', 'Upload Date');
        if (isset($_POST['include_paths'])) {
            array_push($headers, 'File Path');
        }
        fputcsv($output, $headers);
        
        // Get media items
        $args = array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1
        );
        
        $media_items = get_posts($args);
        
        foreach ($media_items as $media) {
            $file_path = get_attached_file($media->ID);
            $file_size = file_exists($file_path) ? size_format(filesize($file_path)) : '';
            $alt_text = get_post_meta($media->ID, '_wp_attachment_image_alt', true);
            
            $row = array(
                $media->ID,
                wp_get_attachment_url($media->ID),
                basename($file_path),
                get_post_mime_type($media->ID),
                $file_size,
                $media->post_title,
                $alt_text,
                $media->post_excerpt,
                $media->post_content,
                $media->post_date
            );
            
            if (isset($_POST['include_paths'])) {
                $row[] = str_replace(ABSPATH, '', $file_path);
            }
            
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Handle ZIP import
     */
    public function handle_zip_import() {
        // Verify nonce and permissions
        if (!isset($_POST['import_media_zip_nonce']) || 
            !wp_verify_nonce($_POST['import_media_zip_nonce'], 'import_media_zip_action') ||
            !current_user_can('manage_options')) {
            wp_die('Security check failed');
        }
        
        // Check file upload
        if (!isset($_FILES['zip_file']) || $_FILES['zip_file']['error'] !== UPLOAD_ERR_OK) {
            wp_die('File upload failed. Error code: ' . $_FILES['zip_file']['error']);
        }
        
        // Create temp directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/media-import-temp/' . uniqid();
        wp_mkdir_p($temp_dir);
        
        // Extract ZIP
        $zip = new ZipArchive();
        $zip_file = $_FILES['zip_file']['tmp_name'];
        
        if ($zip->open($zip_file) !== TRUE) {
            $this->recursive_rmdir($temp_dir);
            wp_die('Could not open ZIP file');
        }
        
        $zip->extractTo($temp_dir);
        $zip->close();
        
        // Find CSV file
        $csv_file = $this->find_csv_file($temp_dir);
        if (!$csv_file) {
            $this->recursive_rmdir($temp_dir);
            wp_die('No CSV file found in ZIP. Please ensure your ZIP contains a media-export.csv file.');
        }
        
        // Find images directory
        $images_dir = $temp_dir . '/images';
        if (!is_dir($images_dir)) {
            $images_dir = $temp_dir; // Use root if images directory doesn't exist
        }
        
        // Import from CSV
        $result = $this->import_from_csv($csv_file, $images_dir . '/', $_POST);
        
        // Clean up
        $this->recursive_rmdir($temp_dir);
        
        // Show results
        $this->show_import_results($result);
    }
    
    /**
     * Handle CSV import
     */
    public function handle_csv_import() {
        // Verify nonce and permissions
        if (!isset($_POST['import_media_csv_nonce']) || 
            !wp_verify_nonce($_POST['import_media_csv_nonce'], 'import_media_csv_action') ||
            !current_user_can('manage_options')) {
            wp_die('Security check failed');
        }
        
        // Check file upload
        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            wp_die('File upload failed');
        }
        
        $source_type = $_POST['source_type'];
        $base_path = isset($_POST['base_path']) ? trailingslashit($_POST['base_path']) : ABSPATH;
        
        // Import from CSV
        $result = $this->import_from_csv($_FILES['csv_file']['tmp_name'], $base_path, $_POST, $source_type);
        
        // Show results
        $this->show_import_results($result);
    }
    
    /**
     * Import from CSV file
     */
    private function import_from_csv($csv_file, $base_path, $options, $source_type = 'url') {
        $result = array(
            'imported' => 0,
            'skipped' => 0,
            'failed' => 0,
            'errors' => array(),
            'successes' => array()
        );
        
        $skip_duplicates = isset($options['skip_duplicates']);
        $overwrite = isset($options['overwrite_existing']);
        $skip_thumbnails = isset($options['skip_thumbnails']);
        
        if (($handle = fopen($csv_file, 'r')) === false) {
            $result['errors'][] = 'Could not open CSV file';
            return $result;
        }
        
        // Get headers
        $headers = fgetcsv($handle);
        if (!$headers) {
            $result['errors'][] = 'Invalid CSV file';
            return $result;
        }
        
        $headers = array_map('strtolower', $headers);
        
        // Find columns
        $url_col = array_search('url', $headers);
        $path_col = array_search('file_path', $headers);
        $alt_col = array_search('alt', $headers);
        $title_col = array_search('title', $headers);
        $caption_col = array_search('caption', $headers);
        $description_col = array_search('description', $headers);
        
        $source_col = ($source_type == 'url') ? $url_col : $path_col;
        
        if ($source_col === false) {
            $result['errors'][] = 'CSV must contain a "' . ($source_type == 'url' ? 'url' : 'file_path') . '" column';
            return $result;
        }
        
        // Process each row
        while (($data = fgetcsv($handle)) !== false) {
            $source = trim($data[$source_col]);
            if (empty($source)) continue;
            
            // Get file
            if ($source_type == 'url') {
                // Download from URL
                $tmp = download_url($source);
                if (is_wp_error($tmp)) {
                    $result['failed']++;
                    $result['errors'][] = 'Failed to download: ' . $source . ' - ' . $tmp->get_error_message();
                    continue;
                }
                
                $file_array = array(
                    'name' => basename($source),
                    'tmp_name' => $tmp
                );
            } else {
                // Local file
                $full_path = $base_path . ltrim($source, '/');
                if (!file_exists($full_path)) {
                    $result['failed']++;
                    $result['errors'][] = 'File not found: ' . $source;
                    continue;
                }
                
                $file_array = array(
                    'name' => basename($full_path),
                    'tmp_name' => $full_path
                );
            }
            
            // Check for duplicates
            if ($skip_duplicates && !$overwrite) {
                $filename = $file_array['name'];
                $existing = get_posts(array(
                    'post_type' => 'attachment',
                    'meta_key' => '_wp_attached_file',
                    'meta_value' => $filename,
                    'meta_compare' => 'LIKE',
                    'posts_per_page' => 1
                ));
                
                if (!empty($existing)) {
                    $result['skipped']++;
                    if ($source_type == 'url') {
                        @unlink($tmp);
                    }
                    continue;
                }
            }
            
            // Import file
            $attachment_id = media_handle_sideload($file_array, 0);
            
            // Clean up temp file
            if ($source_type == 'url') {
                @unlink($tmp);
            }
            
            if (is_wp_error($attachment_id)) {
                $result['failed']++;
                $result['errors'][] = 'Failed to import: ' . basename($source) . ' - ' . $attachment_id->get_error_message();
                continue;
            }
            
            // Update metadata
            if ($alt_col !== false && isset($data[$alt_col]) && !empty($data[$alt_col])) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($data[$alt_col]));
            }
            
            $attachment_data = array('ID' => $attachment_id);
            if ($title_col !== false && isset($data[$title_col]) && !empty($data[$title_col])) {
                $attachment_data['post_title'] = sanitize_text_field($data[$title_col]);
            }
            if ($caption_col !== false && isset($data[$caption_col]) && !empty($data[$caption_col])) {
                $attachment_data['post_excerpt'] = sanitize_text_field($data[$caption_col]);
            }
            if ($description_col !== false && isset($data[$description_col]) && !empty($data[$description_col])) {
                $attachment_data['post_content'] = sanitize_text_field($data[$description_col]);
            }
            
            if (count($attachment_data) > 1) {
                wp_update_post($attachment_data);
            }
            
            // Skip thumbnails if requested
            if ($skip_thumbnails && strpos(get_post_mime_type($attachment_id), 'image/') === 0) {
                update_post_meta($attachment_id, '_wp_attachment_metadata', '');
            }
            
            $result['imported']++;
            $result['successes'][] = 'Imported: ' . basename($source);
        }
        
        fclose($handle);
        return $result;
    }
    
    /**
     * Generate CSV file
     */
    private function generate_csv($file, $media_items) {
        $output = fopen($file, 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
        
        // Headers
        fputcsv($output, array('url', 'alt', 'title', 'caption', 'description'));
        
        // Data
        foreach ($media_items as $media) {
            $alt_text = get_post_meta($media->ID, '_wp_attachment_image_alt', true);
            
            fputcsv($output, array(
                wp_get_attachment_url($media->ID),
                $alt_text,
                $media->post_title,
                $media->post_excerpt,
                $media->post_content
            ));
        }
        
        fclose($output);
    }
    
    /**
     * Add folder to ZIP recursively
     */
    private function add_folder_to_zip($folder, $zip, $zip_folder = '') {
        $handle = opendir($folder);
        while (false !== ($file = readdir($handle))) {
            if ($file != '.' && $file != '..') {
                $file_path = $folder . '/' . $file;
                $local_path = $zip_folder ? $zip_folder . '/' . $file : $file;
                
                if (is_dir($file_path)) {
                    $zip->addEmptyDir($local_path);
                    $this->add_folder_to_zip($file_path, $zip, $local_path);
                } else {
                    $zip->addFile($file_path, $local_path);
                }
            }
        }
        closedir($handle);
    }
    
    /**
     * Find CSV file in directory
     */
    private function find_csv_file($dir) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) == 'csv') {
                return $dir . '/' . $file;
            }
        }
        return false;
    }
    
    /**
     * Recursively delete directory
     */
    private function recursive_rmdir($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->recursive_rmdir($path) : unlink($path);
        }
        
        return rmdir($dir);
    }
    
    /**
     * Get total media library size
     */
    private function get_media_library_size() {
        $upload_dir = wp_upload_dir();
        $total_size = 0;
        
        $args = array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1
        );
        
        $media_items = get_posts($args);
        
        foreach ($media_items as $media) {
            $file = get_attached_file($media->ID);
            if (file_exists($file)) {
                $total_size += filesize($file);
            }
        }
        
        return $total_size;
    }
    
    /**
     * Show import results
     */
    private function show_import_results($result) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Import Results</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 40px; background: #f1f1f1; }
                .wrap { max-width: 800px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { margin-top: 0; color: #23282d; border-bottom: 2px solid #f1f1f1; padding-bottom: 15px; }
                .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 30px 0; }
                .stat { text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px; }
                .stat-value { font-size: 36px; font-weight: bold; line-height: 1.2; }
                .stat-label { color: #666; margin-top: 5px; }
                .stat.imported .stat-value { color: #46b450; }
                .stat.skipped .stat-value { color: #f56e28; }
                .stat.failed .stat-value { color: #dc3232; }
                .section { margin: 30px 0; }
                .section h2 { font-size: 18px; margin-bottom: 15px; }
                .success-list, .error-list { background: #f8f9fa; padding: 15px; border-radius: 4px; max-height: 300px; overflow-y: auto; }
                .success-item { color: #46b450; padding: 5px 0; border-bottom: 1px solid #e5e5e5; }
                .error-item { color: #dc3232; padding: 5px 0; border-bottom: 1px solid #e5e5e5; }
                .button { display: inline-block; padding: 10px 20px; background: #2271b1; color: #fff; text-decoration: none; border-radius: 4px; margin-right: 10px; }
                .button:hover { background: #135e96; }
                .button-secondary { background: #f1f1f1; color: #23282d; }
                .button-secondary:hover { background: #e5e5e5; }
            </style>
        </head>
        <body>
            <div class="wrap">
                <h1>Import Results</h1>
                
                <div class="stats">
                    <div class="stat imported">
                        <div class="stat-value"><?php echo $result['imported']; ?></div>
                        <div class="stat-label">Successfully Imported</div>
                    </div>
                    <div class="stat skipped">
                        <div class="stat-value"><?php echo $result['skipped']; ?></div>
                        <div class="stat-label">Skipped</div>
                    </div>
                    <div class="stat failed">
                        <div class="stat-value"><?php echo $result['failed']; ?></div>
                        <div class="stat-label">Failed</div>
                    </div>
                </div>
                
                <?php if (!empty($result['successes'])): ?>
                <div class="section">
                    <h2>Successfully Imported Files</h2>
                    <div class="success-list">
                        <?php foreach ($result['successes'] as $success): ?>
                            <div class="success-item">✓ <?php echo esc_html($success); ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($result['errors'])): ?>
                <div class="section">
                    <h2>Errors</h2>
                    <div class="error-list">
                        <?php foreach ($result['errors'] as $error): ?>
                            <div class="error-item">✗ <?php echo esc_html($error); ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div style="margin-top: 30px;">
                    <a href="<?php echo admin_url('upload.php'); ?>" class="button">View Media Library</a>
                    <a href="<?php echo admin_url('media.php?page=complete-media-ie'); ?>" class="button button-secondary">Import More</a>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// Initialize the plugin
new Complete_Media_Import_Export();